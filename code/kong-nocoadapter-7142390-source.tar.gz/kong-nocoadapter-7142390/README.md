# kong-nocoadapter

Kong 后的 NocoBase 文件上传/下载适配器。客户端使用
`POST /v1/files` 上传，并用返回的 `data.downloadUrl` 下载。上传时适配器读取 File
Manager 当前目标存储类型后自动选择：

- `s3-compatible` / `s3-pro`：预签名 URL、PUT 对象、创建附件记录。
- 其他 File Manager 存储（包括 Local、开源 S3/OSS/COS）：把 multipart 文件流交给
  NocoBase `attachments:create` 服务端上传。

镜像不包含环境地址、Token 或对象存储密钥。NocoBase host、版本适配和存储选择由
`nocobase.yaml` 配置；敏感 Token 使用环境变量或 Docker secret。

## 身份边界

存在两种严格分离的 Token：

| 身份 | 用途 | 不允许的用途 |
| --- | --- | --- |
| 全局/Root 配置 Token | 读取 NocoBase 系统配置元数据；当前用于 `storages:getBasicInfo` 判断 Local/S3 Pro，后续字段枚举也走此身份 | 不上传、不下载、不申请预签名、不创建附件记录 |
| 客户 NocoBase 原生 Token | `auth:check`、业务工作流、预签名、Local 上传、附件记录创建与文件下载 | 不写入配置或日志 |

因此 NocoBase 中的业务权限校验和审计身份沿用发起请求的客户。适配器不依赖 Kong
OAuth2，也不使用内部 API Key 代替客户身份。

## 对外接口

所有业务接口均不依赖 Kong OAuth2：

| 方法与路径 | 用途 | 认证 |
| --- | --- | --- |
| `POST /v1/auth/token` | NocoBase 账号密码换原生 Token | 账号密码 |
| `POST /simple-test` | 连通工作流 | 客户原生 Bearer Token |
| `POST /homerecord-query` | Home Record 查询 | 客户原生 Bearer Token |
| `POST /v1/files` | Local / S3 Pro 自适应上传 | 客户原生 Bearer Token |
| `GET /v1/files/{attachmentId}` | 按上传返回的附件 ID 流式下载 | 客户原生 Bearer Token |
| `POST /v1/create_intake_for_new_licence` | 校验并暂存 Create NLA 请求，立即返回 `Accepted` | 客户原生 Bearer Token |
| `GET /v1/expansion-aip-checklist` | 查询 Expansion AIP Checklist 位置码 | 客户原生 Bearer Token |
| `POST /v1/create_intake_for_expansion_aip` | 创建 Expansion AIP Intake 与申请 | 客户原生 Bearer Token |
| `POST /v1/update_expansion_aip_data` | 在 `Accepted` 窗口更新 Expansion AIP | 客户原生 Bearer Token |
| `GET /v1/request/{create_id}` | 查询当前业务状态、申请数据、Checklist 与 Notice | 客户原生 Bearer Token |

### `POST /v1/files`

`multipart/form-data` 参数：

| 参数 | 位置 | 必填 | 说明 |
| --- | --- | --- | --- |
| `file` | Form | 是 | 文件二进制内容，不是 Base64 |
| `externalRequestId` | Form | 否 | 客户端追踪编号 |
| `sha256` | Form | 否 | 64 位十六进制摘要；填写后会校验 |
| `Authorization` | Header | 是 | `Bearer <客户 NocoBase 原生 Token>` |
| `X-Request-ID` | Header | 否 | 链路编号；缺省时自动生成 |

```bash
curl --insecure --request POST 'https://127.0.0.1:28443/v1/files' \
  --header "Authorization: Bearer $CLIENT_ACCESS_TOKEN" \
  --header 'X-Request-ID: FILE-001' \
  --form 'externalRequestId=FILE-001' \
  --form 'file=@./application.pdf;type=application/pdf'
```

成功响应继续以 `data.id` 作为 NocoBase 附件记录 ID，并增加实际分支信息：

```json
{
  "requestId": "FILE-001",
  "externalRequestId": "FILE-001",
  "data": {
    "id": 98765,
    "filename": "...",
    "size": 1048576,
    "mimetype": "application/pdf",
    "storageId": 2,
    "storageType": "local",
    "uploadMode": "server-side",
    "downloadUrl": "/v1/files/98765",
    "sha256": "..."
  }
}
```

S3 Pro 响应的 `uploadMode` 为 `client-side-s3-pro`，并可能含有 `etag`。

### `GET /v1/files/{attachmentId}`

把上传响应的 `data.id` 放入路径，或直接使用 `data.downloadUrl`：

```bash
curl --insecure --location \
  --header "Authorization: Bearer $CLIENT_ACCESS_TOKEN" \
  --output ./downloaded-file \
  'https://127.0.0.1:28443/v1/files/98765'
```

adapter 先验证客户 Token，再以同一身份调用 NocoBase File Manager 的稳定文件入口。
NocoBase 根据附件记录的 `storageId` 选择 Local、S3 或 S3 Pro；adapter 流式返回文件，
不把整个文件读入内存。对象存储跳转不会携带客户 Authorization Header。

### 参数校验错误

所有 `422` 字段校验失败响应使用顶层错误码 `validation_failed`。字段明细位于
`error.details.fields`，并且 `code` 只使用以下两个值：

- `required`：字段缺失。
- `invalid_field`：字段已提供，但类型、格式、枚举值或关联规则无效。

原有业务校验错误名不再向客户端返回，也不增加 `error.details.reason`；具体失败原因
直接写入顶层 `error.message` 和对应字段的 `message`。

各业务接口原有的 `status`、`missing_required_fields` 和 Staging 审计状态继续保留；
`validation_errors` 与 `error.details.fields` 使用同一组 `path`、`code`、`message` 字段。

### `POST /v1/create_intake_for_new_licence`

请求先以客户 Token 写入 `t_api_request_staging`，再由 NocoBase 异步工作流创建 Intake、
原生 NLA、关联联系人/地址/处所和 Checklist。以下身份字段为必填：

| 字段 | 业务含义 | NocoBase 目标字段 |
| --- | --- | --- |
| `form_data.case_summary.submitter_user_id` | 业务提交人；可以且通常不同于 Token 所有者 | Intake/NLA `createdById` 及提交人岗位 |
| `form_data.case_summary.task_owner_user_id` | Intake Officer 用户 ID | Intake `fk_task_owner` |
| `form_data.case_summary.task_owner_post_code` | Intake Officer 岗位编码 | Intake `fk_task_owner_post` |

Token 所有者只用于接口权限及 Staging 审计；不能替代 `submitter_user_id`。NLA Intake
Type 不接受客户端传入，由工作流固定。完整字段和迁移说明见
`deliverables/NocoBase-NLA-Staging-Workflow_20260904.md`。

创建接口也不接收 `form_data.part_1.application_ref` 或 `d_no`。这两个值不由外部客户
提供，工作流不会写入 NLA 的 `f_p_no`、`f_d_no`；客户端提交任一字段都会得到
`422 invalid_request`，同时只保留 Staging 审计记录，不触发业务工作流。

每个 Checklist 项只提交一次上传响应的 `data.id`，字段名为 `attachment_id`。客户端
不提交文件名、日期、URL 或附件对象；工作流用该 ID 查询 NocoBase Attachment 记录，
先创建 Checklist `Details` 上传历史，再更新原生 Checklist 的 Latest Files 摘要。工作流
还会把 `form_data.part_5.attachment_ids` 自动组合到一条 `Online Platform` Intake
Activity，不要求客户端重复提交 Activity 附件参数。

地址同样不接受环境相关主键：API 没有 `address_select`、`rch_address_id` 或地址 `id`。
客户端在 `form_data.part_2.address`（以及联系人、处所的嵌套 `address`）中提交
`region_code`、`district_code`、`sub_district_code` 和具体地址字段；NocoBase 工作流按
code 解析字典名称、校验层级并创建地址关联。所有枚举字段使用 API 文档列明的 value，
不以界面显示文字匹配。

所有业务字段、地址关系和附件完成后，分发工作流以 `submitter_user_id` 调用原生
`Intake Form Submit - Sync`。原生岗位规则可以直接完成 Intake，或将其推进到待推荐/待
结案审批；adapter 不接受客户端传入审批状态，也不会绕过审批强制 Complete。关联 NLA
只由现有原生状态工作流在 Intake 真正完成后推进。分发工作流在这一次 Submit 返回后仅
回填 Staging 的 `succeeded`、Intake ID 和 Application ID，然后结束；禁止再次 Submit、
自动 Close 或以审批岗位用户继续执行业务流程。

`POST /v1/create_intake_for_changing_home` 使用同一套原生 Submit：工作流以
`form_data.case_summary.submitter_user_id`（不是接口 Token 帐号）调用
`Intake Form Submit - Sync`，把 CHI Intake 从 Draft 推进到 Pending Recommendation。
重新发布 CHI Create 工作流：

```bash
NOCOBASE_TOKEN=... python3 scripts/revise_nocobase_api_staging_workflows.py \
  --base-url http://119.91.104.211:13001/cmtf2 \
  --only "Create Changing Home Information" \
  --apply
```

## 配置

环境入口统一登记在 `config/environments.yaml`：

| 环境 | Kong 配置 | Adapter 配置 | 上游模式 |
| --- | --- | --- | --- |
| `development` | `config/kong.local-test-dbless.yml` | `config/nocobase.local-test.yaml` | 当前开发环境，直连 `119.91.104.211:13001/cmtf2` |
| `local_test` | 与 `development` 相同 | 与 `development` 相同 | 本机测试兼容名称 |
| `online_test` | `config/kong.211-dbless.yml` | `config/nocobase.211.yaml` | 211 Docker Host 直连 `13000/cmtf2` |
| `uat` | `config/kong.uat-dbless.yml` | `config/nocobase.uat.yaml` | Docker 容器直连 UAT 内网 NocoBase；Nginx 转发到 Kong `18000` |
| `production` | 未配置 | 未配置 | 禁止部署，不能继承任何测试上游 |

检查配置选择及环境隔离约束：

```bash
python3 scripts/manage_environment.py validate development
python3 scripts/manage_environment.py validate online_test
UAT_ENV_FILE=uat.env.example python3 scripts/manage_environment.py validate uat
```

本机启动隔离测试环境：

```bash
scripts/compose_environment.sh development up -d --build
```

要同时验收最终 Gateway 镜像（而不是直接使用基础 `kong:3.9.3`），先构建镜像并覆盖
本地 Profile 的镜像变量：

```bash
docker build -f Dockerfile.kong -t kong-3.93:20260924-r3 .
KONG_IMAGE=kong-3.93:20260924-r3 \
  docker compose --env-file config/compose.local-test.env \
  -f docker-compose.yml up -d --no-build --pull never --force-recreate \
  kong-nocoadapter kong-gateway
```

Gateway 镜像优先加载 Compose 只读挂载的环境专属 DB-less 配置；镜像内 211 配置仅是
缺少挂载时的安全回退。因此新增路由不会再被旧的镜像内模板覆盖。

本地监听端口为 HTTP `127.0.0.1:28000`、HTTPS `127.0.0.1:28443`和
Admin API `127.0.0.1:28001`；容器名和 Docker Network 也使用
`kong-dbless-development-*` / `kong-dbless-local-test-*` 前缀，与 SIT/UAT
编排完全隔离。

211 服务器使用 `online_test` Profile 原地升级现有 `kong-dbless` 编排。该 Profile 固定
使用交付镜像 `kong-3.93:20260924-r3` 与
`kong-3.93-adapter:20260924-r5`、对外 HTTPS
`443`，并直连宿主机 `13000/cmtf2`。先从离线交付包加载两个镜像，再原地重建旧容器：

```bash
python3 scripts/manage_environment.py validate online_test
scripts/compose_environment.sh online_test up -d \
  --no-build --pull never --force-recreate kong-nocoadapter kong-gateway
```

不要在 Mac 上运行 `online_test`，因为 `host.docker.internal:13000` 必须解析到 211
宿主机。

UAT 使用本地 Docker 镜像，不使用镜像仓库。只传输 211 构出的一个 `.tar`，在 UAT
主机解包后用文件管理器修改 `.env` 中的 NocoBase URL 与 UAT API Key，再分别
加载镜像、生成 Kong/Adapter YAML、运行 Docker Compose。下载后完整指引见
`docs/Kong-UAT-Offline-Deployment_zh-CN.md`；不要把 211 的 NocoBase 地址或 Token
直接用于 UAT。离线包中的 `config/environments.yaml` 由打包脚本生成，只保留
`uat` Profile；仓库里的多环境清单不会原样进入包内。

通用模板为 `config/nocobase.yaml`。关键配置：

```yaml
nocobase:
  base_url: "http://119.91.104.211:13001/cmtf2"
  authenticator: "basic"
  storage:
    selection: default
    name: ""
    attachment_field_context: ""
```

- `selection: default` 与 211 旧 `/v1/files` 一致，使用 NocoBase 默认存储。
- `selection: named` 用于固定存储，同时填写 `name`。
- 非默认存储如果依赖附件字段选择，填写
  `attachment_field_context: collection.field`。
- `STORAGE_CACHE_SECONDS=0` 会在每次上传时重新读取配置，存储由 Local 切换到 S3 Pro
  后无需改客户端或重建镜像。

Compose 会从服务器 `.env` 注入运行参数。默认上传上限为 500 MiB，允许所有 MIME：

```dotenv
STORAGE_CACHE_SECONDS=0
MAX_FILE_BYTES=524288000
ALLOWED_MIME_TYPES=*
UPLOAD_TIMEOUT_SECONDS=600
SOURCE_SYSTEM=OP
```

这些值修改后需重新创建 adapter 容器才能生效。NocoBase host、应用 path、存储选择和
API 路径只在 `config/nocobase.211.yaml` 配置，避免同一值分散在多个文件。

全局配置 Token 二选一注入，不得写入 YAML：

```text
NOCOBASE_CONFIG_TOKEN=...
NOCOBASE_CONFIG_TOKEN_FILE=/run/secrets/nocobase_config_token
```

Root Token 是可扩展的系统配置读取身份，例如读取存储配置或字段枚举；任何客户业务
读写仍必须携带客户原生 Token。适配器从不读取 S3 Access Key/Secret，S3 Pro 密钥仍
只由 NocoBase 管理。

## 211 新 DB-less 编排

服务器代码目录固定为 `/Servers/Kong-db-less`；旧 `/Servers/Kong` 只保留原编排和
`kong_db_data`，不与新代码目录混用。

在服务器代码根目录直接执行 Compose。相关文件为：

- `/Servers/Kong-db-less/docker-compose.yml`：仅 Kong 3.9.3 DB-less 与 adapter，
  无 PostgreSQL/数据卷。
- `config/kong.211-dbless.yml`：发布原生登录、`simple-test`、
  `homerecord-query`、Create NLA、统一上传与文件下载六条 Route，不含 OAuth2。
- `config/nocobase.211.yaml`：211 非敏感上游与默认存储选择。
- 根目录 `.env.example`：并行验证端口及固定镜像版本。

完整人工部署、切换和回滚步骤见
`deliverables/Kong-211-DBLess-Native-Token-Deployment-Guide_zh-CN.md`。

## 本地开发

```bash
cd /Users/work/noco/kong-nocoadapter
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env
```

在未提交的 `.env` 填写测试用 `NOCOBASE_CONFIG_TOKEN` 后：

```bash
set -a
source .env
set +a
export NOCOBASE_CONFIG_PATH="$PWD/config/nocobase.yaml"
uvicorn app.main:app --host 127.0.0.1 --port 18081
```

健康检查只检查进程和身份模式，不使用 Root Token 模拟客户写入：

```bash
curl http://127.0.0.1:18081/health/live
curl http://127.0.0.1:18081/health/ready
```

## 错误格式

```json
{
  "ok": false,
  "error": {
    "code": "file_too_large",
    "message": "The file exceeds the configured size limit",
    "requestId": "...",
    "details": {"maxBytes": 20971520}
  }
}
```

常见错误：

| HTTP | code | 说明 |
| --- | --- | --- |
| 401 | `client_token_required` / `invalid_client_token` | 客户 Token 缺失、过期或无效 |
| 403 | `nocobase_permission_denied` | 客户没有对应 NocoBase 操作权限 |
| 413 | `file_too_large` / `file_too_large_for_storage` | 超过 adapter 或存储限制 |
| 415 | `unsupported_media_type` | MIME 不在白名单 |
| 422 | `validation_failed` | 字段或业务规则校验失败；字段码仅为 `required` / `invalid_field` |
| 502 | `object_upload_failed` / `attachment_create_failed` | 上游上传步骤失败 |
| 404 | `attachment_not_found` | 附件记录或存储对象不存在 |
| 502 | `file_download_failed` / `invalid_download_redirect` | 文件下载或上游跳转异常 |
| 503 | `storage_config_token_missing` / `storage_config_access_denied` | Root 系统配置 Token 在读取存储元数据时缺失、无效或权限不足 |
| 504 | `upstream_timeout` | 上游超时 |

S3 PUT 成功但附件记录创建失败时可能产生孤立对象；服务会返回失败并记录对象 Key，
建议在对象存储配置未完成上传对象的生命周期清理。

## 验证

```bash
pytest -q
ruff check app tests
python -m compileall -q app tests
docker compose --env-file .env.example -f docker-compose.yml config
```

自动化测试使用模拟上游，不会写入远程 NocoBase 或对象存储。
