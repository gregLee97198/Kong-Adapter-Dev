"""Kong-facing file upload adapter."""

