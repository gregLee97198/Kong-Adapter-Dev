"""DB-backed Create idempotency for the public client request ID.

This service is only enabled after the accepted-CREATE unique index has been
audited and installed.  A preliminary GET improves retries, but the database
constraint is the concurrency arbiter: two adapters may both observe no row.
"""

from __future__ import annotations

import math
from typing import Any

from .errors import AdapterError


def _public_body(value: object) -> object:
    """Remove server-derived workflow hints before comparing client bodies."""
    if isinstance(value, dict):
        return {
            key: _public_body(item)
            for key, item in value.items()
            if not (isinstance(key, str) and key.startswith("_"))
        }
    if isinstance(value, list):
        return [_public_body(item) for item in value]
    return value


def _same_json_value(left: object, right: object) -> bool:
    """Compare JSON values after PostgreSQL's int/float normalization.

    NocoBase's JSON column may read 12000.0 back as 12000.  Those are the
    same finite JSON number, but Python booleans must not inherit integer
    equality and every nonnumeric JSON type remains exact.  Object order is
    irrelevant; array order is significant.
    """
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) or isinstance(right, (int, float)):
        return (
            isinstance(left, (int, float))
            and isinstance(right, (int, float))
            and (not isinstance(left, float) or math.isfinite(left))
            and (not isinstance(right, float) or math.isfinite(right))
            and left == right
        )
    if isinstance(left, dict) or isinstance(right, dict):
        return (
            isinstance(left, dict)
            and isinstance(right, dict)
            and left.keys() == right.keys()
            and all(_same_json_value(left[key], right[key]) for key in left)
        )
    if isinstance(left, list) or isinstance(right, list):
        return (
            isinstance(left, list)
            and isinstance(right, list)
            and len(left) == len(right)
            and all(
                _same_json_value(left_item, right_item)
                for left_item, right_item in zip(left, right)
            )
        )
    return type(left) is type(right) and left == right


def _same_public_body(left: object, right: object) -> bool:
    return _same_json_value(_public_body(left), _public_body(right))


class CreateIdempotencyService:
    def __init__(self, client: Any, source_system: str) -> None:
        self._client = client
        self._source_system = source_system

    async def find(
        self,
        *,
        token: str,
        transport_request_id: str,
        client_request_id: str,
    ) -> dict[str, Any] | None:
        result = await self._client.list_records(
            collection="t_api_request_staging",
            request_id=transport_request_id,
            authorization_token=token,
            filters={
                "$and": [
                    {"f_source_system": {"$eq": self._source_system}},
                    {"f_request_event": {"$eq": "CREATE"}},
                    {"f_client_request_id": {"$eq": client_request_id}},
                ]
            },
            page=1,
            page_size=2,
            sort=("id",),
        )
        rows = result.get("data") if isinstance(result, dict) else None
        if not isinstance(rows, list) or len(rows) > 1:
            raise self._integrity_error()
        candidates: dict[int, dict[str, Any]] = {}
        for row in rows:
            if (
                not isinstance(row, dict)
                or row.get("f_client_request_id") != client_request_id
            ):
                raise self._integrity_error()
            record_id = row.get("id")
            if not isinstance(record_id, int) or isinstance(record_id, bool):
                raise self._integrity_error()
            candidates[record_id] = row

        # Historical accepted CREATE rows predate f_client_request_id.  The
        # forward-only unique index does not change them.  A JSON-path lookup
        # must therefore precede every new INSERT; choosing one of multiple
        # old successful records would silently swap a client's create_id.
        for page in range(1, 101):
            legacy_result = await self._client.list_records(
                collection="t_api_request_staging",
                request_id=transport_request_id,
                authorization_token=token,
                filters={
                    "$and": [
                        {"f_source_system": {"$eq": self._source_system}},
                        {"f_request_event": {"$eq": "CREATE"}},
                        {"f_request_body.request_id": {"$eq": client_request_id}},
                    ]
                },
                page=page,
                page_size=200,
                sort=("id",),
            )
            legacy_rows = (
                legacy_result.get("data") if isinstance(legacy_result, dict) else None
            )
            if not isinstance(legacy_rows, list):
                raise self._integrity_error()
            for row in legacy_rows:
                if not isinstance(row, dict):
                    raise self._integrity_error()
                body = row.get("f_request_body")
                if (
                    row.get("f_source_system") != self._source_system
                    or row.get("f_request_event") != "CREATE"
                    or not isinstance(body, dict)
                    or body.get("request_id") != client_request_id
                    or row.get("f_client_request_id") not in (None, client_request_id)
                ):
                    # Fail closed if the upstream silently ignores JSON-path
                    # filtering; never insert after an unverified lookup.
                    raise self._integrity_error()
                if row.get("f_status") in {"missing_required", "invalid_request"}:
                    continue
                record_id = row.get("id")
                if not isinstance(record_id, int) or isinstance(record_id, bool):
                    raise self._integrity_error()
                candidates[record_id] = row
                if len(candidates) > 1:
                    raise AdapterError(
                        409,
                        "duplicate_request_id",
                        "request_id matches multiple existing Create requests",
                    )
            if len(legacy_rows) < 200:
                break
        else:
            raise self._integrity_error()
        return next(iter(candidates.values()), None)

    def replay_id(
        self,
        row: dict[str, Any],
        *,
        client_request_id: str,
        create_api_type: str,
        application_type: str,
        client_body: object,
    ) -> int:
        record_id = row.get("id")
        if (
            not isinstance(record_id, int)
            or isinstance(record_id, bool)
            or record_id < 1
            or row.get("f_request_event") != "CREATE"
            or row.get("f_source_system") != self._source_system
            or row.get("f_client_request_id") not in (None, client_request_id)
            or row.get("f_status") in {"missing_required", "invalid_request"}
        ):
            raise self._integrity_error()
        body = row.get("f_request_body")
        if not isinstance(body, dict) or body.get("request_id") != client_request_id:
            raise self._integrity_error()
        if (
            row.get("f_api_type") != create_api_type
            or row.get("f_application_type") != application_type
            or not _same_public_body(row.get("f_request_body"), client_body)
        ):
            raise AdapterError(
                409,
                "duplicate_request_id",
                "request_id was already used with a different Create payload",
            )
        return record_id

    async def create_or_replay(
        self,
        *,
        token: str,
        transport_request_id: str,
        client_request_id: str,
        create_api_type: str,
        application_type: str,
        client_body: dict[str, Any],
        staging_values: dict[str, Any],
    ) -> dict[str, Any]:
        existing = await self.find(
            token=token,
            transport_request_id=transport_request_id,
            client_request_id=client_request_id,
        )
        if existing is not None:
            return {
                "id": self.replay_id(
                    existing,
                    client_request_id=client_request_id,
                    create_api_type=create_api_type,
                    application_type=application_type,
                    client_body=client_body,
                )
            }
        values = {**staging_values, "f_client_request_id": client_request_id}
        try:
            created = await self._client.create_request_staging(
                request_id=transport_request_id,
                authorization_token=token,
                values=values,
            )
        except AdapterError as exc:
            if exc.status_code in {401, 403}:
                raise
            # Unique conflict and ambiguous transport failures both require
            # exact persisted-key readback.  Never retry an INSERT blindly.
            row = await self.find(
                token=token,
                transport_request_id=transport_request_id,
                client_request_id=client_request_id,
            )
            if row is None:
                raise AdapterError(
                    503,
                    "create_idempotency_unconfirmed",
                    "Create acceptance could not be confirmed; retry with the "
                    "same request_id",
                ) from exc
            record_id = self.replay_id(
                row,
                client_request_id=client_request_id,
                create_api_type=create_api_type,
                application_type=application_type,
                client_body=client_body,
            )
            return {"id": record_id}
        record_id = created.get("id") if isinstance(created, dict) else None
        if (
            not isinstance(record_id, int)
            or isinstance(record_id, bool)
            or record_id < 1
        ):
            raise self._integrity_error()
        persisted = await self.find(
            token=token,
            transport_request_id=transport_request_id,
            client_request_id=client_request_id,
        )
        if persisted is None or persisted.get("id") != record_id:
            # Catch a silently ignored f_client_request_id before reporting
            # acceptance.  The DB index must already have been verified by
            # deployment; this readback is a second, per-request guard.
            raise self._integrity_error()
        self.replay_id(
            persisted,
            client_request_id=client_request_id,
            create_api_type=create_api_type,
            application_type=application_type,
            client_body=client_body,
        )
        return created

    @staticmethod
    def _integrity_error() -> AdapterError:
        return AdapterError(
            503,
            "create_idempotency_integrity_error",
            "Create idempotency state could not be verified",
        )
