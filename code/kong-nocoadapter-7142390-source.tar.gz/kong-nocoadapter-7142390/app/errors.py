from __future__ import annotations

from typing import Any, Optional


class AdapterError(Exception):
    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        *,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details


class ConfigurationError(RuntimeError):
    """Raised when startup configuration is invalid."""
