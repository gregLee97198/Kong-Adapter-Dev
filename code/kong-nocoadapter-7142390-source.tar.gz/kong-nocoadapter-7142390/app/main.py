from __future__ import annotations

import asyncio
import logging
import os
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path as FilePath
from typing import Annotated, Any, Optional

from fastapi import (
    Body,
    FastAPI,
    File,
    Form,
    Header,
    Path,
    Query,
    Request,
    UploadFile,
)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import ValidationError as PydanticValidationError

from .create_idempotency import CreateIdempotencyService
from .errors import AdapterError
from .models import (
    CreateIntakeForChangeBedsRequest,
    CreateIntakeForChangeDirectorsRequest,
    CreateIntakeForChangeHomeManagerRequest,
    CreateIntakeForChangeNurseInChargeRequest,
    CreateIntakeForChangeOperationModeRequest,
    CreateIntakeForChangingHomeRequest,
    CreateIntakeForExpansionAipRequest,
    CreateIntakeForNewLicenceRequest,
    CreateIntakeForProsecutionRequest,
    CreateIntakeForRevokeLicenceRequest,
    CreateIntakeForRpRequest,
    CreateIntakeForSelfWithdrawRequest,
    CreateIntakeForSpecificHourRequest,
    CreateLicenceRenewalRequest,
    FileUploadResult,
    UpdateChangeBedsDataRequest,
    UpdateChangeDirectorsDataRequest,
    UpdateChangeHomeManagerDataRequest,
    UpdateChangeNurseInChargeDataRequest,
    UpdateChangeOperationModeDataRequest,
    UpdateChangingHomeDataRequest,
    UpdateExpansionAipDataRequest,
    UpdateLicenceRenewalDataRequest,
    UpdateNewLicenceDataRequest,
    UpdateProsecutionDataRequest,
    UpdateRevokeLicenceDataRequest,
    UpdateRpDataRequest,
    UpdateSelfWithdrawDataRequest,
    UpdateSpecificHourDataRequest,
    nla_rch_type_matches_office,
)
from .nocobase_client import NocoBaseClient, validate_byte_range
from .portable_runtime import load_portable_runtime
from .query_service import QueryService
from .settings import Settings
from .storage_cache import StorageCache
from .update_queue_release import QUEUE_FAMILY_API_TYPES, load_reviewed_queue_release
from .update_queue_service import (
    PUBLIC_UPDATE_QUEUE_TYPES,
    QueueAdmissionService,
    QueueFamily,
    parse_enabled_queue_families,
)
from .upload_service import UploadService

ADAPTER_VERSION = os.getenv("ADAPTER_VERSION", "0.24.0").strip() or "0.24.0"
NEW_LICENCE_APPLICATION_TYPE = "new_licence"
NEW_LICENCE_INITIAL_STATUS = "Accepted"
STAGING_SUBMITTED_STATUS = "submitted"
HTTP_ACCEPTED_STATUS = "Accepted"
OTHER_LOCAL_QUEUE_PILOT_CONFIRMATIONS = {
    "changing_home": (
        "LOCAL_13001_CHANGING_HOME_FIFO_PILOT_20261017_"
        "d5e5a81d9f564742a2869c1a764a2ce7"
    ),
    "self_withdraw": (
        "LOCAL_13001_SELF_WITHDRAW_FIFO_PILOT_20261017_"
        "da0f765676089167f9d3fedfeaf9dc74"
    ),
    "expansion_aip": (
        "LOCAL_13001_EXPANSION_AIP_FIFO_PILOT_20261017_"
        "0851d57a5a7b1adb61a65754e7cc8668"
    ),
    "responsible_person": (
        "LOCAL_13001_RESPONSIBLE_PERSON_FIFO_PILOT_20261017_"
        "62333c46a80e0c0882de82926e5fbf4e"
    ),
    "specific_hour": (
        "LOCAL_13001_SPECIFIC_HOUR_FIFO_PILOT_20261017_"
        "80ed0e3f8fb252b8ee3fe5a39bb6a746"
    ),
    "change_home_manager": (
        "LOCAL_13001_CHANGE_HOME_MANAGER_FIFO_PILOT_20261017_"
        "cf4ffc4144fecc9e22f78f4a2afa8194"
    ),
    "change_nurse_in_charge": (
        "LOCAL_13001_CHANGE_NURSE_IN_CHARGE_FIFO_PILOT_20261017_"
        "f64b0290646998f1e7a32d584c5528ad"
    ),
    "change_beds": (
        "LOCAL_13001_CHANGE_BEDS_FIFO_PILOT_20261017_"
        "667b2b0a24d5920ca9a4df8895847543"
    ),
    "change_operation_mode": (
        "LOCAL_13001_CHANGE_OPERATION_MODE_FIFO_PILOT_20261017_"
        "52d27098aeca949070482d19b58ddab6"
    ),
    "change_directors": (
        "LOCAL_13001_CHANGE_DIRECTORS_FIFO_PILOT_20261017_"
        "c8742be2e8456b342c1cd7824387b2c4"
    ),
}
NEW_LICENCE_OFFICE_CODES = frozenset({"LORCHE", "LORCHD"})
CHECKLIST_OFFICE_CODE_ERRORS = {
    "/v1/new-licence-checklist": "invalid_office_code",
    "/v1/changing-home-checklist": "invalid_request",
    "/v1/licence-renewal-checklist": "invalid_office_code",
    "/v1/expansion-aip-checklist": "invalid_office_code",
    "/v1/self-withdraw-checklist": "invalid_office_code",
    "/v1/specific-hour-checklist": "invalid_office_code",
    "/v1/rp-checklist": "invalid_office_code",
}
CHANGING_HOME_APPLICATION_TYPE = "changing_home"
CHANGING_HOME_INITIAL_STATUS = "Accepted"
CHANGING_HOME_CREATE_API_TYPE = "create_intake_for_changing_home"
CHANGING_HOME_UPDATE_API_TYPE = "update_changing_home_data"
SELF_WITHDRAW_APPLICATION_TYPE = "self_withdraw"
SELF_WITHDRAW_INITIAL_STATUS = "Accepted"
SELF_WITHDRAW_CREATE_API_TYPE = "create_intake_for_self_withdraw"
SELF_WITHDRAW_UPDATE_API_TYPE = "update_self_withdraw_data"
REVOKE_LICENCE_APPLICATION_TYPE = "revoke_licence"
REVOKE_LICENCE_INITIAL_STATUS = "Accepted"
REVOKE_LICENCE_CREATE_API_TYPE = "create_intake_for_revoke_licence"
REVOKE_LICENCE_UPDATE_API_TYPE = "update_revoke_licence_data"
SPECIFIC_HOUR_APPLICATION_TYPE = "specific_hour"
SPECIFIC_HOUR_INITIAL_STATUS = "Accepted"
SPECIFIC_HOUR_CREATE_API_TYPE = "create_intake_for_specific_hour"
SPECIFIC_HOUR_UPDATE_API_TYPE = "update_specific_hour_data"
RESPONSIBLE_PERSON_APPLICATION_TYPE = "responsible_person"
RESPONSIBLE_PERSON_INITIAL_STATUS = "Accepted"
RESPONSIBLE_PERSON_CREATE_API_TYPE = "create_intake_for_rp"
RESPONSIBLE_PERSON_UPDATE_API_TYPE = "update_rp_data"
EXPANSION_AIP_APPLICATION_TYPE = "expansion_aip"
EXPANSION_AIP_INITIAL_STATUS = "Accepted"
EXPANSION_AIP_CREATE_API_TYPE = "create_intake_for_expansion_aip"
EXPANSION_AIP_UPDATE_API_TYPE = "update_expansion_aip_data"
READY_PARENT_REQUIRED_UPDATE_APPLICATION_TYPES = frozenset(
    {
        SELF_WITHDRAW_APPLICATION_TYPE,
        REVOKE_LICENCE_APPLICATION_TYPE,
        SPECIFIC_HOUR_APPLICATION_TYPE,
        RESPONSIBLE_PERSON_APPLICATION_TYPE,
        "change_home_manager",
        "change_beds",
        "change_operation_mode",
        "change_directors",
        "change_nurse_in_charge",
        EXPANSION_AIP_APPLICATION_TYPE,
    }
)
CHANGE_HOME_MANAGER_APPLICATION_TYPE = "change_home_manager"
CHANGE_HOME_MANAGER_INITIAL_STATUS = "Accepted"
CHANGE_HOME_MANAGER_CREATE_API_TYPE = "create_intake_for_change_home_manager"
CHANGE_HOME_MANAGER_UPDATE_API_TYPE = "update_change_home_manager_data"
CHANGE_BEDS_APPLICATION_TYPE = "change_beds"
CHANGE_BEDS_INITIAL_STATUS = "Accepted"
CHANGE_BEDS_CREATE_API_TYPE = "create_intake_for_change_beds"
CHANGE_BEDS_UPDATE_API_TYPE = "update_change_beds_data"
CHANGE_OPERATION_MODE_APPLICATION_TYPE = "change_operation_mode"
CHANGE_OPERATION_MODE_INITIAL_STATUS = "Accepted"
CHANGE_OPERATION_MODE_CREATE_API_TYPE = "create_intake_for_change_operation_mode"
CHANGE_OPERATION_MODE_UPDATE_API_TYPE = "update_change_operation_mode_data"
CHANGE_DIRECTORS_APPLICATION_TYPE = "change_directors"
CHANGE_DIRECTORS_INITIAL_STATUS = "Accepted"
CHANGE_DIRECTORS_CREATE_API_TYPE = "create_intake_for_change_directors"
CHANGE_DIRECTORS_UPDATE_API_TYPE = "update_change_directors_data"
CHANGE_NURSE_APPLICATION_TYPE = "change_nurse_in_charge"
CHANGE_NURSE_INITIAL_STATUS = "Accepted"
CHANGE_NURSE_CREATE_API_TYPE = "create_intake_for_change_nurse_in_charge"
CHANGE_NURSE_UPDATE_API_TYPE = "update_change_nurse_in_charge_data"
CHANGE_MONITORING_APPLICATION_TYPES = frozenset(
    {
        CHANGE_HOME_MANAGER_APPLICATION_TYPE,
        CHANGE_BEDS_APPLICATION_TYPE,
        CHANGE_OPERATION_MODE_APPLICATION_TYPE,
        CHANGE_DIRECTORS_APPLICATION_TYPE,
        CHANGE_NURSE_APPLICATION_TYPE,
    }
)
PROSECUTION_APPLICATION_TYPE = "prosecution"
PROSECUTION_INITIAL_STATUS = "Accepted"
PROSECUTION_CREATE_API_TYPE = "create_intake_for_prosecution"
PROSECUTION_UPDATE_API_TYPE = "update_prosecution_data"
LICENCE_RENEWAL_APPLICATION_TYPE = "licence_renewal"
LICENCE_RENEWAL_INITIAL_STATUS = "Accepted"
LICENCE_RENEWAL_CREATE_API_TYPE = "create_licence_renewal"
LICENCE_RENEWAL_UPDATE_API_TYPE = "update_licence_renewal_data"
# Create readiness is a read-only prerequisite. It is intentionally separate
# from the reservation set above, which writes f_active_update_id and must not
# be expanded until the corresponding NocoBase fields have been installed.
CREATE_READY_REQUIRED_UPDATE_APPLICATION_TYPES = (
    READY_PARENT_REQUIRED_UPDATE_APPLICATION_TYPES
    | {
        NEW_LICENCE_APPLICATION_TYPE,
        CHANGING_HOME_APPLICATION_TYPE,
        LICENCE_RENEWAL_APPLICATION_TYPE,
    }
)
CMTF_SOURCE_SYSTEM = "CMTF"
VALIDATION_REQUIRED_CODE = "required"
VALIDATION_INVALID_FIELD_CODE = "invalid_field"

CHECKLIST_APPLICATION_COLLECTIONS = {
    CHANGING_HOME_APPLICATION_TYPE: "t_licence_app",
    SELF_WITHDRAW_APPLICATION_TYPE: "t_self_withdraw_licence_application",
    REVOKE_LICENCE_APPLICATION_TYPE: "t_self_withdraw_licence_application",
    SPECIFIC_HOUR_APPLICATION_TYPE: "t_specific",
    RESPONSIBLE_PERSON_APPLICATION_TYPE: "t_rp_application",
    EXPANSION_AIP_APPLICATION_TYPE: "t_licence_app",
    LICENCE_RENEWAL_APPLICATION_TYPE: "t_licence_app",
}


def _ensure_parent_create_ready(
    original_request: dict[str, Any], *, require_intake_id: bool = True
) -> None:
    if (
        original_request.get("f_status") == "succeeded"
        and (
            not require_intake_id
            or original_request.get("f_intake_id") not in {None, ""}
        )
        and original_request.get("f_application_id") not in {None, ""}
    ):
        return
    raise AdapterError(
        409,
        "create_not_ready",
        "Update is allowed only after Create has succeeded and "
        "business identifiers are available.",
        details={
            "field": "create_id",
            "status": original_request.get("f_status"),
        },
    )


def _validation_fields(errors: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Convert Pydantic errors to the public two-code field contract."""
    fields: list[dict[str, str]] = []
    location_prefixes = {"body", "cookie", "header", "path", "query"}
    for item in errors:
        location = [str(value) for value in item.get("loc", ())]
        if len(location) > 1 and location[0] in location_prefixes:
            location = location[1:]
        error_type = str(item.get("type", "validation_error"))
        fields.append(
            {
                "path": ".".join(location),
                "code": (
                    VALIDATION_REQUIRED_CODE
                    if error_type == "missing"
                    else VALIDATION_INVALID_FIELD_CODE
                ),
                "message": str(item.get("msg", "Invalid value")),
            }
        )
    return fields


def _validation_error(
    request_id: str,
    fields: list[dict[str, str]],
    *,
    message: str = "The request contains invalid fields.",
    code: str = "validation_failed",
) -> dict[str, Any]:
    error: dict[str, Any] = {
        "code": code,
        "message": message,
        "request_id": request_id,
    }
    if fields:
        error["details"] = {"fields": fields}
    return error


def _validation_response(
    request: Request,
    fields: list[dict[str, str]],
    *,
    status: str,
    include_create_id: bool = False,
    create_id: object = None,
    message: str = "The request contains invalid fields.",
) -> JSONResponse:
    """Preserve public validation context without exposing audit metadata."""
    content: dict[str, Any] = {
        "ok": False,
        "accepted": False,
        "status": status,
        "missing_required_fields": [
            item["path"] for item in fields if item["code"] == VALIDATION_REQUIRED_CODE
        ],
        "validation_errors": fields,
        "error": _validation_error(request.state.request_id, fields, message=message),
    }
    if include_create_id:
        content["create_id"] = create_id
    external_request_id = getattr(request.state, "external_request_id", None)
    if external_request_id is not None:
        content["request_id"] = external_request_id
    return JSONResponse(status_code=422, content=content)


def _external_request_id(payload: object) -> Optional[str]:
    """Return a usable public operation ID from an already parsed body."""
    if not isinstance(payload, dict):
        return None
    value = payload.get("request_id")
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def _remember_external_request_id(request: Request, payload: object) -> None:
    """Make the public operation ID available to common error handlers."""
    request_id = _external_request_id(payload)
    if request_id is not None:
        request.state.external_request_id = request_id


def _accepted_business_response(
    *,
    request_id: str,
    create_id: object,
    application_type: str,
) -> dict[str, Any]:
    """Build the complete public success contract for Create and Update."""
    return {
        "accepted": True,
        "request_id": request_id,
        "create_id": str(create_id),
        "status": HTTP_ACCEPTED_STATUS,
        "application_type": application_type,
    }


def _normalized_create_body(model: Any, application_type: str) -> dict[str, Any]:
    """Mirror each CREATE family's persisted client-owned body shape."""
    if application_type == NEW_LICENCE_APPLICATION_TYPE:
        body = model.model_dump(mode="json", exclude_none=True, exclude_unset=True)
        body["form_data"]["part_1"].setdefault(
            "application_type", model.form_data.part_1.application_type
        )
        return body
    if application_type in CHANGE_MONITORING_APPLICATION_TYPES:
        return model.model_dump(mode="json", exclude_unset=True)
    return model.model_dump(mode="json", exclude_none=True)


def _new_licence_office_code(payload: object) -> Optional[str]:
    """Return a schema-safe office code from an untrusted request body."""
    if not isinstance(payload, dict):
        return None
    form_data = payload.get("form_data")
    if not isinstance(form_data, dict):
        return None
    case_summary = form_data.get("case_summary")
    if not isinstance(case_summary, dict):
        return None
    office_code = case_summary.get("office_code")
    if not isinstance(office_code, str) or office_code not in NEW_LICENCE_OFFICE_CODES:
        return None
    return office_code


def _normalized_home_ref(value: Optional[str]) -> Optional[str]:
    if not isinstance(value, str):
        return None
    text = value.strip().upper()
    return text or None


def _changing_home_rch_reference(payload: object) -> Optional[str]:
    if not isinstance(payload, dict):
        return None
    form_data = payload.get("form_data")
    if not isinstance(form_data, dict):
        return None
    case_summary = form_data.get("case_summary")
    if not isinstance(case_summary, dict):
        return None
    value = case_summary.get("lorche_d_no")
    if not isinstance(value, str) or not value.strip():
        return None
    return value.strip()


def _chi_operators_replacement_requested(form_data: object) -> bool:
    part_3 = getattr(form_data, "part_3", None)
    return part_3 is not None and bool(
        {"operator", "operators"} & part_3.model_fields_set
    )


def _chi_operators_replacement_field(form_data: object) -> str:
    part_3 = getattr(form_data, "part_3", None)
    name = (
        "operator"
        if part_3 is not None and "operator" in part_3.model_fields_set
        else "operators"
    )
    return f"form_data.part_3.{name}"


def _update_queue_service_from_env(
    client: NocoBaseClient,
    settings: Settings,
    application_types: frozenset[str],
) -> QueueAdmissionService | None:
    """Enable only an exact local pilot or an explicitly reviewed release.

    Native Intake ordering is an explicitly accepted narrow business race;
    it is not a verified interlock. The pilot remains restricted to local
    28443/13001. A reviewed release requires a pinned profile digest and
    per-family evidence for every QueueActivationGate.
    """
    if os.getenv("UPDATE_QUEUE_ENABLED") != "1":
        return None
    release_mode = os.getenv("UPDATE_QUEUE_RELEASE_MODE", "").strip()
    if release_mode == "reviewed":
        release = load_reviewed_queue_release(
            profile_path=settings.nocobase.source_path,
            expected_sha256=os.getenv("UPDATE_QUEUE_RELEASE_SHA256", "").strip(),
            deployment_env=os.getenv("DEPLOYMENT_ENV", ""),
            nocobase_base_url=settings.nocobase_base_url,
            source_system=settings.source_system,
            https_bind=os.getenv("KONG_HTTPS_BIND", ""),
            https_port=os.getenv("KONG_HTTPS_PORT", ""),
            enabled_families=application_types,
        )
        return QueueAdmissionService(
            client,
            gates=release.gates,
            admission_workflow_key=release.admission_workflow_key,
            rejection_workflow_key=release.rejection_workflow_key,
        )
    if release_mode:
        raise RuntimeError("UPDATE queue release mode is invalid")
    nla_confirmation = (
        "LOCAL_13001_NLA_FIFO_PILOT_20261016_"
        "c988c590038a73dec9d963140328a327"
    )
    lrn_confirmation = (
        "LOCAL_13001_LRN_FIFO_PILOT_20261017_"
        "b69f4d21a8e75c0d6e4b8f39962a31c5"
    )
    local_13001 = (
        os.getenv("DEPLOYMENT_ENV") == "local_test"
        and os.getenv("KONG_HTTPS_BIND") == "127.0.0.1"
        and os.getenv("KONG_HTTPS_PORT") == "28443"
        and settings.nocobase_base_url
        == "http://119.91.104.211:13001/cmtf2"
        and settings.source_system == "OP"
    )
    nla_selected = (
        application_types == frozenset({NEW_LICENCE_APPLICATION_TYPE})
        and os.getenv("UPDATE_QUEUE_NLA_PILOT_CONFIRM") == nla_confirmation
        and not os.getenv("UPDATE_QUEUE_LRN_PILOT_CONFIRM")
    )
    lrn_selected = (
        application_types == frozenset({LICENCE_RENEWAL_APPLICATION_TYPE})
        and os.getenv("UPDATE_QUEUE_LRN_PILOT_CONFIRM") == lrn_confirmation
        and not os.getenv("UPDATE_QUEUE_NLA_PILOT_CONFIRM")
        and settings.nocobase.licence_renewal_update_enabled is True
    )
    other_confirmation = os.getenv("UPDATE_QUEUE_OTHER_PILOT_CONFIRM", "").strip()
    other_family_name = (
        next(iter(application_types)) if len(application_types) == 1 else None
    )
    other_selected = (
        other_family_name in OTHER_LOCAL_QUEUE_PILOT_CONFIRMATIONS
        and other_confirmation
        == OTHER_LOCAL_QUEUE_PILOT_CONFIRMATIONS[other_family_name]
        and not os.getenv("UPDATE_QUEUE_NLA_PILOT_CONFIRM")
        and not os.getenv("UPDATE_QUEUE_LRN_PILOT_CONFIRM")
    )
    if other_confirmation:
        nla_selected = False
        lrn_selected = False
    if local_13001 and (nla_selected or lrn_selected or other_selected):
        other_pilot = None
        if other_selected:
            assert other_family_name is not None
            create_api, update_api = QUEUE_FAMILY_API_TYPES[other_family_name]
            other_pilot = QueueFamily(
                source_system="OP",
                application_type=other_family_name,
                create_api_type=create_api,
                update_api_type=update_api,
            )
        return QueueAdmissionService(
            client,
            admission_workflow_key="u2w20ale8lj",
            rejection_workflow_key="2jglgnj6mwt",
            pilot_nla_test_mode=nla_selected,
            pilot_lrn_test_mode=lrn_selected,
            pilot_other_family=other_pilot,
        )
    raise RuntimeError(
        "UPDATE queue release is blocked: only exact local 13001 NLA pilot, "
        "LRN pilot, or one fixed other-family pilot is permitted; otherwise "
        "a reviewed release is required"
    )


def create_app(injected_settings: Optional[Settings] = None) -> FastAPI:
    settings = injected_settings or Settings.from_env()
    logging.basicConfig(
        level=getattr(logging, settings.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    @asynccontextmanager
    async def lifespan(application: FastAPI) -> AsyncIterator[None]:
        portable_switch = os.getenv("PORTABLE_RELEASE", "").strip()
        if portable_switch not in {"", "1"}:
            raise RuntimeError("PORTABLE_RELEASE must be empty or 1")
        portable = (
            load_portable_runtime(
                settings=settings,
                kong_path=FilePath(
                    os.getenv("PORTABLE_KONG_CONFIG_PATH", "/app/config/kong.yaml")
                ),
            )
            if portable_switch == "1"
            else None
        )
        client = NocoBaseClient(settings)
        storage_cache = StorageCache(client, settings)
        application.state.settings = settings
        application.state.client = client
        application.state.query_service = QueryService(
            client=client,
            source_system=settings.source_system,
        )
        application.state.storage_cache = storage_cache
        application.state.upload_service = UploadService(
            settings=settings,
            client=client,
            storage_cache=storage_cache,
        )
        application.state.update_submission_locks = {}
        application.state.portable_release = portable is not None
        if portable is not None:
            application.state.update_queue_application_types = (
                portable.update_queue_families
            )
            if portable.update_queue_enabled:
                release = load_reviewed_queue_release(
                    profile_path=settings.nocobase.source_path,
                    expected_sha256=portable.profile_sha256,
                    deployment_env=portable.deployment_env,
                    nocobase_base_url=settings.nocobase_base_url,
                    source_system=portable.source_system,
                    https_bind=portable.https_bind,
                    https_port=portable.https_port,
                    enabled_families=portable.update_queue_families,
                )
                application.state.update_queue_service = QueueAdmissionService(
                    client,
                    gates=release.gates,
                    admission_workflow_key=release.admission_workflow_key,
                    rejection_workflow_key=release.rejection_workflow_key,
                )
            else:
                application.state.update_queue_service = None
        else:
            application.state.update_queue_application_types = (
                parse_enabled_queue_families(
                    os.getenv("UPDATE_QUEUE_APPLICATION_TYPES")
                )
            )
            application.state.update_queue_service = _update_queue_service_from_env(
                client, settings, application.state.update_queue_application_types
            )
        # Activate only after auditing legacy CREATE rows and verifying the
        # forward-only PostgreSQL unique index.  Historical collisions are not
        # backfilled.  The index, not a GET, closes
        # races between concurrent Adapter processes.
        application.state.create_idempotency_service = (
            CreateIdempotencyService(client, settings.source_system)
            if (
                portable.create_idempotency_index_ready
                if portable is not None
                else os.getenv("CREATE_IDEMPOTENCY_INDEX_READY") == "1"
            )
            else None
        )
        await client.start()
        yield
        await client.close()

    application = FastAPI(
        title="NocoBase Gateway Adapter",
        version=ADAPTER_VERSION,
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
    )

    @application.exception_handler(AdapterError)
    async def handle_adapter_error(request: Request, exc: AdapterError) -> JSONResponse:
        request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
        external_request_id = getattr(request.state, "external_request_id", None)
        if exc.status_code == 422:
            fields: list[dict[str, str]] = []
            if exc.details and exc.details.get("field") is not None:
                fields.append(
                    {
                        "path": str(exc.details["field"]),
                        "code": VALIDATION_INVALID_FIELD_CODE,
                        "message": exc.message,
                    }
                )
            content: dict[str, Any] = {
                "ok": False,
                "error": _validation_error(
                    request_id,
                    fields,
                    message=exc.message,
                    code=(
                        exc.code
                        if exc.code in {"missing_document", "invalid_checklist_item"}
                        else "validation_failed"
                    ),
                ),
            }
            if external_request_id is not None:
                content["request_id"] = external_request_id
            return JSONResponse(
                status_code=exc.status_code,
                content=content,
            )
        error = {
            "code": "authentication_failed" if exc.status_code == 401 else exc.code,
            "message": (
                "Authentication failed" if exc.status_code == 401 else exc.message
            ),
            "request_id": request_id,
        }
        # Upstream exception details may contain native collection IDs or raw
        # upstream messages.  Only the public field/status context belongs in
        # the client error envelope.
        if exc.details:
            public_keys = {
                "field": "field",
                "status": "status",
                "position_code": "position_code",
                "maxBytes": "max_bytes",
                "mimeType": "mime_type",
            }
            public_details = {
                public_keys[key]: value
                for key, value in exc.details.items()
                if key in public_keys
            }
            if public_details:
                error["details"] = public_details
        content = {"ok": False, "error": error}
        if external_request_id is not None:
            content["request_id"] = external_request_id
        return JSONResponse(
            status_code=exc.status_code,
            content=content,
        )

    @application.exception_handler(RequestValidationError)
    async def handle_validation_error(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
        external_request_id = _external_request_id(exc.body)
        errors = exc.errors()
        fields = _validation_fields(errors)
        checklist_code = CHECKLIST_OFFICE_CODE_ERRORS.get(request.url.path)
        office_code_error = (
            checklist_code is not None
            and len(errors) == 1
            and tuple(errors[0].get("loc", ())) == ("query", "office_code")
        )
        content: dict[str, Any] = {
            "ok": False,
            "error": _validation_error(
                request_id,
                fields,
                code=checklist_code if office_code_error else "validation_failed",
                message=(
                    "office_code is missing or is not LORCHE or LORCHD"
                    if office_code_error and checklist_code == "invalid_request"
                    else "office_code is not LORCHE or LORCHD"
                    if office_code_error
                    else "The request contains invalid fields."
                ),
            ),
        }
        if external_request_id is not None:
            content["request_id"] = external_request_id
        return JSONResponse(
            status_code=422,
            content=content,
        )

    @application.middleware("http")
    async def request_context(request: Request, call_next):
        request.state.request_id = request.headers.get("X-Request-ID") or str(
            uuid.uuid4()
        )
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    def extract_bearer_token(authorization: Optional[str]) -> str:
        if not authorization:
            raise AdapterError(
                401,
                "client_token_required",
                "Authorization: Bearer <token> is required",
            )
        scheme, separator, token = authorization.strip().partition(" ")
        if not separator or scheme.lower() != "bearer" or not token.strip():
            raise AdapterError(
                401,
                "invalid_client_token",
                "Authorization must use the Bearer scheme",
            )
        return token.strip()

    def authenticated_consumer_id(identity: dict[str, object]) -> str:
        nested_user = identity.get("user")
        candidates = [identity]
        if isinstance(nested_user, dict):
            candidates.insert(0, nested_user)
        for candidate in candidates:
            for key in ("id", "username", "email"):
                value = candidate.get(key)
                if value is not None and str(value).strip():
                    return f"nocobase-user:{value}"
        return "nocobase-user:authenticated"

    def authenticated_user_role(identity: dict[str, object]) -> str:
        nested_user = identity.get("user")
        candidates = [identity]
        if isinstance(nested_user, dict):
            candidates.insert(0, nested_user)

        def role_name(value: object) -> Optional[str]:
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, dict):
                for key in ("name", "title", "roleName", "sn"):
                    nested_value = value.get(key)
                    if nested_value is not None and str(nested_value).strip():
                        return str(nested_value).strip()
            if isinstance(value, list):
                for item in value:
                    resolved = role_name(item)
                    if resolved:
                        return resolved
            return None

        for candidate in candidates:
            for key in ("roleName", "currentRole", "role", "roles"):
                resolved = role_name(candidate.get(key))
                if resolved:
                    return resolved
        return "authenticated"

    async def authenticate_client(
        request: Request,
        authorization: Optional[str],
    ) -> tuple[str, str, dict[str, object]]:
        token = extract_bearer_token(authorization)
        identity = await request.app.state.client.check_access_token(
            token,
            request.state.request_id,
        )
        return token, authenticated_consumer_id(identity), identity

    async def resolve_home_record(
        request: Request,
        *,
        authorization_token: str,
        office_code: str,
        create_id: Optional[object] = None,
        rch_no: Optional[str] = None,
        p_no: Optional[str] = None,
    ) -> dict[str, Any]:
        rch_no = _normalized_home_ref(rch_no)
        p_no = _normalized_home_ref(p_no)
        client = request.app.state.client

        # Public fallback order is deterministic. A missing/invalid reference
        # falls through to the next identifier instead of being combined with it.
        if create_id is not None:
            try:
                source_request = await client.get_record(
                    collection="t_api_request_staging",
                    record_id=create_id,
                    request_id=request.state.request_id,
                    authorization_token=authorization_token,
                )
                source_rch_id = source_request.get("f_rch_id")
                if source_rch_id is not None:
                    home = await client.get_record(
                        collection="t_home_record",
                        record_id=source_rch_id,
                        request_id=request.state.request_id,
                        authorization_token=authorization_token,
                    )
                    if (
                        home.get("id") is not None
                        and home.get("f_office_cd") == office_code
                    ):
                        return home
            except AdapterError as exc:
                if exc.status_code not in {404, 422}:
                    raise

        for field_name, reference in (("f_rch_no", rch_no), ("f_final_o_no", p_no)):
            if not reference:
                continue
            result = await client.list_records(
                collection="t_home_record",
                request_id=request.state.request_id,
                authorization_token=authorization_token,
                filters={
                    "$and": [
                        {field_name: {"$eq": reference}},
                        {"f_office_cd": {"$eq": office_code}},
                    ]
                },
                page=1,
                page_size=2,
                sort=("id",),
            )
            rows = result.get("data") or []
            if (
                len(rows) == 1
                and isinstance(rows[0], dict)
                and rows[0].get("id") is not None
            ):
                return rows[0]

        raise AdapterError(
            422,
            "home_record_not_found",
            "No matching Home Record was found",
            details={
                "field": "form_data.case_summary",
                "office_code": office_code,
                "create_id": create_id,
                "rch_no": rch_no,
                "p_no": p_no,
                "lookup_order": ["create_id", "rch_no", "p_no"],
            },
        )

    async def ensure_no_active_update(
        request: Request,
        *,
        authorization_token: str,
        create_id: object,
    ) -> None:
        """Allow at most one submitted/processing Update per Create request.

        The per-process lock closes the query/create race for the deployed
        single-worker adapter.  The persisted Staging filter remains the
        source of truth across restarts and makes a later Update wait until
        the preceding request has either succeeded or failed.
        """

        result = await request.app.state.client.list_records(
            collection="t_api_request_staging",
            request_id=request.state.request_id,
            authorization_token=authorization_token,
            filters={
                "$and": [
                    {"f_request_event": {"$eq": "UPDATE"}},
                    {"f_parent_create_id": {"$eq": str(create_id)}},
                    {"f_status": {"$in": ["submitted", "processing"]}},
                ]
            },
            page=1,
            page_size=1,
            sort=("id",),
        )
        if result.get("data"):
            raise AdapterError(
                409,
                "update_in_progress",
                "A previous Update for this create_id is still being processed.",
                details={"field": "create_id"},
            )

    def update_submission_lock(request: Request, create_id: object) -> asyncio.Lock:
        locks: dict[str, asyncio.Lock] = request.app.state.update_submission_locks
        return locks.setdefault(str(create_id), asyncio.Lock())

    def queue_service_for(
        request: Request, application_type: str
    ) -> QueueAdmissionService | None:
        # FIFO-only native workers cannot consume legacy direct Staging rows.
        # Fail before acknowledging an UPDATE when that path is required.
        queue_required = (
            request.app.state.portable_release
            or os.getenv("UPDATE_QUEUE_REQUIRED") == "1"
        )
        if queue_required and (
            application_type not in PUBLIC_UPDATE_QUEUE_TYPES
            or application_type
            not in request.app.state.update_queue_application_types
            or request.app.state.update_queue_service is None
        ):
            raise AdapterError(
                503,
                "update_queue_not_ready",
                "This Update route is not enabled for the configured queue",
            )
        if application_type not in request.app.state.update_queue_application_types:
            return None
        return request.app.state.update_queue_service

    async def admit_queued_update(
        request: Request,
        *,
        token: str,
        validated_payload: Any,
        body: dict[str, Any],
        application_type: str,
        create_api_type: str,
        update_api_type: str,
        office_code: object,
        rch_id: object,
        user_role: str,
    ) -> dict[str, Any]:
        service = queue_service_for(request, application_type)
        if service is None:
            raise RuntimeError("Update queue was not enabled")
        await service.admit_update(
            authorization_token=token,
            transport_request_id=request.state.request_id,
            client_request_id=validated_payload.request_id,
            create_id=validated_payload.create_id,
            request_body=body,
            family=QueueFamily(
                source_system=settings.source_system,
                application_type=application_type,
                create_api_type=create_api_type,
                update_api_type=update_api_type,
            ),
            context={
                "f_office_code": str(office_code) if office_code is not None else None,
                "f_rch_id": str(rch_id) if rch_id is not None else None,
                "f_user_role": user_role,
            },
        )
        return _accepted_business_response(
            request_id=validated_payload.request_id,
            create_id=validated_payload.create_id,
            application_type=application_type,
        )

    async def preflight_home_bound_checklist(
        request: Request,
        *,
        authorization_token: str,
        office_code: str,
        checklist: object,
        application_collection: str,
        field_path: str,
    ) -> None:
        """Reject invalid checklist uploads before a runnable Staging row exists.

        The catalog is the same filtered collection exposed by the public
        checklist route. Attachment existence is checked with the caller's
        token, never the root configuration token. Pydantic bounds the number
        of assignments; repeated attachment IDs incur only one upstream read.
        """
        if not checklist:
            return
        catalog = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
            application_collection=application_collection,
        )
        rows = catalog.get("data") if isinstance(catalog, dict) else None
        if not isinstance(rows, list):
            raise AdapterError(
                502,
                "invalid_checklist_catalog",
                "The upstream did not return a checklist catalog",
            )
        valid_codes = {
            row.get("position_code")
            for row in rows
            if isinstance(row, dict) and isinstance(row.get("position_code"), str)
        }
        for index, item in enumerate(checklist):
            if item.position_code not in valid_codes:
                raise AdapterError(
                    422,
                    "invalid_checklist_item",
                    "The position_code is not in the office-specific checklist",
                    details={
                        "field": f"{field_path}.{index}.position_code",
                        "position_code": item.position_code,
                        "office_code": office_code,
                    },
                )
        checked_attachment_ids: set[int] = set()
        for index, item in enumerate(checklist):
            attachment_id = int(item.attachment_id)
            if attachment_id in checked_attachment_ids:
                continue
            checked_attachment_ids.add(attachment_id)
            try:
                attachment = await request.app.state.client.get_record(
                    collection="attachments",
                    record_id=attachment_id,
                    request_id=request.state.request_id,
                    authorization_token=authorization_token,
                )
            except AdapterError as exc:
                if exc.status_code not in {401, 403, 404, 422}:
                    raise
                attachment = {}
            if str(attachment.get("id")) != str(attachment_id):
                raise AdapterError(
                    422,
                    "missing_document",
                    "The uploaded attachment was not found or is not accessible",
                    details={
                        "field": f"{field_path}.{index}.attachment_id",
                        "attachment_id": attachment_id,
                    },
                )

    async def preflight_attachment_references(
        request: Request,
        *,
        authorization_token: str,
        references: list[tuple[str, int]],
    ) -> None:
        """Verify every public attachment ID with the caller's identity."""

        checked: set[int] = set()
        for field_path, attachment_id in references:
            if attachment_id in checked:
                continue
            checked.add(attachment_id)
            try:
                attachment = await request.app.state.client.get_record(
                    collection="attachments",
                    record_id=attachment_id,
                    request_id=request.state.request_id,
                    authorization_token=authorization_token,
                )
            except AdapterError as exc:
                if exc.status_code not in {401, 403, 404, 422}:
                    raise
                attachment = {}
            if str(attachment.get("id")) != str(attachment_id):
                raise AdapterError(
                    422,
                    "missing_document",
                    "The uploaded attachment was not found or is not accessible",
                    details={
                        "field": field_path,
                        "attachment_id": attachment_id,
                    },
                )

    async def preflight_change_monitoring_payload(
        request: Request,
        *,
        authorization_token: str,
        application_type: str,
        model: Any,
        home_record: dict[str, Any],
        office_code: str,
    ) -> None:
        """Validate Change Monitoring relations before creating runnable Staging."""

        form = model.form_data
        references: list[tuple[str, int]] = []
        attachment_ids = getattr(form, "attachment_ids", None)
        if attachment_ids is not None:
            references.extend(
                (f"form_data.attachment_ids.{index}", int(attachment_id))
                for index, attachment_id in enumerate(attachment_ids)
            )
        documents = getattr(form, "documents", None)
        if documents is not None:
            for document_index, document in enumerate(documents):
                references.extend(
                    (
                        "form_data.documents."
                        f"{document_index}.attachment_ids.{attachment_index}",
                        int(attachment_id),
                    )
                    for attachment_index, attachment_id in enumerate(
                        document.attachment_ids
                    )
                )
        await preflight_attachment_references(
            request,
            authorization_token=authorization_token,
            references=references,
        )

        if application_type == CHANGE_OPERATION_MODE_APPLICATION_TYPE:
            proposed_code = getattr(form, "proposed_rch_nature_code", None)
            if proposed_code is not None:
                result = await request.app.state.client.list_configuration_records(
                    collection="f_rch_nature",
                    request_id=request.state.request_id,
                    filters={
                        "$and": [
                            {"f_code": {"$eq": proposed_code}},
                            {"f_enabled": {"$eq": True}},
                        ]
                    },
                    page=1,
                    page_size=2,
                )
                rows = result.get("data") if isinstance(result, dict) else None
                candidates = [
                    row
                    for row in rows or []
                    if isinstance(row, dict)
                    and office_code in (row.get("f_for_office") or [])
                ]
                if len(candidates) != 1:
                    raise AdapterError(
                        422,
                        "invalid_field",
                        "The proposed Home Type is not enabled for office_code",
                        details={
                            "field": "form_data.proposed_rch_nature_code",
                            "office_code": office_code,
                        },
                    )
                current_code = home_record.get("fk_rch_nature")
                if current_code is None:
                    loaded_home = await request.app.state.client.get_record(
                        collection="t_home_record",
                        record_id=home_record["id"],
                        request_id=request.state.request_id,
                        authorization_token=authorization_token,
                    )
                    current_code = loaded_home.get("fk_rch_nature")
                if str(current_code or "") == proposed_code:
                    raise AdapterError(
                        422,
                        "invalid_field",
                        "The proposed Home Type must differ from the current value",
                        details={
                            "field": "form_data.proposed_rch_nature_code",
                            "current_value": current_code,
                        },
                    )

    def home_bound_checklist(model: Any, application_type: str) -> tuple[object, str]:
        """Return the checklist payload and its public validation path."""
        if application_type == EXPANSION_AIP_APPLICATION_TYPE:
            part_3 = model.form_data.part_3
            return (
                part_3.checklist if part_3 is not None else None,
                "form_data.part_3.checklist",
            )
        if application_type in {
            CHANGING_HOME_APPLICATION_TYPE,
            LICENCE_RENEWAL_APPLICATION_TYPE,
        }:
            part_5 = model.form_data.part_5
            return (
                part_5.checklist if part_5 is not None else None,
                "form_data.part_5.checklist",
            )
        return getattr(model.form_data, "checklist", None), "form_data.checklist"

    async def raise_audited_preflight_error(
        request: Request,
        *,
        error: AdapterError,
        authorization_token: str,
        request_body: dict[str, Any],
        request_event: str,
        api_type: str,
        user_role: str,
        application_type: str,
        office_code: object,
        rch_id: object,
        parent_create_id: object | None = None,
    ) -> None:
        if error.status_code != 422:
            raise error
        values: dict[str, Any] = {
            "f_request_body": request_body,
            "f_source_system": settings.source_system,
            "f_request_event": request_event,
            "f_api_type": api_type,
            "f_user_role": user_role,
            "f_status": "invalid_request",
            "f_application_type": application_type,
            "f_office_code": office_code,
            "f_application_status": None,
            "f_rch_id": str(rch_id) if rch_id is not None else None,
            "f_error_message": error.code,
        }
        if parent_create_id is not None:
            values["f_parent_create_id"] = str(parent_create_id)
        staging = await request.app.state.client.create_request_staging(
            request_id=request.state.request_id,
            authorization_token=authorization_token,
            values=values,
        )
        details = dict(error.details or {})
        if isinstance(staging, dict) and staging.get("id") is not None:
            details["staging_record_id"] = str(staging["id"])
        raise AdapterError(
            error.status_code,
            error.code,
            error.message,
            details=details,
        )

    async def validate_specific_hour_staffing(
        request: Request,
        *,
        home_record: dict[str, Any],
        office_code: str,
        authorization_token: str,
        options: object,
    ) -> dict[str, dict[str, Any]]:
        """Validate SH staffing against the active server-side rule catalogue."""
        if options is None:
            return {}
        home_type_id = home_record.get("fk_type_of_rch")
        if home_type_id is None:
            loaded_home = await request.app.state.client.get_record(
                collection="t_home_record",
                record_id=home_record["id"],
                request_id=request.state.request_id,
                authorization_token=authorization_token,
            )
            home_type_id = loaded_home.get("fk_type_of_rch")
        if home_type_id is None:
            raise AdapterError(
                422,
                "home_type_not_configured",
                "The matched Home Record has no RCH type for Specific Hour rules",
                details={"field": "form_data.case_summary"},
            )

        result = await request.app.state.client.list_configuration_records(
            collection="t_specific_hour_staff_rule",
            request_id=request.state.request_id,
            filters={
                "$and": [
                    {"f_office_cd": {"$eq": office_code}},
                    {"fk_rch_care_level": {"$eq": home_type_id}},
                    {"f_is_active": {"$eq": True}},
                ]
            },
            appends=("f_staff_types_id",),
            page=1,
            page_size=100,
            sort=("f_sort_order", "id"),
        )
        rules = result.get("data") if isinstance(result, dict) else None
        if not isinstance(rules, list) or not rules:
            raise AdapterError(
                422,
                "staffing_rules_not_configured",
                "No active Specific Hour staffing rules match the Home Record",
                details={"field": "form_data.specific_hour_options"},
            )

        normalized_rules: list[tuple[set[str], float, dict[str, Any]]] = []
        for rule in rules:
            if not isinstance(rule, dict):
                continue
            related = rule.get("f_staff_types_id")
            related_rows = related if isinstance(related, list) else [related]
            allowed_codes = {
                str(row.get("f_staff_code")).strip().upper()
                for row in related_rows
                if isinstance(row, dict) and row.get("f_staff_code")
            }
            if not allowed_codes:
                continue
            try:
                minimum_hours = float(rule.get("f_minimum_required_hours") or 0)
            except (TypeError, ValueError):
                minimum_hours = 0
            normalized_rules.append(
                (
                    allowed_codes,
                    minimum_hours,
                    {
                        "rule_id": rule.get("id"),
                        "staff_ratio_requirement": rule.get(
                            "f_staff_ratio_requirement"
                        ),
                        "minimum_required_hours": rule.get("f_minimum_required_hours"),
                        "sort_order": rule.get("f_sort_order"),
                    },
                )
            )
        if not normalized_rules:
            raise AdapterError(
                422,
                "staffing_rules_invalid",
                "The matching Specific Hour staffing rules have no staff types",
                details={"field": "form_data.specific_hour_options"},
            )

        snapshots: dict[str, dict[str, Any]] = {}
        for option_index, option in enumerate(options):
            staffing_by_code = {
                staffing.staff_type_code.strip().upper(): staffing
                for staffing in option.staffings
            }
            matched_codes: set[str] = set()
            for allowed_codes, minimum_hours, snapshot in normalized_rules:
                selected = allowed_codes.intersection(staffing_by_code)
                if len(selected) != 1:
                    raise AdapterError(
                        422,
                        "invalid_staffing_selection",
                        "Each Specific Hour staffing rule requires exactly one "
                        "allowed staff type",
                        details={
                            "field": (
                                "form_data.specific_hour_options."
                                f"{option_index}.staffings"
                            ),
                            "allowed_staff_type_codes": sorted(allowed_codes),
                        },
                    )
                code = next(iter(selected))
                if code in matched_codes:
                    raise AdapterError(
                        422,
                        "ambiguous_staffing_rule",
                        "A staff type matched more than one staffing rule",
                        details={
                            "field": (
                                "form_data.specific_hour_options."
                                f"{option_index}.staffings"
                            ),
                            "staff_type_code": code,
                        },
                    )
                matched_codes.add(code)
                snapshots[code] = snapshot
                total_minutes = 0
                for time_row in staffing_by_code[code].time_rows:
                    start = (
                        time_row.work_hour_from.hour * 60
                        + time_row.work_hour_from.minute
                    )
                    end = time_row.work_hour_to.hour * 60 + time_row.work_hour_to.minute
                    if end <= start:
                        end += 24 * 60
                    total_minutes += end - start
                if total_minutes / 60 < minimum_hours:
                    raise AdapterError(
                        422,
                        "minimum_staffing_hours_not_met",
                        "The submitted working hours are below the configured minimum",
                        details={
                            "field": (
                                "form_data.specific_hour_options."
                                f"{option_index}.staffings"
                            ),
                            "staff_type_code": code,
                            "minimum_required_hours": minimum_hours,
                        },
                    )
            unexpected = set(staffing_by_code).difference(matched_codes)
            if unexpected:
                raise AdapterError(
                    422,
                    "invalid_staff_type",
                    "A submitted staff type is not allowed by the active rules",
                    details={
                        "field": (
                            f"form_data.specific_hour_options.{option_index}.staffings"
                        ),
                        "staff_type_codes": sorted(unexpected),
                    },
                )
        return snapshots

    def enrich_specific_hour_staging_body(
        body: dict[str, Any], snapshots: dict[str, dict[str, Any]]
    ) -> None:
        """Attach server-derived rule snapshots to the internal Staging JSON."""
        form_data = body.get("form_data")
        if not isinstance(form_data, dict):
            return
        options = form_data.get("specific_hour_options")
        if not isinstance(options, list):
            return
        for option in options:
            if not isinstance(option, dict):
                continue
            staffings = option.get("staffings")
            if not isinstance(staffings, list):
                continue
            for staffing in staffings:
                if not isinstance(staffing, dict):
                    continue
                code = str(staffing.get("staff_type_code") or "").upper()
                snapshot = snapshots.get(code)
                if snapshot is not None:
                    staffing["_rule_snapshot"] = snapshot
                time_rows = staffing.get("time_rows")
                if not isinstance(time_rows, list):
                    continue
                for index, time_row in enumerate(time_rows, start=1):
                    if not isinstance(time_row, dict):
                        continue
                    start_value = str(time_row.get("work_hour_from") or "")
                    end_value = str(time_row.get("work_hour_to") or "")
                    try:
                        start_hour, start_minute = (
                            int(value) for value in start_value.split(":")[:2]
                        )
                        end_hour, end_minute = (
                            int(value) for value in end_value.split(":")[:2]
                        )
                    except (TypeError, ValueError):
                        continue
                    start_minutes = start_hour * 60 + start_minute
                    end_minutes = end_hour * 60 + end_minute
                    if end_minutes <= start_minutes:
                        end_minutes += 24 * 60
                    time_row["_duration_hours"] = round(
                        (end_minutes - start_minutes) / 60, 4
                    )
                    time_row["_sort_order"] = index

    async def replay_existing_create(
        request: Request,
        *,
        token: str,
        payload: dict[str, Any],
        model_cls: type,
        application_type: str,
        api_type: str,
    ) -> dict[str, Any] | None:
        service: CreateIdempotencyService | None = (
            request.app.state.create_idempotency_service
        )
        request_id = payload.get("request_id")
        if service is None or not isinstance(request_id, str) or not request_id:
            return None
        existing = await service.find(
            token=token,
            transport_request_id=request.state.request_id,
            client_request_id=request_id,
        )
        if existing is None:
            return None
        try:
            model = model_cls.model_validate(payload)
        except PydanticValidationError as exc:
            raise AdapterError(
                409,
                "duplicate_request_id",
                "request_id was already used with a different Create payload",
            ) from exc
        record_id = service.replay_id(
            existing,
            client_request_id=request_id,
            create_api_type=api_type,
            application_type=application_type,
            client_body=_normalized_create_body(model, application_type),
        )
        return _accepted_business_response(
            request_id=request_id,
            create_id=record_id,
            application_type=application_type,
        )

    async def create_accepted_staging(
        request: Request,
        *,
        token: str,
        staging_values: dict[str, Any],
        client_body: dict[str, Any],
        client_request_id: str,
        application_type: str,
        api_type: str,
    ) -> dict[str, Any]:
        service: CreateIdempotencyService | None = (
            request.app.state.create_idempotency_service
        )
        if service is None:
            return await request.app.state.client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values=staging_values,
            )
        return await service.create_or_replay(
            token=token,
            transport_request_id=request.state.request_id,
            client_request_id=client_request_id,
            create_api_type=api_type,
            application_type=application_type,
            client_body=client_body,
            staging_values=staging_values,
        )

    async def stage_home_bound_create(
        request: Request,
        payload: dict[str, Any],
        *,
        token: str,
        consumer_id: str,
        user_role: str,
        model_cls: type,
        application_type: str,
        api_type: str,
        initial_status: str,
        log_label: str,
    ) -> Any:
        _remember_external_request_id(request, payload)
        nocobase_client = request.app.state.client
        replay = await replay_existing_create(
            request,
            token=token,
            payload=payload,
            model_cls=model_cls,
            application_type=application_type,
            api_type=api_type,
        )
        if replay is not None:
            return replay
        try:
            validated_payload = model_cls.model_validate(payload)
        except PydanticValidationError as exc:
            validation_errors = _validation_fields(exc.errors())
            missing_required_fields = [
                item["path"]
                for item in validation_errors
                if item["code"] == VALIDATION_REQUIRED_CODE
            ]
            status = (
                "missing_required" if missing_required_fields else "invalid_request"
            )
            await nocobase_client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values={
                    "f_request_body": payload,
                    "f_source_system": settings.source_system,
                    "f_request_event": "CREATE",
                    "f_api_type": api_type,
                    "f_user_role": user_role,
                    "f_status": status,
                    "f_application_type": application_type,
                    "f_office_code": _new_licence_office_code(payload),
                    "f_application_status": None,
                    "f_rch_id": None,
                },
            )
            return _validation_response(request, validation_errors, status=status)

        # The active CHI projection selects a natural person by native child
        # ID. Both the singular public operator and the complete-list form
        # need the guarded same-key Create/Update revisions before admission.
        if (
            application_type == CHANGING_HOME_APPLICATION_TYPE
            and _chi_operators_replacement_requested(validated_payload.form_data)
            and not settings.nocobase.changing_home_operator_replacement_enabled
        ):
            raise AdapterError(
                503,
                "operator_replacement_temporarily_unavailable",
                "CHI operators replacement is temporarily unavailable.",
                details={
                    "field": _chi_operators_replacement_field(
                        validated_payload.form_data
                    )
                },
            )

        case_summary = validated_payload.form_data.case_summary
        rch_no_only = application_type in {
            CHANGING_HOME_APPLICATION_TYPE,
            LICENCE_RENEWAL_APPLICATION_TYPE,
        }
        try:
            home_record = await resolve_home_record(
                request,
                authorization_token=token,
                office_code=case_summary.office_code,
                create_id=(
                    None
                    if rch_no_only
                    else getattr(validated_payload, "create_id", None)
                ),
                rch_no=(
                    case_summary.rch_no
                    if rch_no_only
                    else case_summary.rch_no or case_summary.lorche_d_no
                ),
                p_no=None if rch_no_only else case_summary.p_no,
            )
        except AdapterError as exc:
            if exc.status_code != 422:
                raise
            validation_fields: list[dict[str, str]] = []
            if exc.details and exc.details.get("field") is not None:
                validation_fields.append(
                    {
                        "path": str(exc.details["field"]),
                        "code": VALIDATION_INVALID_FIELD_CODE,
                        "message": exc.message,
                    }
                )
            await nocobase_client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values={
                    "f_request_body": validated_payload.model_dump(mode="json"),
                    "f_source_system": settings.source_system,
                    "f_request_event": "CREATE",
                    "f_api_type": api_type,
                    "f_user_role": user_role,
                    "f_status": "invalid_request",
                    "f_application_type": application_type,
                    "f_office_code": case_summary.office_code,
                    "f_application_status": None,
                    "f_rch_id": None,
                },
            )
            return _validation_response(
                request,
                validation_fields,
                status="invalid_request",
                message=exc.message,
            )

        staffing_rule_snapshots: dict[str, dict[str, Any]] = {}
        try:
            if application_type == SPECIFIC_HOUR_APPLICATION_TYPE:
                staffing_rule_snapshots = await validate_specific_hour_staffing(
                    request,
                    home_record=home_record,
                    office_code=case_summary.office_code,
                    authorization_token=token,
                    options=validated_payload.form_data.specific_hour_options,
                )

            if application_type in CHANGE_MONITORING_APPLICATION_TYPES:
                await preflight_change_monitoring_payload(
                    request,
                    authorization_token=token,
                    application_type=application_type,
                    model=validated_payload,
                    home_record=home_record,
                    office_code=case_summary.office_code,
                )

            checklist_collection = CHECKLIST_APPLICATION_COLLECTIONS.get(
                application_type
            )
            if checklist_collection is not None:
                checklist, field_path = home_bound_checklist(
                    validated_payload, application_type
                )
                await preflight_home_bound_checklist(
                    request,
                    authorization_token=token,
                    office_code=case_summary.office_code,
                    checklist=checklist,
                    application_collection=checklist_collection,
                    field_path=field_path,
                )
        except AdapterError as exc:
            await raise_audited_preflight_error(
                request,
                error=exc,
                authorization_token=token,
                request_body=validated_payload.model_dump(
                    mode="json", exclude_none=True
                ),
                request_event="CREATE",
                api_type=api_type,
                user_role=user_role,
                application_type=application_type,
                office_code=case_summary.office_code,
                rch_id=home_record.get("id"),
            )

        # Change Monitoring is layered on top of native synchronous Intake and
        # application initialisers.  Preserve the distinction between an
        # omitted field and an explicit empty replacement so native defaults
        # are not erased by model defaults such as ``attachment_ids=[]``.
        if application_type in CHANGE_MONITORING_APPLICATION_TYPES:
            staging_body = validated_payload.model_dump(mode="json", exclude_unset=True)
        else:
            staging_body = validated_payload.model_dump(mode="json", exclude_none=True)
        if application_type == SPECIFIC_HOUR_APPLICATION_TYPE:
            enrich_specific_hour_staging_body(staging_body, staffing_rule_snapshots)
        staging_record = await create_accepted_staging(
            request,
            token=token,
            client_body=staging_body,
            client_request_id=validated_payload.request_id,
            application_type=application_type,
            api_type=api_type,
            staging_values={
                "f_request_body": staging_body,
                "f_source_system": settings.source_system,
                "f_request_event": "CREATE",
                "f_api_type": api_type,
                "f_user_role": user_role,
                "f_status": STAGING_SUBMITTED_STATUS,
                "f_application_type": application_type,
                "f_office_code": case_summary.office_code,
                "f_application_status": initial_status,
                "f_rch_id": str(home_record["id"]),
            },
        )
        logging.getLogger(__name__).info(
            "%s request submitted request_id=%s external_request_id=%s "
            "consumer_id=%s staging_record_id=%s rch_id=%s",
            log_label,
            request.state.request_id,
            validated_payload.request_id,
            consumer_id,
            staging_record["id"],
            home_record["id"],
        )
        return _accepted_business_response(
            request_id=validated_payload.request_id,
            create_id=staging_record["id"],
            application_type=application_type,
        )

    async def stage_home_bound_update(
        request: Request,
        payload: dict[str, Any],
        *,
        token: str,
        consumer_id: str,
        user_role: str,
        model_cls: type,
        application_type: str,
        create_api_type: str,
        update_api_type: str,
        initial_status: str,
        log_label: str,
        allow_cmtf_create: bool = False,
    ) -> Any:
        _remember_external_request_id(request, payload)
        nocobase_client = request.app.state.client
        try:
            validated_payload = model_cls.model_validate(payload)
        except PydanticValidationError as exc:
            validation_errors = _validation_fields(exc.errors())
            missing_required_fields = [
                item["path"]
                for item in validation_errors
                if item["code"] == VALIDATION_REQUIRED_CODE
            ]
            status = (
                "missing_required" if missing_required_fields else "invalid_request"
            )
            await nocobase_client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values={
                    "f_request_body": payload,
                    "f_source_system": settings.source_system,
                    "f_request_event": "UPDATE",
                    "f_api_type": update_api_type,
                    "f_user_role": user_role,
                    "f_status": status,
                    "f_application_type": application_type,
                    "f_office_code": _new_licence_office_code(payload),
                    "f_application_status": None,
                    "f_rch_id": None,
                },
            )
            return _validation_response(
                request,
                validation_errors,
                status=status,
                include_create_id=True,
                create_id=payload.get("create_id"),
            )

        try:
            original_request = await nocobase_client.get_record(
                collection="t_api_request_staging",
                record_id=validated_payload.create_id,
                request_id=request.state.request_id,
                authorization_token=token,
            )
        except AdapterError as exc:
            if exc.status_code == 404:
                raise AdapterError(
                    404,
                    "request_not_found",
                    "The create request was not found",
                    details={"field": "create_id"},
                ) from exc
            raise
        original_source = str(original_request.get("f_source_system") or "").upper()
        source_matches = original_source == settings.source_system or (
            allow_cmtf_create and original_source == CMTF_SOURCE_SYSTEM
        )
        if (
            not source_matches
            or original_request.get("f_request_event") != "CREATE"
            or original_request.get("f_api_type") != create_api_type
            or original_request.get("f_application_type") != application_type
        ):
            raise AdapterError(
                404,
                "request_not_found",
                "The create request was not found",
                details={"field": "create_id"},
            )
        queue_service = queue_service_for(request, application_type)
        if queue_service is not None and original_source != settings.source_system:
            # A CMTF-origin CREATE needs a separately verified cross-source
            # admission binding.  Never bypass the queue with legacy UPDATE
            # once the queue route has been enabled.
            raise AdapterError(
                503,
                "update_queue_not_ready",
                "Cross-source Update queue binding is not available",
            )
        application_status = original_request.get("f_application_status")
        if application_status != initial_status:
            if queue_service is not None:
                return await admit_queued_update(
                    request,
                    token=token,
                    validated_payload=validated_payload,
                    body=validated_payload.model_dump(mode="json", exclude_unset=True),
                    application_type=application_type,
                    create_api_type=create_api_type,
                    update_api_type=update_api_type,
                    office_code=original_request.get("f_office_code"),
                    rch_id=original_request.get("f_rch_id"),
                    user_role=user_role,
                )
            raise AdapterError(
                409,
                "update_locked",
                "Update is allowed only while status is Accepted.",
                details={"field": "create_id", "status": application_status},
            )
        if (
            queue_service is None
            and application_type in CREATE_READY_REQUIRED_UPDATE_APPLICATION_TYPES
        ):
            _ensure_parent_create_ready(
                original_request,
                require_intake_id=(
                    application_type != LICENCE_RENEWAL_APPLICATION_TYPE
                ),
            )
        if (
            application_type == CHANGING_HOME_APPLICATION_TYPE
            and _chi_operators_replacement_requested(validated_payload.form_data)
            and not settings.nocobase.changing_home_operator_replacement_enabled
        ):
            raise AdapterError(
                503,
                "operator_replacement_temporarily_unavailable",
                "CHI operators replacement is temporarily unavailable.",
                details={
                    "field": _chi_operators_replacement_field(
                        validated_payload.form_data
                    )
                },
            )

        update_summary = validated_payload.form_data.case_summary
        rch_id = original_request.get("f_rch_id")
        office_code = original_request.get("f_office_code")
        original_body = original_request.get("f_request_body")
        original_form = (
            original_body.get("form_data") if isinstance(original_body, dict) else None
        )
        original_summary = (
            original_form.get("case_summary")
            if isinstance(original_form, dict)
            else None
        )
        original_summary = (
            original_summary if isinstance(original_summary, dict) else {}
        )
        original_office_code = office_code or original_summary.get("office_code")
        office_code = original_office_code
        if application_type == CHANGING_HOME_APPLICATION_TYPE:
            updated_part_2 = validated_payload.form_data.part_2
            proposed_rch_type = (
                updated_part_2.rch_type_code if updated_part_2 is not None else None
            )
            valid_rch_types = (
                {"a1", "a2", "a3", "a4"}
                if original_office_code == "LORCHE"
                else {"b1", "b2", "b3"}
            )
            if (
                proposed_rch_type is not None
                and proposed_rch_type not in valid_rch_types
            ):
                raise AdapterError(
                    422,
                    "invalid_field",
                    "The RCH Type is not valid for the original office_code",
                    details={"field": "form_data.part_2.rch_type_code"},
                )
        if (
            update_summary is not None
            and update_summary.office_code is not None
            and update_summary.office_code != original_office_code
        ):
            raise AdapterError(
                422,
                "invalid_field",
                "The office_code must match the original Create request",
                details={"field": "form_data.case_summary.office_code"},
            )
        if update_summary is not None and (
            update_summary.rch_no is not None
            or update_summary.lorche_d_no is not None
            or update_summary.p_no is not None
        ):
            lookup_office_code = update_summary.office_code or original_office_code
            if lookup_office_code is None:
                raise AdapterError(
                    422,
                    "home_record_not_resolved",
                    "The original create request has no office_code",
                    details={"field": "create_id"},
                )
            home_record = await resolve_home_record(
                request,
                authorization_token=token,
                office_code=lookup_office_code,
                rch_no=update_summary.rch_no or update_summary.lorche_d_no,
                p_no=update_summary.p_no,
            )
            if str(home_record["id"]) != str(original_request.get("f_rch_id")):
                raise AdapterError(
                    422,
                    "home_record_mismatch",
                    "The Home Record must match the original Create request",
                    details={"field": "form_data.case_summary"},
                )
            rch_id = home_record["id"]
            office_code = lookup_office_code
        if rch_id is None:
            raise AdapterError(
                422,
                "home_record_not_resolved",
                "The original create request has no resolved Home Record",
                details={"field": "create_id"},
            )

        staffing_rule_snapshots: dict[str, dict[str, Any]] = {}
        try:
            if (
                application_type == SPECIFIC_HOUR_APPLICATION_TYPE
                and validated_payload.form_data.specific_hour_options is not None
            ):
                current_home = await nocobase_client.get_record(
                    collection="t_home_record",
                    record_id=rch_id,
                    request_id=request.state.request_id,
                    authorization_token=token,
                )
                staffing_rule_snapshots = await validate_specific_hour_staffing(
                    request,
                    home_record=current_home,
                    office_code=office_code,
                    authorization_token=token,
                    options=validated_payload.form_data.specific_hour_options,
                )

            if application_type in CHANGE_MONITORING_APPLICATION_TYPES:
                current_home = await nocobase_client.get_record(
                    collection="t_home_record",
                    record_id=rch_id,
                    request_id=request.state.request_id,
                    authorization_token=token,
                )
                await preflight_change_monitoring_payload(
                    request,
                    authorization_token=token,
                    application_type=application_type,
                    model=validated_payload,
                    home_record=current_home,
                    office_code=str(office_code),
                )

            checklist_collection = CHECKLIST_APPLICATION_COLLECTIONS.get(
                application_type
            )
            if checklist_collection is not None:
                checklist, field_path = home_bound_checklist(
                    validated_payload, application_type
                )
                await preflight_home_bound_checklist(
                    request,
                    authorization_token=token,
                    office_code=office_code,
                    checklist=checklist,
                    application_collection=checklist_collection,
                    field_path=field_path,
                )
        except AdapterError as exc:
            await raise_audited_preflight_error(
                request,
                error=exc,
                authorization_token=token,
                request_body=validated_payload.model_dump(
                    mode="json", exclude_unset=True
                ),
                request_event="UPDATE",
                api_type=update_api_type,
                user_role=user_role,
                application_type=application_type,
                office_code=office_code,
                rch_id=rch_id,
                parent_create_id=validated_payload.create_id,
            )

        staging_body = validated_payload.model_dump(mode="json", exclude_unset=True)
        if application_type == SPECIFIC_HOUR_APPLICATION_TYPE:
            enrich_specific_hour_staging_body(staging_body, staffing_rule_snapshots)
        if queue_service is not None:
            return await admit_queued_update(
                request,
                token=token,
                validated_payload=validated_payload,
                body=staging_body,
                application_type=application_type,
                create_api_type=create_api_type,
                update_api_type=update_api_type,
                office_code=office_code,
                rch_id=rch_id,
                user_role=user_role,
            )
        async with update_submission_lock(request, validated_payload.create_id):
            await ensure_no_active_update(
                request,
                authorization_token=token,
                create_id=validated_payload.create_id,
            )
            reservation_token: str | None = None
            if application_type in READY_PARENT_REQUIRED_UPDATE_APPLICATION_TYPES:
                reservation_token = str(uuid.uuid4())
                await nocobase_client.update_record_if(
                    collection="t_api_request_staging",
                    record_id=validated_payload.create_id,
                    expected={
                        "f_application_status": initial_status,
                        "f_active_update_id": None,
                    },
                    request_id=request.state.request_id,
                    authorization_token=token,
                    values={"f_active_update_id": reservation_token},
                )
                reserved_parent = await nocobase_client.get_record(
                    collection="t_api_request_staging",
                    record_id=validated_payload.create_id,
                    request_id=request.state.request_id,
                    authorization_token=token,
                )
                if reserved_parent.get("f_active_update_id") != reservation_token:
                    reserved_status = reserved_parent.get("f_application_status")
                    if reserved_status == initial_status and reserved_parent.get(
                        "f_active_update_id"
                    ):
                        raise AdapterError(
                            409,
                            "update_in_progress",
                            "A previous Update for this create_id is still being "
                            "processed.",
                            details={"field": "create_id"},
                        )
                    raise AdapterError(
                        409,
                        "update_locked",
                        "Update is allowed only while status is Accepted.",
                        details={
                            "field": "create_id",
                            "status": reserved_status,
                        },
                    )
            try:
                staging_record = await nocobase_client.create_request_staging(
                    request_id=request.state.request_id,
                    authorization_token=token,
                    values={
                        "f_request_body": staging_body,
                        "f_source_system": settings.source_system,
                        "f_request_event": "UPDATE",
                        "f_api_type": update_api_type,
                        "f_user_role": user_role,
                        "f_status": STAGING_SUBMITTED_STATUS,
                        "f_application_type": application_type,
                        "f_office_code": office_code,
                        "f_application_status": None,
                        "f_rch_id": str(rch_id),
                        "f_parent_create_id": str(validated_payload.create_id),
                        "f_active_update_id": reservation_token,
                    },
                )
            except Exception:
                if reservation_token is not None:
                    await nocobase_client.update_record_if(
                        collection="t_api_request_staging",
                        record_id=validated_payload.create_id,
                        expected={"f_active_update_id": reservation_token},
                        request_id=request.state.request_id,
                        authorization_token=token,
                        values={"f_active_update_id": None},
                    )
                raise
        logging.getLogger(__name__).info(
            "%s update submitted request_id=%s external_request_id=%s "
            "create_id=%s consumer_id=%s update_id=%s",
            log_label,
            request.state.request_id,
            validated_payload.request_id,
            validated_payload.create_id,
            consumer_id,
            staging_record["id"],
        )
        return _accepted_business_response(
            request_id=validated_payload.request_id,
            create_id=validated_payload.create_id,
            application_type=application_type,
        )

    @application.post("/v1/auth/token")
    async def get_native_token(request: Request) -> dict[str, Any]:
        media_type = request.headers.get("content-type", "").split(";", 1)[0]
        if media_type.strip().lower() != "application/json":
            raise AdapterError(
                400,
                "invalid_request",
                "A JSON object with account and password is required",
            )
        try:
            payload = await request.json()
        except ValueError as exc:
            raise AdapterError(
                400,
                "invalid_request",
                "A JSON object with account and password is required",
            ) from exc
        if not isinstance(payload, dict) or any(
            not isinstance(payload.get(field), str) or not payload[field].strip()
            for field in ("account", "password")
        ):
            raise AdapterError(
                400,
                "invalid_request",
                "A JSON object with account and password is required",
            )
        result = await request.app.state.client.sign_in(
            account=payload["account"],
            password=payload["password"],
            request_id=request.state.request_id,
        )
        data = result.get("data") if isinstance(result, dict) else None
        token = data.get("token") if isinstance(data, dict) else None
        if not isinstance(token, str) or not token.strip():
            raise AdapterError(
                502,
                "upstream_error",
                "The authentication upstream returned an invalid response",
            )
        return {"data": {"token": token}}

    @application.get("/health/live")
    async def live() -> dict[str, str]:
        return {"status": "ok"}

    @application.get("/health/ready")
    async def ready(request: Request) -> dict[str, str]:
        if not await request.app.state.client.check_readiness():
            raise AdapterError(
                503,
                "service_not_ready",
                "A required dependency is unavailable",
            )
        return {"status": "ready"}

    @application.get("/v1/requests/{record_id}")
    async def get_request_status(
        request: Request,
        record_id: Annotated[
            str,
            Path(pattern=r"^[A-Za-z0-9_-]{1,128}$"),
        ],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.get_request(
            record_id=record_id,
            request_id=request.state.request_id,
            authorization_token=token,
        )
        logging.getLogger(__name__).info(
            "Request status queried request_id=%s consumer_id=%s record_id=%s",
            request.state.request_id,
            consumer_id,
            record_id,
        )
        return result

    @application.get("/v1/request/{create_id}")
    async def get_new_licence_request(
        request: Request,
        create_id: Annotated[
            str,
            Path(pattern=r"^[A-Za-z0-9_-]{1,128}$"),
        ],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        try:
            result = await request.app.state.query_service.get_new_licence_request(
                create_id=create_id,
                request_id=request.state.request_id,
                authorization_token=token,
            )
            # Letter files are exposed only through the Notice List. Notice rows
            # remain visible even when the related letter has no attachment.
            result.pop("letter_attachments", None)
            application_type = result.get("application_type") or {}
            result["notices"] = await request.app.state.query_service.list_notices(
                create_id=create_id,
                request_id=request.state.request_id,
                authorization_token=token,
                application_type_label=application_type.get("label"),
                application_type_value=application_type.get("value"),
                current_status=result.get("status"),
            )
        except AdapterError as exc:
            if exc.status_code == 403:
                raise AdapterError(
                    403, "request_forbidden", "This request is not available"
                ) from exc
            if exc.status_code == 404:
                raise AdapterError(
                    404, "create_id_not_found", "The create_id was not found"
                ) from exc
            raise
        logging.getLogger(__name__).info(
            "New licence request queried request_id=%s consumer_id=%s create_id=%s",
            request.state.request_id,
            consumer_id,
            create_id,
        )
        return result

    @application.get("/v1/intakes")
    async def query_intakes(
        request: Request,
        office_code: Annotated[
            Optional[str], Query(pattern=r"^(LORCHE|LORCHD)$")
        ] = None,
        status: Annotated[
            Optional[str], Query(pattern=r"^[A-Za-z0-9_-]{1,64}$")
        ] = None,
        intake_id: Annotated[
            Optional[str], Query(pattern=r"^[A-Za-z0-9_-]{1,128}$")
        ] = None,
        application_id: Annotated[
            Optional[str], Query(pattern=r"^[A-Za-z0-9_-]{1,128}$")
        ] = None,
        page: Annotated[int, Query(ge=1)] = 1,
        page_size: Annotated[int, Query(ge=1, le=50)] = 10,
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_intakes(
            request_id=request.state.request_id,
            authorization_token=token,
            office_code=office_code,
            status=status,
            intake_id=intake_id,
            application_id=application_id,
            page=page,
            page_size=page_size,
        )
        logging.getLogger(__name__).info(
            "Intakes queried request_id=%s consumer_id=%s result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.get("/v1/new-licence-applications")
    async def query_new_licence_applications(
        request: Request,
        office_code: Annotated[
            Optional[str], Query(pattern=r"^(LORCHE|LORCHD)$")
        ] = None,
        status: Annotated[
            Optional[str],
            Query(pattern=r"^[A-Za-z0-9_-]{1,64}$"),
        ] = None,
        intake_id: Annotated[
            Optional[str], Query(pattern=r"^[A-Za-z0-9_-]{1,128}$")
        ] = None,
        application_id: Annotated[
            Optional[str], Query(pattern=r"^[A-Za-z0-9_-]{1,128}$")
        ] = None,
        page: Annotated[int, Query(ge=1)] = 1,
        page_size: Annotated[int, Query(ge=1, le=50)] = 10,
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_applications(
            request_id=request.state.request_id,
            authorization_token=token,
            office_code=office_code,
            status=status,
            intake_id=intake_id,
            application_id=application_id,
            page=page,
            page_size=page_size,
        )
        logging.getLogger(__name__).info(
            "New licence applications queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.get("/v1/new-licence-checklist")
    async def query_new_licence_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
        )
        logging.getLogger(__name__).info(
            "New licence checklist queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.get("/v1/changing-home-checklist")
    async def query_changing_home_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
        )
        logging.getLogger(__name__).info(
            "Changing Home checklist queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.get("/v1/self-withdraw-checklist")
    async def query_self_withdraw_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
            application_collection="t_self_withdraw_licence_application",
        )
        logging.getLogger(__name__).info(
            "Self-withdraw checklist queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.get("/v1/revoke-licence-checklist")
    async def query_revoke_licence_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
            application_collection="t_self_withdraw_licence_application",
        )
        logging.getLogger(__name__).info(
            "Revoke Licence checklist queried request_id=%s consumer_id=%s "
            "office_code=%s result_count=%s",
            request.state.request_id,
            consumer_id,
            office_code,
            len(result["data"]),
        )
        return result

    @application.get("/v1/specific-hour-checklist")
    async def query_specific_hour_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
            application_collection="t_specific",
        )
        logging.getLogger(__name__).info(
            "Specific Hour checklist queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.get("/v1/rp-checklist")
    async def query_rp_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
            application_collection="t_rp_application",
        )
        logging.getLogger(__name__).info(
            "RP checklist queried request_id=%s consumer_id=%s result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.post("/v1/create_intake_for_new_licence")
    async def create_intake_for_new_licence(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        _remember_external_request_id(request, payload)
        nocobase_client = request.app.state.client
        user_role = authenticated_user_role(identity)
        replay = await replay_existing_create(
            request,
            token=token,
            payload=payload,
            model_cls=CreateIntakeForNewLicenceRequest,
            application_type=NEW_LICENCE_APPLICATION_TYPE,
            api_type="create_intake_for_new_licence",
        )
        if replay is not None:
            return replay
        try:
            validated_payload = CreateIntakeForNewLicenceRequest.model_validate(payload)
        except PydanticValidationError as exc:
            validation_errors = _validation_fields(exc.errors())
            missing_required_fields = [
                item["path"]
                for item in validation_errors
                if item["code"] == VALIDATION_REQUIRED_CODE
            ]
            status = (
                "missing_required" if missing_required_fields else "invalid_request"
            )
            staging_values = {
                "f_request_body": payload,
                "f_source_system": settings.source_system,
                "f_request_event": "CREATE",
                "f_api_type": "create_intake_for_new_licence",
                "f_user_role": user_role,
                "f_status": status,
                "f_application_type": NEW_LICENCE_APPLICATION_TYPE,
                "f_office_code": _new_licence_office_code(payload),
                "f_application_status": None,
            }
            staging_record = await nocobase_client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values=staging_values,
            )
            if not isinstance(staging_record, dict) or staging_record.get("id") is None:
                raise AdapterError(
                    502,
                    "invalid_staging_create_response",
                    "The upstream did not return the created staging record ID",
                )
            external_request_id = payload.get("request_id")
            if not isinstance(external_request_id, str):
                external_request_id = None
            logging.getLogger(__name__).warning(
                "New licence request rejected after staging request_id=%s "
                "external_request_id=%s consumer_id=%s user_role=%s "
                "status=%s staging_record_id=%s validation_error_count=%s",
                request.state.request_id,
                external_request_id,
                consumer_id,
                user_role,
                status,
                staging_record["id"],
                len(validation_errors),
            )
            return _validation_response(request, validation_errors, status=status)

        staging_body = validated_payload.model_dump(
            mode="json", exclude_none=True, exclude_unset=True
        )
        # The native NLA workflow reads this business default from the staged
        # body when creating the application, even if the client omits it.
        staging_body["form_data"]["part_1"].setdefault(
            "application_type", validated_payload.form_data.part_1.application_type
        )
        try:
            await preflight_home_bound_checklist(
                request,
                authorization_token=token,
                office_code=validated_payload.form_data.case_summary.office_code,
                checklist=validated_payload.form_data.part_5.checklist,
                application_collection="t_licence_app",
                field_path="form_data.part_5.checklist",
            )
        except AdapterError as exc:
            await raise_audited_preflight_error(
                request,
                error=exc,
                authorization_token=token,
                request_body=staging_body,
                request_event="CREATE",
                api_type="create_intake_for_new_licence",
                user_role=user_role,
                application_type=NEW_LICENCE_APPLICATION_TYPE,
                office_code=validated_payload.form_data.case_summary.office_code,
                rch_id=None,
            )
        staging_values = {
            "f_request_body": staging_body,
            "f_source_system": settings.source_system,
            "f_request_event": "CREATE",
            "f_api_type": "create_intake_for_new_licence",
            "f_user_role": user_role,
            "f_status": STAGING_SUBMITTED_STATUS,
            "f_application_type": NEW_LICENCE_APPLICATION_TYPE,
            "f_office_code": validated_payload.form_data.case_summary.office_code,
            "f_application_status": NEW_LICENCE_INITIAL_STATUS,
        }
        staging_record = await create_accepted_staging(
            request,
            token=token,
            client_body=staging_body,
            client_request_id=validated_payload.request_id,
            application_type=NEW_LICENCE_APPLICATION_TYPE,
            api_type="create_intake_for_new_licence",
            staging_values=staging_values,
        )
        if not isinstance(staging_record, dict) or staging_record.get("id") is None:
            raise AdapterError(
                502,
                "invalid_staging_create_response",
                "The upstream did not return the created staging record ID",
            )
        logging.getLogger(__name__).info(
            "New licence request submitted request_id=%s "
            "external_request_id=%s consumer_id=%s user_role=%s "
            "source_system=%s staging_record_id=%s",
            request.state.request_id,
            validated_payload.request_id,
            consumer_id,
            user_role,
            settings.source_system,
            staging_record["id"],
        )
        return _accepted_business_response(
            request_id=validated_payload.request_id,
            create_id=staging_record["id"],
            application_type=NEW_LICENCE_APPLICATION_TYPE,
        )

    @application.post("/v1/update_new_licence_data")
    async def update_new_licence_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        _remember_external_request_id(request, payload)
        nocobase_client = request.app.state.client
        user_role = authenticated_user_role(identity)
        try:
            validated_payload = UpdateNewLicenceDataRequest.model_validate(payload)
        except PydanticValidationError as exc:
            validation_errors = _validation_fields(exc.errors())
            missing_required_fields = [
                item["path"]
                for item in validation_errors
                if item["code"] == VALIDATION_REQUIRED_CODE
            ]
            status = (
                "missing_required" if missing_required_fields else "invalid_request"
            )
            await nocobase_client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values={
                    "f_request_body": payload,
                    "f_source_system": settings.source_system,
                    "f_request_event": "UPDATE",
                    "f_api_type": "update_new_licence_data",
                    "f_user_role": user_role,
                    "f_status": status,
                    "f_application_type": NEW_LICENCE_APPLICATION_TYPE,
                    "f_office_code": _new_licence_office_code(payload),
                    "f_application_status": None,
                },
            )
            return _validation_response(
                request,
                validation_errors,
                status=status,
                include_create_id=True,
                create_id=payload.get("create_id"),
            )

        try:
            original_request = await nocobase_client.get_record(
                collection="t_api_request_staging",
                record_id=validated_payload.create_id,
                request_id=request.state.request_id,
                authorization_token=token,
            )
        except AdapterError as exc:
            if exc.status_code == 404:
                raise AdapterError(
                    404,
                    "request_not_found",
                    "The create request was not found",
                    details={"field": "create_id"},
                ) from exc
            raise
        if (
            str(original_request.get("f_source_system") or "").upper()
            != settings.source_system
            or original_request.get("f_request_event") != "CREATE"
            or original_request.get("f_api_type") != "create_intake_for_new_licence"
            or original_request.get("f_application_type")
            not in (None, "", NEW_LICENCE_APPLICATION_TYPE)
        ):
            raise AdapterError(
                404,
                "request_not_found",
                "The create request was not found",
                details={"field": "create_id"},
            )
        original_office_code = original_request.get("f_office_code")
        if original_office_code not in NEW_LICENCE_OFFICE_CODES:
            original_body = original_request.get("f_request_body")
            if isinstance(original_body, dict):
                original_form = original_body.get("form_data")
                if isinstance(original_form, dict):
                    original_summary = original_form.get("case_summary")
                    if isinstance(original_summary, dict):
                        original_office_code = original_summary.get("office_code")
        if original_office_code not in NEW_LICENCE_OFFICE_CODES:
            raise AdapterError(
                502,
                "invalid_create_record",
                "The original Create has no valid office_code.",
                details={"field": "create_id"},
            )
        update_summary = validated_payload.form_data.case_summary
        if (
            update_summary is not None
            and update_summary.office_code is not None
            and update_summary.office_code != original_office_code
        ):
            raise AdapterError(
                422,
                "invalid_field",
                "office_code cannot be changed after Create.",
                details={"field": "form_data.case_summary.office_code"},
            )
        update_part_2 = validated_payload.form_data.part_2
        if (
            update_part_2 is not None
            and update_part_2.rch_type_code is not None
            and not nla_rch_type_matches_office(
                original_office_code, update_part_2.rch_type_code
            )
        ):
            raise AdapterError(
                422,
                "invalid_field",
                "rch_type_code is not valid for the original office_code.",
                details={"field": "form_data.part_2.rch_type_code"},
            )
        application_status = original_request.get("f_application_status")
        queue_service = queue_service_for(request, NEW_LICENCE_APPLICATION_TYPE)
        if application_status != NEW_LICENCE_INITIAL_STATUS:
            if queue_service is not None:
                return await admit_queued_update(
                    request,
                    token=token,
                    validated_payload=validated_payload,
                    body=validated_payload.model_dump(mode="json", exclude_unset=True),
                    application_type=NEW_LICENCE_APPLICATION_TYPE,
                    create_api_type="create_intake_for_new_licence",
                    update_api_type="update_new_licence_data",
                    office_code=original_office_code,
                    rch_id=original_request.get("f_rch_id"),
                    user_role=user_role,
                )
            raise AdapterError(
                409,
                "update_locked",
                "Update is allowed only while status is Accepted.",
                details={"field": "create_id", "status": application_status},
            )
        if queue_service is None:
            _ensure_parent_create_ready(original_request)

        part_5 = validated_payload.form_data.part_5
        try:
            await preflight_home_bound_checklist(
                request,
                authorization_token=token,
                office_code=original_office_code,
                checklist=part_5.checklist if part_5 is not None else None,
                application_collection="t_licence_app",
                field_path="form_data.part_5.checklist",
            )
        except AdapterError as exc:
            await raise_audited_preflight_error(
                request,
                error=exc,
                authorization_token=token,
                request_body=validated_payload.model_dump(
                    mode="json", exclude_unset=True
                ),
                request_event="UPDATE",
                api_type="update_new_licence_data",
                user_role=user_role,
                application_type=NEW_LICENCE_APPLICATION_TYPE,
                office_code=original_office_code,
                rch_id=original_request.get("f_rch_id"),
                parent_create_id=validated_payload.create_id,
            )

        if queue_service is not None:
            return await admit_queued_update(
                request,
                token=token,
                validated_payload=validated_payload,
                body=validated_payload.model_dump(mode="json", exclude_unset=True),
                application_type=NEW_LICENCE_APPLICATION_TYPE,
                create_api_type="create_intake_for_new_licence",
                update_api_type="update_new_licence_data",
                office_code=original_office_code,
                rch_id=original_request.get("f_rch_id"),
                user_role=user_role,
            )
        async with update_submission_lock(request, validated_payload.create_id):
            await ensure_no_active_update(
                request,
                authorization_token=token,
                create_id=validated_payload.create_id,
            )
            staging_record = await nocobase_client.create_request_staging(
                request_id=request.state.request_id,
                authorization_token=token,
                values={
                    "f_request_body": validated_payload.model_dump(
                        mode="json", exclude_unset=True
                    ),
                    "f_source_system": settings.source_system,
                    "f_request_event": "UPDATE",
                    "f_api_type": "update_new_licence_data",
                    "f_user_role": user_role,
                    "f_status": STAGING_SUBMITTED_STATUS,
                    "f_application_type": NEW_LICENCE_APPLICATION_TYPE,
                    "f_office_code": original_office_code,
                    "f_application_status": None,
                    "f_parent_create_id": str(validated_payload.create_id),
                },
            )
        logging.getLogger(__name__).info(
            "New licence update submitted request_id=%s "
            "external_request_id=%s create_id=%s consumer_id=%s "
            "user_role=%s update_id=%s",
            request.state.request_id,
            validated_payload.request_id,
            validated_payload.create_id,
            consumer_id,
            user_role,
            staging_record["id"],
        )
        return _accepted_business_response(
            request_id=validated_payload.request_id,
            create_id=validated_payload.create_id,
            application_type=NEW_LICENCE_APPLICATION_TYPE,
        )

    @application.post("/v1/create_intake_for_changing_home")
    async def create_intake_for_changing_home(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForChangingHomeRequest,
            application_type=CHANGING_HOME_APPLICATION_TYPE,
            api_type=CHANGING_HOME_CREATE_API_TYPE,
            initial_status=CHANGING_HOME_INITIAL_STATUS,
            log_label="Changing Home",
        )

    @application.post("/v1/update_changing_home_data")
    async def update_changing_home_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateChangingHomeDataRequest,
            application_type=CHANGING_HOME_APPLICATION_TYPE,
            create_api_type=CHANGING_HOME_CREATE_API_TYPE,
            update_api_type=CHANGING_HOME_UPDATE_API_TYPE,
            initial_status=CHANGING_HOME_INITIAL_STATUS,
            log_label="Changing Home",
        )

    @application.post("/v1/create_intake_for_self_withdraw")
    async def create_intake_for_self_withdraw(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForSelfWithdrawRequest,
            application_type=SELF_WITHDRAW_APPLICATION_TYPE,
            api_type=SELF_WITHDRAW_CREATE_API_TYPE,
            initial_status=SELF_WITHDRAW_INITIAL_STATUS,
            log_label="Self-withdraw",
        )

    @application.post("/v1/update_self_withdraw_data")
    async def update_self_withdraw_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateSelfWithdrawDataRequest,
            application_type=SELF_WITHDRAW_APPLICATION_TYPE,
            create_api_type=SELF_WITHDRAW_CREATE_API_TYPE,
            update_api_type=SELF_WITHDRAW_UPDATE_API_TYPE,
            initial_status=SELF_WITHDRAW_INITIAL_STATUS,
            log_label="Self-withdraw",
        )

    @application.post("/v1/create_intake_for_revoke_licence")
    async def create_intake_for_revoke_licence(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForRevokeLicenceRequest,
            application_type=REVOKE_LICENCE_APPLICATION_TYPE,
            api_type=REVOKE_LICENCE_CREATE_API_TYPE,
            initial_status=REVOKE_LICENCE_INITIAL_STATUS,
            log_label="Revoke Licence",
        )

    @application.post("/v1/update_revoke_licence_data")
    async def update_revoke_licence_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateRevokeLicenceDataRequest,
            application_type=REVOKE_LICENCE_APPLICATION_TYPE,
            create_api_type=REVOKE_LICENCE_CREATE_API_TYPE,
            update_api_type=REVOKE_LICENCE_UPDATE_API_TYPE,
            initial_status=REVOKE_LICENCE_INITIAL_STATUS,
            log_label="Revoke Licence",
        )

    @application.post("/v1/create_intake_for_specific_hour")
    async def create_intake_for_specific_hour(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForSpecificHourRequest,
            application_type=SPECIFIC_HOUR_APPLICATION_TYPE,
            api_type=SPECIFIC_HOUR_CREATE_API_TYPE,
            initial_status=SPECIFIC_HOUR_INITIAL_STATUS,
            log_label="Specific Hour",
        )

    @application.post("/v1/update_specific_hour_data")
    async def update_specific_hour_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateSpecificHourDataRequest,
            application_type=SPECIFIC_HOUR_APPLICATION_TYPE,
            create_api_type=SPECIFIC_HOUR_CREATE_API_TYPE,
            update_api_type=SPECIFIC_HOUR_UPDATE_API_TYPE,
            initial_status=SPECIFIC_HOUR_INITIAL_STATUS,
            log_label="Specific Hour",
        )

    @application.post("/v1/create_intake_for_rp")
    async def create_intake_for_rp(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForRpRequest,
            application_type=RESPONSIBLE_PERSON_APPLICATION_TYPE,
            api_type=RESPONSIBLE_PERSON_CREATE_API_TYPE,
            initial_status=RESPONSIBLE_PERSON_INITIAL_STATUS,
            log_label="Responsible Person",
        )

    @application.post("/v1/update_rp_data")
    async def update_rp_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateRpDataRequest,
            application_type=RESPONSIBLE_PERSON_APPLICATION_TYPE,
            create_api_type=RESPONSIBLE_PERSON_CREATE_API_TYPE,
            update_api_type=RESPONSIBLE_PERSON_UPDATE_API_TYPE,
            initial_status=RESPONSIBLE_PERSON_INITIAL_STATUS,
            log_label="Responsible Person",
        )

    @application.post("/v1/create_intake_for_change_home_manager")
    async def create_intake_for_change_home_manager(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForChangeHomeManagerRequest,
            application_type=CHANGE_HOME_MANAGER_APPLICATION_TYPE,
            api_type=CHANGE_HOME_MANAGER_CREATE_API_TYPE,
            initial_status=CHANGE_HOME_MANAGER_INITIAL_STATUS,
            log_label="Change Home Manager",
        )

    @application.post("/v1/update_change_home_manager_data")
    async def update_change_home_manager_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateChangeHomeManagerDataRequest,
            application_type=CHANGE_HOME_MANAGER_APPLICATION_TYPE,
            create_api_type=CHANGE_HOME_MANAGER_CREATE_API_TYPE,
            update_api_type=CHANGE_HOME_MANAGER_UPDATE_API_TYPE,
            initial_status=CHANGE_HOME_MANAGER_INITIAL_STATUS,
            log_label="Change Home Manager",
        )

    @application.post("/v1/create_intake_for_change_beds")
    async def create_intake_for_change_beds(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForChangeBedsRequest,
            application_type=CHANGE_BEDS_APPLICATION_TYPE,
            api_type=CHANGE_BEDS_CREATE_API_TYPE,
            initial_status=CHANGE_BEDS_INITIAL_STATUS,
            log_label="Change Beds",
        )

    @application.post("/v1/update_change_beds_data")
    async def update_change_beds_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateChangeBedsDataRequest,
            application_type=CHANGE_BEDS_APPLICATION_TYPE,
            create_api_type=CHANGE_BEDS_CREATE_API_TYPE,
            update_api_type=CHANGE_BEDS_UPDATE_API_TYPE,
            initial_status=CHANGE_BEDS_INITIAL_STATUS,
            log_label="Change Beds",
        )

    @application.post("/v1/create_intake_for_change_operation_mode")
    async def create_intake_for_change_operation_mode(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForChangeOperationModeRequest,
            application_type=CHANGE_OPERATION_MODE_APPLICATION_TYPE,
            api_type=CHANGE_OPERATION_MODE_CREATE_API_TYPE,
            initial_status=CHANGE_OPERATION_MODE_INITIAL_STATUS,
            log_label="Change Operation Mode",
        )

    @application.post("/v1/update_change_operation_mode_data")
    async def update_change_operation_mode_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateChangeOperationModeDataRequest,
            application_type=CHANGE_OPERATION_MODE_APPLICATION_TYPE,
            create_api_type=CHANGE_OPERATION_MODE_CREATE_API_TYPE,
            update_api_type=CHANGE_OPERATION_MODE_UPDATE_API_TYPE,
            initial_status=CHANGE_OPERATION_MODE_INITIAL_STATUS,
            log_label="Change Operation Mode",
        )

    @application.post("/v1/create_intake_for_change_directors")
    async def create_intake_for_change_directors(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForChangeDirectorsRequest,
            application_type=CHANGE_DIRECTORS_APPLICATION_TYPE,
            api_type=CHANGE_DIRECTORS_CREATE_API_TYPE,
            initial_status=CHANGE_DIRECTORS_INITIAL_STATUS,
            log_label="Change Directors",
        )

    @application.post("/v1/update_change_directors_data")
    async def update_change_directors_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateChangeDirectorsDataRequest,
            application_type=CHANGE_DIRECTORS_APPLICATION_TYPE,
            create_api_type=CHANGE_DIRECTORS_CREATE_API_TYPE,
            update_api_type=CHANGE_DIRECTORS_UPDATE_API_TYPE,
            initial_status=CHANGE_DIRECTORS_INITIAL_STATUS,
            log_label="Change Directors",
        )

    @application.post("/v1/create_intake_for_change_nurse_in_charge")
    async def create_intake_for_change_nurse_in_charge(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForChangeNurseInChargeRequest,
            application_type=CHANGE_NURSE_APPLICATION_TYPE,
            api_type=CHANGE_NURSE_CREATE_API_TYPE,
            initial_status=CHANGE_NURSE_INITIAL_STATUS,
            log_label="Change Nurse-in-Charge",
        )

    @application.post("/v1/update_change_nurse_in_charge_data")
    async def update_change_nurse_in_charge_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateChangeNurseInChargeDataRequest,
            application_type=CHANGE_NURSE_APPLICATION_TYPE,
            create_api_type=CHANGE_NURSE_CREATE_API_TYPE,
            update_api_type=CHANGE_NURSE_UPDATE_API_TYPE,
            initial_status=CHANGE_NURSE_INITIAL_STATUS,
            log_label="Change Nurse-in-Charge",
        )

    @application.post("/v1/create_intake_for_prosecution")
    async def create_intake_for_prosecution(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForProsecutionRequest,
            application_type=PROSECUTION_APPLICATION_TYPE,
            api_type=PROSECUTION_CREATE_API_TYPE,
            initial_status=PROSECUTION_INITIAL_STATUS,
            log_label="Prosecution",
        )

    @application.post("/v1/update_prosecution_data")
    async def update_prosecution_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        if not settings.nocobase.prosecution_update_enabled:
            raise AdapterError(
                503,
                "update_temporarily_unavailable",
                "Prosecution Update is temporarily unavailable.",
            )
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateProsecutionDataRequest,
            application_type=PROSECUTION_APPLICATION_TYPE,
            create_api_type=PROSECUTION_CREATE_API_TYPE,
            update_api_type=PROSECUTION_UPDATE_API_TYPE,
            initial_status=PROSECUTION_INITIAL_STATUS,
            log_label="Prosecution",
        )

    @application.get("/v1/licence-renewal-checklist")
    async def query_licence_renewal_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
            application_collection="t_licence_app",
        )
        logging.getLogger(__name__).info(
            "Licence Renewal checklist queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.post("/v1/create_licence_renewal")
    async def create_licence_renewal(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateLicenceRenewalRequest,
            application_type=LICENCE_RENEWAL_APPLICATION_TYPE,
            api_type=LICENCE_RENEWAL_CREATE_API_TYPE,
            initial_status=LICENCE_RENEWAL_INITIAL_STATUS,
            log_label="Licence Renewal",
        )

    @application.post("/v1/update_licence_renewal_data")
    async def update_licence_renewal_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        # A reviewed queue release already proves the LRN worker binding.
        # Keep the legacy feature flag for non-queue operation, but do not
        # require a second independent switch for a selected queue family.
        lrn_queue_active = (
            LICENCE_RENEWAL_APPLICATION_TYPE
            in request.app.state.update_queue_application_types
            and request.app.state.update_queue_service is not None
        )
        if (
            not settings.nocobase.licence_renewal_update_enabled
            and not lrn_queue_active
        ):
            raise AdapterError(
                503,
                "update_temporarily_unavailable",
                "Licence renewal Update is temporarily unavailable.",
            )
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateLicenceRenewalDataRequest,
            application_type=LICENCE_RENEWAL_APPLICATION_TYPE,
            create_api_type=LICENCE_RENEWAL_CREATE_API_TYPE,
            update_api_type=LICENCE_RENEWAL_UPDATE_API_TYPE,
            initial_status=LICENCE_RENEWAL_INITIAL_STATUS,
            log_label="Licence Renewal",
            allow_cmtf_create=True,
        )

    @application.get("/v1/expansion-aip-checklist")
    async def query_expansion_aip_checklist(
        request: Request,
        office_code: Annotated[str, Query(pattern=r"^(LORCHE|LORCHD)$")],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> dict[str, Any]:
        _token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.query_service.list_checklist_catalog(
            request_id=request.state.request_id,
            office_code=office_code,
        )
        logging.getLogger(__name__).info(
            "Expansion AIP checklist queried request_id=%s consumer_id=%s "
            "result_count=%s",
            request.state.request_id,
            consumer_id,
            len(result["data"]),
        )
        return result

    @application.post("/v1/create_intake_for_expansion_aip")
    async def create_intake_for_expansion_aip(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_create(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=CreateIntakeForExpansionAipRequest,
            application_type=EXPANSION_AIP_APPLICATION_TYPE,
            api_type=EXPANSION_AIP_CREATE_API_TYPE,
            initial_status=EXPANSION_AIP_INITIAL_STATUS,
            log_label="Expansion AIP",
        )

    @application.post("/v1/update_expansion_aip_data")
    async def update_expansion_aip_data(
        request: Request,
        payload: Annotated[dict[str, Any], Body()],
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> Any:
        token, consumer_id, identity = await authenticate_client(request, authorization)
        return await stage_home_bound_update(
            request,
            payload,
            token=token,
            consumer_id=consumer_id,
            user_role=authenticated_user_role(identity),
            model_cls=UpdateExpansionAipDataRequest,
            application_type=EXPANSION_AIP_APPLICATION_TYPE,
            create_api_type=EXPANSION_AIP_CREATE_API_TYPE,
            update_api_type=EXPANSION_AIP_UPDATE_API_TYPE,
            initial_status=EXPANSION_AIP_INITIAL_STATUS,
            log_label="Expansion AIP",
        )

    @application.post("/v1/files", response_model=FileUploadResult)
    async def upload_file(
        request: Request,
        file: Annotated[UploadFile, File()],
        external_request_id: Annotated[
            Optional[str], Form(alias="externalRequestId")
        ] = None,
        sha256: Annotated[Optional[str], Form()] = None,
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> FileUploadResult:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        return await request.app.state.upload_service.upload_file(
            upload=file,
            request_id=request.state.request_id,
            external_request_id=external_request_id,
            expected_sha256=sha256,
            consumer_id=consumer_id,
            authorization_token=token,
        )

    @application.get("/v1/files/{attachment_id}")
    async def download_file(
        request: Request,
        attachment_id: Annotated[
            str,
            Path(pattern=r"^[A-Za-z0-9_-]{1,128}$"),
        ],
        authorization: Annotated[Optional[str], Header()] = None,
        range_header: Annotated[Optional[str], Header(alias="Range")] = None,
    ) -> StreamingResponse:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        byte_range = validate_byte_range(range_header)
        try:
            download = await request.app.state.client.open_attachment_download(
                attachment_id=attachment_id,
                request_id=request.state.request_id,
                authorization_token=token,
                byte_range=byte_range,
            )
        except AdapterError as exc:
            if exc.status_code == 403:
                raise AdapterError(
                    403,
                    "attachment_forbidden",
                    "The attachment is not available to this user",
                ) from exc
            raise
        logging.getLogger(__name__).info(
            "File download opened request_id=%s consumer_id=%s attachment_id=%s",
            request.state.request_id,
            consumer_id,
            attachment_id,
        )
        return StreamingResponse(
            download.content,
            status_code=download.status_code,
            headers=download.headers,
        )

    @application.post("/simple-test")
    async def simple_test(
        request: Request,
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> object:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        result = await request.app.state.client.trigger_business_webhook(
            path=settings.nocobase.api.simple_test,
            request_id=request.state.request_id,
            authorization_token=token,
        )
        logging.getLogger(__name__).info(
            "Business webhook completed request_id=%s consumer_id=%s route=simple-test",
            request.state.request_id,
            consumer_id,
        )
        return result

    @application.post("/homerecord-query")
    async def homerecord_query(
        request: Request,
        officeCode: Optional[str] = None,
        rchStatus: Optional[str] = None,
        rchNo: Optional[str] = None,
        authorization: Annotated[Optional[str], Header()] = None,
    ) -> object:
        token, consumer_id, _identity = await authenticate_client(
            request, authorization
        )
        params = [
            (key, value)
            for key, value in (
                ("officeCode", officeCode),
                ("rchStatus", rchStatus),
                ("rchNo", rchNo),
            )
            if value is not None
        ]
        result = await request.app.state.client.trigger_business_webhook(
            path=settings.nocobase.api.homerecord_query,
            request_id=request.state.request_id,
            authorization_token=token,
            params=params or None,
        )
        logging.getLogger(__name__).info(
            "Business webhook completed request_id=%s consumer_id=%s "
            "route=homerecord-query",
            request.state.request_id,
            consumer_id,
        )
        return result

    return application


app = create_app()
