from __future__ import annotations

import re
from pathlib import Path

import yaml

from .errors import AdapterError, ConfigurationError
from .models import ApplicationMapping, AttachmentFieldMapping

SAFE_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


class ApplicationMappings:
    def __init__(self, items: dict[str, ApplicationMapping]) -> None:
        self._items = items

    @classmethod
    def load(cls, path: Path) -> ApplicationMappings:
        if not path.is_file():
            raise ConfigurationError(f"Mapping file does not exist: {path}")
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        raw_applications = raw.get("applications")
        if not isinstance(raw_applications, dict) or not raw_applications:
            raise ConfigurationError("applications mapping cannot be empty")

        mappings: dict[str, ApplicationMapping] = {}
        for application_type, raw_mapping in raw_applications.items():
            normalized_type = str(application_type).strip().upper()
            collection = str(raw_mapping.get("collection", "")).strip()
            if not SAFE_IDENTIFIER.fullmatch(collection):
                raise ConfigurationError(
                    f"Invalid collection for {normalized_type}: {collection}"
                )

            raw_fields = raw_mapping.get("attachment_fields")
            if not isinstance(raw_fields, dict) or not raw_fields:
                raise ConfigurationError(
                    f"attachment_fields cannot be empty for {normalized_type}"
                )
            fields: dict[str, AttachmentFieldMapping] = {}
            for public_name, raw_field in raw_fields.items():
                public_name = str(public_name).strip()
                internal_field = str(
                    raw_field.get("internal_field", "")
                ).strip()
                if not SAFE_IDENTIFIER.fullmatch(internal_field):
                    raise ConfigurationError(
                        f"Invalid attachment field for {normalized_type}: "
                        f"{internal_field}"
                    )
                document_types = frozenset(
                    str(value).strip().upper()
                    for value in raw_field.get("document_types", [])
                    if str(value).strip()
                )
                fields[public_name] = AttachmentFieldMapping(
                    public_name=public_name,
                    internal_field=internal_field,
                    multiple=bool(raw_field.get("multiple", True)),
                    document_types=document_types,
                )
            mappings[normalized_type] = ApplicationMapping(
                application_type=normalized_type,
                collection=collection,
                attachment_fields=fields,
            )
        return cls(mappings)

    def resolve(
        self,
        application_type: str,
        attachment_field: str,
        document_type: str,
    ) -> tuple[ApplicationMapping, AttachmentFieldMapping]:
        normalized_type = application_type.strip().upper()
        application = self._items.get(normalized_type)
        if application is None:
            raise AdapterError(
                400,
                "unsupported_application_type",
                "The applicationType is not enabled",
            )
        field = application.attachment_fields.get(attachment_field.strip())
        if field is None:
            raise AdapterError(
                400,
                "unsupported_attachment_field",
                "The attachmentField is not enabled for this applicationType",
            )
        normalized_document_type = document_type.strip().upper()
        if (
            field.document_types
            and normalized_document_type not in field.document_types
        ):
            raise AdapterError(
                400,
                "unsupported_document_type",
                "The documentType is not enabled for this attachmentField",
            )
        return application, field
