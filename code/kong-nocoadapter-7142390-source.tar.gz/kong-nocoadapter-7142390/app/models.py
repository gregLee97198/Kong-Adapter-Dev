from __future__ import annotations

import datetime as dt
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import date, time
from typing import Any, ClassVar, Literal, Optional, Union

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    NonNegativeInt,
    PositiveInt,
    StrictBool,
    field_validator,
    model_validator,
)


@dataclass(frozen=True)
class AttachmentFieldMapping:
    public_name: str
    internal_field: str
    multiple: bool
    document_types: frozenset[str]


@dataclass(frozen=True)
class ApplicationMapping:
    application_type: str
    collection: str
    attachment_fields: dict[str, AttachmentFieldMapping]


class StorageInfo(BaseModel):
    id: Union[int, str]
    title: Optional[str] = None
    name: str
    type: str
    rules: dict[str, Any] = Field(default_factory=dict)
    baseUrl: Optional[str] = None
    public: Optional[bool] = None


class UploadResult(BaseModel):
    success: bool = True
    requestId: str
    externalRequestId: Optional[str] = None
    application: dict[str, Any]
    attachmentField: str
    documentType: str
    attachment: dict[str, Any]
    storage: dict[str, Any]
    status: str = "ATTACHED"


class FileUploadResult(BaseModel):
    data_id: Union[int, str]
    filename: str
    size: int = Field(ge=0)
    download_url: str


class ApiPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")


ScalarId = Union[int, str]
EnumValue = Union[int, str]


def _validate_business_email(value: Optional[str]) -> Optional[str]:
    """Match the practical constraints of the NocoBase email field.

    NocoBase rejects non-routable test top-level domains during the workflow
    update.  Catch those values before a Staging row can start an otherwise
    irreversible business flow.
    """

    if value is None:
        return None
    candidate = value.strip()
    local, separator, domain = candidate.rpartition("@")
    labels = domain.split(".")
    reserved_tlds = {"example", "invalid", "localhost", "test"}
    if (
        not separator
        or not local
        or any(character.isspace() for character in candidate)
        or len(labels) < 2
        or any(not label for label in labels)
        or not labels[-1].isalpha()
        or len(labels[-1]) < 2
        or labels[-1].lower() in reserved_tlds
    ):
        raise ValueError("must be a valid routable email address")
    return candidate


class AddressPayload(ApiPayload):
    # The public API deliberately has no address_select/address record ID.
    # Clients send the address itself. The workflow resolves these portable
    # codes against f_tree_region_district and creates a t_address record.
    region_code: str = Field(min_length=1, max_length=128)
    district_code: str = Field(min_length=1, max_length=128)
    sub_district_code: str = Field(min_length=1, max_length=128)
    full_name_en: Optional[str] = None
    full_name_cn: Optional[str] = None
    lot_or_address_en: Optional[str] = None
    lot_or_address_cn: Optional[str] = None
    block_no_en: Optional[str] = None
    block_no_cn: Optional[str] = None
    block_type_en: Optional[Literal["0", "1", "2", "3"]] = None
    block_type_cn: Optional[Literal["0", "1", "2", "3"]] = None
    floor_en: Optional[str] = None
    floor_cn: Optional[str] = None
    unit_no_en: Optional[str] = None
    unit_no_cn: Optional[str] = None
    unit_type_en: Optional[Literal["0", "1", "2", "3", "4"]] = None
    unit_type_cn: Optional[Literal["0", "1", "2", "3", "4"]] = None
    building_name_en: Optional[str] = None
    building_name_cn: Optional[str] = None
    estate_or_village_en: Optional[str] = None
    estate_or_village_cn: Optional[str] = None
    street_no_en: Optional[str] = None
    street_no_cn: Optional[str] = None
    street_name_en: Optional[str] = None
    street_name_cn: Optional[str] = None
    phase_en: Optional[str] = None
    phase_cn: Optional[str] = None


class ContactPayload(ApiPayload):
    id: Optional[ScalarId] = None
    title: Optional[str] = None
    display_name: Optional[str] = None
    full_name_en: Optional[str] = None
    full_name_cn: Optional[str] = None
    first_name_en: Optional[str] = None
    middle_name_en: Optional[str] = None
    last_name_en: Optional[str] = None
    surname_cn: Optional[str] = None
    given_name_cn: Optional[str] = None
    hkid_part_1: Optional[str] = None
    hkid_part_2: Optional[str] = None
    hkid_part_3: Optional[str] = None
    position_title: Optional[str] = None
    representative_position: Optional[str] = None
    contact_relationship: Optional[EnumValue] = None
    contact_relationship_other: Optional[str] = None
    mobile_phone: Optional[str] = None
    residential_phone: Optional[str] = None
    office_phone: Optional[str] = None
    email: Optional[str] = None
    office_email: Optional[str] = None
    company_name_en: Optional[str] = None
    company_name_cn: Optional[str] = None
    business_registration_no: Optional[str] = None
    certificate_of_incorporation_no: Optional[str] = None
    application_type: Optional[EnumValue] = None
    address_for_licence: Optional[bool] = None
    active: Optional[bool] = None
    address: Optional[AddressPayload] = None


class NlaContactPayload(ContactPayload):
    """Client-supplied NLA contact data never identifies a native child row."""

    @model_validator(mode="before")
    @classmethod
    def reject_native_id(cls, value: Any) -> Any:
        if isinstance(value, dict) and "id" in value:
            raise ValueError("NLA contact id is an internal field")
        return value


class PremisePayload(ApiPayload):
    # Returned by the Create-result query and reused by the Update API.
    # The Create workflow ignores a client-supplied value.
    id: Optional[ScalarId] = None
    premise_type: Literal["0", "1", "2", "3"]
    location: Optional[str] = None
    tenancy_from: date
    tenancy_to: date
    sort_order: Optional[int] = None
    address: Optional[AddressPayload] = None


class NlaPremisePayload(PremisePayload):
    """A supplied NLA premise is a complete replacement item, not an ID patch."""

    @model_validator(mode="before")
    @classmethod
    def reject_native_id(cls, value: Any) -> Any:
        if isinstance(value, dict) and "id" in value:
            raise ValueError("NLA premise id is an internal field")
        return value


class NlaReplacementPremisePayload(NlaPremisePayload):
    """Update creates a new premise/address pair for each supplied row."""

    address: AddressPayload


class PremisesPayload(ApiPayload):
    self_owned: list[NlaPremisePayload] = Field(default_factory=list)
    rented: list[NlaPremisePayload] = Field(default_factory=list)


class ChecklistItemPayload(ApiPayload):
    position_code: str = Field(min_length=1, max_length=128)
    attachment_id: PositiveInt


class CaseSummaryPayload(ApiPayload):
    office_code: Literal["LORCHE", "LORCHD"]
    received_date: Optional[date] = None
    severity: Optional[EnumValue] = None


class NewLicenceCaseSummaryPayload(ApiPayload):
    """Only the client-owned NLA summary fields appear in its public schema."""

    office_code: Literal["LORCHE", "LORCHD"]
    received_date: Optional[date] = None
    severity: Optional[Literal["0", "1", "2"]] = None


class NlaPart1Payload(ApiPayload):
    application_received_date: date
    application_type: Literal["0", "1"] = "0"
    tentative_commencement_date: date


class NlaPart2Payload(ApiPayload):
    rch_name_en: str = Field(min_length=1)
    rch_name_cn: str = Field(min_length=1)
    operation_mode_id: ScalarId
    premises_type: Literal["0", "1", "2", "3"]
    monthly_fee_min: float
    monthly_fee_max: float
    gender: Literal["0", "1", "2"]
    floor_area_sqm: float
    licence_capacity: int
    address: AddressPayload
    telephone_no: Optional[str] = None
    fax_no: Optional[str] = None
    email: Optional[str] = None
    floors_total: Optional[int] = None
    units_total: Optional[int] = None
    operation_mode_other: Optional[str] = None
    is_rcsv: Optional[bool] = None
    rch_type_code: Literal["a1", "a2", "a3", "a4", "b1", "b2", "b3"]
    complies_lease_dmc: Optional[bool] = None
    complies_lease_dmc_other: Optional[str] = None
    nursing_home_places: NonNegativeInt
    care_and_attention_home_places: NonNegativeInt
    aged_home_places: NonNegativeInt
    self_care_hostel_places: NonNegativeInt
    max_capacity: Optional[int] = None
    existing_capacity: Optional[int] = None
    enrolment_residents: Optional[int] = None
    premises: PremisesPayload


class NlaPart3Payload(ApiPayload):
    rch_business_status: Literal["0", "1"]
    applicant_operator_type: Literal["0", "1", "2", "3"]
    date_of_operation: Optional[date] = None
    signature_date: Optional[date] = None
    operator: Optional[NlaContactPayload] = None
    company: Optional[NlaContactPayload] = None
    personnel: list[NlaContactPayload] = Field(default_factory=list)


class NlaPart4Payload(ApiPayload):
    authorised_representative: Optional[NlaContactPayload] = None


class NlaPart5Payload(ApiPayload):
    application_level: Literal["normal", "high"]
    checklist: list[ChecklistItemPayload] = Field(default_factory=list)

    @model_validator(mode="after")
    def require_distinct_checklist_positions(self) -> NlaPart5Payload:
        codes = [item.position_code for item in self.checklist]
        if len(codes) != len(set(codes)):
            raise ValueError("NLA checklist position_code must be unique")
        return self


NLA_RCH_TYPES_BY_OFFICE = {
    "LORCHE": frozenset({"a1", "a2", "a3", "a4"}),
    "LORCHD": frozenset({"b1", "b2", "b3"}),
}


def nla_rch_type_matches_office(office_code: str, rch_type_code: str) -> bool:
    """Apply the office-specific rch_type_code values in the public enum table."""
    return rch_type_code in NLA_RCH_TYPES_BY_OFFICE.get(office_code, ())


class NewLicenceFormData(ApiPayload):
    case_summary: NewLicenceCaseSummaryPayload
    part_1: NlaPart1Payload
    part_2: NlaPart2Payload
    part_3: NlaPart3Payload
    part_4: Optional[NlaPart4Payload] = None
    part_5: NlaPart5Payload

    @model_validator(mode="after")
    def require_office_specific_rch_type(self) -> NewLicenceFormData:
        if not nla_rch_type_matches_office(
            self.case_summary.office_code, self.part_2.rch_type_code
        ):
            raise ValueError(
                "form_data.part_2.rch_type_code is not valid for office_code"
            )
        return self


class CreateIntakeForNewLicenceRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: NewLicenceFormData


class UpdateAddressPayload(ApiPayload):
    region_code: Optional[str] = Field(default=None, min_length=1, max_length=128)
    district_code: Optional[str] = Field(default=None, min_length=1, max_length=128)
    sub_district_code: Optional[str] = Field(default=None, min_length=1, max_length=128)
    full_name_en: Optional[str] = None
    full_name_cn: Optional[str] = None
    lot_or_address_en: Optional[str] = None
    lot_or_address_cn: Optional[str] = None
    block_no_en: Optional[str] = None
    block_no_cn: Optional[str] = None
    block_type_en: Optional[Literal["0", "1", "2", "3"]] = None
    block_type_cn: Optional[Literal["0", "1", "2", "3"]] = None
    floor_en: Optional[str] = None
    floor_cn: Optional[str] = None
    unit_no_en: Optional[str] = None
    unit_no_cn: Optional[str] = None
    unit_type_en: Optional[Literal["0", "1", "2", "3", "4"]] = None
    unit_type_cn: Optional[Literal["0", "1", "2", "3", "4"]] = None
    building_name_en: Optional[str] = None
    building_name_cn: Optional[str] = None
    estate_or_village_en: Optional[str] = None
    estate_or_village_cn: Optional[str] = None
    street_no_en: Optional[str] = None
    street_no_cn: Optional[str] = None
    street_name_en: Optional[str] = None
    street_name_cn: Optional[str] = None
    phase_en: Optional[str] = None
    phase_cn: Optional[str] = None

    @model_validator(mode="after")
    def require_complete_location_codes(self) -> UpdateAddressPayload:
        codes = (self.region_code, self.district_code, self.sub_district_code)
        if any(value is not None for value in codes) and not all(
            value is not None for value in codes
        ):
            raise ValueError(
                "region_code, district_code and sub_district_code must be "
                "provided together"
            )
        return self


class UpdateContactPayload(ApiPayload):
    id: Optional[ScalarId] = None
    title: Optional[str] = None
    display_name: Optional[str] = None
    full_name_en: Optional[str] = None
    full_name_cn: Optional[str] = None
    first_name_en: Optional[str] = None
    middle_name_en: Optional[str] = None
    last_name_en: Optional[str] = None
    surname_cn: Optional[str] = None
    given_name_cn: Optional[str] = None
    hkid_part_1: Optional[str] = None
    hkid_part_2: Optional[str] = None
    hkid_part_3: Optional[str] = None
    position_title: Optional[str] = None
    representative_position: Optional[str] = None
    contact_relationship: Optional[EnumValue] = None
    contact_relationship_other: Optional[str] = None
    mobile_phone: Optional[str] = None
    residential_phone: Optional[str] = None
    office_phone: Optional[str] = None
    email: Optional[str] = None
    office_email: Optional[str] = None
    company_name_en: Optional[str] = None
    company_name_cn: Optional[str] = None
    business_registration_no: Optional[str] = None
    certificate_of_incorporation_no: Optional[str] = None
    application_type: Optional[EnumValue] = None
    address_for_licence: Optional[bool] = None
    active: Optional[bool] = None
    address: Optional[UpdateAddressPayload] = None


class UpdateNlaContactPayload(UpdateContactPayload):
    """NLA singleton contacts are selected by role, not a client child ID."""

    @model_validator(mode="before")
    @classmethod
    def reject_native_id(cls, value: Any) -> Any:
        if isinstance(value, dict) and "id" in value:
            raise ValueError("NLA contact id is an internal field")
        return value


class NlaReplacementPersonnelPayload(NlaContactPayload):
    """Each supplied personnel row is part of a complete new list."""

    @model_validator(mode="after")
    def require_name(self) -> NlaReplacementPersonnelPayload:
        def has(value: Optional[str]) -> bool:
            return isinstance(value, str) and bool(value.strip())

        has_name = any(
            has(value)
            for value in (self.full_name_en, self.full_name_cn, self.display_name)
        )
        has_split_english_name = has(self.first_name_en) and has(self.last_name_en)
        has_split_chinese_name = has(self.surname_cn) and has(self.given_name_cn)
        if not (has_name or has_split_english_name or has_split_chinese_name):
            raise ValueError(
                "Each NLA personnel member needs a full or complete split name"
            )
        return self


class UpdatePremisePayload(ApiPayload):
    id: Optional[ScalarId] = None
    premise_type: Optional[Literal["0", "1", "2", "3"]] = None
    location: Optional[str] = None
    tenancy_from: Optional[date] = None
    tenancy_to: Optional[date] = None
    sort_order: Optional[int] = None
    address: Optional[UpdateAddressPayload] = None


class UpdatePremisesPayload(ApiPayload):
    self_owned: Optional[list[UpdatePremisePayload]] = None
    rented: Optional[list[UpdatePremisePayload]] = None


class NlaReplacementPremisesPayload(ApiPayload):
    self_owned: Optional[list[NlaReplacementPremisePayload]] = None
    rented: Optional[list[NlaReplacementPremisePayload]] = None

    @field_validator("self_owned", "rented", mode="before")
    @classmethod
    def require_array_when_supplied(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("Use [] to clear a supplied NLA premises category")
        return value


class UpdateChecklistItemPayload(ApiPayload):
    position_code: str = Field(min_length=1, max_length=128)
    attachment_id: PositiveInt


class UpdateCaseSummaryPayload(ApiPayload):
    office_code: Optional[Literal["LORCHE", "LORCHD"]] = None
    received_date: Optional[date] = None
    severity: Optional[EnumValue] = None


class UpdateNewLicenceCaseSummaryPayload(ApiPayload):
    office_code: Optional[Literal["LORCHE", "LORCHD"]] = None
    received_date: Optional[date] = None
    severity: Optional[Literal["0", "1", "2"]] = None


class UpdateNlaPart1Payload(ApiPayload):
    application_received_date: Optional[date] = None
    application_type: Optional[Literal["0", "1"]] = None
    tentative_commencement_date: Optional[date] = None


class UpdateNlaPart2Payload(ApiPayload):
    rch_name_en: Optional[str] = Field(default=None, min_length=1)
    rch_name_cn: Optional[str] = Field(default=None, min_length=1)
    operation_mode_id: Optional[ScalarId] = None
    premises_type: Optional[Literal["0", "1", "2", "3"]] = None
    monthly_fee_min: Optional[float] = None
    monthly_fee_max: Optional[float] = None
    gender: Optional[EnumValue] = None
    floor_area_sqm: Optional[float] = None
    licence_capacity: Optional[int] = None
    address: Optional[UpdateAddressPayload] = None
    telephone_no: Optional[str] = None
    fax_no: Optional[str] = None
    email: Optional[str] = None
    floors_total: Optional[int] = None
    units_total: Optional[int] = None
    operation_mode_other: Optional[str] = None
    is_rcsv: Optional[bool] = None
    rch_type_code: Optional[Literal["a1", "a2", "a3", "a4", "b1", "b2", "b3"]] = None
    complies_lease_dmc: Optional[bool] = None
    complies_lease_dmc_other: Optional[str] = None
    nursing_home_places: Optional[NonNegativeInt] = None
    care_and_attention_home_places: Optional[NonNegativeInt] = None
    aged_home_places: Optional[NonNegativeInt] = None
    self_care_hostel_places: Optional[NonNegativeInt] = None
    max_capacity: Optional[int] = None
    existing_capacity: Optional[int] = None
    enrolment_residents: Optional[int] = None
    premises: Optional[UpdatePremisesPayload] = None


class UpdatePublicNlaPart2Payload(UpdateNlaPart2Payload):
    gender: Optional[Literal["0", "1", "2"]] = None
    premises: Optional[NlaReplacementPremisesPayload] = None

    @field_validator("premises", mode="before")
    @classmethod
    def require_premises_object_when_supplied(cls, value: Any) -> Any:
        if value is None:
            raise ValueError(
                "Supply self_owned or rented as an array to replace that category"
            )
        return value


class UpdateNlaPart3Payload(ApiPayload):
    rch_business_status: Optional[EnumValue] = None
    applicant_operator_type: Optional[EnumValue] = None
    date_of_operation: Optional[date] = None
    signature_date: Optional[date] = None
    operator: Optional[UpdateContactPayload] = None
    company: Optional[UpdateContactPayload] = None
    personnel: Optional[list[UpdateContactPayload]] = None

    @model_validator(mode="after")
    def require_personnel_ids(self) -> UpdateNlaPart3Payload:
        if self.personnel is not None and any(
            person.id is None for person in self.personnel
        ):
            raise ValueError("Each personnel update must include id")
        return self


class UpdatePublicNlaPart3Payload(ApiPayload):
    rch_business_status: Optional[Literal["0", "1"]] = None
    applicant_operator_type: Optional[Literal["0", "1", "2", "3"]] = None
    date_of_operation: Optional[date] = None
    signature_date: Optional[date] = None
    operator: Optional[UpdateNlaContactPayload] = None
    company: Optional[UpdateNlaContactPayload] = None
    personnel: Optional[list[NlaReplacementPersonnelPayload]] = None

    @field_validator("personnel", mode="before")
    @classmethod
    def require_personnel_array_when_supplied(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("Use [] to clear supplied NLA personnel")
        return value


class UpdateNlaPart4Payload(ApiPayload):
    authorised_representative: Optional[UpdateContactPayload] = None


class UpdatePublicNlaPart4Payload(ApiPayload):
    authorised_representative: Optional[UpdateNlaContactPayload] = None


class UpdateNlaPart5Payload(ApiPayload):
    application_level: Optional[Literal["normal", "high"]] = None
    comments: Optional[str] = None
    other_information: Optional[str] = None
    remarks: Optional[str] = None
    attachment_ids: Optional[list[PositiveInt]] = None
    checklist: Optional[list[UpdateChecklistItemPayload]] = None


class UpdatePublicNlaPart5Payload(ApiPayload):
    application_level: Optional[Literal["normal", "high"]] = None
    checklist: Optional[list[UpdateChecklistItemPayload]] = None

    @field_validator("checklist", mode="before")
    @classmethod
    def require_checklist_array_when_supplied(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("Use [] to clear the supplied NLA checklist")
        return value

    @model_validator(mode="after")
    def require_distinct_checklist_positions(self) -> UpdatePublicNlaPart5Payload:
        if self.checklist is not None:
            codes = [item.position_code for item in self.checklist]
            if len(codes) != len(set(codes)):
                raise ValueError("NLA checklist position_code must be unique")
        return self


class UpdateNewLicenceFormData(ApiPayload):
    case_summary: Optional[UpdateNewLicenceCaseSummaryPayload] = None
    part_1: Optional[UpdateNlaPart1Payload] = None
    part_2: Optional[UpdatePublicNlaPart2Payload] = None
    part_3: Optional[UpdatePublicNlaPart3Payload] = None
    part_4: Optional[UpdatePublicNlaPart4Payload] = None
    part_5: Optional[UpdatePublicNlaPart5Payload] = None

    @field_validator(
        "case_summary", "part_1", "part_2", "part_3", "part_4", "part_5",
        mode="before",
    )
    @classmethod
    def require_section_object_when_supplied(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("Supply an object containing changed fields")
        return value

    def replacement_categories(self) -> tuple[str, ...]:
        """Report only child lists explicitly supplied by the client.

        An omitted category means preserve existing rows; an explicit empty
        array means clear that category. Pydantic defaults must not turn an
        omitted category into a replacement when serializing the request.
        """
        supplied: list[str] = []
        if self.part_3 is not None and "personnel" in self.part_3.model_fields_set:
            supplied.append("form_data.part_3.personnel")
        if self.part_2 is not None and self.part_2.premises is not None:
            premises = self.part_2.premises
            for category in ("self_owned", "rented"):
                if category in premises.model_fields_set:
                    supplied.append(f"form_data.part_2.premises.{category}")
        return tuple(supplied)

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateNewLicenceFormData:
        def has_change(value: Any) -> bool:
            if isinstance(value, dict):
                return any(has_change(item) for item in value.values())
            # An explicitly supplied scalar, null, or list (including an empty
            # personnel/premises array that clears that category) is a change.
            return True

        supplied = self.model_dump(exclude_unset=True)
        if not has_change(supplied):
            raise ValueError("form_data must contain at least one changed field")
        if self.case_summary is not None and supplied == {
            "case_summary": {"office_code": self.case_summary.office_code}
        }:
            raise ValueError(
                "form_data must contain a changed field besides office_code"
            )
        return self


class UpdateNewLicenceDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    # API Request Staging ID returned as create_id by the Create endpoint.
    create_id: ScalarId
    form_data: UpdateNewLicenceFormData


class ChangingHomeCaseSummaryPayload(CaseSummaryPayload):
    # Public RCH / P references. The adapter resolves these against
    # t_home_record.f_rch_no or t_home_record.f_final_o_no with office_code.
    lorche_d_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    rch_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    p_no: Optional[str] = Field(default=None, min_length=1, max_length=128)


class PublicHomeBoundCaseSummaryPayload(ApiPayload):
    """SH/RP client-owned Intake fields and Home Record lookup references."""

    office_code: Literal["LORCHE", "LORCHD"]
    rch_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    lorche_d_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    p_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    received_date: Optional[date] = None
    severity: Optional[EnumValue] = None


class ChangingHomeApiCaseSummaryPayload(ChangingHomeCaseSummaryPayload):
    """The CHI API Intake fields only; other BP models keep their contract."""

    rch_no: str = Field(min_length=1, max_length=128)
    severity: Optional[Literal["0", "1", "2"]] = None

    @model_validator(mode="after")
    def only_accept_visible_chi_intake_fields(
        self,
    ) -> ChangingHomeApiCaseSummaryPayload:
        # CHI's Source of Intake menu has no free-text Other input. Do not
        # acknowledge a field which its Intake form cannot display or save.
        if "source_other" in self.model_fields_set:
            raise ValueError("CHI case_summary.source_other is not supported")
        return self


ChangingHomeDeclarationKey = Literal["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]


class ChangingHomeOperatorPayload(UpdateContactPayload):
    # CHI resolves its own contact rows. A client must never select a native
    # child record by ID; overriding the inherited field also removes it from
    # the public request schema (including the company subclass).
    id: ClassVar[None] = None

    # The native CHI declaration questions apply to each ownership branch.
    declaration_answers: Optional[
        dict[ChangingHomeDeclarationKey, Literal["Yes", "No"]]
    ] = None

    @model_validator(mode="after")
    def require_declared_answer_values(self) -> ChangingHomeOperatorPayload:
        if (
            "declaration_answers" in self.model_fields_set
            and not self.declaration_answers
        ):
            raise ValueError(
                "declaration_answers must include at least one Yes/No answer"
            )
        return self


class ChangingHomeCompanyPayload(ChangingHomeOperatorPayload):
    # CHI corporate registration records are not NLA contacts.
    application_type: Optional[Literal["0", "1"]] = None
    registration_identifier_types: Optional[list[Literal["0", "1", "2"]]] = None
    legislation_chapter_no: Optional[str] = Field(default=None, min_length=1)

    @model_validator(mode="after")
    def require_distinct_registration_types(self) -> ChangingHomeCompanyPayload:
        if (
            "registration_identifier_types" in self.model_fields_set
            and self.registration_identifier_types is None
        ):
            raise ValueError("registration_identifier_types cannot be null")
        if (
            "legislation_chapter_no" in self.model_fields_set
            and self.legislation_chapter_no is None
        ):
            raise ValueError("legislation_chapter_no cannot be null")
        if self.registration_identifier_types is not None:
            values = self.registration_identifier_types
            if len(values) != 1:
                raise ValueError(
                    "registration_identifier_types must select exactly one type"
                )
            if len(values) != len(set(values)):
                raise ValueError("registration_identifier_types must be unique")
        return self


class ChangingHomePart3Payload(ApiPayload):
    rch_business_status: Optional[Literal["0", "1"]] = None
    applicant_operator_type: Optional[Literal["0", "1", "2", "3"]] = None
    operator: Optional[ChangingHomeOperatorPayload] = None
    # When supplied, this is the complete proposed natural-person list.
    # Omission leaves the current relation unchanged; [] explicitly clears it.
    operators: Optional[list[ChangingHomeOperatorPayload]] = Field(
        default=None, max_length=100
    )
    company: Optional[ChangingHomeCompanyPayload] = None


class ChangingHomePart2Payload(UpdateNlaPart2Payload):
    # The CHI "Maximum Capacity of Proposed New RCH" popup accepts a
    # positive integer. Do not change the NLA capacity contract.
    max_capacity: Optional[int] = Field(default=None, gt=0, strict=True)


CHI_CHANGE_FLAGS = (
    "is_change_name",
    "is_change_address",
    "is_change_operator_or_operating_company",
    "is_change_rch_type",
    "is_change_maximum_capacity",
)


def _validate_chi_rch_type_for_office(form: Any, office_code: str) -> None:
    part_2 = form.part_2
    if part_2 is None or part_2.rch_type_code is None:
        return
    valid_types = (
        {"a1", "a2", "a3", "a4"} if office_code == "LORCHE" else {"b1", "b2", "b3"}
    )
    if part_2.rch_type_code not in valid_types:
        raise ValueError(
            f"rch_type_code {part_2.rch_type_code} is not valid for {office_code}"
        )


def _validate_chi_change_sections(form: Any) -> None:
    """A selected CHI category must carry the corresponding NLA-shaped data."""
    for name in ("part_1", "part_2", "part_3", "part_4", "part_5"):
        if name in form.model_fields_set and getattr(form, name) is None:
            raise ValueError(f"CHI {name} cannot be null")
    part_2 = form.part_2
    part_3 = form.part_3
    supported_part_1 = {"application_received_date"}
    supported_part_2 = {
        "rch_name_en",
        "rch_name_cn",
        "address",
        "rch_type_code",
        "max_capacity",
    }
    if form.part_1 is not None:
        unsupported = form.part_1.model_fields_set - supported_part_1
        if unsupported:
            raise ValueError(
                "CHI part_1 contains unsupported fields: "
                + ", ".join(sorted(unsupported))
            )
    if part_2 is not None:
        unsupported = part_2.model_fields_set - supported_part_2
        if unsupported:
            raise ValueError(
                "CHI part_2 contains unsupported fields: "
                + ", ".join(sorted(unsupported))
            )
    if "part_4" in form.model_fields_set:
        raise ValueError("CHI part_4 is not supported in this version")
    if part_2 is not None:
        for name in ("rch_name_en", "rch_name_cn", "rch_type_code", "max_capacity"):
            if name in part_2.model_fields_set and getattr(part_2, name) is None:
                raise ValueError(f"CHI part_2.{name} cannot be null")
        for name in ("rch_name_en", "rch_name_cn"):
            value = getattr(part_2, name)
            if value is not None and not value.strip():
                raise ValueError(f"CHI part_2.{name} cannot be blank")
    if part_3 is not None:
        has_operator = part_3.operator is not None
        has_operators = "operators" in part_3.model_fields_set
        has_company = part_3.company is not None
        if has_operators and part_3.operators is None:
            raise ValueError("CHI part_3.operators cannot be null")
        if sum((has_operator, has_operators, has_company)) > 1:
            raise ValueError(
                "CHI part_3.operator, part_3.operators and part_3.company "
                "cannot be combined"
            )
        if has_operator or has_operators or has_company:
            operator_type = part_3.applicant_operator_type
            if operator_type is None:
                raise ValueError(
                    "CHI contact change requires part_3.applicant_operator_type"
                )
            if (has_operator or has_operators) and operator_type not in {"0", "1"}:
                raise ValueError(
                    "CHI personal operator requires applicant_operator_type 0 or 1"
                )
            if has_company and operator_type not in {"2", "3"}:
                raise ValueError("CHI company requires applicant_operator_type 2 or 3")
        operator_fields = {
            "id",
            "full_name_en",
            "full_name_cn",
            "hkid_part_1",
            "hkid_part_2",
            "hkid_part_3",
            "mobile_phone",
            "email",
            "declaration_answers",
        }
        company_fields = {
            "id",
            "company_name_en",
            "company_name_cn",
            "business_registration_no",
            "certificate_of_incorporation_no",
            "application_type",
            "registration_identifier_types",
            "legislation_chapter_no",
            "mobile_phone",
            "email",
            "declaration_answers",
        }
        for name, allowed in (
            ("operator", operator_fields),
            ("company", company_fields),
        ):
            contact = getattr(part_3, name)
            if name in part_3.model_fields_set and contact is None:
                raise ValueError(f"CHI part_3.{name} cannot be null")
            if contact is not None:
                unsupported = contact.model_fields_set - allowed
                if unsupported:
                    raise ValueError(
                        f"CHI part_3.{name} contains unsupported fields: "
                        + ", ".join(sorted(unsupported))
                    )
        if part_3.operators is not None:
            for index, contact in enumerate(part_3.operators):
                unsupported = contact.model_fields_set - operator_fields
                if unsupported:
                    raise ValueError(
                        f"CHI part_3.operators[{index}] contains unsupported fields: "
                        + ", ".join(sorted(unsupported))
                    )
                if not (contact.full_name_en or contact.full_name_cn):
                    raise ValueError(
                        f"CHI part_3.operators[{index}] requires full_name_en "
                        "or full_name_cn"
                    )
        for name in ("rch_business_status", "applicant_operator_type"):
            if name in part_3.model_fields_set and getattr(part_3, name) is None:
                raise ValueError(f"CHI part_3.{name} cannot be null")
    checks = (
        (
            "is_change_name",
            part_2 is not None
            and any(
                getattr(part_2, name) is not None
                for name in ("rch_name_en", "rch_name_cn")
            ),
            "part_2.rch_name_en or part_2.rch_name_cn",
        ),
        (
            "is_change_address",
            part_2 is not None
            and part_2.address is not None
            and bool(part_2.address.model_fields_set),
            "part_2.address",
        ),
        (
            "is_change_operator_or_operating_company",
            part_3 is not None
            and (
                bool(
                    part_3.model_fields_set
                    & {"rch_business_status", "applicant_operator_type"}
                )
                or "operators" in part_3.model_fields_set
                or any(
                    contact is not None and bool(contact.model_fields_set - {"id"})
                    for contact in (part_3.operator, part_3.company)
                )
            ),
            "part_3 business status, operator(s) or company",
        ),
        (
            "is_change_rch_type",
            part_2 is not None and part_2.rch_type_code is not None,
            "part_2.rch_type_code",
        ),
        (
            "is_change_maximum_capacity",
            part_2 is not None and part_2.max_capacity is not None,
            "part_2.max_capacity",
        ),
    )
    for flag, supplied, path in checks:
        if getattr(form, flag) is True and not supplied:
            raise ValueError(f"{flag}=true requires {path}")
    reverse = (
        (
            "is_change_name",
            part_2 is not None
            and bool(part_2.model_fields_set & {"rch_name_en", "rch_name_cn"}),
        ),
        (
            "is_change_address",
            part_2 is not None and "address" in part_2.model_fields_set,
        ),
        (
            "is_change_rch_type",
            part_2 is not None and "rch_type_code" in part_2.model_fields_set,
        ),
        (
            "is_change_maximum_capacity",
            part_2 is not None and "max_capacity" in part_2.model_fields_set,
        ),
        (
            "is_change_operator_or_operating_company",
            part_3 is not None
            and bool(
                part_3.model_fields_set
                & {
                    "rch_business_status",
                    "applicant_operator_type",
                    "operator",
                    "operators",
                    "company",
                }
            ),
        ),
    )
    for flag, supplied in reverse:
        if supplied and getattr(form, flag) is not True:
            raise ValueError(f"Changed CHI fields require {flag}=true")


class ChangingHomePart5Payload(UpdateNlaPart5Payload):
    # CHI Checklist assignment always means an uploaded file, not a bare code.
    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @model_validator(mode="after")
    def require_distinct_checklist_assignments(self) -> ChangingHomePart5Payload:
        unsupported = self.model_fields_set - {"checklist"}
        if unsupported:
            raise ValueError(
                "CHI part_5 contains unsupported fields: "
                + ", ".join(sorted(unsupported))
            )
        if not self.model_fields_set:
            raise ValueError("CHI part_5 requires checklist assignments")
        if "checklist" in self.model_fields_set and self.checklist is None:
            raise ValueError("CHI part_5.checklist cannot be null")
        if self.checklist is not None:
            if not self.checklist:
                raise ValueError("CHI checklist must contain at least one assignment")
            codes = [item.position_code for item in self.checklist]
            if len(codes) != len(set(codes)):
                raise ValueError("CHI checklist position_code must be unique")
        return self


class ChangingHomeFormData(ApiPayload):
    case_summary: ChangingHomeApiCaseSummaryPayload
    is_change_name: StrictBool = False
    is_change_address: StrictBool = False
    is_change_operator_or_operating_company: StrictBool = False
    is_change_rch_type: StrictBool = False
    is_change_maximum_capacity: StrictBool = False
    # CHI starts from the Home Record snapshot. Only supplied sections replace
    # values in that snapshot, so the NLA-shaped sections are partial.
    part_1: Optional[UpdateNlaPart1Payload] = None
    part_2: Optional[ChangingHomePart2Payload] = None
    part_3: Optional[ChangingHomePart3Payload] = None
    part_4: Optional[UpdateNlaPart4Payload] = None
    part_5: Optional[ChangingHomePart5Payload] = None

    @model_validator(mode="after")
    def require_a_change_category(self) -> ChangingHomeFormData:
        if not any(
            (
                self.is_change_name,
                self.is_change_address,
                self.is_change_operator_or_operating_company,
                self.is_change_rch_type,
                self.is_change_maximum_capacity,
            )
        ):
            raise ValueError("At least one CHI change category must be selected")
        _validate_chi_change_sections(self)
        _validate_chi_rch_type_for_office(self, self.case_summary.office_code)
        return self


class CreateIntakeForChangingHomeRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ChangingHomeFormData


class UpdateChangingHomeCaseSummaryPayload(UpdateCaseSummaryPayload):
    lorche_d_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    rch_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    p_no: Optional[str] = Field(default=None, min_length=1, max_length=128)

    @model_validator(mode="after")
    def require_office_with_home_reference(
        self,
    ) -> UpdateChangingHomeCaseSummaryPayload:
        # The CHI UPDATE workflow only projects proposed application/page
        # fields. Repeated Intake metadata here would be accepted by the
        # inherited NLA model but silently ignored by the CHI workflow.
        allowed = {
            "office_code",
            "rch_no",
            "lorche_d_no",
            "p_no",
        }
        unsupported = self.model_fields_set - allowed
        if unsupported:
            raise ValueError(
                "CHI Update case_summary contains unsupported fields: "
                + ", ".join(sorted(unsupported))
            )
        has_office = self.office_code is not None
        has_home_ref = any(
            value is not None for value in (self.rch_no, self.lorche_d_no, self.p_no)
        )
        if has_office != has_home_ref:
            raise ValueError(
                "office_code must be provided together with rch_no or p_no"
            )
        return self


class UpdateHomeBoundCaseSummaryPayload(UpdateCaseSummaryPayload):
    """Partial Intake metadata plus immutable Home Record lookup keys.

    Closure, Specific Hour and Responsible Person Updates keep the same
    ``case_summary`` shape as Create, but every field is optional.  The
    adapter uses the Home Record fields only to verify the original Create;
    the remaining supplied fields are projected to the linked Intake.
    """

    lorche_d_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    rch_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    p_no: Optional[str] = Field(default=None, min_length=1, max_length=128)

    @model_validator(mode="after")
    def require_office_with_home_reference(
        self,
    ) -> UpdateHomeBoundCaseSummaryPayload:
        has_office = self.office_code is not None
        has_home_ref = any(
            value is not None for value in (self.rch_no, self.lorche_d_no, self.p_no)
        )
        if has_home_ref and not has_office:
            raise ValueError(
                "office_code must be provided together with rch_no or p_no"
            )
        return self


class UpdatePublicHomeBoundCaseSummaryPayload(ApiPayload):
    """SH/RP Update fields without CMTF-II personnel or source metadata."""

    office_code: Optional[Literal["LORCHE", "LORCHD"]] = None
    rch_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    lorche_d_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    p_no: Optional[str] = Field(default=None, min_length=1, max_length=128)
    received_date: Optional[date] = None
    severity: Optional[EnumValue] = None

    @model_validator(mode="after")
    def require_office_with_home_reference(
        self,
    ) -> UpdatePublicHomeBoundCaseSummaryPayload:
        has_office = self.office_code is not None
        has_home_ref = any(
            value is not None for value in (self.rch_no, self.lorche_d_no, self.p_no)
        )
        if has_home_ref and not has_office:
            raise ValueError(
                "office_code must be provided together with rch_no or p_no"
            )
        return self


HOME_BOUND_IDENTITY_FIELDS = {
    "office_code",
    "rch_no",
    "lorche_d_no",
    "p_no",
}


def _only_home_bound_identity(summary: object) -> bool:
    if not isinstance(
        summary,
        (UpdateHomeBoundCaseSummaryPayload, UpdatePublicHomeBoundCaseSummaryPayload),
    ):
        return False
    return bool(summary.model_fields_set) and summary.model_fields_set <= (
        HOME_BOUND_IDENTITY_FIELDS
    )


class UpdateChangingHomeFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    is_change_name: Optional[StrictBool] = None
    is_change_address: Optional[StrictBool] = None
    is_change_operator_or_operating_company: Optional[StrictBool] = None
    is_change_rch_type: Optional[StrictBool] = None
    is_change_maximum_capacity: Optional[StrictBool] = None
    part_1: Optional[UpdateNlaPart1Payload] = None
    part_2: Optional[ChangingHomePart2Payload] = None
    part_3: Optional[ChangingHomePart3Payload] = None
    part_4: Optional[UpdateNlaPart4Payload] = None
    part_5: Optional[ChangingHomePart5Payload] = None

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateChangingHomeFormData:
        def has_change(value: Any) -> bool:
            if isinstance(value, dict):
                return any(has_change(item) for item in value.values())
            # A supplied scalar or null is an intentional replacement/clear.
            # An empty list can clear an attachment relation when supported.
            return True

        supplied = self.model_dump(exclude_unset=True)
        for flag in CHI_CHANGE_FLAGS:
            if flag in self.model_fields_set and getattr(self, flag) is not True:
                raise ValueError(f"Update {flag} must be true when supplied")
        if "case_summary" in self.model_fields_set and self.case_summary is None:
            raise ValueError("Update case_summary cannot be null")
        if not has_change(supplied):
            raise ValueError("form_data must contain at least one changed field")
        # Home identity values are repeated for validation, not a business
        # change. They must not produce an Accepted no-op UPDATE on their own.
        if set(supplied) == {"case_summary"} and set(supplied["case_summary"]) <= {
            "office_code",
            "rch_no",
            "lorche_d_no",
            "p_no",
        }:
            raise ValueError("form_data must contain a proposed CHI change")
        _validate_chi_change_sections(self)
        return self


class UpdateChangingHomeDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateChangingHomeFormData


class SelfWithdrawFormData(ApiPayload):
    case_summary: ChangingHomeCaseSummaryPayload
    applicant_title: Literal["0", "1", "2", "3"]
    applicant_name_en: str = Field(min_length=1)
    applicant_name_cn: Optional[str] = None
    applicant_position: Optional[str] = None
    means_of_authorisation: Literal["0", "1"]
    tentative_date_of_closure: date
    reason_for_closure: Literal["0", "1", "others"]
    reason_for_closure_others: Optional[str] = None
    checklist: list[ChecklistItemPayload] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def validate_closure_create(self) -> SelfWithdrawFormData:
        if self.case_summary.received_date is None:
            raise ValueError("case_summary.received_date is required")
        if (
            self.reason_for_closure == "others"
            and not (self.reason_for_closure_others or "").strip()
        ):
            raise ValueError(
                "reason_for_closure_others is required when "
                "reason_for_closure is others"
            )
        codes = [item.position_code for item in self.checklist]
        if len(codes) != len(set(codes)):
            raise ValueError("checklist position_code must be unique")
        return self


class CreateIntakeForSelfWithdrawRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: SelfWithdrawFormData


class UpdateSelfWithdrawFormData(ApiPayload):
    case_summary: Optional[UpdateHomeBoundCaseSummaryPayload] = None
    applicant_title: Optional[Literal["0", "1", "2", "3"]] = None
    applicant_name_en: Optional[str] = None
    applicant_name_cn: Optional[str] = None
    applicant_position: Optional[str] = None
    means_of_authorisation: Optional[Literal["0", "1"]] = None
    tentative_date_of_closure: Optional[date] = None
    reason_for_closure: Optional[Literal["0", "1", "others"]] = None
    reason_for_closure_others: Optional[str] = None
    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateSelfWithdrawFormData:
        if not self.model_dump(exclude_unset=True):
            raise ValueError("form_data must contain at least one changed field")
        if "case_summary" in self.model_fields_set and self.case_summary is None:
            raise ValueError("case_summary cannot be null")
        if set(self.model_fields_set) == {"case_summary"} and _only_home_bound_identity(
            self.case_summary
        ):
            raise ValueError("form_data must contain a business or Intake change")
        if (
            self.reason_for_closure == "others"
            and not (self.reason_for_closure_others or "").strip()
        ):
            raise ValueError(
                "reason_for_closure_others is required when "
                "reason_for_closure is others"
            )
        if self.checklist is not None:
            codes = [item.position_code for item in self.checklist]
            if len(codes) != len(set(codes)):
                raise ValueError("checklist position_code must be unique")
        return self


class UpdateSelfWithdrawDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateSelfWithdrawFormData


class RevokeLicenceFormData(SelfWithdrawFormData):
    """Revoke uses the shared Closure application data contract."""


class CreateIntakeForRevokeLicenceRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: Optional[ScalarId] = None
    form_data: RevokeLicenceFormData


class UpdateRevokeLicenceFormData(UpdateSelfWithdrawFormData):
    """Revoke Update uses the shared Closure application data contract."""


class UpdateRevokeLicenceDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateRevokeLicenceFormData


class SpecificHourTimeRowPayload(ApiPayload):
    work_hour_from: time
    work_hour_to: time
    remark: Optional[str] = None

    @model_validator(mode="after")
    def require_non_zero_period(self) -> SpecificHourTimeRowPayload:
        if self.work_hour_from == self.work_hour_to:
            raise ValueError("work_hour_from and work_hour_to cannot be equal")
        return self


class SpecificHourStaffingPayload(ApiPayload):
    staff_type_code: str = Field(pattern=r"^[A-Za-z0-9_()-]{1,64}$")
    other_duties: Optional[str] = None
    time_rows: list[SpecificHourTimeRowPayload] = Field(min_length=1, max_length=48)


class SpecificHourOptionPayload(ApiPayload):
    set_no: Literal["0", "1", "2", "3"]
    section: Literal[
        "workday_and_holiday",
        "exclude_holiday",
        "only_holiday",
        "school_holiday",
        "others",
    ]
    section_other: Optional[str] = None
    staffings: list[SpecificHourStaffingPayload] = Field(min_length=1, max_length=16)

    @model_validator(mode="after")
    def validate_option(self) -> SpecificHourOptionPayload:
        if self.section == "others" and not (self.section_other or "").strip():
            raise ValueError("section_other is required when section is others")
        codes = [item.staff_type_code.upper() for item in self.staffings]
        if len(codes) != len(set(codes)):
            raise ValueError("staff_type_code must be unique within each set")
        return self


MAX_SPECIFIC_HOUR_TIME_ROWS = 256


def _validate_specific_hour_options(
    *, set_count: str, options: list[SpecificHourOptionPayload]
) -> None:
    expected_count = int(set_count) + 1
    if len(options) != expected_count:
        raise ValueError(
            "specific_hour_options count must equal specific_hour_set_count + 1"
        )
    actual = sorted(int(item.set_no) for item in options)
    if actual != list(range(expected_count)):
        raise ValueError("specific_hour_options set_no must be unique and contiguous")
    total_time_rows = sum(
        len(staffing.time_rows)
        for option in options
        for staffing in option.staffings
    )
    if total_time_rows > MAX_SPECIFIC_HOUR_TIME_ROWS:
        raise ValueError(
            "specific_hour_options may contain at most "
            f"{MAX_SPECIFIC_HOUR_TIME_ROWS} time rows per request"
        )


class SpecificHourFormData(ApiPayload):
    case_summary: PublicHomeBoundCaseSummaryPayload
    application_detail: Literal["approval", "changing"]
    applicant_title: Literal["Mr", "Mrs", "Miss", "Ms"]
    applicant_name_en: str = Field(min_length=1)
    applicant_name_cn: Optional[str] = None
    authorisation_method: Literal["digital", "written"]
    authorised_to_apply: StrictBool
    certificate_name_en: str = Field(min_length=1)
    # Kept for compatibility only. Staffing rules are selected from the
    # resolved Home Record's type; clients cannot override that decision.
    rch_care_level: Optional[Literal["0", "1", "2"]] = None
    tentative_commencement_date: Optional[date] = None
    tentative_effective_date: Optional[date] = None
    specific_hour_set_count: Literal["0", "1", "2", "3"]
    specific_hour_options: list[SpecificHourOptionPayload] = Field(
        min_length=1, max_length=4
    )
    declaration_acknowledged: StrictBool
    warning_acknowledged: StrictBool
    declared_at: date
    checklist: list[ChecklistItemPayload] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def validate_specific_hour_create(self) -> SpecificHourFormData:
        if self.case_summary.received_date is None:
            raise ValueError("case_summary.received_date is required")
        if (
            self.tentative_commencement_date is None
            and self.tentative_effective_date is None
        ):
            raise ValueError(
                "tentative_commencement_date or tentative_effective_date is required"
            )
        if not self.authorised_to_apply:
            raise ValueError("authorised_to_apply must be true")
        if not self.declaration_acknowledged:
            raise ValueError("declaration_acknowledged must be true")
        if not self.warning_acknowledged:
            raise ValueError("warning_acknowledged must be true")
        _validate_specific_hour_options(
            set_count=self.specific_hour_set_count,
            options=self.specific_hour_options,
        )
        codes = [item.position_code for item in self.checklist]
        if len(codes) != len(set(codes)):
            raise ValueError("checklist position_code must be unique")
        return self


class CreateIntakeForSpecificHourRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: SpecificHourFormData


class UpdateSpecificHourFormData(ApiPayload):
    case_summary: Optional[UpdatePublicHomeBoundCaseSummaryPayload] = None
    application_detail: Optional[Literal["approval", "changing"]] = None
    applicant_title: Optional[Literal["Mr", "Mrs", "Miss", "Ms"]] = None
    applicant_name_en: Optional[str] = None
    applicant_name_cn: Optional[str] = None
    authorisation_method: Optional[Literal["digital", "written"]] = None
    authorised_to_apply: Optional[bool] = None
    certificate_name_en: Optional[str] = None
    rch_care_level: Optional[Literal["0", "1", "2"]] = None
    tentative_commencement_date: Optional[date] = None
    tentative_effective_date: Optional[date] = None
    specific_hour_set_count: Optional[Literal["0", "1", "2", "3"]] = None
    specific_hour_options: Optional[list[SpecificHourOptionPayload]] = Field(
        default=None, min_length=1, max_length=4
    )
    declaration_acknowledged: Optional[bool] = None
    warning_acknowledged: Optional[bool] = None
    declared_at: Optional[date] = None
    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateSpecificHourFormData:
        if not self.model_dump(exclude_unset=True):
            raise ValueError("form_data must contain at least one changed field")
        if "case_summary" in self.model_fields_set and self.case_summary is None:
            raise ValueError("case_summary cannot be null")
        if set(self.model_fields_set) == {"case_summary"} and _only_home_bound_identity(
            self.case_summary
        ):
            raise ValueError("form_data must contain a business or Intake change")
        if (self.specific_hour_set_count is None) != (
            self.specific_hour_options is None
        ):
            raise ValueError(
                "specific_hour_set_count and specific_hour_options must be "
                "supplied together"
            )
        if self.specific_hour_options is not None:
            _validate_specific_hour_options(
                set_count=self.specific_hour_set_count or "0",
                options=self.specific_hour_options,
            )
        if self.authorised_to_apply is False:
            raise ValueError("authorised_to_apply cannot be false")
        if self.declaration_acknowledged is False:
            raise ValueError("declaration_acknowledged cannot be false")
        if self.warning_acknowledged is False:
            raise ValueError("warning_acknowledged cannot be false")
        if self.checklist is not None:
            codes = [item.position_code for item in self.checklist]
            if len(codes) != len(set(codes)):
                raise ValueError("checklist position_code must be unique")
        return self


class UpdateSpecificHourDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateSpecificHourFormData


class RpCurrentlyAppointedHomePayload(ApiPayload):
    rch_no: str = Field(min_length=1, max_length=128)
    rch_name: str = Field(min_length=1)


class RpLegalQuestionPayload(ApiPayload):
    answer: Literal["yes", "no"]
    case_status: Optional[
        Literal["being_prosecuted_currently", "has_been_convicted"]
    ] = None
    prosecuting_authority: Optional[str] = None
    place_of_proceeding: Optional[str] = None
    offence_involved: Optional[str] = None
    hearing_date: Optional[date] = None
    court: Optional[str] = None
    place_of_court: Optional[str] = None
    offence_committed: Optional[str] = None
    penalty: Optional[str] = None
    conviction_date: Optional[date] = None

    @model_validator(mode="after")
    def validate_yes_branch(self) -> RpLegalQuestionPayload:
        if self.answer == "no":
            return self
        if self.case_status is None:
            raise ValueError("case_status is required when answer is yes")
        if self.case_status == "being_prosecuted_currently":
            required = (
                "prosecuting_authority",
                "offence_involved",
                "hearing_date",
            )
        else:
            required = ("court", "offence_committed", "penalty", "conviction_date")
        missing = [name for name in required if getattr(self, name) in (None, "")]
        if missing:
            raise ValueError(
                "The selected legal case branch requires: " + ", ".join(missing)
            )
        return self


class RpQ5Payload(ApiPayload):
    answer: Literal["yes", "no"]
    date: Optional[dt.date] = None
    rch_no_and_name: Optional[str] = None
    reasons: Optional[str] = None

    @model_validator(mode="after")
    def validate_yes_branch(self) -> RpQ5Payload:
        if self.answer == "yes" and any(
            value in (None, "")
            for value in (self.date, self.rch_no_and_name, self.reasons)
        ):
            raise ValueError(
                "Q5 date, rch_no_and_name and reasons are required when answer is yes"
            )
        return self


class RpQ6Payload(ApiPayload):
    answer: Literal["yes", "no"]
    adjudication_date: Optional[date] = None
    court: Optional[str] = None

    @model_validator(mode="after")
    def validate_yes_branch(self) -> RpQ6Payload:
        if self.answer == "yes" and (
            self.adjudication_date is None or not (self.court or "").strip()
        ):
            raise ValueError(
                "Q6 adjudication_date and court are required when answer is yes"
            )
        return self


class RpQ7Payload(ApiPayload):
    answer: Literal["yes", "no"]
    adjudication_date: Optional[date] = None
    repayment_proposal: Optional[str] = None

    @model_validator(mode="after")
    def validate_yes_branch(self) -> RpQ7Payload:
        if self.answer == "yes" and (
            self.adjudication_date is None
            or not (self.repayment_proposal or "").strip()
        ):
            raise ValueError("Q7 adjudication_date and repayment_proposal are required")
        return self


class RpQ8Payload(ApiPayload):
    answer: Literal["yes", "no"]
    company_name_en: Optional[str] = None
    company_name_cn: Optional[str] = None
    business_registration_no: Optional[str] = None
    certificate_of_incorporation_no: Optional[str] = None
    registered_address: Optional[str] = None
    adjudication_date: Optional[date] = None
    court: Optional[str] = None

    @model_validator(mode="after")
    def validate_yes_branch(self) -> RpQ8Payload:
        required = (
            self.company_name_en,
            self.business_registration_no,
            self.certificate_of_incorporation_no,
            self.registered_address,
            self.adjudication_date,
            self.court,
        )
        if self.answer == "yes" and any(value in (None, "") for value in required):
            raise ValueError("Q8 company and adjudication details are required")
        return self


class RpOtherParticularsPayload(ApiPayload):
    q1: RpLegalQuestionPayload
    q2: RpLegalQuestionPayload
    q3: RpLegalQuestionPayload
    q4: RpLegalQuestionPayload
    q5: RpQ5Payload
    q6: RpQ6Payload
    q7: RpQ7Payload
    q8: RpQ8Payload

    @model_validator(mode="after")
    def reject_non_page_q2_q4_place_fields(self) -> RpOtherParticularsPayload:
        for question_name in ("q2", "q4"):
            question = getattr(self, question_name)
            unsupported = {
                "place_of_proceeding",
                "place_of_court",
            } & question.model_fields_set
            if unsupported:
                raise ValueError(
                    f"{question_name} does not support: "
                    + ", ".join(sorted(unsupported))
                )
        return self


class RpDeclarationPayload(ApiPayload):
    acknowledged: StrictBool
    signature_date_of_rp: date
    signature_date_of_applicant_representative_partner: date

    @model_validator(mode="after")
    def require_acknowledgements(self) -> RpDeclarationPayload:
        if not self.acknowledged:
            raise ValueError("declaration.acknowledged must be true")
        return self


class UpdateRpLegalQuestionPayload(ApiPayload):
    answer: Optional[Literal["yes", "no"]] = None
    case_status: Optional[
        Literal["being_prosecuted_currently", "has_been_convicted"]
    ] = None
    prosecuting_authority: Optional[str] = None
    place_of_proceeding: Optional[str] = None
    offence_involved: Optional[str] = None
    hearing_date: Optional[date] = None
    court: Optional[str] = None
    place_of_court: Optional[str] = None
    offence_committed: Optional[str] = None
    penalty: Optional[str] = None
    conviction_date: Optional[date] = None

    @model_validator(mode="after")
    def require_a_changed_field(self) -> UpdateRpLegalQuestionPayload:
        if not self.model_fields_set:
            raise ValueError("RP question update must contain a changed field")
        return self


class UpdateRpQ5Payload(ApiPayload):
    answer: Optional[Literal["yes", "no"]] = None
    date: Optional[dt.date] = None
    rch_no_and_name: Optional[str] = None
    reasons: Optional[str] = None

    @model_validator(mode="after")
    def require_a_changed_field(self) -> UpdateRpQ5Payload:
        if not self.model_fields_set:
            raise ValueError("RP Q5 update must contain a changed field")
        return self


class UpdateRpQ6Payload(ApiPayload):
    answer: Optional[Literal["yes", "no"]] = None
    adjudication_date: Optional[date] = None
    court: Optional[str] = None

    @model_validator(mode="after")
    def require_a_changed_field(self) -> UpdateRpQ6Payload:
        if not self.model_fields_set:
            raise ValueError("RP Q6 update must contain a changed field")
        return self


class UpdateRpQ7Payload(ApiPayload):
    answer: Optional[Literal["yes", "no"]] = None
    adjudication_date: Optional[date] = None
    repayment_proposal: Optional[str] = None

    @model_validator(mode="after")
    def require_a_changed_field(self) -> UpdateRpQ7Payload:
        if not self.model_fields_set:
            raise ValueError("RP Q7 update must contain a changed field")
        return self


class UpdateRpQ8Payload(ApiPayload):
    answer: Optional[Literal["yes", "no"]] = None
    company_name_en: Optional[str] = None
    company_name_cn: Optional[str] = None
    business_registration_no: Optional[str] = None
    certificate_of_incorporation_no: Optional[str] = None
    registered_address: Optional[str] = None
    adjudication_date: Optional[date] = None
    court: Optional[str] = None

    @model_validator(mode="after")
    def require_a_changed_field(self) -> UpdateRpQ8Payload:
        if not self.model_fields_set:
            raise ValueError("RP Q8 update must contain a changed field")
        return self


class UpdateRpOtherParticularsPayload(ApiPayload):
    q1: Optional[UpdateRpLegalQuestionPayload] = None
    q2: Optional[UpdateRpLegalQuestionPayload] = None
    q3: Optional[UpdateRpLegalQuestionPayload] = None
    q4: Optional[UpdateRpLegalQuestionPayload] = None
    q5: Optional[UpdateRpQ5Payload] = None
    q6: Optional[UpdateRpQ6Payload] = None
    q7: Optional[UpdateRpQ7Payload] = None
    q8: Optional[UpdateRpQ8Payload] = None

    @model_validator(mode="after")
    def require_a_changed_question(self) -> UpdateRpOtherParticularsPayload:
        if not self.model_fields_set:
            raise ValueError("other_particulars must contain a changed question")
        for question_name in ("q2", "q4"):
            question = getattr(self, question_name)
            if question is None:
                continue
            unsupported = {
                "place_of_proceeding",
                "place_of_court",
            } & question.model_fields_set
            if unsupported:
                raise ValueError(
                    f"{question_name} does not support: "
                    + ", ".join(sorted(unsupported))
                )
        return self


class UpdateRpDeclarationPayload(ApiPayload):
    acknowledged: Optional[StrictBool] = None
    signature_date_of_rp: Optional[date] = None
    signature_date_of_applicant_representative_partner: Optional[date] = None

    @model_validator(mode="after")
    def require_a_changed_field(self) -> UpdateRpDeclarationPayload:
        if not self.model_fields_set:
            raise ValueError("declaration must contain a changed field")
        if self.acknowledged is False:
            raise ValueError("declaration.acknowledged cannot be false")
        return self


class ResponsiblePersonFormData(ApiPayload):
    case_summary: PublicHomeBoundCaseSummaryPayload
    rp_title: Literal["mr", "mrs", "ms", "dr"]
    rp_name_en: str = Field(min_length=1)
    rp_name_cn: Optional[str] = None
    rp_hkid: Optional[str] = None
    rp_hkid_no_1: Optional[str] = None
    rp_hkid_no_2: Optional[str] = None
    rp_hkid_no_3: Optional[str] = None
    rp_tel: str = Field(min_length=1)
    rp_email: str = Field(min_length=3)
    rp_address_en: str = Field(min_length=1)
    rp_address_cn: str = Field(min_length=1)
    rp_position_type: Literal[
        "sole_proprietorship",
        "partnership",
        "dody_corporate",
        "non_governmental_rganisation",
        "rche/rche（nh）",
    ]
    rp_other_home: Literal["no", "yes"]
    currently_appointed_homes: list[RpCurrentlyAppointedHomePayload] = Field(
        default_factory=list, max_length=100
    )
    rp_application_type: Literal["section_8", "section_9", "section_12", "section_13"]
    change_reason: Literal[
        "DSW_change",
        "deceased",
        "mental_physical_incapacity",
        "ceased_officer",
        "written_notice",
        "others",
    ]
    change_reason_other: Optional[str] = None
    ceased_status: Literal["has_ceased", "will_cease"]
    cease_position_date: date
    new_rp_assume_office_date: date
    notice_expected_issued_date: date
    authorised_rep_position: str = Field(min_length=1)
    other_particulars: RpOtherParticularsPayload
    declaration: RpDeclarationPayload
    checklist: list[ChecklistItemPayload] = Field(default_factory=list, max_length=100)

    @field_validator("rp_email")
    @classmethod
    def validate_rp_email(cls, value: str) -> str:
        validated = _validate_business_email(value)
        if validated is None:  # pragma: no cover - create field is required
            raise ValueError("must be a valid routable email address")
        return validated

    @model_validator(mode="after")
    def validate_rp_create(self) -> ResponsiblePersonFormData:
        if self.case_summary.received_date is None:
            raise ValueError("case_summary.received_date is required")
        if (
            self.change_reason == "others"
            and not (self.change_reason_other or "").strip()
        ):
            raise ValueError(
                "change_reason_other is required when change_reason is others"
            )
        if self.rp_other_home == "yes" and not self.currently_appointed_homes:
            raise ValueError(
                "currently_appointed_homes is required when rp_other_home is yes"
            )
        if self.rp_other_home == "no" and self.currently_appointed_homes:
            raise ValueError(
                "currently_appointed_homes must be empty when rp_other_home is no"
            )
        codes = [item.position_code for item in self.checklist]
        if len(codes) != len(set(codes)):
            raise ValueError("checklist position_code must be unique")
        return self


class CreateIntakeForRpRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ResponsiblePersonFormData


class UpdateResponsiblePersonFormData(ApiPayload):
    case_summary: Optional[UpdatePublicHomeBoundCaseSummaryPayload] = None
    rp_title: Optional[Literal["mr", "mrs", "ms", "dr"]] = None
    rp_name_en: Optional[str] = None
    rp_name_cn: Optional[str] = None
    rp_hkid: Optional[str] = None
    rp_hkid_no_1: Optional[str] = None
    rp_hkid_no_2: Optional[str] = None
    rp_hkid_no_3: Optional[str] = None
    rp_tel: Optional[str] = None
    rp_email: Optional[str] = None
    rp_address_en: Optional[str] = None
    rp_address_cn: Optional[str] = None
    rp_position_type: Optional[
        Literal[
            "sole_proprietorship",
            "partnership",
            "dody_corporate",
            "non_governmental_rganisation",
            "rche/rche（nh）",
        ]
    ] = None
    rp_other_home: Optional[Literal["no", "yes"]] = None
    currently_appointed_homes: Optional[list[RpCurrentlyAppointedHomePayload]] = Field(
        default=None, max_length=100
    )
    rp_application_type: Optional[
        Literal["section_8", "section_9", "section_12", "section_13"]
    ] = None
    change_reason: Optional[
        Literal[
            "DSW_change",
            "deceased",
            "mental_physical_incapacity",
            "ceased_officer",
            "written_notice",
            "others",
        ]
    ] = None
    change_reason_other: Optional[str] = None
    ceased_status: Optional[Literal["has_ceased", "will_cease"]] = None
    cease_position_date: Optional[date] = None
    new_rp_assume_office_date: Optional[date] = None
    notice_expected_issued_date: Optional[date] = None
    authorised_rep_position: Optional[str] = None
    other_particulars: Optional[UpdateRpOtherParticularsPayload] = None
    declaration: Optional[UpdateRpDeclarationPayload] = None
    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @field_validator("rp_email")
    @classmethod
    def validate_rp_email(cls, value: Optional[str]) -> Optional[str]:
        return _validate_business_email(value)

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateResponsiblePersonFormData:
        if not self.model_dump(exclude_unset=True):
            raise ValueError("form_data must contain at least one changed field")
        if "case_summary" in self.model_fields_set and self.case_summary is None:
            raise ValueError("case_summary cannot be null")
        if set(self.model_fields_set) == {"case_summary"} and _only_home_bound_identity(
            self.case_summary
        ):
            raise ValueError("form_data must contain a business or Intake change")
        if (
            self.change_reason == "others"
            and not (self.change_reason_other or "").strip()
        ):
            raise ValueError(
                "change_reason_other is required when change_reason is others"
            )
        other_home_supplied = "rp_other_home" in self.model_fields_set
        homes_supplied = "currently_appointed_homes" in self.model_fields_set
        if other_home_supplied != homes_supplied:
            raise ValueError(
                "rp_other_home and currently_appointed_homes must be supplied "
                "together"
            )
        if other_home_supplied:
            if self.rp_other_home == "yes" and not self.currently_appointed_homes:
                raise ValueError(
                    "currently_appointed_homes is required when rp_other_home is yes"
                )
            if self.rp_other_home == "no" and self.currently_appointed_homes != []:
                raise ValueError(
                    "currently_appointed_homes must be an empty array when "
                    "rp_other_home is no"
                )
        if self.checklist is not None:
            codes = [item.position_code for item in self.checklist]
            if len(codes) != len(set(codes)):
                raise ValueError("checklist position_code must be unique")
        return self


class UpdateRpDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateResponsiblePersonFormData


class ChangeMonitoringCommonFormData(ApiPayload):
    case_summary: ChangingHomeCaseSummaryPayload
    proposed_effective_date: Optional[date] = None


class ChangeHomeManagerFormData(ChangeMonitoringCommonFormData):
    proposed_name: Optional[str] = None
    proposed_tel: Optional[str] = None
    proposed_email: Optional[str] = None
    proposed_post: Optional[str] = None
    proposed_remark: Optional[str] = None

    @field_validator("proposed_email")
    @classmethod
    def validate_proposed_email(cls, value: Optional[str]) -> Optional[str]:
        return _validate_business_email(value)

    @model_validator(mode="after")
    def require_manager_change(self) -> ChangeHomeManagerFormData:
        business_fields = {
            "proposed_name",
            "proposed_tel",
            "proposed_email",
            "proposed_post",
            "proposed_remark",
            "proposed_effective_date",
        }
        if not (self.model_fields_set & business_fields):
            raise ValueError(
                "form_data must contain at least one Home Manager change"
            )
        return self


class CreateIntakeForChangeHomeManagerRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ChangeHomeManagerFormData


class UpdateChangeHomeManagerFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    proposed_effective_date: Optional[date] = None
    proposed_name: Optional[str] = None
    proposed_tel: Optional[str] = None
    proposed_email: Optional[str] = None
    proposed_post: Optional[str] = None
    proposed_remark: Optional[str] = None

    @field_validator("proposed_email")
    @classmethod
    def validate_proposed_email(cls, value: Optional[str]) -> Optional[str]:
        return _validate_business_email(value)

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateChangeHomeManagerFormData:
        if not (self.model_fields_set - {"case_summary"}):
            raise ValueError("form_data must contain a proposed Home Manager change")
        return self


class UpdateChangeHomeManagerDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateChangeHomeManagerFormData


class ChangeBedsFormData(ChangeMonitoringCommonFormData):
    # These four inputs are marked mandatory on the live Change of No. of
    # Beds page.  The native formula derives the proposed bed total.
    proposed_beds_self_care: NonNegativeInt
    proposed_beds_meal: NonNegativeInt
    proposed_beds_nursing: NonNegativeInt
    proposed_beds_care_and_attention: NonNegativeInt
    proposed_residents_total_ab: NonNegativeInt
    proposed_residents_total_a: NonNegativeInt
    proposed_residents_total_b: NonNegativeInt
    proposed_residents_self_care: NonNegativeInt
    proposed_residents_meal: NonNegativeInt
    proposed_residents_nursing: NonNegativeInt
    proposed_residents_care_and_attention: NonNegativeInt
    proposed_residents_nursing_beyond: NonNegativeInt
    proposed_residents_nonelderly_mental: NonNegativeInt
    proposed_residents_nonelderly_intellectual: NonNegativeInt
    proposed_residents_nonelderly_physical: NonNegativeInt
    proposed_residents_nonelderly_others: NonNegativeInt
    proposed_residents_nonelderly_others_specify: Optional[str] = None
    proposed_residents_nonelderly_other_details_num: NonNegativeInt

    @model_validator(mode="after")
    def validate_others_details(self) -> ChangeBedsFormData:
        if (
            self.proposed_residents_nonelderly_others > 0
            or self.proposed_residents_nonelderly_other_details_num > 0
        ) and not (self.proposed_residents_nonelderly_others_specify or "").strip():
            raise ValueError(
                "proposed_residents_nonelderly_others_specify is required "
                "when an Others count is greater than zero"
            )
        return self


class CreateIntakeForChangeBedsRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ChangeBedsFormData


class UpdateChangeBedsFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    proposed_effective_date: Optional[date] = None
    proposed_beds_self_care: Optional[NonNegativeInt] = None
    proposed_beds_meal: Optional[NonNegativeInt] = None
    proposed_beds_nursing: Optional[NonNegativeInt] = None
    proposed_beds_care_and_attention: Optional[NonNegativeInt] = None
    proposed_residents_total_ab: Optional[NonNegativeInt] = None
    proposed_residents_total_a: Optional[NonNegativeInt] = None
    proposed_residents_total_b: Optional[NonNegativeInt] = None
    proposed_residents_self_care: Optional[NonNegativeInt] = None
    proposed_residents_meal: Optional[NonNegativeInt] = None
    proposed_residents_nursing: Optional[NonNegativeInt] = None
    proposed_residents_care_and_attention: Optional[NonNegativeInt] = None
    proposed_residents_nursing_beyond: Optional[NonNegativeInt] = None
    proposed_residents_nonelderly_mental: Optional[NonNegativeInt] = None
    proposed_residents_nonelderly_intellectual: Optional[NonNegativeInt] = None
    proposed_residents_nonelderly_physical: Optional[NonNegativeInt] = None
    proposed_residents_nonelderly_others: Optional[NonNegativeInt] = None
    proposed_residents_nonelderly_others_specify: Optional[str] = None
    proposed_residents_nonelderly_other_details_num: Optional[NonNegativeInt] = None

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateChangeBedsFormData:
        if not (self.model_fields_set - {"case_summary"}):
            raise ValueError("form_data must contain a proposed Beds/Layout change")
        return self


class UpdateChangeBedsDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateChangeBedsFormData


class ChangeOperationModeFormData(ChangeMonitoringCommonFormData):
    proposed_rch_nature_code: Literal["PN", "PE", "PN_D", "PE_D"]

    @model_validator(mode="after")
    def validate_nature_for_office(self) -> ChangeOperationModeFormData:
        allowed = {
            "LORCHE": {"PN", "PE"},
            "LORCHD": {"PN_D", "PE_D"},
        }[self.case_summary.office_code]
        if self.proposed_rch_nature_code not in allowed:
            raise ValueError(
                "proposed_rch_nature_code is not valid for office_code"
            )
        return self


class CreateIntakeForChangeOperationModeRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ChangeOperationModeFormData


class UpdateChangeOperationModeFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    proposed_effective_date: Optional[date] = None
    proposed_rch_nature_code: Optional[
        Literal["PN", "PE", "PN_D", "PE_D"]
    ] = None

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateChangeOperationModeFormData:
        if not (self.model_fields_set - {"case_summary"}):
            raise ValueError("form_data must contain a proposed Home Type change")
        if self.proposed_rch_nature_code is not None and self.case_summary is not None:
            office_code = self.case_summary.office_code
            if office_code is not None:
                allowed = {
                    "LORCHE": {"PN", "PE"},
                    "LORCHD": {"PN_D", "PE_D"},
                }[office_code]
                if self.proposed_rch_nature_code not in allowed:
                    raise ValueError(
                        "proposed_rch_nature_code is not valid for office_code"
                    )
        return self


class UpdateChangeOperationModeDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateChangeOperationModeFormData


class ChangeDirectorDocumentPayload(ApiPayload):
    document_type: Literal["AUTHORISATION_LETTER", "ND2A", "ND2B"]
    attachment_ids: list[PositiveInt] = Field(min_length=1)
    remarks: Optional[str] = None

    @field_validator("attachment_ids")
    @classmethod
    def require_distinct_attachment_ids(
        cls, value: list[PositiveInt]
    ) -> list[PositiveInt]:
        if len(value) != len(set(value)):
            raise ValueError("documents attachment_ids must be unique")
        return value


def _validate_director_documents(
    documents: Optional[list[ChangeDirectorDocumentPayload]],
) -> None:
    if documents is None:
        return
    document_types = [item.document_type for item in documents]
    if len(document_types) != len(set(document_types)):
        raise ValueError("documents document_type must be unique")


class ChangeDirectorsFormData(ChangeMonitoringCommonFormData):
    title: Literal["0", "1", "2", "3", "4"]
    name_en: str = Field(min_length=1)
    name_cn: str = Field(min_length=1)
    hkid_no: Optional[str] = None
    date_of_directors_change: date
    position_in_rch: Optional[str] = None
    authorised_to_apply: StrictBool
    means_of_authorisation: Optional[Literal["0", "1"]] = None
    signature_name_en: Optional[str] = None
    signature_name_cn: Optional[str] = None
    signature_title: Optional[Literal["0", "1", "2", "3", "4"]] = None
    other_phone_number: str = Field(min_length=1)
    hkid_no_1: Optional[str] = None
    hkid_no_2: Optional[str] = None
    hkid_no_3: Optional[str] = None
    hkid_check_digit: Optional[str] = None
    digital_organisation_certificate_name_en: Optional[str] = None
    documents: list[ChangeDirectorDocumentPayload] = Field(default_factory=list)

    @field_validator("documents", mode="before")
    @classmethod
    def validate_documents_array(
        cls, value: Optional[list[ChangeDirectorDocumentPayload]]
    ) -> list[ChangeDirectorDocumentPayload]:
        if value is None:
            raise ValueError("documents must be an array; use [] to clear")
        return value

    @model_validator(mode="after")
    def validate_director_authorisation(self) -> ChangeDirectorsFormData:
        if "attachment_ids" in self.model_fields_set:
            raise ValueError(
                "Change of Directors uses documents instead of attachment_ids"
            )
        _validate_director_documents(self.documents)
        if self.authorised_to_apply and self.means_of_authorisation is None:
            raise ValueError(
                "means_of_authorisation is required when authorised_to_apply is true"
            )
        if (
            self.authorised_to_apply
            and self.means_of_authorisation == "0"
            and not (self.digital_organisation_certificate_name_en or "").strip()
        ):
            raise ValueError(
                "digital_organisation_certificate_name_en is required for "
                "digital organisation certificate authorisation"
            )
        if self.authorised_to_apply and self.means_of_authorisation == "1":
            if not self.documents or not any(
                item.document_type == "AUTHORISATION_LETTER"
                for item in self.documents
            ):
                raise ValueError(
                    "documents must include AUTHORISATION_LETTER for written "
                    "authorisation"
                )
        return self


class CreateIntakeForChangeDirectorsRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ChangeDirectorsFormData


class UpdateChangeDirectorsFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    proposed_effective_date: Optional[date] = None
    title: Optional[Literal["0", "1", "2", "3", "4"]] = None
    name_en: Optional[str] = None
    name_cn: Optional[str] = None
    hkid_no: Optional[str] = None
    date_of_directors_change: Optional[date] = None
    position_in_rch: Optional[str] = None
    authorised_to_apply: Optional[StrictBool] = None
    means_of_authorisation: Optional[Literal["0", "1"]] = None
    signature_name_en: Optional[str] = None
    signature_name_cn: Optional[str] = None
    signature_title: Optional[Literal["0", "1", "2", "3", "4"]] = None
    other_phone_number: Optional[str] = None
    hkid_no_1: Optional[str] = None
    hkid_no_2: Optional[str] = None
    hkid_no_3: Optional[str] = None
    hkid_check_digit: Optional[str] = None
    digital_organisation_certificate_name_en: Optional[str] = None
    documents: Optional[list[ChangeDirectorDocumentPayload]] = None

    @field_validator("documents", mode="before")
    @classmethod
    def validate_documents_array(
        cls, value: Optional[list[ChangeDirectorDocumentPayload]]
    ) -> list[ChangeDirectorDocumentPayload]:
        if value is None:
            raise ValueError("documents must be an array; use [] to clear")
        return value

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateChangeDirectorsFormData:
        if "attachment_ids" in self.model_fields_set:
            raise ValueError(
                "Change of Directors uses documents instead of attachment_ids"
            )
        _validate_director_documents(self.documents)
        if not (self.model_fields_set - {"case_summary"}):
            raise ValueError("form_data must contain a proposed Directors change")
        if (
            self.authorised_to_apply is True
            and "authorised_to_apply" in self.model_fields_set
            and self.means_of_authorisation is None
            and "means_of_authorisation" in self.model_fields_set
        ):
            raise ValueError(
                "means_of_authorisation cannot be null when authorised_to_apply is true"
            )
        return self


class UpdateChangeDirectorsDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateChangeDirectorsFormData


class ChangeNurseInChargeFormData(ChangeMonitoringCommonFormData):
    person_title: Literal["0", "1", "2", "3"]
    name: str = Field(min_length=1)
    tel: Optional[str] = None
    email: Optional[str] = None
    position: Optional[str] = None

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: Optional[str]) -> Optional[str]:
        return _validate_business_email(value)

    @model_validator(mode="after")
    def require_nurse_change(self) -> ChangeNurseInChargeFormData:
        business_fields = {
            "person_title",
            "name",
            "tel",
            "email",
            "position",
            "proposed_effective_date",
        }
        if not (self.model_fields_set & business_fields):
            raise ValueError(
                "form_data must contain at least one Nurse-in-Charge change"
            )
        return self


class CreateIntakeForChangeNurseInChargeRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ChangeNurseInChargeFormData


class UpdateChangeNurseInChargeFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    proposed_effective_date: Optional[date] = None
    person_title: Optional[Literal["0", "1", "2", "3"]] = None
    name: Optional[str] = None
    tel: Optional[str] = None
    email: Optional[str] = None
    position: Optional[str] = None

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: Optional[str]) -> Optional[str]:
        return _validate_business_email(value)

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateChangeNurseInChargeFormData:
        if not (self.model_fields_set - {"case_summary"}):
            raise ValueError(
                "form_data must contain a proposed Nurse-in-Charge change"
            )
        return self


class UpdateChangeNurseInChargeDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateChangeNurseInChargeFormData


class OffenceChargedItemPayload(ApiPayload):
    name_of_defendant: Optional[str] = None
    name_of_defendant_chi: Optional[str] = None
    type_of_defendant: Optional[Literal["Natural Person", "Body Coporate"]] = None
    hkic_no: Optional[str] = None
    date_of_birth: Optional[date] = None
    offence_charged: Optional[str] = None
    offence_charged_items: Optional[list[str]] = None
    offence_charged_items_others: Optional[str] = None
    detail_of_offence: Optional[str] = None
    section_cap: Optional[str] = None
    pg_png: Optional[Literal["PG", "PNG"]] = None
    date_of_conviction: Optional[date] = None
    sanction: Optional[str] = None
    court_disposal: Optional[str] = None
    remark: Optional[str] = None
    business_registration_number: Optional[str] = None
    certificate_of_incorporation_number: Optional[str] = None
    brc_no: Optional[str] = None
    trust_number: Optional[str] = None


class ProsecutionFormData(ApiPayload):
    case_summary: ChangingHomeCaseSummaryPayload
    serial_no: Optional[str] = None
    court_case_no: Optional[str] = None
    unlicenced_rch: Optional[bool] = None
    legal_advice_result: Optional[
        Literal["Go for Prosecution", "Not Go for Prosecution"]
    ] = None
    date_of_advice_from_doj: Optional[date] = None
    date_of_enforcement_action: Optional[date] = None
    first_court_hearing_date: Optional[date] = None
    last_court_hearing_date: Optional[date] = None
    reason: Optional[str] = None
    remarks: Optional[str] = None
    comments: Optional[str] = None
    offence_items: list[OffenceChargedItemPayload] = Field(default_factory=list)


class CreateIntakeForProsecutionRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: Optional[ScalarId] = None
    form_data: ProsecutionFormData


class UpdateProsecutionFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    serial_no: Optional[str] = None
    court_case_no: Optional[str] = None
    unlicenced_rch: Optional[bool] = None
    legal_advice_result: Optional[
        Literal["Go for Prosecution", "Not Go for Prosecution"]
    ] = None
    date_of_advice_from_doj: Optional[date] = None
    date_of_enforcement_action: Optional[date] = None
    first_court_hearing_date: Optional[date] = None
    last_court_hearing_date: Optional[date] = None
    reason: Optional[str] = None
    remarks: Optional[str] = None
    comments: Optional[str] = None
    offence_items: Optional[list[OffenceChargedItemPayload]] = None

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateProsecutionFormData:
        if not self.model_dump(exclude_unset=True):
            raise ValueError("form_data must contain at least one changed field")
        return self


class UpdateProsecutionDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateProsecutionFormData


class LicenceRenewalCaseSummaryPayload(ChangingHomeCaseSummaryPayload):
    """A Renewal Create identifies the existing Home by its RCH number."""

    rch_no: str = Field(min_length=1, max_length=128)


class LicenceRenewalPart5Payload(ApiPayload):
    """Renewal clients submit document assignments, not approval notes."""

    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @model_validator(mode="after")
    def require_distinct_positions(self) -> LicenceRenewalPart5Payload:
        if self.checklist is not None:
            codes = [item.position_code for item in self.checklist]
            if len(codes) != len(set(codes)):
                raise ValueError(
                    "Licence Renewal checklist position_code must be unique"
                )
        return self


class LicenceRenewalFormData(ApiPayload):
    """NLA-shaped body. Only confirmed whitelist fields are written."""

    case_summary: LicenceRenewalCaseSummaryPayload
    part_1: Optional[UpdateNlaPart1Payload] = None
    part_2: Optional[UpdateNlaPart2Payload] = None
    part_3: Optional[UpdateNlaPart3Payload] = None
    part_4: Optional[UpdateNlaPart4Payload] = None
    part_5: Optional[LicenceRenewalPart5Payload] = None

    @model_validator(mode="after")
    def reject_unimplemented_renewal_parts(self) -> LicenceRenewalFormData:
        _validate_renewal_part_whitelist(self)
        return self


def _validate_renewal_part_whitelist(form: Any) -> None:
    """Reject accepted-but-ignored fields until their workflow exists."""
    if any(getattr(form, name) is not None for name in ("part_2", "part_3", "part_4")):
        raise ValueError("Licence Renewal supports only part_1 and part_5")
    if form.part_1 is not None and form.part_1.model_fields_set - {
        "application_received_date"
    }:
        raise ValueError("part_1 supports only application_received_date")
    if form.part_5 is not None and form.part_5.model_fields_set - {"checklist"}:
        raise ValueError("part_5 contains an unsupported Licence Renewal field")


class UpdateLicenceRenewalPart5Payload(LicenceRenewalPart5Payload):
    """Each submitted renewal Checklist position needs its uploaded file ID."""

    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @model_validator(mode="after")
    def reject_null_replacement(self) -> UpdateLicenceRenewalPart5Payload:
        if "checklist" in self.model_fields_set and self.checklist is None:
            raise ValueError("Licence Renewal part_5.checklist cannot be null")
        return self


class CreateLicenceRenewalRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: LicenceRenewalFormData


class UpdateLicenceRenewalFormData(ApiPayload):
    case_summary: Optional[UpdateChangingHomeCaseSummaryPayload] = None
    part_1: Optional[UpdateNlaPart1Payload] = None
    part_2: Optional[UpdateNlaPart2Payload] = None
    part_3: Optional[UpdateNlaPart3Payload] = None
    part_4: Optional[UpdateNlaPart4Payload] = None
    part_5: Optional[UpdateLicenceRenewalPart5Payload] = None

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateLicenceRenewalFormData:
        if not self.model_dump(exclude_unset=True):
            raise ValueError("form_data must contain at least one changed field")
        _validate_renewal_part_whitelist(self)
        return self


class UpdateLicenceRenewalDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateLicenceRenewalFormData


class ExpansionAipPart1Payload(ApiPayload):
    title: Literal["0", "1", "2", "3"]
    name_eng: str = Field(min_length=1)
    name_chi: Optional[str] = None
    authorised_to_apply_by_operator: StrictBool
    means_of_authorisation: Literal["0", "1"]
    authorised_name_eng: Optional[str] = None
    hkic_number1: str = Field(min_length=1)
    hkic_number2: str = Field(min_length=1)


class ExpansionAipPart2Payload(ApiPayload):
    address_chi_expansion: str = Field(min_length=1)
    address_eng_expansion: str = Field(min_length=1)
    tentative_licencing_capacity_expansion: PositiveInt
    # NocoBase stores this public tentative value in
    # f_existing_area_of_floor_space_expansion. Pydantic deliberately accepts
    # numeric JSON strings and normalises them to a positive number.
    tentative_area_of_floor_space_expansion: float = Field(gt=0)
    number_of_beds_expansion: PositiveInt


def _validate_expansion_aip_checklist(
    checklist: Optional[list[ChecklistItemPayload]],
) -> None:
    if checklist is None:
        return
    codes = [item.position_code for item in checklist]
    if len(codes) != len(set(codes)):
        raise ValueError("Expansion AIP checklist position_code must be unique")


class ExpansionAipPart3Payload(ApiPayload):
    checklist: list[ChecklistItemPayload] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def require_distinct_checklist_assignments(self) -> ExpansionAipPart3Payload:
        _validate_expansion_aip_checklist(self.checklist)
        return self


class ExpansionAipFormData(ApiPayload):
    case_summary: ChangingHomeCaseSummaryPayload
    part_1: ExpansionAipPart1Payload
    part_2: ExpansionAipPart2Payload
    part_3: ExpansionAipPart3Payload = Field(default_factory=ExpansionAipPart3Payload)


class CreateIntakeForExpansionAipRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    form_data: ExpansionAipFormData


class UpdateExpansionAipPart1Payload(ApiPayload):
    title: Optional[Literal["0", "1", "2", "3"]] = None
    name_eng: Optional[str] = Field(default=None, min_length=1)
    name_chi: Optional[str] = None
    authorised_to_apply_by_operator: Optional[StrictBool] = None
    means_of_authorisation: Optional[Literal["0", "1"]] = None
    authorised_name_eng: Optional[str] = None
    hkic_number1: Optional[str] = Field(default=None, min_length=1)
    hkic_number2: Optional[str] = Field(default=None, min_length=1)


class UpdateExpansionAipPart2Payload(ApiPayload):
    address_chi_expansion: Optional[str] = Field(default=None, min_length=1)
    address_eng_expansion: Optional[str] = Field(default=None, min_length=1)
    tentative_licencing_capacity_expansion: Optional[PositiveInt] = None
    tentative_area_of_floor_space_expansion: Optional[float] = Field(
        default=None, gt=0
    )
    number_of_beds_expansion: Optional[PositiveInt] = None


class UpdateExpansionAipPart3Payload(ApiPayload):
    # Supplying [] deliberately clears all assignments. Supplying null is
    # rejected because it is not a valid replacement collection.
    checklist: Optional[list[ChecklistItemPayload]] = Field(
        default=None, max_length=100
    )

    @model_validator(mode="after")
    def validate_replacement_checklist(self) -> UpdateExpansionAipPart3Payload:
        if "checklist" in self.model_fields_set and self.checklist is None:
            raise ValueError("Expansion AIP part_3.checklist cannot be null")
        _validate_expansion_aip_checklist(self.checklist)
        return self


class UpdateExpansionAipFormData(ApiPayload):
    case_summary: Optional[UpdateHomeBoundCaseSummaryPayload] = None
    part_1: Optional[UpdateExpansionAipPart1Payload] = None
    part_2: Optional[UpdateExpansionAipPart2Payload] = None
    part_3: Optional[UpdateExpansionAipPart3Payload] = None

    @model_validator(mode="after")
    def require_at_least_one_change(self) -> UpdateExpansionAipFormData:
        def has_change(value: Any) -> bool:
            if isinstance(value, dict):
                return any(has_change(item) for item in value.values())
            # Explicit nulls and lists, including [] for checklist replacement,
            # are intentional changes.
            return True

        supplied = self.model_dump(exclude_unset=True)
        if not has_change(supplied):
            raise ValueError("form_data must contain at least one changed field")
        for name in ("case_summary", "part_1", "part_2", "part_3"):
            if name in self.model_fields_set and getattr(self, name) is None:
                raise ValueError(f"Expansion AIP {name} cannot be null")
        if set(supplied) == {"case_summary"} and set(supplied["case_summary"]) <= {
            "office_code",
            "rch_no",
            "lorche_d_no",
            "p_no",
        }:
            raise ValueError("form_data must contain an Expansion AIP change")
        return self


class UpdateExpansionAipDataRequest(ApiPayload):
    request_id: str = Field(min_length=1, max_length=128)
    create_id: ScalarId
    form_data: UpdateExpansionAipFormData


@dataclass(frozen=True)
class FileDownload:
    content: AsyncIterator[bytes]
    status_code: int
    headers: dict[str, str]
