from __future__ import annotations

import asyncio
import json
import logging
import re
from collections.abc import AsyncIterator
from typing import Any, BinaryIO, Optional, Union
from urllib.parse import quote

import httpx

from .errors import AdapterError
from .models import FileDownload, StorageInfo
from .settings import Settings

logger = logging.getLogger(__name__)
REDIRECT_STATUS_CODES = {301, 302, 303, 307, 308}
DOWNLOAD_RESPONSE_HEADERS = {
    "accept-ranges",
    "cache-control",
    "content-disposition",
    "content-encoding",
    "content-length",
    "content-range",
    "content-type",
    "etag",
    "last-modified",
}
READINESS_TIMEOUT_SECONDS = 2.0
SINGLE_BYTE_RANGE = re.compile(r"bytes=(?:(\d+)-(\d*)|-(\d+))\Z")


def validate_byte_range(value: Optional[str]) -> Optional[str]:
    """Accept one HTTP byte range; never forward malformed or multi-ranges."""
    if value is None:
        return None
    value = value.strip()
    match = SINGLE_BYTE_RANGE.fullmatch(value) if len(value) <= 128 else None
    if match is None:
        raise AdapterError(400, "invalid_range", "Invalid byte range")
    start, end, suffix = match.groups()
    if (start is not None and end and int(end) < int(start)) or (
        suffix is not None and int(suffix) == 0
    ):
        raise AdapterError(400, "invalid_range", "Invalid byte range")
    return value


class NocoBaseClient:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._client: Optional[httpx.AsyncClient] = None
        self._object_client: Optional[httpx.AsyncClient] = None

    async def start(self) -> None:
        limits = httpx.Limits(
            max_connections=self._settings.max_connections,
            max_keepalive_connections=min(20, self._settings.max_connections),
        )
        timeout = httpx.Timeout(
            connect=self._settings.connect_timeout_seconds,
            read=self._settings.request_timeout_seconds,
            write=self._settings.request_timeout_seconds,
            pool=self._settings.connect_timeout_seconds,
        )
        self._client = httpx.AsyncClient(
            base_url=self._settings.nocobase_base_url,
            timeout=timeout,
            limits=limits,
            verify=self._settings.verify_tls,
            follow_redirects=False,
        )
        self._object_client = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=self._settings.connect_timeout_seconds,
                read=self._settings.upload_timeout_seconds,
                write=self._settings.upload_timeout_seconds,
                pool=self._settings.connect_timeout_seconds,
            ),
            limits=limits,
            follow_redirects=False,
        )

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
        if self._object_client is not None:
            await self._object_client.aclose()

    async def sign_in(
        self, *, account: str, password: str, request_id: str
    ) -> dict[str, Any]:
        """Exchange credentials for a native NocoBase token without a Bearer token.

        Authentication failures never expose the upstream response body, which
        can contain account details or a copy of the submitted credentials.
        """
        if self._client is None:
            raise RuntimeError("NocoBase client has not been started")
        try:
            response = await self._client.post(
                self._settings.nocobase.api.auth_sign_in,
                json={"account": account, "password": password},
                headers={
                    "Accept": "application/json",
                    "X-Authenticator": self._settings.nocobase.authenticator,
                    "X-Request-ID": request_id,
                },
            )
        except (httpx.TimeoutException, httpx.RequestError) as exc:
            logger.warning(
                "Authentication upstream unavailable request_id=%s error=%s",
                request_id,
                type(exc).__name__,
            )
            raise AdapterError(
                503,
                "service_unavailable",
                "The authentication service is unavailable",
            ) from exc

        if response.status_code in {400, 401, 403, 422}:
            raise AdapterError(
                401,
                "invalid_credentials",
                "The account or password is invalid",
            )
        if response.status_code == 429:
            raise AdapterError(
                429,
                "rate_limit_exceeded",
                "Authentication request rate exceeded",
            )
        if response.status_code >= 500 or response.status_code == 404:
            raise AdapterError(
                503,
                "service_unavailable",
                "The authentication service is unavailable",
            )
        if not 200 <= response.status_code < 300:
            raise AdapterError(
                502,
                "upstream_error",
                "The authentication upstream returned an invalid response",
            )
        try:
            payload = response.json()
        except json.JSONDecodeError as exc:
            raise AdapterError(
                502,
                "upstream_error",
                "The authentication upstream returned an invalid response",
            ) from exc
        if isinstance(payload, dict) and payload.get("errors"):
            raise AdapterError(
                401,
                "invalid_credentials",
                "The account or password is invalid",
            )
        data_key = self._settings.nocobase.response_data_key or "data"
        data = payload.get(data_key) if isinstance(payload, dict) else None
        if (
            not isinstance(data, dict)
            or not isinstance(data.get("token"), str)
            or not data["token"].strip()
        ):
            raise AdapterError(
                502,
                "upstream_error",
                "The authentication upstream returned an invalid response",
            )
        # NocoBase may also return user and authenticator metadata.  Only the
        # documented native token is part of the public authentication result.
        return {"data": {"token": data["token"]}}

    async def check_access_token(
        self,
        token: str,
        request_id: str,
    ) -> dict[str, Any]:
        data = await self._request_json(
            "GET",
            self._settings.nocobase.api.auth_check,
            request_id=request_id,
            authorization_token=token,
            client_auth_request=True,
        )
        if not isinstance(data, dict):
            raise AdapterError(
                401,
                "invalid_client_token",
                "The client access token is invalid or expired",
            )
        return data

    async def check_readiness(self) -> bool:
        """Bounded, read-only check of the required NocoBase API dependency.

        The configured service token is never taken from the caller or exposed
        in the health response.  Checking auth:check also verifies the API can
        resolve an account, rather than merely accepting a TCP connection.
        """
        token = self._settings.nocobase_config_token
        if not token:
            return False
        try:
            await asyncio.wait_for(
                self.check_access_token(token, "health-readiness"),
                timeout=READINESS_TIMEOUT_SECONDS,
            )
        except Exception as exc:
            logger.warning("Readiness probe failed: %s", type(exc).__name__)
            return False
        return True

    async def trigger_business_webhook(
        self,
        *,
        path: str,
        request_id: str,
        authorization_token: str,
        params: Optional[list[tuple[str, str]]] = None,
    ) -> Any:
        """Call a configured workflow with the verified client's identity."""
        return await self._request_json(
            "POST",
            path,
            request_id=request_id,
            authorization_token=authorization_token,
            params=params,
            unwrap_data=False,
        )

    async def create_request_staging(
        self,
        *,
        request_id: str,
        authorization_token: str,
        values: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a staging record using the verified client's identity."""
        data = await self._request_json(
            "POST",
            self._settings.nocobase.api.request_staging_create,
            request_id=request_id,
            authorization_token=authorization_token,
            json_body=values,
        )
        if not isinstance(data, dict) or data.get("id") is None:
            raise AdapterError(
                502,
                "invalid_staging_create_response",
                "The upstream did not return the created staging record ID",
            )
        return data

    async def trigger_staging_custom_action(
        self,
        *,
        staging_id: Union[int, str],
        workflow_key: str,
        request_id: str,
        authorization_token: str,
    ) -> None:
        """Trigger an exact Staging Custom Action with the caller's identity.

        NocoBase returns HTTP 200 ``{}`` for both one and zero SQL rows.  This
        method intentionally exposes no success result; the queue service
        must read the exact Staging child after the synchronous action.
        """

        await self._request_json(
            "POST",
            "/api/t_api_request_staging:trigger",
            request_id=request_id,
            authorization_token=authorization_token,
            params=[
                ("filterByTk", str(staging_id)),
                ("triggerWorkflows", workflow_key),
            ],
            json_body={},
            unwrap_data=False,
        )

    async def get_record(
        self,
        *,
        collection: str,
        record_id: Union[int, str],
        request_id: str,
        authorization_token: str,
        appends: tuple[str, ...] = (),
    ) -> dict[str, Any]:
        """Read one business record with the verified client's identity."""
        params: list[tuple[str, str]] = [("filterByTk", str(record_id))]
        params.extend(("appends[]", field) for field in appends)
        data = await self._request_json(
            "GET",
            f"/api/{collection}:get",
            request_id=request_id,
            authorization_token=authorization_token,
            params=params,
        )
        if data is None:
            raise AdapterError(404, "record_not_found", "The record was not found")
        if not isinstance(data, dict):
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream did not return a record object",
            )
        return data

    async def update_record_if(
        self,
        *,
        collection: str,
        record_id: Union[int, str],
        expected: dict[str, Any],
        request_id: str,
        authorization_token: str,
        values: dict[str, Any],
    ) -> Any:
        """Atomically update one record only while all expected values match."""

        expected_filters = [
            {field: ({"$empty": True} if value is None else {"$eq": value})}
            for field, value in expected.items()
        ]
        filters = {"$and": [{"id": {"$eq": record_id}}, *expected_filters]}
        return await self._request_json(
            "POST",
            f"/api/{collection}:update",
            request_id=request_id,
            authorization_token=authorization_token,
            params=[("filter", json.dumps(filters, separators=(",", ":")))],
            json_body=values,
        )

    async def list_records(
        self,
        *,
        collection: str,
        request_id: str,
        authorization_token: str,
        filters: Optional[dict[str, Any]] = None,
        appends: tuple[str, ...] = (),
        page: int = 1,
        page_size: int = 20,
        sort: tuple[str, ...] = ("-createdAt",),
    ) -> dict[str, Any]:
        """List business records while preserving NocoBase pagination metadata."""
        return await self._list_records_with_token(
            collection=collection,
            request_id=request_id,
            authorization_token=authorization_token,
            filters=filters,
            appends=appends,
            page=page,
            page_size=page_size,
            sort=sort,
        )

    async def list_configuration_records(
        self,
        *,
        collection: str,
        request_id: str,
        filters: Optional[dict[str, Any]] = None,
        appends: tuple[str, ...] = (),
        page: int = 1,
        page_size: int = 1000,
        sort: tuple[str, ...] = (),
    ) -> dict[str, Any]:
        """Read non-business catalog data with the configured global token."""
        token = self._settings.nocobase_config_token
        if not token:
            raise AdapterError(
                503,
                "configuration_token_missing",
                "The NocoBase configuration token is not configured",
            )
        try:
            return await self._list_records_with_token(
                collection=collection,
                request_id=request_id,
                authorization_token=token,
                filters=filters,
                appends=appends,
                page=page,
                page_size=page_size,
                sort=sort,
            )
        except AdapterError as exc:
            if exc.status_code in {401, 403}:
                raise AdapterError(
                    503,
                    "configuration_access_denied",
                    "The NocoBase configuration token is invalid or lacks permission",
                ) from exc
            raise

    async def _list_records_with_token(
        self,
        *,
        collection: str,
        request_id: str,
        authorization_token: str,
        filters: Optional[dict[str, Any]],
        appends: tuple[str, ...],
        page: int,
        page_size: int,
        sort: tuple[str, ...],
    ) -> dict[str, Any]:
        params: list[tuple[str, str]] = [
            ("page", str(page)),
            ("pageSize", str(page_size)),
        ]
        if filters:
            params.append(("filter", json.dumps(filters, separators=(",", ":"))))
        params.extend(("appends[]", field) for field in appends)
        params.extend(("sort[]", field) for field in sort)
        payload = await self._request_json(
            "GET",
            f"/api/{collection}:list",
            request_id=request_id,
            authorization_token=authorization_token,
            params=params,
            unwrap_data=False,
        )
        data_key = self._settings.nocobase.response_data_key or "data"
        if not isinstance(payload, dict) or not isinstance(payload.get(data_key), list):
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream did not return a record array",
            )
        meta = payload.get("meta")
        return {
            "data": payload[data_key],
            "meta": meta if isinstance(meta, dict) else {},
        }

    async def get_storage(self, request_id: str) -> StorageInfo:
        token = self._settings.nocobase_config_token
        if not token:
            raise AdapterError(
                503,
                "storage_config_token_missing",
                "The NocoBase storage configuration token is not configured",
            )
        storage_name = self._settings.storage_name
        path = self._settings.nocobase.api.storage_basic_info
        if storage_name:
            path = self._settings.nocobase.api.storage_basic_info_by_name.format(
                storage_name=quote(storage_name, safe="")
            )
        try:
            data = await self._request_json(
                "GET",
                path,
                request_id=request_id,
                authorization_token=token,
            )
        except AdapterError as exc:
            if exc.status_code in {401, 403}:
                raise AdapterError(
                    503,
                    "storage_config_access_denied",
                    "The NocoBase storage configuration token is invalid "
                    "or lacks permission",
                ) from exc
            raise
        try:
            return StorageInfo.model_validate(data)
        except Exception as exc:
            raise AdapterError(
                502,
                "invalid_storage_response",
                "The upstream returned an invalid file storage configuration",
            ) from exc

    async def create_presigned_url(
        self,
        *,
        filename: str,
        size: int,
        mime_type: str,
        storage: StorageInfo,
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        data = await self._request_json(
            "POST",
            self._settings.nocobase.api.create_presigned_url,
            request_id=request_id,
            authorization_token=authorization_token,
            json_body={
                "name": filename,
                "size": size,
                "type": mime_type,
                "storageId": storage.id,
                "storageType": storage.type,
            },
        )
        if not isinstance(data, dict):
            raise AdapterError(
                502,
                "invalid_presigned_response",
                "The upstream returned invalid presigned upload information",
            )
        put_url = data.get("putUrl")
        file_info = data.get("fileInfo")
        if not isinstance(put_url, str) or not put_url.startswith(
            ("http://", "https://")
        ):
            raise AdapterError(
                502,
                "invalid_presigned_response",
                "The upstream did not return a valid putUrl",
            )
        if not isinstance(file_info, dict):
            raise AdapterError(
                502,
                "invalid_presigned_response",
                "The upstream did not return valid fileInfo",
            )
        return data

    async def upload_object(
        self,
        *,
        put_url: str,
        content: AsyncIterator[bytes],
        size: int,
        mime_type: str,
        request_id: str,
    ) -> Optional[str]:
        if self._object_client is None:
            raise RuntimeError("NocoBase client has not been started")
        try:
            response = await self._object_client.put(
                put_url,
                content=content,
                headers={
                    "Content-Type": mime_type,
                    "Content-Length": str(size),
                },
            )
        except httpx.TimeoutException as exc:
            raise AdapterError(
                504,
                "object_upload_timeout",
                "The object storage upload timed out",
            ) from exc
        except httpx.RequestError as exc:
            logger.warning(
                "Object upload connection failed request_id=%s error=%s",
                request_id,
                type(exc).__name__,
            )
            raise AdapterError(
                502,
                "object_storage_unavailable",
                "Could not connect to object storage",
            ) from exc
        if not 200 <= response.status_code < 300:
            raise AdapterError(
                502,
                "object_upload_failed",
                f"Object storage returned HTTP {response.status_code}",
            )
        return response.headers.get("etag")

    async def upload_attachment_file(
        self,
        *,
        filename: str,
        mime_type: str,
        file_object: BinaryIO,
        request_id: str,
        authorization_token: str,
        attachment_field_context: Optional[str] = None,
    ) -> dict[str, Any]:
        params = _attachment_field_params(attachment_field_context)
        data = await self._request_json(
            "POST",
            self._settings.nocobase.api.attachment_create,
            request_id=request_id,
            authorization_token=authorization_token,
            params=params,
            files={"file": (filename, file_object, mime_type)},
            upload_request=True,
        )
        return _validate_attachment(data)

    async def create_attachment(
        self,
        *,
        file_info: dict[str, Any],
        storage_id: Union[int, str],
        request_id: str,
        authorization_token: str,
        attachment_field_context: Optional[str] = None,
    ) -> dict[str, Any]:
        filename = file_info.get("key") or file_info.get("filename")
        payload = {
            "title": file_info.get("title"),
            "filename": filename,
            "extname": file_info.get("extname"),
            "path": file_info.get("path", ""),
            "size": file_info.get("size"),
            "url": file_info.get("url", ""),
            "mimetype": file_info.get("mimetype"),
            "meta": file_info.get("meta") or {},
            "storageId": storage_id,
        }
        if not payload["filename"] or payload["size"] is None:
            raise AdapterError(
                502,
                "invalid_file_info",
                "The presigned response is missing required file metadata",
            )
        data = await self._request_json(
            "POST",
            self._settings.nocobase.api.attachment_create,
            request_id=request_id,
            authorization_token=authorization_token,
            params=_attachment_field_params(attachment_field_context),
            json_body=payload,
        )
        return _validate_attachment(data)

    async def open_attachment_download(
        self,
        *,
        attachment_id: Union[int, str],
        request_id: str,
        authorization_token: str,
        byte_range: Optional[str] = None,
    ) -> FileDownload:
        """Open a NocoBase attachment download without buffering its body."""
        if self._client is None or self._object_client is None:
            raise RuntimeError("NocoBase client has not been started")

        path = self._settings.nocobase.api.attachment_download.format(
            attachment_id=quote(str(attachment_id), safe="")
        )
        authenticated_headers = self._authenticated_headers(
            authorization_token,
            request_id,
            accept="*/*",
        )
        byte_range = validate_byte_range(byte_range)
        if byte_range is not None:
            authenticated_headers["Range"] = byte_range
        response = await self._send_download_request(
            client=self._client,
            url=path,
            headers=authenticated_headers,
            params=[("download", "1")],
            request_id=request_id,
            object_storage=False,
        )
        nocobase_origin = httpx.URL(self._settings.nocobase_base_url)
        object_storage = False

        for _ in range(5):
            if response.status_code not in REDIRECT_STATUS_CODES:
                break
            location = response.headers.get("location")
            if not location:
                await response.aclose()
                raise AdapterError(
                    502,
                    "invalid_download_redirect",
                    "The upstream returned a download redirect without a URL",
                )
            target = response.url.join(location)
            await response.aclose()
            if target.scheme not in {"http", "https"}:
                raise AdapterError(
                    502,
                    "invalid_download_redirect",
                    "The upstream returned an unsupported download URL",
                )
            same_origin = _same_origin(target, nocobase_origin)
            object_storage = not same_origin
            response = await self._send_download_request(
                client=self._client if same_origin else self._object_client,
                url=target,
                headers=(
                    authenticated_headers
                    if same_origin
                    else {
                        "Accept": "*/*",
                        **({"Range": byte_range} if byte_range is not None else {}),
                    }
                ),
                params=None,
                request_id=request_id,
                object_storage=object_storage,
            )
        else:
            await response.aclose()
            raise AdapterError(
                502,
                "too_many_download_redirects",
                "The upstream returned too many download redirects",
            )

        if response.status_code not in {200, 206}:
            await response.aread()
            status_code = response.status_code
            await response.aclose()
            if status_code == 416 and byte_range is not None:
                raise AdapterError(400, "invalid_range", "Invalid byte range")
            if status_code == 403:
                raise AdapterError(
                    403,
                    "attachment_forbidden",
                    "The attachment is not available to this user",
                )
            if not object_storage and status_code == 401:
                raise AdapterError(
                    401,
                    "invalid_client_token",
                    "The client access token is invalid or expired",
                )
            if status_code == 404:
                raise AdapterError(
                    404,
                    "attachment_not_found",
                    "The attachment or stored file was not found",
                )
            raise AdapterError(
                502,
                "file_download_failed",
                f"The download upstream returned HTTP {status_code}",
            )

        if response.status_code == 206 and not response.headers.get("content-range"):
            await response.aclose()
            raise AdapterError(
                502,
                "invalid_download_response",
                "The upstream returned a partial file without Content-Range",
            )

        headers = {
            key: value
            for key, value in response.headers.items()
            if key.lower() in DOWNLOAD_RESPONSE_HEADERS
        }

        async def content() -> AsyncIterator[bytes]:
            try:
                async for chunk in response.aiter_raw():
                    yield chunk
            finally:
                await response.aclose()

        return FileDownload(
            content=content(),
            status_code=response.status_code,
            headers=headers,
        )

    async def _send_download_request(
        self,
        *,
        client: httpx.AsyncClient,
        url: Union[str, httpx.URL],
        headers: dict[str, str],
        params: Optional[list[tuple[str, str]]],
        request_id: str,
        object_storage: bool,
    ) -> httpx.Response:
        request = client.build_request(
            "GET",
            url,
            headers=headers,
            params=params,
        )
        try:
            return await client.send(request, stream=True)
        except httpx.TimeoutException as exc:
            raise AdapterError(
                504,
                (
                    "object_download_timeout"
                    if object_storage
                    else "upstream_timeout"
                ),
                "The file download did not respond before the timeout",
            ) from exc
        except httpx.RequestError as exc:
            logger.warning(
                "Download connection failed request_id=%s external=%s "
                "error=%s",
                request_id,
                object_storage,
                type(exc).__name__,
            )
            raise AdapterError(
                502,
                (
                    "object_storage_unavailable"
                    if object_storage
                    else "upstream_unavailable"
                ),
                "Could not connect to the file download upstream",
            ) from exc

    def _authenticated_headers(
        self,
        authorization_token: str,
        request_id: str,
        *,
        accept: str = "application/json",
    ) -> dict[str, str]:
        return {
            "Accept": accept,
            "Authorization": f"Bearer {authorization_token}",
            "X-Authenticator": self._settings.nocobase.authenticator,
            "X-Request-ID": request_id,
        }

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        request_id: str,
        authorization_token: str,
        params: Optional[list[tuple[str, str]]] = None,
        json_body: Any = None,
        files: Optional[dict[str, tuple[str, BinaryIO, str]]] = None,
        upload_request: bool = False,
        client_auth_request: bool = False,
        unwrap_data: bool = True,
    ) -> Any:
        if self._client is None:
            raise RuntimeError("NocoBase client has not been started")
        headers = self._authenticated_headers(
            authorization_token,
            request_id,
        )
        timeout: Optional[httpx.Timeout] = None
        if upload_request:
            timeout = httpx.Timeout(
                self._settings.upload_timeout_seconds,
                connect=self._settings.connect_timeout_seconds,
            )
        try:
            response = await self._client.request(
                method,
                path,
                params=params,
                json=json_body,
                files=files,
                headers=headers,
                timeout=timeout,
            )
        except httpx.TimeoutException as exc:
            raise AdapterError(
                504,
                "upstream_timeout",
                "The upstream did not respond before the timeout",
            ) from exc
        except httpx.RequestError as exc:
            logger.warning(
                "Upstream connection failed request_id=%s error=%s",
                request_id,
                type(exc).__name__,
            )
            raise AdapterError(
                502,
                "upstream_unavailable",
                "Could not connect to the upstream application",
            ) from exc

        if response.status_code in {401, 403} and client_auth_request:
            raise AdapterError(
                401,
                "invalid_client_token",
                "The client access token is invalid or expired",
            )
        if response.status_code == 401:
            raise AdapterError(
                401,
                "invalid_client_token",
                "The client access token is invalid or expired",
            )
        if response.status_code == 403:
            raise AdapterError(
                403,
                "nocobase_permission_denied",
                "The NocoBase user is not allowed to perform this operation",
            )
        payload: Any = None
        if response.content:
            try:
                payload = response.json()
            except json.JSONDecodeError as exc:
                raise AdapterError(
                    502,
                    "invalid_upstream_response",
                    "The upstream returned a non-JSON response",
                ) from exc
        if not 200 <= response.status_code < 300:
            upstream_message = _extract_upstream_message(payload)
            public_status = (
                response.status_code
                if response.status_code in {400, 404, 409, 413, 415, 422}
                else 502
            )
            raise AdapterError(
                public_status,
                "nocobase_request_rejected",
                f"The upstream returned HTTP {response.status_code}",
                details={"upstreamMessage": upstream_message}
                if upstream_message
                else None,
            )
        if isinstance(payload, dict) and payload.get("errors"):
            if client_auth_request:
                raise AdapterError(
                    401,
                    "invalid_client_token",
                    "The client access token is invalid or expired",
                )
            raise AdapterError(
                502,
                "upstream_business_error",
                "The upstream reported a business error",
            )
        if payload is None:
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream returned an empty response",
            )
        data_key = self._settings.nocobase.response_data_key
        if (
            unwrap_data
            and isinstance(payload, dict)
            and data_key
            and data_key in payload
        ):
            return payload[data_key]
        return payload


def _attachment_field_params(
    attachment_field_context: Optional[str],
) -> Optional[list[tuple[str, str]]]:
    if not attachment_field_context:
        return None
    return [("attachmentField", attachment_field_context)]


def _validate_attachment(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict) or data.get("id") is None:
        raise AdapterError(
            502,
            "attachment_create_failed",
            "The upstream did not return an attachment ID",
        )
    return data


def _extract_upstream_message(payload: Any) -> Optional[str]:
    if not isinstance(payload, dict):
        return None
    message = payload.get("message")
    if isinstance(message, str):
        return message[:300]
    errors = payload.get("errors")
    if isinstance(errors, list) and errors and isinstance(errors[0], dict):
        value = errors[0].get("message")
        if isinstance(value, str):
            return value[:300]
    return None


def _same_origin(left: httpx.URL, right: httpx.URL) -> bool:
    return (
        left.scheme,
        left.host,
        left.port,
    ) == (
        right.scheme,
        right.host,
        right.port,
    )
