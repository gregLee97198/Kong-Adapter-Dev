from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

import yaml

from .errors import ConfigurationError


@dataclass(frozen=True)
class NocoBaseApiPaths:
    auth_sign_in: str
    auth_check: str
    simple_test: str
    homerecord_query: str
    request_staging_create: str
    storage_basic_info: str
    storage_basic_info_by_name: str
    create_presigned_url: str
    attachment_create: str
    attachment_download: str


@dataclass(frozen=True)
class NocoBaseProfile:
    version: str
    base_url: str
    authenticator: str
    storage_selection: str
    storage_name: Optional[str]
    attachment_field_context: Optional[str]
    api: NocoBaseApiPaths
    response_data_key: Optional[str]
    config_token: Optional[str] = field(repr=False)
    source_path: Path
    licence_renewal_update_enabled: bool = False
    prosecution_update_enabled: bool = False
    changing_home_operator_replacement_enabled: bool = False

    @classmethod
    def load(cls, path: Path) -> NocoBaseProfile:
        if not path.is_file():
            raise ConfigurationError(
                f"NocoBase configuration file does not exist: {path}"
            )
        try:
            document = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as exc:
            raise ConfigurationError(
                f"NocoBase configuration is invalid YAML: {path}"
            ) from exc
        if not isinstance(document, dict):
            raise ConfigurationError("nocobase.yaml root must be an object")
        raw = document.get("nocobase")
        if not isinstance(raw, dict):
            raise ConfigurationError("nocobase.yaml must contain nocobase")

        raw_storage = _require_mapping(raw, "storage")
        raw_api = _require_mapping(raw, "api")
        raw_response = raw.get("response") or {}
        if not isinstance(raw_response, dict):
            raise ConfigurationError("nocobase.response must be an object")
        raw_features = raw.get("features") or {}
        if not isinstance(raw_features, dict):
            raise ConfigurationError("nocobase.features must be an object")
        lrn_update_enabled = raw_features.get("licence_renewal_update", False)
        if not isinstance(lrn_update_enabled, bool):
            raise ConfigurationError(
                "nocobase.features.licence_renewal_update must be true or false"
            )
        prosecution_update_enabled = raw_features.get("prosecution_update", False)
        if not isinstance(prosecution_update_enabled, bool):
            raise ConfigurationError(
                "nocobase.features.prosecution_update must be true or false"
            )
        chi_operators_enabled = raw_features.get(
            "changing_home_operator_replacement", False
        )
        if not isinstance(chi_operators_enabled, bool):
            raise ConfigurationError(
                "nocobase.features.changing_home_operator_replacement "
                "must be true or false"
            )

        base_url = os.getenv(
            "NOCOBASE_BASE_URL", str(raw.get("base_url", ""))
        ).strip().rstrip("/")
        storage_selection = os.getenv(
            "NOCOBASE_STORAGE_SELECTION",
            str(raw_storage.get("selection", "default")),
        ).strip().lower()
        configured_name = raw_storage.get("name")
        if "NOCOBASE_STORAGE_NAME" in os.environ:
            configured_name = os.environ["NOCOBASE_STORAGE_NAME"]
        storage_name = str(configured_name or "").strip() or None
        if storage_selection == "default":
            storage_name = None
        configured_attachment_field = raw_storage.get(
            "attachment_field_context"
        )
        if "NOCOBASE_ATTACHMENT_FIELD_CONTEXT" in os.environ:
            configured_attachment_field = os.environ[
                "NOCOBASE_ATTACHMENT_FIELD_CONTEXT"
            ]
        attachment_field_context = (
            str(configured_attachment_field or "").strip() or None
        )

        api = NocoBaseApiPaths(
            auth_sign_in=_read_path(
                raw_api, "auth_sign_in", default="/api/auth:signIn"
            ),
            auth_check=_read_path(raw_api, "auth_check"),
            simple_test=_read_path(raw_api, "simple_test"),
            homerecord_query=_read_path(raw_api, "homerecord_query"),
            request_staging_create=_read_path(
                raw_api, "request_staging_create"
            ),
            storage_basic_info=_read_path(raw_api, "storage_basic_info"),
            storage_basic_info_by_name=_read_path(
                raw_api, "storage_basic_info_by_name"
            ),
            create_presigned_url=_read_path(
                raw_api, "create_presigned_url"
            ),
            attachment_create=_read_path(raw_api, "attachment_create"),
            attachment_download=_read_endpoint_path(
                raw_api, "attachment_download"
            ),
        )
        configured_token = raw.get("config_token")
        if configured_token is not None and not isinstance(
            configured_token, str
        ):
            raise ConfigurationError(
                "nocobase.config_token must be a string or null"
            )

        profile = cls(
            version=str(raw.get("version", "")).strip(),
            base_url=base_url,
            authenticator=os.getenv(
                "NOCOBASE_AUTHENTICATOR",
                str(raw.get("authenticator", "basic")),
            ).strip(),
            storage_selection=storage_selection,
            storage_name=storage_name,
            attachment_field_context=attachment_field_context,
            api=api,
            response_data_key=(
                str(raw_response.get("data_key", "data")).strip() or None
            ),
            config_token=(
                configured_token.strip() if configured_token else None
            ),
            source_path=path,
            licence_renewal_update_enabled=lrn_update_enabled,
            prosecution_update_enabled=prosecution_update_enabled,
            changing_home_operator_replacement_enabled=chi_operators_enabled,
        )
        profile.validate()
        return profile

    def validate(self) -> None:
        if not self.version:
            raise ConfigurationError("nocobase.version cannot be empty")
        if not self.authenticator:
            raise ConfigurationError("nocobase.authenticator cannot be empty")
        parsed = urlparse(self.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ConfigurationError(
                "nocobase.base_url must be an absolute http(s) URL"
            )
        if self.storage_selection not in {"default", "named"}:
            raise ConfigurationError(
                "nocobase.storage.selection must be default or named"
            )
        if self.storage_selection == "named" and not self.storage_name:
            raise ConfigurationError(
                "nocobase.storage.name is required when selection is named"
            )
        if self.attachment_field_context and (
            self.attachment_field_context.count(".") != 1
            or any(
                not part.strip()
                for part in self.attachment_field_context.split(".")
            )
        ):
            raise ConfigurationError(
                "nocobase.storage.attachment_field_context must use "
                "collection.field format"
            )
        _require_placeholders(
            self.api.storage_basic_info_by_name,
            "storage_basic_info_by_name",
            {"storage_name"},
        )
        _require_placeholders(
            self.api.attachment_download,
            "attachment_download",
            {"attachment_id"},
        )


def default_profile_path() -> Path:
    container_path = Path("/app/config/nocobase.yaml")
    local_path = Path(__file__).resolve().parents[1] / "config/nocobase.yaml"
    default = container_path if container_path.is_file() else local_path
    return Path(os.getenv("NOCOBASE_CONFIG_PATH", str(default)))


def _require_mapping(parent: dict[str, Any], key: str) -> dict[str, Any]:
    value = parent.get(key)
    if not isinstance(value, dict):
        raise ConfigurationError(f"nocobase.{key} must be an object")
    return value


def _read_path(
    parent: dict[str, Any], key: str, *, default: str = ""
) -> str:
    value = str(parent.get(key, default)).strip()
    if not value.startswith("/api/"):
        raise ConfigurationError(
            f"nocobase.api.{key} must start with /api/"
        )
    return value


def _read_endpoint_path(parent: dict[str, Any], key: str) -> str:
    value = str(parent.get(key, "")).strip()
    if not value.startswith("/") or value.startswith("//"):
        raise ConfigurationError(
            f"nocobase.api.{key} must be an absolute application path"
        )
    return value


def _require_placeholders(
    value: str, key: str, placeholders: set[str]
) -> None:
    missing = [item for item in sorted(placeholders) if f"{{{item}}}" not in value]
    if missing:
        raise ConfigurationError(
            f"nocobase.api.{key} is missing placeholders: {', '.join(missing)}"
        )
