from __future__ import annotations

import argparse
import hashlib
import os
import re
import sys
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import yaml

from .errors import ConfigurationError

LEGACY_ADAPTER_SERVICE = "nocobase-file-adapter-service"
ADAPTER_SERVICE_PREFIX = "nocobase-adapter-"
ADAPTER_HOST = "cmtf-adapter"
ADAPTER_PORT = 8080
ADAPTER_URL = f"http://{ADAPTER_HOST}:{ADAPTER_PORT}"
HEADER = (
    "# Generated from adapter.yaml. Do not place a Token in this file.\n"
)
PIN_PARAMETER = "adapter_profile_sha256"
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_PIN_LINE = re.compile(
    r'(?m)^(  - parameter: adapter_profile_sha256\n    value: )"([^"]*)"$'
)


def _load_mapping(path: Path) -> dict[str, Any]:
    try:
        document = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except FileNotFoundError as exc:
        raise ConfigurationError(f"configuration file is missing: {path}") from exc
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"invalid YAML: {path}") from exc
    if not isinstance(document, dict):
        raise ConfigurationError(f"YAML root must be an object: {path}")
    return document


def _nocobase_settings(
    path: Path, *, require_token: bool
) -> tuple[str, str | None]:
    document = _load_mapping(path)
    nocobase = document.get("nocobase")
    if not isinstance(nocobase, dict):
        raise ConfigurationError("adapter.yaml must contain nocobase")
    base_url = str(nocobase.get("base_url", "")).strip().rstrip("/")
    parsed = urlsplit(base_url)
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
    ):
        raise ConfigurationError(
            "nocobase.base_url must be an absolute http(s) URL without "
            "credentials, query, or fragment"
        )
    token_value = nocobase.get("config_token")
    if token_value is not None and not isinstance(token_value, str):
        raise ConfigurationError("nocobase.config_token must be a string or null")
    config_token = token_value.strip() if token_value else None
    if require_token and not config_token:
        raise ConfigurationError("nocobase.config_token is required")
    if require_token and parsed.hostname == "change-me.invalid":
        raise ConfigurationError("nocobase.base_url is still a placeholder")
    return base_url, config_token


def _profile_digest(path: Path) -> str:
    try:
        contents = path.read_bytes()
    except OSError as exc:
        raise ConfigurationError("adapter.yaml is unavailable") from exc
    if not contents or len(contents) > 262_144:
        raise ConfigurationError("adapter.yaml size is invalid")
    return hashlib.sha256(contents).hexdigest()


def _kong_profile_pin(document: dict[str, Any]) -> str:
    ignored = document.get("_ignore")
    if not isinstance(ignored, list):
        raise ConfigurationError("kong.yaml has no adapter profile pin")
    matches = [
        item.get("value")
        for item in ignored
        if isinstance(item, dict) and item.get("parameter") == PIN_PARAMETER
    ]
    if len(matches) != 1 or not isinstance(matches[0], str):
        raise ConfigurationError("kong.yaml must have one adapter profile pin")
    return matches[0]


def pinned_profile_digest(kong_path: Path, nocobase_path: Path) -> str:
    """Verify a cross-file pin without exposing the NocoBase Token."""
    pin = _kong_profile_pin(_load_mapping(kong_path))
    if not _SHA256.fullmatch(pin):
        raise ConfigurationError("kong.yaml adapter profile pin is invalid")
    if pin != _profile_digest(nocobase_path):
        raise ConfigurationError("kong.yaml adapter profile pin does not match")
    return pin


def pin_runtime(kong_path: Path, nocobase_path: Path) -> str:
    """Atomically pin the populated Adapter YAML in the matching Kong YAML."""
    validate_runtime(kong_path, nocobase_path, require_token=True)
    document = _load_mapping(kong_path)
    _kong_profile_pin(document)
    try:
        original = kong_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigurationError("kong.yaml is unavailable") from exc
    digest = _profile_digest(nocobase_path)
    updated, count = _PIN_LINE.subn(
        lambda match: match.group(1) + f'"{digest}"', original
    )
    if count != 1:
        raise ConfigurationError("kong.yaml adapter profile pin is not editable")
    mode = kong_path.stat().st_mode & 0o777
    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=kong_path.parent,
            prefix=f".{kong_path.name}.", delete=False,
        ) as handle:
            temporary = handle.name
            handle.write(updated)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, kong_path)
    finally:
        if temporary is not None and os.path.exists(temporary):
            os.unlink(temporary)
    pinned_profile_digest(kong_path, nocobase_path)
    return digest


def _is_adapter_service(name: object) -> bool:
    return name == LEGACY_ADAPTER_SERVICE or (
        isinstance(name, str) and name.startswith(ADAPTER_SERVICE_PREFIX)
    )


def _set_service_target(
    service: dict[str, Any],
    *,
    url: str,
    legacy_target: dict[str, Any],
) -> None:
    """Set a service target without breaking legacy component templates.

    New portable templates use Kong's ``url`` shorthand so the complete
    upstream is configured as one value. Older templates used separate
    protocol/host/port/path fields and remain supported.
    """
    if "url" in service:
        service["url"] = url
        for key in ("protocol", "host", "port", "path"):
            service.pop(key, None)
        return

    service.pop("url", None)
    for key in ("protocol", "host", "port", "path"):
        if key not in legacy_target:
            service.pop(key, None)
    service.update(legacy_target)


def _validate_service_target(
    service: dict[str, Any],
    *,
    expected_url: str,
    legacy_target: dict[str, Any],
    error_message: str,
) -> None:
    if "url" in service:
        if service.get("url") != expected_url:
            raise ConfigurationError(error_message)
        return

    actual = {key: service.get(key) for key in legacy_target}
    if actual != legacy_target:
        raise ConfigurationError(error_message)


def render_kong_config(template_path: Path, nocobase_path: Path) -> str:
    template = _load_mapping(template_path)
    template_text = template_path.read_text(encoding="utf-8")
    services = template.get("services")
    if not isinstance(services, list):
        raise ConfigurationError("Kong template must contain services")
    _nocobase_settings(nocobase_path, require_token=False)
    result = deepcopy(template)
    adapter_services = 0
    for service in result["services"]:
        if not isinstance(service, dict):
            raise ConfigurationError("Kong services must be objects")
        name = service.get("name")
        if _is_adapter_service(name):
            _set_service_target(
                service,
                url=ADAPTER_URL,
                legacy_target={
                    "protocol": "http",
                    "host": ADAPTER_HOST,
                    "port": ADAPTER_PORT,
                },
            )
            adapter_services += 1
        else:
            raise ConfigurationError(f"unexpected Kong service: {name}")
    if adapter_services < 1:
        raise ConfigurationError("Kong template requires adapter services")

    # The portable template deliberately keeps all editable settings and policy
    # explanations as YAML comments and named anchors.  When every service uses
    # Kong's URL shorthand, replace only the URL scalar values in the original
    # text so those comments and anchors survive generation.  Legacy component
    # templates still use the object/dump path below.
    if all(isinstance(service, dict) and "url" in service for service in services):
        rendered = template_text
        for original, updated in zip(services, result["services"]):
            original_url = str(original["url"])
            updated_url = str(updated["url"])
            if original_url == updated_url:
                continue
            if original_url not in rendered:
                raise ConfigurationError(
                    f"Kong service URL is not replaceable in template: "
                    f"{original.get('name')}"
                )
            rendered = rendered.replace(original_url, updated_url, 1)
        return rendered

    return HEADER + yaml.safe_dump(
        result,
        allow_unicode=True,
        sort_keys=False,
        width=100,
    )


def validate_runtime(
    kong_path: Path,
    nocobase_path: Path,
    *,
    require_token: bool,
    require_pin: bool = False,
) -> None:
    document = _load_mapping(kong_path)
    services = document.get("services")
    if not isinstance(services, list):
        raise ConfigurationError("Kong runtime must contain services")
    _nocobase_settings(nocobase_path, require_token=require_token)
    adapter_services = 0
    for service in services:
        if not isinstance(service, dict):
            raise ConfigurationError("Kong services must be objects")
        name = service.get("name")
        if _is_adapter_service(name):
            _validate_service_target(
                service,
                expected_url=ADAPTER_URL,
                legacy_target={
                    "protocol": "http",
                    "host": ADAPTER_HOST,
                    "port": ADAPTER_PORT,
                },
                error_message="Kong adapter target is invalid",
            )
            adapter_services += 1
        else:
            raise ConfigurationError(f"unexpected Kong service: {name}")
    if adapter_services < 1:
        raise ConfigurationError("Kong runtime requires adapter services")
    if require_pin:
        pinned_profile_digest(kong_path, nocobase_path)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Render and validate portable Kong/NocoBase runtime YAML"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    render = subparsers.add_parser("render")
    render.add_argument("--template", type=Path, required=True)
    render.add_argument("--nocobase", type=Path, required=True)
    render.add_argument("--output", type=Path)
    validate = subparsers.add_parser("validate")
    validate.add_argument("--kong", type=Path, required=True)
    validate.add_argument("--nocobase", type=Path, required=True)
    validate.add_argument("--allow-empty-token", action="store_true")
    validate.add_argument("--require-pin", action="store_true")
    pin = subparsers.add_parser("pin")
    pin.add_argument("--kong", type=Path, required=True)
    pin.add_argument("--nocobase", type=Path, required=True)
    args = parser.parse_args()

    try:
        if args.command == "render":
            rendered = render_kong_config(args.template, args.nocobase)
            if args.output:
                args.output.write_text(rendered, encoding="utf-8")
                print(f"generated={args.output}")
            else:
                sys.stdout.write(rendered)
        elif args.command == "validate":
            validate_runtime(
                args.kong,
                args.nocobase,
                require_token=not args.allow_empty_token,
                require_pin=args.require_pin,
            )
            print("portable_configuration=valid")
        else:
            pin_runtime(args.kong, args.nocobase)
            print("portable_profile_pin=updated")
    except ConfigurationError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
