"""Fail-closed activation from the two portable runtime YAML files.

The distributed templates are inert.  A populated adapter.yaml is pinned by
kong.yaml, and the existing reviewed UPDATE release contract still validates
every enabled family against its target NocoBase environment.  The pin is an
operational cross-check, not a signature or proof that the cited tests passed.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .errors import ConfigurationError
from .portable_config import _load_mapping, pinned_profile_digest, validate_runtime
from .update_queue_service import PUBLIC_UPDATE_QUEUE_TYPES

if TYPE_CHECKING:
    from .settings import Settings


@dataclass(frozen=True)
class PortableRuntimeActivation:
    profile_sha256: str
    deployment_env: str
    source_system: str
    https_bind: str
    https_port: str
    create_idempotency_index_ready: bool
    update_queue_enabled: bool
    update_queue_families: frozenset[str]


def _exact_mapping(value: Any, keys: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != keys:
        raise ConfigurationError(f"portable {label} has invalid keys")
    return value


def load_portable_runtime(
    *, settings: Settings, kong_path: Path,
) -> PortableRuntimeActivation:
    """Validate two YAMLs and bind them to the fixed Docker-run environment."""
    # A YAML pin cannot attest to values silently overridden by container
    # environment variables.  Portable deployments use the two mounted YAMLs
    # as their only source for these NocoBase settings.
    forbidden_overrides = (
        "NOCOBASE_BASE_URL",
        "NOCOBASE_AUTHENTICATOR",
        "NOCOBASE_CONFIG_TOKEN",
        "NOCOBASE_CONFIG_TOKEN_FILE",
        "NOCOBASE_STORAGE_SELECTION",
        "NOCOBASE_STORAGE_NAME",
        "NOCOBASE_ATTACHMENT_FIELD_CONTEXT",
    )
    if any(os.getenv(name) for name in forbidden_overrides):
        raise ConfigurationError(
            "portable NocoBase environment overrides are not allowed"
        )
    profile_path = settings.nocobase.source_path
    validate_runtime(kong_path, profile_path, require_token=True, require_pin=True)
    document = _load_mapping(profile_path)
    deployment = _exact_mapping(
        document.get("portable_deployment"),
        {
            "schema_version", "deployment_env", "source_system", "https_bind",
            "https_port", "create_idempotency", "update_queue",
        },
        "deployment",
    )
    if (
        type(deployment["schema_version"]) is not int
        or deployment["schema_version"] != 1
    ):
        raise ConfigurationError("portable deployment schema version is unsupported")
    binding = {
        "deployment_env": os.getenv("DEPLOYMENT_ENV", ""),
        "source_system": settings.source_system,
        "https_bind": os.getenv("KONG_HTTPS_BIND", ""),
        "https_port": os.getenv("KONG_HTTPS_PORT", ""),
    }
    if any(deployment[key] != value for key, value in binding.items()):
        raise ConfigurationError("portable deployment binding does not match")
    if binding["deployment_env"] not in {"local_test", "online_test"}:
        raise ConfigurationError("portable deployment environment is unsupported")

    create = _exact_mapping(
        deployment["create_idempotency"], {"enabled", "evidence"},
        "Create idempotency",
    )
    if type(create["enabled"]) is not bool or not isinstance(create["evidence"], str):
        raise ConfigurationError("portable Create idempotency settings are invalid")
    if create["enabled"] and not 8 <= len(create["evidence"].strip()) <= 512:
        raise ConfigurationError("portable Create idempotency evidence is missing")
    if not create["enabled"] and create["evidence"].strip():
        raise ConfigurationError("portable disabled Create idempotency has evidence")

    queue = _exact_mapping(
        deployment["update_queue"], {"enabled", "families"}, "UPDATE queue",
    )
    if type(queue["enabled"]) is not bool or not isinstance(queue["families"], list):
        raise ConfigurationError("portable UPDATE queue settings are invalid")
    families = queue["families"]
    if (
        any(not isinstance(name, str) or not name for name in families)
        or len(families) != len(set(families))
        or set(families) - PUBLIC_UPDATE_QUEUE_TYPES
    ):
        raise ConfigurationError("portable UPDATE queue families are invalid")
    enabled_families = frozenset(families)
    if not queue["enabled"] and enabled_families:
        raise ConfigurationError("portable disabled UPDATE queue has families")
    if queue["enabled"] and not enabled_families:
        raise ConfigurationError(
            "portable UPDATE queue requires at least one reviewed family"
        )
    if queue["enabled"] and not isinstance(document.get("update_queue_release"), dict):
        raise ConfigurationError("portable UPDATE queue release evidence is missing")
    return PortableRuntimeActivation(
        profile_sha256=pinned_profile_digest(kong_path, profile_path),
        deployment_env=binding["deployment_env"],
        source_system=binding["source_system"],
        https_bind=binding["https_bind"],
        https_port=binding["https_port"],
        create_idempotency_index_ready=create["enabled"],
        update_queue_enabled=queue["enabled"],
        update_queue_families=enabled_families,
    )
