from __future__ import annotations

import copy
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Optional, Union

from .errors import AdapterError
from .nocobase_client import NocoBaseClient

ScalarId = Union[int, str]

NEW_LICENCE_REQUEST_TYPE = "create_intake_for_new_licence"
NEW_LICENCE_APPLICATION_TYPE = "new_licence"
NEW_LICENCE_APPLICATION_TYPE_NAME = "New Licence Applications"
CMTF_SOURCE_SYSTEM = "CMTF"
CHANGING_HOME_REQUEST_TYPE = "create_intake_for_changing_home"
CHANGING_HOME_APPLICATION_TYPE = "changing_home"
CHANGING_HOME_APPLICATION_TYPE_NAME = "Changing Home Information Application"
SELF_WITHDRAW_REQUEST_TYPE = "create_intake_for_self_withdraw"
SELF_WITHDRAW_APPLICATION_TYPE = "self_withdraw"
SELF_WITHDRAW_APPLICATION_TYPE_NAME = "Closure - Self-withdraw Licence"
REVOKE_LICENCE_REQUEST_TYPE = "create_intake_for_revoke_licence"
REVOKE_LICENCE_APPLICATION_TYPE = "revoke_licence"
REVOKE_LICENCE_APPLICATION_TYPE_NAME = "Closure - Revoke Licence"
CLOSURE_APPLICATION_COLLECTION = "t_self_withdraw_licence_application"
SPECIFIC_HOUR_REQUEST_TYPE = "create_intake_for_specific_hour"
SPECIFIC_HOUR_APPLICATION_TYPE = "specific_hour"
SPECIFIC_HOUR_APPLICATION_TYPE_NAME = "Specific Hour Application"
SPECIFIC_HOUR_APPLICATION_COLLECTION = "t_specific_hour_app"
RESPONSIBLE_PERSON_REQUEST_TYPE = "create_intake_for_rp"
RESPONSIBLE_PERSON_APPLICATION_TYPE = "responsible_person"
RESPONSIBLE_PERSON_APPLICATION_TYPE_NAME = "Proposal of a Responsible Person (RP)"
RESPONSIBLE_PERSON_APPLICATION_COLLECTION = "t_rp_application"
CHANGE_MONITORING_COLLECTION = "t_change_monitoring_base"
CHANGE_HOME_MANAGER_REQUEST_TYPE = "create_intake_for_change_home_manager"
CHANGE_HOME_MANAGER_APPLICATION_TYPE = "change_home_manager"
CHANGE_HOME_MANAGER_APPLICATION_TYPE_NAME = "Change of Home Manager (Home Profile)"
CHANGE_BEDS_REQUEST_TYPE = "create_intake_for_change_beds"
CHANGE_BEDS_APPLICATION_TYPE = "change_beds"
CHANGE_BEDS_APPLICATION_TYPE_NAME = "Change of No. of Beds / Layout (Home Profile)"
CHANGE_OPERATION_MODE_REQUEST_TYPE = "create_intake_for_change_operation_mode"
CHANGE_OPERATION_MODE_APPLICATION_TYPE = "change_operation_mode"
CHANGE_OPERATION_MODE_APPLICATION_TYPE_NAME = "Change of Home Type (Home Profile)"
CHANGE_DIRECTORS_REQUEST_TYPE = "create_intake_for_change_directors"
CHANGE_DIRECTORS_APPLICATION_TYPE = "change_directors"
CHANGE_DIRECTORS_APPLICATION_TYPE_NAME = "Change of Directors Monitoring"
CHANGE_NURSE_REQUEST_TYPE = "create_intake_for_change_nurse_in_charge"
CHANGE_NURSE_APPLICATION_TYPE = "change_nurse_in_charge"
CHANGE_NURSE_APPLICATION_TYPE_NAME = "Change of Nurse-in-Charge Monitoring"
PROSECUTION_REQUEST_TYPE = "create_intake_for_prosecution"
PROSECUTION_APPLICATION_TYPE = "prosecution"
PROSECUTION_APPLICATION_TYPE_NAME = "Prosecution"
PROSECUTION_APPLICATION_COLLECTION = "t_prosecution_conviction_records"
LICENCE_RENEWAL_REQUEST_TYPE = "create_licence_renewal"
LICENCE_RENEWAL_APPLICATION_TYPE = "licence_renewal"
LICENCE_RENEWAL_APPLICATION_TYPE_NAME = "Licence Renewal Application"
LICENCE_RENEWAL_APPLICATION_COLLECTION = "t_licence_renewal_app"
EXPANSION_AIP_REQUEST_TYPE = "create_intake_for_expansion_aip"
EXPANSION_AIP_APPLICATION_TYPE = "expansion_aip"
EXPANSION_AIP_APPLICATION_TYPE_NAME = "Expansion AIP for Licence"
EXPANSION_AIP_APPLICATION_COLLECTION = "t_expansion_aip_for_licence"
CHANGE_MONITORING_QUERY_TYPES = {
    CHANGE_HOME_MANAGER_REQUEST_TYPE: (
        CHANGE_HOME_MANAGER_APPLICATION_TYPE,
        CHANGE_HOME_MANAGER_APPLICATION_TYPE_NAME,
        "f_change_home_manager",
    ),
    CHANGE_BEDS_REQUEST_TYPE: (
        CHANGE_BEDS_APPLICATION_TYPE,
        CHANGE_BEDS_APPLICATION_TYPE_NAME,
        "f_change_beds",
    ),
    CHANGE_OPERATION_MODE_REQUEST_TYPE: (
        CHANGE_OPERATION_MODE_APPLICATION_TYPE,
        CHANGE_OPERATION_MODE_APPLICATION_TYPE_NAME,
        "f_change_home_type",
    ),
    CHANGE_DIRECTORS_REQUEST_TYPE: (
        CHANGE_DIRECTORS_APPLICATION_TYPE,
        CHANGE_DIRECTORS_APPLICATION_TYPE_NAME,
        "f_change_directors_information",
    ),
    CHANGE_NURSE_REQUEST_TYPE: (
        CHANGE_NURSE_APPLICATION_TYPE,
        CHANGE_NURSE_APPLICATION_TYPE_NAME,
        "f_change_nurse_in_charge",
    ),
}

# A public Query is keyed by the CREATE row, but its request_id tracks the
# latest accepted request for that application.  Bind UPDATE rows to the
# CREATE API type so an unrelated or invalid Staging row cannot replace it.
UPDATE_API_TYPES_BY_CREATE_TYPE = {
    NEW_LICENCE_REQUEST_TYPE: "update_new_licence_data",
    CHANGING_HOME_REQUEST_TYPE: "update_changing_home_data",
    SELF_WITHDRAW_REQUEST_TYPE: "update_self_withdraw_data",
    REVOKE_LICENCE_REQUEST_TYPE: "update_revoke_licence_data",
    SPECIFIC_HOUR_REQUEST_TYPE: "update_specific_hour_data",
    RESPONSIBLE_PERSON_REQUEST_TYPE: "update_rp_data",
    CHANGE_HOME_MANAGER_REQUEST_TYPE: "update_change_home_manager_data",
    CHANGE_BEDS_REQUEST_TYPE: "update_change_beds_data",
    CHANGE_OPERATION_MODE_REQUEST_TYPE: "update_change_operation_mode_data",
    CHANGE_DIRECTORS_REQUEST_TYPE: "update_change_directors_data",
    CHANGE_NURSE_REQUEST_TYPE: "update_change_nurse_in_charge_data",
    PROSECUTION_REQUEST_TYPE: "update_prosecution_data",
    LICENCE_RENEWAL_REQUEST_TYPE: "update_licence_renewal_data",
    EXPANSION_AIP_REQUEST_TYPE: "update_expansion_aip_data",
}
ACCEPTED_UPDATE_STAGING_STATUSES = frozenset(
    {"queued", "submitted", "processing", "needs_review", "succeeded"}
)

INTAKE_STATUS_OPTIONS = [
    {"value": "0", "label": "Draft"},
    {"value": "2", "label": "Closed"},
    {"value": "3", "label": "Returned"},
    {"value": "4", "label": "Completed"},
    {"value": "5", "label": "Pending Recommendation"},
    {"value": "6", "label": "Pending Approval for Case Closure"},
    {"value": "7", "label": "Pending Inspection"},
]

APPLICATION_STATUS_OPTIONS = [
    {"value": "0", "label": "Draft"},
    {"value": "2", "label": "Closed"},
    {"value": "3", "label": "Returned"},
    {"value": "4", "label": "Completed"},
    {"value": "5", "label": "Auto Assign ITs"},
    {"value": "6", "label": "Assigning Inspection Teams"},
    {"value": "15", "label": "Issue Acknowledgement Letter to RCH"},
    {"value": "7", "label": "Pending Initial Inspection"},
    {"value": "13", "label": "Pending SWO Approval - Initial Inspection"},
    {"value": "8", "label": "Issue Confirmation Letter to RCH"},
    {"value": "9", "label": "Pending Full Inspection"},
    {"value": "14", "label": "Pending SWO Approval - Full Inspection"},
    {"value": "10", "label": "Pending SSWO Approval"},
    {"value": "11", "label": "Pending CSWO Approval"},
    {"value": "12", "label": "Pending AD Approval"},
    {"value": "16", "label": "Close Pending"},
]

NEW_LICENCE_LETTER_CATEGORY_OPTIONS = [
    {"value": "a", "label": "Acknowledgement Letter"},
    {"value": "b", "label": "Confirmation Letter"},
    {"value": "c", "label": "Cover Letter"},
    {"value": "d", "label": "Notification letter"},
    {"value": "e", "label": "SoA"},
    {"value": "f", "label": "New Licence Letter"},
]

# Translate the established NocoBase letter codes to the public v0.8.1
# Notice Type Values.  Native `e` is labelled SoA / Statement of Account,
# whereas the specification says advice_statement / Statement of Advice;
# leave `e` untouched until that business meaning is confirmed.
PUBLIC_NOTICE_TYPES_BY_NATIVE_CODE = {
    "a": "acknowledgement_letter",
    "b": "confirmation_letter",
    "c": "cover_letter",
    "d": "notification_letter",
    "f": "new_licence_letter",
}

PUBLIC_ENUMS = {
    "request_status": [
        {"value": "received", "label": "Received"},
        {"value": "processing", "label": "Processing"},
        {"value": "succeeded", "label": "Succeeded"},
        {"value": "failed", "label": "Failed"},
        {"value": "missing_required", "label": "Missing required fields"},
        {"value": "invalid_request", "label": "Invalid request"},
    ],
    "office_code": [
        {"value": "LORCHE", "label": "LORCHE"},
        {"value": "LORCHD", "label": "LORCHD"},
    ],
    "intake_status": INTAKE_STATUS_OPTIONS,
    "application_status": APPLICATION_STATUS_OPTIONS,
    "severity": [
        {"value": "0", "label": "Normal"},
        {"value": "1", "label": "Alert (to SWO level)"},
        {"value": "2", "label": "Alert (to SSWO level)"},
    ],
    "application_type": [
        {"value": "0", "label": "New / first application"},
        {"value": "1", "label": "Configured native option"},
    ],
    "premises_type": [
        {"value": "0", "label": "Self-owned property"},
        {"value": "1", "label": "Rented premises"},
        {"value": "2", "label": "Partially self-owned and rented"},
        {"value": "3", "label": "Situated on leased government land"},
    ],
    "gender": [
        {"value": "1", "label": "Male"},
        {"value": "2", "label": "Female"},
        {"value": "0", "label": "Both"},
    ],
    "rch_business_status": [
        {"value": "0", "label": "Proposed service/business"},
        {"value": "1", "label": "Existing service/business"},
    ],
    "applicant_operator_type": [
        {"value": "0", "label": "Sole proprietorship"},
        {"value": "1", "label": "Partnership"},
        {"value": "2", "label": "Body corporate"},
        {"value": "3", "label": "Body corporate (NGO)"},
    ],
    "application_level": [
        {"value": "normal", "label": "Normal"},
        {"value": "high", "label": "High"},
    ],
    "checklist_status": [
        {"value": "1", "label": "Submitted"},
        {"value": "2", "label": "Not applicable"},
        {"value": "3", "label": "Please submit"},
        {"value": "4", "label": "Amend / resubmit"},
        {"value": "5", "label": "Transferred"},
    ],
    "block_type_en": [
        {"value": "0", "label": "Block"},
        {"value": "1", "label": "Tower"},
        {"value": "2", "label": "House"},
        {"value": "3", "label": "Other"},
    ],
    "block_type_cn": [
        {"value": "0", "label": "座數"},
        {"value": "1", "label": "洋房"},
        {"value": "2", "label": "住宅"},
        {"value": "3", "label": "其他"},
    ],
    "unit_type_en": [
        {"value": "0", "label": "Flat"},
        {"value": "1", "label": "Shop"},
        {"value": "2", "label": "Suite"},
        {"value": "3", "label": "Room"},
        {"value": "4", "label": "Other"},
    ],
    "unit_type_cn": [
        {"value": "0", "label": "室"},
        {"value": "1", "label": "舖"},
        {"value": "2", "label": "套房"},
        {"value": "3", "label": "房"},
        {"value": "4", "label": "其他"},
    ],
}

CHECKLIST_SPECIAL_NAMES = {
    "(ii) Fire Service Installation Plans for Prescribed Commercial "
    "Premises/Specified Commercial Buildings (FSI/314B); or": "FSI_314B",
    "(iii) Fire Service Installation Plans for Composite Building/Domestic "
    "Building (FSI/314C); (as appropriate). Relevant fire service installation "
    "plan(s) with the stamp of the FSD and subsequent reply from the D of FS "
    "shall be included.": "FSI_314C",
    "Elderly Home Licence Application Form": ("ELDERLY_HOME_LICENCE_APPLICATION_FORM"),
    "proof of Address (e.g. rates demand note, utility bills such as "
    "water/electricity)": "PROOF_OF_ADDRESS",
}

ADDRESS_RELATION_APPENDS = (
    "f_region_en",
    "f_district_name_en",
    "f_sub_district_en",
)

APPLICATION_APPENDS = (
    "f_intake_form",
    "f_intake_form.f_activity",
    "f_intake_form.f_activity.f_attachments",
    "f_rch_address",
    *(f"f_rch_address.{name}" for name in ADDRESS_RELATION_APPENDS),
    "f_type_of_rch",
    "f_licence_contact_applicant",
    "f_licence_contact_applicant.f_address_correspondence",
    *(
        f"f_licence_contact_applicant.f_address_correspondence.{name}"
        for name in ADDRESS_RELATION_APPENDS
    ),
    "f_licence_contact_operator",
    "f_licence_contact_operator.f_address_correspondence",
    *(
        f"f_licence_contact_operator.f_address_correspondence.{name}"
        for name in ADDRESS_RELATION_APPENDS
    ),
    "f_licence_contact_company",
    "f_licence_contact_company.f_address_correspondence",
    *(
        f"f_licence_contact_company.f_address_correspondence.{name}"
        for name in ADDRESS_RELATION_APPENDS
    ),
    "f_licence_contact_person",
    "f_licence_contact_person.f_address_correspondence",
    *(
        f"f_licence_contact_person.f_address_correspondence.{name}"
        for name in ADDRESS_RELATION_APPENDS
    ),
    "f_licence_app_premise",
    "f_licence_app_premise.f_address_self_owned",
    *(
        f"f_licence_app_premise.f_address_self_owned.{name}"
        for name in ADDRESS_RELATION_APPENDS
    ),
    "f_licence_app_premise.f_address_rented",
    *(
        f"f_licence_app_premise.f_address_rented.{name}"
        for name in ADDRESS_RELATION_APPENDS
    ),
    "f_attachments_of_rchs",
    "f_documents_submitted",
    "f_documents_submitted.f_document_checklist",
    "f_documents_submitted.f_lastest_files",
    "f_documents_submitted.f_details",
    "f_documents_submitted.f_details.f_files",
    "f_letter_attachments",
    "f_letter_attachments.f_attachment",
)

# ``GET /v1/request/{create_id}`` returns generated correspondence exclusively
# through ``notices``.  Keep the broader append set for legacy list endpoints,
# but do not fetch Letter Attachment rows, checklist upload history, or Intake
# activity history for the unified request projection.
REQUEST_APPLICATION_APPENDS = tuple(
    item
    for item in APPLICATION_APPENDS
    if not item.startswith("f_letter_attachments")
    and not item.startswith("f_documents_submitted.f_details")
    and not item.startswith("f_intake_form.f_activity")
)

INTAKE_APPENDS = (
    "f_activity",
    "f_activity.f_attachments",
    "t_new_licence_application",
    *(
        f"t_new_licence_application.{name}"
        for name in APPLICATION_APPENDS
        if not name.startswith("f_intake_form")
    ),
)

CHANGING_HOME_APPENDS = (
    "f_intake_form",
    "f_intake_form.f_activity",
    "f_intake_form.f_activity.f_attachments",
    "f_home_record",
    "f_rch_address",
    *(f"f_rch_address.{name}" for name in ADDRESS_RELATION_APPENDS),
    "f_type_of_rch",
    "f_licence_contact_applicant",
    "f_licence_contact_applicant.f_address_correspondence",
    "f_licence_contact_company",
    "f_licence_contact_company.f_address_correspondence",
    "f_licence_contact_company.f_rpop_op_app",
    *(f"f_licence_contact_company.f_rpop_app_detail_{slot}" for slot in range(1, 11)),
    "f_licence_contact_person",
    "f_licence_contact_person.f_address_correspondence",
    *(f"f_licence_contact_person.f_rpop_app_detail_{slot}" for slot in range(1, 11)),
    "f_tenancy_agreements",
    "f_tenancy_agreements.f_address_self_owned",
    "f_tenancy_agreements.f_address_rented",
    "f_attachments_of_rchs",
)

CHANGING_HOME_CHECKLIST_APPENDS = (
    "f_document_checklist",
    "f_lastest_files",
)

CLOSURE_APPENDS = (
    "f_intake_form",
    "f_intake_form.createdBy",
    "f_intake_form.fk_intake_source",
    "f_intake_form.fk_task_owner",
    "f_intake_form.fk_task_owner_post",
    "f_intake_form.f_activity",
    "f_intake_form.f_activity.f_attachments",
)

EXPANSION_AIP_APPENDS = (
    "f_intake_form",
    "f_intake_form.createdBy",
    "f_intake_form.fk_intake_source",
    "f_intake_form.fk_task_owner",
    "f_intake_form.fk_task_owner_post",
)

SPECIFIC_HOUR_APPENDS = (
    "f_intake_form",
    "f_intake_form.createdBy",
    "f_intake_form.fk_intake_source",
    "f_intake_form.fk_task_owner",
    "f_intake_form.fk_task_owner_post",
    "f_home_record",
    "f_specific_hour_options",
    "f_specific_hour_options.f_specific_hour_staffings",
    "f_specific_hour_options.f_specific_hour_staffings.f_staff_type_id",
    "f_specific_hour_options.f_specific_hour_staffings.f_specific_hour_time_rows",
)

RESPONSIBLE_PERSON_APPENDS = (
    "fk_intake",
    "fk_intake.createdBy",
    "fk_intake.fk_intake_source",
    "fk_intake.fk_task_owner",
    "fk_intake.fk_task_owner_post",
    "f_home_record",
    "f_t_rp_currently_appointed",
)

ADDRESS_FIELDS = {
    "full_name_en": "f_fullname_en",
    "full_name_cn": "f_fullname_cn",
    "lot_or_address_en": "f_lot_or_address_en",
    "lot_or_address_cn": "f_lot_or_address_cn",
    "block_no_en": "f_block_no_en",
    "block_no_cn": "f_block_no_cn",
    "block_type_en": "f_block_type_en",
    "block_type_cn": "f_block_type_cn",
    "floor_en": "f_floor_num_en",
    "floor_cn": "f_floor_num_cn",
    "unit_no_en": "f_unit_no_en",
    "unit_no_cn": "f_unit_no_cn",
    "unit_type_en": "f_unit_type_en",
    "unit_type_cn": "f_unit_type_cn",
    "building_name_en": "f_building_name_en",
    "building_name_cn": "f_building_name_cn",
    "estate_or_village_en": "f_estate_or_village_name_en",
    "estate_or_village_cn": "f_estate_or_village_name_cn",
    "street_no_en": "f_street_no_en",
    "street_no_cn": "f_street_no_cn",
    "street_name_en": "f_street_name_en",
    "street_name_cn": "f_street_name_cn",
    "phase_en": "f_phase_en",
    "phase_cn": "f_phase_cn",
}

CONTACT_FIELDS = {
    "title": "f_person_title",
    "display_name": "f_display_name",
    "full_name_en": "f_full_name_en",
    "full_name_cn": "f_full_name_cn",
    "first_name_en": "f_name_en_first",
    "middle_name_en": "f_name_en_middle",
    "last_name_en": "f_name_en_last",
    "surname_cn": "f_name_cn_sur",
    "given_name_cn": "f_name_cn_given",
    "hkid_part_1": "f_hkid_no_1",
    "hkid_part_2": "f_hkid_no_2",
    "hkid_part_3": "f_hkid_no_3",
    "position_title": "f_position_title",
    "representative_position": "f_representative_position",
    "contact_relationship": "f_contact_relationship",
    "contact_relationship_other": "f_contact_relationship_other",
    "mobile_phone": "f_mobile_phone",
    "residential_phone": "f_residential_phone",
    "office_phone": "f_office_phone",
    "email": "f_email",
    "office_email": "f_office_email",
    "company_name_en": "f_compnay_name_en",
    "company_name_cn": "f_company_name_cn",
    "business_registration_no": "f_business_registration_no",
    "certificate_of_incorporation_no": "f_certificate_of_incorporation_no",
    "application_type": "f_body_corporate_application_type",
    "address_for_licence": "f_address_for_licence",
    "active": "f_is_active",
}

ENUM_FIELD_TARGETS = {
    ("t_intake_form", "f_approval_status"): "intake_status",
    ("t_intake_form", "f_severity"): "severity",
    ("t_licence_app", "f_approval_status"): "application_status",
    ("t_licence_app", "f_app_type"): "application_type",
    ("t_licence_app", "f_application_level"): "application_level",
    ("t_home_record_base", "f_rch_premises"): "premises_type",
    ("t_home_record_base", "f_rch_gender"): "gender",
    ("t_home_record_base", "f_service_type"): "rch_business_status",
    ("t_home_record_base", "f_business_ownership_type"): ("applicant_operator_type"),
    ("t_document_submitted_for_application", "f_status"): "checklist_status",
    ("t_address", "f_block_type_en"): "block_type_en",
    ("t_address", "f_block_type_cn"): "block_type_cn",
    ("t_address", "f_unit_type_en"): "unit_type_en",
    ("t_address", "f_unit_type_cn"): "unit_type_cn",
}


class QueryService:
    def __init__(self, client: NocoBaseClient, source_system: str) -> None:
        self._client = client
        self._source_system = source_system.upper()
        # OP may query records created by the CMTF native UI after the
        # business workflow publishes their create_id at Received.  Other
        # source systems remain outside this integration boundary.
        self._queryable_source_systems = frozenset(
            {self._source_system, CMTF_SOURCE_SYSTEM}
        )
        self._enum_cache: Optional[dict[str, list[dict[str, str]]]] = None

    def _is_queryable_source(self, row: dict[str, Any]) -> bool:
        return (
            str(row.get("f_source_system") or "").upper()
            in self._queryable_source_systems
        )

    async def list_notices(
        self,
        *,
        create_id: ScalarId,
        request_id: str,
        authorization_token: str,
        application_type_label: Optional[str] = None,
        application_type_value: Optional[str] = None,
        current_status: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Return the compact Notice List linked to one public create_id.

        The caller's application label fills only an absent native intake type.
        """
        page_size = 500
        max_pages = 100
        rows_all: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        filters = {
            "$and": [
                {"fk_api_request": {"$eq": create_id}},
                {"f_third_party_name": {"$eq": self._source_system}},
            ]
        }
        for page in range(1, max_pages + 1):
            result = await self._client.list_records(
                collection="t_notice_board",
                request_id=request_id,
                authorization_token=authorization_token,
                filters=filters,
                appends=(
                    "f_intake_type",
                    "f_status",
                    "f_letter_attachment",
                    "f_letter_attachment.f_attachment",
                    "f_issued_letters",
                    "f_issued_letters.f_attachment",
                ),
                page=page,
                page_size=page_size,
                sort=("createdAt", "id"),
            )
            batch = result.get("data") or []
            for row in batch:
                if not isinstance(row, dict):
                    continue
                row_id = row.get("id")
                if row_id is not None:
                    identity = str(row_id)
                    if identity in seen_ids:
                        raise AdapterError(
                            502,
                            "invalid_upstream_response",
                            "The upstream repeated a Notice across pages",
                        )
                    seen_ids.add(identity)
                rows_all.append(row)
            meta = result.get("meta") or {}
            total = meta.get("count")
            try:
                total_count = int(total) if total is not None else None
            except (TypeError, ValueError):
                total_count = None
            if not batch or (total_count is not None and len(rows_all) >= total_count):
                break
            if len(batch) < page_size and total_count is None:
                break
        else:
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream Notice history exceeded the pagination limit",
            )
        notices: list[tuple[tuple[Any, ...], dict[str, Any]]] = []
        legacy_approved: list[tuple[dict[str, Any], dict[str, Any]]] = []
        package_approved: list[tuple[dict[str, Any], dict[str, Any]]] = []
        rows = sorted(
            rows_all,
            key=_notice_event_sort_key,
        )
        for row in rows:
            # The upstream filter is the primary boundary; also fail closed
            # if an append, custom collection hook, or stale cache returns a
            # row addressed to a different third party.
            if str(row.get("f_third_party_name") or "").upper() != self._source_system:
                continue
            # NocoBase applies the create_id filter upstream.  Guard against
            # a custom hook or stale page returning another application's
            # Notice alongside the requested one.  Older projections may omit
            # this FK, so keep the upstream filter as their primary boundary.
            linked_create_id = row.get("fk_api_request")
            if linked_create_id not in (None, "") and str(linked_create_id) != str(
                create_id
            ):
                continue
            if row.get("id") is None:
                raise AdapterError(
                    502,
                    "upstream_error",
                    "The upstream returned a Notice without an ID",
                )
            intake_type = row.get("f_intake_type")
            intake_label = None
            if isinstance(intake_type, dict):
                intake_label = intake_type.get("f_name") or intake_type.get("name")
            intake_label = intake_label or application_type_label
            notice_status = row.get("f_status")
            status = (
                notice_status.get("f_status")
                if isinstance(notice_status, dict)
                else None
            )
            letter = row.get("f_letter_attachment")
            nla_letter_status = (
                application_type_value == NEW_LICENCE_APPLICATION_TYPE
                and status
                in {"Acknowledged", "Confirmed", "Reminding", "Approved", "Closed"}
            )
            # The non-NLA letter sidecar uses the same Notice collection. A
            # deleted source Letter leaves its historical Notice behind with
            # a NULL relation, so apply the issued-file guard across every
            # letter-origin Notice, not only the NLA status vocabulary.
            letter_origin = row.get("f_source_collection") == "t_letter_attachment"
            issued_letter_notice = nla_letter_status or letter_origin
            if application_type_value == NEW_LICENCE_APPLICATION_TYPE:
                # Old Send Letter revisions could record a cover letter as
                # Approved before the licence letter was sent.  Keep that
                # historical row internally, but expose the Approved stage
                # only after the canonical CREATE status has crossed the
                # two-letter boundary.  Closed retains prior Notices.
                if status == "Approved" and current_status not in {
                    "Approved", "Closed"
                }:
                    continue
            if issued_letter_notice and not (
                isinstance(letter, dict)
                and letter.get("f_is_send") is True
                and letter.get("f_sendtime")
            ):
                continue
            source_letter_id = row.get("f_source_record_id")
            if (
                letter_origin
                and source_letter_id not in (None, "")
                and str(letter.get("id")) != str(source_letter_id)
            ):
                continue
            business_id = row.get("f_business_record_id")
            if (
                letter_origin
                and business_id not in (None, "")
                and letter.get("f_business_key") not in (None, "")
                and str(letter["f_business_key"]) != str(business_id)
            ):
                continue
            # A generated file is not an issued Notice attachment until the
            # native Send Letter action has recorded the send flag and time.
            attachments = _notice_letter_files(letter)
            issued_letters = row.get("f_issued_letters")
            approved_package = (
                application_type_value == NEW_LICENCE_APPLICATION_TYPE
                and status == "Approved"
                and isinstance(issued_letters, list)
                and bool(issued_letters)
            )
            if approved_package:
                # This integration-owned relation retains both native Send
                # Letter records.  A snapshot of attachment IDs alone could
                # expose an unsent or subsequently removed letter.
                attachments = _nla_approved_package_files(row)
            # Old backfills may point to a missing Letter row or a sent Letter
            # with no attachment; do not present those as issued documents.
            if issued_letter_notice and not attachments:
                continue
            projected = {
                    "notice_id": str(row["id"]),
                    "third_party_name": row.get("f_third_party_name"),
                    "intake_type": intake_label,
                    # Received and P-number notices are status events, not
                    # issued letter categories in the public Notice taxonomy.
                    "notice_type": _public_notice_type(row.get("f_notice_type")),
                    "status": status,
                    "content": row.get("f_content"),
                    "rch_no": row.get("f_rch_no"),
                    "rch_name": row.get("f_rch_name"),
                    "created_time": row.get("createdAt"),
                    "attachments": attachments,
                }
            if (
                application_type_value == NEW_LICENCE_APPLICATION_TYPE
                and status == "Approved"
            ):
                if approved_package:
                    package_approved.append((row, projected))
                else:
                    legacy_approved.append((row, projected))
            else:
                notices.append((_notice_event_sort_key(row), projected))
        if package_approved:
            # New revisions write one Approved Notice.  Never expose legacy
            # per-letter rows alongside it for the same create_id.
            if len(package_approved) != 1:
                raise AdapterError(
                    502,
                    "invalid_upstream_response",
                    "The upstream returned duplicate Approved Notice packages",
                )
            row, projected = package_approved[0]
            notices.append((_notice_event_sort_key(row), projected))
        elif legacy_approved:
            # Historical sidecars wrote one Notice per letter.  Project a
            # single backward-compatible result only for one valid c/f pair.
            by_type: dict[str, list[tuple[dict[str, Any], dict[str, Any]]]] = {
                "c": [], "f": [],
            }
            for row, projected in legacy_approved:
                notice_type = row.get("f_notice_type")
                if notice_type in by_type:
                    by_type[notice_type].append((row, projected))
            if all(len(by_type[kind]) == 1 for kind in ("c", "f")):
                cover, licence = by_type["c"][0], by_type["f"][0]
                combined = dict(licence[1])
                combined["attachments"] = (
                    cover[1]["attachments"] + licence[1]["attachments"]
                )
                notices.append((_notice_event_sort_key(licence[0]), combined))
        return [projected for _, projected in sorted(notices, key=lambda item: item[0])]

    async def get_request(
        self,
        *,
        record_id: ScalarId,
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        row = await self._client.get_record(
            collection="t_api_request_staging",
            record_id=record_id,
            request_id=request_id,
            authorization_token=authorization_token,
        )
        if not self._is_queryable_source(row):
            raise AdapterError(404, "request_not_found", "The request was not found")
        body = row.get("f_request_body")
        body = body if isinstance(body, dict) else {}
        api_type = row.get("f_api_type")
        is_create = str(row.get("f_request_event") or "").upper() == "CREATE"
        return {
            "id": row.get("id"),
            "request_id": body.get("request_id"),
            "create_id": row.get("id") if is_create else body.get("create_id"),
            "update_id": None if is_create else row.get("id"),
            "request_event": row.get("f_request_event"),
            "request_type": api_type,
            "status": row.get("f_status"),
            "application_type": row.get("f_application_type") or None,
            "office_code": row.get("f_office_code") or None,
            "application_status": row.get("f_application_status") or None,
            "intake_id": row.get("f_intake_id") or None,
            "application_id": row.get("f_application_id") or None,
            "rch_id": row.get("f_rch_id") or None,
            "created_at": row.get("createdAt"),
            "updated_at": row.get("updatedAt"),
        }

    async def get_new_licence_request(
        self,
        *,
        create_id: ScalarId,
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        """Resolve one New Licence Application from its API Call record ID."""
        request_row = await self._client.get_record(
            collection="t_api_request_staging",
            record_id=create_id,
            request_id=request_id,
            authorization_token=authorization_token,
        )
        if not self._is_queryable_source(request_row):
            raise AdapterError(404, "request_not_found", "The request was not found")

        result = await self._project_create_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
        )
        application_data = result.get("application_data")
        if isinstance(application_data, dict):
            result["application_data"] = _public_request_application_data(
                application_data
            )
        return {
            "request_id": await self._latest_accepted_request_id(
                request_row=request_row,
                create_id=create_id,
                request_id=request_id,
                authorization_token=authorization_token,
            ),
            "create_id": str(request_row.get("id") or create_id),
            **result,
        }

    async def _latest_accepted_request_id(
        self,
        *,
        request_row: dict[str, Any],
        create_id: ScalarId,
        request_id: str,
        authorization_token: str,
    ) -> Optional[str]:
        """Return the most recent accepted Create/Update client request ID.

        A failed, invalid or unadmitted UPDATE remains in Staging for audit,
        but must not replace the public request ID.  This read does not alter
        the business-data projection, which comes from the current application.
        """

        create_body = request_row.get("f_request_body")
        create_body = create_body if isinstance(create_body, dict) else {}
        create_request_id = create_body.get("request_id")
        update_api_type = UPDATE_API_TYPES_BY_CREATE_TYPE.get(
            str(request_row.get("f_api_type") or "")
        )
        # Native CMTF-created requests have no OP request ID, and malformed
        # historical CREATE bodies cannot establish a public ID lineage.
        if (
            update_api_type is None
            or not isinstance(create_request_id, str)
            or not create_request_id
            or str(request_row.get("f_source_system") or "").upper()
            != self._source_system
        ):
            return create_request_id

        result = await self._client.list_records(
            collection="t_api_request_staging",
            request_id=request_id,
            authorization_token=authorization_token,
            filters={
                "$and": [
                    {"f_source_system": {"$eq": self._source_system}},
                    {"f_request_event": {"$eq": "UPDATE"}},
                    {"f_parent_create_id": {"$eq": str(create_id)}},
                    {"f_api_type": {"$eq": update_api_type}},
                    {"f_status": {
                        "$in": sorted(ACCEPTED_UPDATE_STAGING_STATUSES)
                    }},
                ]
            },
            page=1,
            page_size=1,
            sort=("-id",),
        )
        rows = result.get("data") or []
        if not isinstance(rows, list):
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream returned an invalid request history",
            )
        if not rows:
            return create_request_id
        latest = rows[0]
        if not isinstance(latest, dict):
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream returned an invalid request history",
            )
        # Re-check the boundary even though NocoBase applies the filter: the
        # result may pass through custom collection hooks or stale caches.
        if (
            str(latest.get("f_source_system") or "").upper()
            != self._source_system
            or latest.get("f_request_event") != "UPDATE"
            or str(latest.get("f_parent_create_id")) != str(create_id)
            or latest.get("f_api_type") != update_api_type
            or latest.get("f_status") not in ACCEPTED_UPDATE_STAGING_STATUSES
        ):
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The upstream returned an unrelated request history row",
            )
        update_body = latest.get("f_request_body")
        update_request_id = (
            update_body.get("request_id") if isinstance(update_body, dict) else None
        )
        if not isinstance(update_request_id, str) or not update_request_id:
            raise AdapterError(
                502,
                "invalid_upstream_response",
                "The latest accepted request has no request_id",
            )
        return update_request_id

    async def _project_create_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        """Resolve the business record while the outer Query adds public IDs."""

        application_type = request_row.get("f_application_type")
        api_type = request_row.get("f_api_type")
        if (
            api_type == CHANGING_HOME_REQUEST_TYPE
            and application_type == CHANGING_HOME_APPLICATION_TYPE
        ):
            return await self._get_changing_home_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
            )
        if (
            api_type == SELF_WITHDRAW_REQUEST_TYPE
            and application_type == SELF_WITHDRAW_APPLICATION_TYPE
        ):
            return await self._get_closure_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
                application_type=SELF_WITHDRAW_APPLICATION_TYPE,
                application_label=SELF_WITHDRAW_APPLICATION_TYPE_NAME,
            )
        if (
            api_type == REVOKE_LICENCE_REQUEST_TYPE
            and application_type == REVOKE_LICENCE_APPLICATION_TYPE
        ):
            return await self._get_closure_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
                application_type=REVOKE_LICENCE_APPLICATION_TYPE,
                application_label=REVOKE_LICENCE_APPLICATION_TYPE_NAME,
            )
        if (
            api_type == SPECIFIC_HOUR_REQUEST_TYPE
            and application_type == SPECIFIC_HOUR_APPLICATION_TYPE
        ):
            return await self._get_specific_hour_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
            )
        if (
            api_type == RESPONSIBLE_PERSON_REQUEST_TYPE
            and application_type == RESPONSIBLE_PERSON_APPLICATION_TYPE
        ):
            return await self._get_responsible_person_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
            )
        change_meta = CHANGE_MONITORING_QUERY_TYPES.get(str(api_type or ""))
        if change_meta and application_type == change_meta[0]:
            return await self._get_change_monitoring_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
                application_type=change_meta[0],
                application_label=change_meta[1],
                child_assoc=change_meta[2],
            )
        if (
            api_type == PROSECUTION_REQUEST_TYPE
            and application_type == PROSECUTION_APPLICATION_TYPE
        ):
            return await self._get_prosecution_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
            )
        if (
            api_type == LICENCE_RENEWAL_REQUEST_TYPE
            and application_type == LICENCE_RENEWAL_APPLICATION_TYPE
        ):
            return await self._get_licence_renewal_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
            )
        if (
            api_type == EXPANSION_AIP_REQUEST_TYPE
            and application_type == EXPANSION_AIP_APPLICATION_TYPE
        ):
            return await self._get_expansion_aip_request(
                request_row=request_row,
                request_id=request_id,
                authorization_token=authorization_token,
            )
        if api_type != NEW_LICENCE_REQUEST_TYPE or application_type not in (
            None,
            "",
            NEW_LICENCE_APPLICATION_TYPE,
        ):
            raise AdapterError(404, "request_not_found", "The request was not found")

        application_id = request_row.get("f_application_id") or None
        result: dict[str, Any] = {
            "office_code": request_row.get("f_office_code") or None,
            "application_type": {
                "value": NEW_LICENCE_APPLICATION_TYPE,
                "label": NEW_LICENCE_APPLICATION_TYPE_NAME,
            },
            "status": request_row.get("f_application_status") or None,
            "application_data": None,
        }
        if application_id is None:
            raise AdapterError(
                502,
                "upstream_error",
                "The application data is not available for this request",
            )

        application_row = await self._client.get_record(
            collection="t_licence_app",
            record_id=application_id,
            request_id=request_id,
            authorization_token=authorization_token,
            appends=REQUEST_APPLICATION_APPENDS,
        )
        if not isinstance(application_row, dict) or application_row.get("id") is None:
            raise AdapterError(
                502,
                "upstream_error",
                "The application data is not available for this request",
            )
        application_data = _public_new_licence_request_application(application_row)
        if result["office_code"] is None:
            result["office_code"] = application_data.get("office_code")
        result["application_data"] = application_data
        return result

    async def _get_changing_home_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        application_id = request_row.get("f_application_id") or None
        result: dict[str, Any] = {
            "office_code": request_row.get("f_office_code") or None,
            "application_type": {
                "value": CHANGING_HOME_APPLICATION_TYPE,
                "label": CHANGING_HOME_APPLICATION_TYPE_NAME,
            },
            "status": request_row.get("f_application_status") or None,
            "application_data": None,
        }
        if application_id is None:
            return result

        application_row = await self._client.get_record(
            collection="t_change_home_information_app",
            record_id=application_id,
            request_id=request_id,
            authorization_token=authorization_token,
            appends=CHANGING_HOME_APPENDS,
        )
        checklist_result = await self._client.list_records(
            collection="t_document_submitted_for_application",
            request_id=request_id,
            authorization_token=authorization_token,
            filters={
                "$and": [
                    {"f_business_key": {"$eq": application_id}},
                    {"f_business_type": {"$eq": "t_change_home_information_app"}},
                ]
            },
            appends=CHANGING_HOME_CHECKLIST_APPENDS,
            page=1,
            page_size=1000,
            sort=("f_sort",),
        )
        application_data = _public_changing_home_application(
            application_row,
            checklist_result.get("data") or [],
            request_row.get("f_rch_id"),
        )
        application_data.pop("letter_attachments", None)
        _remove_unified_request_internal_details(application_data)
        chi_part_3 = (application_data.get("form_data") or {}).get("part_3")
        rch_business_status = (
            chi_part_3.get("rch_business_status")
            if isinstance(chi_part_3, dict)
            else None
        )
        application_data = _without_status_fields(application_data)
        # This is the CHI popup's business-status field, not an approval
        # status. The generic NLA status scrubber would otherwise remove it.
        filtered_part_3 = (application_data.get("form_data") or {}).get("part_3")
        if isinstance(filtered_part_3, dict):
            filtered_part_3["rch_business_status"] = rch_business_status
        if result["office_code"] is None:
            result["office_code"] = application_data.get("office_code")
        result["application_data"] = application_data
        return result

    async def _get_closure_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
        application_type: str,
        application_label: str,
    ) -> dict[str, Any]:
        application_id = request_row.get("f_application_id") or None
        result: dict[str, Any] = {
            "office_code": request_row.get("f_office_code") or None,
            "application_type": {
                "value": application_type,
                "label": application_label,
            },
            "status": request_row.get("f_application_status") or None,
            "application_data": None,
        }
        if application_id is None:
            return result

        application_row = await self._client.get_record(
            collection=CLOSURE_APPLICATION_COLLECTION,
            record_id=application_id,
            request_id=request_id,
            authorization_token=authorization_token,
            appends=CLOSURE_APPENDS,
        )
        checklist_result = await self._client.list_records(
            collection="t_document_submitted_for_application",
            request_id=request_id,
            authorization_token=authorization_token,
            filters={
                "$and": [
                    {"f_business_key": {"$eq": application_id}},
                    {"f_business_type": {"$eq": CLOSURE_APPLICATION_COLLECTION}},
                ]
            },
            appends=CHANGING_HOME_CHECKLIST_APPENDS,
            page=1,
            page_size=1000,
            sort=("f_sort",),
        )
        home_row: dict[str, Any] = {}
        home_id = application_row.get("fk_home_record_id") or request_row.get(
            "f_rch_id"
        )
        if home_id is not None:
            try:
                loaded_home = await self._client.get_record(
                    collection="t_home_record",
                    record_id=home_id,
                    request_id=request_id,
                    authorization_token=authorization_token,
                )
            except AdapterError:
                loaded_home = {}
            if isinstance(loaded_home, dict):
                home_row = loaded_home
        application_data = _public_closure_application(
            application_row,
            checklist_result.get("data") or [],
            home_row,
            request_row.get("f_rch_id"),
        )
        application_data.pop("letter_attachments", None)
        # Native closure comments are officer approval notes, not fields
        # submitted through the public Create/Update contract.
        form_data = application_data.get("form_data")
        if isinstance(form_data, dict):
            form_data.pop("comments", None)
        application_data = _without_status_fields(application_data)
        if result["office_code"] is None:
            result["office_code"] = application_data.get("office_code")
        result["application_data"] = application_data
        return result

    async def _get_specific_hour_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        return await self._get_simple_home_bound_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
            application_type=SPECIFIC_HOUR_APPLICATION_TYPE,
            application_label=SPECIFIC_HOUR_APPLICATION_TYPE_NAME,
            collection=SPECIFIC_HOUR_APPLICATION_COLLECTION,
            home_fk="fk_home_record",
            appends=SPECIFIC_HOUR_APPENDS,
            projector=_public_specific_hour_application,
        )

    async def _get_prosecution_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        return await self._get_simple_home_bound_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
            application_type=PROSECUTION_APPLICATION_TYPE,
            application_label=PROSECUTION_APPLICATION_TYPE_NAME,
            collection=PROSECUTION_APPLICATION_COLLECTION,
            home_fk="fk_home_record_id",
            appends=("f_intake_form", "f_offence_charged_items"),
            projector=_public_prosecution_application,
        )

    async def _get_licence_renewal_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        return await self._get_simple_home_bound_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
            application_type=LICENCE_RENEWAL_APPLICATION_TYPE,
            application_label=LICENCE_RENEWAL_APPLICATION_TYPE_NAME,
            collection=LICENCE_RENEWAL_APPLICATION_COLLECTION,
            home_fk="fk_renewal_home_record_id",
            appends=("f_renewal_home_record",),
            projector=_public_licence_renewal_application,
        )

    async def _get_expansion_aip_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        return await self._get_simple_home_bound_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
            application_type=EXPANSION_AIP_APPLICATION_TYPE,
            application_label=EXPANSION_AIP_APPLICATION_TYPE_NAME,
            collection=EXPANSION_AIP_APPLICATION_COLLECTION,
            home_fk="fk_home_record_id",
            appends=EXPANSION_AIP_APPENDS,
            projector=_public_expansion_aip_application,
        )

    async def _get_change_monitoring_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
        application_type: str,
        application_label: str,
        child_assoc: str,
    ) -> dict[str, Any]:
        appends = (
            "f_intake_form",
            "f_documents",
            child_assoc,
        )
        if child_assoc == "f_change_home_type":
            appends = appends + ("f_change_home_type.f_proposed_rch_nature",)
        elif child_assoc == "f_change_nurse_in_charge":
            appends = appends + ("f_change_nurse_in_charge.f_documents",)
        elif child_assoc == "f_change_directors_information":
            appends = appends + (
                "f_change_directors_information.f_uploading_documents",
                "f_change_directors_information.f_uploading_documents.f_lastest_files",
            )
        return await self._get_simple_home_bound_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
            application_type=application_type,
            application_label=application_label,
            collection=CHANGE_MONITORING_COLLECTION,
            home_fk="fk_home_record_id",
            appends=appends,
            load_checklist=False,
            projector=lambda row, checklist, home, staging_rch_id: (
                _public_change_monitoring_application(
                    row,
                    checklist,
                    home,
                    staging_rch_id,
                    application_type=application_type,
                    child_assoc=child_assoc,
                )
            ),
        )

    async def _get_responsible_person_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        return await self._get_simple_home_bound_request(
            request_row=request_row,
            request_id=request_id,
            authorization_token=authorization_token,
            application_type=RESPONSIBLE_PERSON_APPLICATION_TYPE,
            application_label=RESPONSIBLE_PERSON_APPLICATION_TYPE_NAME,
            collection=RESPONSIBLE_PERSON_APPLICATION_COLLECTION,
            home_fk="fk_home_record_id",
            appends=RESPONSIBLE_PERSON_APPENDS,
            projector=_public_responsible_person_application,
        )

    async def _get_simple_home_bound_request(
        self,
        *,
        request_row: dict[str, Any],
        request_id: str,
        authorization_token: str,
        application_type: str,
        application_label: str,
        collection: str,
        home_fk: str,
        appends: tuple[str, ...],
        projector: Any,
        load_checklist: bool = True,
    ) -> dict[str, Any]:
        application_id = request_row.get("f_application_id") or None
        result: dict[str, Any] = {
            "office_code": request_row.get("f_office_code") or None,
            "application_type": {
                "value": application_type,
                "label": application_label,
            },
            "status": request_row.get("f_application_status") or None,
            "application_data": None,
        }
        if application_id is None:
            return result
        application_row = await self._client.get_record(
            collection=collection,
            record_id=application_id,
            request_id=request_id,
            authorization_token=authorization_token,
            appends=appends,
        )
        checklist: list[dict[str, Any]] = []
        if load_checklist:
            checklist_result = await self._client.list_records(
                collection="t_document_submitted_for_application",
                request_id=request_id,
                authorization_token=authorization_token,
                filters={
                    "$and": [
                        {"f_business_key": {"$eq": application_id}},
                        {"f_business_type": {"$eq": collection}},
                    ]
                },
                appends=CHANGING_HOME_CHECKLIST_APPENDS,
                page=1,
                page_size=1000,
                sort=("f_sort",),
            )
            checklist = checklist_result.get("data") or []
        home = application_row.get("f_home_record") or application_row.get(
            "f_renewal_home_record"
        )
        home = home if isinstance(home, dict) else {}
        home_id = (
            application_row.get(home_fk)
            or home.get("id")
            or request_row.get("f_rch_id")
        )
        if not home and home_id is not None:
            try:
                loaded = await self._client.get_record(
                    collection="t_home_record",
                    record_id=home_id,
                    request_id=request_id,
                    authorization_token=authorization_token,
                )
            except AdapterError:
                loaded = {}
            if isinstance(loaded, dict):
                home = loaded
        application_data = projector(
            application_row,
            checklist,
            home,
            request_row.get("f_rch_id"),
        )
        application_data.pop("letter_attachments", None)
        if application_type == LICENCE_RENEWAL_APPLICATION_TYPE:
            _remove_unified_request_internal_details(application_data)
        unfiltered_application_data = application_data
        application_data = _without_status_fields(unfiltered_application_data)
        if application_type == RESPONSIBLE_PERSON_APPLICATION_TYPE:
            _restore_responsible_person_business_statuses(
                application_data, unfiltered_application_data
            )
        if result["office_code"] is None:
            result["office_code"] = application_data.get("office_code")
        result["application_data"] = application_data
        return result

    async def list_intakes(
        self,
        *,
        request_id: str,
        authorization_token: str,
        office_code: Optional[str],
        status: Optional[str],
        intake_id: Optional[ScalarId],
        application_id: Optional[ScalarId],
        page: int,
        page_size: int,
    ) -> dict[str, Any]:
        resolved_intake_id = intake_id
        if application_id is not None:
            # Filtering the Intake's has-one Application association while also
            # appending its nested contacts/addresses makes NocoBase generate a
            # duplicate SQL JOIN alias. Resolve the scalar FK first, then query
            # the Intake by its own primary key. Both calls retain the client's
            # token and therefore the client's row-level permissions.
            application_result = await self._client.list_records(
                collection="t_licence_app",
                request_id=request_id,
                authorization_token=authorization_token,
                filters={"id": {"$eq": application_id}},
                page=1,
                page_size=1,
                sort=(),
            )
            application_rows = application_result["data"]
            if not application_rows:
                return _response(
                    [],
                    _empty_meta(page, page_size),
                    await self._enum_catalog(request_id),
                )
            application_intake_id = application_rows[0].get("fk_intake_form")
            if application_intake_id is None or (
                intake_id is not None and str(intake_id) != str(application_intake_id)
            ):
                return _response(
                    [],
                    _empty_meta(page, page_size),
                    await self._enum_catalog(request_id),
                )
            resolved_intake_id = application_intake_id
        filters = _filters(
            ("f_office_cd", office_code),
            ("f_approval_status", status),
            ("id", resolved_intake_id),
        )
        result = await self._client.list_records(
            collection="t_intake_form",
            request_id=request_id,
            authorization_token=authorization_token,
            filters=filters,
            appends=INTAKE_APPENDS,
            page=page,
            page_size=page_size,
        )
        return _response(
            [_public_intake(row) for row in result["data"]],
            result["meta"],
            await self._enum_catalog(request_id),
        )

    async def list_applications(
        self,
        *,
        request_id: str,
        authorization_token: str,
        office_code: Optional[str],
        status: Optional[str],
        intake_id: Optional[ScalarId],
        application_id: Optional[ScalarId],
        page: int,
        page_size: int,
    ) -> dict[str, Any]:
        filters = _filters(
            ("f_office_cd", office_code),
            ("f_approval_status", status),
            ("fk_intake_form", intake_id),
            ("id", application_id),
        )
        result = await self._client.list_records(
            collection="t_licence_app",
            request_id=request_id,
            authorization_token=authorization_token,
            filters=filters,
            appends=APPLICATION_APPENDS,
            page=page,
            page_size=page_size,
        )
        return _response(
            [_public_application(row) for row in result["data"]],
            result["meta"],
            await self._enum_catalog(request_id),
        )

    async def list_checklist_catalog(
        self,
        *,
        request_id: str,
        office_code: str,
        application_collection: str = "t_licence_app",
    ) -> dict[str, Any]:
        result = await self._client.list_configuration_records(
            collection="t_document_checklist",
            request_id=request_id,
            filters={
                "$and": [
                    {"f_office_code": {"$eq": office_code}},
                    {"f_use_for": {"$anyOf": [application_collection]}},
                    {"f_active": {"$eq": True}},
                ]
            },
            page_size=1000,
            sort=("f_sort_order",),
        )
        rows = result["data"]
        items = []
        for row in rows:
            if str(row.get("f_item_type")) != "2":
                continue
            if application_collection not in (row.get("f_use_for") or []):
                continue
            if row.get("f_office_code") != office_code:
                continue
            position_code = _checklist_position_code(row)
            if not position_code:
                continue
            items.append(
                {
                    "checklist_id": row.get("id"),
                    "position_code": position_code,
                    "name_en": row.get("f_name_en") or None,
                    "name_cn": row.get("f_name_cn") or None,
                    "required": bool(row.get("f_is_mandatory_default")),
                }
            )
        return {"data": items}

    async def _enum_catalog(self, request_id: str) -> dict[str, list[dict[str, str]]]:
        if self._enum_cache is not None:
            return self._enum_cache
        field_names = sorted({name for _collection, name in ENUM_FIELD_TARGETS})
        result = await self._client.list_configuration_records(
            collection="fields",
            request_id=request_id,
            filters={"name": {"$in": field_names}},
            page_size=200,
        )
        catalog = copy.deepcopy(PUBLIC_ENUMS)
        for field in result["data"]:
            if not isinstance(field, dict):
                continue
            target = ENUM_FIELD_TARGETS.get(
                (field.get("collectionName"), field.get("name"))
            )
            schema = field.get("uiSchema")
            raw_options = schema.get("enum") if isinstance(schema, dict) else None
            if not target or not isinstance(raw_options, list):
                continue
            options = []
            for option in raw_options:
                if not isinstance(option, dict) or option.get("value") is None:
                    continue
                options.append(
                    {
                        "value": str(option["value"]),
                        "label": str(option.get("label") or option["value"]),
                    }
                )
            if options:
                catalog[target] = options
        self._enum_cache = catalog
        return catalog


def _filters(*pairs: tuple[str, Any]) -> Optional[dict[str, Any]]:
    clauses = [{field: {"$eq": value}} for field, value in pairs if value is not None]
    if not clauses:
        return None
    return clauses[0] if len(clauses) == 1 else {"$and": clauses}


def _response(
    data: list[dict[str, Any]],
    meta: dict[str, Any],
    enums: dict[str, list[dict[str, str]]],
) -> dict[str, Any]:
    return {"data": data, "meta": meta, "enums": enums}


def _empty_meta(page: int, page_size: int) -> dict[str, int]:
    return {"count": 0, "page": page, "pageSize": page_size, "totalPage": 0}


def _enum(value: Any, options: list[dict[str, str]]) -> Optional[dict[str, Any]]:
    if value is None:
        return None
    text = str(value)
    label = next((item["label"] for item in options if item["value"] == text), None)
    return {"value": text, "label": label}


def _public_intake(row: dict[str, Any]) -> dict[str, Any]:
    application = row.get("t_new_licence_application")
    applications = [application] if isinstance(application, dict) else []
    if isinstance(application, list):
        applications = [item for item in application if isinstance(item, dict)]
    return {
        "intake_id": row.get("id"),
        "intake_no": row.get("f_intake_no"),
        "office_code": row.get("f_office_cd"),
        "intake_status": _enum(row.get("f_approval_status"), INTAKE_STATUS_OPTIONS),
        "subject": row.get("f_subject"),
        "received_date": row.get("f_received_date"),
        "severity": row.get("f_severity"),
        "submitter_user_id": row.get("createdById"),
        "submitter_post_code": row.get("fk_created_by_post"),
        "intake_officer_user_id": row.get("fk_task_owner"),
        "intake_officer_post_code": row.get("fk_task_owner_post"),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "activities": [
            _public_activity(item)
            for item in row.get("f_activity") or []
            if isinstance(item, dict)
        ],
        "new_licence_applications": [
            _public_application(item, include_intake=False) for item in applications
        ],
    }


def _without_status_fields(value: Any) -> Any:
    """Remove nested status fields from the unified application payload."""
    if isinstance(value, dict):
        return {
            key: _without_status_fields(item)
            for key, item in value.items()
            if not isinstance(key, str) or "status" not in key.lower()
        }
    if isinstance(value, list):
        return [_without_status_fields(item) for item in value]
    return value


def _public_notice_type(value: Any) -> Optional[str]:
    """Convert known native letter categories to the public Notice enum."""
    if value is None:
        return None
    notice_type = str(value).strip()
    if not notice_type or notice_type in {"received", "p_number_generated"}:
        return None
    return PUBLIC_NOTICE_TYPES_BY_NATIVE_CODE.get(notice_type, notice_type)


def _notice_letter_files(letter: Any) -> list[dict[str, Any]]:
    """Expose files only from a native letter recorded as actually sent."""
    if not (
        isinstance(letter, dict)
        and letter.get("f_is_send") is True
        and letter.get("f_sendtime")
    ):
        return []
    files = letter.get("f_attachment")
    result = []
    for item in files if isinstance(files, list) else []:
        if not isinstance(item, dict) or item.get("id") is None:
            continue
        result.append(
            {
                "data_id": item["id"],
                "filename": item.get("filename") or item.get("title"),
                "size": item.get("size"),
                "download_url": f"/v1/files/{item['id']}",
            }
        )
    return result


def _nla_approved_package_files(row: dict[str, Any]) -> list[dict[str, Any]]:
    """Require the real issued Cover and New Licence letters for one Notice.

    The many-to-many Notice relation is integration-owned.  Its two native
    Letter records are the provenance of the existing public attachments[];
    it does not introduce a new public field or Notice type.
    """
    letters = row.get("f_issued_letters")
    if not isinstance(letters, list) or len(letters) != 2:
        return []
    by_type: dict[str, tuple[dict[str, Any], list[dict[str, Any]]]] = {}
    for letter in letters:
        if not isinstance(letter, dict) or letter.get("id") is None:
            return []
        kind = letter.get("f_letter_type")
        files = _notice_letter_files(letter)
        if kind not in {"c", "f"} or kind in by_type or not files:
            return []
        by_type[kind] = letter, files
    if set(by_type) != {"c", "f"}:
        return []
    primary = row.get("f_letter_attachment")
    if not isinstance(primary, dict) or str(primary.get("id")) != str(
        by_type["f"][0]["id"]
    ):
        return []
    evidence = row.get("f_recipient_snapshot")
    if not isinstance(evidence, dict):
        return []
    expected = evidence.get("issuedLetterIds")
    if not isinstance(expected, list) or {
        str(value) for value in expected
    } != {str(by_type["c"][0]["id"]), str(by_type["f"][0]["id"])}:
        return []
    application_id = row.get("f_business_record_id")
    if application_id not in (None, "") and any(
        str(by_type[kind][0].get("f_business_key")) != str(application_id)
        for kind in ("c", "f")
    ):
        return []
    issued_files = by_type["c"][1] + by_type["f"][1]
    expected_files = evidence.get("attachmentIds")
    if not isinstance(expected_files, list) or sorted(
        str(value) for value in expected_files
    ) != sorted(str(item["data_id"]) for item in issued_files):
        return []
    return issued_files


def _public_request_application_data(
    application_data: dict[str, Any],
) -> dict[str, Any]:
    """Omit native record/person IDs from the create_id Query projection only.

    Uploaded attachment IDs and Checklist IDs are public API references and
    remain available for download and reconciliation.
    """
    internal_keys = {
        "id",
        "application_id",
        "home_record_id",
        "intake_id",
        "rch_id",
        "submitter_user_id",
        "task_owner_user_id",
        "source_id",
        "source_other",
        "received_by_user_id",
        "sent_by_user_id",
        "task_owner_post_code",
        "submitter_post_code",
        "intake_officer_post_code",
    }

    def omit_internal(value: Any) -> Any:
        if isinstance(value, dict):
            return {
                key: omit_internal(item)
                for key, item in value.items()
                if key not in internal_keys
                and not key.startswith("fk_")
                and not key.endswith("_user_id")
            }
        if isinstance(value, list):
            return [omit_internal(item) for item in value]
        return value

    public = omit_internal(application_data)
    # These application-level metadata fields were deleted from the accepted
    # v0.8.1 Query contract. Office remains available at the response top
    # level and inside submitted form_data.case_summary where applicable.
    for field in ("intake", "office_code", "created_at", "updated_at"):
        public.pop(field, None)
    return public


def _remove_unified_request_internal_details(application_data: dict[str, Any]) -> None:
    """Keep legacy list projections intact while narrowing create_id Query data."""
    form_data = application_data.get("form_data")
    if isinstance(form_data, dict):
        case_summary = form_data.get("case_summary")
        if isinstance(case_summary, dict):
            for internal_field in (
                "submitter_user_id",
                "task_owner_user_id",
                "task_owner_post_code",
                "source_id",
                "source_other",
                "severity",
            ):
                case_summary.pop(internal_field, None)
        part_5 = form_data.get("part_5")
        if isinstance(part_5, dict):
            # The public CHI/LRN file contract uses Checklist positions only.
            # These native application attachments and approval notes are not
            # client-submitted files or Notice attachments.
            for internal_field in (
                "attachments",
                "attachment_ids",
                "comments",
                "other_information",
                "remarks",
            ):
                part_5.pop(internal_field, None)
    intake = application_data.get("intake")
    if isinstance(intake, dict):
        intake.pop("activities", None)


def _prune_empty_public_values(value: Any) -> Any:
    """Omit native child IDs and absent fields without losing false or zero."""
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            if key in {"id", "sort_order"}:
                continue
            if key == "display_name" and item in {"()", "（）"}:
                continue
            cleaned = _prune_empty_public_values(item)
            if cleaned is None or cleaned == "" or cleaned == [] or cleaned == {}:
                continue
            result[key] = cleaned
        return result
    if isinstance(value, list):
        return [
            cleaned
            for item in value
            if (cleaned := _prune_empty_public_values(item))
            is not None
            and cleaned != ""
            and cleaned != []
            and cleaned != {}
        ]
    return value


def _public_new_licence_request_application(row: dict[str, Any]) -> dict[str, Any]:
    """Project current NLA business fields, not native workflow bookkeeping."""
    projected = _public_application(row)
    _remove_unified_request_internal_details(projected)
    form_data = projected.get("form_data")
    if isinstance(form_data, dict):
        _normalize_new_licence_public_types(form_data)
        case_summary = form_data.get("case_summary")
        if isinstance(case_summary, dict):
            case_summary.pop("received_date", None)
        part_5 = form_data.get("part_5")
        if isinstance(part_5, dict):
            for field in (
                "comments",
                "other_information",
                "remarks",
                "attachments",
                "attachment_ids",
            ):
                part_5.pop(field, None)
            checklist: list[dict[str, Any]] = []
            for submitted in row.get("f_documents_submitted") or []:
                if not isinstance(submitted, dict):
                    continue
                template = submitted.get("f_document_checklist")
                template = template if isinstance(template, dict) else {}
                public = _public_checklist(submitted)
                if (
                    template.get("id") is None
                    or not public.get("position_code")
                    or public.get("attachment_id") is None
                ):
                    continue
                checklist.append(
                    {
                        "position_code": public["position_code"],
                        "attachment_id": public["attachment_id"],
                    }
                )
            part_5["checklist"] = checklist
    public_application = {"form_data": form_data}
    filtered = _without_status_fields(public_application)
    # This is an OP-submitted RCH business field, not an application approval
    # status. Preserve it while excluding native workflow status fields.
    if isinstance(form_data, dict):
        original_part_3 = form_data.get("part_3")
        filtered_form = filtered.get("form_data")
        filtered_part_3 = (
            filtered_form.get("part_3") if isinstance(filtered_form, dict) else None
        )
        if (
            isinstance(original_part_3, dict)
            and isinstance(filtered_part_3, dict)
            and original_part_3.get("rch_business_status") is not None
        ):
            filtered_part_3["rch_business_status"] = original_part_3[
                "rch_business_status"
            ]
    return _prune_empty_public_values(filtered)


def _contract_value_error(field: str, expected: str) -> AdapterError:
    return AdapterError(
        502,
        "upstream_error",
        f"The upstream returned an invalid {expected} for {field}",
    )


def _contract_date(value: Any, field: str) -> Optional[str]:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if not isinstance(value, str):
        raise _contract_value_error(field, "date")
    try:
        if len(value) == 10:
            return date.fromisoformat(value).isoformat()
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.date().isoformat()
    except ValueError as exc:
        raise _contract_value_error(field, "date") from exc


def _contract_decimal(value: Any, field: str) -> Optional[Decimal]:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        raise _contract_value_error(field, "number")
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise _contract_value_error(field, "number") from exc
    if not number.is_finite():
        raise _contract_value_error(field, "number")
    return number


def _contract_number(value: Any, field: str) -> Optional[int | float]:
    number = _contract_decimal(value, field)
    if number is None:
        return None
    return int(number) if number == number.to_integral_value() else float(number)


def _contract_integer(value: Any, field: str) -> Optional[int]:
    number = _contract_decimal(value, field)
    if number is None:
        return None
    if number != number.to_integral_value():
        raise _contract_value_error(field, "integer")
    return int(number)


def _contract_boolean(value: Any, field: str) -> Optional[bool]:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return value
    if value in (1, "1", "true", "True"):
        return True
    if value in (0, "0", "false", "False"):
        return False
    raise _contract_value_error(field, "boolean")


def _normalize_new_licence_public_types(form_data: dict[str, Any]) -> None:
    """Keep the unified NLA Query types aligned with the Create contract.

    Native NocoBase decimal, boolean and date fields may be serialized as
    strings. This changes only the public create_id projection, not stored
    business data or legacy list endpoints.
    """
    part_1 = form_data.get("part_1")
    if isinstance(part_1, dict):
        for field in ("application_received_date", "tentative_commencement_date"):
            if field in part_1:
                part_1[field] = _contract_date(part_1[field], f"part_1.{field}")
    part_2 = form_data.get("part_2")
    if isinstance(part_2, dict):
        for field in ("monthly_fee_min", "monthly_fee_max", "floor_area_sqm"):
            if field in part_2:
                part_2[field] = _contract_number(part_2[field], f"part_2.{field}")
        for field in (
            "licence_capacity",
            "floors_total",
            "units_total",
            "nursing_home_places",
            "care_and_attention_home_places",
            "aged_home_places",
            "self_care_hostel_places",
            "max_capacity",
            "existing_capacity",
            "enrolment_residents",
        ):
            if field in part_2:
                part_2[field] = _contract_integer(part_2[field], f"part_2.{field}")
        for field in ("is_rcsv", "complies_lease_dmc"):
            if field in part_2:
                part_2[field] = _contract_boolean(part_2[field], f"part_2.{field}")
        premises = part_2.get("premises")
        if isinstance(premises, dict):
            for category in ("self_owned", "rented"):
                for premise in premises.get(category) or []:
                    if not isinstance(premise, dict):
                        continue
                    for field in ("tenancy_from", "tenancy_to"):
                        if field in premise:
                            premise[field] = _contract_date(
                                premise[field], f"part_2.premises.{category}.{field}"
                            )
    part_3 = form_data.get("part_3")
    if isinstance(part_3, dict):
        for field in ("date_of_operation", "signature_date"):
            if field in part_3:
                part_3[field] = _contract_date(part_3[field], f"part_3.{field}")
        contacts = [part_3.get("operator"), part_3.get("company")]
        contacts.extend(part_3.get("personnel") or [])
    else:
        contacts = []
    part_4 = form_data.get("part_4")
    if isinstance(part_4, dict):
        contacts.append(part_4.get("authorised_representative"))
    for contact in contacts:
        if not isinstance(contact, dict):
            continue
        for field in ("active", "address_for_licence"):
            if field in contact:
                contact[field] = _contract_boolean(contact[field], f"contact.{field}")


def _restore_responsible_person_business_statuses(
    filtered: dict[str, Any], original: dict[str, Any]
) -> None:
    """Keep RP questionnaire answers that happen to use ``status`` in names."""
    filtered_form = filtered.get("form_data")
    original_form = original.get("form_data")
    if not isinstance(filtered_form, dict) or not isinstance(original_form, dict):
        return
    if "ceased_status" in original_form:
        filtered_form["ceased_status"] = original_form.get("ceased_status")
    filtered_questions = filtered_form.get("other_particulars")
    original_questions = original_form.get("other_particulars")
    if not isinstance(filtered_questions, dict) or not isinstance(
        original_questions, dict
    ):
        return
    for question_name in ("q1", "q2", "q3", "q4"):
        filtered_question = filtered_questions.get(question_name)
        original_question = original_questions.get(question_name)
        if isinstance(filtered_question, dict) and isinstance(original_question, dict):
            filtered_question["case_status"] = original_question.get("case_status")


def _public_application(
    row: dict[str, Any], *, include_intake: bool = True
) -> dict[str, Any]:
    intake = row.get("f_intake_form")
    intake = intake if isinstance(intake, dict) else {}
    contacts = row.get("f_licence_contact_person") or []
    premises = row.get("f_licence_app_premise") or []
    checklist = row.get("f_documents_submitted") or []
    rch_type = row.get("f_type_of_rch")
    rch_type = rch_type if isinstance(rch_type, dict) else {}
    form_data = {
        "case_summary": {
            "office_code": row.get("f_office_cd") or intake.get("f_office_cd"),
            "submitter_user_id": row.get("createdById") or intake.get("createdById"),
            "received_date": intake.get("f_received_date"),
            "severity": intake.get("f_severity"),
            "source_id": intake.get("fk_intake_source"),
            "source_other": intake.get("f_source_other"),
            "task_owner_user_id": intake.get("fk_task_owner"),
            "task_owner_post_code": intake.get("fk_task_owner_post"),
        },
        "part_1": {
            "application_received_date": row.get("f_application_received_date"),
            "application_type": row.get("f_app_type"),
            "tentative_commencement_date": row.get(
                "f_tentative_service_commencement_date"
            ),
        },
        "part_2": {
            "rch_name_en": row.get("f_rch_name_en"),
            "rch_name_cn": row.get("f_rch_name_cn"),
            "operation_mode_id": row.get("fk_rch_nature"),
            "premises_type": row.get("f_rch_premises"),
            "monthly_fee_min": row.get("f_monthly_fee_per_resident_min"),
            "monthly_fee_max": row.get("f_monthly_fee_per_resident_max"),
            "gender": row.get("f_rch_gender"),
            "floor_area_sqm": row.get("f_net_floor_area_sqm"),
            "licence_capacity": row.get("f_licence_capacity"),
            "address": _public_address(row.get("f_rch_address")),
            "telephone_no": row.get("f_telephone_no"),
            "fax_no": row.get("f_fax_no"),
            "email": row.get("f_email"),
            "floors_total": row.get("f_floors_total"),
            "units_total": row.get("f_units_total"),
            "operation_mode_other": row.get("f_rch_nature_other"),
            "is_rcsv": row.get("f_is_rcsv"),
            "rch_type_code": rch_type.get("f_code"),
            "complies_lease_dmc": row.get("f_complies_lease_dmc"),
            "complies_lease_dmc_other": row.get("f_complies_lease_dmc_other"),
            "nursing_home_places": row.get("f_beds_nursing"),
            "care_and_attention_home_places": row.get("f_beds_care_and_attention"),
            "aged_home_places": row.get("f_beds_meal"),
            "self_care_hostel_places": row.get("f_beds_self_care"),
            "max_capacity": row.get("f_max_capacity"),
            "existing_capacity": row.get("f_existing_capacity"),
            "enrolment_residents": row.get("f_enrolment_residents"),
            "premises": _public_premises(premises),
        },
        "part_3": {
            "rch_business_status": row.get("f_service_type"),
            "applicant_operator_type": row.get("f_business_ownership_type"),
            "date_of_operation": row.get("f_date_of_operation"),
            "signature_date": row.get("f_signature_date"),
            "operator": _public_contact(row.get("f_licence_contact_operator")),
            "company": _public_contact(row.get("f_licence_contact_company")),
            "personnel": [
                _public_contact(item) for item in contacts if isinstance(item, dict)
            ],
        },
        "part_4": {
            "authorised_representative": _public_contact(
                row.get("f_licence_contact_applicant")
            )
        },
        "part_5": {
            "application_level": row.get("f_application_level"),
            "comments": row.get("f_comments"),
            "other_information": row.get("f_other_information"),
            "remarks": row.get("f_remarks"),
            "attachments": _public_attachments(row.get("f_attachments_of_rchs") or []),
            "attachment_ids": [
                item.get("id")
                for item in row.get("f_attachments_of_rchs") or []
                if isinstance(item, dict) and item.get("id") is not None
            ],
            "checklist": [
                _public_checklist(item)
                for item in checklist
                if isinstance(item, dict) and item.get("id") is not None
            ],
        },
    }
    result = {
        "application_id": row.get("id"),
        "intake_id": row.get("fk_intake_form") or intake.get("id"),
        "office_code": row.get("f_office_cd"),
        "application_status": _enum(
            row.get("f_approval_status"), APPLICATION_STATUS_OPTIONS
        ),
        "letter_attachments": _public_letter_attachments(
            row.get("f_letter_attachments")
        ),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": form_data,
    }
    if include_intake:
        result["intake"] = {
            "intake_id": intake.get("id") or row.get("fk_intake_form"),
            "intake_no": intake.get("f_intake_no"),
            "intake_status": _enum(
                intake.get("f_approval_status"), INTAKE_STATUS_OPTIONS
            ),
            "activities": [
                _public_activity(item)
                for item in intake.get("f_activity") or []
                if isinstance(item, dict)
            ],
        }
    return result


def _public_changing_home_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    staging_rch_id: Any,
) -> dict[str, Any]:
    normalized = dict(row)
    normalized["f_licence_app_premise"] = row.get("f_tenancy_agreements") or []
    normalized["f_documents_submitted"] = checklist
    result = _public_application(normalized)
    home = row.get("f_home_record")
    home = home if isinstance(home, dict) else {}
    result["home_record_id"] = (
        row.get("fk_home_record") or home.get("id") or staging_rch_id
    )
    form_data = result.get("form_data")
    if isinstance(form_data, dict):
        case_summary = form_data.get("case_summary")
        if isinstance(case_summary, dict):
            case_summary["lorche_d_no"] = row.get("f_rch_no") or home.get("f_rch_no")
            case_summary["p_no"] = home.get("f_final_o_no")
        part_2 = form_data.get("part_2")
        if isinstance(part_2, dict):
            # The Changing Home popup writes f_licence_capacity; the generic
            # NLA form uses a different f_max_capacity field.
            part_2["max_capacity"] = row.get("f_licence_capacity")
        form_data.update(
            {
                "is_change_name": bool(row.get("is_change_name")),
                "is_change_address": bool(row.get("is_change_address")),
                "is_change_operator_or_operating_company": bool(
                    row.get("is_change_operator_or_operating_company")
                ),
                "is_change_rch_type": bool(row.get("is_change_rch_type")),
                "is_change_maximum_capacity": bool(
                    row.get("is_change_maximum_capacity")
                ),
                "is_aip": bool(row.get("is_aip")),
            }
        )
        part_3 = form_data.get("part_3")
        if isinstance(part_3, dict):
            part_3["company"] = _public_chi_contact(
                row.get("f_licence_contact_company")
            )
            people = row.get("f_licence_contact_person")
            if isinstance(people, list):
                chi_people = [
                    contact
                    for value in people
                    if (contact := _public_chi_contact(value)) is not None
                ]
                # Preserve the original singular/operator and personnel
                # projections for existing clients.  The ID-free CHI full-list
                # replacement contract uses operators[] in both request and
                # query; never choose an arbitrary person for the singular key.
                part_3["personnel"] = chi_people
                part_3["operators"] = chi_people
                part_3["operator"] = chi_people[0] if len(chi_people) == 1 else None
    return result


def _related_id(value: Any) -> Any:
    if isinstance(value, dict):
        return value.get("id")
    return value


def _task_owner_post_code(value: Any) -> Any:
    if not isinstance(value, dict):
        return value
    for field in ("f_post_cd", "f_post_code", "code", "name"):
        if value.get(field) not in (None, ""):
            return value[field]
    return value.get("id")


def _public_home_bound_case_summary(
    intake: dict[str, Any],
    home: dict[str, Any],
    *,
    office_code: Any,
    received_date: Any = None,
) -> dict[str, Any]:
    return {
        "office_code": office_code,
        "lorche_d_no": home.get("f_rch_no"),
        "p_no": home.get("f_final_o_no"),
        "submitter_user_id": _related_id(
            intake.get("createdBy") or intake.get("createdById")
        ),
        "received_date": received_date or intake.get("f_received_date"),
        "severity": intake.get("f_severity"),
        "source_id": _related_id(intake.get("fk_intake_source")),
        "source_other": intake.get("f_source_other"),
        "task_owner_user_id": _related_id(intake.get("fk_task_owner")),
        "task_owner_post_code": _task_owner_post_code(
            intake.get("fk_task_owner_post")
        ),
    }


def _public_closure_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
) -> dict[str, Any]:
    intake = row.get("f_intake_form")
    intake = intake if isinstance(intake, dict) else {}
    home_id = row.get("fk_home_record_id") or home.get("id") or staging_rch_id
    form_data = {
        "case_summary": _public_home_bound_case_summary(
            intake,
            home,
            office_code=row.get("f_office_cd") or intake.get("f_office_cd"),
            received_date=row.get("f_received_date"),
        ),
        "workflow_type": row.get("f_closure_workflow_type"),
        "type_of_closure": row.get("f_type_of_closure"),
        "applicant_title": row.get("f_applicant_title"),
        "applicant_name_en": row.get("f_applicant_name_eng"),
        "applicant_name_cn": row.get("f_applicant_name_chi"),
        "applicant_position": row.get("f_applicant_position"),
        "means_of_authorisation": row.get("f_means_of_authorisation"),
        "tentative_date_of_closure": row.get("f_tentative_date_of_closure"),
        "actual_date_of_closure": row.get("f_actual_date_of_closure"),
        "reason_for_closure": row.get("f_reason_for_closure"),
        "reason_for_closure_others": row.get("f_reason_for_closure_others"),
        "comments": row.get("f_comments"),
        "checklist": _public_checklist_items(checklist),
    }
    return {
        "application_id": row.get("id"),
        "home_record_id": home_id,
        "office_code": row.get("f_office_cd"),
        "application_status": _enum(
            row.get("f_approval_status"), APPLICATION_STATUS_OPTIONS
        ),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": form_data,
        "intake": {
            "intake_id": intake.get("id") or row.get("fk_intake_form"),
            "intake_no": intake.get("f_intake_no"),
            "intake_status": _enum(
                intake.get("f_approval_status"), INTAKE_STATUS_OPTIONS
            ),
        },
    }


def _public_checklist_items(checklist: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        _public_checklist(item) for item in checklist if isinstance(item, dict)
    ]


def _natural_sort_value(value: Any) -> tuple[int, Any]:
    """Sort NocoBase number-like values first and keep null values last."""
    if value is None:
        return (2, "")
    try:
        return (0, float(value))
    except (TypeError, ValueError):
        return (1, str(value))


def _specific_hour_time_rows(values: Any) -> list[dict[str, Any]]:
    rows = (
        [item for item in values if isinstance(item, dict)]
        if isinstance(values, list)
        else []
    )
    rows.sort(
        key=lambda item: (
            _natural_sort_value(item.get("f_sort_order")),
            _natural_sort_value(item.get("f_work_hour_from")),
            _natural_sort_value(item.get("f_work_hour_to")),
            _natural_sort_value(item.get("id")),
        )
    )
    return [
        {
            "work_hour_from": item.get("f_work_hour_from"),
            "work_hour_to": item.get("f_work_hour_to"),
            "duration_hours": item.get("f_duration_hours"),
            "remark": item.get("f_remark"),
        }
        for item in rows
    ]


def _specific_hour_staffings(values: Any) -> list[dict[str, Any]]:
    rows = (
        [item for item in values if isinstance(item, dict)]
        if isinstance(values, list)
        else []
    )

    def staff_code(item: dict[str, Any]) -> Any:
        relation = item.get("f_staff_type_id")
        return relation.get("f_staff_code") if isinstance(relation, dict) else None

    rows.sort(
        key=lambda item: (
            _natural_sort_value(item.get("f_sort_order")),
            _natural_sort_value(staff_code(item)),
            _natural_sort_value(item.get("id")),
        )
    )
    return [
        {
            "staff_type_code": staff_code(item),
            "other_duties": item.get("f_duty_description"),
            "staff_ratio_requirement": item.get("f_staff_ratio_requirement"),
            "minimum_required_hours": item.get("f_minimum_required_hours"),
            "time_rows": _specific_hour_time_rows(
                item.get("f_specific_hour_time_rows")
            ),
        }
        for item in rows
    ]


def _specific_hour_options(values: Any) -> list[dict[str, Any]]:
    rows = (
        [item for item in values if isinstance(item, dict)]
        if isinstance(values, list)
        else []
    )
    rows.sort(
        key=lambda item: (
            _natural_sort_value(item.get("f_specific_hour_set_no")),
            _natural_sort_value(item.get("id")),
        )
    )
    return [
        {
            "set_no": item.get("f_specific_hour_set_no"),
            "section": item.get("f_section"),
            "section_other": item.get("f_section_other"),
            "staffings": _specific_hour_staffings(
                item.get("f_specific_hour_staffings")
            ),
        }
        for item in rows
    ]


def _public_specific_hour_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
) -> dict[str, Any]:
    intake = row.get("f_intake_form")
    intake = intake if isinstance(intake, dict) else {}
    home_id = row.get("fk_home_record") or home.get("id") or staging_rch_id
    return {
        "application_id": row.get("id"),
        "home_record_id": home_id,
        "office_code": intake.get("f_office_cd"),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": {
            "case_summary": _public_home_bound_case_summary(
                intake,
                home,
                office_code=intake.get("f_office_cd"),
            ),
            "application_detail": row.get("f_application_detail"),
            "applicant_title": row.get("f_applicant_title"),
            "applicant_name_en": row.get("f_applicant_name_en"),
            "applicant_name_cn": row.get("f_applicant_name_cn"),
            "authorisation_method": row.get("f_authorisation_method"),
            "rch_care_level": row.get("f_rch_care_level"),
            "tentative_commencement_date": row.get("f_tentative_commencement_date"),
            "tentative_effective_date": row.get("f_tentative_effective_date"),
            "authorised_to_apply": row.get("f_authorised_to_apply"),
            "certificate_name_en": row.get("f_certificate_name_en"),
            "specific_hour_set_count": row.get("f_specific_hour_set_count"),
            "specific_hour_options": _specific_hour_options(
                row.get("f_specific_hour_options")
            ),
            "declaration_acknowledged": row.get("f_declaration_acknowledged"),
            "warning_acknowledged": row.get("f_warning_acknowledged"),
            "declared_at": row.get("f_declared_at"),
            "checklist": _public_checklist_items(checklist),
        },
        "intake": {
            "intake_id": intake.get("id") or row.get("fk_intake_form"),
            "intake_no": intake.get("f_intake_no"),
        },
    }


def _rp_legal_question(row: dict[str, Any], question: int) -> dict[str, Any]:
    mappings = {
        1: {
            "answer": "f_q1_answer",
            "case_status": "f_q1_case_status",
            "prosecuting_authority": "f_q1_prosecuting_authority",
            "place_of_proceeding": "f_fxeb5nzxq5f",
            "offence_involved": "f_q1_offence",
            "hearing_date": "f_q1_conviction_date",
            "court": "f_q2_court",
            "place_of_court": "q1Place_of",
            "offence_committed": "f_q2_offence",
            "penalty": "f_q1_penalty",
            "conviction_date": "f_q2_conviction_date",
        },
        2: {
            "answer": "f_q4_answer",
            "case_status": "q2being_and_has",
            "prosecuting_authority": "q2Prosecuting_Authority",
            "offence_involved": "q2Offence_involved",
            "hearing_date": "q2hearing",
            "court": "f_q3_court",
            "offence_committed": "f_q3_offence",
            "penalty": "f_q2_penalty",
            "conviction_date": "f_q3_conviction_date",
        },
        3: {
            "answer": "f_q3_answer",
            "case_status": "f_q3_case_status",
            "prosecuting_authority": "f_q3_court_place",
            "place_of_proceeding": "f_q4_prosecuting_authority",
            "offence_involved": "f_q4_offence",
            "hearing_date": "f_q4_hearing_date",
            "court": "f_q4_case_status",
            "place_of_court": "q3Place_of",
            "offence_committed": "q3Offence_Committed",
            "penalty": "f_q3_penalty",
            "conviction_date": "q3Date_of_Conviction",
        },
        4: {
            "answer": "q4_",
            "case_status": "q4being_has",
            "prosecuting_authority": "q4Prosecuting_Authority",
            "offence_involved": "q4Offence_involved",
            "hearing_date": "q4Date_of_hearing",
            "court": "q4Court",
            "offence_committed": "q4Offence_Committed",
            "penalty": "q4Penalty_imposed",
            "conviction_date": "q4Date_of_conviction",
        },
    }
    result = {
        public_name: row.get(native_name)
        for public_name, native_name in mappings[question].items()
    }
    raw_status = result.get("case_status")
    normalized_statuses = {
        1: {
            "being prosecuted currently": "being_prosecuted_currently",
            "has been convicted": "has_been_convicted",
        },
        2: {
            "being prosecuted currently": "being_prosecuted_currently",
            "has been convicted": "has_been_convicted",
        },
        3: {
            "q3being": "being_prosecuted_currently",
            "q3has": "has_been_convicted",
        },
        4: {
            "q4being prosecuted currently": "being_prosecuted_currently",
            "q4has been convicted": "has_been_convicted",
        },
    }
    result["case_status"] = normalized_statuses[question].get(raw_status, raw_status)
    return result


def _rp_other_particulars(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "q1": _rp_legal_question(row, 1),
        "q2": _rp_legal_question(row, 2),
        "q3": _rp_legal_question(row, 3),
        "q4": _rp_legal_question(row, 4),
        "q5": {
            "answer": row.get("f_q5_answer"),
            "date": row.get("f_q5_date"),
            "rch_no_and_name": row.get("f_q5_rch_name"),
            "reasons": row.get("f_q5_reasons"),
        },
        "q6": {
            "answer": row.get("f_q6_answer"),
            "adjudication_date": row.get("f_q6_adjudication_date"),
            "court": row.get("f_q6_court"),
        },
        "q7": {
            "answer": row.get("f_q7_answer"),
            "adjudication_date": row.get("f_q7_adjudication_date"),
            "repayment_proposal": row.get("f_q7_court"),
        },
        "q8": {
            "answer": row.get("f_q8_answer"),
            "company_name_en": row.get("f_q8_company_name_en"),
            "company_name_cn": row.get("f_q8_company_name_zh"),
            "business_registration_no": row.get("f_q8_business_registration_no"),
            "certificate_of_incorporation_no": row.get(
                "f_q8_certificate_incorporation_no"
            ),
            "registered_address": row.get("q8Registered_address"),
            "adjudication_date": row.get("f_q8_adjudication_date"),
            "court": row.get("f_q8_court"),
        },
    }


def _rp_currently_appointed_homes(values: Any) -> list[dict[str, Any]]:
    rows = (
        [item for item in values if isinstance(item, dict)]
        if isinstance(values, list)
        else []
    )
    rows.sort(
        key=lambda item: (
            _natural_sort_value(item.get("f_rch_no")),
            _natural_sort_value(item.get("f_rch_name")),
            _natural_sort_value(item.get("id")),
        )
    )
    return [
        {"rch_no": item.get("f_rch_no"), "rch_name": item.get("f_rch_name")}
        for item in rows
    ]


def _public_responsible_person_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
) -> dict[str, Any]:
    intake = row.get("fk_intake")
    intake = intake if isinstance(intake, dict) else {}
    home_id = row.get("fk_home_record_id") or home.get("id") or staging_rch_id
    return {
        "application_id": row.get("id"),
        "home_record_id": home_id,
        "office_code": row.get("f_office_code") or intake.get("f_office_cd"),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": {
            "case_summary": _public_home_bound_case_summary(
                intake,
                home,
                office_code=(
                    row.get("f_office_code") or intake.get("f_office_cd")
                ),
                received_date=row.get("f_application_received_date"),
            ),
            "rp_title": row.get("f_rp_title"),
            "rp_name_en": row.get("f_rp_name_en"),
            "rp_name_cn": row.get("f_rp_name_zh"),
            "rp_hkid": row.get("f_rp_hkid"),
            "rp_hkid_no_1": row.get("HKIC_number1"),
            "rp_hkid_no_2": row.get("HKIC_number2"),
            "rp_hkid_no_3": row.get("HKIC_number3"),
            "rp_tel": row.get("f_rp_tel"),
            "rp_email": row.get("p3_Email") or row.get("f_rp_email"),
            "rp_address_en": row.get("f_rp_address_en"),
            "rp_address_cn": row.get("f_rp_address_zh"),
            "rp_position_type": row.get("f_rp_position_type"),
            "rp_other_home": row.get("f_rp_other_home"),
            "currently_appointed_homes": _rp_currently_appointed_homes(
                row.get("f_t_rp_currently_appointed")
            ),
            "rp_application_type": row.get("f_application_type"),
            "change_reason": row.get("f_change_reason"),
            "change_reason_other": row.get("f_change_reason_other"),
            "ceased_status": row.get("f_ceased_status"),
            "cease_position_date": row.get("f_cease_position_date"),
            "new_rp_assume_office_date": row.get("f_new_rp_assume_office_date"),
            "notice_expected_issued_date": row.get("f_notice_expected_issued_at"),
            "authorised_rep_position": row.get("f_authorised_rep_position"),
            "other_particulars": _rp_other_particulars(row),
            "declaration": {
                "acknowledged": row.get("p8_checked"),
                "signature_date_of_rp": row.get("f_signature_date_of_rp"),
                "signature_date_of_applicant_representative_partner": row.get(
                    "f_signature_date_of_applicant_representative_partner"
                ),
            },
            "checklist": _public_checklist_items(checklist),
        },
        "intake": {
            "intake_id": intake.get("id") or row.get("fk_intake_id"),
            "intake_no": intake.get("f_intake_no"),
        },
    }


def _public_change_monitoring_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
    *,
    application_type: str,
    child_assoc: str,
) -> dict[str, Any]:
    del checklist
    intake = row.get("f_intake_form")
    intake = intake if isinstance(intake, dict) else {}
    child = row.get(child_assoc)
    child = child if isinstance(child, dict) else {}
    home_id = row.get("fk_home_record_id") or home.get("id") or staging_rch_id
    office = row.get("f_office_cd") or intake.get("f_office_cd")
    form_data: dict[str, Any] = {
        "case_summary": {
            "office_code": office,
            "lorche_d_no": home.get("f_rch_no"),
            "p_no": home.get("f_final_o_no"),
        },
        "proposed_effective_date": row.get("f_proposed_effective_date"),
    }
    if application_type == CHANGE_HOME_MANAGER_APPLICATION_TYPE:
        form_data.update(
            {
                "proposed_name": child.get("f_proposed_name"),
                "proposed_tel": child.get("f_proposed_tel"),
                "proposed_email": child.get("f_proposed_email"),
                "proposed_post": child.get("f_proposed_post"),
                "proposed_remark": child.get("f_proposed_remark"),
            }
        )
    elif application_type == CHANGE_BEDS_APPLICATION_TYPE:
        form_data.update(
            {
                "proposed_beds_self_care": child.get("f_proposed_beds_self_care"),
                "proposed_beds_meal": child.get("f_proposed_beds_meal"),
                "proposed_beds_nursing": child.get("f_proposed_beds_nursing"),
                "proposed_beds_care_and_attention": child.get(
                    "f_proposed_beds_care_and_attention"
                ),
                "proposed_residents_total_ab": child.get(
                    "f_proposed_residents_total_ab"
                ),
                "proposed_residents_total_a": child.get("f_proposed_residents_total_a"),
                "proposed_residents_total_b": child.get("f_proposed_residents_total_b"),
                "proposed_residents_self_care": child.get(
                    "f_proposed_residents_self_care"
                ),
                "proposed_residents_meal": child.get("f_proposed_residents_meal"),
                "proposed_residents_nursing": child.get("f_proposed_residents_nursing"),
                "proposed_residents_care_and_attention": child.get(
                    "f_proposed_residents_care_and_attention"
                ),
                "proposed_residents_nursing_beyond": child.get(
                    "f_proposed_residents_nursing_beyond"
                ),
                "proposed_residents_nonelderly_mental": child.get(
                    "f_proposed_residents_nonelderly_mental"
                ),
                "proposed_residents_nonelderly_intellectual": child.get(
                    "f_proposed_residents_nonelderly_intellectual"
                ),
                "proposed_residents_nonelderly_physical": child.get(
                    "f_proposed_residents_nonelderly_physical"
                ),
                "proposed_residents_nonelderly_others": child.get(
                    "f_proposed_residents_nonelderly_others"
                ),
                "proposed_residents_nonelderly_others_specify": child.get(
                    "f_proposed_residents_nonelderly_others_specify"
                ),
                "proposed_residents_nonelderly_other_details_num": child.get(
                    "f_proposed_residents_nonelderly_other_details_num"
                ),
            }
        )
    elif application_type == CHANGE_OPERATION_MODE_APPLICATION_TYPE:
        nature = child.get("f_proposed_rch_nature")
        form_data["proposed_rch_nature_code"] = (
            nature.get("f_code")
            if isinstance(nature, dict)
            else child.get("fk_proposed_rch_nature")
        )
    elif application_type == CHANGE_DIRECTORS_APPLICATION_TYPE:
        form_data.update(
            {
                "title": child.get("f_title"),
                "name_en": child.get("f_name_eng"),
                "name_cn": child.get("f_name_chi"),
                "hkid_no": child.get("f_hkid_number"),
                "date_of_directors_change": child.get("f_date_of_directors_change"),
                "position_in_rch": child.get("f_position_in_the_rche_rche_nh"),
                "authorised_to_apply": child.get("f_authorised_to_apply"),
                "means_of_authorisation": child.get("f_means_of_authorisation"),
                "signature_name_en": child.get("f_signature_name_eng"),
                "signature_name_cn": child.get("f_signature_name_chi"),
                "signature_title": child.get("f_signature_title"),
                "other_phone_number": child.get("f_other_phone_number"),
                "hkid_no_1": child.get("f_hkid_no_1"),
                "hkid_no_2": child.get("f_hkid_no_2"),
                "hkid_no_3": child.get("f_hkid_no_3"),
                "hkid_check_digit": child.get("f_hkid_check_digit"),
                "digital_organisation_certificate_name_en": child.get(
                    "f_name_eng_of_digital_organisation_certificate"
                ),
                "documents": [
                    {
                        "document_type": document.get("f_document_type"),
                        "attachment_ids": [
                            attachment.get("id")
                            for attachment in (
                                document.get("f_lastest_files") or []
                            )
                            if isinstance(attachment, dict)
                            and attachment.get("id") is not None
                        ],
                        "remarks": document.get("f_remarks"),
                    }
                    for document in (child.get("f_uploading_documents") or [])
                    if isinstance(document, dict)
                ],
            }
        )
    elif application_type == CHANGE_NURSE_APPLICATION_TYPE:
        form_data.update(
            {
                "person_title": child.get("f_person_title"),
                "name": child.get("f_name"),
                "tel": child.get("f_tel"),
                "email": child.get("f_email"),
                "position": child.get("f_position"),
            }
        )
    return {
        "application_id": row.get("id"),
        "home_record_id": home_id,
        "office_code": office,
        "letter_attachments": _public_letter_attachments(
            row.get("f_letter_attachments")
        ),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": form_data,
        "intake": {
            "intake_id": intake.get("id") or row.get("fk_intake_form"),
            "intake_no": intake.get("f_intake_no"),
        },
    }


def _public_prosecution_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
) -> dict[str, Any]:
    del checklist
    intake = row.get("f_intake_form")
    intake = intake if isinstance(intake, dict) else {}
    home_id = row.get("fk_home_record_id") or home.get("id") or staging_rch_id
    office = row.get("f_office_cd") or intake.get("f_office_cd")
    offences = [
        {
            "name_of_defendant": item.get("f_name_of_defendant"),
            "name_of_defendant_chi": item.get("f_name_of_defendant_chi"),
            "type_of_defendant": item.get("f_type_of_defendant"),
            "hkic_no": item.get("f_hkic_no"),
            "date_of_birth": item.get("f_date_of_birth"),
            "offence_charged": item.get("f_offence_charged"),
            "offence_charged_items": item.get("f_offence_charged_items"),
            "offence_charged_items_others": item.get("f_offence_charged_items_others"),
            "detail_of_offence": item.get("f_detail_of_offence"),
            "section_cap": item.get("f_section_cap_of_the_offences"),
            "pg_png": item.get("f_pg_png"),
            "date_of_conviction": item.get("f_date_of_conviction"),
            "sanction": item.get("f_sanction"),
            "court_disposal": item.get("f_court_disposal"),
            "remark": item.get("f_remark"),
            "business_registration_number": item.get(
                "f_business_registration_number_if_applicable"
            ),
            "certificate_of_incorporation_number": item.get(
                "f_certificate_of_incorporation_number_if_applicable"
            ),
            "brc_no": item.get("f_brc_no"),
            "trust_number": item.get("f_the_trust_number_if_applicable"),
        }
        for item in (row.get("f_offence_charged_items") or [])
        if isinstance(item, dict)
    ]
    return {
        "application_id": row.get("id"),
        "home_record_id": home_id,
        "office_code": office,
        "letter_attachments": _public_letter_attachments(
            row.get("f_letter_attachments")
        ),
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": {
            "case_summary": {
                "office_code": office,
                "lorche_d_no": home.get("f_rch_no") or row.get("f_rch_no"),
                "p_no": home.get("f_final_o_no"),
            },
            "serial_no": row.get("f_serial_no"),
            "court_case_no": row.get("f_court_case_no"),
            "unlicenced_rch": row.get("f_unlicenced_rch"),
            "legal_advice_result": row.get("f_result_of_seeking_legal_advice_from_doj"),
            "date_of_advice_from_doj": row.get("f_date_of_advice_from_doj"),
            "date_of_enforcement_action": row.get("f_date_of_enforcement_action"),
            "first_court_hearing_date": row.get("f_first_court_hearing_date"),
            "last_court_hearing_date": row.get("f_last_court_hearing_date"),
            "reason": row.get("f_reason"),
            "remarks": row.get("f_remarks"),
            "comments": row.get("f_comments"),
            "offence_items": offences,
            "offence_charged_items": offences,
        },
        "intake": {
            "intake_id": intake.get("id") or row.get("fk_intake_form"),
            "intake_no": intake.get("f_intake_no"),
        },
    }


def _public_licence_renewal_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
) -> dict[str, Any]:
    home_rel = row.get("f_renewal_home_record")
    home_rel = home_rel if isinstance(home_rel, dict) else home
    normalized = dict(row)
    # A sparse LRN Update may clear a previously submitted position without
    # deleting its native row. Only positions with a current submitted file
    # belong in the external replacement array; inactive/history rows do not.
    normalized["f_documents_submitted"] = [
        record
        for record in checklist
        if isinstance(record, dict)
        and record.get("f_is_checked") is True
        and (public := _public_checklist(record)).get("position_code")
        and public.get("attachment_id") is not None
    ]
    normalized["f_home_record"] = home_rel
    result = _public_application(normalized, include_intake=False)
    form_data = result.get("form_data")
    if isinstance(form_data, dict):
        case_summary = form_data.get("case_summary")
        if isinstance(case_summary, dict):
            case_summary["lorche_d_no"] = (
                row.get("f_rch_no") or row.get("f_d_no") or home_rel.get("f_rch_no")
            )
            case_summary["p_no"] = home_rel.get("f_final_o_no")
            case_summary["office_code"] = row.get("f_office_cd") or case_summary.get(
                "office_code"
            )
            case_summary["received_date"] = row.get("f_application_received_date")
    result["home_record_id"] = (
        row.get("fk_renewal_home_record_id") or home_rel.get("id") or staging_rch_id
    )
    result["intake"] = {"intake_id": None, "intake_no": None}
    return result


def _public_expansion_aip_application(
    row: dict[str, Any],
    checklist: list[dict[str, Any]],
    home: dict[str, Any],
    staging_rch_id: Any,
) -> dict[str, Any]:
    intake = row.get("f_intake_form")
    intake = intake if isinstance(intake, dict) else {}
    office_code = row.get("f_office_cd") or intake.get("f_office_cd")
    home_record_id = (
        row.get("fk_home_record_id") or home.get("id") or staging_rch_id
    )
    return {
        "application_id": row.get("id"),
        "home_record_id": home_record_id,
        "office_code": office_code,
        "created_at": row.get("createdAt"),
        "updated_at": row.get("updatedAt"),
        "form_data": {
            "case_summary": _public_home_bound_case_summary(
                intake,
                home,
                office_code=office_code,
                received_date=row.get("f_received_date"),
            ),
            "part_1": {
                "title": row.get("f_title"),
                "name_eng": row.get("f_name_eng"),
                "name_chi": row.get("f_name_chi"),
                "authorised_to_apply_by_operator": row.get(
                    "f_authorised_to_apply_by_operator"
                ),
                "means_of_authorisation": row.get("f_means_of_authorisation"),
                "authorised_name_eng": row.get("f_authorised_name_eng"),
                "hkic_number1": row.get("f_hkic_number1"),
                "hkic_number2": row.get("f_hkic_number2"),
            },
            "part_2": {
                "address_chi_expansion": row.get("f_address_chi_expansion"),
                "address_eng_expansion": row.get("f_address_eng_expansion"),
                "tentative_licencing_capacity_expansion": row.get(
                    "f_tentative_licencing_capacity_expansion"
                ),
                "tentative_area_of_floor_space_expansion": row.get(
                    "f_existing_area_of_floor_space_expansion"
                ),
                "number_of_beds_expansion": row.get("f_number_of_beds_expansion"),
            },
            "part_3": {
                "checklist": [
                    item
                    for record in checklist
                    if record.get("f_is_checked")
                    and (item := _public_checklist(record)).get("position_code")
                ]
            },
        },
        "intake": {
            "intake_id": intake.get("id") or row.get("fk_intake_form"),
            "intake_no": intake.get("f_intake_no"),
        },
    }


def _public_address(value: Any) -> Optional[dict[str, Any]]:
    if not isinstance(value, dict) or value.get("id") is None:
        return None
    result = {
        "region_code": _relation_code(value.get("f_region_en")),
        "district_code": _relation_code(value.get("f_district_name_en")),
        "sub_district_code": _relation_code(value.get("f_sub_district_en")),
    }
    result.update(
        {public: value.get(native) for public, native in ADDRESS_FIELDS.items()}
    )
    return result


def _relation_code(value: Any) -> Any:
    return value.get("f_code") if isinstance(value, dict) else None


def _public_contact(value: Any) -> Optional[dict[str, Any]]:
    if not isinstance(value, dict) or value.get("id") is None:
        return None
    result = {"id": value.get("id")}
    result.update(
        {public: value.get(native) for public, native in CONTACT_FIELDS.items()}
    )
    result["address"] = _public_address(value.get("f_address_correspondence"))
    return result


def _public_chi_contact(value: Any) -> Optional[dict[str, Any]]:
    """Project only CHI-owned popup children; do not change NLA contacts."""
    result = _public_contact(value)
    if result is None:
        return None
    if not isinstance(value, dict):
        return result
    registration = value.get("f_rpop_op_app")
    if isinstance(registration, list) and len(registration) == 1:
        child = registration[0]
        if isinstance(child, dict):
            selected = child.get("f_company_registration_identifier_types")
            if isinstance(selected, list):
                result["registration_identifier_types"] = [
                    str(item) for item in selected
                ]
            elif selected is not None:
                # Older NocoBase rows contain a scalar despite an array schema.
                result["registration_identifier_types"] = [str(selected)]
            result["legislation_chapter_no"] = child.get("f_legislation_chapter_no")
    answers = {
        str(slot): detail["f_declaration_answer"]
        for slot in range(1, 11)
        if isinstance(detail := value.get(f"f_rpop_app_detail_{slot}"), dict)
        and detail.get("f_declaration_answer") in ("Yes", "No")
    }
    if answers:
        result["declaration_answers"] = answers
    return result


def _public_premises(values: Any) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {"self_owned": [], "rented": []}
    for row in values if isinstance(values, list) else []:
        if not isinstance(row, dict):
            continue
        base = {
            "id": row.get("id"),
            "premise_type": row.get("f_premise_type"),
            "location": row.get("f_location"),
            "tenancy_from": row.get("f_tenancy_from"),
            "tenancy_to": row.get("f_tenancy_to"),
            "sort_order": row.get("f_sort_order"),
        }
        if isinstance(row.get("f_address_self_owned"), dict):
            result["self_owned"].append(
                {**base, "address": _public_address(row["f_address_self_owned"])}
            )
        if isinstance(row.get("f_address_rented"), dict):
            result["rented"].append(
                {**base, "address": _public_address(row["f_address_rented"])}
            )
    return result


def _public_checklist(row: dict[str, Any]) -> dict[str, Any]:
    template = row.get("f_document_checklist")
    template = template if isinstance(template, dict) else {}
    latest = _public_attachments(row.get("f_lastest_files") or [])
    return {
        "position_code": _checklist_position_code(template),
        "attachment_id": latest[0]["data_id"] if latest else None,
    }


def _public_activity(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row.get("id"),
        "activity": row.get("f_activity"),
        "status": row.get("f_activity_status"),
        "date": row.get("f_date"),
        "remarks": row.get("f_remarks"),
        "received_by_user_id": row.get("fk_received_by"),
        "attachments": _public_attachments(row.get("f_attachments") or []),
    }


def _public_letter_attachments(values: Any) -> list[dict[str, Any]]:
    sent_items: list[tuple[datetime, int, dict[str, Any]]] = []
    for row in values if isinstance(values, list) else []:
        if not isinstance(row, dict) or row.get("id") is None:
            continue
        sent_at = _parse_nocobase_datetime(row.get("f_sendtime"))
        if sent_at is None:
            continue
        item = _public_letter_attachment(row)
        if item["attachment_ids"]:
            try:
                record_order = int(row["id"])
            except (TypeError, ValueError):
                record_order = -1
            sent_items.append((sent_at, record_order, item))

    sent_items.sort(key=lambda value: (value[0], value[1]), reverse=True)
    result = [value[2] for value in sent_items]
    latest_categories: set[str] = set()
    for item in result:
        category = item.get("letter_category")
        category_value = category.get("value") if isinstance(category, dict) else None
        category_key = (
            str(category_value)
            if category_value is not None
            else f"__record__:{item['letter_attachment_id']}"
        )
        item["is_latest"] = category_key not in latest_categories
        latest_categories.add(category_key)
    return result


def _public_letter_attachment(row: dict[str, Any]) -> dict[str, Any]:
    attachments = _public_attachments(row.get("f_attachment") or [])
    return {
        "letter_attachment_id": row.get("id"),
        "letter_category": _enum(
            row.get("f_letter_type"), NEW_LICENCE_LETTER_CATEGORY_OPTIONS
        ),
        "send_time": row.get("f_sendtime"),
        "sent_by_user_id": row.get("fk_senduser"),
        "attachment_ids": [item["data_id"] for item in attachments],
        "attachments": attachments,
    }


def _parse_nocobase_datetime(value: Any) -> Optional[datetime]:
    if not isinstance(value, str) or not value.strip():
        return None
    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _notice_event_sort_key(row: dict[str, Any]) -> tuple[Any, ...]:
    """Order notices by the business event, including historical backfills.

    An older status may be inserted after a newer one.  Keep ``createdAt``
    as the fallback and the native ID as a deterministic tie-breaker; the
    public ``created_time`` field still describes when the row was inserted.
    """
    event_at = _parse_nocobase_datetime(
        row.get("f_status_updated_at")
    ) or _parse_nocobase_datetime(row.get("createdAt"))
    raw_id = row.get("id")
    try:
        id_key = (0, int(raw_id))
    except (TypeError, ValueError):
        id_key = (1, str(raw_id or ""))
    return (
        event_at is None,
        event_at or datetime.max.replace(tzinfo=timezone.utc),
        id_key,
    )


def _public_attachments(values: Any) -> list[dict[str, Any]]:
    result = []
    for row in values if isinstance(values, list) else []:
        if not isinstance(row, dict) or row.get("id") is None:
            continue
        result.append(
            {
                "data_id": row.get("id"),
                "filename": row.get("filename"),
                "size": row.get("size"),
                "download_url": f"/v1/files/{row['id']}",
            }
        )
    return result


def _checklist_position_code(row: dict[str, Any]) -> Optional[str]:
    position_code = str(row.get("f_position_code") or "").strip()
    return position_code or None


def _checklist_section_path(
    row: dict[str, Any], by_id: dict[str, dict[str, Any]]
) -> list[dict[str, Optional[str]]]:
    path = []
    parent_id = row.get("parentId")
    seen = set()
    while parent_id is not None and str(parent_id) not in seen:
        seen.add(str(parent_id))
        parent = by_id.get(str(parent_id))
        if not parent:
            break
        path.append(
            {
                "name_en": parent.get("f_name_en") or None,
                "name_cn": parent.get("f_name_cn") or None,
            }
        )
        parent_id = parent.get("parentId")
    path.reverse()
    return path
