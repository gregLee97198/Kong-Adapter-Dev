from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .errors import ConfigurationError
from .nocobase_config import NocoBaseProfile, default_profile_path


def _read_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ConfigurationError(f"{name} must be true or false")


def _read_int(name: str, default: int, *, minimum: int = 0) -> int:
    raw = os.getenv(name)
    try:
        value = default if raw is None else int(raw)
    except ValueError as exc:
        raise ConfigurationError(f"{name} must be an integer") from exc
    if value < minimum:
        raise ConfigurationError(f"{name} must be >= {minimum}")
    return value


def _read_float(name: str, default: float, *, minimum: float = 0.01) -> float:
    raw = os.getenv(name)
    try:
        value = default if raw is None else float(raw)
    except ValueError as exc:
        raise ConfigurationError(f"{name} must be a number") from exc
    if value < minimum:
        raise ConfigurationError(f"{name} must be >= {minimum}")
    return value


def _read_optional_secret(
    direct_name: str,
    file_name: str,
) -> Optional[str]:
    secret_file = os.getenv(file_name, "").strip()
    direct_value = os.getenv(direct_name, "").strip()
    if secret_file and direct_value:
        raise ConfigurationError(
            f"Set only one of {file_name} or {direct_name}"
        )
    if secret_file:
        path = Path(secret_file)
        if not path.is_file():
            raise ConfigurationError(f"{file_name} does not exist: {path}")
        value = path.read_text(encoding="utf-8").strip()
        if not value:
            raise ConfigurationError(f"{file_name} is empty")
        return value
    return direct_value or None


@dataclass(frozen=True)
class Settings:
    nocobase: NocoBaseProfile
    nocobase_config_token: Optional[str] = field(repr=False)
    verify_tls: bool
    storage_cache_seconds: int
    max_file_bytes: int
    allowed_mime_types: frozenset[str]
    connect_timeout_seconds: float
    request_timeout_seconds: float
    upload_timeout_seconds: float
    max_connections: int
    log_level: str
    source_system: str = "OP"

    @classmethod
    def from_env(cls) -> Settings:
        mime_types = frozenset(
            item.strip().lower()
            for item in os.getenv(
                "ALLOWED_MIME_TYPES",
                "application/pdf,image/jpeg,image/png",
            ).split(",")
            if item.strip()
        )
        nocobase = NocoBaseProfile.load(default_profile_path())
        injected_config_token = _read_optional_secret(
            "NOCOBASE_CONFIG_TOKEN",
            "NOCOBASE_CONFIG_TOKEN_FILE",
        )
        settings = cls(
            nocobase=nocobase,
            nocobase_config_token=(
                injected_config_token
                if injected_config_token is not None
                else nocobase.config_token
            ),
            verify_tls=_read_bool("NOCOBASE_VERIFY_TLS", True),
            storage_cache_seconds=_read_int(
                "STORAGE_CACHE_SECONDS", 0, minimum=0
            ),
            max_file_bytes=_read_int(
                "MAX_FILE_BYTES", 20 * 1024 * 1024, minimum=1
            ),
            allowed_mime_types=mime_types,
            connect_timeout_seconds=_read_float(
                "CONNECT_TIMEOUT_SECONDS", 5.0
            ),
            request_timeout_seconds=_read_float(
                "REQUEST_TIMEOUT_SECONDS", 30.0
            ),
            upload_timeout_seconds=_read_float(
                "UPLOAD_TIMEOUT_SECONDS", 300.0
            ),
            max_connections=_read_int("MAX_CONNECTIONS", 50, minimum=1),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
            source_system=os.getenv("SOURCE_SYSTEM", "OP").strip().upper(),
        )
        settings.validate()
        return settings

    def validate(self) -> None:
        self.nocobase.validate()
        if not self.allowed_mime_types:
            raise ConfigurationError("ALLOWED_MIME_TYPES cannot be empty")
        if not re.fullmatch(r"[A-Z][A-Z0-9_-]{1,31}", self.source_system):
            raise ConfigurationError(
                "SOURCE_SYSTEM must contain 2-32 uppercase letters, numbers, "
                "underscores or hyphens"
            )

    @property
    def nocobase_base_url(self) -> str:
        return self.nocobase.base_url

    @property
    def storage_name(self) -> Optional[str]:
        return self.nocobase.storage_name
