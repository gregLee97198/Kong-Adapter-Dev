from __future__ import annotations

import asyncio
import time
from typing import Optional

from .models import StorageInfo
from .nocobase_client import NocoBaseClient
from .settings import Settings


class StorageCache:
    def __init__(self, client: NocoBaseClient, settings: Settings) -> None:
        self._client = client
        self._ttl = settings.storage_cache_seconds
        self._value: Optional[StorageInfo] = None
        self._expires_at = 0.0
        self._lock = asyncio.Lock()

    async def get(self, request_id: str, *, force: bool = False) -> StorageInfo:
        now = time.monotonic()
        if not force and self._value is not None and now < self._expires_at:
            return self._value
        async with self._lock:
            now = time.monotonic()
            if not force and self._value is not None and now < self._expires_at:
                return self._value
            value = await self._client.get_storage(request_id)
            self._value = value
            self._expires_at = now + self._ttl
            return value
