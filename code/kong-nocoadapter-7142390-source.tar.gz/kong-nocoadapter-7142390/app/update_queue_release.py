"""Read a reviewed, environment-bound UPDATE queue activation from YAML.

The activation block lives beside the NocoBase profile already mounted by
Docker Compose.  A separate deployment setting pins the SHA-256 of the whole
file, so editing either the upstream or the review evidence requires an
explicit deployment change.  This is an operational review gate, not a
cryptographic signature or a substitute for live workflow verification.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any

import yaml

from .update_queue_service import (
    PUBLIC_UPDATE_QUEUE_TYPES,
    QueueActivationGates,
)

_SHA256 = re.compile(r"^[a-fA-F0-9]{64}$")
_WORKFLOW_KEY = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_BOUNDARY_GATES = frozenset({
    "native_intake_boundary_verified",
    "native_intake_boundary_race_accepted",
})
_REQUIRED_EVIDENCE = frozenset(
    item.name for item in fields(QueueActivationGates)
) - _BOUNDARY_GATES

# These bindings are part of the public route contract, not supplied by a
# client or inferred from a manifest.  Reject a manifest that describes a
# different route for any enabled family.
QUEUE_FAMILY_API_TYPES: dict[str, tuple[str, str]] = {
    "new_licence": (
        "create_intake_for_new_licence", "update_new_licence_data"
    ),
    "changing_home": (
        "create_intake_for_changing_home", "update_changing_home_data"
    ),
    "licence_renewal": (
        "create_licence_renewal", "update_licence_renewal_data"
    ),
    "expansion_aip": (
        "create_intake_for_expansion_aip", "update_expansion_aip_data"
    ),
    "self_withdraw": (
        "create_intake_for_self_withdraw", "update_self_withdraw_data"
    ),
    "specific_hour": (
        "create_intake_for_specific_hour", "update_specific_hour_data"
    ),
    "responsible_person": (
        "create_intake_for_rp", "update_rp_data"
    ),
    "change_home_manager": (
        "create_intake_for_change_home_manager",
        "update_change_home_manager_data",
    ),
    "change_beds": (
        "create_intake_for_change_beds", "update_change_beds_data"
    ),
    "change_operation_mode": (
        "create_intake_for_change_operation_mode",
        "update_change_operation_mode_data",
    ),
    "change_nurse_in_charge": (
        "create_intake_for_change_nurse_in_charge",
        "update_change_nurse_in_charge_data",
    ),
    "change_directors": (
        "create_intake_for_change_directors",
        "update_change_directors_data",
    ),
}
assert frozenset(QUEUE_FAMILY_API_TYPES) == PUBLIC_UPDATE_QUEUE_TYPES


@dataclass(frozen=True)
class ReviewedQueueRelease:
    families: frozenset[str]
    admission_workflow_key: str
    rejection_workflow_key: str
    gates: QueueActivationGates
    review_id: str


def _require_exact_keys(value: Any, expected: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != expected:
        raise RuntimeError(f"UPDATE queue release {label} has invalid keys")
    return value


def _review_ref(value: Any) -> bool:
    return isinstance(value, str) and 8 <= len(value.strip()) <= 512


def load_reviewed_queue_release(
    *,
    profile_path: Path,
    expected_sha256: str,
    deployment_env: str,
    nocobase_base_url: str,
    source_system: str,
    https_bind: str,
    https_port: str,
    enabled_families: frozenset[str],
) -> ReviewedQueueRelease:
    """Validate review evidence and bind it to this exact running profile.

    Nothing is enabled by merely adding YAML.  The caller also requires the
    independent runtime enable bit, reviewed mode, family allowlist and digest.
    Error messages intentionally omit YAML contents and any profile secrets.
    """

    if deployment_env not in {"local_test", "online_test"}:
        raise RuntimeError("UPDATE queue reviewed mode is not for this environment")
    if source_system != "OP":
        raise RuntimeError("UPDATE queue reviewed mode requires OP source")
    if not enabled_families:
        raise RuntimeError("UPDATE queue reviewed mode requires a family allowlist")
    if not _SHA256.fullmatch(expected_sha256):
        raise RuntimeError("UPDATE queue profile SHA-256 is missing or invalid")
    try:
        profile_bytes = profile_path.read_bytes()
    except OSError as exc:
        raise RuntimeError("UPDATE queue profile is unavailable") from exc
    if not profile_bytes or len(profile_bytes) > 262_144:
        raise RuntimeError("UPDATE queue profile size is invalid")
    if hashlib.sha256(profile_bytes).hexdigest() != expected_sha256.lower():
        raise RuntimeError("UPDATE queue profile SHA-256 does not match")
    try:
        document = yaml.safe_load(profile_bytes)
    except yaml.YAMLError as exc:
        raise RuntimeError("UPDATE queue release YAML is invalid") from exc
    if not isinstance(document, dict):
        raise RuntimeError("UPDATE queue release YAML root is invalid")
    release = _require_exact_keys(
        document.get("update_queue_release"),
        {
            "schema_version",
            "review_id",
            "deployment_env",
            "nocobase_base_url",
            "source_system",
            "https_bind",
            "https_port",
            "admission_workflow_key",
            "rejection_workflow_key",
            "families",
        },
        "manifest",
    )
    if type(release["schema_version"]) is not int or release["schema_version"] != 1:
        raise RuntimeError("UPDATE queue release schema version is unsupported")
    if not _review_ref(release["review_id"]):
        raise RuntimeError("UPDATE queue release review ID is invalid")
    runtime_binding = {
        "deployment_env": deployment_env,
        "nocobase_base_url": nocobase_base_url,
        "source_system": source_system,
        "https_bind": https_bind,
        "https_port": https_port,
    }
    if any(release[key] != value for key, value in runtime_binding.items()):
        raise RuntimeError("UPDATE queue release runtime binding does not match")
    admission_key = release["admission_workflow_key"]
    rejection_key = release["rejection_workflow_key"]
    if not all(
        isinstance(key, str) and _WORKFLOW_KEY.fullmatch(key)
        for key in (admission_key, rejection_key)
    ):
        raise RuntimeError("UPDATE queue release workflow key is invalid")
    families = release["families"]
    if (
        not isinstance(families, dict)
        or set(families) != enabled_families
        or set(families) - PUBLIC_UPDATE_QUEUE_TYPES
    ):
        raise RuntimeError("UPDATE queue release family allowlist does not match")

    for name, raw_family in families.items():
        family = _require_exact_keys(
            raw_family,
            {"create_api_type", "update_api_type", "evidence"},
            "family",
        )
        if (
            family["create_api_type"],
            family["update_api_type"],
        ) != QUEUE_FAMILY_API_TYPES[name]:
            raise RuntimeError("UPDATE queue release route binding does not match")
        evidence = family["evidence"]
        if not isinstance(evidence, dict) or (
            set(evidence) - (_REQUIRED_EVIDENCE | _BOUNDARY_GATES)
        ) or not _REQUIRED_EVIDENCE <= set(evidence):
            raise RuntimeError("UPDATE queue release gate evidence is incomplete")
        if not _BOUNDARY_GATES & set(evidence):
            raise RuntimeError("UPDATE queue release Intake boundary is unreviewed")
        if any(not _review_ref(ref) for ref in evidence.values()):
            raise RuntimeError("UPDATE queue release gate reference is invalid")

    # All enabled families passed the same complete gate set.  The service is
    # given ready gates, but every family's evidence is checked separately.
    boundary_verified = all(
        "native_intake_boundary_verified" in family["evidence"]
        for family in families.values()
    )
    gates = QueueActivationGates(
        **{
            item.name: (
                boundary_verified
                if item.name == "native_intake_boundary_verified"
                else not boundary_verified
                if item.name == "native_intake_boundary_race_accepted"
                else True
            )
            for item in fields(QueueActivationGates)
        }
    )
    # In a mixed release, the accepted-race waiver is the common bound.
    # Every family supplied either a verified interlock or that waiver.
    gates.require_ready()
    return ReviewedQueueRelease(
        families=frozenset(families),
        admission_workflow_key=admission_key,
        rejection_workflow_key=rejection_key,
        gates=gates,
        review_id=release["review_id"].strip(),
    )
