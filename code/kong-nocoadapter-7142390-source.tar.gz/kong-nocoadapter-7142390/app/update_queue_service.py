"""Fail-closed UPDATE admission using this request's customer token.

Public routes may opt in only through explicit activation gates. The default
path remains inert until the 13001 unique indexes, synchronous Custom Actions,
native Staging workflow wake/worker revisions, and post-Received cancellation
and reconciliation have passed the release gates. A successful Custom Action
HTTP response is never treated as an admission. No customer token is persisted
asynchronously.
"""

from __future__ import annotations

import json
import re
import uuid
from collections.abc import Mapping
from dataclasses import dataclass, fields
from typing import Any, Literal

from .errors import AdapterError
from .nocobase_client import NocoBaseClient

ADMISSION_PENDING = "admission_pending"
_ACCEPTED_ACTIVE = frozenset({"queued", "submitted", "processing", "needs_review"})
_TERMINAL = frozenset({"succeeded", "failed"})
_CONTEXT_FIELDS = frozenset({"f_office_code", "f_rch_id", "f_user_role"})
_WORKFLOW_KEY = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

# v0.8.1 Create/Update pairs only.  Historical Prosecution/Revoke routes are
# deliberately outside this release's queue activation scope.
PUBLIC_UPDATE_QUEUE_TYPES = frozenset({
    "new_licence",
    "changing_home",
    "licence_renewal",
    "expansion_aip",
    "self_withdraw",
    "specific_hour",
    "responsible_person",
    "change_home_manager",
    "change_beds",
    "change_operation_mode",
    "change_nurse_in_charge",
    "change_directors",
})


def parse_enabled_queue_families(raw: str | None) -> frozenset[str]:
    """Parse an exact activation allowlist; never accept a wildcard or typo."""

    if raw is None or not raw.strip():
        return frozenset()
    values = [value.strip() for value in raw.split(",")]
    if (
        any(not value for value in values)
        or len(set(values)) != len(values)
        or set(values) - PUBLIC_UPDATE_QUEUE_TYPES
    ):
        raise ValueError("UPDATE queue family allowlist is invalid")
    return frozenset(values)

AdmissionDecision = Literal[
    "accepted",
    "retry_admission",
    "wake_required",
    "reject_unadmitted",
    "update_locked",
    "idempotency_conflict",
    "isolate",
]


@dataclass(frozen=True)
class QueueActivationGates:
    """Explicit external evidence; no field is inferred from schema alone."""

    schema_verified: bool = False
    unique_indexes_verified: bool = False
    admission_action_verified: bool = False
    rejection_action_verified: bool = False
    native_worker_revisions_verified: bool = False
    native_wake_path_verified: bool = False
    audit_actor_backfill_verified: bool = False
    post_received_cancel_verified: bool = False
    native_reconciliation_verified: bool = False
    monotonic_fence_verified: bool = False
    # A native Intake interlock is the only way to *guarantee* that every
    # admitted UPDATE is applied before Intake completes. The owner has ruled
    # out changing that workflow and explicitly accepted this narrow race for
    # the development queue. Keep the waiver separate from verified evidence.
    native_intake_boundary_verified: bool = False
    native_intake_boundary_race_accepted: bool = False
    admission_sequence_verified: bool = False
    client_network_boundary_verified: bool = False

    def require_ready(self) -> None:
        boundary_gate_names = {
            "native_intake_boundary_verified",
            "native_intake_boundary_race_accepted",
        }
        other_gates_ready = all(
            getattr(self, item.name)
            for item in fields(self)
            if item.name not in boundary_gate_names
        )
        boundary_accepted = (
            self.native_intake_boundary_verified
            or self.native_intake_boundary_race_accepted
        )
        if not other_gates_ready or not boundary_accepted:
            raise AdapterError(
                503,
                "update_queue_not_ready",
                "The Update queue is not available",
            )


@dataclass(frozen=True)
class QueueFamily:
    """Trusted server-side binding, never constructed from request body fields."""

    source_system: str
    application_type: str
    create_api_type: str
    update_api_type: str


# These bindings are only for the explicitly confirmed 13001 local pilots.
# Reviewed releases use their independently verified manifest instead.
_OTHER_LOCAL_PILOT_FAMILIES = frozenset({
    QueueFamily("OP", "changing_home", "create_intake_for_changing_home",
                "update_changing_home_data"),
    QueueFamily("OP", "self_withdraw", "create_intake_for_self_withdraw",
                "update_self_withdraw_data"),
    QueueFamily("OP", "expansion_aip", "create_intake_for_expansion_aip",
                "update_expansion_aip_data"),
    QueueFamily("OP", "specific_hour", "create_intake_for_specific_hour",
                "update_specific_hour_data"),
    QueueFamily("OP", "responsible_person", "create_intake_for_rp",
                "update_rp_data"),
    QueueFamily("OP", "change_home_manager",
                "create_intake_for_change_home_manager",
                "update_change_home_manager_data"),
    QueueFamily("OP", "change_nurse_in_charge",
                "create_intake_for_change_nurse_in_charge",
                "update_change_nurse_in_charge_data"),
    QueueFamily("OP", "change_beds", "create_intake_for_change_beds",
                "update_change_beds_data"),
    QueueFamily("OP", "change_operation_mode",
                "create_intake_for_change_operation_mode",
                "update_change_operation_mode_data"),
    QueueFamily("OP", "change_directors",
                "create_intake_for_change_directors",
                "update_change_directors_data"),
})


@dataclass(frozen=True)
class QueueAdmissionResult:
    create_id: str
    update_id: int
    status: Literal["accepted"] = "accepted"
    replayed: bool = False


def _same_body(left: Mapping[str, Any], right: Mapping[str, Any]) -> bool:
    return json.dumps(left, sort_keys=True, separators=(",", ":")) == json.dumps(
        right, sort_keys=True, separators=(",", ":")
    )


def _next_sequence(value: object) -> int:
    # Existing CREATE rows predate this nullable column.  PostgreSQL
    # Admission treats NULL as zero; exact row readback must do the same.
    if value is None:
        return 0
    if (
        not isinstance(value, int)
        or isinstance(value, bool)
        or value < 0
        or value > 2147483647
    ):
        raise ValueError("Invalid parent queue sequence")
    return value


def classify_admission_readback(
    *,
    row: Mapping[str, Any],
    parent_application_status: str,
    parent_next_sequence: int | None,
    family: QueueFamily,
    create_id: str,
    client_request_id: str,
    request_body: Mapping[str, Any],
    reservation_id: str | None,
) -> AdmissionDecision:
    """Inspect persisted state after an ambiguous create/Custom Action result."""

    expected = {
        "f_request_event": "UPDATE",
        "f_source_system": family.source_system,
        "f_api_type": family.update_api_type,
        "f_application_type": family.application_type,
        "f_parent_create_id": create_id,
        "f_client_request_id": client_request_id,
    }
    if any(str(row.get(field)) != str(value) for field, value in expected.items()):
        return "isolate"
    if not isinstance(row.get("f_active_update_id"), str) or not row.get(
        "f_active_update_id"
    ):
        return "isolate"
    if reservation_id is not None and row.get("f_active_update_id") != reservation_id:
        return "isolate"
    stored_body = row.get("f_request_body")
    if not isinstance(stored_body, dict):
        return "isolate"
    if not _same_body(stored_body, request_body):
        return "idempotency_conflict"

    row_id = row.get("id")
    if not isinstance(row_id, int) or isinstance(row_id, bool) or row_id < 1:
        return "isolate"
    try:
        next_sequence = _next_sequence(parent_next_sequence)
    except ValueError:
        return "isolate"

    sequence = row.get("f_queue_sequence")
    if sequence is not None and (
        not isinstance(sequence, int)
        or isinstance(sequence, bool)
        or sequence < 1
    ):
        return "isolate"

    status = row.get("f_status")
    counted = row.get("f_queue_counted") is True
    attempts = row.get("f_attempt_count")
    phase = row.get("f_queue_phase")
    if status in _ACCEPTED_ACTIVE:
        return (
            "accepted"
            if counted and sequence is not None and next_sequence >= sequence
            else "isolate"
        )
    if status in _TERMINAL:
        # Admission was confirmed before the native business boundary moved.
        # The customer may already have received Accepted. Replays of that
        # exact request therefore preserve the admission result even though
        # the child was safely cancelled before any business write.
        if (
            status == "failed"
            and row.get("f_error_message") == "update_locked_after_admission"
            and not counted
            and sequence is not None
            and next_sequence >= sequence
        ):
            return "accepted"
        if sequence is not None and next_sequence >= sequence and (counted or (
            isinstance(attempts, int)
            and not isinstance(attempts, bool)
            and attempts > 0
            and phase in {"preflight", "applying", "finished"}
        )):
            return "accepted"
        if (
            status == "failed"
            and row.get("f_error_message") == "update_locked"
            and not counted
        ):
            return "update_locked"
        return "isolate"
    if status == ADMISSION_PENDING and not counted:
        if sequence is not None:
            return "isolate"
        if parent_application_status != "Accepted":
            return "reject_unadmitted"
        return "retry_admission"
    if status == ADMISSION_PENDING and counted:
        if sequence is None or next_sequence < sequence:
            return "isolate"
        # The native status may cross Received after synchronous Admission.
        # Preserve the already-issued admission result without waking an
        # UPDATE that must be cancelled by the bounded reconciler.
        return (
            "wake_required" if parent_application_status == "Accepted" else "accepted"
        )
    return "isolate"


class QueueAdmissionService:
    def __init__(
        self,
        client: NocoBaseClient,
        *,
        gates: QueueActivationGates | None = None,
        admission_workflow_key: str | None = None,
        rejection_workflow_key: str | None = None,
        pilot_nla_test_mode: bool = False,
        pilot_lrn_test_mode: bool = False,
        pilot_other_family: QueueFamily | None = None,
        max_admission_attempts: int = 2,
        max_wake_attempts: int = 2,
    ) -> None:
        if max_admission_attempts < 1 or max_wake_attempts < 1:
            raise ValueError("Queue retry limits must be positive")
        self._client = client
        self._gates = gates or QueueActivationGates()
        self._admission_workflow_key = admission_workflow_key
        self._rejection_workflow_key = rejection_workflow_key
        if sum((pilot_nla_test_mode, pilot_lrn_test_mode,
                pilot_other_family is not None)) > 1:
            raise ValueError("Only one local UPDATE queue pilot may be selected")
        if (pilot_other_family is not None
                and pilot_other_family not in _OTHER_LOCAL_PILOT_FAMILIES):
            raise ValueError("Unknown local UPDATE queue pilot family")
        self._pilot_nla_test_mode = pilot_nla_test_mode
        self._pilot_lrn_test_mode = pilot_lrn_test_mode
        self._pilot_other_family = pilot_other_family
        self._max_admission_attempts = max_admission_attempts
        self._max_wake_attempts = max_wake_attempts

    async def admit_update(
        self,
        *,
        authorization_token: str,
        transport_request_id: str,
        client_request_id: str,
        create_id: int | str,
        request_body: Mapping[str, Any],
        family: QueueFamily,
        context: Mapping[str, str | None] | None = None,
    ) -> QueueAdmissionResult:
        """Persist and admit one UPDATE; never acknowledge unconfirmed work.

        All synchronous NocoBase I/O uses ``authorization_token``.  A timeout
        or a 200 empty Custom Action response is resolved by the exact child
        row and unique client request key, never by inserting another row
        blindly.  Native asynchronous workflows later run in NocoBase's
        system context and explicitly backfill the immutable Staging actor.
        """

        if (self._pilot_nla_test_mode or self._pilot_lrn_test_mode
                or self._pilot_other_family is not None):
            # This deliberately narrow local test bypasses release evidence,
            # not identity, idempotency or SQL admission checks. It must never
            # be used as a production readiness assertion.
            if self._pilot_nla_test_mode:
                expected = QueueFamily(
                    "OP", "new_licence", "create_intake_for_new_licence",
                    "update_new_licence_data",
                )
                pilot_name = "NLA"
            elif self._pilot_lrn_test_mode:
                expected = QueueFamily(
                    "OP", "licence_renewal", "create_licence_renewal",
                    "update_licence_renewal_data",
                )
                pilot_name = "LRN"
            else:
                assert self._pilot_other_family is not None
                expected = self._pilot_other_family
                pilot_name = "Local"
            if family != expected:
                raise AdapterError(
                    503,
                    "update_queue_not_ready",
                    f"{pilot_name} pilot binding is invalid",
                )
        else:
            self._gates.require_ready()
        if not authorization_token or not transport_request_id:
            raise AdapterError(401, "invalid_client_token", "Client token is required")
        if not isinstance(client_request_id, str) or not client_request_id:
            raise AdapterError(422, "invalid_request_id", "request_id is required")
        if request_body.get("request_id") != client_request_id:
            raise AdapterError(
                422,
                "invalid_request_id",
                "Body request_id does not match the Update request",
            )
        if not isinstance(create_id, (int, str)) or not str(create_id).isdigit():
            raise AdapterError(422, "invalid_create_id", "create_id is invalid")
        normalized_create_id = str(create_id)
        if not all(getattr(family, item.name) for item in fields(family)):
            raise ValueError("Queue family binding must be complete")
        if not all(
            isinstance(key, str) and _WORKFLOW_KEY.fullmatch(key)
            for key in (self._admission_workflow_key, self._rejection_workflow_key)
        ):
            raise AdapterError(
                503, "update_queue_not_ready", "Queue action mapping is unavailable"
            )
        if context and (set(context) - _CONTEXT_FIELDS):
            raise ValueError("Queue context includes unapproved Staging fields")
        try:
            body = json.loads(json.dumps(dict(request_body)))
        except (TypeError, ValueError) as exc:
            raise AdapterError(
                422, "invalid_request_body", "Body must be JSON"
            ) from exc

        parent = await self._parent(
            authorization_token, transport_request_id, normalized_create_id, family
        )
        row = await self._existing(
            authorization_token,
            transport_request_id,
            normalized_create_id,
            client_request_id,
            family,
        )
        replayed = row is not None
        reservation_id: str | None = None
        if row is None:
            # A post-Received request still has to be visible in Staging for
            # audit, but must never be admitted or wake a business workflow.
            # Creating it in the inert admission_pending state lets the
            # guarded rejection action close the exact child.  The parent's
            # application status and the admission SQL share one row lock, so
            # a concurrent Received transition cannot admit this child late.
            reservation_id = str(uuid.uuid4())
            values: dict[str, Any] = {
                "f_request_body": body,
                "f_source_system": family.source_system,
                "f_request_event": "UPDATE",
                "f_api_type": family.update_api_type,
                "f_status": ADMISSION_PENDING,
                "f_application_type": family.application_type,
                "f_parent_create_id": normalized_create_id,
                "f_active_update_id": reservation_id,
                "f_client_request_id": client_request_id,
                "f_queue_counted": False,
                "f_queue_sequence": None,
                "f_queue_phase": None,
                "f_attempt_count": 0,
                "f_application_status": None,
                **(context or {}),
            }
            try:
                created = await self._client.create_request_staging(
                    request_id=transport_request_id,
                    authorization_token=authorization_token,
                    values=values,
                )
            except AdapterError as exc:
                if exc.status_code not in {409, 502, 504}:
                    raise
                row = await self._existing(
                    authorization_token,
                    transport_request_id,
                    normalized_create_id,
                    client_request_id,
                    family,
                )
                if row is None:
                    raise self._unconfirmed() from exc
                replayed = True
                # A conflicting concurrent caller generated a different UUID;
                # the unique request key and body, not our proposed UUID,
                # decide whether the existing row is a valid replay.
                reservation_id = None
            else:
                created_id = created.get("id")
                if not isinstance(created_id, int) or isinstance(created_id, bool):
                    raise self._unconfirmed()
                row = await self._client.get_record(
                    collection="t_api_request_staging",
                    record_id=created_id,
                    request_id=transport_request_id,
                    authorization_token=authorization_token,
                )
                if row.get("id") != created_id:
                    raise self._integrity_error()
        assert row is not None
        return await self._resolve(
            row=row,
            parent=parent,
            body=body,
            family=family,
            create_id=normalized_create_id,
            client_request_id=client_request_id,
            reservation_id=reservation_id,
            replayed=replayed,
            authorization_token=authorization_token,
            transport_request_id=transport_request_id,
        )

    async def _parent(
        self,
        token: str,
        transport_request_id: str,
        create_id: str,
        family: QueueFamily,
    ) -> dict[str, Any]:
        row = await self._client.get_record(
            collection="t_api_request_staging",
            record_id=create_id,
            request_id=transport_request_id,
            authorization_token=token,
        )
        if (
            str(row.get("id")) != create_id
            or row.get("f_request_event") != "CREATE"
            or row.get("f_source_system") != family.source_system
            or row.get("f_api_type") != family.create_api_type
            or row.get("f_application_type") != family.application_type
        ):
            raise AdapterError(
                422, "invalid_create_id", "create_id is not this application"
            )
        if "f_queue_next_sequence" not in row:
            raise self._integrity_error()
        return row

    async def _existing(
        self,
        token: str,
        transport_request_id: str,
        create_id: str,
        client_request_id: str,
        family: QueueFamily,
    ) -> dict[str, Any] | None:
        result = await self._client.list_records(
            collection="t_api_request_staging",
            request_id=transport_request_id,
            authorization_token=token,
            filters={
                "$and": [
                    {"f_request_event": {"$eq": "UPDATE"}},
                    {"f_source_system": {"$eq": family.source_system}},
                    {"f_api_type": {"$eq": family.update_api_type}},
                    {"f_parent_create_id": {"$eq": create_id}},
                    {"f_client_request_id": {"$eq": client_request_id}},
                ]
            },
            page=1,
            page_size=2,
            sort=("id",),
        )
        rows = result.get("data")
        if not isinstance(rows, list) or len(rows) > 1:
            raise self._integrity_error()
        if not rows:
            return None
        if not isinstance(rows[0], dict) or not isinstance(rows[0].get("id"), int):
            raise self._integrity_error()
        return rows[0]

    async def _resolve(
        self,
        *,
        row: dict[str, Any],
        parent: dict[str, Any],
        body: dict[str, Any],
        family: QueueFamily,
        create_id: str,
        client_request_id: str,
        reservation_id: str | None,
        replayed: bool,
        authorization_token: str,
        transport_request_id: str,
    ) -> QueueAdmissionResult:
        admission_attempts = 0
        wake_attempts = 0
        rejection_attempted = False
        while True:
            decision = classify_admission_readback(
                row=row,
                parent_application_status=str(parent.get("f_application_status") or ""),
                parent_next_sequence=parent.get("f_queue_next_sequence"),
                family=family,
                create_id=create_id,
                client_request_id=client_request_id,
                request_body=body,
                reservation_id=reservation_id,
            )
            if decision == "accepted":
                row_id = row.get("id")
                if not isinstance(row_id, int) or isinstance(row_id, bool):
                    raise self._integrity_error()
                return QueueAdmissionResult(create_id, row_id, replayed=replayed)
            if decision == "idempotency_conflict":
                raise AdapterError(
                    409,
                    "idempotency_conflict",
                    "request_id was already used with a different body",
                )
            if decision == "update_locked":
                raise self._locked(parent.get("f_application_status"))
            if decision == "isolate":
                raise self._integrity_error()
            if decision == "wake_required":
                if wake_attempts >= self._max_wake_attempts:
                    raise self._unconfirmed()
                wake_attempts += 1
                try:
                    # Admission SQL only counts the child.  This *ORM* field
                    # transition is what wakes the native Collection Event;
                    # SQL writes alone do not trigger collection workflows.
                    await self._client.update_record_if(
                        collection="t_api_request_staging",
                        record_id=row["id"],
                        expected={
                            "f_status": ADMISSION_PENDING,
                            "f_queue_counted": True,
                            "f_active_update_id": row["f_active_update_id"],
                        },
                        values={"f_status": "queued"},
                        request_id=transport_request_id,
                        authorization_token=authorization_token,
                    )
                except AdapterError as exc:
                    if exc.status_code in {401, 403}:
                        raise
                    # An ambiguous result may have committed; exact readback
                    # below decides, never the HTTP status or response body.
                row = await self._client.get_record(
                    collection="t_api_request_staging",
                    record_id=row["id"],
                    request_id=transport_request_id,
                    authorization_token=authorization_token,
                )
                parent = await self._parent(
                    authorization_token, transport_request_id, create_id, family
                )
                continue
            if decision == "reject_unadmitted":
                if rejection_attempted:
                    raise self._unconfirmed()
                rejection_attempted = True
                workflow_key = self._rejection_workflow_key
            else:
                if admission_attempts >= self._max_admission_attempts:
                    raise self._unconfirmed()
                admission_attempts += 1
                workflow_key = self._admission_workflow_key
            assert workflow_key is not None
            try:
                await self._client.trigger_staging_custom_action(
                    staging_id=row["id"],
                    workflow_key=workflow_key,
                    request_id=transport_request_id,
                    authorization_token=authorization_token,
                )
            except AdapterError as exc:
                if exc.status_code in {401, 403}:
                    raise
                # A timeout or SQL error may have happened after the write.
                # Always read the exact child; never infer outcome from HTTP.
            row = await self._client.get_record(
                collection="t_api_request_staging",
                record_id=row["id"],
                request_id=transport_request_id,
                authorization_token=authorization_token,
            )
            parent = await self._parent(
                authorization_token, transport_request_id, create_id, family
            )

    @staticmethod
    def _locked(application_status: object) -> AdapterError:
        return AdapterError(
            409,
            "update_locked",
            "Update is allowed only while status is Accepted.",
            details={"field": "create_id", "status": application_status},
        )

    @staticmethod
    def _unconfirmed() -> AdapterError:
        return AdapterError(
            503,
            "update_queue_unconfirmed",
            "Update admission could not be confirmed; retry with the same request_id",
        )

    @staticmethod
    def _integrity_error() -> AdapterError:
        return AdapterError(
            503,
            "update_queue_integrity_error",
            "Update queue state could not be verified",
        )
