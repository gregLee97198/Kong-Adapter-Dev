from __future__ import annotations

import hashlib
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import PurePath
from typing import Any, Optional
from urllib.parse import quote

from fastapi import UploadFile

from .errors import AdapterError
from .models import FileUploadResult, StorageInfo
from .nocobase_client import NocoBaseClient
from .settings import Settings
from .storage_cache import StorageCache

logger = logging.getLogger(__name__)
CHUNK_SIZE = 1024 * 1024
S3_PRO_TYPES = {"s3-compatible", "s3-pro"}


@dataclass(frozen=True)
class InspectedUpload:
    filename: str
    mime_type: str
    size: int
    sha256: str


class UploadService:
    def __init__(
        self,
        *,
        settings: Settings,
        client: NocoBaseClient,
        storage_cache: StorageCache,
    ) -> None:
        self._settings = settings
        self._client = client
        self._storage_cache = storage_cache

    async def upload_file(
        self,
        *,
        upload: UploadFile,
        request_id: str,
        external_request_id: Optional[str],
        expected_sha256: Optional[str],
        consumer_id: str,
        authorization_token: str,
    ) -> FileUploadResult:
        inspected = await self._inspect_upload(upload, expected_sha256)
        # Storage discovery deliberately uses the separately configured root
        # token. All business operations below keep the client's native token.
        storage = await self._storage_cache.get(request_id)
        self._enforce_storage_limit(storage, inspected.size)

        storage_type = storage.type.strip().lower()
        etag: Optional[str] = None
        if storage_type in S3_PRO_TYPES:
            attachment, etag = await self._upload_s3_pro(
                upload=upload,
                inspected=inspected,
                storage=storage,
                request_id=request_id,
                authorization_token=authorization_token,
            )
            upload_mode = "client-side-s3-pro"
        else:
            attachment = await self._upload_server_side(
                upload=upload,
                inspected=inspected,
                request_id=request_id,
                authorization_token=authorization_token,
            )
            upload_mode = "server-side"

        download_url = (
            f"/v1/files/{quote(str(attachment['id']), safe='')}"
        )

        logger.info(
            "File uploaded request_id=%s consumer_id=%s attachment_id=%s "
            "storage_type=%s upload_mode=%s size=%s sha256=%s",
            request_id,
            consumer_id,
            attachment["id"],
            storage.type,
            upload_mode,
            inspected.size,
            inspected.sha256,
        )
        return FileUploadResult(
            data_id=attachment["id"],
            filename=inspected.filename,
            size=inspected.size,
            download_url=download_url,
        )

    async def _upload_s3_pro(
        self,
        *,
        upload: UploadFile,
        inspected: InspectedUpload,
        storage: StorageInfo,
        request_id: str,
        authorization_token: str,
    ) -> tuple[dict[str, Any], Optional[str]]:
        presigned = await self._client.create_presigned_url(
            filename=inspected.filename,
            size=inspected.size,
            mime_type=inspected.mime_type,
            storage=storage,
            request_id=request_id,
            authorization_token=authorization_token,
        )
        await upload.seek(0)

        async def content() -> AsyncIterator[bytes]:
            while True:
                chunk = await upload.read(CHUNK_SIZE)
                if not chunk:
                    break
                yield chunk

        etag = await self._client.upload_object(
            put_url=presigned["putUrl"],
            content=content(),
            size=inspected.size,
            mime_type=inspected.mime_type,
            request_id=request_id,
        )
        file_info = dict(presigned["fileInfo"])
        file_info.setdefault("size", inspected.size)
        file_info.setdefault("mimetype", inspected.mime_type)
        try:
            attachment = await self._client.create_attachment(
                file_info=file_info,
                storage_id=storage.id,
                request_id=request_id,
                authorization_token=authorization_token,
                attachment_field_context=(
                    self._settings.nocobase.attachment_field_context
                ),
            )
        except AdapterError:
            logger.error(
                "Object may be orphaned because attachment creation failed "
                "request_id=%s object_key=%s",
                request_id,
                file_info.get("key") or file_info.get("filename"),
            )
            raise
        return attachment, etag

    async def _upload_server_side(
        self,
        *,
        upload: UploadFile,
        inspected: InspectedUpload,
        request_id: str,
        authorization_token: str,
    ) -> dict[str, Any]:
        await upload.seek(0)
        return await self._client.upload_attachment_file(
            filename=inspected.filename,
            mime_type=inspected.mime_type,
            file_object=upload.file,
            request_id=request_id,
            authorization_token=authorization_token,
            attachment_field_context=(
                self._settings.nocobase.attachment_field_context
            ),
        )

    @staticmethod
    def _enforce_storage_limit(storage: StorageInfo, size: int) -> None:
        storage_limit = _storage_size_limit(storage)
        if storage_limit is not None and size > storage_limit:
            raise AdapterError(
                413,
                "file_too_large_for_storage",
                "The file exceeds the storage size limit",
                details={"maxBytes": storage_limit},
            )

    async def _inspect_upload(
        self,
        upload: UploadFile,
        expected_sha256: Optional[str],
    ) -> InspectedUpload:
        raw_name = (upload.filename or "").replace("\\", "/")
        filename = PurePath(raw_name).name
        if not filename or filename in {".", ".."}:
            raise AdapterError(
                400,
                "invalid_filename",
                "A valid filename is required",
            )
        mime_type = (upload.content_type or "application/octet-stream").lower()
        if (
            "*" not in self._settings.allowed_mime_types
            and mime_type not in self._settings.allowed_mime_types
        ):
            raise AdapterError(
                415,
                "unsupported_media_type",
                "The file MIME type is not allowed",
                details={"mimeType": mime_type},
            )
        normalized_expected = (expected_sha256 or "").strip().lower()
        if normalized_expected and (
            len(normalized_expected) != 64
            or any(
                value not in "0123456789abcdef"
                for value in normalized_expected
            )
        ):
            raise AdapterError(
                400,
                "invalid_sha256",
                "sha256 must contain 64 hexadecimal characters",
            )

        digest = hashlib.sha256()
        size = 0
        await upload.seek(0)
        while True:
            chunk = await upload.read(CHUNK_SIZE)
            if not chunk:
                break
            size += len(chunk)
            if size > self._settings.max_file_bytes:
                raise AdapterError(
                    413,
                    "file_too_large",
                    "The file exceeds the configured size limit",
                    details={"maxBytes": self._settings.max_file_bytes},
                )
            digest.update(chunk)
        if size == 0:
            raise AdapterError(400, "empty_file", "The uploaded file is empty")
        actual = digest.hexdigest()
        if normalized_expected and normalized_expected != actual:
            raise AdapterError(
                422,
                "sha256_mismatch",
                "The uploaded file does not match the supplied sha256",
                details={"field": "sha256"},
            )
        await upload.seek(0)
        return InspectedUpload(
            filename=filename,
            mime_type=mime_type,
            size=size,
            sha256=actual,
        )


def _storage_size_limit(storage: StorageInfo) -> Optional[int]:
    raw = storage.rules.get("size")
    if raw is None or isinstance(raw, bool):
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None
