#!/bin/sh
set -eu

runtime_config=/kong/declarative/kong.yml

if [ ! -s "$runtime_config" ]; then
  printf 'portable Kong configuration error: %s is missing or empty\n' \
    "$runtime_config" >&2
  exit 64
fi

export KONG_DATABASE=off
export KONG_DECLARATIVE_CONFIG="$runtime_config"

exec /docker-entrypoint.sh "$@"
