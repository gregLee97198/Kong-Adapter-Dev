#!/bin/sh
set -eu

# Compose mounts the environment-specific DB-less contract here.  Keeping the
# same path authoritative prevents an older image-embedded route template from
# silently hiding newly released routes.  The embedded 211 contract is only a
# safe fallback for image inspection or deployments that omit the mount.
mounted_config=/kong/declarative/kong.yml
embedded_config=/opt/kong-release/kong.yml

if [ -r "$mounted_config" ]; then
  runtime_config=$mounted_config
else
  runtime_config=$embedded_config
fi

if [ ! -s "$runtime_config" ]; then
  printf 'kong release configuration error: %s is missing or empty\n' \
    "$runtime_config" >&2
  exit 64
fi

export KONG_DATABASE=off
export KONG_DECLARATIVE_CONFIG="$runtime_config"

exec /docker-entrypoint.sh "$@"
