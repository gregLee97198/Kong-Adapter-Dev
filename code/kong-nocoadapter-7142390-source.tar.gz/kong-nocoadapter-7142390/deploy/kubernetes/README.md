# 旧 SIT Kubernetes 文件（不用于当前 UAT）

当前 Kong 内网 UAT 交付使用本地 Docker 镜像和
`../../docker-compose.uat.yml`；下载后部署步骤见
`../../docs/Kong-UAT-Offline-Deployment_zh-CN.md`。本目录的 YAML 是旧 SIT
Kubernetes 候选文件，**不进入当前 UAT 离线包，也不要用于 Docker UAT 启动**。

保留的旧 SIT 文件：

- `10-configmap.yaml`：旧 Adapter 配置模板。
- `15-object-storage-ca.yaml`、`sit-object-storage-ca.crt`：旧对象存储受信 CA。
- `20-workload.yaml`：旧 Adapter Deployment/Service 模板。
- `30-networkpolicy.yaml`：旧网络策略模板。
- `kong-sit-current.yml`、`kong-sit-with-adapter.yml`：旧 Kong 路由候选。
- `50-kong-service-fragment.yaml`：旧 Kong Service 片段。
- `secret.example.yaml`：Secret 结构示例，不得写入真实 Token。

如仍需维护 SIT Kubernetes，请先核对现场资源、证书和审批；不要直接把这些
历史模板应用到 UAT。旧 UAT Kubernetes 候选与应用脚本已从当前仓库清理。
