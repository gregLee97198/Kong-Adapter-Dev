# Kong 内网 UAT Docker 离线部署（下载后）

适用：已安装 Docker 与 Docker Compose 的 Linux/AMD64 UAT 主机；Nginx 将外部请求
转发到该主机的 Kong HTTP 端口 `18000`。交付物只有一个 `.tar`，内含 Kong `3.9.3`、
Adapter `0.19.1` 镜像和 Python 依赖。UAT 不使用镜像仓库，也不执行 `pip install`。
包内 `config/environments.yaml` 只有 `uat` Profile；不包含其他环境的部署参数。

## 1. 在 UAT NocoBase 获取 Root API Key

这里的“Root Key”是 **UAT NocoBase API Key（Bearer Token）**，用于 Adapter 读取
系统配置；**不是** NocoBase 服务端的 `APP_KEY`、Root 用户密码，也不是其他
环境的 Token。不要从登录浏览器中复制短期会话 Token 作为长期服务凭据。

1. 请 UAT NocoBase 管理员登录 **UAT 实例**，确认内置的 **Auth: API Keys** 插件已启用。
   在系统设置的 API Keys 页面创建新的 Key。若页面不存在，先由管理员启用该插件。
2. 选择已分配给创建者的角色。若 UAT 已批准使用 Root 权限，选择 Root 角色；
   更安全的做法是使用专门的服务账号及最小权限角色。所选角色至少要能读取
   `GET /api/storages:getBasicInfo`、`GET /api/fields:list` 和
   `GET /api/t_document_checklist:list`；实际权限由 UAT 管理员核准。
3. 设置符合 UAT 安全要求的有效期。创建完成后 **立即复制 Key** 到受控的密钥
   存储位置：NocoBase 只在创建时显示一次。到期或撤销后需重新生成并更新 `.env`。
   如需先确认权限，可在获批准的 API 测试工具中用
   `Authorization: Bearer <API Key>` 调用上述只读接口；不要把真实 Key 放入命令、
   聊天、截图或文档。

API Key 创建、角色绑定和有效期操作见
[NocoBase 官方 API Key 指引](https://docs.nocobase.com/integration/api-keys/usage)；
`APP_KEY` 与 API Token 的区别见
[NocoBase 官方安全指引](https://docs.nocobase.com/security/guide)。

## 2. 解压并在文件管理器修改参数

在 **UAT Docker 主机**的文件管理器中解压下载的 `.tar`，进入解出的同名目录。
包内已经有不含真实密钥的 `.env` 模板；打开“显示隐藏文件”，用文件管理器编辑
`.env` 中的 **两行**，不需要在终端编辑：

| `.env` 修改位置 | 填写内容 |
| --- | --- |
| `UAT_NOCOBASE_BASE_URL=` | **Kong 和 Adapter 容器都能访问**的 UAT NocoBase 内网地址，格式为 `http(s)://内网主机:端口/cmtf2`，不要填其他环境或仅浏览器可访问的地址。若 NocoBase 在同一 Docker 宿主机，可使用 `host.docker.internal`，端口以 UAT 实际值为准。 |
| `NOCOBASE_CONFIG_TOKEN=` | 第 1 步创建的 **UAT** API Key 原文，不加引号，不加 `Bearer ` 前缀。 |

`.env` 中不要增加其他参数；不要把它提交到 Git、放回离线包或发到聊天。
文件权限设为仅所有者可读写（`600`）；包内模板已采用这个权限。
**不需要手工修改** `config/kong.uat-dbless.yml`、`config/nocobase.uat.yaml`
或 `docker-compose.uat.yml`：第 3 步的配置命令会根据 `.env` 更新两个 YAML。

## 3. 分别加载镜像、生成配置、启动容器

先在文件管理器中将
`images/kong-uat-0.19.1-linux-amd64.docker.tar.gz` **单独解压**为同目录的
`kong-uat-0.19.1-linux-amd64.docker.tar`。这是镜像文件，不是最外层交付包；
请确认解压后 `.docker.tar` 文件确实存在。

然后在交付包的解压目录打开终端，按顺序执行以下命令；不要把真实 API Key
输入终端。先将已解压的 Linux/AMD64 镜像加载到 UAT Docker：

```bash
docker image load -i images/kong-uat-0.19.1-linux-amd64.docker.tar
export ADAPTER_IMAGE="$(cat ADAPTER_SOURCE_IMAGE)"
```

再用已加载的 Adapter 镜像运行 **仅生成配置** 的命令：它读取 `.env`，更新
`config/kong.uat-dbless.yml` 与 `config/nocobase.uat.yaml`；不启动容器，
不在 UAT 主机安装 Python 包。保持在同一个终端，使 `ADAPTER_IMAGE` 继续有效。

```bash
docker run --rm --network none \
  --user "$(id -u):$(id -g)" \
  --mount "type=bind,source=$PWD,target=/release" \
  --entrypoint python "$ADAPTER_IMAGE" \
  /release/scripts/retarget_uat_config.py --write
```

最后分别确认 Compose 配置并启动两个容器：

```bash
docker compose --env-file .env -f docker-compose.uat.yml config --quiet
docker compose --env-file .env -f docker-compose.uat.yml \
  up -d --no-build --pull never --force-recreate
docker compose --env-file .env -f docker-compose.uat.yml ps
```

`up` 会创建或重建 Kong 和 Adapter 容器以加载最新镜像、YAML 和 `.env`；
不会拉取 Registry，也不会在 UAT 安装 Python 包。以后改 `.env` 时不必再次
加载同一镜像，但要重新运行配置生成命令和 Compose `up` 命令。

在 UAT Docker 主机查看结果：

```bash
docker ps --filter name=kong-uat-dbless
curl -i --max-time 15 http://127.0.0.1:18000/health/ready
```

两容器应为健康状态；`/health/ready` 返回 API JSON、Adapter 版本 `0.19.1`。
该健康检查只表明服务启动和 Key 已填写，**不代表 Key 对上述 NocoBase
接口有权限**。再从正式 UAT Nginx 入口用获批准的业务测试身份验证接口及
NocoBase 工作流；遇到 `401`/`403`、`configuration_access_denied` 或
`storage_config_access_denied`，请 UAT
管理员核对 API Key 的角色、权限和有效期。

## 4. Nginx 端口指向

| 流向 | 目标 |
| --- | --- |
| 客户端 HTTPS → Nginx | UAT 对外域名及 `443`，由 Nginx 终止 TLS。 |
| Nginx → Kong | `http://UAT主机内网IP:18000`；若 Nginx 与 Kong 同机，用 `http://127.0.0.1:18000`。 |
| Kong → Adapter | Docker 内网服务 `kong-nocoadapter:8080`，不用 Nginx 配置。 |
| Kong → UAT NocoBase | `.env` 的 `UAT_NOCOBASE_BASE_URL`，与 Nginx 指向 Kong 的地址不是同一项。 |

Nginx 对需经过 Kong 的接口保留原始请求路径、查询参数和 `Authorization`
Header；不要在转发时增删 `/cmtf2` 等路径前缀。UAT 运维负责按现有站点结构
配置 Nginx 的 location，不要将不属于 Kong 的 NocoBase 页面全部改指向 Kong。
**必须限制 UAT 主机的 `18000` 仅允许获批准的 Nginx 来源访问**，避免绕过
入口层；Kong Admin API 仅绑定 `127.0.0.1:18001`，不得向 Nginx 或公网转发。
Kong 不占用 UAT 主机的 `443`；上述命令也不修改 Nginx。
