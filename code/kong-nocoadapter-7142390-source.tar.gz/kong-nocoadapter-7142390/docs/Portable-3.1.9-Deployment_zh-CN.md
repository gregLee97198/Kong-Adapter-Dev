# CMTF-II 集成服务 3.1.9 离线部署

本交付包含两个独立的 Linux/AMD64 镜像：

- `cmtf-kong:3.1.9`（底层 Kong 3.9.3）
- `cmtf-adapter:3.1.9`

两个镜像均不保存实际 NocoBase 地址或 Token。部署时只编辑
`adapter.yaml`，再运行配置脚本生成 Kong DB-less 配置。

两个镜像包与两份运行配置 YAML 全部放在交付目录的同一级：

- `adapter.yaml`：Adapter 配置，保存 NocoBase 上游和 Token；
- `kong.yaml`：Kong DB-less 配置，保存全部 Service、Route 和插件声明。

同级的 `docker-compose.yml` 是容器编排文件，不需要修改上游或 Token。

## 1. 导入镜像

```bash
sha256sum -c SHA256SUMS
gzip -dc cmtf-kong-3.1.9-linux-amd64.docker.tar.gz | docker load
gzip -dc cmtf-adapter-3.1.9-linux-amd64.docker.tar.gz | docker load
```

## 2. 编辑唯一运行配置

编辑 `adapter.yaml`：

```yaml
nocobase:
  base_url: "http://host.docker.internal:13000/cmtf2"
  config_token: "replace-with-approved-root-api-token"
```

`base_url` 必须是两个 Docker 容器可访问的地址。Token 不加 `Bearer ` 前缀。
填入实际 Token 后的 YAML 不得提交 Git、放回镜像包或发到聊天。

## 3. 生成并校验 Kong 配置

```bash
sudo bash scripts/configure-runtime.sh
```

脚本会：

1. 将 `adapter.yaml` 权限设置为 UID/GID `10001:10001`、模式 `600`；
2. 从同一个 `base_url` 生成 `kong.yaml`；
3. 验证 Kong 和 Adapter 的 NocoBase 上游一致；
4. 使用 Kong 自身解析完整 DB-less 配置；
5. 不输出 Token。

Docker Secret 或环境变量仍可覆盖 YAML Token，优先级为：

```text
NOCOBASE_CONFIG_TOKEN_FILE / NOCOBASE_CONFIG_TOKEN > nocobase.config_token
```

## 4. 启动

```bash
docker compose -f docker-compose.yml up -d \
  --no-build --pull never --force-recreate

docker compose -f docker-compose.yml ps
curl -k -i https://127.0.0.1/health/ready
```

默认端口：HTTPS `443`、本机 HTTP `18000`、本机 Admin API `18001`。
Adapter 只暴露在 Docker 网络的 `8080`，不占用宿主机端口。
`/health/live` 仅供容器内部健康检查，不作为对外路由。

示例健康检查使用 Kong 自带证书，因此使用 `curl -k`。正式环境如要求受信任
TLS，应在启动前按现场证书规范配置 Kong 证书，或由现有 TLS 终止层代理。

每次修改 `adapter.yaml` 后，重新执行第 3、4 步。

## 5. 安全约束

- 不得把实际 Token 写进镜像、Git 或原始交付包。
- `adapter.yaml` 必须保持 `600` 权限。
- Kong 镜像未挂载 `kong.yaml` 时会拒绝启动，不会回退连接 211。
- 不要使用旧的 UAT `0.19.1` 打包脚本或旧 PostgreSQL Compose。
