#!/usr/bin/env python3
"""Align only the DEV NLA Closed mapping after Send Letter v4 is prepared.

Default invocation is GET-only. ``--apply`` changes two reviewed NLA mapping
rows, one field each, after validating the original values and the unique
Closed status dictionary entry. The historical Rejected dictionary entry and
all other business mappings remain untouched. ``--rollback`` reverses those
two fields only; it deliberately does not delete Closed or any Notice.

This script is deliberately restricted to the 13001 development environment.
Do not run it against 13000; migrate the reviewed NocoBase configuration by
the normal environment migration procedure. No workflow or business form is
edited here.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from dataclasses import dataclass
from typing import Any

from create_nocobase_notice_board_collection import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError

BASE_URL = "http://119.91.104.211:13001/cmtf2"
MAP_COLLECTION = "t_status_name_map"
DETAIL_COLLECTION = "t_status_name_map_details"
STATUS_COLLECTION = "t_notice_board_status"
NLA_MAP_CODE = "t_licence_app"
CLOSED_DETAIL_ID = 370258484068354
PENDING_CLOSURE_DETAIL_ID = 381860413833216
REJECTED_STATUS_ID = 8
MAX_DETAILS = 1000
MAX_STATUSES = 100


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ApiError(message)


def list_rows(
    api: RootNocoBaseApi, collection: str, limit: int
) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"pageSize": limit, "paginate": "false"})
    rows = api.request("GET", f"/api/{collection}:list?{query}")
    require(
        isinstance(rows, list) and len(rows) < limit,
        f"{collection} list missing or possibly truncated",
    )
    require(
        all(isinstance(row, dict) for row in rows),
        f"{collection} list contains a non-object row",
    )
    return [dict(row) for row in rows]


def get_detail(api: RootNocoBaseApi, record_id: int) -> dict[str, Any]:
    query = urllib.parse.urlencode({"filterByTk": str(record_id)})
    row = api.request("GET", f"/api/{DETAIL_COLLECTION}:get?{query}")
    require(
        isinstance(row, dict) and row.get("id") == record_id,
        f"Mapping detail {record_id} is missing or drifted",
    )
    return dict(row)


@dataclass(frozen=True)
class Audit:
    map_id: int
    closed_status_id: int | None
    closed_detail: dict[str, Any]
    pending_detail: dict[str, Any]
    other_rejected_reference_ids: tuple[int, ...]


def audit(api: RootNocoBaseApi) -> Audit:
    """Read the complete relevant dictionary and mappings; never write."""
    maps = list_rows(api, MAP_COLLECTION, MAX_DETAILS)
    nla_maps = [row for row in maps if row.get("f_code") == NLA_MAP_CODE]
    require(
        len(nla_maps) == 1 and type(nla_maps[0].get("id")) is int,
        "Expected one NLA status-name map",
    )
    map_id = nla_maps[0]["id"]

    statuses = list_rows(api, STATUS_COLLECTION, MAX_STATUSES)
    status_ids = [row.get("id") for row in statuses]
    require(
        len(status_ids) == len(set(status_ids)),
        "Notice status dictionary contains duplicate IDs",
    )
    rejected = [row for row in statuses if row.get("f_status") == "Rejected"]
    require(
        len(rejected) == 1 and rejected[0].get("id") == REJECTED_STATUS_ID,
        "Historical Rejected status ID 8 is missing or drifted",
    )
    closed = [row for row in statuses if row.get("f_status") == "Closed"]
    require(len(closed) <= 1, "Closed status is not unique")
    closed_status_id: int | None = None
    if closed:
        row = closed[0]
        require(
            type(row.get("id")) is int
            and row["id"] != REJECTED_STATUS_ID
            and row.get("f_update_allowed") is False
            and row.get("f_recommended_query_data") == "application_data, notices"
            and row.get("f_sort") == 9,
            "Closed dictionary row does not match the Send Letter v4 contract",
        )
        closed_status_id = row["id"]

    details = list_rows(api, DETAIL_COLLECTION, MAX_DETAILS)
    detail_ids = [row.get("id") for row in details]
    require(
        len(detail_ids) == len(set(detail_ids)),
        "Status mapping details contain duplicate IDs",
    )
    by_id = {row.get("id"): row for row in details}
    closed_detail = by_id.get(CLOSED_DETAIL_ID)
    pending_detail = by_id.get(PENDING_CLOSURE_DETAIL_ID)
    require(
        isinstance(closed_detail, dict) and isinstance(pending_detail, dict),
        "The two audited NLA detail rows are missing",
    )

    nla_details = [row for row in details if row.get("fk_map_id") == map_id]
    for code, expected_id in (
        ("2", CLOSED_DETAIL_ID),
        ("16", PENDING_CLOSURE_DETAIL_ID),
    ):
        matches = [row for row in nla_details if str(row.get("f_code")) == code]
        require(
            len(matches) == 1 and matches[0].get("id") == expected_id,
            f"NLA node {code} mapping is not uniquely bound to the audited row",
        )
    require(
        closed_detail.get("fk_map_id") == map_id
        and closed_detail.get("f_name") == "Closed",
        "NLA Closed node identity drifted",
    )
    require(
        pending_detail.get("fk_map_id") == map_id
        and pending_detail.get("f_name") == "Approve for closing the case?",
        "NLA pending-closure node identity drifted",
    )
    require(
        closed_detail.get("f_notice_board_persist") is True,
        "NLA Closed persist flag drifted",
    )
    require(
        closed_detail.get("fk_notice_board_status")
        in (
            {REJECTED_STATUS_ID, closed_status_id}
            if closed_status_id is not None
            else {REJECTED_STATUS_ID}
        ),
        "NLA Closed status mapping is neither reviewed old nor new value",
    )
    require(
        pending_detail.get("f_notice_board_persist") in (True, False)
        and type(pending_detail.get("f_notice_board_persist")) is bool,
        "NLA pending-closure persist flag drifted",
    )

    other_rejected = tuple(
        sorted(
            int(row["id"])
            for row in details
            if row.get("fk_notice_board_status") == REJECTED_STATUS_ID
            and row.get("id") != CLOSED_DETAIL_ID
        )
    )
    return Audit(
        map_id,
        closed_status_id,
        dict(closed_detail),
        dict(pending_detail),
        other_rejected,
    )


def state(snapshot: Audit) -> str:
    closed_id = snapshot.closed_detail["fk_notice_board_status"]
    pending = snapshot.pending_detail["f_notice_board_persist"]
    if closed_id == REJECTED_STATUS_ID and pending is True:
        return "old"
    if (
        snapshot.closed_status_id is not None
        and closed_id == snapshot.closed_status_id
        and pending is False
    ):
        return "new"
    return "partial"


def print_audit(snapshot: Audit, *, rollback: bool) -> None:
    print(
        json.dumps(
            {
                "environment": "13001",
                "mode": "rollback-preview" if rollback else "dry-run",
                "nla_map_id": snapshot.map_id,
                "closed_status_id": snapshot.closed_status_id,
                "closed_detail_id": CLOSED_DETAIL_ID,
                "closed_detail_status_id": snapshot.closed_detail[
                    "fk_notice_board_status"
                ],
                "pending_closure_detail_id": PENDING_CLOSURE_DETAIL_ID,
                "pending_closure_persist": snapshot.pending_detail[
                    "f_notice_board_persist"
                ],
                "other_rejected_reference_ids": snapshot.other_rejected_reference_ids,
                "state": state(snapshot),
                "writes": "none",
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )


def write_one(
    api: RootNocoBaseApi,
    *,
    record_id: int,
    field: str,
    expected: Any,
    desired: Any,
    map_id: int,
    name: str,
) -> None:
    row = get_detail(api, record_id)
    require(
        row.get("fk_map_id") == map_id
        and row.get("f_name") == name
        and row.get(field) == expected
        and type(row.get(field)) is type(expected),
        f"Mapping detail {record_id} changed after preflight; no write made",
    )
    query = urllib.parse.urlencode({"filterByTk": str(record_id)})
    path = f"/api/{DETAIL_COLLECTION}:update?{query}"
    write_error: ApiError | None = None
    try:
        api.request("POST", path, {field: desired})
    except ApiError as exc:
        write_error = exc
    result = get_detail(api, record_id)
    require(
        result.get("fk_map_id") == map_id
        and result.get("f_name") == name
        and result.get(field) == desired
        and type(result.get(field)) is type(desired),
        f"Mapping detail {record_id} update not confirmed by readback",
    )
    if write_error is not None:
        print(f"write_timeout_recovered_by_readback={record_id}")


def apply(api: RootNocoBaseApi, *, rollback: bool = False) -> Audit:
    snapshot = audit(api)
    if not rollback:
        require(
            snapshot.closed_status_id is not None,
            "Closed dictionary is absent; prepare Send Letter v4 first",
        )
        # Suppress a premature closure Notice before switching the final node.
        if snapshot.pending_detail["f_notice_board_persist"] is True:
            write_one(
                api,
                record_id=PENDING_CLOSURE_DETAIL_ID,
                field="f_notice_board_persist",
                expected=True,
                desired=False,
                map_id=snapshot.map_id,
                name="Approve for closing the case?",
            )
        if snapshot.closed_detail["fk_notice_board_status"] == REJECTED_STATUS_ID:
            write_one(
                api,
                record_id=CLOSED_DETAIL_ID,
                field="fk_notice_board_status",
                expected=REJECTED_STATUS_ID,
                desired=snapshot.closed_status_id,
                map_id=snapshot.map_id,
                name="Closed",
            )
        expected_state = "new"
    else:
        # Reverse the final-node mapping first; do not delete the shared
        # Rejected or Closed dictionary rows or historical Notice records.
        if (
            snapshot.closed_status_id is not None
            and snapshot.closed_detail["fk_notice_board_status"]
            == snapshot.closed_status_id
        ):
            write_one(
                api,
                record_id=CLOSED_DETAIL_ID,
                field="fk_notice_board_status",
                expected=snapshot.closed_status_id,
                desired=REJECTED_STATUS_ID,
                map_id=snapshot.map_id,
                name="Closed",
            )
        if snapshot.pending_detail["f_notice_board_persist"] is False:
            write_one(
                api,
                record_id=PENDING_CLOSURE_DETAIL_ID,
                field="f_notice_board_persist",
                expected=False,
                desired=True,
                map_id=snapshot.map_id,
                name="Approve for closing the case?",
            )
        expected_state = "old"
    final = audit(api)
    require(
        state(final) == expected_state,
        f"Final NLA mapping state is not {expected_state}; inspect before retry",
    )
    return final


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default=BASE_URL)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--rollback", action="store_true")
    parser.add_argument(
        "--ack-rollback-risk",
        action="store_true",
        help="Required for --rollback --apply; restores old premature-notice risk",
    )
    args = parser.parse_args(argv)
    if args.base_url.rstrip("/") != BASE_URL:
        parser.error("Only the audited NocoBase DEV 13001 URL is allowed")
    if args.rollback and args.apply and not args.ack_rollback_risk:
        parser.error("--rollback --apply requires --ack-rollback-risk")
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    try:
        api = RootNocoBaseApi(BASE_URL, token)
        if not args.apply:
            print_audit(audit(api), rollback=args.rollback)
            if not args.rollback:
                print("apply_after=Send Letter v4 prepares Closed status")
            else:
                print("rollback_note=Notice history and Closed status remain")
            return 0
        final = apply(api, rollback=args.rollback)
        print(f"result={state(final)}")
        print("rollback_note=Historical Notices and status dictionary are retained")
        return 0
    except ApiError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
