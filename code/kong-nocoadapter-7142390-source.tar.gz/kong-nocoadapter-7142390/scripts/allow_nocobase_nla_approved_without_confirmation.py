#!/usr/bin/env python3
"""Prepare an isolated Send Letter v5 status-eligibility revision on DEV 13001.

The executed v4 source is never edited.  This tool pins its complete graph
fingerprint, creates a disabled NocoBase revision, and changes only two JS
script-node ``content`` strings: the NLA Notice plan and its persisted-Notice
status-advance guard.  The sole semantic change permits Approved to advance
from Acknowledged after the real sent c+f pair exists.  This supports the
native LORCHE 13→9 route, which may skip b Confirmation and d Reminder.

``audit`` and commands without ``--apply`` issue only GETs.  ``prepare``
temporarily disables v4 to clone a revision, then restores it; UTC gap bounds
are printed for Send Letter event reconciliation.  ``cutover`` and ``rollback``
are explicit, guarded and never enable both versions.  Do not run operators
concurrently.  No native NLA business workflow, historical Notice or 13000
environment is modified by this script.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import os
import sys
import urllib.parse
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any

from complete_nocobase_nla_sent_letter_notice import (
    ADVANCE_PLAN,
    BASE_URL,
    PLAN,
    RootNocoBaseApi,
    source_fingerprint,
)
from extend_nocobase_staging_relations import ApiError

SOURCE_ID = 390912096600064
SOURCE_KEY = "75fzv69gij3"
SOURCE_TITLE = "API Notice — Sent Letter to Notice List v3"
SOURCE_FINGERPRINT = (
    "f2b66de8889339820863fbbb35aefa92adbeff8952ac6704bf4308eeaeda0079"
)
SOURCE_NODE_COUNT = 26
PLAN_ID = 390912193069056
ADVANCE_PLAN_ID = 390912237109248
PLAN_CONTENT_SHA256 = (
    "2651b3f7a16dd905ffb4e6d05eb33834ea7bdb4313766dddf9ed8129f28d3519"
)
ADVANCE_CONTENT_SHA256 = (
    "bb484af5b67806cfcbac81ee4c36f3797d60a5e2988260617eb5d8b7ee017ff6"
)
CHANGES = {
    PLAN: (
        "  Approved: ['Confirmed', 'Reminding', 'Approved'],",
        "  Approved: ['Acknowledged', 'Confirmed', 'Reminding', 'Approved'],",
        PLAN_ID,
        PLAN_CONTENT_SHA256,
    ),
    ADVANCE_PLAN: (
        "  Approved: ['Confirmed', 'Reminding'],",
        "  Approved: ['Acknowledged', 'Confirmed', 'Reminding'],",
        ADVANCE_PLAN_ID,
        ADVANCE_CONTENT_SHA256,
    ),
}


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ApiError(message)


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def by_title(workflow: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    nodes = workflow.get("nodes") or []
    titles = [node.get("title") for node in nodes]
    require(len(titles) == len(set(titles)), "Duplicate workflow node title")
    return {str(node["title"]): dict(node) for node in nodes}


def validated_source_content(workflow: Mapping[str, Any], title: str) -> str:
    source_node = by_title(workflow).get(title)
    require(source_node is not None, f"Missing v4 node: {title}")
    old, _new, node_id, expected_hash = CHANGES[title]
    content = (source_node.get("config") or {}).get("content")
    require(
        source_node.get("id") == node_id
        and source_node.get("type") == "script"
        and isinstance(content, str)
        and hashlib.sha256(content.encode()).hexdigest() == expected_hash
        and content.count(old) == 1,
        f"Reviewed v4 JS node differs: {title}",
    )
    return content


def target_content(source: Mapping[str, Any], title: str) -> str:
    content = validated_source_content(source, title)
    old, new, _node_id, _hash = CHANGES[title]
    revised = content.replace(old, new, 1)
    require(revised != content, f"No JS status eligibility change: {title}")
    return revised


def validate_source(workflow: Mapping[str, Any], *, enabled: bool) -> None:
    require(
        workflow.get("id") == SOURCE_ID
        and workflow.get("key") == SOURCE_KEY
        and workflow.get("title") == SOURCE_TITLE
        and workflow.get("enabled") is enabled
        and workflow.get("type") == "collection"
        and workflow.get("sync") is False
        and len(workflow.get("nodes") or []) == SOURCE_NODE_COUNT
        and source_fingerprint(workflow) == SOURCE_FINGERPRINT,
        "Executed Send Letter v4 differs from the audited 26-node graph",
    )
    for title in CHANGES:
        validated_source_content(workflow, title)


def graph_view(workflow: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    nodes = by_title(workflow)
    ids = [node.get("id") for node in nodes.values()]
    keys = [node.get("key") for node in nodes.values()]
    require(
        all(isinstance(value, int) for value in ids)
        and all(isinstance(value, str) and value for value in keys)
        and len(ids) == len(set(ids))
        and len(keys) == len(set(keys)),
        "Workflow node identity missing or duplicated",
    )
    id_to_title = {node["id"]: title for title, node in nodes.items()}
    view: dict[str, dict[str, Any]] = {}
    for title, node in nodes.items():
        require(node.get("workflowId") == workflow.get("id"),
                f"Node belongs to another workflow: {title}")
        for name in ("upstreamId", "downstreamId"):
            require(node.get(name) is None or node[name] in id_to_title,
                    f"Edge leaves workflow: {title}.{name}")
        view[title] = {
            "key": node["key"],
            "type": node.get("type"),
            "config": node.get("config"),
            "upstream": id_to_title.get(node.get("upstreamId")),
            "downstream": id_to_title.get(node.get("downstreamId")),
            "branchIndex": node.get("branchIndex"),
        }
    return view


def validate_candidate(
    source: Mapping[str, Any], candidate: Mapping[str, Any],
    *, enabled: bool, phase: str,
) -> None:
    require(
        isinstance(candidate.get("id"), int)
        and candidate["id"] > SOURCE_ID
        and candidate.get("key") == SOURCE_KEY
        and candidate.get("title") == SOURCE_TITLE
        and candidate.get("enabled") is enabled
        and candidate.get("type") == source.get("type")
        and candidate.get("sync") == source.get("sync")
        and candidate.get("config") == source.get("config")
        and len(candidate.get("nodes") or []) == SOURCE_NODE_COUNT,
        "v5 revision identity, trigger or node count drifted",
    )
    expected = graph_view(source)
    actual = graph_view(candidate)
    require(set(actual) == set(expected), "v5 revision node titles differ")
    for title in CHANGES:
        expected[title] = copy.deepcopy(expected[title])
        config = copy.deepcopy(expected[title]["config"])
        if phase == "prepared" or (phase == "partial" and
                                   actual[title]["config"].get("content") ==
                                   target_content(source, title)):
            config["content"] = target_content(source, title)
        expected[title]["config"] = config
    require(actual == expected,
            "v5 revision differs beyond the two reviewed JS content changes")
    if phase == "clone":
        require(not enabled, "Untouched clone cannot be active")
    if phase == "partial":
        require(not enabled, "Partial v5 revision cannot be active")


def workflow_family(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    q = urllib.parse.urlencode({"filter[key]": SOURCE_KEY, "pageSize": 100})
    rows = api.request("GET", "/api/workflows:list?" + q)
    require(isinstance(rows, list) and len(rows) < 100,
            "Send Letter workflow family query incomplete")
    require(all(row.get("key") == SOURCE_KEY for row in rows),
            "Send Letter family key drifted")
    return [dict(row) for row in rows]


def candidate_id(api: RootNocoBaseApi) -> int | None:
    rows = workflow_family(api)
    require(sum(row.get("id") == SOURCE_ID for row in rows) == 1,
            "Audited v4 source missing from revision family")
    require(all(not row.get("enabled") for row in rows
                if int(row["id"]) < SOURCE_ID),
            "Older Send Letter revision unexpectedly enabled")
    newer = [int(row["id"]) for row in rows if int(row["id"]) > SOURCE_ID]
    require(len(newer) <= 1, "Unexpected additional Send Letter revisions")
    return newer[0] if newer else None


def has_execution(api: RootNocoBaseApi, workflow_id: int) -> bool:
    q = urllib.parse.urlencode(
        {"filter[workflowId]": str(workflow_id), "pageSize": 1}
    )
    rows = api.request("GET", "/api/executions:list?" + q)
    require(isinstance(rows, list), "v5 execution query failed")
    return bool(rows)


def set_enabled(api: RootNocoBaseApi, workflow_id: int, desired: bool) -> None:
    before = api.get_workflow(workflow_id)
    require(isinstance(before.get("enabled"), bool), "Enabled flag unknown")
    if before["enabled"] is not desired:
        api.request("POST", f"/api/workflows:update?filterByTk={workflow_id}",
                    {"enabled": desired})
    require(api.get_workflow(workflow_id).get("enabled") is desired,
            f"Workflow {workflow_id} enabled readback failed")


def create_revision(api: RootNocoBaseApi,
                    source: Mapping[str, Any]) -> int:
    validate_source(source, enabled=True)
    require(candidate_id(api) is None, "A newer Send Letter revision exists")
    print(f"prepare_gap_start_utc={now_utc()}", flush=True)
    revision_id: int | None = None
    try:
        set_enabled(api, SOURCE_ID, False)
        q = urllib.parse.urlencode(
            {"filterByTk": SOURCE_ID, "filter[key]": SOURCE_KEY}
        )
        try:
            result = api.request("POST", "/api/workflows:revision?" + q, {})
            if isinstance(result, dict) and isinstance(result.get("id"), int):
                revision_id = result["id"]
        except ApiError:
            pass
        discovered = candidate_id(api)
        require(discovered is not None
                and (revision_id is None or revision_id == discovered),
                "Revision outcome uncertain; inspect family before retry")
        revision_id = discovered
        set_enabled(api, revision_id, False)
        validate_candidate(
            source, api.get_workflow(revision_id), enabled=False, phase="clone"
        )
    finally:
        discovered = candidate_id(api)
        if discovered is not None:
            set_enabled(api, discovered, False)
        set_enabled(api, SOURCE_ID, True)
        print(f"prepare_gap_end_utc={now_utc()}", flush=True)
        print("gap_audit=Reconcile Send Letter events within UTC gap bounds")
    require(revision_id is not None, "Revision was not created")
    return revision_id


def prepare(api: RootNocoBaseApi) -> int:
    source = api.get_workflow(SOURCE_ID)
    validate_source(source, enabled=True)
    revision_id = candidate_id(api)
    if revision_id is None:
        revision_id = create_revision(api, source)
    require(not has_execution(api, revision_id),
            "An executed v5 revision cannot be edited")
    candidate = api.get_workflow(revision_id)
    require(candidate.get("enabled") is False,
            "v5 candidate must be disabled during prepare")
    validate_candidate(source, candidate, enabled=False, phase="partial")
    for title in CHANGES:
        candidate = api.get_workflow(revision_id)
        node = by_title(candidate)[title]
        config = copy.deepcopy(node["config"])
        desired = target_content(source, title)
        if config["content"] == desired:
            continue
        require(config["content"] == validated_source_content(source, title),
                f"Candidate {title} content differs unexpectedly")
        config["content"] = desired
        try:
            api.update_node(int(node["id"]), {"config": config})
        except ApiError:
            pass
        after = by_title(api.get_workflow(revision_id))[title]
        require(after.get("config") == config,
                f"v5 {title} write outcome uncertain")
    validate_candidate(source, api.get_workflow(revision_id),
                       enabled=False, phase="prepared")
    validate_source(api.get_workflow(SOURCE_ID), enabled=True)
    return revision_id


def checked_pair(api: RootNocoBaseApi, *, source_enabled: bool,
                 candidate_enabled: bool
                 ) -> tuple[dict[str, Any], dict[str, Any]]:
    source = dict(api.get_workflow(SOURCE_ID))
    validate_source(source, enabled=source_enabled)
    revision_id = candidate_id(api)
    require(revision_id is not None, "Prepared v5 revision missing")
    candidate = dict(api.get_workflow(revision_id))
    validate_candidate(source, candidate,
                       enabled=candidate_enabled, phase="prepared")
    require(not (source_enabled and candidate_enabled),
            "v4 and v5 both enabled")
    return source, candidate


def cutover(api: RootNocoBaseApi) -> int:
    _source, candidate = checked_pair(
        api, source_enabled=True, candidate_enabled=False
    )
    revision_id = int(candidate["id"])
    require(not has_execution(api, revision_id),
            "Candidate has already executed")
    print(f"cutover_gap_start_utc={now_utc()}", flush=True)
    try:
        set_enabled(api, SOURCE_ID, False)
        set_enabled(api, revision_id, True)
        checked_pair(api, source_enabled=False, candidate_enabled=True)
    except Exception as exc:
        try:
            set_enabled(api, revision_id, False)
            set_enabled(api, SOURCE_ID, True)
            checked_pair(api, source_enabled=True, candidate_enabled=False)
        except Exception as rollback_exc:
            try:
                # A lost source-enable response may follow a committed write.
                # Turn v4 off before restoring the already-reviewed v5 graph.
                set_enabled(api, SOURCE_ID, False)
                set_enabled(api, revision_id, True)
                checked_pair(api, source_enabled=False, candidate_enabled=True)
            except Exception as restore_exc:
                raise ApiError(
                    f"Cutover failed ({exc}); restoring v4 failed "
                    f"({rollback_exc}); restoring v5 also failed "
                    f"({restore_exc}); inspect enabled flags immediately"
                ) from restore_exc
            raise ApiError(
                f"Cutover failed ({exc}); restoring v4 failed "
                f"({rollback_exc}); reviewed v5 is active"
            ) from rollback_exc
        raise ApiError(f"Cutover failed; v4 restored: {exc}") from exc
    finally:
        print(f"cutover_gap_end_utc={now_utc()}", flush=True)
        print("gap_audit=Reconcile Send Letter events within UTC gap bounds")
    return revision_id


def rollback(api: RootNocoBaseApi) -> None:
    _source, candidate = checked_pair(
        api, source_enabled=False, candidate_enabled=True
    )
    revision_id = int(candidate["id"])
    print(f"rollback_gap_start_utc={now_utc()}", flush=True)
    try:
        set_enabled(api, revision_id, False)
        set_enabled(api, SOURCE_ID, True)
        checked_pair(api, source_enabled=True, candidate_enabled=False)
    except Exception as exc:
        try:
            # Recheck v4 before re-enabling v5: the source write may have
            # committed even when its response was lost.
            set_enabled(api, SOURCE_ID, False)
            set_enabled(api, revision_id, True)
            checked_pair(api, source_enabled=False, candidate_enabled=True)
        except Exception as restore_exc:
            raise ApiError(
                f"Rollback failed ({exc}); restoring v5 also failed "
                f"({restore_exc}); inspect enabled flags immediately"
            ) from restore_exc
        raise ApiError(f"Rollback failed ({exc}); v5 restored") from exc
    finally:
        print(f"rollback_gap_end_utc={now_utc()}", flush=True)
        print("gap_audit=Reconcile Send Letter events within UTC gap bounds")


def audit(api: RootNocoBaseApi) -> None:
    source = api.get_workflow(SOURCE_ID)
    enabled = source.get("enabled")
    require(isinstance(enabled, bool), "v4 enabled flag unknown")
    validate_source(source, enabled=enabled)
    revision_id = candidate_id(api)
    phase = "absent"
    revision_enabled = None
    if revision_id is not None:
        candidate = api.get_workflow(revision_id)
        revision_enabled = candidate.get("enabled")
        require(isinstance(revision_enabled, bool), "v5 enabled flag unknown")
        require(not (enabled and revision_enabled), "Both versions enabled")
        try:
            validate_candidate(source, candidate,
                               enabled=revision_enabled, phase="prepared")
            phase = "active" if revision_enabled else "prepared-disabled"
        except ApiError:
            require(not revision_enabled, "Incomplete candidate is active")
            validate_candidate(source, candidate,
                               enabled=False, phase="partial")
            phase = "partial-disabled"
    require(enabled or revision_enabled is True,
            "Both Send Letter versions are disabled; Notice capture is offline")
    print(f"source_v4_id={SOURCE_ID} enabled={str(enabled).lower()}")
    print(f"source_fingerprint={source_fingerprint(source)}")
    print(f"candidate_v5_id={revision_id} enabled={revision_enabled} phase={phase}")
    print("scope=two JS content strings only; all 26 nodes/edges and trigger preserved")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("audit", "prepare", "cutover", "rollback", "verify")
    )
    parser.add_argument("--base-url", default=BASE_URL)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--ack-brief-nonatomic-cutover", action="store_true")
    args = parser.parse_args(argv)
    if args.base_url.rstrip("/") != BASE_URL:
        parser.error("Only 13001 DEV NocoBase is in scope")
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        parser.error("NOCOBASE_TOKEN is required")
    api = RootNocoBaseApi(BASE_URL, token)
    try:
        if args.command in ("audit", "verify"):
            audit(api)
            if args.command == "verify":
                _, candidate = checked_pair(
                    api, source_enabled=False, candidate_enabled=True
                )
                print(f"verified_active_v5_id={candidate['id']}")
            return 0
        if not args.apply:
            audit(api)
            print(f"mode=read-only planned_command={args.command}")
            return 0
        if not args.ack_brief_nonatomic_cutover:
            parser.error("--apply requires --ack-brief-nonatomic-cutover")
        if args.command == "prepare":
            print(f"prepared_candidate_id={prepare(api)}")
        elif args.command == "cutover":
            print(f"active_candidate_id={cutover(api)}")
        else:
            rollback(api)
            print(f"restored_v4_id={SOURCE_ID}")
    except ApiError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
