#!/usr/bin/env python3
"""Guardedly classify explicitly reviewed API integration workflows on 13001.

Dry-run is GET-only.  Apply reads exact workflow preimages, saves them outside
the repository, and changes only the categories association.  No workflow is
enabled/disabled, revised, or given a new node.  An uncertain POST is read
back once and never blindly retried.

Inputs are reviewed FIFO manifests (worker/formal UID roles only) and/or
an explicit JSON allowlist with uid/title/type/key.  This deliberately does
not discover workflows by a broad title prefix or include native workflows,
smoke probes, or retired Schedule versions.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import urllib.parse
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import API_SOURCE_CATEGORY_TITLE, ApiError
from plan_nocobase_q3_actions import (
    ADMISSION_TITLE,
    DISPATCH_TITLE,
    REJECTION_TITLE,
)

BASE_URL = "http://119.91.104.211:13001/cmtf2"
CONFIRM = "ATTACH_API_SUORCE_EXACT_WORKFLOWS_13001_ONLY"
BACKUP_ROOT = Path("/Users/work/noco/kong-nocoadapter-artifacts/workflow-backups")
MANIFEST_ROLES = {
    "worker_uid": "collection",
    "formal_uid": "schedule",
}
ALLOWED_TITLE_PREFIXES = ("API ", "OP ")
EXACT_Q3_ACTION_TITLES = {ADMISSION_TITLE, REJECTION_TITLE, DISPATCH_TITLE}


class CategoryGuardError(ApiError):
    """A reviewed workflow/category preimage differs from the live state."""


@dataclass(frozen=True)
class Target:
    uid: int
    expected_type: str
    expected_title: str | None
    expected_key: str | None
    source: str


def _sha(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True,
                   separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_targets(manifests: list[Path], allowlist: Path | None) -> list[Target]:
    result: dict[int, Target] = {}
    for path in manifests:
        doc = _load_json(path)
        if not isinstance(doc, dict) or not isinstance(doc.get("family"), str):
            raise CategoryGuardError(f"Invalid reviewed manifest: {path}")
        schedule_key = doc.get("schedule_key")
        for field, expected_type in MANIFEST_ROLES.items():
            uid = doc.get(field)
            if uid is None:
                continue
            if not isinstance(uid, int) or uid <= 0:
                raise CategoryGuardError(f"Invalid {field} in {path}")
            target = Target(
                uid, expected_type, None,
                schedule_key if expected_type == "schedule" else None,
                f"{path}:{field}:{doc['family']}",
            )
            _add_target(result, target)
    if allowlist is not None:
        doc = _load_json(allowlist)
        if not isinstance(doc, list):
            raise CategoryGuardError("Explicit allowlist must be a JSON array")
        for item in doc:
            if not isinstance(item, dict):
                raise CategoryGuardError("Invalid explicit allowlist row")
            uid = item.get("uid")
            title = item.get("title")
            kind = item.get("type")
            key = item.get("key")
            if (not isinstance(uid, int) or uid <= 0
                    or not isinstance(title, str) or not title
                    or kind not in {"collection", "schedule", "custom-action"}
                    or not isinstance(key, str) or not key):
                raise CategoryGuardError(
                    "Allowlist requires exact uid, title, type and key"
                )
            _add_target(result, Target(uid, kind, title, key, str(allowlist)))
    if not result:
        raise CategoryGuardError("No reviewed workflow UIDs supplied")
    return [result[uid] for uid in sorted(result)]


def _add_target(result: dict[int, Target], target: Target) -> None:
    previous = result.get(target.uid)
    if previous is not None:
        if (previous.expected_type != target.expected_type
                or (previous.expected_title and target.expected_title
                    and previous.expected_title != target.expected_title)
                or (previous.expected_key and target.expected_key
                    and previous.expected_key != target.expected_key)):
            raise CategoryGuardError(f"Conflicting UID {target.uid} inputs")
        return
    result[target.uid] = target


def _get_workflow(api: RootNocoBaseApi, uid: int) -> dict[str, Any]:
    query = urllib.parse.urlencode([
        ("filterByTk", str(uid)), ("appends[]", "categories"),
        ("appends[]", "nodes"),
    ])
    row = api.request("GET", f"/api/workflows:get?{query}")
    if not isinstance(row, dict) or row.get("id") != uid:
        raise CategoryGuardError(f"Workflow UID {uid} readback failed")
    if not isinstance(row.get("categories"), list):
        raise CategoryGuardError(f"Workflow UID {uid} categories not appended")
    if not isinstance(row.get("nodes"), list):
        raise CategoryGuardError(f"Workflow UID {uid} nodes not appended")
    return row


def _category_ids(row: Mapping[str, Any]) -> list[int]:
    ids: list[int] = []
    for entry in row["categories"]:
        category_id = entry.get("id") if isinstance(entry, dict) else entry
        if not isinstance(category_id, int):
            raise CategoryGuardError("Workflow category has no integer ID")
        ids.append(category_id)
    if len(ids) != len(set(ids)):
        raise CategoryGuardError("Workflow categories contain duplicate IDs")
    return sorted(ids)


def _shape(row: Mapping[str, Any]) -> str:
    nodes = [
        {field: node.get(field) for field in (
            "id", "key", "type", "title", "upstreamId", "downstreamId",
            "branchIndex", "config",
        )}
        for node in row["nodes"]
    ]
    nodes.sort(key=lambda node: str(node["id"]))
    return _sha({field: row.get(field) for field in (
        "id", "key", "type", "title", "enabled", "sync", "config",
    )} | {"nodes": nodes})


def _validate(row: Mapping[str, Any], target: Target) -> None:
    if row.get("type") != target.expected_type:
        raise CategoryGuardError(f"UID {target.uid} workflow type drift")
    title = row.get("title")
    if (not isinstance(title, str)
            or not (title.startswith(ALLOWED_TITLE_PREFIXES)
                    or (row.get("type") == "custom-action"
                        and target.expected_title is not None
                        and target.expected_key is not None
                        and title in EXACT_Q3_ACTION_TITLES))):
        raise CategoryGuardError(f"UID {target.uid} is not an API workflow")
    if target.expected_title is not None and title != target.expected_title:
        raise CategoryGuardError(f"UID {target.uid} title drift")
    if target.expected_key is not None and row.get("key") != target.expected_key:
        raise CategoryGuardError(f"UID {target.uid} key drift")


def _category_id(api: RootNocoBaseApi) -> int:
    query = urllib.parse.urlencode({
        "pageSize": 100, "filter[title]": API_SOURCE_CATEGORY_TITLE,
    })
    rows = api.request("GET", f"/api/workflowCategories:list?{query}")
    exact = [row for row in rows or [] if isinstance(row, dict)
             and row.get("title") == API_SOURCE_CATEGORY_TITLE]
    if len(exact) != 1 or not isinstance(exact[0].get("id"), int):
        raise CategoryGuardError("API Suorce category is missing or ambiguous")
    return exact[0]["id"]


def inspect(api: RootNocoBaseApi, targets: list[Target]) -> dict[str, Any]:
    category_id = _category_id(api)
    rows: list[dict[str, Any]] = []
    for target in targets:
        workflow = _get_workflow(api, target.uid)
        _validate(workflow, target)
        current = _category_ids(workflow)
        rows.append({
            "uid": target.uid, "source": target.source,
            "title": workflow["title"], "type": workflow["type"],
            "key": workflow["key"], "enabled": workflow.get("enabled"),
            "category_ids_before": current,
            "category_ids_after": sorted(set(current) | {category_id}),
            "needs_update": category_id not in current,
            "shape_sha256": _shape(workflow), "workflow": workflow,
        })
    return {"category_title": API_SOURCE_CATEGORY_TITLE,
            "category_id": category_id, "rows": rows}


def _write_private(path: Path, data: Any) -> None:
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, default=str)
        stream.write("\n")


def apply(
    api: RootNocoBaseApi, targets: list[Target], backup_root: Path
) -> dict[str, Any]:
    plan = inspect(api, targets)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_dir = backup_root / f"13001-api-suorce-classification-{stamp}"
    backup_dir.mkdir(mode=0o700, parents=True, exist_ok=False)
    for row in plan["rows"]:
        _write_private(backup_dir / f"workflow-{row['uid']}-before.json",
                       row["workflow"])
    _write_private(backup_dir / "intent.json", {
        "category_title": plan["category_title"],
        "category_id": plan["category_id"],
        "targets": [{key: value for key, value in row.items()
                     if key != "workflow"} for row in plan["rows"]],
    })
    completed: list[int] = []
    for row in plan["rows"]:
        uid = row["uid"]
        if not row["needs_update"]:
            continue
        fresh = _get_workflow(api, uid)
        if (_shape(fresh) != row["shape_sha256"]
                or _category_ids(fresh) != row["category_ids_before"]):
            raise CategoryGuardError(
                f"UID {uid} changed after backup; no category write"
            )
        error: Exception | None = None
        try:
            api.request("POST", f"/api/workflows:update?filterByTk={uid}",
                        {"categories": row["category_ids_after"]})
        except Exception as exc:
            error = exc
        try:
            after = _get_workflow(api, uid)
        except Exception as exc:
            raise CategoryGuardError(
                f"UID {uid} POST/readback outcome unknown; inspect exact UID; "
                f"do not retry. Backup: {backup_dir}"
            ) from exc
        if (_shape(after) != row["shape_sha256"]
                or _category_ids(after) != row["category_ids_after"]):
            raise CategoryGuardError(
                f"UID {uid} category/graph readback differs"
                + (f" after POST error {error!r}" if error else "")
                + f"; stop, no retry. Backup: {backup_dir}"
            )
        completed.append(uid)
    return {"environment": "13001", "category": API_SOURCE_CATEGORY_TITLE,
            "category_id": plan["category_id"],
            "backup_dir": str(backup_dir), "updated_uids": completed,
            "already_categorized_uids": [row["uid"] for row in plan["rows"]
                                         if not row["needs_update"]],
            "nodes_or_enablement_changed": False}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", action="append", type=Path, default=[])
    parser.add_argument("--allowlist", type=Path)
    parser.add_argument("--base-url", default=BASE_URL)
    parser.add_argument("--token-file", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--confirm")
    parser.add_argument("--backup-root", type=Path, default=BACKUP_ROOT)
    args = parser.parse_args()
    if args.base_url.rstrip("/") != BASE_URL:
        raise SystemExit("Only exact 13001 /cmtf2 URL is allowed")
    if args.apply and args.confirm != CONFIRM:
        raise SystemExit(f"Apply requires --confirm {CONFIRM}")
    targets = load_targets(args.manifest, args.allowlist)
    token = args.token_file.read_text(encoding="utf-8").strip()
    if not token:
        raise SystemExit("Empty root token file")
    api = RootNocoBaseApi(args.base_url, token)
    if args.apply:
        print(json.dumps(apply(api, targets, args.backup_root),
                         ensure_ascii=False, indent=2))
    else:
        plan = inspect(api, targets)
        print(json.dumps({
            "environment": "13001", "writes": False,
            "category": plan["category_title"],
            "category_id": plan["category_id"],
            "workflows": [{key: value for key, value in row.items()
                           if key != "workflow"} for row in plan["rows"]],
        }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
