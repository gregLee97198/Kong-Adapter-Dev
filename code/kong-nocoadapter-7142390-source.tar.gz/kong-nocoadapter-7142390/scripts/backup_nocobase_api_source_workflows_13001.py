#!/usr/bin/env python3
"""Create a read-only, local backup of NocoBase API Suorce workflows.

This utility is deliberately export-only: it uses HTTP ``GET`` requests and
has no code path for creating, revising, enabling, disabling, or deleting a
NocoBase resource.  It is intended to be run *before* an approved cleanup of
development workflows.

By default it discovers every workflow in the ``API Suorce`` category.  One
or more ``--workflow-id`` values can be supplied to export an exact set
instead.  The output directory is new for every invocation and contains:

* ``manifest.json``: selection, hashes, and a compact inventory;
* ``workflows/<id>--<slug>.json``: workflow metadata plus every node/config;
* ``workflows/<id>--<slug>.graph.json``: a normalized nodes/edges view;
* ``README.md``: restore/audit notes (this script itself does not restore).

The source never embeds a credential.  Supply an expiring administrator token
only at runtime through ``NOCOBASE_TOKEN``.  Values that look like secrets in
workflow configuration are redacted by default; use the explicit two-flag
opt-in only when an exact local, access-controlled configuration archive is
required.
"""

from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import os
import re
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Iterable, Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_BASE_URL = "http://119.91.104.211:13001/cmtf2"
DEFAULT_CATEGORY_TITLE = "API Suorce"  # Existing NocoBase category spelling.
DEFAULT_OUTPUT_ROOT = Path(
    "/Users/work/noco/kong-nocoadapter-artifacts/workflow-backups"
)
SENSITIVE_KEY_RE = re.compile(
    r"(?:^|[_-])(?:token|secret|password|passwd|authorization|api[_-]?key|"
    r"private[_-]?key|credential)(?:$|[_-])",
    re.IGNORECASE,
)
SENSITIVE_VALUE_RE = re.compile(
    r"^(?:Bearer\s+)?(?:eyJ[A-Za-z0-9_-]{10,}|gh[pousr]_[A-Za-z0-9_]{10,}|"
    r"sk-[A-Za-z0-9_-]{10,})$",
    re.IGNORECASE,
)
RAW_CONFIG_CONFIRMATION = "INCLUDE_SENSITIVE_WORKFLOW_CONFIG"
GET_RETRY_ATTEMPTS = 6


class ExportError(RuntimeError):
    """An API or local export invariant failed."""


class ReadOnlyNocoBaseApi:
    """Tiny GET-only NocoBase client; mutation methods intentionally do not exist."""

    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        root_role: bool = True,
        get_retry_attempts: int = GET_RETRY_ATTEMPTS,
    ) -> None:
        if get_retry_attempts < 1:
            raise ValueError("get_retry_attempts must be at least one")
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.root_role = root_role
        self.get_retry_attempts = get_retry_attempts

    def get(self, path: str) -> tuple[Any, Mapping[str, Any]]:
        """Read one endpoint with bounded retry for safe, idempotent GETs only."""
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        # Workflow metadata on 13001 is visible through the root role.  This
        # remains an optional request header and does not change the GET-only
        # safety boundary of this exporter.
        if self.root_role:
            headers["X-Role"] = "root"
        request = urllib.request.Request(
            self.base_url + path,
            headers=headers,
            method="GET",
        )
        last_error: Exception | None = None
        raw = b""
        for attempt in range(self.get_retry_attempts):
            try:
                with urllib.request.urlopen(request, timeout=90) as response:
                    raw = response.read()
                last_error = None
                break
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode(errors="replace")[:1200]
                if exc.code < 500 or attempt + 1 >= self.get_retry_attempts:
                    raise ExportError(f"HTTP {exc.code} for {path}: {detail}") from exc
                last_error = ExportError(f"HTTP {exc.code} for {path}: {detail}")
            except (
                urllib.error.URLError,
                http.client.HTTPException,
                ConnectionError,
                TimeoutError,
            ) as exc:
                last_error = exc
                if attempt + 1 >= self.get_retry_attempts:
                    raise ExportError(
                        f"Network error for {path} after "
                        f"{self.get_retry_attempts} GET attempts: {exc}"
                    ) from exc
            # A GET has no mutation ambiguity.  Bound the backoff so a brief
            # 13001 restart or peer reset cannot discard an otherwise valid
            # local backup, while a persistent failure still returns promptly.
            time.sleep(min(2**attempt, 16))
        if last_error is not None:
            raise ExportError(
                f"Network error for {path} after "
                f"{self.get_retry_attempts} GET attempts: {last_error}"
            ) from last_error
        try:
            decoded = json.loads(raw) if raw else None
        except json.JSONDecodeError as exc:
            raise ExportError(f"Non-JSON response for {path}") from exc
        if isinstance(decoded, dict):
            if decoded.get("errors"):
                raise ExportError(f"NocoBase error for {path}: {decoded['errors']}")
            return decoded.get("data"), decoded.get("meta") or {}
        return decoded, {}

    def get_workflow(self, workflow_id: int) -> dict[str, Any]:
        query = urllib.parse.urlencode(
            [
                ("filterByTk", str(workflow_id)),
                ("appends[]", "nodes"),
                ("appends[]", "categories"),
            ]
        )
        value, _ = self.get(f"/api/workflows:get?{query}")
        if not isinstance(value, dict) or int(value.get("id") or 0) != workflow_id:
            raise ExportError(f"Workflow {workflow_id} readback is invalid")
        return value


def _json_default(value: Any) -> str:
    return str(value)


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=_json_default,
    ).encode("utf-8")


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _slug(value: Any) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "-", str(value or "untitled").strip())
    return (text.strip("-._") or "untitled")[:80]


def _safe_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _redact(value: Any, *, parent_key: str | None = None) -> Any:
    """Remove likely secrets without changing workflow shape or references."""
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for raw_key, child in value.items():
            key = str(raw_key)
            if SENSITIVE_KEY_RE.search(key):
                result[key] = "<redacted>"
            else:
                result[key] = _redact(child, parent_key=key)
        return result
    if isinstance(value, list):
        return [_redact(item, parent_key=parent_key) for item in value]
    if isinstance(value, str) and SENSITIVE_VALUE_RE.match(value.strip()):
        return "<redacted>"
    return value


def _sanitized(value: Any, *, include_sensitive_config: bool) -> Any:
    return value if include_sensitive_config else _redact(value)


def _write_private_json(path: Path, value: Any) -> str:
    """Atomically create a 0600 JSON file and return its SHA-256."""
    payload = json.dumps(value, ensure_ascii=False, indent=2, default=_json_default)
    data = (payload + "\n").encode("utf-8")
    if path.exists():
        raise ExportError(f"Refusing to overwrite existing file: {path}")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", dir=str(path.parent), text=False
    )
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, path)
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise
    return _sha256(data)


def _write_private_text(path: Path, text: str) -> str:
    if path.exists():
        raise ExportError(f"Refusing to overwrite existing file: {path}")
    data = text.encode("utf-8")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", dir=str(path.parent), text=False
    )
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, path)
    except Exception:
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise
    return _sha256(data)


def _list_pages(
    api: ReadOnlyNocoBaseApi, path: str, *, page_size: int = 100
) -> list[dict[str, Any]]:
    """Read NocoBase list pages using only GET, tolerating absent meta.count."""
    items: list[dict[str, Any]] = []
    page = 1
    while True:
        separator = "&" if "?" in path else "?"
        value, meta = api.get(f"{path}{separator}page={page}&pageSize={page_size}")
        if not isinstance(value, list):
            raise ExportError(f"List API {path} did not return an array")
        page_items = [dict(row) for row in value if isinstance(row, Mapping)]
        if len(page_items) != len(value):
            raise ExportError(f"List API {path} returned a non-object item")
        items.extend(page_items)
        count = _safe_int(meta.get("count"))
        if not page_items or len(page_items) < page_size:
            break
        if count is not None and len(items) >= count:
            break
        page += 1
        if page > 1000:
            raise ExportError(f"List API {path} pagination did not terminate")
    return items


def _category_id(api: ReadOnlyNocoBaseApi, title: str) -> int:
    rows = _list_pages(api, "/api/workflowCategories:list")
    matches = [
        row
        for row in rows
        if row.get("title") == title and _safe_int(row.get("id")) is not None
    ]
    if len(matches) != 1:
        raise ExportError(
            f"Expected exactly one workflow category titled {title!r}; "
            f"found {len(matches)}"
        )
    return int(matches[0]["id"])


def _category_ids(workflow: Mapping[str, Any]) -> set[int]:
    values = workflow.get("categories") or []
    result: set[int] = set()
    if not isinstance(values, list):
        return result
    for item in values:
        value = item.get("id") if isinstance(item, Mapping) else item
        parsed = _safe_int(value)
        if parsed is not None:
            result.add(parsed)
    return result


def _discover_category_workflow_ids(
    api: ReadOnlyNocoBaseApi, category_title: str
) -> tuple[int, list[int]]:
    """Discover category members and verify membership from full workflow GETs."""
    category_id = _category_id(api, category_title)
    summary_rows = _list_pages(api, "/api/workflows:list")
    ids: list[int] = []
    for row in summary_rows:
        workflow_id = _safe_int(row.get("id"))
        if workflow_id is None:
            continue
        # Some NocoBase versions omit many-to-many relations in list responses.
        # A detail read is slower but avoids silently omitting a workflow backup.
        full = api.get_workflow(workflow_id)
        if category_id in _category_ids(full):
            ids.append(workflow_id)
    if not ids:
        raise ExportError(
            "No workflows are attached to category "
            f"{category_title!r} (ID {category_id})"
        )
    return category_id, sorted(set(ids))


def _graph(workflow: Mapping[str, Any]) -> dict[str, Any]:
    nodes = [
        dict(node) for node in workflow.get("nodes") or [] if isinstance(node, Mapping)
    ]
    known_ids = {_safe_int(node.get("id")) for node in nodes}
    known_ids.discard(None)
    edges: list[dict[str, Any]] = []
    seen_pairs: set[tuple[int, int]] = set()
    # Prefer the child-side upstream relation because it carries branchIndex.
    # A second pass records only genuinely orphaned parent downstream links.
    for node in nodes:
        node_id = _safe_int(node.get("id"))
        upstream_id = _safe_int(node.get("upstreamId"))
        branch_index = _safe_int(node.get("branchIndex"))
        if node_id is not None and upstream_id is not None:
            pair = (upstream_id, node_id)
            if pair not in seen_pairs:
                edges.append(
                    {
                        "from_node_id": upstream_id,
                        "to_node_id": node_id,
                        "branch_index": branch_index,
                        "source": "upstreamId",
                        "reference_resolves": upstream_id in known_ids,
                    }
                )
                seen_pairs.add(pair)
    for node in nodes:
        node_id = _safe_int(node.get("id"))
        downstream_id = _safe_int(node.get("downstreamId"))
        if node_id is not None and downstream_id is not None:
            # downstreamId has no branch field.  Preserve it only when it is not
            # already represented by the child’s upstream relation.
            pair = (node_id, downstream_id)
            if pair not in seen_pairs:
                edges.append(
                    {
                        "from_node_id": node_id,
                        "to_node_id": downstream_id,
                        "branch_index": None,
                        "source": "downstreamId",
                        "reference_resolves": downstream_id in known_ids,
                    }
                )
                seen_pairs.add(pair)
    normalized_nodes = []
    for node in sorted(nodes, key=lambda item: _safe_int(item.get("id")) or 0):
        normalized_nodes.append(
            {
                "id": node.get("id"),
                "key": node.get("key"),
                "title": node.get("title"),
                "type": node.get("type"),
                "upstream_id": node.get("upstreamId"),
                "downstream_id": node.get("downstreamId"),
                "branch_index": node.get("branchIndex"),
                "config": node.get("config"),
            }
        )
    return {
        "workflow": {
            key: workflow.get(key)
            for key in (
                "id",
                "key",
                "title",
                "type",
                "sync",
                "enabled",
                "executed",
                "config",
            )
        },
        "node_count": len(normalized_nodes),
        "edge_count": len(edges),
        "nodes": normalized_nodes,
        "edges": sorted(
            edges,
            key=lambda item: (
                int(item["from_node_id"]),
                int(item["to_node_id"]),
                -1 if item["branch_index"] is None else int(item["branch_index"]),
            ),
        ),
    }


def _workflow_summary(workflow: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "id": workflow.get("id"),
        "key": workflow.get("key"),
        "title": workflow.get("title"),
        "type": workflow.get("type"),
        "sync": workflow.get("sync"),
        "enabled": workflow.get("enabled"),
        "executed": workflow.get("executed"),
        "node_count": len(workflow.get("nodes") or []),
        "category_ids": sorted(_category_ids(workflow)),
    }


def _readme(
    *,
    base_url: str,
    category_title: str,
    exported_count: int,
    redact_sensitive: bool,
    root_role: bool,
    timestamp: str,
) -> str:
    redaction = (
        "Likely secret values were redacted before writing files."
        if redact_sensitive
        else (
            "Sensitive workflow configuration was explicitly included. "
            "Protect this directory."
        )
    )
    return f"""# NocoBase API Suorce workflow backup

- Environment endpoint: `{base_url}`
- Category: `{category_title}`
- Export time (UTC): `{timestamp}`
- Exported workflows: {exported_count}
- Workflow metadata role header: `{'root' if root_role else 'not sent'}`
- {redaction}

## Contents

- `manifest.json` records the selection, compact inventory, and SHA-256 for
  every exported file.
- `workflows/*.json` contains the server-returned workflow metadata, nodes,
  connections, and node configuration.
- `workflows/*.graph.json` is a normalized graph view convenient for review.

## Safety boundary

This is a **read-only evidence backup**, not a restore tool.  It contains no
NocoBase bearer token.  Before deleting or revising any remote workflow,
compare the remote workflow ID/key and graph against this manifest, then use a
separate, approved migration script.
"""


def _make_output_dir(root: Path, stamp: str) -> Path:
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    output = root / f"13001-api-source-workflows-{stamp}"
    output.mkdir(mode=0o700, exist_ok=False)
    (output / "workflows").mkdir(mode=0o700, exist_ok=False)
    return output


def _exact_output_dir(root: Path | None) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return _make_output_dir(root or DEFAULT_OUTPUT_ROOT, stamp)


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read-only local backup of 13001 API Suorce workflows."
    )
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument(
        "--workflow-id",
        action="append",
        type=int,
        default=[],
        help="Exact workflow ID to export; repeat for more than one.",
    )
    parser.add_argument(
        "--category-title",
        default=DEFAULT_CATEGORY_TITLE,
        help="Category used when no --workflow-id is supplied (default: API Suorce).",
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
        help="Parent directory for a new private timestamped backup folder.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print selection/output plan only; make no network or filesystem changes.",
    )
    parser.add_argument(
        "--without-root-role",
        action="store_true",
        help=(
            "Do not send X-Role: root. By default this 13001 workflow export "
            "uses the root role for complete workflow metadata."
        ),
    )
    parser.add_argument(
        "--include-sensitive-config",
        action="store_true",
        help="Keep likely credential values in the local export (not the default).",
    )
    parser.add_argument(
        "--confirm-include-sensitive-config",
        help=f"Required literal confirmation: {RAW_CONFIG_CONFIRMATION}",
    )
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    if args.include_sensitive_config and (
        args.confirm_include_sensitive_config != RAW_CONFIG_CONFIRMATION
    ):
        print(
            "error=--include-sensitive-config requires "
            f"--confirm-include-sensitive-config {RAW_CONFIG_CONFIRMATION}",
            file=sys.stderr,
        )
        return 2
    selected = sorted(set(args.workflow_id))
    selection = (
        {"mode": "explicit_ids", "workflow_ids": selected}
        if selected
        else {"mode": "category", "category_title": args.category_title}
    )
    if args.dry_run:
        print(
            json.dumps(
                {
                    "writes_remote": False,
                    "writes_local": False,
                    "base_url": args.base_url.rstrip("/"),
                    "selection": selection,
                    "planned_output_root": str(args.output_root),
                    "redact_sensitive_config": not args.include_sensitive_config,
                    "root_role": not args.without_root_role,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required for read-only export", file=sys.stderr)
        return 2
    api = ReadOnlyNocoBaseApi(
        args.base_url,
        token,
        root_role=not args.without_root_role,
    )
    try:
        category_id: int | None = None
        if not selected:
            category_id, selected = _discover_category_workflow_ids(
                api, args.category_title
            )
        workflows = [api.get_workflow(workflow_id) for workflow_id in selected]
        # The remote inventory has been read before the new local directory is
        # created, so an auth/API failure never leaves a misleading partial backup.
        output = _exact_output_dir(args.output_root)
        files: list[dict[str, Any]] = []
        inventory: list[dict[str, Any]] = []
        for workflow in workflows:
            safe_workflow = _sanitized(
                workflow, include_sensitive_config=args.include_sensitive_config
            )
            safe_graph = _sanitized(
                _graph(workflow), include_sensitive_config=args.include_sensitive_config
            )
            workflow_id = int(workflow["id"])
            stem = f"{workflow_id}--{_slug(workflow.get('title'))}"
            raw_path = output / "workflows" / f"{stem}.json"
            graph_path = output / "workflows" / f"{stem}.graph.json"
            files.append(
                {
                    "path": str(raw_path.relative_to(output)),
                    "sha256": _write_private_json(raw_path, safe_workflow),
                }
            )
            files.append(
                {
                    "path": str(graph_path.relative_to(output)),
                    "sha256": _write_private_json(graph_path, safe_graph),
                }
            )
            inventory.append(_workflow_summary(workflow))
        timestamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        readme_path = output / "README.md"
        files.append(
            {
                "path": "README.md",
                "sha256": _write_private_text(
                    readme_path,
                    _readme(
                        base_url=args.base_url.rstrip("/"),
                        category_title=args.category_title,
                        exported_count=len(workflows),
                        redact_sensitive=not args.include_sensitive_config,
                        root_role=not args.without_root_role,
                        timestamp=timestamp,
                    ),
                ),
            }
        )
        manifest = {
            "format": "nocobase-api-source-workflow-backup/v1",
            "environment": "13001",
            "exported_at_utc": timestamp,
            "base_url": args.base_url.rstrip("/"),
            "selection": selection,
            "category_id": category_id,
            "redact_sensitive_config": not args.include_sensitive_config,
            "root_role": not args.without_root_role,
            "workflow_count": len(workflows),
            "workflows": sorted(inventory, key=lambda item: int(item["id"])),
            "files": sorted(files, key=lambda item: str(item["path"])),
            "remote_write_operations": 0,
        }
        _write_private_json(output / "manifest.json", manifest)
    except ExportError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1
    print(
        json.dumps(
            {
                "writes_remote": False,
                "remote_write_operations": 0,
                "backup_dir": str(output),
                "manifest": str(output / "manifest.json"),
                "workflow_count": len(workflows),
                "workflow_ids": [workflow.get("id") for workflow in workflows],
                "redact_sensitive_config": not args.include_sensitive_config,
                "root_role": not args.without_root_role,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
