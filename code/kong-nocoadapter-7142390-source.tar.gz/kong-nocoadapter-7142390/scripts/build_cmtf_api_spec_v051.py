#!/usr/bin/env python3
"""Build CMTF-II API Specification v0.51 and the request-field Excel."""

from __future__ import annotations

import json
import shutil
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

SPEC_DIR = Path(
    "/Users/work/NCSI-CM-Documents/SI&I/Interfaces/API Specification"
)
REPO_DELIVERABLES = Path("/Users/work/noco/kong-nocoadapter/deliverables")
SOURCE_COMMENTS = SPEC_DIR / "CMTF-II API Specification v0.5 (Daniel Comments).docx"
TODAY = date(2026, 9, 14)
AUTHOR = "Gregory Lee"
VERSION = "v0.51"
BASE_URL = "https://119.91.104.211"
ADAPTER = "0.18.0"

LIVE_CREATE_IDS = {
    "nla": "386601020882944",
    "chi": "386601025077273",
    "sw": "386601027174468",
    "rev": "386601031368711",
    "sh": "386601035563021",
    "rp": "386601037660186",
    "mgr": "386601039757359",
    "beds": "386601043951633",
    "mode": "386601046048815",
    "dir": "386601050243102",
    "nurse": "386601054437376",
    "pro": "386601056534550",
    "lrn": "386601058631729",
}

CASE_NLA = {
    "office_code": "LORCHE",
    "submitter_user_id": 1,
    "task_owner_user_id": 45,
    "task_owner_post_code": "S(LR)1",
}
CASE_HOME = {
    **CASE_NLA,
    "lorche_d_no": "L0043",
}
CASE_PNO = {
    **CASE_NLA,
    "p_no": "PE0177",
}


def dump(obj: object) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


NLA_CREATE = {
    "request_id": "NLA-20260914-0001",
    "form_data": {
        "case_summary": CASE_NLA,
        "part_1": {
            "application_received_date": "2026-09-14",
            "tentative_commencement_date": "2026-12-01",
        },
        "part_2": {
            "rch_name_en": "Example RCH",
            "rch_name_cn": "示例院舍",
            "operation_mode_id": 1,
            "premises_type": "0",
            "monthly_fee_min": 8000,
            "monthly_fee_max": 12000,
            "gender": "1",
            "floor_area_sqm": 380.5,
            "licence_capacity": 48,
            "rch_type_code": "a1",
            "nursing_home_places": 12,
            "care_and_attention_home_places": 12,
            "aged_home_places": 12,
            "self_care_hostel_places": 12,
            "address": {
                "region_code": "0",
                "district_code": "C",
                "sub_district_code": "Admiralty",
            },
            "premises": {"self_owned": [], "rented": []},
        },
        "part_3": {
            "rch_business_status": "0",
            "applicant_operator_type": "0",
        },
        "part_5": {"application_level": "normal"},
    },
}
CHI_CREATE = {
    "request_id": "CHI-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "is_change_name": True,
        "part_2": {"rch_name_en": "Updated Name"},
        "part_5": {"comments": "CHI create"},
    },
}
SW_CREATE = {
    "request_id": "SW-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "reason_for_closure": "0",
        "comments": "Self-withdraw",
    },
}
REV_CREATE = {
    "request_id": "REV-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "type_of_closure": "cancellation",
        "comments": "Revoke",
    },
}
SH_CREATE = {
    "request_id": "SH-20260914-0001",
    "form_data": {
        "case_summary": CASE_PNO,
        "application_detail": "approval",
        "certificate_name_en": "Example Cert",
        "comments": "Specific hour",
    },
}
RP_CREATE = {
    "request_id": "RP-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "rp_name_en": "Example RP",
        "rp_address_en": "1 Example Street",
        "comments": "RP create",
    },
}
MGR_CREATE = {
    "request_id": "CHG-MGR-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "proposed_name": "Example Manager",
        "comments": "Change home manager",
    },
}
BEDS_CREATE = {
    "request_id": "CHG-BEDS-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "proposed_beds_nursing": 10,
        "comments": "Change beds",
    },
}
MODE_CREATE = {
    "request_id": "CHG-MODE-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "proposed_rch_nature_code": "a1",
        "comments": "Change operation mode",
    },
}
DIR_CREATE = {
    "request_id": "CHG-DIR-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "name_en": "Example Director",
        "comments": "Change directors",
    },
}
NURSE_CREATE = {
    "request_id": "CHG-NURSE-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "name": "Example Nurse",
        "person_type": "home_manager",
        "comments": "Change nurse in charge",
    },
}
PRO_CREATE = {
    "request_id": "PRO-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "legal_advice_result": "Go for Prosecution",
        "comments": "Prosecution",
        "offence_items": [
            {
                "name_of_defendant": "Example Defendant",
                "type_of_defendant": "Natural Person",
            }
        ],
    },
}
LRN_CREATE = {
    "request_id": "LRN-20260914-0001",
    "form_data": {
        "case_summary": CASE_HOME,
        "part_5": {"comments": "Renewal skeleton"},
    },
}


def update_body(request_id: str, create_id: str, form_data: dict) -> dict:
    return {
        "request_id": request_id,
        "create_id": create_id,
        "form_data": form_data,
    }


def accepted_response(create_id: str, api_type: str, event: str = "CREATE") -> dict:
    body = {
        "accepted": True,
        "request_id": "example",
        "create_id": create_id,
        "status": "Accepted",
        "source_system": "OP",
        "request_event": event,
        "api_type": api_type,
        "intake_id": None,
        "application_id": None,
        "message": "Request submitted",
        "message_zh": "请求已提交",
    }
    if event == "CREATE":
        body["request_id"] = api_type.replace("create_intake_for_", "").upper()
    return body


APIS = [
    {
        "id": "CMTFII-API-0001",
        "group": "Authentication and security",
        "name": "Get Token",
        "method": "POST",
        "path": "/v1/auth/token",
        "auth": "None. Kong adds X-Authenticator: basic",
        "fields": [
            ("email", "body", "Yes", "string", "Login email"),
            ("password", "body", "Yes", "string", "Password"),
        ],
        "example": {"email": "<account-email>", "password": "<password>"},
        "notes": "Returns a NocoBase native token. Live 211: HTTP 200.",
    },
    {
        "id": "CMTFII-API-0011",
        "group": "Health and operational APIs",
        "name": "Health Live",
        "method": "GET",
        "path": "/health/live",
        "auth": "None",
        "fields": [],
        "example": None,
        "notes": "Liveness probe. No body.",
    },
    {
        "id": "CMTFII-API-0012",
        "group": "Health and operational APIs",
        "name": "Health Ready",
        "method": "GET",
        "path": "/health/ready",
        "auth": "None",
        "fields": [],
        "example": None,
        "notes": f"Readiness probe. Live 211 returns adapterVersion {ADAPTER}.",
    },
    {
        "id": "CMTFII-API-0021",
        "group": "File services",
        "name": "Upload File",
        "method": "POST",
        "path": "/v1/files",
        "auth": "Bearer",
        "fields": [
            ("file", "form", "Yes", "file", "Binary file, not Base64"),
            ("externalRequestId", "form", "No", "string", "Client trace id"),
            ("sha256", "form", "No", "string", "64-hex digest"),
        ],
        "example": None,
        "notes": "multipart/form-data. Success returns data_id, filename, size, download_url.",
    },
    {
        "id": "CMTFII-API-0022",
        "group": "File services",
        "name": "Download File",
        "method": "GET",
        "path": "/v1/files/{attachment_id}",
        "auth": "Bearer",
        "fields": [
            ("attachment_id", "path", "Yes", "int", "Attachment id from upload data_id"),
        ],
        "example": None,
        "notes": "Stream the file through the gateway.",
    },
    {
        "id": "CMTFII-API-0023",
        "group": "File services",
        "name": "Home Record Query",
        "method": "POST",
        "path": "/homerecord-query",
        "auth": "Bearer",
        "fields": [
            ("officeCode", "query", "No", "string", "LORCHE / LORCHD"),
            ("rchStatus", "query", "No", "string", "Status filter"),
            ("rchNo", "query", "No", "string", "RCH no, e.g. L0043"),
        ],
        "example": None,
        "notes": "Live 211 with L0043 returned HTTP 200 and 1 home record.",
    },
    {
        "id": "CMTFII-API-0024",
        "group": "Health and operational APIs",
        "name": "Simple Test",
        "method": "POST",
        "path": "/simple-test",
        "auth": "Bearer",
        "fields": [],
        "example": {},
        "notes": "Connectivity test. No required body.",
    },
    {
        "id": "CMTFII-API-1001",
        "group": "New Licence Applications",
        "name": "Query New Licence Checklist",
        "method": "GET",
        "path": "/v1/new-licence-checklist",
        "auth": "Bearer",
        "fields": [
            ("office_code", "query", "Yes", "string", "LORCHE or LORCHD"),
        ],
        "example": None,
        "notes": "Live 211: 69 items. Client maps each item by position_code.",
    },
    {
        "id": "CMTFII-API-1002",
        "group": "New Licence Applications",
        "name": "Create Intake for New Licence",
        "method": "POST",
        "path": "/v1/create_intake_for_new_licence",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "NLA case_summary, no RCH no"),
            ("form_data.part_1", "body", "Yes", "object", "Dates"),
            ("form_data.part_2", "body", "Yes", "object", "RCH particulars and address"),
            ("form_data.part_3", "body", "Yes", "object", "Operator / company"),
            ("form_data.part_4", "body", "No", "object", "Authorised representative"),
            ("form_data.part_5", "body", "Yes", "object", "application_level required"),
        ],
        "example": NLA_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['nla']}. Immediate status Accepted.",
    },
    {
        "id": "CMTFII-API-1003",
        "group": "New Licence Applications",
        "name": "Update New Licence Data",
        "method": "POST",
        "path": "/v1/update_new_licence_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id from Create"),
            ("form_data", "body", "Yes", "object", "At least one changed field"),
        ],
        "example": update_body(
            "NLA-UPDATE-0001",
            LIVE_CREATE_IDS["nla"],
            {"part_5": {"comments": "Updated through API"}},
        ),
        "notes": "Allowed only while mapped business status is Submitted.",
    },
    {
        "id": "CMTFII-API-1901",
        "group": "Application query",
        "name": "Query Request by Create ID",
        "method": "GET",
        "path": "/v1/request/{create_id}",
        "auth": "Bearer",
        "fields": [
            ("create_id", "path", "Yes", "string", "Create Staging id"),
        ],
        "example": None,
        "notes": "Works for OP Create and CMTF-initiated applications. Live 211: after ~12s all 13 creates returned Submitted with application data.",
    },
    {
        "id": "CMTFII-API-1902",
        "group": "Application query",
        "name": "Query Staging Record",
        "method": "GET",
        "path": "/v1/requests/{record_id}",
        "auth": "Bearer",
        "fields": [
            ("record_id", "path", "Yes", "string", "Staging record id"),
        ],
        "example": None,
        "notes": "Internal processing status. Not the public business lookup.",
    },
    {
        "id": "CMTFII-API-1903",
        "group": "Application query",
        "name": "List Intakes",
        "method": "GET",
        "path": "/v1/intakes",
        "auth": "Bearer",
        "fields": [
            ("office_code", "query", "No", "string", "Filter"),
            ("status", "query", "No", "string", "Filter"),
            ("intake_id", "query", "No", "string", "Filter"),
            ("application_id", "query", "No", "string", "Filter"),
            ("page", "query", "No", "int", "Page"),
            ("page_size", "query", "No", "int", "Page size"),
        ],
        "example": None,
        "notes": "Live 211: HTTP 200.",
    },
    {
        "id": "CMTFII-API-1904",
        "group": "Application query",
        "name": "List New Licence Applications",
        "method": "GET",
        "path": "/v1/new-licence-applications",
        "auth": "Bearer",
        "fields": [
            ("office_code", "query", "No", "string", "Filter"),
            ("status", "query", "No", "string", "Filter"),
            ("page", "query", "No", "int", "Page"),
            ("page_size", "query", "No", "int", "Page size"),
        ],
        "example": None,
        "notes": "Optional list view. Public lookup key remains create_id.",
    },
    {
        "id": "CMTFII-API-2001",
        "group": "Changing Home",
        "name": "Query Changing Home Checklist",
        "method": "GET",
        "path": "/v1/changing-home-checklist",
        "auth": "Bearer",
        "fields": [("office_code", "query", "Yes", "string", "LORCHE or LORCHD")],
        "example": None,
        "notes": "Live 211: 69 items. Map by position_code.",
    },
    {
        "id": "CMTFII-API-2002",
        "group": "Changing Home",
        "name": "Create Intake for Changing Home",
        "method": "POST",
        "path": "/v1/create_intake_for_changing_home",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Must include lorche_d_no or p_no"),
            ("form_data.is_change_name", "body", "One of five", "bool", "Change name"),
            ("form_data.is_change_address", "body", "One of five", "bool", "Change address"),
            ("form_data.is_change_operator_or_operating_company", "body", "One of five", "bool", "Change operator"),
            ("form_data.is_change_rch_type", "body", "One of five", "bool", "Change RCH type"),
            ("form_data.is_change_maximum_capacity", "body", "One of five", "bool", "Change capacity"),
            ("form_data.part_5.comments", "body", "No", "string", "CHI has no top-level comments"),
        ],
        "example": CHI_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['chi']}.",
    },
    {
        "id": "CMTFII-API-2003",
        "group": "Changing Home",
        "name": "Update Changing Home Data",
        "method": "POST",
        "path": "/v1/update_changing_home_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data.part_5.comments", "body", "If changing comments", "string", "Must be part_5, not top-level"),
        ],
        "example": update_body(
            "CHI-UPDATE-0001",
            LIVE_CREATE_IDS["chi"],
            {"part_5": {"comments": "Updated through API"}},
        ),
        "notes": "Live 211 CHI Update returned 200 Accepted.",
    },
    {
        "id": "CMTFII-API-2101",
        "group": "Closure",
        "name": "Query Self-withdraw Checklist",
        "method": "GET",
        "path": "/v1/self-withdraw-checklist",
        "auth": "Bearer",
        "fields": [("office_code", "query", "Yes", "string", "LORCHE or LORCHD")],
        "example": None,
        "notes": "Live 211: 4 items.",
    },
    {
        "id": "CMTFII-API-2102",
        "group": "Closure",
        "name": "Create Intake for Self-withdraw",
        "method": "POST",
        "path": "/v1/create_intake_for_self_withdraw",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.reason_for_closure", "body", "No", "string", "0 / 1 / others"),
            ("form_data.comments", "body", "No", "string", "Remarks"),
            ("form_data.checklist", "body", "No", "array", "position_code + attachment_id"),
        ],
        "example": SW_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['sw']}.",
    },
    {
        "id": "CMTFII-API-2103",
        "group": "Closure",
        "name": "Update Self-withdraw Data",
        "method": "POST",
        "path": "/v1/update_self_withdraw_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field; comments is top-level"),
        ],
        "example": update_body(
            "SW-UPDATE-0001", LIVE_CREATE_IDS["sw"], {"comments": "Updated through API"}
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2104",
        "group": "Closure",
        "name": "Create Intake for Revoke Licence",
        "method": "POST",
        "path": "/v1/create_intake_for_revoke_licence",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.type_of_closure", "body", "No", "string", "refusal_to_renew / cancellation / suspension / amendment_or_variation_of_conditions"),
            ("form_data.comments", "body", "No", "string", "Remarks"),
        ],
        "example": REV_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['rev']}.",
    },
    {
        "id": "CMTFII-API-2105",
        "group": "Closure",
        "name": "Update Revoke Licence Data",
        "method": "POST",
        "path": "/v1/update_revoke_licence_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one changed field"),
        ],
        "example": update_body(
            "REV-UPDATE-0001", LIVE_CREATE_IDS["rev"], {"comments": "Updated through API"}
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2201",
        "group": "Specific Hour",
        "name": "Query Specific Hour Checklist",
        "method": "GET",
        "path": "/v1/specific-hour-checklist",
        "auth": "Bearer",
        "fields": [("office_code", "query", "Yes", "string", "LORCHE or LORCHD")],
        "example": None,
        "notes": "Live 211: 6 items.",
    },
    {
        "id": "CMTFII-API-2202",
        "group": "Specific Hour",
        "name": "Create Intake for Specific Hour",
        "method": "POST",
        "path": "/v1/create_intake_for_specific_hour",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "lorche_d_no or p_no"),
            ("form_data.application_detail", "body", "No", "string", "approval / changing"),
            ("form_data.certificate_name_en", "body", "No", "string", "Certificate English name"),
            ("form_data.comments", "body", "No", "string", "Remarks"),
        ],
        "example": SH_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['sh']}. p_no PE0177 accepted.",
    },
    {
        "id": "CMTFII-API-2203",
        "group": "Specific Hour",
        "name": "Update Specific Hour Data",
        "method": "POST",
        "path": "/v1/update_specific_hour_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "SH-UPDATE-0001", LIVE_CREATE_IDS["sh"], {"comments": "Updated through API"}
        ),
        "notes": "Live 211 SH Update returned 200 Accepted.",
    },
    {
        "id": "CMTFII-API-2301",
        "group": "Responsible Person",
        "name": "Query RP Checklist",
        "method": "GET",
        "path": "/v1/rp-checklist",
        "auth": "Bearer",
        "fields": [("office_code", "query", "Yes", "string", "LORCHE or LORCHD")],
        "example": None,
        "notes": "Live 211: 4 items.",
    },
    {
        "id": "CMTFII-API-2302",
        "group": "Responsible Person",
        "name": "Create Intake for RP",
        "method": "POST",
        "path": "/v1/create_intake_for_rp",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.rp_name_en", "body", "No", "string", "RP English name"),
            ("form_data.rp_address_en", "body", "No", "string", "RP address"),
            ("form_data.rp_position_type", "body", "No", "string", "Live spelling: dody_corporate / non_governmental_rganisation / rche/rche（nh）"),
            ("form_data.comments", "body", "No", "string", "Remarks"),
        ],
        "example": RP_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['rp']}.",
    },
    {
        "id": "CMTFII-API-2303",
        "group": "Responsible Person",
        "name": "Update RP Data",
        "method": "POST",
        "path": "/v1/update_rp_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "RP-UPDATE-0001", LIVE_CREATE_IDS["rp"], {"comments": "Updated through API"}
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2401",
        "group": "Change Monitoring",
        "name": "Create Change Home Manager",
        "method": "POST",
        "path": "/v1/create_intake_for_change_home_manager",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.proposed_name", "body", "No", "string", "Proposed manager name"),
            ("form_data.comments", "body", "No", "string", "Remarks"),
        ],
        "example": MGR_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['mgr']}.",
    },
    {
        "id": "CMTFII-API-2402",
        "group": "Change Monitoring",
        "name": "Update Change Home Manager",
        "method": "POST",
        "path": "/v1/update_change_home_manager_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "CHG-MGR-UPDATE-0001",
            LIVE_CREATE_IDS["mgr"],
            {"comments": "Updated through API"},
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2403",
        "group": "Change Monitoring",
        "name": "Create Change Beds",
        "method": "POST",
        "path": "/v1/create_intake_for_change_beds",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.proposed_beds_*", "body", "No", "int", "Proposed bed counts"),
            ("form_data.proposed_residents_*", "body", "No", "int", "Proposed resident counts"),
        ],
        "example": BEDS_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['beds']}.",
    },
    {
        "id": "CMTFII-API-2404",
        "group": "Change Monitoring",
        "name": "Update Change Beds",
        "method": "POST",
        "path": "/v1/update_change_beds_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "CHG-BEDS-UPDATE-0001",
            LIVE_CREATE_IDS["beds"],
            {"comments": "Updated through API"},
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2405",
        "group": "Change Monitoring",
        "name": "Create Change Operation Mode",
        "method": "POST",
        "path": "/v1/create_intake_for_change_operation_mode",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.proposed_rch_nature_code", "body", "No", "string", "Proposed nature code"),
        ],
        "example": MODE_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['mode']}.",
    },
    {
        "id": "CMTFII-API-2406",
        "group": "Change Monitoring",
        "name": "Update Change Operation Mode",
        "method": "POST",
        "path": "/v1/update_change_operation_mode_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "CHG-MODE-UPDATE-0001",
            LIVE_CREATE_IDS["mode"],
            {"comments": "Updated through API"},
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2407",
        "group": "Change Monitoring",
        "name": "Create Change Directors",
        "method": "POST",
        "path": "/v1/create_intake_for_change_directors",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.title", "body", "No", "string", "0-4"),
            ("form_data.name_en", "body", "No", "string", "Director English name"),
        ],
        "example": DIR_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['dir']}.",
    },
    {
        "id": "CMTFII-API-2408",
        "group": "Change Monitoring",
        "name": "Update Change Directors",
        "method": "POST",
        "path": "/v1/update_change_directors_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "CHG-DIR-UPDATE-0001",
            LIVE_CREATE_IDS["dir"],
            {"comments": "Updated through API"},
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2409",
        "group": "Change Monitoring",
        "name": "Create Change Nurse in Charge",
        "method": "POST",
        "path": "/v1/create_intake_for_change_nurse_in_charge",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.name", "body", "No", "string", "Person name"),
            ("form_data.person_type", "body", "No", "string", "director / home_manager / responsible_person"),
        ],
        "example": NURSE_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['nurse']}.",
    },
    {
        "id": "CMTFII-API-2410",
        "group": "Change Monitoring",
        "name": "Update Change Nurse in Charge",
        "method": "POST",
        "path": "/v1/update_change_nurse_in_charge_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "CHG-NURSE-UPDATE-0001",
            LIVE_CREATE_IDS["nurse"],
            {"comments": "Updated through API"},
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2501",
        "group": "Prosecution",
        "name": "Create Intake for Prosecution",
        "method": "POST",
        "path": "/v1/create_intake_for_prosecution",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.legal_advice_result", "body", "No", "string", "Go for Prosecution / Not Go for Prosecution"),
            ("form_data.offence_items", "body", "No", "array", "Defendants and charges"),
            ("form_data.comments", "body", "No", "string", "Remarks"),
        ],
        "example": PRO_CREATE,
        "notes": f"Live 211 create_id {LIVE_CREATE_IDS['pro']}.",
    },
    {
        "id": "CMTFII-API-2502",
        "group": "Prosecution",
        "name": "Update Prosecution Data",
        "method": "POST",
        "path": "/v1/update_prosecution_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "PRO-UPDATE-0001", LIVE_CREATE_IDS["pro"], {"comments": "Updated through API"}
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-2601",
        "group": "Licence Renewal",
        "name": "Query Licence Renewal Checklist",
        "method": "GET",
        "path": "/v1/licence-renewal-checklist",
        "auth": "Bearer",
        "fields": [("office_code", "query", "Yes", "string", "LORCHE or LORCHD")],
        "example": None,
        "notes": "Live 211: 69 items.",
    },
    {
        "id": "CMTFII-API-2602",
        "group": "Licence Renewal",
        "name": "Create Licence Renewal",
        "method": "POST",
        "path": "/v1/create_licence_renewal",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("form_data.case_summary", "body", "Yes", "object", "Home-bound case_summary"),
            ("form_data.part_1 to part_5", "body", "No", "object", "NLA-shaped optional sections; unlisted fields ignored"),
        ],
        "example": LRN_CREATE,
        "notes": f"No Intake. Live 211 create_id {LIVE_CREATE_IDS['lrn']}. CMTF-created renewal can be updated by OP.",
    },
    {
        "id": "CMTFII-API-2603",
        "group": "Licence Renewal",
        "name": "Update Licence Renewal Data",
        "method": "POST",
        "path": "/v1/update_licence_renewal_data",
        "auth": "Bearer",
        "fields": [
            ("request_id", "body", "Yes", "string", "Client request id"),
            ("create_id", "body", "Yes", "string", "Staging id"),
            ("form_data", "body", "Yes", "object", "At least one field"),
        ],
        "example": update_body(
            "LRN-UPDATE-0001",
            LIVE_CREATE_IDS["lrn"],
            {"part_5": {"comments": "Updated through API"}},
        ),
        "notes": "",
    },
    {
        "id": "CMTFII-API-9001",
        "group": "Outbound APIs",
        "name": "Business Status Notification",
        "method": "POST",
        "path": "{CLIENT_CALLBACK_HOST}/v1/business-status-notifications",
        "auth": "Client-defined",
        "fields": [
            ("create_id", "body", "Yes", "string", "Stable public id. May be unprecedented if CMTF-II initiated the application"),
            ("status", "body", "Yes", "string", "Outgoing business status"),
        ],
        "example": {"create_id": LIVE_CREATE_IDS["nla"], "status": "Received"},
        "notes": "Client must reply for every status. Receiver status is Accepted. Retry includes HTTP 500. Query API is still required even when Create was not called by the client.",
    },
]


SHARED_FIELDS = [
    ("case_summary.office_code", "Yes", "string", "LORCHE / LORCHD"),
    ("case_summary.submitter_user_id", "Yes", "id", "Submitter NocoBase user id"),
    ("case_summary.task_owner_user_id", "Yes", "id", "Intake Officer user id"),
    ("case_summary.task_owner_post_code", "Yes", "string", "Post code, e.g. S(LR)1"),
    ("case_summary.received_date", "No", "date", "YYYY-MM-DD"),
    ("case_summary.severity", "No", "enum", "Severity option"),
    ("case_summary.source_id", "No", "id", "Source option id"),
    ("case_summary.source_other", "No", "string", "Other source text"),
    ("case_summary.lorche_d_no", "Home-bound: one of two", "string", "RCH no → t_home_record.f_rch_no. Do not send on NLA."),
    ("case_summary.p_no", "Home-bound: one of two", "string", "P no → t_home_record.f_final_o_no. Do not send on NLA."),
    ("address.region_code", "Create Yes", "string", "Region code"),
    ("address.district_code", "Create Yes", "string", "District code"),
    ("address.sub_district_code", "Create Yes", "string", "Sub-district / street code"),
    ("address.full_name_en / full_name_cn", "No", "string", "Full address"),
    ("checklist[].position_code", "Yes", "string", "Stable item type key from checklist GET"),
    ("checklist[].checked", "No, default true", "bool", "Checked"),
    ("checklist[].status", "No, default 1", "string", "1-5"),
    ("checklist[].attachment_id", "If item submitted", "int", "Upload File data_id"),
    ("checklist[].remarks", "No", "string", "Remarks"),
]


def shade(cell, hex_color: str) -> None:
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = tcPr.makeelement(
        qn("w:shd"),
        {
            qn("w:val"): "clear",
            qn("w:color"): "auto",
            qn("w:fill"): hex_color,
        },
    )
    tcPr.append(shd)


def set_run_font(run, *, size=11, bold=False, color=None, name="Calibri"):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "PMingLiU")
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def add_para(doc, text, *, style=None, size=11, bold=False, space_after=8):
    p = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    run = p.add_run(text)
    set_run_font(run, size=size, bold=bold)
    p.paragraph_format.space_after = Pt(space_after)
    return p


def add_table(doc, headers, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ""
        run = cell.paragraphs[0].add_run(h)
        set_run_font(run, size=10, bold=True, color="FFFFFF")
        shade(cell, "1F4E79")
    for r, row in enumerate(rows, start=1):
        for c, value in enumerate(row):
            cell = table.rows[r].cells[c]
            cell.text = ""
            run = cell.paragraphs[0].add_run(str(value))
            set_run_font(run, size=10)
            if r % 2 == 0:
                shade(cell, "F2F2F2")
    doc.add_paragraph()
    return table


def add_code(doc, text: str) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_run_font(run, size=9, name="Consolas")
    p.paragraph_format.space_after = Pt(10)
    shade_p = p._p.get_or_add_pPr()
    # keep as plain monospace block


def heading(doc, text, level: int) -> None:
    doc.add_heading(text, level=level)


def build_word(path: Path) -> None:
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("Application Services API Specification")
    set_run_font(run, size=22, bold=True)
    for line in [
        "for",
        "Redevelopment of",
        "Case Management cum Tracking Facility (“CMTF”)",
        "for the",
        "Social Welfare Department",
        "CMTF-II API Specification v0.51",
        "14 September 2026",
    ]:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(line)
        set_run_font(run, size=14 if "v0.51" in line else 12, bold="v0.51" in line)

    add_para(
        doc,
        "This version is copied from CMTF-II API Specification v0.5 (Daniel Comments) "
        "and revised against the review comments plus the Adapter 0.18.0 live contract "
        f"on {BASE_URL}.",
        size=11,
    )

    heading(doc, "1. Amendment History", 1)
    add_table(
        doc,
        ["Version", "Revision Description", "Section Affected", "Date", "By"],
        [
            ["v0.1", "Init version", "All", "14 Aug 2026", "Ben Fan"],
            ["v0.2", "Corrected format and answered ISTB comments", "All", "19 Aug 2026", "Ben Fan"],
            ["v0.3", "Updated table format and added API specifications", "All", "—", "Ben Fan"],
            ["v0.4 / v0.5", "NLA Create / Update / Query contract", "API Specification", "Sep 2026", "Ben Fan / Daniel Suen"],
            [
                "v0.51",
                "Apply Daniel Suen review comments; rename API return status submitted → Accepted; "
                "generic multi-application scope; new API numbering; add CHI / Closure / SH / RP / "
                "Change / Prosecution / Renewal APIs verified on Adapter 0.18.0 (211).",
                "All",
                "14 Sep 2026",
                AUTHOR,
            ],
        ],
    )

    heading(doc, "2. How to Use This Specification", 1)
    add_para(
        doc,
        "This specification describes the external CMTF-II application services API. "
        "It is not limited to New Licence Applications. Each application type has its "
        "own Create, Update and where applicable Checklist query. One Query-by-create_id "
        "interface serves all application types.",
    )
    add_para(
        doc,
        "Unknown JSON fields are rejected with HTTP 422. Clients must send only documented fields. "
        f"Base URL for the current online environment: {BASE_URL}. Adapter version: {ADAPTER}.",
    )

    heading(doc, "3. Overview", 1)
    heading(doc, "3.1 Interface Overview", 2)
    add_para(
        doc,
        "Current released application types: New Licence, Changing Home, Self-withdraw, "
        "Revoke Licence, Specific Hour, Responsible Person, Change Home Manager / Beds / "
        "Operation Mode / Directors / Nurse in Charge, Prosecution, and Licence Renewal. "
        "Create writes t_api_request_staging and returns immediately. NocoBase workflows "
        "create the business records asynchronously.",
    )
    heading(doc, "3.2 Request Identifiers", 2)
    add_para(
        doc,
        "create_id is the only public lookup key. It is the Staging record ID returned by Create. "
        "intake_id and application_id are informational. Create/Update immediate responses return "
        "them as null; the client loads them later from GET /v1/request/{create_id}. "
        "They must not replace create_id.",
    )
    heading(doc, "3.3 API Numbering Convention", 2)
    add_table(
        doc,
        ["Range", "Category"],
        [
            ["0000–0010", "Authentication and security"],
            ["0011–0020", "Health and operational APIs"],
            ["0021–0030", "File services and supporting lookups"],
            ["1000–8000", "Application-specific APIs"],
            ["9000–9999", "Outbound APIs"],
        ],
    )
    add_para(
        doc,
        "API IDs appear in each interface heading. The complete list is in Section 5 and in the table of contents.",
    )

    heading(doc, "4. Business Status Notification", 1)
    heading(doc, "4.1 Notification Payload", 2)
    add_para(
        doc,
        "Body is create_id + status. The client must expect unprecedented create_id values "
        "because CMTF-II may initiate an application itself. The client still uses that "
        "create_id with GET /v1/request/{create_id}. Query remains mandatory even when the "
        "client never called Create Intake.",
    )
    heading(doc, "4.2 Business Status Mapping", 2)
    add_table(
        doc,
        ["Status", "Meaning", "Update allowed", "Resource path client might need"],
        [
            ["Submitted", "Initial mapped business stage after Create is accepted", "Yes", "GET /v1/request/{create_id}"],
            ["Received", "Outgoing workflow status after SWIT/SWO confirmed recommend proceed", "No", "GET /v1/request/{create_id}"],
            ["P_Number_Generated", "Licence number generated where applicable", "No", "application_data"],
            ["Acknowledged", "Acknowledgement letter sent", "No", "letter_attachments"],
            ["Confirmed", "Confirmation letter sent", "No", "letter_attachments"],
            ["Reminding", "Reminder issued; may repeat", "No", "letter_attachments"],
            ["Approved", "Application approved", "No", "application_data"],
            ["Rejected", "Application rejected (generic outgoing status, not NLA-only)", "No", "application_data"],
        ],
    )
    add_para(
        doc,
        "Every outgoing status requires a receiver reply. There is no separate Notification column. "
        "Received is not the Create API response. After Received, Update is locked. "
        "The lock uses server-side status, not callback delivery. HTTP 409 code update_locked.",
    )
    heading(doc, "4.3 Receiver Response", 2)
    add_para(
        doc,
        "The client acknowledges a notification with status Accepted.",
    )
    add_code(
        doc,
        dump({"status": "Accepted", "create_id": LIVE_CREATE_IDS["nla"]}),
    )
    heading(doc, "4.4 Delivery and Duplicate Handling", 2)
    add_para(
        doc,
        "Any 2xx response means accepted. Most 4xx responses and HTTP 500 are retried. "
        "Duplicate deliveries with the same create_id + status must be treated as idempotent.",
    )

    heading(doc, "5. Common Request Objects", 1)
    heading(doc, "5.1 case_summary", 2)
    add_table(
        doc,
        ["Field", "Required", "Description"],
        [
            ["office_code", "Yes", "LORCHE / LORCHD"],
            ["submitter_user_id", "Yes", "Business submitter; may differ from token owner"],
            ["task_owner_user_id", "Yes", "Intake Officer"],
            ["task_owner_post_code", "Yes", "Post code, e.g. S(LR)1"],
            ["lorche_d_no / p_no", "Home-bound only; at least one", "RCH no or Final P No. NLA must not send these."],
        ],
    )
    heading(doc, "5.2 Checklist mapping", 2)
    add_para(
        doc,
        "Call the application-specific checklist GET first. Each item has position_code, name_en, "
        "name_cn and required. position_code is the stable type key for client mapping. "
        "Do not map by database id, display name or section path. When submitting files, send "
        "position_code + attachment_id from Upload File.",
    )
    heading(doc, "5.3 Letter attachments", 2)
    add_para(
        doc,
        "Query returns letter_attachments[] as sent-letter records. Each record has letter_id, "
        "letter_type (a–f), send_time and attachments[]. letter_attachments[] is the letter; "
        "letter_attachments[].attachments[] are the generated files. Draft or file-less records "
        "are excluded. Types: a Acknowledgement, b Confirmation, c Cover, d Notification, e SoA, f New Licence Letter.",
    )
    heading(doc, "5.4 Request versus business status", 2)
    add_para(
        doc,
        "Create/Update immediate HTTP field status is Accepted. This is not the mapped business "
        "status. Query GET /v1/request/{create_id} returns business status Submitted until the "
        "workflow advances. Internal staging f_status remains a processing value and is not the "
        "external contract.",
    )
    heading(doc, "5.5 Notice Board", 2)
    add_para(
        doc,
        "notice_board is not in the Adapter 0.18.0 live Query response and is not specified in v0.51. "
        "It remains a follow-up item from the v0.5 review.",
    )

    heading(doc, "6. API Specification", 1)
    add_para(
        doc,
        "Unless noted, send Authorization: Bearer <token> and Content-Type: application/json. "
        "Create/Update success: accepted true, status Accepted, create_id = Staging ID. "
        "Update form_data must not be empty. If business status is not Submitted: 409 update_locked.",
    )

    current_group = None
    for api in APIS:
        if api["group"] != current_group:
            current_group = api["group"]
            heading(doc, current_group, 2)
        heading(doc, f"{api['id']}  {api['name']}", 3)
        add_para(doc, f"{api['method']}  {api['path']}", bold=True)
        add_para(doc, f"Authentication: {api['auth']}")
        if api.get("notes"):
            add_para(doc, api["notes"])
        if api["fields"]:
            add_table(
                doc,
                ["Field", "In", "Required", "Type", "Description"],
                [tuple(x) for x in api["fields"]],
            )
        if api.get("example") is not None:
            heading(doc, "Request example", 4)
            add_code(doc, dump(api["example"]))
        is_command = api["method"] == "POST" and (
            "create_" in api["path"] or api["path"].endswith("_data")
        )
        if is_command:
            heading(doc, "Success response example", 4)
            add_code(
                doc,
                dump(
                    {
                        "accepted": True,
                        "create_id": LIVE_CREATE_IDS.get("nla", "386601020882944"),
                        "status": "Accepted",
                        "intake_id": None,
                        "application_id": None,
                    }
                ),
            )

    heading(doc, "7. Live Acceptance on 211 (Adapter 0.18.0)", 1)
    add_table(
        doc,
        ["Item", "Result"],
        [
            ["GET /health/ready", f"adapterVersion {ADAPTER}"],
            ["POST /v1/auth/token", "200, token issued"],
            ["Checklist × 6", "200 (NLA/CHI/Renewal 69, SH 6, SW/RP 4)"],
            ["GET /v1/intakes", "200"],
            ["POST /homerecord-query L0043", "200, 1 home"],
            ["13 Creates", "All 200 status Accepted"],
            ["GET /v1/request/{create_id} after ~12s", "All 200, business status Submitted, application present"],
            ["CHI / SH Update", "200 Accepted; CHI comments in form_data.part_5"],
        ],
    )
    add_table(
        doc,
        ["Application", "create_id"],
        [[k.upper(), v] for k, v in LIVE_CREATE_IDS.items()],
    )

    heading(doc, "8. End-to-End Procedure Implementation Example", 1)
    heading(doc, "8.1 Application with attachments", 2)
    add_para(
        doc,
        "1. POST /v1/auth/token. 2. GET the application checklist. 3. POST /v1/files for each document. "
        "4. POST Create with checklist[].position_code + attachment_id. 5. Receive status Accepted and create_id. "
        "6. GET /v1/request/{create_id} until application_data is present. 7. Update only while Submitted.",
    )
    heading(doc, "8.2 Application without attachments", 2)
    add_para(
        doc,
        "Skip file upload. Create still returns Accepted immediately. Query later for Submitted and application ids.",
    )
    heading(doc, "8.3 Application initiated from CMTF-II", 2)
    add_para(
        doc,
        "CMTF-II may insert Staging itself. The client receives a create_id it never created, via notification "
        "or operational handover, then uses the same Query API. Update is allowed while Submitted.",
    )

    heading(doc, "9. Error Handling", 1)
    add_para(doc, "Common envelope:")
    add_code(
        doc,
        dump(
            {
                "ok": False,
                "error": {
                    "code": "update_locked",
                    "message": "The application can only be updated while its status is Submitted",
                    "requestId": "REQ-20260914-0001",
                    "details": {"status": "Received"},
                },
            }
        ),
    )
    add_table(
        doc,
        ["HTTP", "error.code", "When"],
        [
            ["400", "empty_file / invalid_checksum / unsupported_media_type", "Upload validation"],
            ["401", "unauthorized", "Missing or invalid token"],
            ["404", "request_not_found / record_not_found", "Unknown create_id or record"],
            ["409", "update_locked", "Business status is no longer Submitted"],
            ["422", "invalid_request / home_record_not_resolved / missing_required", "Schema or home-record resolution"],
            ["500 / 502", "upstream_error / invalid_staging_create_response", "Server or upstream failure"],
        ],
    )

    heading(doc, "10. Client Implementation Checklist", 1)
    add_para(doc, "• Treat create_id as the only public key, including CMTF-initiated ids.")
    add_para(doc, "• Map checklist items by position_code.")
    add_para(doc, "• Immediate Create/Update status is Accepted; Query business status starts at Submitted.")
    add_para(doc, "• Allow Update only while Submitted; handle 409 update_locked without retrying the same change.")
    add_para(doc, "• Reply Accepted to every notification; expect retries on 4xx and 500.")
    add_para(doc, "• CHI comments go in form_data.part_5, not a top-level comments field.")

    heading(doc, "11. Review Comment Disposition (Daniel Suen)", 1)
    add_table(
        doc,
        ["Comment", "Disposition in v0.51"],
        [
            ["#4 version/date", "This version is v0.51 dated 14 Sep 2026, author Gregory Lee."],
            ["#12 #38 not NLA-only", "Scope rewritten as multi-application."],
            ["#44 intake_id / application_id", "Not public lookup keys; Create returns null."],
            ["#61 #62 #69 #136 #194 #197 numbering", "Daniel range applied; IDs in headings."],
            ["#74 CMTF create_id + Query", "Documented in notification and E2E 8.3."],
            ["#78 remove Notification column", "All statuses require a reply; column removed."],
            ["#80 #87 #171 Received locks Update", "Mapping table Update allowed = No at Received."],
            ["#86 generic outgoing statuses", "Rejected is generic, not NLA-only."],
            ["#90 #91 submitted → Accepted", "Receiver and Create/Update HTTP status are Accepted. Business status remains Submitted."],
            ["#94 retry 500", "Delivery section includes HTTP 500."],
            ["#120 more application APIs", "CHI through Renewal added from live 0.18.0."],
            ["#149 checklist before Create", "Checklist query is the first API in each application group."],
            ["#159 checklist type mapping", "position_code is the mapping key."],
            ["#158 #164 real JSON", "Live 211 examples included."],
            ["#175 notice_board", "Not in live Query; deferred."],
            ["#177 letter types", "Section 5.3."],
            ["#200 #205 E2E grouping", "Grouped by with/without attachments and CMTF-initiated."],
            ["#211 error.code types", "Section 9 table."],
        ],
    )

    footer = doc.sections[0].footer
    p = footer.paragraphs[0]
    run = p.add_run("CMTF-II API Specification v0.51  |  Gregory Lee  |  14 September 2026")
    set_run_font(run, size=8, color="666666")

    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)


HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(color="FFFFFF", bold=True, name="Calibri", size=11)
CELL_FONT = Font(name="Calibri", size=10)
WRAP = Alignment(wrap_text=True, vertical="top")
THIN = Border(
    left=Side(style="thin", color="B0B0B0"),
    right=Side(style="thin", color="B0B0B0"),
    top=Side(style="thin", color="B0B0B0"),
    bottom=Side(style="thin", color="B0B0B0"),
)
ALT = PatternFill("solid", fgColor="F2F7FB")


def style_header(ws, cols: int) -> None:
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for col in range(1, cols + 1):
        cell = ws.cell(1, col)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        cell.border = THIN


def write_row(ws, row: int, values, alt=False) -> None:
    for i, value in enumerate(values, start=1):
        cell = ws.cell(row, i, value)
        cell.font = CELL_FONT
        cell.alignment = WRAP
        cell.border = THIN
        if alt:
            cell.fill = ALT


def autosize(ws, widths: dict[int, int]) -> None:
    for col, width in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = width


DETAILED_FIELDS = {
    "CMTFII-API-1002": [
        ("request_id", "body", "Yes", "string", "Client id", "NLA-20260914-0001"),
        ("form_data.case_summary.office_code", "body", "Yes", "string", "LORCHE/LORCHD", "LORCHE"),
        ("form_data.case_summary.submitter_user_id", "body", "Yes", "id", "Submitter", "1"),
        ("form_data.case_summary.task_owner_user_id", "body", "Yes", "id", "Intake Officer", "45"),
        ("form_data.case_summary.task_owner_post_code", "body", "Yes", "string", "Post code", "S(LR)1"),
        ("form_data.part_1.application_received_date", "body", "Yes", "date", "Received date", "2026-09-14"),
        ("form_data.part_1.tentative_commencement_date", "body", "Yes", "date", "Tentative start", "2026-12-01"),
        ("form_data.part_1.application_type", "body", "No", "string", "0/1", "0"),
        ("form_data.part_2.rch_name_en", "body", "Yes", "string", "English name", "Example RCH"),
        ("form_data.part_2.rch_name_cn", "body", "Yes", "string", "Chinese name", "示例院舍"),
        ("form_data.part_2.operation_mode_id", "body", "Yes", "id", "Operation mode", "1"),
        ("form_data.part_2.premises_type", "body", "Yes", "string", "0-3", "0"),
        ("form_data.part_2.monthly_fee_min", "body", "Yes", "number", "Min fee", "8000"),
        ("form_data.part_2.monthly_fee_max", "body", "Yes", "number", "Max fee", "12000"),
        ("form_data.part_2.gender", "body", "Yes", "enum", "Gender", "1"),
        ("form_data.part_2.floor_area_sqm", "body", "Yes", "number", "Area", "380.5"),
        ("form_data.part_2.licence_capacity", "body", "Yes", "int", "Capacity", "48"),
        ("form_data.part_2.address", "body", "Yes", "object", "See address object", ""),
        ("form_data.part_2.rch_type_code", "body", "Yes", "string", "a1-a4 / b1-b3", "a1"),
        ("form_data.part_2.nursing_home_places", "body", "Yes", "int", ">=0", "12"),
        ("form_data.part_2.care_and_attention_home_places", "body", "Yes", "int", ">=0", "12"),
        ("form_data.part_2.aged_home_places", "body", "Yes", "int", ">=0", "12"),
        ("form_data.part_2.self_care_hostel_places", "body", "Yes", "int", ">=0", "12"),
        ("form_data.part_2.premises", "body", "Yes", "object", "{self_owned:[], rented:[]}", ""),
        ("form_data.part_3.rch_business_status", "body", "Yes", "enum", "Business status", "0"),
        ("form_data.part_3.applicant_operator_type", "body", "Yes", "enum", "Operator type", "0"),
        ("form_data.part_5.application_level", "body", "Yes", "string", "normal/high", "normal"),
        ("form_data.part_5.comments", "body", "No", "string", "Comments", ""),
        ("form_data.part_5.checklist", "body", "No", "array", "position_code + attachment_id", ""),
    ],
}


def build_excel(path: Path) -> None:
    wb = Workbook()

    ws = wb.active
    ws.title = "Index"
    ws.append(["API ID", "Group", "Method", "Path", "Name", "Live note"])
    for api in APIS:
        ws.append(
            [api["id"], api["group"], api["method"], api["path"], api["name"], api.get("notes") or ""]
        )
    style_header(ws, 6)
    for i, row in enumerate(ws.iter_rows(min_row=2), start=2):
        for cell in row:
            cell.font = CELL_FONT
            cell.alignment = WRAP
            cell.border = THIN
            if i % 2 == 0:
                cell.fill = ALT
    autosize(ws, {1: 20, 2: 28, 3: 10, 4: 52, 5: 36, 6: 70})
    ws.row_dimensions[1].height = 22

    shared = wb.create_sheet("Shared objects")
    shared.append(["Field path", "Required", "Type", "Description"])
    for i, row in enumerate(SHARED_FIELDS, start=2):
        write_row(shared, i, row, alt=i % 2 == 0)
    style_header(shared, 4)
    autosize(shared, {1: 42, 2: 28, 3: 12, 4: 70})

    fields_ws = wb.create_sheet("Request fields")
    fields_ws.append(
        [
            "API ID",
            "API name",
            "Method",
            "Path",
            "Field path",
            "In",
            "Required",
            "Type",
            "Description",
            "Example",
        ]
    )
    r = 2
    for api in APIS:
        detailed = DETAILED_FIELDS.get(api["id"])
        rows = detailed or [
            (f[0], f[1], f[2], f[3], f[4], "") for f in api["fields"]
        ] or [("(no request fields)", "—", "—", "—", api.get("notes") or "No body", "")]
        for field in rows:
            if detailed:
                path_f, loc, req, typ, desc, ex = field
            else:
                path_f, loc, req, typ, desc = field[:5]
                ex = field[5] if len(field) > 5 else ""
            write_row(
                fields_ws,
                r,
                [
                    api["id"],
                    api["name"],
                    api["method"],
                    api["path"],
                    path_f,
                    loc,
                    req,
                    typ,
                    desc,
                    ex,
                ],
                alt=r % 2 == 0,
            )
            r += 1
    style_header(fields_ws, 10)
    autosize(
        fields_ws,
        {1: 20, 2: 34, 3: 10, 4: 48, 5: 48, 6: 10, 7: 18, 8: 12, 9: 55, 10: 28},
    )

    ex = wb.create_sheet("Request body examples")
    ex.append(["API ID", "API name", "Method", "Path", "Request body example (JSON)"])
    r = 2
    for api in APIS:
        body = dump(api["example"]) if api.get("example") is not None else "(no JSON body)"
        write_row(ex, r, [api["id"], api["name"], api["method"], api["path"], body], alt=r % 2 == 0)
        ex.row_dimensions[r].height = min(220, 18 + body.count("\n") * 14)
        r += 1
    style_header(ex, 5)
    autosize(ex, {1: 20, 2: 36, 3: 10, 4: 52, 5: 90})

    live = wb.create_sheet("211 live create_id")
    live.append(["Application", "create_id", "Immediate HTTP status", "Query business status after ~12s"])
    labels = {
        "nla": "New Licence",
        "chi": "Changing Home",
        "sw": "Self-withdraw",
        "rev": "Revoke Licence",
        "sh": "Specific Hour",
        "rp": "Responsible Person",
        "mgr": "Change Home Manager",
        "beds": "Change Beds",
        "mode": "Change Operation Mode",
        "dir": "Change Directors",
        "nurse": "Change Nurse in Charge",
        "pro": "Prosecution",
        "lrn": "Licence Renewal",
    }
    r = 2
    for key, cid in LIVE_CREATE_IDS.items():
        write_row(live, r, [labels[key], cid, "Accepted", "Submitted"], alt=r % 2 == 0)
        r += 1
    style_header(live, 4)
    autosize(live, {1: 28, 2: 24, 3: 24, 4: 36})

    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def main() -> None:
    copy_src = SPEC_DIR / "CMTF-II API Specification v0.5 (Daniel Comments) - working copy for v0.51.docx"
    if SOURCE_COMMENTS.exists() and not copy_src.exists():
        shutil.copy2(SOURCE_COMMENTS, copy_src)

    word_name = "CMTF-II API Specification v0.51.docx"
    xlsx_name = "CMTF-II API Specification v0.51 Request Fields.xlsx"
    word_path = SPEC_DIR / word_name
    xlsx_path = SPEC_DIR / xlsx_name
    build_word(word_path)
    build_excel(xlsx_path)

    REPO_DELIVERABLES.mkdir(parents=True, exist_ok=True)
    shutil.copy2(word_path, REPO_DELIVERABLES / word_name)
    shutil.copy2(xlsx_path, REPO_DELIVERABLES / xlsx_name)
    print(f"word={word_path}")
    print(f"excel={xlsx_path}")
    print(f"repo_word={REPO_DELIVERABLES / word_name}")
    print(f"repo_excel={REPO_DELIVERABLES / xlsx_name}")


if __name__ == "__main__":
    main()
