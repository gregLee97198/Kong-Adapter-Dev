#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_ROOT="${PORTABLE_OUTPUT_ROOT:-$ROOT_DIR/releases}"
VERSION=3.1.9
PLATFORM=linux/amd64
KONG_IMAGE="cmtf-kong:$VERSION"
ADAPTER_IMAGE="cmtf-adapter:$VERSION"
VCS_REF="$(git -C "$ROOT_DIR" rev-parse HEAD)"
SHORT_REF="$(git -C "$ROOT_DIR" rev-parse --short HEAD)"
RELEASE_NAME="cmtf-integration-$VERSION-linux-amd64-$SHORT_REF"
RELEASE_DIR="$OUTPUT_ROOT/$RELEASE_NAME"

if [[ -n "$(git -C "$ROOT_DIR" status --porcelain --untracked-files=normal)" ]]; then
  echo "error=refusing to build from a dirty source tree" >&2
  exit 1
fi

for command in docker git gzip; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "error=missing required command: $command" >&2
    exit 1
  fi
done
if command -v sha256sum >/dev/null 2>&1; then
  CHECKSUM_COMMAND=(sha256sum)
elif command -v shasum >/dev/null 2>&1; then
  CHECKSUM_COMMAND=(shasum -a 256)
else
  echo "error=missing required command: sha256sum or shasum" >&2
  exit 1
fi
if ! docker buildx version >/dev/null 2>&1; then
  echo "error=docker buildx is required" >&2
  exit 1
fi
if [[ -e "$RELEASE_DIR" ]]; then
  echo "error=release already exists: $RELEASE_DIR" >&2
  exit 1
fi

cd "$ROOT_DIR"
docker buildx build --platform "$PLATFORM" --provenance=false \
  --build-arg "ADAPTER_VERSION=$VERSION" \
  --build-arg "VCS_REF=$VCS_REF" \
  -f Dockerfile -t "$ADAPTER_IMAGE" --load .
docker buildx build --platform "$PLATFORM" --provenance=false \
  --build-arg "RELEASE_VERSION=$VERSION" \
  --build-arg "VCS_REF=$VCS_REF" \
  -f Dockerfile.kong-portable -t "$KONG_IMAGE" --load .

for image in "$KONG_IMAGE" "$ADAPTER_IMAGE"; do
  platform="$(docker image inspect --format '{{.Os}}/{{.Architecture}}' "$image")"
  if [[ "$platform" != "$PLATFORM" ]]; then
    echo "error=$image platform is $platform, expected $PLATFORM" >&2
    exit 1
  fi
done
KONG_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$KONG_IMAGE")"
ADAPTER_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$ADAPTER_IMAGE")"
docker run --rm --network none --entrypoint python "$ADAPTER_IMAGE" \
  -c "import app.main; assert app.main.ADAPTER_VERSION == '$VERSION'"

mkdir -p "$RELEASE_DIR/scripts"
install -m 0600 config/nocobase.portable.yaml \
  "$RELEASE_DIR/adapter.yaml"
install -m 0644 config/kong.portable-template.yml \
  "$RELEASE_DIR/kong.yaml"
install -m 0644 docker-compose.portable.yml \
  "$RELEASE_DIR/docker-compose.yml"
install -m 0755 scripts/configure_portable_runtime.sh \
  "$RELEASE_DIR/scripts/configure-runtime.sh"
install -m 0644 docs/Portable-3.1.9-Deployment_zh-CN.md \
  "$RELEASE_DIR/README.md"

docker save "$KONG_IMAGE" | gzip -9 \
  > "$RELEASE_DIR/cmtf-kong-$VERSION-linux-amd64.docker.tar.gz"
docker save "$ADAPTER_IMAGE" | gzip -9 \
  > "$RELEASE_DIR/cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz"

gzip -t "$RELEASE_DIR/cmtf-kong-$VERSION-linux-amd64.docker.tar.gz"
gzip -t "$RELEASE_DIR/cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz"

printf '%s\n' \
  "release=$RELEASE_NAME" \
  "source_commit=$VCS_REF" \
  "platform=$PLATFORM" \
  "kong_image=$KONG_IMAGE" \
  "kong_image_id=$KONG_IMAGE_ID" \
  "adapter_image=$ADAPTER_IMAGE" \
  "adapter_image_id=$ADAPTER_IMAGE_ID" \
  "token_included=false" \
  > "$RELEASE_DIR/RELEASE-MANIFEST.txt"

(
  cd "$RELEASE_DIR"
  "${CHECKSUM_COMMAND[@]}" \
    "cmtf-kong-$VERSION-linux-amd64.docker.tar.gz" \
    "cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz" \
    adapter.yaml \
    kong.yaml \
    docker-compose.yml \
    scripts/configure-runtime.sh \
    README.md \
    RELEASE-MANIFEST.txt \
    > SHA256SUMS
)

echo "release_dir=$RELEASE_DIR"
