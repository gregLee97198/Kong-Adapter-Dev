#!/usr/bin/env bash
set -Eeuo pipefail

# Four-file, secret-free source bundle.  The operator populates a separate
# runtime copy of adapter.yaml and pins it into kong.yaml on the target host.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_ROOT="${PORTABLE_OUTPUT_ROOT:-$ROOT_DIR/releases}"
PLATFORM=linux/amd64
SHORT_REF="$(git -C "$ROOT_DIR" rev-parse --short HEAD)"
VCS_REF="$(git -C "$ROOT_DIR" rev-parse HEAD)"
VERSION="3.1.9-v081-$SHORT_REF"
KONG_IMAGE="cmtf-kong:$VERSION"
ADAPTER_IMAGE="cmtf-adapter:$VERSION"
RELEASE_DIR="$OUTPUT_ROOT/cmtf-integration-$VERSION-linux-amd64"

if [[ -n "$(git -C "$ROOT_DIR" status --porcelain --untracked-files=normal)" ]]; then
  echo "error=refusing to build from a dirty source tree" >&2
  exit 1
fi
for command in docker git gzip; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "error=missing required command: $command" >&2
    exit 1
  fi
done
if command -v sha256sum >/dev/null 2>&1; then
  CHECKSUM_COMMAND=(sha256sum)
elif command -v shasum >/dev/null 2>&1; then
  CHECKSUM_COMMAND=(shasum -a 256)
else
  echo "error=missing SHA-256 command" >&2
  exit 1
fi
if ! docker buildx version >/dev/null 2>&1; then
  echo "error=docker buildx is required" >&2
  exit 1
fi
if [[ -e "$RELEASE_DIR" ]]; then
  echo "error=release already exists: $RELEASE_DIR" >&2
  exit 1
fi

cd "$ROOT_DIR"
docker buildx build --platform "$PLATFORM" --provenance=false \
  --build-arg "ADAPTER_VERSION=$VERSION" --build-arg "VCS_REF=$VCS_REF" \
  --build-arg "PORTABLE_RELEASE=1" \
  -f Dockerfile -t "$ADAPTER_IMAGE" --load .
docker buildx build --platform "$PLATFORM" --provenance=false \
  --build-arg "RELEASE_VERSION=$VERSION" --build-arg "VCS_REF=$VCS_REF" \
  -f Dockerfile.kong-portable -t "$KONG_IMAGE" --load .

for image in "$KONG_IMAGE" "$ADAPTER_IMAGE"; do
  platform="$(docker image inspect --format '{{.Os}}/{{.Architecture}}' "$image")"
  if [[ "$platform" != "$PLATFORM" ]]; then
    echo "error=$image platform is $platform, expected $PLATFORM" >&2
    exit 1
  fi
  revision="$(docker image inspect --format '{{index .Config.Labels "org.opencontainers.image.revision"}}' "$image")"
  if [[ "$revision" != "$VCS_REF" ]]; then
    echo "error=$image source revision does not match" >&2
    exit 1
  fi
done
portable_switch="$(docker image inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$ADAPTER_IMAGE" | sed -n 's/^PORTABLE_RELEASE=//p')"
if [[ "$portable_switch" != "1" ]]; then
  echo "error=$ADAPTER_IMAGE must require portable runtime validation" >&2
  exit 1
fi
docker run --rm --network none --entrypoint python "$ADAPTER_IMAGE" \
  -c "import app.main; assert app.main.ADAPTER_VERSION == '$VERSION'"
docker run --rm --network none --user 0:0 \
  --mount "type=bind,source=$ROOT_DIR/config/nocobase.portable.yaml,target=/runtime/adapter.yaml,readonly" \
  --mount "type=bind,source=$ROOT_DIR/config/kong.portable-template.yml,target=/runtime/kong.yaml,readonly" \
  --entrypoint python "$ADAPTER_IMAGE" -m app.portable_config validate \
  --nocobase /runtime/adapter.yaml --kong /runtime/kong.yaml --allow-empty-token
docker run --rm --network none \
  --mount "type=bind,source=$ROOT_DIR/config/kong.portable-template.yml,target=/kong/declarative/kong.yml,readonly" \
  -e KONG_DATABASE=off --entrypoint kong "$KONG_IMAGE" \
  config parse /kong/declarative/kong.yml

mkdir -p "$RELEASE_DIR"
install -m 0600 config/nocobase.portable.yaml "$RELEASE_DIR/adapter.yaml"
install -m 0644 config/kong.portable-template.yml "$RELEASE_DIR/kong.yaml"
docker save "$KONG_IMAGE" | gzip -9 \
  > "$RELEASE_DIR/cmtf-kong-$VERSION-linux-amd64.docker.tar.gz"
docker save "$ADAPTER_IMAGE" | gzip -9 \
  > "$RELEASE_DIR/cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz"
gzip -t "$RELEASE_DIR/cmtf-kong-$VERSION-linux-amd64.docker.tar.gz"
gzip -t "$RELEASE_DIR/cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz"

echo "release_dir=$RELEASE_DIR"
echo "source_commit=$VCS_REF"
echo "kong_image=$KONG_IMAGE"
echo "adapter_image=$ADAPTER_IMAGE"
echo "kong_image_id=$(docker image inspect --format '{{.Id}}' "$KONG_IMAGE")"
echo "adapter_image_id=$(docker image inspect --format '{{.Id}}' "$ADAPTER_IMAGE")"
echo "token_included=false"
(
  cd "$RELEASE_DIR"
  "${CHECKSUM_COMMAND[@]}" \
    "cmtf-kong-$VERSION-linux-amd64.docker.tar.gz" \
    "cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz" \
    kong.yaml adapter.yaml
)
