#!/usr/bin/env bash
# Build the Linux/AMD64 UAT image and a secret-free offline delivery bundle on 211.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT_ROOT="${UAT_BUNDLE_OUTPUT_ROOT:-$ROOT_DIR/releases}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
ADAPTER_IMAGE=""
KONG_IMAGE="kong:3.9.3"
PLATFORM="linux/amd64"

if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
  echo "error=this script must run on the Linux/AMD64 211 build host" >&2
  exit 1
fi
for command in docker git python3 gzip tar; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "error=missing required command: $command" >&2
    exit 1
  fi
done
if ! docker info >/dev/null 2>&1; then
  echo "error=Docker daemon is not available" >&2
  exit 1
fi
if [[ -n "$(git -C "$ROOT_DIR" ls-files --others --exclude-standard app)" ]]; then
  echo "error=untracked app files could enter the image; review them first" >&2
  exit 1
fi

BUILD_INPUT_PATHS=(
  .dockerignore Dockerfile requirements.txt app uat.env.example
  config/environments.yaml config/nocobase.uat.yaml config/kong.uat-dbless.yml
  docker-compose.uat.yml
  scripts/build_uat_offline_bundle.sh
  scripts/generate_uat_kong_config.py
  scripts/manage_environment.py
  scripts/render_uat_release_manifest.py
  scripts/retarget_uat_config.py
  docs/Kong-UAT-Offline-Deployment_zh-CN.md
)
RELEASE_PATHS=(
  config/nocobase.uat.yaml config/kong.uat-dbless.yml
  docker-compose.uat.yml
  scripts/retarget_uat_config.py
  scripts/manage_environment.py
  docs/Kong-UAT-Offline-Deployment_zh-CN.md
)
if ! git -C "$ROOT_DIR" diff --quiet HEAD -- "${BUILD_INPUT_PATHS[@]}"; then
  echo "error=build or release files differ from HEAD; commit reviewed changes before packaging" >&2
  exit 1
fi
ADAPTER_IMAGE="kong-nocoadapter:0.19.1-uat-offline-$(git -C "$ROOT_DIR" rev-parse --short HEAD)-$STAMP"

cd "$ROOT_DIR"
PROFILE_PYTHON=python3
if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PROFILE_PYTHON="$ROOT_DIR/.venv/bin/python"
fi
if ! "$PROFILE_PYTHON" -c 'import yaml' >/dev/null 2>&1; then
  echo "error=211 build host needs an existing Python/PyYAML environment for static checks" >&2
  exit 1
fi
UAT_ENV_FILE=uat.env.example "$PROFILE_PYTHON" scripts/generate_uat_kong_config.py --check
UAT_ENV_FILE=uat.env.example "$PROFILE_PYTHON" scripts/manage_environment.py validate uat
NOCOBASE_CONFIG_TOKEN=example-only ADAPTER_IMAGE="$ADAPTER_IMAGE" \
  docker compose --env-file uat.env.example -f docker-compose.uat.yml config --quiet
if ! "$PROFILE_PYTHON" -c \
  'from app.main import ADAPTER_VERSION; assert ADAPTER_VERSION == "0.19.1"'; then
  echo "error=app version does not match release version 0.19.1" >&2
  exit 1
fi
if ! docker image inspect "$KONG_IMAGE" >/dev/null 2>&1; then
  echo "error=$KONG_IMAGE is missing; import or pull the approved image on 211 first" >&2
  exit 1
fi
if [[ "$(docker image inspect "$KONG_IMAGE" --format '{{.Architecture}}')" != amd64 ]]; then
  echo "error=$KONG_IMAGE is not Linux/AMD64" >&2
  exit 1
fi

# Use a unique UAT build tag so the live 211 adapter's 0.19.1 tag is untouched.
# pip install happens in the Dockerfile during this build, not on the UAT host.
docker build --platform "$PLATFORM" --tag "$ADAPTER_IMAGE" .
if [[ "$(docker image inspect "$ADAPTER_IMAGE" --format '{{.Architecture}}')" != amd64 ]]; then
  echo "error=adapter image is not Linux/AMD64" >&2
  exit 1
fi
docker run --rm --network none \
  --mount "type=bind,source=$ROOT_DIR/config/nocobase.uat.yaml,target=/app/config/nocobase.yaml,readonly" \
  --env NOCOBASE_CONFIG_PATH=/app/config/nocobase.yaml \
  --entrypoint python "$ADAPTER_IMAGE" -c '
import fastapi, httpx, multipart, uvicorn, yaml
from app.main import ADAPTER_VERSION
assert ADAPTER_VERSION == "0.19.1", ADAPTER_VERSION
print("adapter_python_dependencies=present version=" + ADAPTER_VERSION)
'

mkdir -p "$OUTPUT_ROOT"
RELEASE_NAME="kong-uat-offline-0.19.1-linux-amd64-$STAMP"
RELEASE_TAR="$OUTPUT_ROOT/$RELEASE_NAME.tar"
if [[ -e "$RELEASE_TAR" ]]; then
  echo "error=release output already exists: $RELEASE_TAR" >&2
  exit 1
fi
STAGE_PARENT="$(mktemp -d "$OUTPUT_ROOT/.uat-stage.XXXXXX")"
cleanup_stage() {
  if [[ -n "${STAGE_PARENT:-}" && -d "$STAGE_PARENT" ]]; then
    rm -r -- "$STAGE_PARENT"
  fi
}
trap cleanup_stage EXIT
STAGE_DIR="$STAGE_PARENT/$RELEASE_NAME"
mkdir -p "$STAGE_DIR"

git archive --format=tar HEAD "${RELEASE_PATHS[@]}" | tar -C "$STAGE_DIR" -xf -
# Never copy the live 211 .env: the packaged file is only a secret-free
# two-key template, to be edited in UAT's file manager after download.
cp -- uat.env.example "$STAGE_DIR/.env"
chmod 600 "$STAGE_DIR/.env"
"$PROFILE_PYTHON" scripts/render_uat_release_manifest.py \
  "$STAGE_DIR/config/environments.yaml" --check-dir "$STAGE_DIR"
mkdir -p "$STAGE_DIR/images"
docker image save "$ADAPTER_IMAGE" "$KONG_IMAGE" \
  | gzip -1 > "$STAGE_DIR/images/kong-uat-0.19.1-linux-amd64.docker.tar.gz"
gzip -t "$STAGE_DIR/images/kong-uat-0.19.1-linux-amd64.docker.tar.gz"

printf '%s\n' "$ADAPTER_IMAGE" > "$STAGE_DIR/ADAPTER_SOURCE_IMAGE"
tar -C "$STAGE_PARENT" -cf "$STAGE_PARENT/$RELEASE_NAME.tar" "$RELEASE_NAME"
mv -- "$STAGE_PARENT/$RELEASE_NAME.tar" "$RELEASE_TAR"
echo "release_tar=$RELEASE_TAR"
echo "note=no secrets or runtime tokens are included; edit UAT .env after unpacking"
