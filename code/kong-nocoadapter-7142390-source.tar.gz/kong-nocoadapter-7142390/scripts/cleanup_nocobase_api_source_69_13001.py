#!/usr/bin/env python3
"""Delete the 69 explicitly reviewed obsolete API workflows on DEV 13001.

The only mutating path requires ``--execute``.  It takes a fresh, private,
GET-only backup of workflow details, categories, nodes and execution summaries
before deleting any row.  Every deletion is checked against its exact ID and
the fresh snapshot; a checkpoint is written after each confirmed destroy.

This script is scoped to the 13001 development instance.  It never selects
workflows by a title search and never touches native business workflows.
"""

from __future__ import annotations

import argparse
import json
import os
import tempfile
import urllib.parse
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import execute_nocobase_unified_subflow_cleanup_13001 as prior
from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError, resolve_workflow_category_id

BASE_URL = "http://119.91.104.211:13001/cmtf2"
OUTPUT_ROOT = Path("/Users/work/noco/kong-nocoadapter-artifacts/workflow-cleanups")
API_CATEGORY = 380631923228672
NOTICE_CATEGORY = 389469911187456

OLD_REVISIONS = (
    386582574202880,
    386583851368448,
    386583859757056,
    386583880728576,
    386583905894400,
    386583931060224,
    386583943643136,
    386584843321344,
    386584855904256,
    386584950276096,
    386584960761856,
    386586349076480,
    386586359562240,
    386586504265728,
    386586518945792,
    386586653163520,
    386586669940736,
    386586820935680,
    386586829324288,
    386586961444864,
    386586971930624,
    386588127461376,
    386588165210112,
    386591625510912,
    386591684231168,
    386751692734466,
    388078607138816,
    388078651179008,
    388078678441984,
    388078718287872,
    388078751842304,
    388078789591040,
    388079116746752,
    388079156592640,
    388079192244224,
    388079229992960,
    388079263547392,
    388079301296128,
    388191708643328,
    388192398606336,
    388199657832448,
    388250708803585,
    389126120865792,
    389126466895872,
    390043355578368,
    390782003970048,
    390796453347328,
    390912096600064,
    390917828116480,
    390957986480128,
)
OLD_SINGLETONS = (
    384597111537664,
    384608150945792,
    384621457375232,
    384624645046272,
    384631051845632,
    386576588931072,
    386576983195648,
    386590304305152,
    386590352539648,
    390043514961920,
    390796566593536,
)
ACTIVE_PROSECUTION = (
    386588190375936,
    386588198764544,
    386591126388736,
    386593907212288,
)
DISABLED_CANDIDATES = (
    392955195686912,
    392955501871104,
    392957108289536,
    392958045716480,
)
DELETE_IDS = tuple(
    dict.fromkeys(
        (*OLD_REVISIONS, *OLD_SINGLETONS, *DISABLED_CANDIDATES, *ACTIVE_PROSECUTION)
    )
)
NOTICE_IDS = (
    386594108538880,
    386770558713856,
    386836358955008,
    388100004380672,
    388100065198080,
    388100100849664,
    388100197318656,
    388100232970240,
    388100285399040,
    388251235188736,
    388251277131776,
    388254141841408,
    388254175395840,
    388254764695552,
    388254800347136,
    388255559516160,
    388255593070592,
    388256725532672,
    388256763281408,
    390051177955328,
    390051643523072,
    390807050256384,
    392436154695680,
)
OTHER_PROTECTED = (
    386582576300033,  # The only retained CHI Received bridge.
    388192025313280,
    388192073547776,
    388199490060288,
    388199729135616,  # Active Revoke workflows.
)


class ExactCleanupError(RuntimeError):
    """A precondition or readback failed; stop all further deletions."""


def _assert_catalogue() -> None:
    if (
        len(OLD_REVISIONS),
        len(OLD_SINGLETONS),
        len(ACTIVE_PROSECUTION),
        len(DISABLED_CANDIDATES),
        len(DELETE_IDS),
        len(NOTICE_IDS),
    ) != (50, 11, 4, 4, 69, 23):
        raise ExactCleanupError("reviewed workflow catalogue count drifted")
    if set(DELETE_IDS) & (set(NOTICE_IDS) | set(OTHER_PROTECTED)):
        raise ExactCleanupError("deletion target overlaps a protected workflow")
    if not {386588127461376, 386588165210112} <= set(OLD_REVISIONS):
        raise ExactCleanupError("two disabled Prosecution revisions are absent")


def _atomic_json(path: Path, value: dict[str, Any], *, replace: bool) -> None:
    if path.exists() and not replace:
        raise ExactCleanupError(f"refusing to overwrite backup: {path}")
    payload = (
        json.dumps(value, ensure_ascii=False, sort_keys=True, default=str) + "\n"
    ).encode()
    descriptor, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def _read(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    return prior._read_workflow(api, workflow_id)


def _execution(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    return prior._assert_execution_idle(
        api, workflow_id, label=f"workflow {workflow_id}"
    )


def _verify_protected(api: RootNocoBaseApi, *, full: bool) -> dict[str, Any]:
    if resolve_workflow_category_id(api, "API Suorce") != API_CATEGORY:
        raise ExactCleanupError("API Suorce category identity changed")
    if resolve_workflow_category_id(api, "Notice Board") != NOTICE_CATEGORY:
        raise ExactCleanupError("Notice Board category identity changed")
    topology = prior.verify_active_topology(api, prior._load_candidate_manifest())
    active_ids = [int(topology["parent"]["id"])] + [
        int(row["id"]) for row in topology["children"].values()
    ]
    if len(active_ids) != 13 or set(active_ids) & set(DELETE_IDS):
        raise ExactCleanupError("dispatcher or child identity changed")
    result: dict[str, Any] = {"active_ids": active_ids}
    if full:
        result["workflows"] = {}
        result["executions"] = {}
        for row in [topology["parent"], *topology["children"].values()]:
            result["workflows"][str(row["id"])] = row
            result["executions"][str(row["id"])] = _execution(api, int(row["id"]))
    for workflow_id in (*NOTICE_IDS, *OTHER_PROTECTED):
        row = _read(api, workflow_id)
        categories = set(row["_category_ids"])
        if workflow_id in NOTICE_IDS:
            if (
                row.get("enabled") is not True
                or NOTICE_CATEGORY not in categories
                or API_CATEGORY in categories
            ):
                raise ExactCleanupError(f"Notice category/state drifted: {workflow_id}")
        elif workflow_id == 386582576300033:
            if row.get("enabled") is not False:
                raise ExactCleanupError("retained CHI bridge is no longer disabled")
        elif row.get("enabled") is not True:
            raise ExactCleanupError(
                f"protected Revoke workflow state drifted: {workflow_id}"
            )
        if full:
            result["workflows"][str(workflow_id)] = row
            result["executions"][str(workflow_id)] = _execution(api, workflow_id)
    return result


def _target_row(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    row = _read(api, workflow_id)
    expected_enabled = workflow_id in ACTIVE_PROSECUTION
    if row.get("id") != workflow_id or row.get("type") != "collection":
        raise ExactCleanupError(f"target identity/type drifted: {workflow_id}")
    if row.get("enabled") is not expected_enabled or API_CATEGORY not in set(
        row["_category_ids"]
    ):
        raise ExactCleanupError(f"target state/category drifted: {workflow_id}")
    title = row.get("title")
    if not isinstance(title, str) or not title.startswith("API "):
        raise ExactCleanupError(
            f"target title no longer belongs to API integration: {workflow_id}"
        )
    if workflow_id in ACTIVE_PROSECUTION or workflow_id in {
        386588127461376,
        386588165210112,
    }:
        if "Prosecution" not in title:
            raise ExactCleanupError(f"Prosecution identity drifted: {workflow_id}")
    if workflow_id in DISABLED_CANDIDATES and "Dispatcher" not in title:
        raise ExactCleanupError(
            f"diagnostic dispatcher identity drifted: {workflow_id}"
        )
    if not isinstance(row.get("key"), str) or not isinstance(row.get("nodes"), list):
        raise ExactCleanupError(f"target workflow details incomplete: {workflow_id}")
    return row


def _run_dir(root: Path) -> Path:
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(root, 0o700)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    result = root / f"api-source-69-{stamp}-{uuid.uuid4().hex[:8]}"
    result.mkdir(mode=0o700)
    return result


def execute(api: RootNocoBaseApi, output_root: Path = OUTPUT_ROOT) -> Path:
    """Fresh backup, then sequential exact deletion with durable checkpoints."""
    _assert_catalogue()
    if getattr(api, "base_url", "").rstrip("/") != BASE_URL:
        raise ExactCleanupError("endpoint must be fixed DEV 13001")
    directory = _run_dir(output_root)
    protected = _verify_protected(api, full=True)
    targets: dict[str, dict[str, Any]] = {}
    executions: dict[str, dict[str, Any]] = {}
    for workflow_id in DELETE_IDS:
        targets[str(workflow_id)] = _target_row(api, workflow_id)
        executions[str(workflow_id)] = _execution(api, workflow_id)
    snapshot = {
        "environment": "13001",
        "base_url": BASE_URL,
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "target_count": 69,
        "targets": targets,
        "target_executions": executions,
        "protected": protected,
    }
    _atomic_json(directory / "predelete-full-snapshot.json", snapshot, replace=False)
    checkpoint = {
        "environment": "13001",
        "snapshot": "predelete-full-snapshot.json",
        "planned_ids": list(DELETE_IDS),
        "completed_ids": [],
        "status": "in_progress",
    }
    checkpoint_path = directory / "checkpoint.json"
    _atomic_json(checkpoint_path, checkpoint, replace=False)

    # A network failure on POST can have an uncertain outcome.  Confirm the
    # exact row is absent before treating it as completed; otherwise stop.
    for workflow_id in DELETE_IDS:
        original = targets[str(workflow_id)]
        current = _target_row(api, workflow_id)
        for field in ("id", "key", "title", "type", "enabled", "_category_ids"):
            if current[field] != original[field]:
                raise ExactCleanupError(
                    f"target changed after snapshot: {workflow_id}, {field}"
                )
        _execution(api, workflow_id)
        path = "/api/workflows:destroy?" + urllib.parse.urlencode(
            {"filterByTk": str(workflow_id)}
        )
        try:
            api.request("POST", path, {})
        except ApiError as exc:
            if not prior._read_absent(api, workflow_id):
                raise ExactCleanupError(f"destroy failed for {workflow_id}") from exc
        if not prior._read_absent(api, workflow_id):
            raise ExactCleanupError(f"destroy did not persist for {workflow_id}")
        checkpoint["completed_ids"].append(workflow_id)
        _atomic_json(checkpoint_path, checkpoint, replace=True)

    _verify_protected(api, full=False)
    remaining = [
        workflow_id
        for workflow_id in DELETE_IDS
        if not prior._read_absent(api, workflow_id)
    ]
    if remaining:
        raise ExactCleanupError(f"postcheck found undeleted targets: {remaining}")
    checkpoint["status"] = "complete"
    checkpoint["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    _atomic_json(checkpoint_path, checkpoint, replace=True)
    return directory


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Back up then delete exactly 69 reviewed 13001 workflows",
    )
    parser.add_argument("--output-root", type=Path, default=OUTPUT_ROOT)
    args = parser.parse_args()
    _assert_catalogue()
    if not args.execute:
        print(
            json.dumps(
                {
                    "environment": "13001",
                    "delete_count": len(DELETE_IDS),
                    "writes_remote": False,
                }
            )
        )
        return 0
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        parser.error("NOCOBASE_TOKEN is required")
    api = RootNocoBaseApi(BASE_URL, token)
    try:
        directory = execute(api, args.output_root)
    except (ApiError, ExactCleanupError, prior.CleanupError) as exc:
        print(f"cleanup failed: {exc}", file=__import__("sys").stderr)
        return 1
    print(
        json.dumps(
            {
                "environment": "13001",
                "deleted": 69,
                "evidence_directory": str(directory),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
