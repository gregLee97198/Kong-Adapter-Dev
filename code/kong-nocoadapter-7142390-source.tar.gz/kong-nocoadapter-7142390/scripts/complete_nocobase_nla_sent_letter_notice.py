#!/usr/bin/env python3
"""Prepare and cut over a guarded NLA Send Letter Notice workflow on DEV 13001.

The v3 sidecar remains active until an explicit ``cutover --apply``.  ``audit``
and every command without ``--apply`` are read-only.  ``prepare`` copies v3
as a disabled revision, then adds a NLA-only branch.  Non-NLA letters continue
through the unchanged v3 branch.  The native NLA business workflows are never
edited.  No HTTP callback is sent to OP by this workflow.

This graph records a NLA Notice only after the native Send Letter action has
set both ``f_is_send=true`` and ``f_sendtime``.  Letter ``a`` remains owned by
Approval Log Sync Data.  ``b`` is Confirmed.  ``d`` is Reminding only while the
native application is Pending Initial Inspection (code 7).  Sent ``c`` and
``f`` letters must both exist before either Approved Notice is visible or the
canonical CREATE row advances to Approved.  Any already-sent ``e`` letter is
recorded at that point; a later ``e`` is recorded separately.  The native
workflow is expected to permit c/f sending only after business approval; the
letter pair, rather than a native Completed code that may lag Send Letter, is
the external Approved boundary.  A cancellation acknowledgement may publish
Closed only in native state 17 or 2, never a draft/approval state.

The Notice status dictionary's historical Rejected row is not renamed.  A
separate Closed row is ensured in ``prepare``.  The canonical staging update
is a conditional write with ``individualHooks=false`` after persisted Notice
readback.  It cannot recursively trigger the OP staging creation workflow.
An existing v3 Notice for the first c/f letter is never duplicated.  It can
satisfy Approved readback only when its original Send Letter event identity,
canonical CREATE link, letter type and Approved status all match.  A drifted
legacy row is left untouched and blocks advancement for manual reconciliation.

Do not run concurrent operators.  Copying a revision has a brief both-Off gap;
the commands print UTC gap bounds for event reconciliation.  The script
refuses 13000 and any other host.  A failed/uncertain write requires a fresh
``audit`` before retrying.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError

BASE_URL = "http://119.91.104.211:13001/cmtf2"
SOURCE_ID = 390796453347328
SOURCE_KEY = "75fzv69gij3"
SOURCE_TITLE = "API Notice — Sent Letter to Notice List v3"
SOURCE_FINGERPRINT = (
    "a43cfd9b5c3627dc59cc24dafbc2208d44ab3e5783c5e0f4bb5c306779c6b38b"
)
SOURCE_NODE_COUNT = 9
ORIGINAL_START = "01 Check Existing Notice for Letter"
NLA_APP = "NLA v4 01 Resolve licence application"
NLA_GATE = "NLA v4 02 Is licence application"
CANONICAL = "NLA v4 03 Resolve unique OP CREATE"
COVER = "NLA v4 04 Resolve sent Cover Letters"
LICENCE = "NLA v4 05 Resolve sent Licence Letters"
ACCOUNT = "NLA v4 06 Resolve sent Account Letters"
PLAN = "NLA v4 07 Plan sent-letter Notices"
READY = "NLA v4 08 Plan is publishable"
STATUS = "NLA v4 09 Resolve mapped Notice status"
LOOP = "NLA v4 10 Ensure each sent-letter Notice"
EXISTING = "NLA v4 11 Check existing letter Notice"
MISSING = "NLA v4 12 Letter Notice is missing"
CREATE = "NLA v4 13 Create letter Notice"
READBACK = "NLA v4 14 Read persisted letter Notices"
ADVANCE_PLAN = "NLA v4 15 Guard canonical status advance"
ADVANCE_GATE = "NLA v4 16 Canonical status may advance"
ADVANCE = "NLA v4 17 CAS canonical CREATE status"
ADDED_TITLES = (
    NLA_APP, NLA_GATE, CANONICAL, COVER, LICENCE, ACCOUNT, PLAN, READY,
    STATUS, LOOP, EXISTING, MISSING, CREATE, READBACK, ADVANCE_PLAN,
    ADVANCE_GATE, ADVANCE,
)
NOTICE_STATUS_COLLECTION = "t_notice_board_status"
NOTICE_COLLECTION = "t_notice_board"
STAGING_COLLECTION = "t_api_request_staging"
NLA_COLLECTION = "t_licence_app"
LETTER_COLLECTION = "t_letter_attachment"
CANCELLATION_TYPE = "t_acknowledgement_letter_of_cancellation"
NLA_LETTER_TYPES = {"a", "b", "c", "d", "e", "f", CANCELLATION_TYPE}


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ApiError(message)


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def ref(node: Mapping[str, Any], field: str) -> str:
    return "{{$jobsMapByNodeKey." + str(node["key"]) + "." + field + "}}"


def row_ref(node: Mapping[str, Any]) -> str:
    return "{{$jobsMapByNodeKey." + str(node["key"]) + "}}"


def scope(node: Mapping[str, Any], field: str) -> str:
    # NocoBase loop child nodes bind the current item through $scopes, not
    # $jobsMapByNodeKey or the retired $scopesMapByNodeKey spelling.
    return "{{$scopes." + str(node["key"]) + ".item." + field + "}}"


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def source_fingerprint(workflow: Mapping[str, Any]) -> str:
    body = {
        "key": workflow.get("key"),
        "title": workflow.get("title"),
        "config": workflow.get("config"),
        "nodes": sorted(
            [
                {key: node.get(key) for key in (
                    "id", "key", "title", "type", "workflowId",
                    "upstreamId", "downstreamId", "branchIndex", "config",
                )}
                for node in workflow.get("nodes") or []
            ],
            key=lambda node: node["id"],
        ),
    }
    return hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":"),
                   ensure_ascii=False).encode("utf-8")
    ).hexdigest()


def nodes_by_title(workflow: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    nodes = workflow.get("nodes") or []
    titles = [node.get("title") for node in nodes]
    require(len(titles) == len(set(titles)), "Duplicate workflow node title")
    return {str(node["title"]): dict(node) for node in nodes}


def validate_source(workflow: Mapping[str, Any]) -> None:
    config = workflow.get("config") or {}
    require(
        workflow.get("id") == SOURCE_ID
        and workflow.get("key") == SOURCE_KEY
        and workflow.get("title") == SOURCE_TITLE
        and workflow.get("type") == "collection"
        and workflow.get("sync") is False
        and config.get("mode") == 2
        and config.get("collection") == LETTER_COLLECTION
        and config.get("changed") == ["f_sendtime"]
        and config.get("condition") == {
            "$and": [{"f_sendtime": {"$notEmpty": True}}]
        }
        and len(workflow.get("nodes") or []) == SOURCE_NODE_COUNT
        and ORIGINAL_START in nodes_by_title(workflow)
        and source_fingerprint(workflow) == SOURCE_FINGERPRINT,
        "Active Send Letter v3 differs from the audited fingerprint",
    )


def query_config(
    collection: str, filters: list[dict[str, Any]], *, multiple: bool = False,
    page_size: int = 1, appends: tuple[str, ...] = (),
) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": multiple,
        "failOnEmpty": False,
        "params": {
            "filter": {"$and": filters},
            "sort": [{"field": "createdAt", "direction": "asc"}],
            "page": 1,
            "pageSize": page_size,
            "appends": list(appends),
        },
    }


def condition_config(operands: list[Any], *, reject: bool = False) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject,
        "engine": "basic",
        "calculation": {"group": {"type": "and", "calculations": [
            {"calculator": "equal", "operands": operands},
        ]}},
    }


def plan_script() -> str:
    return r"""const file = letter || {};
const app = application || {};
const rows = Array.isArray(canonicalRows) ? canonicalRows : [];
const canonical = rows.length === 1 ? rows[0] : null;
const type = String(file.f_letter_type || '');
const appId = String(app.id || '');
const current = String(canonical?.f_application_status || '');
const valid = !!appId && String(file.f_business_key || '') === appId
  && canonical && String(canonical.f_application_id || '') === appId
  && canonical.f_source_system === 'OP'
  && canonical.f_request_event === 'CREATE'
  && canonical.f_api_type === 'create_intake_for_new_licence'
  && canonical.f_application_type === 'new_licence';
const sent = value => !!value?.id && value.f_is_send === true
  && !!value.f_sendtime && String(value.f_business_key || '') === appId;
const normalize = value => Array.isArray(value) ? value : [];
const covers = normalize(coverLetters)
  .filter(row => sent(row) && row.f_letter_type === 'c');
const licences = normalize(licenceLetters)
  .filter(row => sent(row) && row.f_letter_type === 'f');
const accounts = normalize(accountLetters)
  .filter(row => sent(row) && row.f_letter_type === 'e');
// A full result page is ambiguous: never publish a partial Notice history.
if ([covers, licences, accounts].some(rows => rows.length >= 100))
  throw new Error('Sent NLA letter query reached its 100-row limit');
const pairReady = covers.length > 0 && licences.length > 0;
const native = String(app.f_approval_status ?? '');
const allowed = {
  Confirmed: ['Acknowledged', 'Reminding', 'Confirmed'],
  Reminding: ['Acknowledged', 'Confirmed', 'Reminding'],
  Approved: ['Confirmed', 'Reminding', 'Approved'],
  Closed: ['Received', 'P_Number_Generated', 'Acknowledged',
    'Confirmed', 'Reminding', 'Approved', 'Closed'],
};
let statusName = '';
let selected = [];
if (valid && sent(file)) {
  if (type === 'b') { statusName = 'Confirmed'; selected = [file]; }
  else if (type === 'd' && native === '7') {
    statusName = 'Reminding'; selected = [file];
  } else if (['c','e','f'].includes(type) && pairReady) {
    statusName = 'Approved'; selected = [...covers, ...licences, ...accounts];
  } else if (type === 't_acknowledgement_letter_of_cancellation'
      && ['17','2'].includes(native)) {
    statusName = 'Closed'; selected = [file];
  }
}
if (!allowed[statusName]?.includes(current)) selected = [];
const labels = {
  b: 'Confirmation Letter', c: 'Cover Letter',
  d: 'Notification Letter', e: 'Statement of Account',
  f: 'New Licence Letter',
  t_acknowledgement_letter_of_cancellation: 'Acknowledgement Letter of Cancellation',
};
const unique = new Map();
for (const row of selected) {
  const id = String(row.id);
  if (!unique.has(id)) {
    const label = labels[row.f_letter_type];
    if (!label) continue;
    const files = Array.isArray(row.f_attachment) ? row.f_attachment : [];
    unique.set(id, {
      letterId: row.id,
      letterType: row.f_letter_type,
      sentAt: row.f_sendtime,
      dedupeKey: 'nla:letter:' + id,
      legacyDedupeKey: 'letter:sent:' + id + ':' + String(row.f_sendtime),
      legacyEventId: id + ':' + String(row.f_sendtime),
      label,
      content: label + ' recorded as sent.',
      attachmentIds: files.map(value => value?.id).filter(value => value != null),
      snapshot: {
        attachmentIds: files.map(value => value?.id).filter(value => value != null),
      },
    });
  }
}
const notices = [...unique.values()];
return {
  ready: Boolean(valid && notices.length > 0),
  statusName,
  priorStatus: current,
  canonicalId: canonical?.id || null,
  businessId: app.id || null,
  intakeType: app.f_intake_form?.fk_intake_type || null,
  rchNo: app.f_intake_form?.f_intake_source_rch?.f_rch_no
    || canonical?.f_rch_no || null,
  rchName: app.f_intake_form?.f_intake_source_rch?.f_rch_name_en
    || canonical?.f_rch_name || null,
  applicationRef: app.f_p_no || app.f_d_no || app.id || null,
  notices,
  requiredLetterIds: notices.map(item => String(item.letterId)),
};
"""


def advance_script() -> str:
    return r"""const plan = planned || {};
const canonical = Array.isArray(canonicalRows) && canonicalRows.length === 1
  ? canonicalRows[0] : null;
const persisted = Array.isArray(notices) ? notices : [];
if (persisted.length >= 100)
  throw new Error('Notice readback reached its 100-row limit');
const required = Array.isArray(plan.requiredLetterIds) ? plan.requiredLetterIds : [];
const expected = new Map((Array.isArray(plan.notices) ? plan.notices : [])
  .map(item => [String(item.letterId), item]));
const statusId = mappedStatus?.id;
const found = new Set(persisted.filter(row =>
  String(row.fk_api_request || '') === String(plan.canonicalId || '')
  && String(row.f_business_record_id || '') === String(plan.businessId || '')
  && String(row.f_third_party_name || '') === 'OP'
  && String(row.f_source_collection || '') === 't_letter_attachment'
  && statusId != null && String(row.fk_status || '') === String(statusId)
  && (row.fk_letter_attachment != null || row.f_letter_attachment != null)
  && (() => {
    const id = String(row.fk_letter_attachment
      || row.f_letter_attachment?.id || row.f_letter_attachment);
    const item = expected.get(id);
    if (!item) return false;
    const v4 = row.f_dedupe_key === item.dedupeKey
      && row.f_source_event_id === item.dedupeKey
      && String(row.f_source_workflow_key || '') === '75fzv69gij3';
    const v3 = row.f_dedupe_key === item.legacyDedupeKey
      && row.f_source_event_id === item.legacyEventId
      && String(row.f_source_workflow_key || '') === 'i1qob8kae1n';
    return row.f_notice_type === item.letterType
      && String(row.f_source_record_id || '') === id
      && row.f_source_workflow_node === 'Send Letter'
      && (v4 || v3);
  })()
).map(row => String(row.fk_letter_attachment
  || row.f_letter_attachment?.id || row.f_letter_attachment)));
const complete = required.length > 0 && required.every(id => found.has(id));
const current = String(canonical?.f_application_status || '');
const next = String(plan.statusName || '');
const allowed = {
  Confirmed: ['Acknowledged', 'Reminding'],
  Reminding: ['Acknowledged', 'Confirmed'],
  Approved: ['Confirmed', 'Reminding'],
  Closed: ['Received', 'P_Number_Generated', 'Acknowledged',
    'Confirmed', 'Reminding', 'Approved'],
};
return {
  advance: complete && canonical && String(canonical.id) === String(plan.canonicalId)
    && allowed[next]?.includes(current) === true,
  priorStatus: current,
  statusName: next,
  readbackCount: found.size,
};
"""


def node_specs(
    nodes: Mapping[str, Mapping[str, Any]],
) -> dict[str, tuple[str, dict[str, Any]]]:
    app, staging, cover, licence, account = (
        nodes[NLA_APP], nodes[CANONICAL], nodes[COVER], nodes[LICENCE], nodes[ACCOUNT]
    )
    plan, status, loop, existing, readback, guard = (
        nodes[PLAN], nodes[STATUS], nodes[LOOP], nodes[EXISTING],
        nodes[READBACK], nodes[ADVANCE_PLAN]
    )
    return {
        NLA_APP: ("query", query_config(NLA_COLLECTION, [
            {"id": {"$eq": context("f_business_key")}},
        ], appends=("f_intake_form", "f_intake_form.f_intake_source_rch"))),
        NLA_GATE: ("condition", {
            "rejectOnFalse": False, "engine": "basic",
            # Letter category codes are reused by other business types.
            # Only an actual licence application may enter this NLA branch.
            "calculation": {"group": {"type": "and", "calculations": [
                {"calculator": "gt", "operands": [ref(app, "id"), 0]},
            ]}},
        }),
        CANONICAL: ("query", query_config(STAGING_COLLECTION, [
            {"f_application_id": {"$eq": context("f_business_key")}},
            {"f_source_system": {"$eq": "OP"}},
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_api_type": {"$eq": "create_intake_for_new_licence"}},
            {"f_application_type": {"$eq": "new_licence"}},
        ], multiple=True, page_size=2)),
        COVER: ("query", query_config(LETTER_COLLECTION, [
            {"f_business_key": {"$eq": context("f_business_key")}},
            {"f_letter_type": {"$eq": "c"}},
            {"f_is_send": {"$eq": True}},
            {"f_sendtime": {"$notEmpty": True}},
        ], multiple=True, page_size=100, appends=("f_attachment",))),
        LICENCE: ("query", query_config(LETTER_COLLECTION, [
            {"f_business_key": {"$eq": context("f_business_key")}},
            {"f_letter_type": {"$eq": "f"}},
            {"f_is_send": {"$eq": True}},
            {"f_sendtime": {"$notEmpty": True}},
        ], multiple=True, page_size=100, appends=("f_attachment",))),
        ACCOUNT: ("query", query_config(LETTER_COLLECTION, [
            {"f_business_key": {"$eq": context("f_business_key")}},
            {"f_letter_type": {"$eq": "e"}},
            {"f_is_send": {"$eq": True}},
            {"f_sendtime": {"$notEmpty": True}},
        ], multiple=True, page_size=100, appends=("f_attachment",))),
        PLAN: ("script", {
            "arguments": [
                {"name": "letter", "value": "{{$context.data}}"},
                {"name": "application", "value": row_ref(app)},
                {"name": "canonicalRows", "value": row_ref(staging)},
                {"name": "coverLetters", "value": row_ref(cover)},
                {"name": "licenceLetters", "value": row_ref(licence)},
                {"name": "accountLetters", "value": row_ref(account)},
            ],
            "content": plan_script(), "timeout": 5000, "continue": False,
        }),
        READY: ("condition", condition_config([ref(plan, "ready"), True])),
        STATUS: ("query", {
            **query_config(NOTICE_STATUS_COLLECTION, [
                {"f_status": {"$eq": ref(plan, "statusName")}},
            ]),
            "failOnEmpty": True,
        }),
        LOOP: ("loop", {"target": ref(plan, "notices"), "condition": False, "exit": 2}),
        EXISTING: ("query", query_config(NOTICE_COLLECTION, [
            # A v3 Notice may already exist for the first c/f letter.  Check
            # globally by Letter Attachment ID so we never duplicate that
            # letter under another (possibly wrong) CREATE identity.  The
            # post-loop readback below only accepts an exact canonical row.
            {"fk_letter_attachment": {"$eq": scope(loop, "letterId")}},
        ])),
        MISSING: ("condition", condition_config([ref(existing, "id"), None])),
        CREATE: ("create", {
            "collection": NOTICE_COLLECTION,
            "params": {"values": {
                "f_api_request": ref(plan, "canonicalId"),
                "f_third_party_name": "OP",
                "f_intake_type": ref(plan, "intakeType"),
                "f_notice_type": scope(loop, "letterType"),
                "f_letter_attachment": scope(loop, "letterId"),
                "f_rch_no": ref(plan, "rchNo"),
                "f_rch_name": ref(plan, "rchName"),
                "f_business_type_code": NLA_COLLECTION,
                "f_business_record_id": ref(plan, "businessId"),
                "f_business_reference": ref(plan, "applicationRef"),
                "f_business_status_code": "sent",
                "f_business_status_name": scope(loop, "label"),
                "f_status_phrase": scope(loop, "label"),
                "f_status_updated_at": scope(loop, "sentAt"),
                "f_event_code": "LETTER_SENT",
                "f_event_type": "letter_sent",
                "f_source_collection": LETTER_COLLECTION,
                "f_source_record_id": scope(loop, "letterId"),
                "f_source_event_id": scope(loop, "dedupeKey"),
                "f_source_workflow_key": SOURCE_KEY,
                "f_source_workflow_node": "Send Letter",
                "f_dedupe_key": scope(loop, "dedupeKey"),
                "f_title": scope(loop, "label"),
                "f_content": scope(loop, "content"),
                "f_channels": ["record_only", "letter"],
                "f_dispatch_attempts": 0,
                "f_dispatch_status": "recorded",
                "f_external_targets": [],
                "f_process_action": "Send Letter",
                "f_process_status": "sent",
                "f_notify_rank_groups": [],
                "f_recipient_snapshot": scope(loop, "snapshot"),
                "fk_status": ref(status, "id"),
            }, "appends": []},
        }),
        READBACK: ("query", query_config(NOTICE_COLLECTION, [
            {"fk_api_request": {"$eq": ref(plan, "canonicalId")}},
            {"f_business_record_id": {"$eq": ref(plan, "businessId")}},
            {"f_source_collection": {"$eq": LETTER_COLLECTION}},
        ], multiple=True, page_size=100)),
        ADVANCE_PLAN: ("script", {
            "arguments": [
                {"name": "planned", "value": row_ref(plan)},
                {"name": "canonicalRows", "value": row_ref(staging)},
                {"name": "notices", "value": row_ref(readback)},
                {"name": "mappedStatus", "value": row_ref(status)},
            ],
            "content": advance_script(), "timeout": 5000, "continue": False,
        }),
        ADVANCE_GATE: ("condition", condition_config([ref(guard, "advance"), True])),
        ADVANCE: ("update", {
            "collection": STAGING_COLLECTION,
            "params": {
                "individualHooks": False,
                "filter": {"$and": [
                    {"id": {"$eq": ref(plan, "canonicalId")}},
                    {"f_source_system": {"$eq": "OP"}},
                    {"f_request_event": {"$eq": "CREATE"}},
                    {"f_api_type": {"$eq": "create_intake_for_new_licence"}},
                    {"f_application_type": {"$eq": "new_licence"}},
                    {"f_application_id": {"$eq": ref(plan, "businessId")}},
                    {"f_application_status": {"$eq": ref(guard, "priorStatus")}},
                ]},
                "values": {"f_application_status": ref(guard, "statusName")},
                "appends": [],
            },
        }),
    }


def expected_edges(
    source: Mapping[str, Any],
) -> dict[str, tuple[str | None, str | None, int | None]]:
    original = nodes_by_title(source)
    id_to_title = {node["id"]: title for title, node in original.items()}
    edges = {
        title: (
            id_to_title.get(node.get("upstreamId")),
            id_to_title.get(node.get("downstreamId")),
            node.get("branchIndex"),
        )
        for title, node in original.items()
    }
    edges[ORIGINAL_START] = (NLA_GATE, edges[ORIGINAL_START][1], 0)
    edges.update({
        NLA_APP: (None, NLA_GATE, None),
        NLA_GATE: (NLA_APP, None, None),
        CANONICAL: (NLA_GATE, COVER, 1),
        COVER: (CANONICAL, LICENCE, None),
        LICENCE: (COVER, ACCOUNT, None),
        ACCOUNT: (LICENCE, PLAN, None),
        PLAN: (ACCOUNT, READY, None),
        READY: (PLAN, None, None),
        STATUS: (READY, LOOP, 1),
        LOOP: (STATUS, READBACK, None),
        EXISTING: (LOOP, MISSING, 0),
        MISSING: (EXISTING, None, None),
        CREATE: (MISSING, None, 1),
        READBACK: (LOOP, ADVANCE_PLAN, None),
        ADVANCE_PLAN: (READBACK, ADVANCE_GATE, None),
        ADVANCE_GATE: (ADVANCE_PLAN, None, None),
        ADVANCE: (ADVANCE_GATE, None, 1),
    })
    return edges


def required_candidate_config(source: Mapping[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(source["config"])
    require(config.get("changed") == ["f_sendtime"],
            "v3 Send Letter changed-field trigger drifted")
    # Native Send Letter may persist these two fields in either order.  The
    # condition below requires both, so observing either changed field is
    # safe and avoids a permanently missed event.
    config["changed"] = ["f_sendtime", "f_is_send"]
    conditions = config["condition"]["$and"]
    require(conditions == [{"f_sendtime": {"$notEmpty": True}}],
            "v3 Send Letter trigger condition drifted")
    conditions.append({"f_is_send": {"$eq": True}})
    return config


def validate_candidate(
    source: Mapping[str, Any], candidate: Mapping[str, Any], *, complete: bool,
) -> None:
    require(
        isinstance(candidate.get("id"), int)
        and candidate["id"] > SOURCE_ID
        and candidate.get("key") == SOURCE_KEY
        and candidate.get("title") == SOURCE_TITLE
        and candidate.get("enabled") in (True, False)
        and candidate.get("type") == "collection"
        and candidate.get("sync") is False,
        "Candidate Send Letter version identity drifted",
    )
    current = nodes_by_title(candidate)
    source_nodes = nodes_by_title(source)
    ids = [node.get("id") for node in current.values()]
    keys = [node.get("key") for node in current.values()]
    require(
        all(isinstance(value, int) for value in ids)
        and all(isinstance(value, str) and value for value in keys)
        and len(ids) == len(set(ids))
        and len(keys) == len(set(keys)),
        "Candidate node identity is missing or duplicated",
    )
    if not complete:
        require(
            candidate.get("enabled") is False
            and candidate.get("config") == source.get("config")
            and len(current) == SOURCE_NODE_COUNT
            and set(current) == set(source_nodes),
            "Expected a disabled, untouched v3 clone",
        )
        for title in source_nodes:
            require(
                current[title].get("key") == source_nodes[title].get("key")
                and current[title].get("type") == source_nodes[title].get("type")
                and current[title].get("config") == source_nodes[title].get("config"),
                f"v3 clone node drifted: {title}",
            )
        return
    require(
        candidate.get("config") == required_candidate_config(source)
        and len(current) == SOURCE_NODE_COUNT + len(ADDED_TITLES)
        and set(current) == set(source_nodes) | set(ADDED_TITLES),
        "Candidate graph is incomplete or trigger differs",
    )
    expected = node_specs(current)
    expected_links = expected_edges(source)
    id_to_title = {node["id"]: title for title, node in current.items()}
    for title, row in current.items():
        require(row.get("workflowId") == candidate["id"],
                f"Node not in candidate workflow: {title}")
        if title in source_nodes:
            require(
                row.get("key") == source_nodes[title].get("key")
                and row.get("type") == source_nodes[title].get("type")
                and row.get("config") == source_nodes[title].get("config"),
                f"Original v3 node modified: {title}",
            )
        else:
            require((row.get("type"), row.get("config")) == expected[title],
                    f"NLA v4 node config differs: {title}")
        actual_edge = (
            id_to_title.get(row.get("upstreamId")),
            id_to_title.get(row.get("downstreamId")),
            row.get("branchIndex"),
        )
        require(actual_edge == expected_links[title],
                f"NLA v4 edge differs: {title}: {actual_edge!r}")


def workflow_family(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"filter[key]": SOURCE_KEY, "pageSize": 100})
    rows = api.request("GET", "/api/workflows:list?" + query)
    require(isinstance(rows, list) and len(rows) < 100,
            "Send Letter workflow family result incomplete")
    require(all(row.get("key") == SOURCE_KEY for row in rows),
            "Send Letter workflow family changed")
    return [dict(row) for row in rows]


def candidate_id(api: RootNocoBaseApi) -> int | None:
    rows = workflow_family(api)
    require(sum(row.get("id") == SOURCE_ID for row in rows) == 1,
            "Audited Send Letter source version missing")
    newer = [int(row["id"]) for row in rows if int(row["id"]) > SOURCE_ID]
    require(len(newer) <= 1, "Unexpected extra Send Letter revisions")
    require(all(not row.get("enabled") for row in rows
                if int(row["id"]) < SOURCE_ID),
            "Older Send Letter version unexpectedly enabled")
    return newer[0] if newer else None


def has_execution(api: RootNocoBaseApi, workflow_id: int) -> bool:
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(workflow_id), "pageSize": 1}
    )
    rows = api.request("GET", "/api/executions:list?" + query)
    require(isinstance(rows, list), "Execution history query failed")
    return bool(rows)


def status_rows(api: RootNocoBaseApi, name: str) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"filter[f_status]": name, "pageSize": 2})
    rows = api.request("GET", f"/api/{NOTICE_STATUS_COLLECTION}:list?{query}")
    require(isinstance(rows, list) and len(rows) <= 1,
            f"Notice status {name!r} missing uniqueness")
    return list(rows)


def ensure_closed_status(api: RootNocoBaseApi, *, create: bool) -> int | None:
    rows = status_rows(api, "Closed")
    if not rows and create:
        values = {
            "f_status": "Closed",
            "f_meaning": (
                "Application closure acknowledged by a sent cancellation letter"
            ),
            "f_update_allowed": False,
            "f_recommended_query_data": "application_data, notices",
            "f_sort": 9,
        }
        try:
            api.request("POST", f"/api/{NOTICE_STATUS_COLLECTION}:create", values)
        except ApiError:
            # A transport failure may follow a committed write.  Only exact
            # readback is accepted; anything else remains a visible failure.
            rows = status_rows(api, "Closed")
            require(rows and all(rows[0].get(k) == v for k, v in values.items()),
                    "Closed status create outcome uncertain")
        rows = status_rows(api, "Closed")
    if rows:
        row = rows[0]
        require(row.get("f_status") == "Closed"
                and row.get("f_update_allowed") is False,
                "Closed status row differs from contract")
        return int(row["id"])
    return None


def validate_schema(api: RootNocoBaseApi, *, require_closed: bool) -> None:
    for name in ("Confirmed", "Reminding", "Approved"):
        require(len(status_rows(api, name)) == 1,
                f"Notice status dictionary lacks {name}")
    rejected = status_rows(api, "Rejected")
    require(len(rejected) == 1,
            "Historical Rejected dictionary row must remain intact")
    if require_closed:
        require(ensure_closed_status(api, create=False) is not None,
                "Closed dictionary status has not been prepared")
    required_fields = {
        NOTICE_COLLECTION: (
            "f_dedupe_key", "f_event_code", "f_letter_attachment",
            "f_api_request", "fk_status", "f_content",
        ),
        STAGING_COLLECTION: (
            "f_application_id", "f_application_status", "f_application_type",
            "f_source_system", "f_request_event", "f_api_type",
        ),
        LETTER_COLLECTION: (
            "f_letter_type", "f_is_send", "f_sendtime", "f_business_key",
            "f_attachment",
        ),
        NLA_COLLECTION: ("f_approval_status", "f_intake_form"),
    }
    for collection, names in required_fields.items():
        for field_name in names:
            field = api.request(
                "GET",
                f"/api/collections/{collection}/fields:get?"
                + urllib.parse.urlencode({"filterByTk": field_name}),
            )
            require(isinstance(field, dict) and field.get("name") == field_name,
                    f"Required {collection}.{field_name} field missing")
            if collection == NOTICE_COLLECTION and field_name == "f_dedupe_key":
                require(field.get("unique") is True,
                        "Notice dedupe key must be unique")
    letter_type = api.request("GET", "/api/collections/t_letter_attachment/fields:get?"
                              + urllib.parse.urlencode({"filterByTk": "f_letter_type"}))
    values = {row.get("value") for row in
              (letter_type or {}).get("uiSchema", {}).get("enum", [])}
    require(NLA_LETTER_TYPES.issubset(values),
            "Native NLA/cancellation letter type enum differs")


def set_enabled(api: RootNocoBaseApi, workflow_id: int, desired: bool) -> None:
    current = api.get_workflow(workflow_id)
    require(isinstance(current.get("enabled"), bool), "Enabled state unknown")
    if current["enabled"] is not desired:
        api.request("POST", f"/api/workflows:update?filterByTk={workflow_id}",
                    {"enabled": desired})
    require(api.get_workflow(workflow_id).get("enabled") is desired,
            f"Workflow {workflow_id} enable readback failed")


def create_revision(api: RootNocoBaseApi, source: Mapping[str, Any]) -> int:
    require(candidate_id(api) is None, "A newer Send Letter revision already exists")
    require(source.get("enabled") is True, "v3 must be active before prepare")
    print(f"prepare_gap_start_utc={now_utc()}", flush=True)
    revision_id: int | None = None
    try:
        set_enabled(api, SOURCE_ID, False)
        query = urllib.parse.urlencode(
            {"filterByTk": SOURCE_ID, "filter[key]": SOURCE_KEY}
        )
        try:
            result = api.request("POST", "/api/workflows:revision?" + query, {})
            if isinstance(result, dict) and isinstance(result.get("id"), int):
                revision_id = result["id"]
        except ApiError:
            pass
        discovered = candidate_id(api)
        require(discovered is not None
                and (revision_id is None or revision_id == discovered),
                "Revision outcome uncertain; inspect family before retry")
        revision_id = discovered
        set_enabled(api, revision_id, False)
        validate_candidate(source, api.get_workflow(revision_id), complete=False)
    finally:
        discovered = candidate_id(api)
        if discovered is not None:
            set_enabled(api, discovered, False)
        set_enabled(api, SOURCE_ID, True)
        print(f"prepare_gap_end_utc={now_utc()}", flush=True)
        print("gap_audit=Reconcile Send Letter events within these UTC bounds")
    require(revision_id is not None, "Revision was not created")
    return revision_id


def ensure_node(
    api: RootNocoBaseApi, workflow_id: int, title: str,
    kind: str, config: Mapping[str, Any],
) -> dict[str, Any]:
    current = nodes_by_title(api.get_workflow(workflow_id))
    if title in current:
        node = current[title]
        require((node.get("type"), node.get("config")) == (kind, dict(config)),
                f"Existing candidate node differs: {title}")
        return node
    try:
        api.create_node({"workflowId": workflow_id, "type": kind,
                         "title": title, "config": dict(config)})
    except ApiError:
        pass
    current = nodes_by_title(api.get_workflow(workflow_id))
    require(title in current, f"Create node outcome uncertain: {title}")
    node = current[title]
    require((node.get("type"), node.get("config")) == (kind, dict(config)),
            f"Created node differs: {title}")
    return node


def patch_node(api: RootNocoBaseApi, workflow_id: int,
               title: str, values: Mapping[str, Any]) -> None:
    row = nodes_by_title(api.get_workflow(workflow_id))[title]
    if all(row.get(k) == v for k, v in values.items()):
        return
    try:
        api.update_node(int(row["id"]), values)
    except ApiError:
        pass
    after = nodes_by_title(api.get_workflow(workflow_id))[title]
    require(all(after.get(k) == v for k, v in values.items()),
            f"Node patch outcome uncertain: {title}")


def prepare(api: RootNocoBaseApi) -> int:
    validate_schema(api, require_closed=False)
    source = api.get_workflow(SOURCE_ID)
    validate_source(source)
    require(source.get("enabled") is True, "Source v3 must be enabled")
    revision_id = candidate_id(api)
    if revision_id is None:
        revision_id = create_revision(api, source)
    candidate = api.get_workflow(revision_id)
    require(candidate.get("enabled") is False,
            "Candidate must remain disabled throughout prepare")
    require(not has_execution(api, revision_id),
            "An executed candidate cannot be edited; inspect before continuing")
    # The dictionary row is a stand-alone additive collection change; the
    # historical Rejected status remains exactly as it was.
    ensure_closed_status(api, create=True)
    current = nodes_by_title(candidate)
    for title in ADDED_TITLES:
        if title not in current:
            # Node configs reference stable node keys.  First allocate all
            # identities with a harmless sentinel, then set exact configs.
            ensure_node(api, revision_id, title, _node_kinds()[title], {})
            current = nodes_by_title(api.get_workflow(revision_id))
    specs = node_specs(current)
    for title in ADDED_TITLES:
        kind, config = specs[title]
        require(current[title]["type"] == kind, f"Node type drift: {title}")
        patch_node(api, revision_id, title, {"config": config})
    edges = expected_edges(source)
    by_title = nodes_by_title(api.get_workflow(revision_id))
    for title, (upstream, downstream, branch) in edges.items():
        patch_node(api, revision_id, title, {
            "upstreamId": by_title[upstream]["id"] if upstream else None,
            "downstreamId": by_title[downstream]["id"] if downstream else None,
            "branchIndex": branch,
        })
    config = required_candidate_config(source)
    candidate = api.get_workflow(revision_id)
    if candidate.get("config") != config:
        try:
            api.request("POST", f"/api/workflows:update?filterByTk={revision_id}",
                        {"config": config})
        except ApiError:
            pass
    validate_candidate(source, api.get_workflow(revision_id), complete=True)
    validate_source(api.get_workflow(SOURCE_ID))
    require(api.get_workflow(SOURCE_ID).get("enabled") is True,
            "v3 stopped during prepare")
    return revision_id


def _node_kinds() -> dict[str, str]:
    return {
        NLA_APP: "query", NLA_GATE: "condition", CANONICAL: "query",
        COVER: "query", LICENCE: "query", ACCOUNT: "query",
        PLAN: "script", READY: "condition", STATUS: "query",
        LOOP: "loop", EXISTING: "query", MISSING: "condition",
        CREATE: "create", READBACK: "query", ADVANCE_PLAN: "script",
        ADVANCE_GATE: "condition", ADVANCE: "update",
    }


def checked_pair(api: RootNocoBaseApi,
                 *, source_enabled: bool, candidate_enabled: bool
                 ) -> tuple[dict[str, Any], dict[str, Any]]:
    source = dict(api.get_workflow(SOURCE_ID))
    validate_source(source)
    require(source.get("enabled") is source_enabled,
            "Source Send Letter enabled state differs")
    revision_id = candidate_id(api)
    require(revision_id is not None, "Prepared v4 revision missing")
    candidate = dict(api.get_workflow(revision_id))
    require(candidate.get("enabled") is candidate_enabled,
            "Candidate Send Letter enabled state differs")
    validate_candidate(source, candidate, complete=True)
    require(not (source_enabled and candidate_enabled),
            "Both Send Letter versions cannot be active")
    return source, candidate


def cutover(api: RootNocoBaseApi) -> int:
    validate_schema(api, require_closed=True)
    _, candidate = checked_pair(api, source_enabled=True, candidate_enabled=False)
    revision_id = int(candidate["id"])
    print(f"cutover_gap_start_utc={now_utc()}", flush=True)
    try:
        set_enabled(api, SOURCE_ID, False)
        set_enabled(api, revision_id, True)
        checked_pair(api, source_enabled=False, candidate_enabled=True)
    except Exception as exc:
        try:
            set_enabled(api, revision_id, False)
            set_enabled(api, SOURCE_ID, True)
            checked_pair(api, source_enabled=True, candidate_enabled=False)
        except Exception as rollback_exc:
            try:
                # A source-enable response may be lost after it committed.
                # Turn it off before activating the already-reviewed v4 graph
                # so a failed cutover cannot leave both versions running.
                set_enabled(api, SOURCE_ID, False)
                set_enabled(api, revision_id, True)
                checked_pair(api, source_enabled=False, candidate_enabled=True)
            except Exception as restore_exc:
                raise ApiError(
                    f"Cutover failed ({exc}); restoring v3 failed "
                    f"({rollback_exc}); restoring v4 also failed "
                    f"({restore_exc}); inspect enabled flags immediately"
                ) from restore_exc
            raise ApiError(
                f"Cutover failed ({exc}); restoring v3 failed "
                f"({rollback_exc}); reviewed v4 is active"
            ) from rollback_exc
        raise ApiError(f"Cutover failed; v3 restored: {exc}") from exc
    finally:
        print(f"cutover_gap_end_utc={now_utc()}", flush=True)
        print("gap_audit=Reconcile Send Letter events within these UTC bounds")
    return revision_id


def rollback(api: RootNocoBaseApi) -> None:
    _, candidate = checked_pair(api, source_enabled=False, candidate_enabled=True)
    revision_id = int(candidate["id"])
    print(f"rollback_gap_start_utc={now_utc()}", flush=True)
    try:
        set_enabled(api, revision_id, False)
        set_enabled(api, SOURCE_ID, True)
        checked_pair(api, source_enabled=True, candidate_enabled=False)
    except Exception as exc:
        try:
            # Source activation may have committed before its response failed.
            # Keep the two versions mutually exclusive while restoring the
            # already-reviewed candidate as the safe operational fallback.
            set_enabled(api, SOURCE_ID, False)
            set_enabled(api, revision_id, True)
            checked_pair(api, source_enabled=False, candidate_enabled=True)
        except Exception as restore_exc:
            raise ApiError(
                f"Rollback failed ({exc}); restoring v4 also failed "
                f"({restore_exc}); inspect enabled flags immediately"
            ) from restore_exc
        raise ApiError(f"Rollback failed ({exc}); v4 restored") from exc
    finally:
        print(f"rollback_gap_end_utc={now_utc()}", flush=True)
        print("gap_audit=Reconcile Send Letter events within these UTC bounds")


def audit(api: RootNocoBaseApi) -> None:
    validate_schema(api, require_closed=False)
    source = api.get_workflow(SOURCE_ID)
    validate_source(source)
    revision_id = candidate_id(api)
    phase = "absent"
    candidate_enabled = None
    if revision_id is not None:
        candidate = api.get_workflow(revision_id)
        candidate_enabled = candidate.get("enabled")
        require(not (source.get("enabled") and candidate_enabled),
                "Both Send Letter versions are enabled")
        try:
            validate_candidate(source, candidate, complete=True)
            phase = "active" if candidate_enabled else "prepared"
        except ApiError:
            # A partial revision is never treated as ready for cutover.
            phase = "partial-or-clone-disabled"
            require(candidate_enabled is False,
                    "Incomplete Send Letter v4 graph is enabled")
    print(f"source_id={SOURCE_ID} enabled={str(source.get('enabled')).lower()}")
    print(f"source_fingerprint={source_fingerprint(source)}")
    print(f"candidate_id={revision_id} enabled={candidate_enabled} phase={phase}")
    print(f"closed_status_id={ensure_closed_status(api, create=False)}")
    print("scope=NLA OP CREATE only; non-NLA v3 graph preserved")
    print("approved_gate=sent c+f pair; no early Approved Notice")
    print("legacy_v3=accept exact canonical sent-letter Notice; never duplicate")
    print("callback=not configured")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("audit", "prepare", "cutover", "rollback", "verify")
    )
    parser.add_argument("--base-url", default=BASE_URL)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--ack-brief-nonatomic-cutover", action="store_true")
    args = parser.parse_args(argv)
    if args.base_url.rstrip("/") != BASE_URL:
        parser.error("Only the 13001 DEV NocoBase is in scope")
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        parser.error("NOCOBASE_TOKEN is required")
    api = RootNocoBaseApi(BASE_URL, token)
    try:
        if args.command in ("audit", "verify"):
            audit(api)
            if args.command == "verify":
                _, candidate = checked_pair(
                    api, source_enabled=False, candidate_enabled=True
                )
                print(f"verified_active_v4_id={candidate['id']}")
            return 0
        if not args.apply:
            audit(api)
            print(f"mode=read-only planned_command={args.command}")
            return 0
        if not args.ack_brief_nonatomic_cutover:
            parser.error("--apply requires --ack-brief-nonatomic-cutover")
        if args.command == "prepare":
            print(f"prepared_candidate_id={prepare(api)}")
        elif args.command == "cutover":
            print(f"active_candidate_id={cutover(api)}")
        else:
            rollback(api)
            print(f"restored_source_id={SOURCE_ID}")
    except ApiError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
