#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_TOOL="$ROOT_DIR/scripts/manage_environment.py"

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <development|local_test|online_test> [compose command ...]" >&2
  echo "Example: $0 development up -d --build" >&2
  exit 2
fi

ENVIRONMENT="$1"
shift

case "$ENVIRONMENT" in
  development|local_test|online_test)
    ;;
  *)
    echo "error=$ENVIRONMENT is not a Docker Compose environment" >&2
    echo "allowed=development,local_test,online_test" >&2
    exit 2
    ;;
esac

if [[ -x "$ROOT_DIR/.venv/bin/python" ]]; then
  PYTHON_BIN="${PYTHON_BIN:-$ROOT_DIR/.venv/bin/python}"
else
  PYTHON_BIN="${PYTHON_BIN:-python3}"
fi

"$PYTHON_BIN" "$PROFILE_TOOL" validate "$ENVIRONMENT"

profile_value() {
  "$PYTHON_BIN" "$PROFILE_TOOL" value "$ENVIRONMENT" "$1"
}

COMPOSE_ENV_FILE="$ROOT_DIR/$(profile_value compose_env_file)"
SECRET_FILE="$ROOT_DIR/$(profile_value secret_file)"

if [[ ! -s "$SECRET_FILE" ]]; then
  echo "error=required Secret file is missing or empty: $SECRET_FILE" >&2
  exit 1
fi

if docker compose version >/dev/null 2>&1; then
  COMPOSE=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
  COMPOSE=(docker-compose)
else
  echo "error=Docker Compose is not installed" >&2
  exit 1
fi

if ! docker version >/dev/null 2>&1; then
  echo "error=Docker daemon is not running" >&2
  exit 1
fi

if [[ $# -eq 0 ]]; then
  set -- up -d --build
fi

cd "$ROOT_DIR"
echo "environment=$ENVIRONMENT"
echo "compose_env_file=$COMPOSE_ENV_FILE"
echo "secret_file=$SECRET_FILE"
echo "command=${COMPOSE[*]} --env-file $COMPOSE_ENV_FILE -f $ROOT_DIR/docker-compose.yml $*"
exec "${COMPOSE[@]}" --env-file "$COMPOSE_ENV_FILE" \
  -f "$ROOT_DIR/docker-compose.yml" "$@"
