#!/usr/bin/env python3
"""Add application enum and timestamps on t_approval_log.

Does not create a Notice Board listener. Collection events are only useful
after this field exists; Add Approval Log already writes through hooks.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_notice_board_collection import RootNocoBaseApi, field_names
from extend_nocobase_staging_relations import ApiError, NocoBaseApi


def ensure_field(api: NocoBaseApi, values: Mapping[str, Any]) -> None:
    name = str(values["name"])
    existing = field_names(api, COLLECTION)
    if name in existing:
        print(f"existing_field={name}")
        return
    api.request(
        "POST",
        f"/api/collections/{COLLECTION}/fields:create",
        dict(values),
    )
    created = api.request(
        "GET",
        f"/api/collections/{COLLECTION}/fields:get?"
        + urllib.parse.urlencode({"filterByTk": name}),
    )
    if not isinstance(created, dict) or created.get("name") != name:
        raise ApiError(f"{name} was not created on {COLLECTION}")
    print(f"created_field={name}")

COLLECTION = "t_approval_log"
ADD_APPROVAL_LOG_TITLE = "Add Approval Log"
APPLICATION_FIELD = "f_application"


def application_enum(api: NocoBaseApi) -> list[dict[str, str]]:
    rows = api.request(
        "GET",
        "/api/t_status_name_map:list?"
        + urllib.parse.urlencode({"pageSize": 200, "paginate": "false"}),
    )
    options = []
    seen: set[str] = set()
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        value = str(row.get("f_code") or "").strip()
        label = str(row.get("f_name") or value).strip()
        if not value or value in seen or not value.startswith("t_"):
            continue
        seen.add(value)
        options.append({"value": value, "label": label})
    if not options:
        raise ApiError("t_status_name_map returned no application codes")
    return options


def enabled_add_approval_log(api: NocoBaseApi) -> dict[str, Any]:
    rows = api.request(
        "GET",
        "/api/workflows:list?"
        + urllib.parse.urlencode(
            {"pageSize": 200, "filter[title]": ADD_APPROVAL_LOG_TITLE}
        ),
    )
    current = [
        row
        for row in (rows or [])
        if isinstance(row, dict)
        and row.get("title") == ADD_APPROVAL_LOG_TITLE
        and row.get("enabled")
        and row.get("current")
    ]
    if len(current) != 1:
        raise ApiError(
            f"expected one enabled current {ADD_APPROVAL_LOG_TITLE!r}, "
            f"found {len(current)}"
        )
    workflow = api.get_workflow(int(current[0]["id"]))
    return dict(workflow)


def list_approval_log_listeners(api: NocoBaseApi) -> list[dict[str, Any]]:
    rows = api.request(
        "GET",
        "/api/workflows:list?"
        + urllib.parse.urlencode({"pageSize": 200, "paginate": "false"}),
    )
    found = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        config = row.get("config") or {}
        if row.get("type") != "collection":
            continue
        if config.get("collection") != COLLECTION:
            continue
        found.append(
            {
                "id": row.get("id"),
                "title": row.get("title"),
                "enabled": row.get("enabled"),
                "sync": row.get("sync"),
                "mode": config.get("mode"),
                "changed": config.get("changed"),
                "condition": config.get("condition"),
            }
        )
    return found


def summarize_add_approval_log(workflow: Mapping[str, Any]) -> dict[str, Any]:
    creates = []
    updates = []
    for node in workflow.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        config = node.get("config") or {}
        params = config.get("params") or {}
        if config.get("collection") != COLLECTION:
            continue
        item = {
            "id": node.get("id"),
            "key": node.get("key"),
            "title": node.get("title"),
            "individualHooks": params.get("individualHooks"),
            "has_application": APPLICATION_FIELD in (params.get("values") or {}),
        }
        if node.get("type") == "create":
            creates.append(item)
        elif node.get("type") == "update":
            updates.append(item)
    return {
        "id": workflow.get("id"),
        "key": workflow.get("key"),
        "enabled": workflow.get("enabled"),
        "sync": workflow.get("sync"),
        "type": workflow.get("type"),
        "create_nodes": creates,
        "update_nodes": updates,
    }


def enable_timestamps(api: NocoBaseApi) -> None:
    api.request(
        "POST",
        f"/api/collections:update?filterByTk={COLLECTION}",
        {
            "createdAt": True,
            "updatedAt": True,
            "timestamps": True,
        },
    )
    print("timestamps=createdAt,updatedAt")


def ensure_timestamp_fields(api: NocoBaseApi) -> None:
    ensure_field(
        api,
        {
            "name": "createdAt",
            "type": "date",
            "interface": "createdAt",
            "uiSchema": {
                "type": "datetime",
                "title": '{{t("Created at")}}',
                "x-component": "DatePicker",
                "x-component-props": {
                    "picker": "date",
                    "dateFormat": "YYYY-MM-DD HH:mm",
                    "showTime": True,
                },
                "x-read-pretty": True,
            },
        },
    )
    ensure_field(
        api,
        {
            "name": "updatedAt",
            "type": "date",
            "interface": "updatedAt",
            "uiSchema": {
                "type": "datetime",
                "title": '{{t("Last updated at")}}',
                "x-component": "DatePicker",
                "x-component-props": {
                    "picker": "date",
                    "dateFormat": "YYYY-MM-DD HH:mm",
                    "showTime": True,
                },
                "x-read-pretty": True,
            },
        },
    )


def ensure_application_field(
    api: NocoBaseApi, options: list[dict[str, str]]
) -> None:
    existing = field_names(api, COLLECTION)
    payload = {
        "name": APPLICATION_FIELD,
        "type": "string",
        "interface": "select",
        "uiSchema": {
            "type": "string",
            "title": "Application",
            "x-component": "Select",
            "enum": options,
        },
    }
    if APPLICATION_FIELD in existing:
        api.request(
            "POST",
            f"/api/collections/{COLLECTION}/fields:update?"
            + urllib.parse.urlencode({"filterByTk": APPLICATION_FIELD}),
            payload,
        )
        print(f"updated_field={APPLICATION_FIELD} options={len(options)}")
        return
    ensure_field(api, payload)


def patch_create_nodes(api: NocoBaseApi, workflow: Mapping[str, Any]) -> None:
    for node in workflow.get("nodes") or []:
        if node.get("type") != "create":
            continue
        config = copy.deepcopy(node.get("config") or {})
        if config.get("collection") != COLLECTION:
            continue
        params = config.setdefault("params", {})
        values = params.setdefault("values", {})
        if values.get(APPLICATION_FIELD):
            print(f"existing_create_application node={node.get('id')}")
            continue
        values[APPLICATION_FIELD] = (
            "{{$jobsMapByNodeKey.epklglptdw4.CollectionName}}"
        )
        api.update_node(int(node["id"]), {"config": config})
        print(f"patched_create_application node={node.get('id')}")


def print_plan(
    options: list[dict[str, str]],
    listeners: list[dict[str, Any]],
    summary: Mapping[str, Any],
) -> None:
    print(f"collection={COLLECTION}")
    print(f"application_options={len(options)}")
    for item in options:
        print(f"  {item['value']}={item['label']}")
    print("timestamps=createdAt,updatedAt currently_missing")
    print(f"collection_listeners={len(listeners)}")
    if listeners:
        print(json.dumps(listeners, ensure_ascii=False))
    else:
        print("collection_listeners=none")
    print(
        "add_approval_log="
        + json.dumps(summary, ensure_ascii=False, separators=(",", ":"))
    )
    print("storm=create_and_update_hooks_open")
    print("notice_listener=not_created")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://119.91.104.211:13001/cmtf2"
    )
    parser.add_argument("--apply", action="store_true")
    parser.add_argument(
        "--patch-add-approval-log",
        action="store_true",
        help="Write f_application on Add Approval Log create nodes",
    )
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    options = application_enum(api)
    listeners = list_approval_log_listeners(api)
    workflow = enabled_add_approval_log(api)
    summary = summarize_add_approval_log(workflow)
    print_plan(options, listeners, summary)
    if not args.apply:
        print("mode=dry-run")
        return 0

    enable_timestamps(api)
    ensure_timestamp_fields(api)
    ensure_application_field(api, options)
    if args.patch_add_approval_log:
        patch_create_nodes(api, workflow)
    print("status=ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
