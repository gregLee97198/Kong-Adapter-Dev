#!/usr/bin/env python3
"""Approval Log Sync Data: fill missing fields and persist Notice Board.

Create: copy f_collection_name onto f_application.
Update: one shared Status Name Map check, then a multi-condition source
branch. Add a new condition + resolve path to support more applications.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_notice_board_collection import RootNocoBaseApi
from create_nocobase_phase_c_chi_workflows import create_node, link
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import destroy_workflow_nodes, revision_workflow

TITLE = "Approval Log Sync Data"
COLLECTION = "t_approval_log"
NLA_COLLECTION = "t_licence_app"
INTAKE_COLLECTION = "t_intake_form"
MAP_COLLECTION = "t_status_name_map"
DETAILS_COLLECTION = "t_status_name_map_details"
NOTICE_COLLECTION = "t_notice_board"
NLA_INTAKE_TYPE_ID = 364490020880384
TRIGGER_CONDITION = {
    "$and": [
        {"f_collection_name": {"$notEmpty": True}},
        {
            "$or": [
                {"f_application": {"$empty": True}},
                {"f_completed_date": {"$notEmpty": True}},
            ]
        },
    ]
}


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str) -> str:
    return "{{$jobsMapByNodeKey." + str(node["key"]) + "." + field + "}}"


def load_workflow(api: NocoBaseApi) -> dict[str, Any]:
    rows = api.request(
        "GET",
        "/api/workflows:list?"
        + urllib.parse.urlencode({"pageSize": 100, "filter[title]": TITLE}),
    )
    found = [
        row
        for row in (rows or [])
        if isinstance(row, dict) and row.get("title") == TITLE and row.get("current")
    ]
    if len(found) != 1 or found[0].get("id") is None:
        raise ApiError(f"expected one current workflow titled {TITLE!r}")
    return dict(api.get_workflow(int(found[0]["id"])))


def configure_trigger(api: NocoBaseApi, workflow_id: int) -> None:
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow_id}",
        {
            "sync": False,
            "enabled": False,
            "config": {
                "mode": 3,
                "collection": COLLECTION,
                "changed": ["f_status", "f_completed_date"],
                "appends": [],
                "condition": TRIGGER_CONDITION,
            },
        },
    )


def query_config(
    collection: str,
    filters: list[dict[str, Any]],
    *,
    appends: tuple[str, ...] = (),
    sort: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": False,
        "params": {
            "filter": {"$and": filters},
            "sort": list(sort or []),
            "page": 1,
            "pageSize": 1,
            "appends": list(appends),
        },
    }


def exists_config(node: Mapping[str, Any], *, reject_on_false: bool) -> dict[str, Any]:
    return basic_condition(
        [{"calculator": "gt", "operands": [ref(node, "id"), 0]}],
        reject_on_false=reject_on_false,
    )


def basic_condition(
    calculations: list[dict[str, Any]],
    *,
    reject_on_false: bool,
    group_type: str = "and",
) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject_on_false,
        "engine": "basic",
        "calculation": {
            "group": {"type": group_type, "calculations": calculations}
        },
    }


def assigned_field(collection: str, name: str) -> dict[str, Any]:
    return {
        "_isJSONSchemaObject": True,
        "version": "2.0",
        "type": "string",
        "name": name,
        "x-toolbar": "FormItemSchemaToolbar",
        "x-settings": "fieldSettings:FormItem",
        "x-component": "AssignedField",
        "x-decorator": "FormItem",
        "x-collection-field": f"{collection}.{name}",
    }


def assign_form_schema(collection: str, *names: str) -> dict[str, Any]:
    properties: dict[str, Any] = {}
    for index, name in enumerate(names):
        row = f"row_{name}"
        col = f"col_{name}"
        properties[row] = {
            "_isJSONSchemaObject": True,
            "version": "2.0",
            "type": "void",
            "name": row,
            "x-component": "Grid.Row",
            "x-index": index,
            "properties": {
                col: {
                    "_isJSONSchemaObject": True,
                    "version": "2.0",
                    "type": "void",
                    "name": col,
                    "x-component": "Grid.Col",
                    "properties": {name: assigned_field(collection, name)},
                }
            },
        }
    return {
        "_isJSONSchemaObject": True,
        "version": "2.0",
        "name": f"{collection}Assign",
        "type": "void",
        "x-component": "Grid",
        "x-initializer": "assignFieldValuesForm:configureFields",
        "properties": properties,
    }


def persist_config(status_map: Mapping[str, Any], details: Mapping[str, Any]) -> dict[str, Any]:
    """Completed + map enabled + node persist + matching log status."""
    return {
        "rejectOnFalse": False,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {
                        "calculator": "notEqual",
                        "operands": [context("f_completed_date"), None],
                    },
                    {"calculator": "gt", "operands": [ref(status_map, "id"), 0]},
                    {"calculator": "gt", "operands": [ref(details, "id"), 0]},
                    {
                        "group": {
                            "type": "or",
                            "calculations": [
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        ref(details, "f_notice_log_status"),
                                        context("f_status"),
                                    ],
                                },
                                {
                                    "group": {
                                        "type": "and",
                                        "calculations": [
                                            {
                                                "calculator": "equal",
                                                "operands": [
                                                    ref(details, "f_notice_log_status"),
                                                    None,
                                                ],
                                            },
                                            {
                                                "group": {
                                                    "type": "or",
                                                    "calculations": [
                                                        {
                                                            "calculator": "equal",
                                                            "operands": [
                                                                context("f_status"),
                                                                "5",
                                                            ],
                                                        },
                                                        {
                                                            "calculator": "equal",
                                                            "operands": [
                                                                context("f_status"),
                                                                "6",
                                                            ],
                                                        },
                                                        {
                                                            "calculator": "equal",
                                                            "operands": [
                                                                context("f_status"),
                                                                "11",
                                                            ],
                                                        },
                                                    ],
                                                }
                                            },
                                        ],
                                    }
                                },
                            ],
                        }
                    },
                ],
            }
        },
    }


def source_branch(uid: str, title: str, collection: str) -> dict[str, Any]:
    return {
        "uid": uid,
        "title": title,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "or",
                "calculations": [
                    {
                        "calculator": "equal",
                        "operands": [context("f_collection_name"), collection],
                    },
                    {
                        "calculator": "equal",
                        "operands": [context("f_application"), collection],
                    },
                ],
            }
        },
    }


def notice_values(
    details: Mapping[str, Any],
    staging: Mapping[str, Any],
    intake_type: str,
    home: Mapping[str, Any],
    letter: Mapping[str, Any] | None = None,
    *,
    content: str | None = None,
) -> dict[str, Any]:
    values = {
        "f_third_party_name": "OP",
        "f_notice_type": ref(details, "f_notice_type"),
        "f_api_request": ref(staging, "id"),
        "f_intake_type": intake_type,
        "f_rch_no": ref(home, "f_rch_no"),
        "f_rch_name": ref(home, "f_rch_name_en"),
        "f_status": ref(details, "fk_notice_board_status"),
        "f_status_updated_at": context("f_completed_date"),
        "f_content": context("f_comments") if content is None else content,
    }
    if letter is not None:
        values["f_letter_attachment"] = ref(letter, "id")
    return values


def install_notice_path(
    api: NocoBaseApi,
    workflow_id: int,
    *,
    prefix: str,
    source_row: Mapping[str, Any],
    details: Mapping[str, Any],
    staging_filters: list[dict[str, Any]],
    intake_type: str,
    home_filters: list[dict[str, Any]],
    content: str | None = None,
    letter_filters: list[dict[str, Any]] | None = None,
) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        f"Query {prefix} CREATE staging",
        query_config("t_api_request_staging", staging_filters),
    )
    ready = create_node(
        api,
        workflow_id,
        "condition",
        f"{prefix} and CREATE staging exist",
        basic_condition(
            [
                {"calculator": "gt", "operands": [ref(source_row, "id"), 0]},
                {"calculator": "gt", "operands": [ref(staging, "id"), 0]},
            ],
            reject_on_false=False,
        ),
    )
    home = create_node(
        api,
        workflow_id,
        "query",
        f"Query {prefix} Home Record",
        query_config("t_home_record", home_filters),
    )
    write = install_notice_write(
        api,
        workflow_id,
        prefix=prefix,
        details=details,
        staging=staging,
        intake_type=intake_type,
        home=home,
        content=context("f_comments") if content is None else content,
        letter_filters=letter_filters,
    )
    link(api, source_row, staging)
    link(api, staging, ready)
    link(api, ready, home, branch_index=1)
    link(api, home, write)


def install_notice_write(
    api: NocoBaseApi,
    workflow_id: int,
    *,
    prefix: str,
    details: Mapping[str, Any],
    staging: Mapping[str, Any],
    intake_type: str,
    home: Mapping[str, Any],
    content: str,
    letter_filters: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Letter lookup + create/update Notice. Returns the first node."""
    filters = [
        {"f_business_key": {"$eq": context("f_data_key")}},
        {"f_letter_type": {"$eq": ref(details, "f_notice_type")}},
    ]
    if letter_filters:
        filters.extend(letter_filters)
    letter = create_node(
        api,
        workflow_id,
        "query",
        f"Query {prefix} letter",
        query_config(
            "t_letter_attachment",
            filters,
            sort=[{"field": "id", "direction": "desc"}],
        ),
    )
    existing = create_node(
        api,
        workflow_id,
        "query",
        f"Query {prefix} existing Notice",
        query_config(
            NOTICE_COLLECTION,
            [
                {"fk_api_request": {"$eq": ref(staging, "id")}},
                {"f_notice_type": {"$eq": ref(details, "f_notice_type")}},
            ],
        ),
    )
    notice_exists = create_node(
        api,
        workflow_id,
        "condition",
        f"{prefix} Notice already exists",
        exists_config(existing, reject_on_false=False),
    )
    create_fields = (
        "f_third_party_name",
        "f_notice_type",
        "f_api_request",
        "f_intake_type",
        "f_rch_no",
        "f_rch_name",
        "f_status",
        "f_status_updated_at",
        "f_content",
        "f_letter_attachment",
    )
    update_fields = create_fields[:-1]
    create_notice = create_node(
        api,
        workflow_id,
        "create",
        f"Create {prefix} Notice Board",
        {
            "collection": NOTICE_COLLECTION,
            "usingAssignFormSchema": True,
            "assignFormSchema": assign_form_schema(
                NOTICE_COLLECTION, *create_fields
            ),
            "params": {
                "values": notice_values(
                    details,
                    staging,
                    intake_type,
                    home,
                    letter,
                    content=content,
                ),
                "appends": [],
            },
        },
    )
    update_notice = create_node(
        api,
        workflow_id,
        "update",
        f"Fill {prefix} Notice Board",
        {
            "collection": NOTICE_COLLECTION,
            "usingAssignFormSchema": True,
            "assignFormSchema": assign_form_schema(
                NOTICE_COLLECTION, *update_fields
            ),
            "params": {
                "individualHooks": False,
                "filter": {"$and": [{"id": {"$eq": ref(existing, "id")}}]},
                "values": notice_values(
                    details, staging, intake_type, home, content=content
                ),
                "appends": [],
            },
        },
    )
    link(api, letter, existing)
    link(api, existing, notice_exists)
    link(api, notice_exists, create_notice, branch_index=0)
    link(api, notice_exists, update_notice, branch_index=1)
    return letter


def install_nodes(api: NocoBaseApi, workflow_id: int) -> None:
    fill = create_node(
        api,
        workflow_id,
        "update",
        "Sync Application onto Approval Log",
        {
            "collection": COLLECTION,
            "usingAssignFormSchema": True,
            "assignFormSchema": assign_form_schema(COLLECTION, "f_application"),
            "params": {
                "individualHooks": False,
                "filter": {
                    "$and": [
                        {"id": {"$eq": context("id")}},
                        {"f_application": {"$empty": True}},
                    ]
                },
                "values": {"f_application": context("f_collection_name")},
                "appends": [],
            },
        },
    )
    status_map = create_node(
        api,
        workflow_id,
        "query",
        "Query Status Name Map for source",
        query_config(
            MAP_COLLECTION,
            [
                {"f_code": {"$eq": context("f_collection_name")}},
                {"f_notice_board_enabled": {"$isTruly": True}},
            ],
        ),
    )
    details = create_node(
        api,
        workflow_id,
        "query",
        "Query node persist config",
        query_config(
            DETAILS_COLLECTION,
            [
                {"fk_map_id": {"$eq": ref(status_map, "id")}},
                {"f_code": {"$eq": context("f_node_val")}},
                {"f_notice_board_persist": {"$isTruly": True}},
            ],
        ),
    )
    persist = create_node(
        api,
        workflow_id,
        "condition",
        "Persist to Notice Board",
        persist_config(status_map, details),
    )
    source = create_node(
        api,
        workflow_id,
        "multi-conditions",
        "判断来源",
        {
            "continueOnNoMatch": True,
            "conditions": [
                source_branch("alNoticeNla", "NLA", NLA_COLLECTION),
                source_branch("alNoticeIntake", "Intake", INTAKE_COLLECTION),
            ],
        },
    )
    nla = create_node(
        api,
        workflow_id,
        "query",
        "Query NLA",
        query_config(
            NLA_COLLECTION,
            [{"id": {"$eq": context("f_data_key")}}],
            appends=("f_intake_form",),
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "query",
        "Query Intake",
        query_config(
            INTAKE_COLLECTION, [{"id": {"$eq": context("f_data_key")}}]
        ),
    )
    intake_staging = create_node(
        api,
        workflow_id,
        "query",
        "Query Intake CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_intake_id": {"$eq": context("f_data_key")}},
                {"f_request_event": {"$eq": "CREATE"}},
            ],
        ),
    )
    intake_ready = create_node(
        api,
        workflow_id,
        "condition",
        "Intake and CREATE staging exist",
        basic_condition(
            [
                {"calculator": "gt", "operands": [ref(intake, "id"), 0]},
                {"calculator": "gt", "operands": [ref(intake_staging, "id"), 0]},
            ],
            reject_on_false=False,
        ),
    )
    intake_home = create_node(
        api,
        workflow_id,
        "query",
        "Query Intake Home Record",
        query_config(
            "t_home_record",
            [{"id": {"$eq": ref(intake, "fk_intake_source_rch")}}],
        ),
    )
    intake_kind = create_node(
        api,
        workflow_id,
        "multi-conditions",
        "Type of Intake",
        {
            "continueOnNoMatch": True,
            "conditions": [
                {
                    "uid": "alIntakeTypeNla",
                    "title": "NLA",
                    "engine": "basic",
                    "calculation": {
                        "group": {
                            "type": "and",
                            "calculations": [
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        ref(intake, "fk_intake_type"),
                                        NLA_INTAKE_TYPE_ID,
                                    ],
                                }
                            ],
                        }
                    },
                }
            ],
        },
    )
    nla_intake = create_node(
        api,
        workflow_id,
        "multi-conditions",
        "NLA Intake",
        {
            "continueOnNoMatch": True,
            "conditions": [
                {
                    "uid": "alIntakeNlaCompleted",
                    "title": "Completed",
                    "engine": "basic",
                    "calculation": {
                        "group": {
                            "type": "and",
                            "calculations": [
                                {
                                    "calculator": "equal",
                                    "operands": [context("f_node_val"), "4"],
                                }
                            ],
                        }
                    },
                },
                {
                    "uid": "alIntakeNlaRejected",
                    "title": "Reject",
                    "engine": "basic",
                    "calculation": {
                        "group": {
                            "type": "or",
                            "calculations": [
                                {
                                    "calculator": "equal",
                                    "operands": [context("f_node_val"), "2"],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [context("f_node_val"), "6"],
                                },
                            ],
                        }
                    },
                },
            ],
        },
    )
    last_remark = create_node(
        api,
        workflow_id,
        "query",
        "Query last Intake Remarks",
        query_config(
            COLLECTION,
            [
                {"f_data_key": {"$eq": context("f_data_key")}},
                {"f_collection_name": {"$eq": INTAKE_COLLECTION}},
                {"f_comments": {"$notEmpty": True}},
            ],
            sort=[
                {"field": "f_completed_date", "direction": "desc"},
                {"field": "id", "direction": "desc"},
            ],
        ),
    )
    received = install_notice_write(
        api,
        workflow_id,
        prefix="Intake NLA Received",
        details=details,
        staging=intake_staging,
        intake_type=ref(intake, "fk_intake_type"),
        home=intake_home,
        content="",
    )
    rejected = install_notice_write(
        api,
        workflow_id,
        prefix="Intake NLA Rejected",
        details=details,
        staging=intake_staging,
        intake_type=ref(intake, "fk_intake_type"),
        home=intake_home,
        content=ref(last_remark, "f_comments"),
    )

    link(api, fill, status_map)
    link(api, status_map, details)
    link(api, details, persist)
    link(api, persist, source, branch_index=1)
    # multi-conditions uses 1-based branchIndex
    link(api, source, nla, branch_index=1)
    link(api, source, intake, branch_index=2)
    install_notice_path(
        api,
        workflow_id,
        prefix="NLA",
        source_row=nla,
        details=details,
        staging_filters=[
            {"f_application_id": {"$eq": context("f_data_key")}},
            {"f_request_event": {"$eq": "CREATE"}},
        ],
        intake_type=ref(nla, "f_intake_form.fk_intake_type"),
        home_filters=[
            {"fk_source_licence_app_id": {"$eq": context("f_data_key")}}
        ],
        letter_filters=[{"f_sendable": {"$isFalsely": True}}],
    )
    link(api, intake, intake_staging)
    link(api, intake_staging, intake_ready)
    link(api, intake_ready, intake_home, branch_index=1)
    link(api, intake_home, intake_kind)
    link(api, intake_kind, nla_intake, branch_index=1)
    link(api, nla_intake, received, branch_index=1)
    link(api, nla_intake, last_remark, branch_index=2)
    link(api, last_remark, rejected)


def list_missing(api: NocoBaseApi) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    page = 1
    while True:
        query = urllib.parse.urlencode(
            {
                "filter": '{"f_application":{"$empty":true}}',
                "pageSize": "200",
                "page": str(page),
            }
        )
        batch = api.request("GET", f"/api/{COLLECTION}:list?{query}")
        if not isinstance(batch, list) or not batch:
            break
        rows.extend(item for item in batch if isinstance(item, dict))
        if len(batch) < 200:
            break
        page += 1
    return rows


def backfill(api: NocoBaseApi, rows: list[dict[str, Any]]) -> tuple[int, int]:
    import concurrent.futures

    updated = 0
    skipped = 0

    def patch(row: dict[str, Any]) -> str:
        collection_name = str(row.get("f_collection_name") or "").strip()
        record_id = row.get("id")
        if record_id is None or not collection_name:
            return "skipped"
        values: dict[str, Any] = {"f_application": collection_name}
        if not row.get("createdAt") and row.get("f_assign_date"):
            values["createdAt"] = row["f_assign_date"]
        if not row.get("updatedAt"):
            stamp = row.get("f_completed_date") or row.get("f_assign_date")
            if stamp:
                values["updatedAt"] = stamp
        api.request(
            "POST",
            f"/api/{COLLECTION}:update?"
            + urllib.parse.urlencode({"filterByTk": str(record_id)}),
            values,
        )
        return "updated"

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for result in pool.map(patch, rows):
            if result == "updated":
                updated += 1
            else:
                skipped += 1
            if updated and updated % 100 == 0:
                print(f"backfill_progress={updated}")
    return updated, skipped


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://119.91.104.211:13001/cmtf2"
    )
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--backfill", action="store_true")
    parser.add_argument("--enable", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    workflow = load_workflow(api)
    print(f"workflow_id={workflow['id']}")
    print(f"enabled={str(bool(workflow.get('enabled'))).lower()}")
    print(f"executed={workflow.get('executed')}")
    print(f"node_count={len(workflow.get('nodes') or [])}")
    print("trigger=create fills application; completed update queries Status Name Map")
    print("notice=one persist condition then multi-condition source branches")
    print("source_branches=NLA,Intake/NLA Completed|Reject")
    missing: list[dict[str, Any]] = []
    if args.backfill:
        missing = list_missing(api)
        print(f"missing_application_count={len(missing)}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    workflow_id = int(workflow["id"])
    if workflow.get("enabled"):
        api.request(
            "POST",
            f"/api/workflows:update?filterByTk={workflow_id}",
            {"enabled": False},
        )
        workflow = api.get_workflow(workflow_id)
    executions = api.request(
        "GET",
        "/api/executions:list?"
        + urllib.parse.urlencode(
            {
                "pageSize": "1",
                "filter[workflowId]": str(workflow_id),
            }
        ),
    )
    if workflow.get("executed") or executions:
        workflow = revision_workflow(api, int(workflow["id"]))
        workflow_id = int(workflow["id"])
        print(f"revision_workflow_id={workflow_id}")
    configure_trigger(api, workflow_id)
    destroy_workflow_nodes(api, api.get_workflow(workflow_id))
    install_nodes(api, workflow_id)
    print("nodes=installed")

    if args.backfill:
        updated, skipped = backfill(api, missing)
        print(f"backfill_updated={updated}")
        print(f"backfill_skipped={skipped}")

    if args.enable:
        api.request(
            "POST",
            f"/api/workflows:update?filterByTk={workflow_id}",
            {"enabled": True},
        )
    final = api.get_workflow(workflow_id)
    print(f"enabled={str(bool(final.get('enabled'))).lower()}")
    print(f"node_count={len(final.get('nodes') or [])}")
    print("status=ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
