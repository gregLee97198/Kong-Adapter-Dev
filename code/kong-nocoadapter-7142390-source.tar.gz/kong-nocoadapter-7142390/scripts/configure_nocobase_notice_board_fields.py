#!/usr/bin/env python3
"""Configure Notice Board field data sources and native NocoBase fields.

Keeps id / createdAt / createdBy / updatedAt / updatedBy on both
t_notice_board and t_notice_board_status. Association fields load from:
  - Status → t_notice_board_status (sorted)
  - Intake Type → t_tree_intake_type (enabled)
  - Letter Attachment → t_letter_attachment
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_notice_board_collection import (
    COLLECTION as NOTICE_BOARD,
    RootNocoBaseApi,
    field_names,
)
from create_nocobase_notice_board_status import STATUS_COLLECTION
from extend_nocobase_staging_relations import ApiError, NocoBaseApi

NATIVE_FIELDS = [
    {
        "name": "id",
        "type": "bigInt",
        "interface": "integer",
        "primaryKey": True,
        "autoIncrement": True,
        "uiSchema": {
            "type": "number",
            "title": '{{t("ID")}}',
            "x-component": "InputNumber",
            "x-read-pretty": True,
        },
    },
    {
        "name": "createdAt",
        "type": "date",
        "interface": "createdAt",
        "uiSchema": {
            "type": "datetime",
            "title": '{{t("Created at")}}',
            "x-component": "DatePicker",
            "x-component-props": {
                "picker": "date",
                "dateFormat": "YYYY-MM-DD HH:mm",
                "showTime": True,
            },
            "x-read-pretty": True,
        },
    },
    {
        "name": "createdBy",
        "type": "belongsTo",
        "interface": "createdBy",
        "target": "users",
        "foreignKey": "createdById",
        "targetKey": "id",
        "uiSchema": {
            "type": "object",
            "title": '{{t("Created by")}}',
            "x-component": "AssociationField",
            "x-component-props": {
                "fieldNames": {"value": "id", "label": "nickname"}
            },
            "x-read-pretty": True,
        },
    },
    {
        "name": "updatedAt",
        "type": "date",
        "interface": "updatedAt",
        "uiSchema": {
            "type": "datetime",
            "title": '{{t("Last updated at")}}',
            "x-component": "DatePicker",
            "x-component-props": {
                "picker": "date",
                "dateFormat": "YYYY-MM-DD HH:mm",
                "showTime": True,
            },
            "x-read-pretty": True,
        },
    },
    {
        "name": "updatedBy",
        "type": "belongsTo",
        "interface": "updatedBy",
        "target": "users",
        "foreignKey": "updatedById",
        "targetKey": "id",
        "uiSchema": {
            "type": "object",
            "title": '{{t("Last updated by")}}',
            "x-component": "AssociationField",
            "x-component-props": {
                "fieldNames": {"value": "id", "label": "nickname"}
            },
            "x-read-pretty": True,
        },
    },
]


def ensure_field(api: NocoBaseApi, collection: str, values: Mapping[str, Any]) -> None:
    name = str(values["name"])
    existing = field_names(api, collection)
    if name in existing:
        print(f"existing_field={collection}.{name}")
        return
    try:
        api.request(
            "POST",
            f"/api/collections/{collection}/fields:create",
            dict(values),
        )
    except ApiError as exc:
        print(f"warn_create_field={collection}.{name} {exc}")
        return
    created = api.request(
        "GET",
        f"/api/collections/{collection}/fields:get?"
        + urllib.parse.urlencode({"filterByTk": name}),
    )
    if not isinstance(created, dict) or created.get("name") != name:
        raise ApiError(f"{name} was not created on {collection}")
    print(f"created_field={collection}.{name}")


def update_field(api: NocoBaseApi, collection: str, name: str, values: Mapping[str, Any]) -> None:
    api.request(
        "POST",
        f"/api/collections/{collection}/fields:update?"
        + urllib.parse.urlencode({"filterByTk": name}),
        dict(values),
    )
    print(f"updated_field={collection}.{name}")


def configure_native_fields(api: NocoBaseApi, collection: str) -> None:
    for field in NATIVE_FIELDS:
        ensure_field(api, collection, field)


def configure_title_field(api: NocoBaseApi, collection: str, title_field: str) -> None:
    api.request(
        "POST",
        f"/api/collections:update?filterByTk={collection}",
        {
            "titleField": title_field,
            "createdAt": True,
            "createdBy": True,
            "updatedAt": True,
            "updatedBy": True,
        },
    )
    print(f"title_field={collection}.{title_field}")


def configure_association_sources(api: NocoBaseApi) -> None:
    update_field(
        api,
        NOTICE_BOARD,
        "f_status",
        {
            "target": STATUS_COLLECTION,
            "foreignKey": "fk_status",
            "targetKey": "id",
            "uiSchema": {
                "title": "Status",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "f_status", "value": "id"},
                    "service": {
                        "resource": STATUS_COLLECTION,
                        "action": "list",
                        "params": {
                            "pageSize": 50,
                            "sort": ["f_sort"],
                        },
                    },
                },
                "required": True,
            },
        },
    )
    update_field(
        api,
        NOTICE_BOARD,
        "f_intake_type",
        {
            "target": "t_tree_intake_type",
            "foreignKey": "fk_intake_type",
            "targetKey": "id",
            "uiSchema": {
                "title": "Intake Type",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "f_name", "value": "id"},
                    "service": {
                        "resource": "t_tree_intake_type",
                        "action": "list",
                        "params": {
                            "pageSize": 200,
                            "sort": ["f_sort"],
                            "filter": {"f_enabled": True},
                        },
                    },
                },
                "required": True,
            },
        },
    )
    update_field(
        api,
        NOTICE_BOARD,
        "f_letter_attachment",
        {
            "target": "t_letter_attachment",
            "foreignKey": "fk_letter_attachment",
            "targetKey": "id",
            "uiSchema": {
                "title": "Letter Attachment",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "id", "value": "id"},
                    "service": {
                        "resource": "t_letter_attachment",
                        "action": "list",
                        "params": {
                            "pageSize": 50,
                            "sort": ["-f_sendtime"],
                            "appends": ["f_attachment"],
                        },
                    },
                },
                "required": False,
            },
        },
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://119.91.104.211:13001/cmtf2"
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("native_fields=id,createdAt,createdBy,updatedAt,updatedBy")
    print("status_source=t_notice_board_status.f_status")
    print("intake_type_source=t_tree_intake_type.f_name")
    print("letter_source=t_letter_attachment")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    for collection in (STATUS_COLLECTION, NOTICE_BOARD):
        configure_native_fields(api, collection)
    configure_title_field(api, STATUS_COLLECTION, "f_status")
    configure_association_sources(api)
    print("status=ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
