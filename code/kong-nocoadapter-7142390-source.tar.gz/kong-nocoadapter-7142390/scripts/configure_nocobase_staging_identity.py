#!/usr/bin/env python3
"""Bind the explicit submitter and Intake Officer to the staging workflow."""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping, MutableMapping
from typing import Any, Optional

DEFAULT_WORKFLOW_ID = 384621457375232
SUBMITTER_PATH = "form_data.case_summary.submitter_user_id"
SUBMITTER_KEY = "submitter01"


class ApiError(RuntimeError):
    pass


class Api:
    def __init__(self, base_url: str, token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        data = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        if body is not None:
            data = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:1200]
            raise ApiError(f"HTTP {exc.code} for {path}: {detail}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise ApiError(f"NocoBase error for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded

    def get_workflow(self, workflow_id: int) -> MutableMapping[str, Any]:
        query = urllib.parse.urlencode(
            {"filterByTk": str(workflow_id), "appends[]": "nodes"}
        )
        data = self.request("GET", f"/api/workflows:get?{query}")
        if not isinstance(data, dict):
            raise ApiError("Workflow API did not return an object")
        return data

    def update_node(self, node_id: int, values: Mapping[str, Any]) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(node_id)})
        self.request("POST", f"/api/flow_nodes:update?{query}", values)


def node_by_title(workflow: Mapping[str, Any], title: str) -> MutableMapping[str, Any]:
    nodes = [node for node in workflow.get("nodes") or [] if node.get("title") == title]
    if len(nodes) != 1:
        raise ApiError(f"Expected one node titled {title!r}, found {len(nodes)}")
    return nodes[0]


def variable_by_path(node: Mapping[str, Any], path: str) -> MutableMapping[str, Any]:
    matches = [
        variable
        for variable in (node.get("config") or {}).get("variables") or []
        if variable.get("path") == path
    ]
    if len(matches) != 1:
        raise ApiError(
            f"Expected one parsed variable for {path!r}, found {len(matches)}"
        )
    return matches[0]


def reference(node_key: str, variable_key: str) -> str:
    return "{{$jobsMapByNodeKey." + node_key + "." + variable_key + "}}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = Api(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    if workflow.get("enabled") or workflow.get("executed"):
        raise ApiError("Target workflow must be editable, unexecuted, and Off")

    parse_node = node_by_title(workflow, "Parse staged request body")
    intake_node = node_by_title(workflow, "Create Intake (fixed NLA type)")
    parse_config = copy.deepcopy(parse_node.get("config") or {})
    variables = parse_config.setdefault("variables", [])
    submitter_matches = [v for v in variables if v.get("path") == SUBMITTER_PATH]
    if not submitter_matches:
        variables.append(
            {
                "key": SUBMITTER_KEY,
                "path": SUBMITTER_PATH,
                "name": "submitter_user_id",
                "paths": ["form_data", "case_summary", "submitter_user_id"],
            }
        )
        submitter_variable = variables[-1]
    elif len(submitter_matches) == 1:
        submitter_variable = submitter_matches[0]
    else:
        raise ApiError("Duplicate submitter variables found")
    example = parse_config.setdefault("example", {})
    example.setdefault("form_data", {}).setdefault("case_summary", {})[
        "submitter_user_id"
    ] = 12

    owner_variable = variable_by_path(
        parse_node, "form_data.case_summary.task_owner_user_id"
    )
    owner_post_variable = variable_by_path(
        parse_node, "form_data.case_summary.task_owner_post_code"
    )
    intake_config = copy.deepcopy(intake_node.get("config") or {})
    values = intake_config.setdefault("params", {}).setdefault("values", {})
    values["createdBy"] = reference(parse_node["key"], submitter_variable["key"])
    values["fk_task_owner"] = reference(parse_node["key"], owner_variable["key"])
    values["fk_task_owner_post"] = reference(
        parse_node["key"], owner_post_variable["key"]
    )

    print(f"workflow_id={args.workflow_id}")
    print("submitter_field=form_data.case_summary.submitter_user_id")
    print("intake_officer_field=form_data.case_summary.task_owner_user_id")
    print("intake_officer_post_field=form_data.case_summary.task_owner_post_code")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api.update_node(int(parse_node["id"]), {"config": parse_config})
    api.update_node(int(intake_node["id"]), {"config": intake_config})

    verified = api.get_workflow(args.workflow_id)
    verified_parse = node_by_title(verified, "Parse staged request body")
    verified_intake = node_by_title(verified, "Create Intake (fixed NLA type)")
    submitter = variable_by_path(verified_parse, SUBMITTER_PATH)
    verified_values = (verified_intake.get("config") or {})["params"]["values"]
    expected = {
        "createdBy": reference(verified_parse["key"], submitter["key"]),
        "fk_task_owner": reference(verified_parse["key"], owner_variable["key"]),
        "fk_task_owner_post": reference(
            verified_parse["key"], owner_post_variable["key"]
        ),
    }
    for field, value in expected.items():
        if verified_values.get(field) != value:
            raise ApiError(f"Verification failed for Intake field {field}")
    print("identity_mapping_verified=yes")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
