#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ADAPTER_CONFIG="$ROOT_DIR/adapter.yaml"
KONG_CONFIG="$ROOT_DIR/kong.yaml"
RELEASE_TAG="${CMTF_RELEASE_TAG:-3.1.9}"
ADAPTER_IMAGE="cmtf-adapter:$RELEASE_TAG"
KONG_IMAGE="cmtf-kong:$RELEASE_TAG"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "error=run this script as root so the Token YAML can remain mode 600" >&2
  exit 1
fi

for path in "$ADAPTER_CONFIG" "$KONG_CONFIG"; do
  if [[ ! -s "$path" ]]; then
    echo "error=missing required configuration: $path" >&2
    exit 1
  fi
done
for image in "$ADAPTER_IMAGE" "$KONG_IMAGE"; do
  if ! docker image inspect "$image" >/dev/null 2>&1; then
    echo "error=required image is not loaded: $image" >&2
    exit 1
  fi
done

# The runtime Adapter is UID/GID 10001 and must be able to read the populated
# YAML. Keep the file inaccessible to other host users.
chown 10001:10001 "$ADAPTER_CONFIG"
chmod 600 "$ADAPTER_CONFIG"

VALIDATE_PIN=()
if [[ "$RELEASE_TAG" == 3.1.9-v081-* ]]; then
  if ! grep -q 'parameter: adapter_profile_sha256' "$KONG_CONFIG"; then
    echo "error=v0.8.1 kong.yaml has no Adapter profile pin" >&2
    exit 1
  fi
  # pin_runtime replaces kong.yaml atomically and needs a writable directory.
  # Run without a network; the populated adapter.yaml is never printed.
  docker run --rm --network none --user 0:0 \
    --mount "type=bind,source=$ROOT_DIR,target=/runtime" \
    --entrypoint python "$ADAPTER_IMAGE" \
    -m app.portable_config pin \
    --nocobase /runtime/adapter.yaml \
    --kong /runtime/kong.yaml
  VALIDATE_PIN=(--require-pin)
else
  TEMP_RUNTIME="$(mktemp "$ROOT_DIR/.kong.yaml.XXXXXX")"
  cleanup() {
    if [[ -f "$TEMP_RUNTIME" ]]; then
      rm -f -- "$TEMP_RUNTIME"
    fi
  }
  trap cleanup EXIT

  docker run --rm --network none --user 0:0 \
    --mount "type=bind,source=$ADAPTER_CONFIG,target=/runtime/adapter.yaml,readonly" \
    --mount "type=bind,source=$KONG_CONFIG,target=/runtime/kong.yaml,readonly" \
    --entrypoint python "$ADAPTER_IMAGE" \
    -m app.portable_config render \
    --nocobase /runtime/adapter.yaml \
    --template /runtime/kong.yaml \
    > "$TEMP_RUNTIME"

  chmod 644 "$TEMP_RUNTIME"
  mv -f -- "$TEMP_RUNTIME" "$KONG_CONFIG"
  trap - EXIT
fi

docker run --rm --network none --user 0:0 \
  --mount "type=bind,source=$ADAPTER_CONFIG,target=/runtime/adapter.yaml,readonly" \
  --mount "type=bind,source=$KONG_CONFIG,target=/runtime/kong.yaml,readonly" \
  --entrypoint python "$ADAPTER_IMAGE" \
  -m app.portable_config validate \
  --nocobase /runtime/adapter.yaml \
  --kong /runtime/kong.yaml \
  "${VALIDATE_PIN[@]}"

docker run --rm --network none \
  --mount "type=bind,source=$KONG_CONFIG,target=/kong/declarative/kong.yml,readonly" \
  -e KONG_DATABASE=off \
  --entrypoint kong "$KONG_IMAGE" \
  config parse /kong/declarative/kong.yml

echo "generated=$KONG_CONFIG"
echo "token_output=not_printed"
