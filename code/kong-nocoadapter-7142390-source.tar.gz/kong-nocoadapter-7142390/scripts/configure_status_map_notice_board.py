#!/usr/bin/env python3
"""Add Notice Board persist flags to Status Name Map / Details.

Application-level (t_status_name_map):
  f_notice_board_enabled — this source can write Notice Board
Node-level (t_status_name_map_details):
  f_notice_board_persist — persist when the approval node is completed
  f_notice_type — Notice Type written to t_notice_board
  f_notice_board_status — mapped Notice Board status
  f_notice_log_status — Approval Log status that triggers persist;
                        empty means Approve / Reject / The End
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_notice_board_collection import RootNocoBaseApi
from create_nocobase_notice_board_status import (
    STATUS_COLLECTION,
    ensure_field,
    hide_foreign_key,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi

MAP_COLLECTION = "t_status_name_map"
DETAILS_COLLECTION = "t_status_name_map_details"
NLA_MAP_CODE = "t_licence_app"
INTAKE_MAP_CODE = "t_intake_form"

NOTICE_LOG_STATUS_OPTIONS = [
    {"value": "5", "label": "Approve"},
    {"value": "6", "label": "Reject"},
    {"value": "11", "label": "The End"},
]

NLA_NOTICE_NODES = [
    {
        "f_code": "15",
        "persist": True,
        "notice_type": "a",
        "status": "Acknowledged",
        "log_status": "5",
    },
    {
        "f_code": "8",
        "persist": True,
        "notice_type": "b",
        "status": "Confirmed",
        "log_status": "5",
    },
    {
        "f_code": "12",
        "persist": True,
        "notice_type": "c",
        "status": "Approved",
        "log_status": "5",
    },
    {
        "f_code": "16",
        "persist": True,
        "notice_type": "d",
        "status": "Rejected",
        "log_status": None,
    },
    {
        "f_code": "2",
        "persist": True,
        "notice_type": "d",
        "status": "Rejected",
        "log_status": "11",
    },
]

# NLA Intake: Completed → Received (empty content). Closed / case-closure
# → Rejected (last Remarks). Pending Recommendation no longer publishes.
INTAKE_NOTICE_NODES = [
    {
        "f_code": "5",
        "persist": False,
        "notice_type": "received",
        "status": "Received",
        "log_status": "5",
    },
    {
        "f_code": "4",
        "persist": True,
        "notice_type": "received",
        "status": "Received",
        "log_status": "11",
    },
    {
        "f_code": "6",
        "persist": True,
        "notice_type": "d",
        "status": "Rejected",
        "log_status": "5",
    },
    {
        "f_code": "2",
        "persist": True,
        "notice_type": "d",
        "status": "Rejected",
        "log_status": "11",
    },
]


def notice_type_enum(api: NocoBaseApi) -> list[dict[str, str]]:
    field = api.request(
        "GET",
        "/api/collections/t_notice_board/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_notice_type"}),
    )
    if not isinstance(field, dict):
        raise ApiError("t_notice_board.f_notice_type was not found")
    options = []
    for item in (field.get("uiSchema") or {}).get("enum") or []:
        if not isinstance(item, dict) or item.get("value") is None:
            continue
        options.append(
            {
                "value": item["value"],
                "label": item.get("label") or str(item["value"]),
            }
        )
    if not options:
        raise ApiError("notice type enum is empty")
    return options


def ensure_received_notice_type(
    api: NocoBaseApi, notice_types: list[dict[str, str]]
) -> list[dict[str, str]]:
    if not any(item["value"] == "received" for item in notice_types):
        notice_types = list(notice_types) + [
            {"value": "received", "label": "Received"}
        ]
        print("added_notice_type=received")
    for collection, field_name in (
        ("t_notice_board", "f_notice_type"),
        (DETAILS_COLLECTION, "f_notice_type"),
    ):
        try:
            field = api.request(
                "GET",
                f"/api/collections/{collection}/fields:get?"
                + urllib.parse.urlencode({"filterByTk": field_name}),
            )
        except ApiError:
            continue
        if not isinstance(field, dict):
            continue
        ui_schema = dict(field.get("uiSchema") or {})
        ui_schema["enum"] = notice_types
        api.request(
            "POST",
            f"/api/collections/{collection}/fields:update?"
            + urllib.parse.urlencode({"filterByTk": field_name}),
            {"uiSchema": ui_schema},
        )
    return notice_types


def status_ids(api: NocoBaseApi) -> dict[str, int]:
    rows = api.request(
        "GET",
        f"/api/{STATUS_COLLECTION}:list?"
        + urllib.parse.urlencode({"pageSize": 50, "paginate": "false"}),
    )
    found: dict[str, int] = {}
    for row in rows or []:
        if isinstance(row, dict) and row.get("f_status") and row.get("id") is not None:
            found[str(row["f_status"])] = int(row["id"])
    return found


def find_map(api: NocoBaseApi, code: str) -> dict[str, Any]:
    rows = api.request(
        "GET",
        f"/api/{MAP_COLLECTION}:list?"
        + urllib.parse.urlencode(
            {
                "filter": '{"f_code":"%s"}' % code,
                "pageSize": "5",
            }
        ),
    )
    found = [
        row
        for row in (rows or [])
        if isinstance(row, dict) and row.get("f_code") == code
    ]
    if len(found) != 1:
        raise ApiError(f"expected one {MAP_COLLECTION} row for {code}")
    return found[0]


def list_details(api: NocoBaseApi, map_id: int) -> list[dict[str, Any]]:
    rows = api.request(
        "GET",
        f"/api/{DETAILS_COLLECTION}:list?"
        + urllib.parse.urlencode(
            {
                "filter": '{"fk_map_id":%s}' % map_id,
                "pageSize": "100",
                "paginate": "false",
            }
        ),
    )
    return [row for row in (rows or []) if isinstance(row, dict)]


def configure_map_fields(api: NocoBaseApi) -> None:
    ensure_field(
        api,
        MAP_COLLECTION,
        {
            "name": "f_notice_board_enabled",
            "type": "boolean",
            "interface": "checkbox",
            "defaultValue": False,
            "uiSchema": {
                "type": "boolean",
                "title": "Notice Board Enabled",
                "x-component": "Checkbox",
            },
        },
    )


def configure_detail_fields(
    api: NocoBaseApi, notice_types: list[dict[str, str]]
) -> None:
    ensure_field(
        api,
        DETAILS_COLLECTION,
        {
            "name": "f_notice_board_persist",
            "type": "boolean",
            "interface": "checkbox",
            "defaultValue": False,
            "uiSchema": {
                "type": "boolean",
                "title": "Persist to Notice Board",
                "x-component": "Checkbox",
            },
        },
    )
    ensure_field(
        api,
        DETAILS_COLLECTION,
        {
            "name": "f_notice_type",
            "type": "string",
            "interface": "select",
            "uiSchema": {
                "type": "string",
                "title": "Notice Type",
                "x-component": "Select",
                "enum": notice_types,
            },
        },
    )
    ensure_field(
        api,
        DETAILS_COLLECTION,
        {
            "name": "f_notice_board_status",
            "type": "belongsTo",
            "interface": "m2o",
            "target": STATUS_COLLECTION,
            "foreignKey": "fk_notice_board_status",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "title": "Notice Board Status",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "f_status", "value": "id"},
                    "service": {
                        "resource": STATUS_COLLECTION,
                        "action": "list",
                        "params": {"pageSize": 50, "sort": ["f_sort"]},
                    },
                },
            },
        },
    )
    ensure_field(
        api,
        DETAILS_COLLECTION,
        {
            "name": "f_notice_log_status",
            "type": "string",
            "interface": "select",
            "uiSchema": {
                "type": "string",
                "title": "Notice Trigger Status",
                "x-component": "Select",
                "enum": NOTICE_LOG_STATUS_OPTIONS,
                "description": (
                    "Approval Log status that writes Notice Board. "
                    "Empty = Approve / Reject / The End."
                ),
            },
        },
    )
    hide_foreign_key(api, DETAILS_COLLECTION, "fk_notice_board_status")


def enable_map(api: NocoBaseApi, code: str) -> None:
    row = find_map(api, code)
    api.request(
        "POST",
        f"/api/{MAP_COLLECTION}:update?"
        + urllib.parse.urlencode({"filterByTk": str(row["id"])}),
        {"f_notice_board_enabled": True},
    )
    print(f"enabled_map={code}")


def seed_map(
    api: NocoBaseApi,
    code: str,
    specs: list[dict[str, Any]],
    statuses: Mapping[str, int],
) -> None:
    enable_map(api, code)
    map_id = int(find_map(api, code)["id"])
    by_code = {str(row.get("f_code")): row for row in list_details(api, map_id)}
    for spec in specs:
        row = by_code.get(spec["f_code"])
        if not row or row.get("id") is None:
            print(f"missing_detail={code}.{spec['f_code']}")
            continue
        status_id = statuses.get(str(spec["status"]))
        if status_id is None:
            raise ApiError(f"notice status {spec['status']!r} was not found")
        values: dict[str, Any] = {
            "f_notice_board_persist": spec["persist"],
            "f_notice_type": spec["notice_type"],
            "f_notice_board_status": status_id,
            "f_notice_log_status": spec["log_status"],
        }
        api.request(
            "POST",
            f"/api/{DETAILS_COLLECTION}:update?"
            + urllib.parse.urlencode({"filterByTk": str(row["id"])}),
            values,
        )
        print(
            f"seeded={code}.{spec['f_code']} "
            f"type={spec['notice_type']} status={spec['status']}"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://119.91.104.211:13001/cmtf2"
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    notice_types = notice_type_enum(api)
    print("map_field=f_notice_board_enabled")
    print(
        "detail_fields=f_notice_board_persist,f_notice_type,"
        "f_notice_board_status,f_notice_log_status"
    )
    print(f"notice_type_options={len(notice_types)}")
    print(f"nla_notice_nodes={len(NLA_NOTICE_NODES)}")
    print(f"intake_notice_nodes={len(INTAKE_NOTICE_NODES)}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    configure_map_fields(api)
    notice_types = ensure_received_notice_type(api, notice_types)
    configure_detail_fields(api, notice_types)
    statuses = status_ids(api)
    seed_map(api, NLA_MAP_CODE, NLA_NOTICE_NODES, statuses)
    seed_map(api, INTAKE_MAP_CODE, INTAKE_NOTICE_NODES, statuses)
    print("status=ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
