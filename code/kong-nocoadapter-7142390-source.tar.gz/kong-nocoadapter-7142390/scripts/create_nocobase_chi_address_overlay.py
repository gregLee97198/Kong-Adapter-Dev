#!/usr/bin/env python3
"""Apply CHI address changes only after the native independent clone exists.

The native CHI snapshot workflow copies the Home Record address *after* the
staging CREATE workflow sees the application. Therefore no staging CREATE or
UPDATE node may directly update application.fk_rch_address. This sidecar runs
on the staging transition to succeeded, proves that the target address ID is
different from the Home Record's address ID, and then updates only the CHI
clone. Updating its completion marker cannot retrigger it because the trigger
is restricted to f_status changes.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    APPLICATION_COLLECTION,
    CREATE_API_TYPE,
    UPDATE_API_TYPE,
    RootNocoBaseApi,
    context,
    create_node,
    create_workflow,
    link,
    query_config,
    ref,
    set_enabled,
    update_config,
)
from extend_nocobase_staging_relations import ADDRESS_FIELDS, ApiError
from create_nocobase_staging_update_workflow import field_references


TITLE = "API Bridge — CHI Independent Address Overlay v1"
STAGING_COLLECTION = "t_api_request_staging"
REQUESTED_FIELD = "f_chi_address_requested"
APPLIED_FIELD = "f_chi_address_applied_at"
ADDRESS_KEYS = [
    *ADDRESS_FIELDS.values(), "fk_region_en", "fk_region_cn",
    "fk_district_name_en", "fk_district_name_cn",
    "fk_sub_district_en", "fk_sub_district_cn",
]


def overlay_script() -> str:
    content = r"""const staged = staging || {};
const app = application || {};
const homeRow = home || {};
const addressRow = independentAddress || {};
const incoming = (((staged.f_request_body || {}).form_data || {}).part_2 || {}).address;
if (staged.f_chi_address_requested !== true || !incoming || !Object.keys(incoming).length)
  throw new Error('CHI staging has no requested address body');
if (!app.id || String(app.id) !== String(staged.f_application_id))
  throw new Error('CHI application ID does not match staging');
if (!homeRow.id || String(homeRow.id) !== String(staged.f_rch_id)
    || String(app.fk_home_record) !== String(homeRow.id))
  throw new Error('CHI Home Record ID does not match staging');
if (!app.fk_rch_address || !addressRow.id
    || String(app.fk_rch_address) !== String(addressRow.id)
    || String(app.fk_rch_address) === String(homeRow.fk_rch_address))
  throw new Error('Independent CHI address is not ready; Home Record write refused');
const own = (obj, key) => obj && Object.prototype.hasOwnProperty.call(obj, key);
const patch = Object.fromEntries(__ADDRESS_KEYS__.map(key =>
  [key, own(addressRow, key) ? addressRow[key] : null]));
for (const [external, internal] of Object.entries(__ADDRESS_MAP__)) {
  if (own(incoming, external)) patch[internal] = incoming[external];
}
if (own(incoming, 'region_code')) {
  const rows = Array.isArray(addressOptions) ? addressOptions : [];
  const region = rows.find(r => String(r.f_code) === String(incoming.region_code));
  const district = rows.find(r => String(r.f_code) === String(incoming.district_code));
  const sub = rows.find(r => String(r.f_code) === String(incoming.sub_district_code));
  if (!region || !district || !sub || String(district.parentId) !== String(region.id)
      || String(sub.parentId) !== String(district.id))
    throw new Error('Invalid Region/District/Sub-district code hierarchy');
  patch.fk_region_en = region.f_name_en;
  patch.fk_region_cn = region.f_name_cn;
  patch.fk_district_name_en = district.f_name_en;
  patch.fk_district_name_cn = district.f_name_cn;
  patch.fk_sub_district_en = sub.f_name_en;
  patch.fk_sub_district_cn = sub.f_name_cn;
}
return { address_id: addressRow.id, address_patch: patch,
  applied_at: new Date().toISOString() };
"""
    return (content.replace("__ADDRESS_KEYS__", json.dumps(ADDRESS_KEYS))
                   .replace("__ADDRESS_MAP__", json.dumps(ADDRESS_FIELDS)))


def ensure_staging_fields(api: RootNocoBaseApi) -> None:
    fields = api.request(
        "GET", f"/api/collections/{STAGING_COLLECTION}/fields:list?pageSize=500"
    ) or []
    names = {field.get("name") for field in fields}
    definitions = (
        {
            "name": REQUESTED_FIELD, "type": "boolean", "interface": "checkbox",
            "defaultValue": False,
            "uiSchema": {"type": "boolean", "title": "CHI Address Requested",
                         "x-component": "Checkbox"},
        },
        {
            "name": APPLIED_FIELD, "type": "string", "interface": "input",
            "uiSchema": {"type": "string", "title": "CHI Address Applied At",
                         "x-component": "Input"},
        },
    )
    for values in definitions:
        if values["name"] in names:
            continue
        api.request(
            "POST", f"/api/collections/{STAGING_COLLECTION}/fields:create",
            values,
        )
        fields = api.request(
            "GET", f"/api/collections/{STAGING_COLLECTION}/fields:list?pageSize=500"
        ) or []
        if not any(field.get("name") == values["name"] for field in fields):
            raise ApiError(f"Could not create {values['name']}")


def build_graph(api: RootNocoBaseApi, workflow_id: int) -> None:
    app = create_node(api, workflow_id, "query", "Resolve linked CHI application",
        query_config(APPLICATION_COLLECTION, [
            {"id": {"$eq": context("f_application_id")}}
        ]))
    home = create_node(api, workflow_id, "query", "Resolve source Home Record",
        query_config("t_home_record", [
            {"id": {"$eq": context("f_rch_id")}}
        ]))
    independent = create_node(api, workflow_id, "query", "Resolve CHI address clone",
        query_config("t_address", [
            {"id": {"$eq": ref(app, "fk_rch_address")}}
        ]))
    options = create_node(api, workflow_id, "query", "Load address codes for CHI",
        query_config("f_tree_region_district", [], multiple=True))
    normalize = create_node(api, workflow_id, "script", "Guard independent CHI address",
        {"arguments": [
            {"name": "staging", "value": "{{$context.data}}"},
            {"name": "application", "value": ref(app)},
            {"name": "home", "value": ref(home)},
            {"name": "independentAddress", "value": ref(independent)},
            {"name": "addressOptions", "value": ref(options)},
        ], "content": overlay_script(), "timeout": 0, "continue": False})
    update_address = create_node(api, workflow_id, "update",
        "Update only independent CHI address",
        update_config("t_address", ref(normalize, "address_id"),
                      field_references(normalize, "address_patch", ADDRESS_KEYS)))
    mark = create_node(api, workflow_id, "update", "Mark CHI address applied",
        update_config(STAGING_COLLECTION, context("id"),
                      {APPLIED_FIELD: ref(normalize, "applied_at")}))
    link(api, app, home)
    link(api, home, independent)
    link(api, independent, options)
    link(api, options, normalize)
    link(api, normalize, update_address)
    link(api, update_address, mark)


def existing(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"filter[title]": TITLE, "pageSize": 100})
    return [dict(row) for row in
            api.request("GET", f"/api/workflows:list?{query}") or []
            if row.get("title") == TITLE]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = RootNocoBaseApi(args.base_url, token)
    found = existing(api)
    if any(row.get("enabled") for row in found):
        print("enabled_workflow_id=", next(row["id"] for row in found
                                            if row.get("enabled")))
        return 0
    print("workflow_title=", TITLE)
    print("only_changed_field=f_status")
    print("home_address_id_guard=yes")
    if not args.apply:
        print("mode=dry-run")
        return 0
    ensure_staging_fields(api)
    condition = {"$and": [
        {"f_status": {"$eq": "succeeded"}},
        {"f_application_type": {"$eq": "changing_home"}},
        {"f_source_system": {"$ne": "CMTF"}},
        {"f_chi_address_requested": {"$eq": True}},
        {"f_chi_address_applied_at": {"$empty": True}},
        {"f_application_id": {"$notEmpty": True}},
        {"$or": [
            {"f_api_type": {"$eq": CREATE_API_TYPE}},
            {"f_api_type": {"$eq": UPDATE_API_TYPE}},
        ]},
    ]}
    workflow = create_workflow(
        api, title=TITLE, collection=STAGING_COLLECTION,
        condition=condition, mode=2, changed=("f_status",)
    )
    try:
        build_graph(api, int(workflow["id"]))
        set_enabled(api, int(workflow["id"]), True)
        result = api.get_workflow(int(workflow["id"]))
        if not result.get("enabled") or len(result.get("nodes") or []) != 7:
            raise ApiError("CHI address overlay did not install correctly")
        print("enabled_workflow_id=", workflow["id"])
        print("node_count=", len(result.get("nodes") or []))
        return 0
    except Exception:
        set_enabled(api, int(workflow["id"]), False)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
