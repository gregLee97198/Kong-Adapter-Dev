#!/usr/bin/env python3
"""Create the Notice Board collection and form fields on NocoBase.

The collection stores 3rd-party Notice List records. Attachments are not
uploaded here; they are read from the related Letter Attachment record.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping
from typing import Any, Optional

from extend_nocobase_staging_relations import ApiError, NocoBaseApi

COLLECTION = "t_notice_board"
COLLECTION_TITLE = "Notice Board"
LETTER_COLLECTION = "t_letter_attachment"
INTAKE_TYPE_COLLECTION = "t_tree_intake_type"
LETTER_CATEGORY_ID = 371705146441728

THIRD_PARTY_OPTIONS = [
    {"value": "OP", "label": "OP"},
]


class RootNocoBaseApi(NocoBaseApi):
    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "X-Role": "root",
        }
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=payload,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:2000]
            raise ApiError(f"HTTP {exc.code} for {path}: {detail}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise ApiError(f"NocoBase error for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded


def letter_type_enum(api: NocoBaseApi) -> list[dict[str, str]]:
    field = api.request(
        "GET",
        "/api/collections/t_letter_attachment/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_letter_type"}),
    )
    if not isinstance(field, dict):
        raise ApiError("t_letter_attachment.f_letter_type was not found")
    options = []
    for item in (field.get("uiSchema") or {}).get("enum") or []:
        if not isinstance(item, dict) or item.get("value") is None:
            continue
        options.append(
            {
                "value": item["value"],
                "label": item.get("label") or str(item["value"]),
            }
        )
    if not options:
        raise ApiError("letter type enum is empty")
    return options


def collection_exists(api: NocoBaseApi, name: str) -> bool:
    query = urllib.parse.urlencode({"filterByTk": name})
    try:
        data = api.request("GET", f"/api/collections:get?{query}")
    except ApiError as exc:
        if "HTTP 404" in str(exc):
            return False
        raise
    return isinstance(data, dict) and data.get("name") == name


def field_names(api: NocoBaseApi, collection: str) -> set[str]:
    rows = api.request(
        "GET",
        f"/api/collections/{collection}/fields:list?"
        + urllib.parse.urlencode({"pageSize": 400, "paginate": "false"}),
    )
    return {
        item.get("name")
        for item in (rows or [])
        if isinstance(item, dict) and item.get("name")
    }


def ensure_collection(api: NocoBaseApi) -> None:
    if collection_exists(api, COLLECTION):
        print(f"existing_collection={COLLECTION}")
        return
    api.request(
        "POST",
        "/api/collections:create",
        {
            "name": COLLECTION,
            "title": COLLECTION_TITLE,
            "template": "general",
            "logging": True,
            "autoGenId": True,
            "createdAt": True,
            "createdBy": True,
            "updatedAt": True,
            "updatedBy": True,
            "hidden": False,
            "description": (
                "3rd-party Notice List. Created when CMTF-II automatically "
                "generates a letter. Attachments come from the related "
                "Letter Attachment; this collection has no compose/send UI."
            ),
        },
    )
    created = api.request(
        "GET",
        "/api/collections:get?"
        + urllib.parse.urlencode({"filterByTk": COLLECTION}),
    )
    if not isinstance(created, dict) or created.get("name") != COLLECTION:
        raise ApiError(f"{COLLECTION} was not created")
    print(f"created_collection={COLLECTION}")


def ensure_category(api: NocoBaseApi) -> None:
    data = api.request(
        "GET",
        "/api/collections:get?"
        + urllib.parse.urlencode(
            {"filterByTk": COLLECTION, "appends[]": "category"}
        ),
    )
    categories = (data or {}).get("category") or []
    if any(
        isinstance(item, dict) and item.get("id") == LETTER_CATEGORY_ID
        for item in categories
    ):
        print("collection_category=Letter")
        return
    api.request(
        "POST",
        f"/api/collectionCategories/{LETTER_CATEGORY_ID}/collections:add",
        {"values": [{"name": COLLECTION}]},
    )
    print("collection_category=Letter")


def hide_foreign_key_fields(api: NocoBaseApi) -> None:
    existing = field_names(api, COLLECTION)
    for name in ("fk_letter_attachment", "fk_intake_type", "fk_api_request"):
        if name not in existing:
            continue
        api.request(
            "POST",
            f"/api/collections/{COLLECTION}/fields:update?"
            + urllib.parse.urlencode({"filterByTk": name}),
            {
                "uiSchema": {
                    "type": "number",
                    "title": name,
                    "x-component": "InputNumber",
                    "x-read-pretty": True,
                    "x-hidden": True,
                }
            },
        )
        print(f"hidden_field={name}")


def ensure_field(api: NocoBaseApi, values: Mapping[str, Any]) -> None:
    name = str(values["name"])
    existing = field_names(api, COLLECTION)
    if name in existing:
        print(f"existing_field={name}")
        return
    api.request(
        "POST",
        f"/api/collections/{COLLECTION}/fields:create",
        dict(values),
    )
    created = api.request(
        "GET",
        f"/api/collections/{COLLECTION}/fields:get?"
        + urllib.parse.urlencode({"filterByTk": name}),
    )
    if not isinstance(created, dict) or created.get("name") != name:
        raise ApiError(f"{name} was not created on {COLLECTION}")
    print(f"created_field={name}")


def ensure_reverse_letter_relation(api: NocoBaseApi) -> None:
    existing = field_names(api, LETTER_COLLECTION)
    if "f_notice_board" in existing:
        print("existing_field=t_letter_attachment.f_notice_board")
        return
    api.request(
        "POST",
        f"/api/collections/{LETTER_COLLECTION}/fields:create",
        {
            "name": "f_notice_board",
            "type": "hasMany",
            "interface": "o2m",
            "collectionName": LETTER_COLLECTION,
            "target": COLLECTION,
            "foreignKey": "fk_letter_attachment",
            "sourceKey": "id",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "type": "array",
                "title": "Notice Board",
                "x-component": "AssociationField",
                "x-component-props": {"multiple": True},
            },
        },
    )
    created = api.request(
        "GET",
        f"/api/collections/{LETTER_COLLECTION}/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_notice_board"}),
    )
    if not isinstance(created, dict) or created.get("name") != "f_notice_board":
        raise ApiError("reverse f_notice_board was not created")
    print("created_field=t_letter_attachment.f_notice_board")


def configure_optional_letter(api: NocoBaseApi) -> None:
    api.request(
        "POST",
        f"/api/collections/{COLLECTION}/fields:update?"
        + urllib.parse.urlencode({"filterByTk": "f_letter_attachment"}),
        {
            "uiSchema": {
                "title": "Letter Attachment",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "id", "value": "id"},
                },
                "required": False,
            }
        },
    )
    print("letter_attachment_required=false")


def fields(notice_types: list[dict[str, str]]) -> list[dict[str, Any]]:
    return [
        {
            "name": "f_third_party_name",
            "type": "string",
            "interface": "select",
            "uiSchema": {
                "type": "string",
                "title": "3rd Party Name",
                "x-component": "Select",
                "enum": THIRD_PARTY_OPTIONS,
                "required": True,
            },
        },
        {
            "name": "f_intake_type",
            "type": "belongsTo",
            "interface": "m2o",
            "target": INTAKE_TYPE_COLLECTION,
            "foreignKey": "fk_intake_type",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "title": "Intake Type",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "f_name", "value": "id"},
                },
                "required": True,
            },
        },
        {
            "name": "f_notice_type",
            "type": "string",
            "interface": "select",
            "uiSchema": {
                "type": "string",
                "title": "Notice Type",
                "x-component": "Select",
                "enum": notice_types,
                "required": True,
            },
        },
        {
            "name": "f_content",
            "type": "text",
            "interface": "textarea",
            "uiSchema": {
                "type": "string",
                "title": "Content",
                "x-component": "Input.TextArea",
                "x-component-props": {
                    "autoSize": {"minRows": 3, "maxRows": 12},
                },
            },
        },
        {
            "name": "f_letter_attachment",
            "type": "belongsTo",
            "interface": "m2o",
            "target": LETTER_COLLECTION,
            "foreignKey": "fk_letter_attachment",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "title": "Letter Attachment",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "id", "value": "id"},
                },
                "required": False,
            },
        },
        {
            "name": "f_api_request",
            "type": "belongsTo",
            "interface": "m2o",
            "target": "t_api_request_staging",
            "foreignKey": "fk_api_request",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "title": "API Call Record",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "id", "value": "id"},
                },
                "required": True,
            },
        },
        {
            "name": "f_rch_no",
            "type": "string",
            "interface": "input",
            "uiSchema": {
                "type": "string",
                "title": "RCH No.",
                "x-component": "Input",
            },
        },
        {
            "name": "f_rch_name",
            "type": "string",
            "interface": "input",
            "uiSchema": {
                "type": "string",
                "title": "RCH Name",
                "x-component": "Input",
            },
        },
    ]


def print_plan(notice_types: list[dict[str, str]]) -> None:
    print(f"collection={COLLECTION}")
    print(f"title={COLLECTION_TITLE}")
    print("fields=f_third_party_name,f_intake_type,f_notice_type,f_content,f_letter_attachment,f_api_request,f_rch_no,f_rch_name,createdAt")
    print("intake_type_target=t_tree_intake_type")
    print("letter_target=t_letter_attachment")
    print("attachment_path=f_letter_attachment.f_attachment")
    print(f"notice_type_options={len(notice_types)}")
    print("third_party_options=OP")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://119.91.104.211:13001/cmtf2"
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    notice_types = letter_type_enum(api)
    print_plan(notice_types)
    if not args.apply:
        print("mode=dry-run")
        return 0

    ensure_collection(api)
    ensure_category(api)
    for field in fields(notice_types):
        ensure_field(api, field)
    hide_foreign_key_fields(api)
    ensure_reverse_letter_relation(api)
    configure_optional_letter(api)
    print("status=ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
