#!/usr/bin/env python3
"""Create the Notice Board business-status table and link it to Notice Board.

Status rows follow the CMTF-II mapped business status contract. Notice Board
stores the current status of the related application and is updated as the
workflow advances.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_notice_board_collection import (
    COLLECTION as NOTICE_BOARD,
    LETTER_CATEGORY_ID,
    RootNocoBaseApi,
    collection_exists,
    field_names,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi

STATUS_COLLECTION = "t_notice_board_status"
STATUS_TITLE = "Notice Board Status"

STATUS_ROWS = [
    {
        "f_status": "Accepted",
        "f_meaning": (
            "Initial mapped business stage immediately after a successful "
            "Create or Update request. Same value as the HTTP response "
            "status Accepted."
        ),
        "f_update_allowed": True,
        "f_recommended_query_data": "N/A",
        "f_sort": 1,
    },
    {
        "f_status": "Received",
        "f_meaning": (
            "Outgoing workflow status after the application is created from "
            "Intake / SWIT-SWO recommend-proceed. Update is not allowed from "
            "this status onward."
        ),
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data",
        "f_sort": 2,
    },
    {
        "f_status": "P_Number_Generated",
        "f_meaning": (
            "When P Number generated, OP will need to create an account and "
            "a profile for the applicant; application advanced from Received."
        ),
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data",
        "f_sort": 3,
    },
    {
        "f_status": "Acknowledged",
        "f_meaning": "Acknowledgement letter confirmed for issue",
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data, notices",
        "f_sort": 4,
    },
    {
        "f_status": "Confirmed",
        "f_meaning": "Confirmation letter confirmed for issue",
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data, notices",
        "f_sort": 5,
    },
    {
        "f_status": "Reminding",
        "f_meaning": (
            "Initial inspection remains incomplete and reminder stage is active"
        ),
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data, notices",
        "f_sort": 6,
    },
    {
        "f_status": "Approved",
        "f_meaning": "Application approved",
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data, notices",
        "f_sort": 7,
    },
    {
        "f_status": "Rejected",
        "f_meaning": "Application rejected",
        "f_update_allowed": False,
        "f_recommended_query_data": "application_data, notices",
        "f_sort": 8,
    },
]

QUERY_DATA_OPTIONS = [
    {"value": "N/A", "label": "N/A"},
    {"value": "application_data", "label": "application_data"},
    {"value": "application_data, notices", "label": "application_data, notices"},
]


def ensure_collection(api: NocoBaseApi) -> None:
    if collection_exists(api, STATUS_COLLECTION):
        print(f"existing_collection={STATUS_COLLECTION}")
        return
    api.request(
        "POST",
        "/api/collections:create",
        {
            "name": STATUS_COLLECTION,
            "title": STATUS_TITLE,
            "template": "general",
            "logging": True,
            "autoGenId": True,
            "createdAt": True,
            "createdBy": True,
            "updatedAt": True,
            "updatedBy": True,
            "hidden": False,
            "description": (
                "Mapped business status dictionary for Notice Board. "
                "Notice Board records point here and are updated as the "
                "application workflow status changes."
            ),
        },
    )
    created = api.request(
        "GET",
        "/api/collections:get?"
        + urllib.parse.urlencode({"filterByTk": STATUS_COLLECTION}),
    )
    if not isinstance(created, dict) or created.get("name") != STATUS_COLLECTION:
        raise ApiError(f"{STATUS_COLLECTION} was not created")
    print(f"created_collection={STATUS_COLLECTION}")


def ensure_category(api: NocoBaseApi) -> None:
    data = api.request(
        "GET",
        "/api/collections:get?"
        + urllib.parse.urlencode(
            {"filterByTk": STATUS_COLLECTION, "appends[]": "category"}
        ),
    )
    categories = (data or {}).get("category") or []
    if any(
        isinstance(item, dict) and item.get("id") == LETTER_CATEGORY_ID
        for item in categories
    ):
        print("collection_category=Letter")
        return
    api.request(
        "POST",
        f"/api/collectionCategories/{LETTER_CATEGORY_ID}/collections:add",
        {"values": [{"name": STATUS_COLLECTION}]},
    )
    print("collection_category=Letter")


def ensure_field(
    api: NocoBaseApi, collection: str, values: Mapping[str, Any]
) -> None:
    name = str(values["name"])
    existing = field_names(api, collection)
    if name in existing:
        print(f"existing_field={collection}.{name}")
        return
    api.request(
        "POST",
        f"/api/collections/{collection}/fields:create",
        dict(values),
    )
    created = api.request(
        "GET",
        f"/api/collections/{collection}/fields:get?"
        + urllib.parse.urlencode({"filterByTk": name}),
    )
    if not isinstance(created, dict) or created.get("name") != name:
        raise ApiError(f"{name} was not created on {collection}")
    print(f"created_field={collection}.{name}")


def hide_foreign_key(api: NocoBaseApi, collection: str, name: str) -> None:
    existing = field_names(api, collection)
    if name not in existing:
        return
    api.request(
        "POST",
        f"/api/collections/{collection}/fields:update?"
        + urllib.parse.urlencode({"filterByTk": name}),
        {
            "uiSchema": {
                "type": "number",
                "title": name,
                "x-component": "InputNumber",
                "x-read-pretty": True,
                "x-hidden": True,
            }
        },
    )
    print(f"hidden_field={collection}.{name}")


def status_fields() -> list[dict[str, Any]]:
    return [
        {
            "name": "f_status",
            "type": "string",
            "interface": "input",
            "unique": True,
            "uiSchema": {
                "type": "string",
                "title": "Status",
                "x-component": "Input",
                "required": True,
            },
        },
        {
            "name": "f_meaning",
            "type": "text",
            "interface": "textarea",
            "uiSchema": {
                "type": "string",
                "title": "Meaning",
                "x-component": "Input.TextArea",
                "required": True,
            },
        },
        {
            "name": "f_update_allowed",
            "type": "boolean",
            "interface": "checkbox",
            "uiSchema": {
                "type": "boolean",
                "title": "Update allowed",
                "x-component": "Checkbox",
            },
        },
        {
            "name": "f_recommended_query_data",
            "type": "string",
            "interface": "select",
            "uiSchema": {
                "type": "string",
                "title": "Recommended Query Data",
                "x-component": "Select",
                "enum": QUERY_DATA_OPTIONS,
                "required": True,
            },
        },
        {
            "name": "f_sort",
            "type": "sort",
            "interface": "sort",
            "uiSchema": {
                "type": "number",
                "title": "Sort",
                "x-component": "InputNumber",
            },
        },
    ]


def ensure_status_rows(api: NocoBaseApi) -> None:
    existing = api.request(
        "GET",
        f"/api/{STATUS_COLLECTION}:list?"
        + urllib.parse.urlencode({"pageSize": 100, "paginate": "false"}),
    )
    rows = existing if isinstance(existing, list) else []
    by_status = {
        row.get("f_status"): row
        for row in rows
        if isinstance(row, dict) and row.get("f_status")
    }
    for values in STATUS_ROWS:
        current = by_status.get(values["f_status"])
        if current and current.get("id") is not None:
            api.request(
                "POST",
                f"/api/{STATUS_COLLECTION}:update?"
                + urllib.parse.urlencode({"filterByTk": str(current["id"])}),
                values,
            )
            print(f"updated_status={values['f_status']}")
            continue
        created = api.request(
            "POST",
            f"/api/{STATUS_COLLECTION}:create",
            values,
        )
        if not isinstance(created, dict) or created.get("f_status") != values["f_status"]:
            raise ApiError(f"failed to create status {values['f_status']}")
        print(f"created_status={values['f_status']} id={created.get('id')}")


def ensure_notice_board_status_fields(api: NocoBaseApi) -> None:
    if not collection_exists(api, NOTICE_BOARD):
        raise ApiError(f"{NOTICE_BOARD} must exist before linking status")
    ensure_field(
        api,
        NOTICE_BOARD,
        {
            "name": "f_status",
            "type": "belongsTo",
            "interface": "m2o",
            "target": STATUS_COLLECTION,
            "foreignKey": "fk_status",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "title": "Status",
                "x-component": "AssociationField",
                "x-component-props": {
                    "multiple": False,
                    "fieldNames": {"label": "f_status", "value": "id"},
                },
                "required": True,
            },
        },
    )
    ensure_field(
        api,
        NOTICE_BOARD,
        {
            "name": "f_status_updated_at",
            "type": "date",
            "interface": "datetime",
            "uiSchema": {
                "type": "string",
                "title": "Status Updated Time",
                "x-component": "DatePicker",
                "x-component-props": {"showTime": True},
            },
        },
    )
    hide_foreign_key(api, NOTICE_BOARD, "fk_status")
    existing = field_names(api, STATUS_COLLECTION)
    if "f_notice_board" in existing:
        print(f"existing_field={STATUS_COLLECTION}.f_notice_board")
        return
    api.request(
        "POST",
        f"/api/collections/{STATUS_COLLECTION}/fields:create",
        {
            "name": "f_notice_board",
            "type": "hasMany",
            "interface": "o2m",
            "collectionName": STATUS_COLLECTION,
            "target": NOTICE_BOARD,
            "foreignKey": "fk_status",
            "sourceKey": "id",
            "targetKey": "id",
            "onDelete": "SET NULL",
            "uiSchema": {
                "type": "array",
                "title": "Notice Board",
                "x-component": "AssociationField",
                "x-component-props": {"multiple": True},
            },
        },
    )
    print(f"created_field={STATUS_COLLECTION}.f_notice_board")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://119.91.104.211:13001/cmtf2"
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print(f"collection={STATUS_COLLECTION}")
    print("fields=f_status,f_meaning,f_update_allowed,f_recommended_query_data,f_sort")
    print("notice_board_link=t_notice_board.f_status")
    print("rows=" + ",".join(item["f_status"] for item in STATUS_ROWS))
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    ensure_collection(api)
    ensure_category(api)
    for field in status_fields():
        ensure_field(api, STATUS_COLLECTION, field)
    ensure_status_rows(api)
    ensure_notice_board_status_fields(api)
    print("status=ready")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
