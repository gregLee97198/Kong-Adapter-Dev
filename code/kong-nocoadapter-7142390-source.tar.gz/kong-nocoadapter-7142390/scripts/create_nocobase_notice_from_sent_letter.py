#!/usr/bin/env python3
"""Create an idempotent Notice row when a Letter Attachment is sent.

The workflow listens only to f_sendtime changes on t_letter_attachment. It
looks up the original CREATE staging row through f_business_key and creates at
most one Notice per Letter Attachment. It never updates the letter or any
application record, which avoids recursive business workflow execution.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from extend_nocobase_staging_relations import ApiError, NocoBaseApi, attach_api_source_category

TITLE = "API Notice — Sent Letter to Notice List v1"


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str) -> str:
    return "{{$jobsMapByNodeKey." + str(node["key"]) + "." + field + "}}"


def query_config(collection: str, filters: list[dict[str, Any]], *, appends: tuple[str, ...] = ()) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": False,
        "params": {
            "filter": {"$and": filters},
            "sort": [],
            "page": 1,
            "pageSize": 1,
            "appends": list(appends),
        },
    }


def create_node(api: NocoBaseApi, workflow_id: int, node_type: str, title: str, config: Mapping[str, Any]) -> dict[str, Any]:
    return dict(api.create_node({"workflowId": workflow_id, "type": node_type, "title": title, "config": dict(config)}))


def link(api: NocoBaseApi, upstream: Mapping[str, Any], downstream: Mapping[str, Any], *, branch_index: int | None = None) -> None:
    if branch_index is None:
        api.update_node(int(upstream["id"]), {"downstreamId": downstream["id"]})
    api.update_node(int(downstream["id"]), {"upstreamId": upstream["id"], "branchIndex": branch_index})


def exists_config(node: Mapping[str, Any], *, reject_on_false: bool) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject_on_false,
        "engine": "basic",
        "calculation": {"group": {"type": "and", "calculations": [{"calculator": "gt", "operands": [ref(node, "id"), 0]}]}},
    }


def list_existing(api: NocoBaseApi) -> list[dict[str, Any]]:
    rows = api.request("GET", "/api/workflows:list?" + urllib.parse.urlencode({"pageSize": 100, "filter[title]": TITLE}))
    return [row for row in (rows or []) if row.get("title") == TITLE]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://119.91.104.211:13001/cmtf2")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    print(f"workflow_title={TITLE}")
    print("trigger=t_letter_attachment.f_sendtime changed and non-empty")
    print("dedupe=one notice per letter attachment")
    print("business_table_write=no")
    print("sync=false")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = NocoBaseApi(args.base_url, token)
    existing = list_existing(api)
    if any(row.get("enabled") for row in existing):
        print(f"existing_enabled_workflow_id={next(row['id'] for row in existing if row.get('enabled'))}")
        return 0
    for row in existing:
        api.request("POST", "/api/workflows:destroy?" + urllib.parse.urlencode({"filterByTk": str(row["id"])}), {})

    workflow = api.request(
        "POST",
        "/api/workflows:create",
        {
            "title": TITLE,
            "type": "collection",
            "sync": False,
            "enabled": False,
            "config": {
                "mode": 2,
                "appends": ["f_attachment"],
                "changed": ["f_sendtime"],
                "collection": "t_letter_attachment",
                "condition": {"$and": [{"f_sendtime": {"$notEmpty": True}}]},
            },
        },
    )
    if not isinstance(workflow, dict) or workflow.get("id") is None:
        raise ApiError("Workflow create API returned no workflow ID")
    workflow_id = int(workflow["id"])
    attach_api_source_category(api, workflow_id)
    try:
        staging = create_node(
            api, workflow_id, "query", "Resolve CREATE staging",
            query_config("t_api_request_staging", [
                {"f_application_id": {"$eq": context("f_business_key")}},
                {"f_request_event": {"$eq": "CREATE"}},
            ]),
        )
        staging_exists = create_node(api, workflow_id, "condition", "CREATE staging exists", exists_config(staging, reject_on_false=True))
        intake = create_node(
            api, workflow_id, "query", "Resolve Intake type",
            query_config("t_intake_form", [{"id": {"$eq": ref(staging, "f_intake_id")}}]),
        )
        home = create_node(
            api, workflow_id, "query", "Resolve Home Record",
            query_config("t_home_record", [{"id": {"$eq": ref(staging, "f_rch_id")}}]),
        )
        existing_notice = create_node(
            api, workflow_id, "query", "Check existing Notice",
            query_config("t_notice_board", [{"fk_letter_attachment": {"$eq": context("id")}}]),
        )
        notice_exists = create_node(
            api,
            workflow_id,
            "condition",
            "Notice already exists",
            exists_config(existing_notice, reject_on_false=False),
        )
        create_notice = create_node(
            api, workflow_id, "create", "Create Notice List record",
            {
                "collection": "t_notice_board",
                "params": {
                    "values": {
                        "f_third_party_name": "OP",
                        "f_notice_type": context("f_letter_type"),
                        "f_letter_attachment": context("id"),
                        "f_api_request": ref(staging, "id"),
                        "f_intake_type": ref(intake, "fk_intake_type"),
                        "f_rch_no": ref(home, "f_rch_no"),
                        "f_rch_name": ref(home, "f_rch_name_en"),
                    },
                    "appends": [],
                },
            },
        )
        link(api, staging, staging_exists)
        link(api, staging_exists, intake, branch_index=1)
        link(api, intake, home)
        link(api, home, existing_notice)
        link(api, existing_notice, notice_exists)
        link(api, notice_exists, create_notice, branch_index=0)
        api.request("POST", f"/api/workflows:update?filterByTk={workflow_id}", {"enabled": True})
        final = api.get_workflow(workflow_id)
        print(f"workflow_id={workflow_id}")
        print(f"enabled={str(bool(final.get('enabled'))).lower()}")
        print(f"node_count={len(final.get('nodes') or [])}")
        return 0
    except Exception:
        try:
            api.request("POST", f"/api/workflows:update?filterByTk={workflow_id}", {"enabled": False})
        except Exception:
            pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
