#!/usr/bin/env python3
"""CMTF-native create-to-staging bridges.

On application insert, create one CMTF CREATE staging row if none exists.
The staging row stays at Accepted. These bridges never update application
or Intake form status fields; later status changes are out of band.

The old Intake-Completed-to-Received bridges are disabled so they cannot
overwrite staging status or touch business forms.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    APPLICATION_COLLECTION as CHI_COLLECTION,
    CREATE_BRIDGE_TITLE as CHI_CREATE_BRIDGE_TITLE,
    RECEIVED_BRIDGE_TITLE as CHI_RECEIVED_BRIDGE_TITLE,
    RootNocoBaseApi,
    build_create_bridge as build_chi_create_bridge,
    create_node,
    disable_workflows_named,
    ensure_enabled_workflow,
    exists_config,
    link,
    query_config,
)
from create_nocobase_phase_c2_renewal_workflows import (
    COLLECTION as RENEWAL_COLLECTION,
    CREATE_BRIDGE_TITLE as RENEWAL_CREATE_BRIDGE_TITLE,
    build_create_bridge as build_renewal_create_bridge,
)

TITLE = "API Bridge — NLA Application Created to Staging v1"
DEPRECATED_TITLE = "API Bridge — NLA Intake Completed to Received v1"
CREATE_API_TYPE = "create_intake_for_new_licence"
APPLICATION_TYPE = "new_licence"
APPLICATION_COLLECTION = "t_licence_app"


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def build_nla_create_bridge(api: Any, workflow_id: int) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {
                    "$or": [
                        {"f_application_id": {"$eq": context("id")}},
                        {"f_intake_id": {"$eq": context("fk_intake_form")}},
                    ]
                },
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    create_cmtf = create_node(
        api,
        workflow_id,
        "create",
        "Create CMTF NLA staging at Accepted",
        {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": CREATE_API_TYPE,
                    "f_application_type": APPLICATION_TYPE,
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": context("f_office_cd"),
                    "f_intake_id": context("fk_intake_form"),
                    "f_application_id": context("id"),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        },
    )
    link(api, staging, exists)
    link(api, exists, create_cmtf, branch_index=0)
    # Staging only. Never update t_licence_app / Intake form status.


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print(f"create_bridge_title={TITLE}")
    print(f"deprecated_title={DEPRECATED_TITLE}")
    print(f"chi_create_bridge_title={CHI_CREATE_BRIDGE_TITLE}")
    print(f"chi_deprecated_title={CHI_RECEIVED_BRIDGE_TITLE}")
    print(f"renewal_create_bridge_title={RENEWAL_CREATE_BRIDGE_TITLE}")
    print("trigger=application after create")
    print("staging_status=Accepted")
    print("application_form_write=no")
    print("skip_when=existing CREATE staging for the same application")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    disable_workflows_named(api, DEPRECATED_TITLE)
    disable_workflows_named(api, CHI_RECEIVED_BRIDGE_TITLE)
    ensure_enabled_workflow(
        api,
        title=TITLE,
        collection=APPLICATION_COLLECTION,
        builder=build_nla_create_bridge,
    )
    ensure_enabled_workflow(
        api,
        title=CHI_CREATE_BRIDGE_TITLE,
        collection=CHI_COLLECTION,
        builder=build_chi_create_bridge,
    )
    ensure_enabled_workflow(
        api,
        title=RENEWAL_CREATE_BRIDGE_TITLE,
        collection=RENEWAL_COLLECTION,
        builder=build_renewal_create_bridge,
    )
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
