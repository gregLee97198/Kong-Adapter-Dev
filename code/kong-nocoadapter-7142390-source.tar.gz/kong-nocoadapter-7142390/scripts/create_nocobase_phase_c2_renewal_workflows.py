#!/usr/bin/env python3
"""Create Phase-C2 Licence Renewal staging workflows on NocoBase.

No Intake. The workflow binds Home Record, creates t_licence_renewal_app,
and writes only the confirmed whitelist. Extra NLA-shaped fields are ignored.
"""

from __future__ import annotations

import argparse
import os
import sys
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    create_workflow,
    ensure_enabled_workflow,
    exists_config,
    link,
    parse_variable,
    query_config,
    require_absent,
    scope,
    set_enabled,
    update_config,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import external_source_condition

COLLECTION = "t_licence_renewal_app"
APPLICATION_TYPE = "licence_renewal"
APPLICATION_LABEL = "Licence Renewal Application"
CREATE_API_TYPE = "create_licence_renewal"
UPDATE_API_TYPE = "update_licence_renewal_data"
CREATE_TITLE = "API Request Staging — Create Licence Renewal v1"
UPDATE_TITLE = "API Request Staging — Update Licence Renewal v1"
CREATE_BRIDGE_TITLE = (
    "API Bridge — Licence Renewal Application Created to Staging v1"
)


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def parse_config() -> dict[str, Any]:
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": {
            "create_id": "386000000000000",
            "form_data": {
                "case_summary": {
                    "office_code": "LORCHE",
                    "lorche_d_no": "L0043",
                    "received_date": "2026-09-14",
                    "submitter_user_id": 12,
                    "task_owner_user_id": 45,
                    "task_owner_post_code": "S(LR)1",
                },
                "part_1": {"application_received_date": "2026-09-14"},
                "part_5": {
                    "comments": "Renewal overlay",
                    "other_information": None,
                    "remarks": None,
                    "attachment_ids": [],
                    "checklist": [
                        {
                            "position_code": "LORCHE_NLA_001",
                            "attachment_id": 504,
                        }
                    ],
                },
            },
        },
        "variables": [
            parse_variable("form_data.case_summary.office_code", "officeCode"),
            parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
            parse_variable("form_data.case_summary.received_date", "receivedDate"),
            parse_variable("form_data.case_summary.submitter_user_id", "submitterId"),
            parse_variable("form_data.case_summary.task_owner_user_id", "ownerId"),
            parse_variable(
                "form_data.case_summary.task_owner_post_code", "ownerPost"
            ),
            parse_variable(
                "form_data.part_1.application_received_date",
                "applicationReceivedDate",
            ),
            parse_variable("form_data.part_5.comments", "comments"),
            parse_variable("form_data.part_5.other_information", "otherInformation"),
            parse_variable("form_data.part_5.remarks", "remarks"),
            parse_variable("form_data.part_5.attachment_ids", "attachmentIds"),
            parse_variable("form_data.part_5.checklist", "checklist"),
            parse_variable(
                "form_data.part_5.checklist[].position_code", "checklistPosition"
            ),
            parse_variable(
                "form_data.part_5.checklist[].attachment_id", "checklistAttachment"
            ),
            parse_variable("create_id", "createId"),
        ],
    }


def overlay_values(parse: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "fk_renewal_home_record_id": context("f_rch_id"),
        "f_office_cd": ref(parse, "officeCode"),
        "f_d_no": ref(parse, "lorcheDNo"),
        "f_rch_no": ref(parse, "lorcheDNo"),
        "f_application_received_date": ref(parse, "applicationReceivedDate"),
        "f_comments": ref(parse, "comments"),
        "f_other_information": ref(parse, "otherInformation"),
        "f_remarks": ref(parse, "remarks"),
        "f_attachments_of_rchs": ref(parse, "attachmentIds"),
    }


def ensure_application_type_enum(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        "filterByTk=f_application_type",
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    if any(item.get("value") == APPLICATION_TYPE for item in options):
        print(f"existing_enum=f_application_type.{APPLICATION_TYPE}")
        return
    options.append({"value": APPLICATION_TYPE, "label": APPLICATION_LABEL})
    ui_schema["enum"] = options
    api.request(
        "POST",
        "/api/collections/t_api_request_staging/fields:update?"
        "filterByTk=f_application_type",
        {"uiSchema": ui_schema},
    )
    print(f"updated_enum=f_application_type.{APPLICATION_TYPE}")


def attach_checklist(
    api: NocoBaseApi,
    workflow_id: int,
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    start: Mapping[str, Any],
    *,
    intake_id: Any,
    rch_id: Any,
) -> None:
    checklist_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply NLA-catalog checklist files to renewal",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
    )
    find_template = create_node(
        api,
        workflow_id,
        "query",
        "Resolve NLA checklist template by position_code",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$eq": scope(checklist_loop, "position_code")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {"f_use_for": {"$anyOf": ["t_licence_app"]}},
            ],
        ),
    )
    find_item = create_node(
        api,
        workflow_id,
        "query",
        "Find renewal checklist item",
        query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"fk_document_checklist": {"$eq": ref(find_template, "id")}},
                {"f_business_type": {"$eq": COLLECTION}},
            ],
        ),
    )
    item_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Renewal checklist item exists",
        exists_config(find_item, reject_on_false=False),
    )
    update_item = create_node(
        api,
        workflow_id,
        "update",
        "Update renewal checklist item + files",
        update_config(
            "t_document_submitted_for_application",
            ref(find_item, "id"),
            {
                "f_is_checked": True,
                "f_lastest_files": [scope(checklist_loop, "attachment_id")],
            },
        ),
    )
    create_item = create_node(
        api,
        workflow_id,
        "create",
        "Create renewal checklist item + files",
        {
            "collection": "t_document_submitted_for_application",
            "params": {
                "values": {
                    "f_business_key": ref(application, "id"),
                    "f_business_type": COLLECTION,
                    "fk_document_checklist": ref(find_template, "id"),
                    "f_is_checked": True,
                    "f_lastest_files": [scope(checklist_loop, "attachment_id")],
                },
                "appends": [],
            },
        },
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark succeeded + backfill IDs",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": None,
                "f_application_id": ref(application, "id"),
                "f_rch_id": rch_id,
            },
        ),
    )
    del intake_id
    link(api, start, checklist_loop)
    link(api, checklist_loop, find_template, branch_index=0)
    link(api, find_template, find_item)
    link(api, find_item, item_exists)
    link(api, item_exists, update_item, branch_index=1)
    link(api, item_exists, create_item, branch_index=0)
    link(api, checklist_loop, succeeded)


def build_create_graph(api: NocoBaseApi, workflow_id: int) -> None:
    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    processing["config"]["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "submitted"}},
        ]
    }
    api.update_node(int(processing["id"]), {"config": processing["config"]})
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged licence renewal request body",
        parse_config(),
    )
    application = create_node(
        api,
        workflow_id,
        "create",
        "Create Licence Renewal bound to Home Record (no Intake)",
        {
            "collection": COLLECTION,
            "params": {
                "values": {
                    "f_approval_status": "0",
                    "f_inspect_type": "Renewal",
                    "f_renewal_trigger_type": "home_record_manual",
                    **overlay_values(parse),
                },
                "appends": [],
            },
        },
    )
    link(api, processing, parse)
    link(api, parse, application)
    attach_checklist(
        api,
        workflow_id,
        parse,
        application,
        application,
        intake_id=None,
        rch_id=context("f_rch_id"),
    )


def build_update_graph(api: NocoBaseApi, workflow_id: int) -> None:
    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark update processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    processing["config"]["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "submitted"}},
        ]
    }
    api.update_node(int(processing["id"]), {"config": processing["config"]})
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged licence renewal update body",
        parse_config(),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {"f_application_status": {"$eq": "Accepted"}},
            ],
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Licence Renewal",
        query_config(
            COLLECTION,
            [{"id": {"$eq": ref(original, "f_application_id")}}],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Licence Renewal exists",
        exists_config(application),
    )
    overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged renewal whitelist overlay",
        update_config(COLLECTION, ref(application, "id"), overlay_values(parse)),
    )
    link(api, processing, parse)
    link(api, parse, original)
    link(api, original, application)
    link(api, application, exists)
    link(api, exists, overlay, branch_index=1)
    attach_checklist(
        api,
        workflow_id,
        parse,
        application,
        overlay,
        intake_id=None,
        rch_id=ref(original, "f_rch_id"),
    )


def build_create_bridge(api: NocoBaseApi, workflow_id: int) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {"f_application_id": {"$eq": context("id")}},
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    create_cmtf = create_node(
        api,
        workflow_id,
        "create",
        "Create CMTF licence renewal staging at Accepted",
        {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": CREATE_API_TYPE,
                    "f_application_type": APPLICATION_TYPE,
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": context("f_office_cd"),
                    "f_intake_id": None,
                    "f_application_id": context("id"),
                    "f_rch_id": context("fk_renewal_home_record_id"),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        },
    )
    # Staging only. Never update t_licence_renewal_app approval/form status.
    link(api, staging, exists)
    link(api, exists, create_cmtf, branch_index=0)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument(
        "--ensure-create-bridge",
        action="store_true",
        help="Only ensure CMTF-native renewal create-to-staging; do not recreate Create/Update",
    )
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=C2")
    print(f"create_title={CREATE_TITLE}")
    print(f"update_title={UPDATE_TITLE}")
    print(f"create_bridge_title={CREATE_BRIDGE_TITLE}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    if args.ensure_create_bridge:
        ensure_enabled_workflow(
            api,
            title=CREATE_BRIDGE_TITLE,
            collection=COLLECTION,
            builder=build_create_bridge,
        )
        print("mode=applied")
        return 0

    created_ids: list[int] = []
    try:
        ensure_application_type_enum(api)
        for title in (CREATE_TITLE, UPDATE_TITLE, CREATE_BRIDGE_TITLE):
            require_absent(api, title)
        create_wf = create_workflow(
            api,
            title=CREATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("CREATE", CREATE_API_TYPE),
        )
        created_ids.append(int(create_wf["id"]))
        build_create_graph(api, int(create_wf["id"]))

        update_wf = create_workflow(
            api,
            title=UPDATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("UPDATE", UPDATE_API_TYPE),
        )
        created_ids.append(int(update_wf["id"]))
        build_update_graph(api, int(update_wf["id"]))

        create_bridge = create_workflow(
            api,
            title=CREATE_BRIDGE_TITLE,
            collection=COLLECTION,
            mode=1,
            condition={},
        )
        created_ids.append(int(create_bridge["id"]))
        build_create_bridge(api, int(create_bridge["id"]))

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            final = api.get_workflow(workflow_id)
            print(f"workflow_id={final.get('id')}")
            print(f"workflow_title={final.get('title')}")
            print(f"enabled={str(bool(final.get('enabled'))).lower()}")
            print(f"node_count={len(final.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
