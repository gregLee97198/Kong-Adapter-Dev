#!/usr/bin/env python3
"""Create Phase-C Changing Home Information staging workflows on NocoBase.

The native CHI workflow already creates the application from Intake when
fk_intake_type is Changing Home Information and fk_intake_source_rch is set.
These sidecar workflows write Staging, Intake, CHI overlay fields and
checklist attachments, then run the native Intake Form Submit as the business
submitter from form_data.case_summary.submitter_user_id — not the API token
account. Native post/rank routing then moves Intake from Draft to Pending
Recommendation. They never Close Intake or impersonate an approval assignee.
"""

from __future__ import annotations

import argparse
import http.client
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping
from typing import Any, Optional

from extend_nocobase_staging_relations import (
    ApiError,
    NocoBaseApi,
    attach_api_source_category,
)
from workflow_source_condition import external_source_condition


class RootNocoBaseApi(NocoBaseApi):
    """Workflow node writes on 13001 require the hidden root role."""

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "X-Role": "root",
        }
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=payload,
            headers=headers,
            method=method,
        )
        # Retrying an uncertain workflow/node mutation can duplicate a write
        # when NocoBase committed it before the connection was reset.  Reads
        # are safe to retry; mutations must fail visibly so the caller can
        # reconcile the server state before deciding whether to continue.
        retryable = method.upper() in {"GET", "HEAD", "OPTIONS"}
        last_error: Exception | None = None
        raw = b""
        for attempt in range(6):
            try:
                with urllib.request.urlopen(request, timeout=180) as response:
                    raw = response.read()
                last_error = None
                break
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode(errors="replace")[:1200]
                if retryable and exc.code >= 500 and attempt < 5:
                    time.sleep(2 ** attempt)
                    last_error = ApiError(f"HTTP {exc.code} for {path}: {detail}")
                    continue
                raise ApiError(f"HTTP {exc.code} for {path}: {detail}") from exc
            except (
                urllib.error.URLError,
                http.client.RemoteDisconnected,
                ConnectionError,
            ) as exc:
                last_error = exc
                if not retryable or attempt == 5:
                    raise ApiError(f"URL error for {path}: {exc}") from exc
                time.sleep(min(2 ** attempt, 16))
        if last_error is not None:
            raise ApiError(f"URL error for {path}: {last_error}") from last_error
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise ApiError(f"NocoBase error for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded

CHI_INTAKE_TYPE_ID = 377193350037504
CREATE_TITLE = "API Request Staging — Create Changing Home Information v1"
UPDATE_TITLE = "API Request Staging — Update Changing Home Information v1"
CREATE_BRIDGE_TITLE = "API Bridge — CHI Application Created to Staging v1"
RECEIVED_BRIDGE_TITLE = "API Bridge — CHI Intake Completed to Received v1"
CREATE_API_TYPE = "create_intake_for_changing_home"
UPDATE_API_TYPE = "update_changing_home_data"
APPLICATION_TYPE = "changing_home"
APPLICATION_COLLECTION = "t_change_home_information_app"
# Same native Intake Form Submit used by NLA. Context.userId must be the
# business submitter so routing writes Pending Recommendation, not Draft.
INTAKE_SUBMIT_WORKFLOW_KEY = "qdkj25b0793"
# Native Submit tests f_intake_accept_reject: "0" = accept / recommend proceed.
INTAKE_NATIVE_ACCEPT = "0"
RESOLVE_SUBMITTER_TITLE = "Resolve business submitter and post"
APPLY_IDENTITY_TITLE = "Apply submitter post to Intake"
LOAD_INTAKE_TITLE = "Load Intake for native Submit"
SUBMIT_TITLE = "Run native Intake Form Submit as business submitter"


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def scope(node: Mapping[str, Any], field: str) -> str:
    return "{{$scopes." + str(node["key"]) + ".item." + field + "}}"


def create_node(
    api: NocoBaseApi,
    workflow_id: int,
    node_type: str,
    title: str,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    return dict(
        api.create_node(
            {
                "workflowId": workflow_id,
                "type": node_type,
                "title": title,
                "config": dict(config),
            }
        )
    )


def link(
    api: NocoBaseApi,
    upstream: Mapping[str, Any],
    downstream: Mapping[str, Any],
    *,
    branch_index: int | None = None,
) -> None:
    if branch_index is None:
        api.update_node(int(upstream["id"]), {"downstreamId": downstream["id"]})
    api.update_node(
        int(downstream["id"]),
        {"upstreamId": upstream["id"], "branchIndex": branch_index},
    )


def query_config(
    collection: str,
    filters: list[dict[str, Any]],
    *,
    multiple: bool = False,
    appends: tuple[str, ...] = (),
) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": multiple,
        "params": {
            "filter": {"$and": filters},
            "sort": [],
            "page": 1,
            "pageSize": 500 if multiple else 1,
            "appends": list(appends),
        },
    }


def update_config(
    collection: str,
    record_id: str,
    values: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "collection": collection,
        "params": {
            "filter": {"$and": [{"id": {"$eq": record_id}}]},
            "values": dict(values),
            "individualHooks": False,
        },
    }


def exists_config(
    node: Mapping[str, Any], *, reject_on_false: bool = True
) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject_on_false,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "gt", "operands": [ref(node, "id"), 0]}
                ],
            }
        },
    }


def parse_variable(path: str, key: str) -> dict[str, str | list[str]]:
    return {
        "key": key,
        "path": path,
        "name": path.rsplit(".", 1)[-1],
        "paths": path.split("."),
    }


def chi_parse_config() -> dict[str, Any]:
    example = {
        "request_id": "CHI-20260914-0001",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "lorche_d_no": "L0043",
                "received_date": "2026-09-14",
                "severity": "0",
                "source_id": 701,
                "source_other": "OP",
                "submitter_user_id": 12,
                "task_owner_user_id": 45,
                "task_owner_post_code": "S(LR)1",
            },
            "is_change_name": True,
            "is_change_address": False,
            "is_change_operator_or_operating_company": False,
            "is_change_rch_type": False,
            "is_change_maximum_capacity": False,
            "is_aip": False,
            "part_1": {"application_received_date": "2026-09-14"},
            "part_2": {
                "rch_name_en": "Example RCH",
                "rch_name_cn": "示例院舍",
                "telephone_no": "21234567",
                "fax_no": "27654321",
                "email": "rch@example.test",
            },
            "part_5": {
                "comments": "CHI overlay",
                "other_information": None,
                "remarks": None,
                "attachment_ids": [501],
                "checklist": [
                    {
                        "position_code": "LORCHE_STAGE2:ROW:68",
                        "attachment_id": 502,
                        "checked": True,
                        "status": "1",
                        "remarks": None,
                    }
                ],
            },
        },
    }
    variables = [
        parse_variable("form_data.case_summary.office_code", "officeCode"),
        parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
        parse_variable("form_data.case_summary.received_date", "receivedDate"),
        parse_variable("form_data.case_summary.severity", "severity"),
        parse_variable("form_data.case_summary.source_id", "sourceId"),
        parse_variable("form_data.case_summary.source_other", "sourceOther"),
        parse_variable("form_data.case_summary.submitter_user_id", "submitterId"),
        parse_variable("form_data.case_summary.task_owner_user_id", "ownerId"),
        parse_variable("form_data.case_summary.task_owner_post_code", "ownerPost"),
        parse_variable("form_data.is_change_name", "flagName"),
        parse_variable("form_data.is_change_address", "flagAddress"),
        parse_variable(
            "form_data.is_change_operator_or_operating_company", "flagOperator"
        ),
        parse_variable("form_data.is_change_rch_type", "flagType"),
        parse_variable("form_data.is_change_maximum_capacity", "flagCapacity"),
        parse_variable("form_data.is_aip", "flagAip"),
        parse_variable(
            "form_data.part_1.application_received_date", "applicationReceivedDate"
        ),
        parse_variable("form_data.part_2.rch_name_en", "rchNameEn"),
        parse_variable("form_data.part_2.rch_name_cn", "rchNameCn"),
        parse_variable("form_data.part_2.telephone_no", "telephoneNo"),
        parse_variable("form_data.part_2.fax_no", "faxNo"),
        parse_variable("form_data.part_2.email", "email"),
        parse_variable("form_data.part_2.gender", "rchGender"),
        parse_variable("form_data.part_2.premises_type", "rchPremises"),
        parse_variable("form_data.part_2.monthly_fee_min", "monthlyFeeMin"),
        parse_variable("form_data.part_2.monthly_fee_max", "monthlyFeeMax"),
        parse_variable("form_data.part_2.floor_area_sqm", "floorArea"),
        parse_variable("form_data.part_2.licence_capacity", "licenceCapacity"),
        parse_variable(
            "form_data.part_2.nursing_home_places", "bedsNursing"
        ),
        parse_variable(
            "form_data.part_2.care_and_attention_home_places", "bedsCareAndAttention"
        ),
        parse_variable("form_data.part_2.aged_home_places", "bedsMeal"),
        parse_variable("form_data.part_2.self_care_hostel_places", "bedsSelfCare"),
        parse_variable(
            "form_data.part_1.tentative_commencement_date",
            "tentativeCommencementDate",
        ),
        parse_variable("form_data.part_5.application_level", "applicationLevel"),
        parse_variable("form_data.part_5.comments", "comments"),
        parse_variable("form_data.part_5.other_information", "otherInformation"),
        parse_variable("form_data.part_5.remarks", "remarks"),
        parse_variable("form_data.part_5.attachment_ids", "attachmentIds"),
        parse_variable("form_data.part_5.checklist", "checklist"),
        parse_variable(
            "form_data.part_5.checklist[].position_code", "checklistPosition"
        ),
        parse_variable(
            "form_data.part_5.checklist[].attachment_id", "checklistAttachment"
        ),
        parse_variable("create_id", "createId"),
    ]
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": example,
        "variables": variables,
    }


def list_existing(api: NocoBaseApi, title: str) -> list[dict[str, Any]]:
    data = api.request(
        "GET",
        "/api/workflows:list?"
        + urllib.parse.urlencode({"pageSize": 100, "filter[title]": title}),
    )
    return [row for row in (data or []) if row.get("title") == title]


def require_absent(api: NocoBaseApi, title: str) -> None:
    existing = list_existing(api, title)
    if any(row.get("enabled") for row in existing):
        raise ApiError(f"Enabled workflow titled {title!r} already exists")
    for row in existing:
        api.request(
            "POST",
            "/api/workflows:destroy?"
            + urllib.parse.urlencode({"filterByTk": str(row["id"])}),
            {},
        )
        print(f"destroyed_incomplete_workflow_id={row['id']}")


def create_workflow(
    api: NocoBaseApi,
    *,
    title: str,
    collection: str,
    condition: Mapping[str, Any],
    mode: int,
    changed: tuple[str, ...] = (),
    appends: tuple[str, ...] = (),
) -> dict[str, Any]:
    workflow = api.request(
        "POST",
        "/api/workflows:create",
        {
            "title": title,
            "type": "collection",
            "sync": False,
            "enabled": False,
            "config": {
                "mode": mode,
                "appends": list(appends),
                "changed": list(changed),
                "collection": collection,
                "condition": dict(condition),
            },
        },
    )
    if not isinstance(workflow, dict) or workflow.get("id") is None:
        raise ApiError("Workflow create API returned no workflow ID")
    attach_api_source_category(api, int(workflow["id"]))
    return workflow


def set_enabled(api: NocoBaseApi, workflow_id: int, enabled: bool) -> None:
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow_id}",
        {"enabled": enabled},
    )


def disable_workflows_named(api: NocoBaseApi, title: str) -> None:
    for row in list_existing(api, title):
        if not row.get("enabled"):
            continue
        set_enabled(api, int(row["id"]), False)
        print(f"disabled_workflow_id={row['id']} title={title}")


def ensure_enabled_workflow(
    api: NocoBaseApi,
    *,
    title: str,
    collection: str,
    builder,
    condition: Mapping[str, Any] | None = None,
    mode: int = 1,
) -> dict[str, Any]:
    existing = list_existing(api, title)
    enabled = [row for row in existing if row.get("enabled")]
    if enabled:
        workflow = api.get_workflow(int(enabled[0]["id"]))
        print(f"already_enabled_workflow_id={workflow.get('id')} title={title}")
        print(f"node_count={len(workflow.get('nodes') or [])}")
        return workflow
    workflow = create_workflow(
        api,
        title=title,
        collection=collection,
        mode=mode,
        condition=dict(condition or {}),
    )
    builder(api, int(workflow["id"]))
    set_enabled(api, int(workflow["id"]), True)
    final = api.get_workflow(int(workflow["id"]))
    print(f"workflow_id={final.get('id')}")
    print(f"workflow_title={final.get('title')}")
    print(f"enabled={str(bool(final.get('enabled'))).lower()}")
    print(f"node_count={len(final.get('nodes') or [])}")
    return final


def ensure_staging_fields(api: NocoBaseApi) -> None:
    existing_fields = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:list?"
        + urllib.parse.urlencode({"pageSize": 400}),
    )
    existing_names = {
        item.get("name")
        for item in (existing_fields or [])
        if isinstance(item, dict)
    }
    if "f_rch_id" not in existing_names:
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:create",
            {
                "name": "f_rch_id",
                "type": "string",
                "interface": "input",
                "uiSchema": {
                    "type": "string",
                    "title": "Home Record ID",
                    "x-component": "Input",
                },
            },
        )
        created = api.request(
            "GET",
            "/api/collections/t_api_request_staging/fields:get?"
            + urllib.parse.urlencode({"filterByTk": "f_rch_id"}),
        )
        if not isinstance(created, dict) or created.get("name") != "f_rch_id":
            raise ApiError("f_rch_id was not created on t_api_request_staging")
        print("created_field=f_rch_id")
    else:
        print("existing_field=f_rch_id")

    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    if not any(item.get("value") == APPLICATION_TYPE for item in options):
        options.append(
            {
                "value": APPLICATION_TYPE,
                "label": "Changing Home Information Application",
            }
        )
        ui_schema["enum"] = options
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:update?"
            + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
            {"uiSchema": ui_schema},
        )
        print("updated_enum=f_application_type.changing_home")
    else:
        print("existing_enum=f_application_type.changing_home")


def chi_intake_create_values(parse: Mapping[str, Any]) -> dict[str, Any]:
    """Create Intake as the business submitter with native accept=0.

    Draft is the NocoBase default. Native Intake Form Submit, executed as
    submitter_user_id, then advances the record to Pending Recommendation.
    """
    return {
        "fk_intake_type": CHI_INTAKE_TYPE_ID,
        "fk_intake_source_rch": context("f_rch_id"),
        "fk_task_owner_post": ref(parse, "ownerPost"),
        "fk_intake_source": ref(parse, "sourceId"),
        "fk_task_owner": ref(parse, "ownerId"),
        "f_severity": ref(parse, "severity"),
        "f_received_date": ref(parse, "receivedDate"),
        "f_source_other": ref(parse, "sourceOther"),
        "f_office_cd": ref(parse, "officeCode"),
        "f_subject": ref(parse, "rchNameEn"),
        "f_comments": ref(parse, "comments"),
        "f_intake_accept_reject": INTAKE_NATIVE_ACCEPT,
        "createdBy": ref(parse, "submitterId"),
    }


def overlay_values(parse: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "is_change_name": ref(parse, "flagName"),
        "is_change_address": ref(parse, "flagAddress"),
        "is_change_operator_or_operating_company": ref(parse, "flagOperator"),
        "is_change_rch_type": ref(parse, "flagType"),
        "is_change_maximum_capacity": ref(parse, "flagCapacity"),
        "is_aip": ref(parse, "flagAip"),
        "fk_home_record": context("f_rch_id"),
        "f_application_received_date": ref(parse, "applicationReceivedDate"),
        "f_rch_name_en": ref(parse, "rchNameEn"),
        "f_rch_name_cn": ref(parse, "rchNameCn"),
        "f_telephone_no": ref(parse, "telephoneNo"),
        "f_fax_no": ref(parse, "faxNo"),
        "f_email": ref(parse, "email"),
        "f_rch_gender": ref(parse, "rchGender"),
        "f_rch_premises": ref(parse, "rchPremises"),
        "f_monthly_fee_per_resident_min": ref(parse, "monthlyFeeMin"),
        "f_monthly_fee_per_resident_max": ref(parse, "monthlyFeeMax"),
        "f_net_floor_area_sqm": ref(parse, "floorArea"),
        "f_licence_capacity": ref(parse, "licenceCapacity"),
        "f_beds_nursing": ref(parse, "bedsNursing"),
        "f_beds_care_and_attention": ref(parse, "bedsCareAndAttention"),
        "f_beds_meal": ref(parse, "bedsMeal"),
        "f_beds_self_care": ref(parse, "bedsSelfCare"),
        "f_tentative_service_commencement_date": ref(
            parse, "tentativeCommencementDate"
        ),
        "f_application_level": ref(parse, "applicationLevel"),
        "f_comments": ref(parse, "comments"),
        "f_other_information": ref(parse, "otherInformation"),
        "f_remarks": ref(parse, "remarks"),
        "f_attachments_of_rchs": ref(parse, "attachmentIds"),
        "f_office_cd": ref(parse, "officeCode"),
    }


def build_create_graph(api: NocoBaseApi, workflow_id: int) -> None:
    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    processing["config"]["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "submitted"}},
        ]
    }
    api.update_node(int(processing["id"]), {"config": processing["config"]})

    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged CHI request body",
        chi_parse_config(),
    )
    resolve_submitter = create_node(
        api,
        workflow_id,
        "query",
        RESOLVE_SUBMITTER_TITLE,
        query_config(
            "users",
            [{"id": {"$eq": ref(parse, "submitterId")}}],
            appends=("f_posts_code",),
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "create",
        "Create Intake (fixed CHI type + Home Record)",
        {
            "collection": "t_intake_form",
            "params": {
                "values": chi_intake_create_values(parse),
                "appends": [],
            },
        },
    )
    apply_identity = create_node(
        api,
        workflow_id,
        "update",
        APPLY_IDENTITY_TITLE,
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            {
                "fk_created_by_post": ref(resolve_submitter, "f_posts_code.f_post_cd"),
                "createdBy": ref(resolve_submitter, "id"),
            },
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Find native-created CHI",
        query_config(
            APPLICATION_COLLECTION,
            [{"fk_intake_form": {"$eq": ref(intake, "id")}}],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native CHI exists",
        exists_config(application, reject_on_false=False),
    )
    apply_chi = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged flags and overlay to native CHI",
        update_config(
            APPLICATION_COLLECTION,
            ref(application, "id"),
            overlay_values(parse),
        ),
    )
    checklist_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply Checklist files to native CHI records",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
    )
    find_template = create_node(
        api,
        workflow_id,
        "query",
        "Resolve checklist template by position_code",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$eq": scope(checklist_loop, "position_code")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {
                    "f_use_for": {
                        "$anyOf": [APPLICATION_COLLECTION, "t_licence_app"]
                    }
                },
            ],
        ),
    )
    find_item = create_node(
        api,
        workflow_id,
        "query",
        "Find native CHI checklist item",
        query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"fk_document_checklist": {"$eq": ref(find_template, "id")}},
                {"f_business_type": {"$eq": APPLICATION_COLLECTION}},
            ],
        ),
    )
    item_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native CHI checklist item exists",
        exists_config(find_item, reject_on_false=False),
    )
    update_item = create_node(
        api,
        workflow_id,
        "update",
        "Update native CHI checklist item + files",
        update_config(
            "t_document_submitted_for_application",
            ref(find_item, "id"),
            {
                "f_is_checked": True,
                "f_lastest_files": [scope(checklist_loop, "attachment_id")],
            },
        ),
    )
    create_item = create_node(
        api,
        workflow_id,
        "create",
        "Create CHI checklist item + files",
        {
            "collection": "t_document_submitted_for_application",
            "params": {
                "values": {
                    "f_business_key": ref(application, "id"),
                    "f_business_type": APPLICATION_COLLECTION,
                    "fk_document_checklist": ref(find_template, "id"),
                    "f_is_checked": True,
                    "f_lastest_files": [scope(checklist_loop, "attachment_id")],
                },
                "appends": [],
            },
        },
    )
    load_intake = create_node(
        api,
        workflow_id,
        "query",
        LOAD_INTAKE_TITLE,
        query_config(
            "t_intake_form",
            [{"id": {"$eq": ref(intake, "id")}}],
            appends=(
                "f_task_owner_post",
                "f_task_owner_post.parent",
                "f_intake_type",
            ),
        ),
    )
    native_submit = create_node(
        api,
        workflow_id,
        "subflow",
        SUBMIT_TITLE,
        {
            "workflow": INTAKE_SUBMIT_WORKFLOW_KEY,
            "context": {
                "data": ref(load_intake),
                "userId": ref(resolve_submitter, "id"),
                "roleName": None,
            },
        },
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark succeeded + backfill IDs",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(intake, "id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": context("f_rch_id"),
            },
        ),
    )
    failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark failed + backfill Intake ID",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "failed",
                "f_intake_id": ref(intake, "id"),
            },
        ),
    )

    link(api, processing, parse)
    link(api, parse, resolve_submitter)
    link(api, resolve_submitter, intake)
    link(api, intake, apply_identity)
    link(api, apply_identity, application)
    link(api, application, exists)
    link(api, exists, apply_chi, branch_index=1)
    link(api, exists, failed, branch_index=0)
    link(api, apply_chi, checklist_loop)
    link(api, checklist_loop, find_template, branch_index=0)
    link(api, find_template, find_item)
    link(api, find_item, item_exists)
    link(api, item_exists, update_item, branch_index=1)
    link(api, item_exists, create_item, branch_index=0)
    link(api, checklist_loop, load_intake)
    link(api, load_intake, native_submit)
    link(api, native_submit, succeeded)


def build_update_graph(api: NocoBaseApi, workflow_id: int) -> None:
    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark update processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    processing["config"]["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "submitted"}},
        ]
    }
    api.update_node(int(processing["id"]), {"config": processing["config"]})
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged CHI update body",
        chi_parse_config(),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {"f_application_status": {"$eq": "Accepted"}},
            ],
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked CHI",
        query_config(
            APPLICATION_COLLECTION,
            [{"id": {"$eq": ref(original, "f_application_id")}}],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked CHI exists",
        exists_config(application),
    )
    apply_chi = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged CHI update overlay",
        update_config(
            APPLICATION_COLLECTION,
            ref(application, "id"),
            overlay_values(parse),
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark update succeeded + backfill IDs",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(original, "f_intake_id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": ref(original, "f_rch_id"),
            },
        ),
    )
    link(api, processing, parse)
    link(api, parse, original)
    link(api, original, application)
    link(api, application, exists)
    link(api, exists, apply_chi, branch_index=1)
    link(api, apply_chi, succeeded)


def build_create_bridge(api: NocoBaseApi, workflow_id: int) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {
                    "$or": [
                        {"f_application_id": {"$eq": context("id")}},
                        {"f_intake_id": {"$eq": context("fk_intake_form")}},
                    ]
                },
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    create_cmtf = create_node(
        api,
        workflow_id,
        "create",
        "Create CMTF CHI staging at Accepted",
        {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": CREATE_API_TYPE,
                    "f_application_type": APPLICATION_TYPE,
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": context("f_office_cd"),
                    "f_intake_id": context("fk_intake_form"),
                    "f_application_id": context("id"),
                    "f_rch_id": context("fk_home_record"),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        },
    )
    # Staging only. Never update t_change_home_information_app status fields.
    link(api, staging, exists)
    link(api, exists, create_cmtf, branch_index=0)


def build_received_bridge(api: NocoBaseApi, workflow_id: int) -> None:
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked CHI",
        query_config(
            APPLICATION_COLLECTION,
            [{"fk_intake_form": {"$eq": context("id")}}],
        ),
    )
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_intake_id": {"$eq": context("id")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging),
    )
    update_existing = create_node(
        api,
        workflow_id,
        "update",
        "Publish Received on existing CREATE staging",
        update_config(
            "t_api_request_staging",
            ref(staging, "id"),
            {
                "f_application_status": "Received",
                "f_application_id": ref(application, "id"),
                "f_office_code": context("f_office_cd"),
            },
        ),
    )
    link(api, application, staging)
    link(api, staging, exists)
    link(api, exists, update_existing, branch_index=1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument(
        "--ensure-create-bridge",
        action="store_true",
        help=(
            "Only ensure CMTF-native CHI create-to-staging; do not recreate "
            "Create/Update"
        ),
    )
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=C")
    print(f"create_title={CREATE_TITLE}")
    print(f"update_title={UPDATE_TITLE}")
    print(f"create_bridge_title={CREATE_BRIDGE_TITLE}")
    print(f"received_bridge_title={RECEIVED_BRIDGE_TITLE}")
    print(f"chi_intake_type_id={CHI_INTAKE_TYPE_ID}")
    print(f"intake_submit_workflow_key={INTAKE_SUBMIT_WORKFLOW_KEY}")
    print("submit_identity=form_data.case_summary.submitter_user_id")
    print("intake_target_status=Pending Recommendation")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    if args.ensure_create_bridge:
        ensure_enabled_workflow(
            api,
            title=CREATE_BRIDGE_TITLE,
            collection=APPLICATION_COLLECTION,
            builder=build_create_bridge,
        )
        print("mode=applied")
        return 0

    created_ids: list[int] = []
    try:
        ensure_staging_fields(api)
        for title in (CREATE_TITLE, UPDATE_TITLE):
            require_absent(api, title)

        create_wf = create_workflow(
            api,
            title=CREATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("CREATE", CREATE_API_TYPE),
        )
        created_ids.append(int(create_wf["id"]))
        build_create_graph(api, int(create_wf["id"]))

        update_wf = create_workflow(
            api,
            title=UPDATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("UPDATE", UPDATE_API_TYPE),
        )
        created_ids.append(int(update_wf["id"]))
        build_update_graph(api, int(update_wf["id"]))

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            final = api.get_workflow(workflow_id)
            print(f"workflow_id={final.get('id')}")
            print(f"workflow_title={final.get('title')}")
            print(f"enabled={str(bool(final.get('enabled'))).lower()}")
            print(f"node_count={len(final.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
