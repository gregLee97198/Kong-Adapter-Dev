#!/usr/bin/env python3
"""Create Phase-D Closure staging workflows on NocoBase.

Native Create-From-Intake workflows already build t_self_withdraw_licence_application
when Intake type is Self-withdraw or Revoke and fk_intake_source_rch is set.
These sidecar workflows only write Staging, Intake, the shared Closure overlay
fields and checklist. New API workflows are mounted under API Suorce.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    create_workflow,
    exists_config,
    link,
    parse_variable,
    query_config,
    require_absent,
    set_enabled,
    update_config,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import external_source_condition

APPLICATION_COLLECTION = "t_self_withdraw_licence_application"
SELF_WITHDRAW_INTAKE_TYPE_ID = 379733733081088
REVOKE_LICENCE_INTAKE_TYPE_ID = 379733764538368

CHECKLIST_CODES = (
    (384035867525120, "LORCHE_SELF_WITHDRAW_001"),
    (384035943022592, "LORCHE_SELF_WITHDRAW_002"),
    (384035966091264, "LORCHE_SELF_WITHDRAW_003"),
    (384035989159936, "LORCHE_SELF_WITHDRAW_004"),
)

SELF_WITHDRAW_SCALAR_FIELD_MAP = {
    "applicant_title": "f_applicant_title",
    "applicant_name_en": "f_applicant_name_eng",
    "applicant_name_cn": "f_applicant_name_chi",
    "applicant_position": "f_applicant_position",
    "means_of_authorisation": "f_means_of_authorisation",
    "tentative_date_of_closure": "f_tentative_date_of_closure",
    "reason_for_closure": "f_reason_for_closure",
    "reason_for_closure_others": "f_reason_for_closure_others",
    "comments": "f_comments",
}

CLOSURE_APPLICATION_CASE_FIELD_MAP = {
    "received_date": "f_received_date",
}

CLOSURE_INTAKE_CASE_FIELD_MAP = {
    "received_date": "f_received_date",
    "severity": "f_severity",
    "source_id": "fk_intake_source",
    "source_other": "f_source_other",
    "task_owner_user_id": "fk_task_owner",
    "task_owner_post_code": "fk_task_owner_post",
}

ATOMIC_STAGING_CLAIM_SQL = (
    'UPDATE "t_api_request_staging" SET "f_status"=\'processing\' '
    'WHERE "id"=:stagingId AND "f_status"=\'submitted\' RETURNING "id";'
)
ATOMIC_UPDATE_STAGING_CLAIM_SQL = (
    'UPDATE "t_api_request_staging" AS staged SET "f_status"=\'processing\' '
    'WHERE staged."id"=:stagingId AND staged."f_status"=\'submitted\' '
    'AND EXISTS (SELECT 1 FROM "t_api_request_staging" AS parent '
    'WHERE CAST(parent."id" AS text)=staged."f_parent_create_id" '
    'AND parent."f_request_event"=\'CREATE\' '
    'AND parent."f_status"=\'succeeded\' '
    'AND parent."f_application_status"=\'Accepted\' '
    'AND parent."f_intake_id" IS NOT NULL '
    'AND parent."f_application_id" IS NOT NULL '
    'AND staged."f_active_update_id" IS NOT NULL '
    'AND parent."f_active_update_id"=staged."f_active_update_id") '
    'AND NOT EXISTS (SELECT 1 FROM "t_api_request_staging" AS active '
    'WHERE active."f_request_event"=\'UPDATE\' '
    'AND active."f_parent_create_id"=staged."f_parent_create_id" '
    'AND active."id"<>staged."id" '
    'AND (active."f_status"=\'processing\' '
    'OR (active."id"<staged."id" AND active."f_status"=\'submitted\'))) '
    'RETURNING staged."id";'
)


def deferred_received_config(bp: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "dataSource": "main",
        "sql": (
            'UPDATE "t_api_request_staging" AS create_row SET '
            '"f_active_update_id"=NULL, '
            '"f_application_status"=CASE WHEN '
            'create_row."f_application_status"=\'Accepted\' '
            'AND EXISTS (SELECT 1 FROM "t_intake_form" AS intake '
            'WHERE CAST(intake."id" AS text)='
            'CAST(create_row."f_intake_id" AS text) '
            'AND CAST(intake."f_approval_status" AS text)=\'4\') '
            'AND NOT EXISTS (SELECT 1 FROM "t_api_request_staging" AS active '
            'WHERE active."f_request_event"=\'UPDATE\' '
            'AND active."f_parent_create_id"=CAST(create_row."id" AS text) '
            'AND active."f_status" IN (\'submitted\',\'processing\')) '
            'THEN \'Received\' ELSE create_row."f_application_status" END '
            'WHERE CAST(create_row."id" AS text)=:parentCreateId '
            'AND create_row."f_status"=\'succeeded\' '
            'AND create_row."f_request_event"=\'CREATE\' '
            'AND create_row."f_api_type"=:createApiType '
            'AND create_row."f_application_type"=:applicationType '
            'AND create_row."f_active_update_id"=:activeUpdateId '
            'RETURNING create_row."id";'
        ),
        "variables": [
            {"name": "parentCreateId", "value": context("f_parent_create_id")},
            {"name": "activeUpdateId", "value": context("f_active_update_id")},
            {"name": "createApiType", "value": bp["create_api_type"]},
            {"name": "applicationType", "value": bp["application_type"]},
        ],
        "withMeta": False,
        "unsafeInjection": False,
    }


def add_deferred_received_finalizer(
    api: NocoBaseApi,
    workflow_id: int,
    upstream: Mapping[str, Any],
    bp: Mapping[str, Any],
    title_suffix: str,
    *,
    branch_index: int | None = None,
) -> Mapping[str, Any]:
    node = create_node(
        api,
        workflow_id,
        "sql",
        f"Finalize deferred Received after {title_suffix}",
        deferred_received_config(bp),
    )
    link(api, upstream, node, branch_index=branch_index)
    return node

BPS: tuple[dict[str, Any], ...] = (
    {
        "key": "self",
        "application_type": "self_withdraw",
        "application_label": "Closure - Self-withdraw Licence",
        "create_api_type": "create_intake_for_self_withdraw",
        "update_api_type": "update_self_withdraw_data",
        "intake_type_id": SELF_WITHDRAW_INTAKE_TYPE_ID,
        "create_title": ("API Request Staging — Create Self-withdraw Licence v1"),
        "update_title": ("API Request Staging — Update Self-withdraw Licence v1"),
        "create_bridge_title": (
            "API Bridge — Self-withdraw Application Created to Staging v1"
        ),
        "received_bridge_title": (
            "API Bridge — Self-withdraw Intake Completed to Received v1"
        ),
        "include_checklist": True,
    },
    {
        "key": "revoke",
        "application_type": "revoke_licence",
        "application_label": "Closure - Revoke Licence",
        "create_api_type": "create_intake_for_revoke_licence",
        "update_api_type": "update_revoke_licence_data",
        "intake_type_id": REVOKE_LICENCE_INTAKE_TYPE_ID,
        "create_title": "API Request Staging — Create Revoke Licence v1",
        "update_title": "API Request Staging — Update Revoke Licence v1",
        "create_bridge_title": (
            "API Bridge — Revoke Licence Application Created to Staging v1"
        ),
        "received_bridge_title": (
            "API Bridge — Revoke Licence Intake Completed to Received v1"
        ),
        "include_checklist": True,
    },
)


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def scope(node: Mapping[str, Any], field: str) -> str:
    return "{{$scopes." + str(node["key"]) + ".item." + field + "}}"


def closure_parse_config(bp: Mapping[str, Any]) -> dict[str, Any]:
    example: dict[str, Any] = {
        "request_id": f"{bp['key'].upper()}-20260914-0001",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "lorche_d_no": "L0043",
                "received_date": "2026-09-14",
                "severity": "0",
                "source_id": 701,
                "source_other": "OP",
                "submitter_user_id": 12,
                "task_owner_user_id": 45,
                "task_owner_post_code": "S(LR)1",
            },
            "comments": "Phase D overlay",
        },
    }
    variables = [
        parse_variable("form_data", "formData"),
        parse_variable("form_data.case_summary.office_code", "officeCode"),
        parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
        parse_variable("form_data.case_summary.received_date", "receivedDate"),
        parse_variable("form_data.case_summary.severity", "severity"),
        parse_variable("form_data.case_summary.source_id", "sourceId"),
        parse_variable("form_data.case_summary.source_other", "sourceOther"),
        parse_variable("form_data.case_summary.submitter_user_id", "submitterId"),
        parse_variable("form_data.case_summary.task_owner_user_id", "ownerId"),
        parse_variable("form_data.case_summary.task_owner_post_code", "ownerPost"),
        parse_variable("form_data.comments", "comments"),
        parse_variable("create_id", "createId"),
    ]
    example["form_data"].update(
        {
            "applicant_title": "0",
            "applicant_name_en": "Example Applicant",
            "applicant_name_cn": "示例申请人",
            "applicant_position": "Operator",
            "means_of_authorisation": "1",
            "tentative_date_of_closure": "2026-12-31",
            "reason_for_closure": "others",
            "reason_for_closure_others": "Operator-initiated closure",
            "comments": "Closure request submitted by OP",
            "checklist": [
                {
                    "position_code": "LORCHE_SELF_WITHDRAW_001",
                    "attachment_id": 501,
                },
                {
                    "position_code": "LORCHE_SELF_WITHDRAW_002",
                    "attachment_id": 502,
                },
                {
                    "position_code": "LORCHE_SELF_WITHDRAW_003",
                    "attachment_id": 503,
                },
                {
                    "position_code": "LORCHE_SELF_WITHDRAW_004",
                    "attachment_id": 504,
                },
            ],
        }
    )
    variables.extend(
        [
            parse_variable("form_data.applicant_title", "applicantTitle"),
            parse_variable("form_data.applicant_name_en", "applicantNameEn"),
            parse_variable("form_data.applicant_name_cn", "applicantNameCn"),
            parse_variable("form_data.applicant_position", "applicantPosition"),
            parse_variable(
                "form_data.means_of_authorisation", "meansOfAuthorisation"
            ),
            parse_variable(
                "form_data.tentative_date_of_closure", "tentativeClosureDate"
            ),
            parse_variable("form_data.reason_for_closure", "reasonForClosure"),
            parse_variable("form_data.reason_for_closure_others", "reasonOthers"),
            parse_variable("form_data.checklist", "checklist"),
            parse_variable(
                "form_data.checklist[].position_code", "checklistPosition"
            ),
            parse_variable(
                "form_data.checklist[].attachment_id", "checklistAttachment"
            ),
        ]
    )
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": example,
        "variables": variables,
    }


def overlay_values(bp: Mapping[str, Any], parse: Mapping[str, Any]) -> dict[str, Any]:
    values: dict[str, Any] = {
        "fk_home_record_id": context("f_rch_id"),
        "f_office_cd": ref(parse, "officeCode"),
        "f_comments": ref(parse, "comments"),
        "f_closure_workflow_type": bp["key"],
        "f_received_date": ref(parse, "receivedDate"),
    }
    values.update(
        {
            "f_applicant_title": ref(parse, "applicantTitle"),
            "f_applicant_name_eng": ref(parse, "applicantNameEn"),
            "f_applicant_name_chi": ref(parse, "applicantNameCn"),
            "f_applicant_position": ref(parse, "applicantPosition"),
            "f_means_of_authorisation": ref(parse, "meansOfAuthorisation"),
            "f_tentative_date_of_closure": ref(parse, "tentativeClosureDate"),
            "f_reason_for_closure": ref(parse, "reasonForClosure"),
            "f_reason_for_closure_others": ref(parse, "reasonOthers"),
        }
    )
    return values


def staging_failed_values(
    reason: str,
    *,
    intake_id: str | None = None,
    application_id: str | None = None,
) -> dict[str, Any]:
    values: dict[str, Any] = {
        "f_status": "failed",
        "f_error_message": reason,
    }
    if intake_id is not None:
        values["f_intake_id"] = intake_id
    if application_id is not None:
        values["f_application_id"] = application_id
    return values


def guarded_patch_script(bp: Mapping[str, Any]) -> str:
    """Return a complete scalar patch without clearing omitted API fields."""

    scalar_map = SELF_WITHDRAW_SCALAR_FIELD_MAP
    replacements = {
        "__SCALAR_MAP__": json.dumps(scalar_map, ensure_ascii=False),
        "__APPLICATION_CASE_MAP__": json.dumps(
            CLOSURE_APPLICATION_CASE_FIELD_MAP, ensure_ascii=False
        ),
        "__INTAKE_CASE_MAP__": json.dumps(
            CLOSURE_INTAKE_CASE_FIELD_MAP, ensure_ascii=False
        ),
    }
    script = """const f = formData || {};
const current = application || {};
const own = (value, key) => value
  && Object.prototype.hasOwnProperty.call(value, key);
const patch = {};
const scalarMap = __SCALAR_MAP__;
for (const [external, internal] of Object.entries(scalarMap)) {
  patch[internal] = own(f, external) ? f[external] : current[internal];
}
const summary = f.case_summary || {};
const applicationCaseMap = __APPLICATION_CASE_MAP__;
for (const [external, internal] of Object.entries(applicationCaseMap)) {
  patch[internal] = own(summary, external)
    ? summary[external] : current[internal];
}
const currentIntake = intake || {};
const intakePatch = {};
const intakeCaseMap = __INTAKE_CASE_MAP__;
for (const [external, internal] of Object.entries(intakeCaseMap)) {
  intakePatch[internal] = own(summary, external)
    ? summary[external] : currentIntake[internal];
}
return { patch, intake_patch: intakePatch };"""
    for marker, value in replacements.items():
        script = script.replace(marker, value)
    return script


def field_references(
    node: Mapping[str, Any], prefix: str, fields: list[str]
) -> dict[str, str]:
    return {field: ref(node, f"{prefix}.{field}") for field in fields}


def processing_only_update_config(
    record_id: str, values: Mapping[str, Any]
) -> dict[str, Any]:
    config = update_config("t_api_request_staging", record_id, values)
    config["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": record_id}},
            {"f_status": {"$eq": "processing"}},
        ]
    }
    return config


def add_atomic_staging_claim(
    api: NocoBaseApi,
    workflow_id: int,
    *,
    title_prefix: str,
    require_ready_parent: bool = False,
) -> dict[str, Any]:
    """Claim one submitted row without a read-after-update race window."""

    claim = create_node(
        api,
        workflow_id,
        "sql",
        f"Atomically claim submitted {title_prefix} row",
        {
            "dataSource": "main",
            "sql": (
                ATOMIC_UPDATE_STAGING_CLAIM_SQL
                if require_ready_parent
                else ATOMIC_STAGING_CLAIM_SQL
            ),
            "withMeta": False,
            "unsafeInjection": False,
            "variables": [
                {"name": "stagingId", "value": context("id")},
            ],
        },
    )
    row_count = create_node(
        api,
        workflow_id,
        "script",
        f"Validate {title_prefix} claim row count",
        {
            "arguments": [{"name": "rows", "value": ref(claim)}],
            "content": "return Array.isArray(rows) && rows.length === 1;",
            "timeout": 3000,
            "continue": False,
        },
    )
    claimed = create_node(
        api,
        workflow_id,
        "condition",
        f"{title_prefix} claim succeeded",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [ref(row_count), True],
                        }
                    ],
                }
            },
        },
    )
    link(api, claim, row_count)
    link(api, row_count, claimed)
    return claimed


def add_rejected_staging_claim_finalizer(
    api: NocoBaseApi,
    workflow_id: int,
    claimed: Mapping[str, Any],
    *,
    title_prefix: str,
    reason: str,
) -> Mapping[str, Any]:
    """Fail only an unclaimed submitted row; never overwrite a winning run."""

    rejected = create_node(
        api,
        workflow_id,
        "sql",
        f"Finalize rejected {title_prefix} claim",
        {
            "dataSource": "main",
            "sql": (
                'UPDATE "t_api_request_staging" SET '
                '"f_status"=\'failed\', "f_error_message"=:reason '
                'WHERE "id"=:stagingId AND "f_status"=\'submitted\' '
                'RETURNING "id";'
            ),
            "variables": [
                {"name": "stagingId", "value": context("id")},
                {"name": "reason", "value": reason},
            ],
            "withMeta": False,
            "unsafeInjection": False,
        },
    )
    link(api, claimed, rejected, branch_index=0)
    row_count = create_node(
        api,
        workflow_id,
        "script",
        f"Validate rejected {title_prefix} claim row count",
        {
            "arguments": [{"name": "rows", "value": ref(rejected)}],
            "content": "return Array.isArray(rows) && rows.length === 1;",
            "timeout": 3000,
            "continue": False,
        },
    )
    finalized = create_node(
        api,
        workflow_id,
        "condition",
        f"Rejected {title_prefix} claim finalized",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [ref(row_count), True],
                        }
                    ],
                }
            },
        },
    )
    link(api, rejected, row_count)
    link(api, row_count, finalized)
    return finalized


def add_processing_completion_guard(
    api: NocoBaseApi,
    workflow_id: int,
    upstream: Mapping[str, Any],
    *,
    title_prefix: str,
) -> dict[str, Any]:
    reload_staging = create_node(
        api,
        workflow_id,
        "query",
        f"Reload processing Staging after {title_prefix}",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": context("id")}},
                {"f_status": {"$eq": "processing"}},
            ],
        ),
    )
    still_processing = create_node(
        api,
        workflow_id,
        "condition",
        f"{title_prefix} completed without failure",
        exists_config(reload_staging, reject_on_false=False),
    )
    link(api, upstream, reload_staging)
    link(api, reload_staging, still_processing)
    return still_processing


def add_checklist_preflight_graph(
    api: NocoBaseApi,
    workflow_id: int,
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    upstream: Mapping[str, Any],
    *,
    intake_id: str,
) -> Mapping[str, Any]:
    """Revalidate Closure checklist references before any Update write."""

    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Preflight Closure Checklist files",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
    )
    template = create_node(
        api,
        workflow_id,
        "query",
        "Preflight Closure checklist template",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$eq": scope(loop, "position_code")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {"f_use_for": {"$anyOf": [APPLICATION_COLLECTION]}},
            ],
        ),
    )
    template_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Preflight Closure checklist template exists",
        exists_config(template, reject_on_false=False),
    )
    invalid_template = create_node(
        api,
        workflow_id,
        "update",
        "Mark Closure checklist preflight template failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values(
                "checklist_template_not_resolved",
                intake_id=intake_id,
                application_id=ref(application, "id"),
            ),
        ),
    )
    attachment = create_node(
        api,
        workflow_id,
        "query",
        "Preflight Closure Checklist attachment",
        query_config(
            "attachments", [{"id": {"$eq": scope(loop, "attachment_id")}}]
        ),
    )
    attachment_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Preflight Closure Checklist attachment exists",
        exists_config(attachment, reject_on_false=False),
    )
    invalid_attachment = create_node(
        api,
        workflow_id,
        "update",
        "Mark Closure checklist preflight attachment failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values(
                "checklist_attachment_not_resolved",
                intake_id=intake_id,
                application_id=ref(application, "id"),
            ),
        ),
    )
    item_ok = create_node(
        api,
        workflow_id,
        "script",
        "Closure checklist preflight item passed",
        {
            "arguments": [],
            "content": "return true;",
            "timeout": 3000,
            "continue": False,
        },
    )
    reload_staging = create_node(
        api,
        workflow_id,
        "query",
        "Reload processing Staging after Closure checklist preflight",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": context("id")}},
                {"f_status": {"$eq": "processing"}},
            ],
        ),
    )
    valid = create_node(
        api,
        workflow_id,
        "condition",
        "Closure checklist preflight completed without failure",
        exists_config(reload_staging, reject_on_false=False),
    )
    link(api, upstream, loop)
    link(api, loop, template, branch_index=0)
    link(api, template, template_exists)
    link(api, template_exists, invalid_template, branch_index=0)
    link(api, template_exists, attachment, branch_index=1)
    link(api, attachment, attachment_exists)
    link(api, attachment_exists, invalid_attachment, branch_index=0)
    link(api, attachment_exists, item_ok, branch_index=1)
    link(api, loop, reload_staging)
    link(api, reload_staging, valid)
    return valid


def add_checklist_graph(
    api: NocoBaseApi,
    workflow_id: int,
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    upstream: Mapping[str, Any],
    *,
    intake_id: str,
) -> dict[str, Any]:
    """Write upload Details first, then refresh the current Latest relation."""

    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply Closure Checklist files",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
    )
    template = create_node(
        api,
        workflow_id,
        "query",
        "Resolve Closure checklist template by position_code",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$eq": scope(loop, "position_code")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {"f_use_for": {"$anyOf": [APPLICATION_COLLECTION]}},
            ],
        ),
    )
    template_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Closure checklist template exists",
        exists_config(template, reject_on_false=False),
    )
    invalid_template = create_node(
        api,
        workflow_id,
        "update",
        "Mark Closure checklist template failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values(
                "checklist_template_not_resolved",
                intake_id=intake_id,
                application_id=ref(application, "id"),
            ),
        ),
    )
    attachment = create_node(
        api,
        workflow_id,
        "query",
        "Load Closure Checklist attachment",
        query_config(
            "attachments",
            [{"id": {"$eq": scope(loop, "attachment_id")}}],
        ),
    )
    attachment_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Closure Checklist attachment exists",
        exists_config(attachment, reject_on_false=False),
    )
    invalid_attachment = create_node(
        api,
        workflow_id,
        "update",
        "Mark Closure Checklist attachment failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values(
                "checklist_attachment_not_resolved",
                intake_id=intake_id,
                application_id=ref(application, "id"),
            ),
        ),
    )
    item = create_node(
        api,
        workflow_id,
        "query",
        "Find native Closure checklist item",
        query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"fk_document_checklist": {"$eq": ref(template, "id")}},
                {"f_business_type": {"$eq": APPLICATION_COLLECTION}},
            ],
        ),
    )
    item_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native Closure checklist item exists",
        exists_config(item, reject_on_false=False),
    )
    update_item = create_node(
        api,
        workflow_id,
        "update",
        "Mark existing Closure checklist item checked",
        update_config(
            "t_document_submitted_for_application",
            ref(item, "id"),
            {"f_is_checked": True},
        ),
    )
    create_item = create_node(
        api,
        workflow_id,
        "create",
        "Create Closure checklist item without Latest",
        {
            "collection": "t_document_submitted_for_application",
            "params": {
                "values": {
                    "f_business_key": ref(application, "id"),
                    "f_business_type": APPLICATION_COLLECTION,
                    "fk_document_checklist": ref(template, "id"),
                    "f_is_checked": True,
                },
                "appends": [],
            },
        },
    )

    def detail(parent: Mapping[str, Any], title: str) -> dict[str, Any]:
        return create_node(
            api,
            workflow_id,
            "create",
            title,
            {
                "collection": "t_document_submitted_for_application_details",
                "params": {
                    "values": {
                        "fk_documests_submitted_for_application_id": ref(parent, "id"),
                        "f_files": [scope(loop, "attachment_id")],
                        "f_file_name": ref(attachment, "filename"),
                        "f_file_date": ref(attachment, "createdAt"),
                    },
                    "appends": [],
                },
            },
        )

    existing_detail = detail(item, "Create existing Closure Checklist upload Details")
    new_detail = detail(create_item, "Create new Closure Checklist upload Details")
    latest_values = {
        "f_lastest_files": [scope(loop, "attachment_id")],
        "f_lastest_files_name": ref(attachment, "filename"),
        "f_lastest_file_date": ref(attachment, "createdAt"),
    }

    def latest(parent: Mapping[str, Any], title: str) -> dict[str, Any]:
        config = update_config(
            "t_document_submitted_for_application",
            ref(parent, "id"),
            latest_values,
        )
        config["params"]["individualHooks"] = True
        return create_node(api, workflow_id, "update", title, config)

    existing_latest = latest(item, "Refresh existing Closure Checklist Latest")
    new_latest = latest(create_item, "Refresh new Closure Checklist Latest")

    link(api, upstream, loop)
    link(api, loop, template, branch_index=0)
    link(api, template, template_exists)
    link(api, template_exists, invalid_template, branch_index=0)
    link(api, template_exists, attachment, branch_index=1)
    link(api, attachment, attachment_exists)
    link(api, attachment_exists, invalid_attachment, branch_index=0)
    link(api, attachment_exists, item, branch_index=1)
    link(api, item, item_exists)
    link(api, item_exists, update_item, branch_index=1)
    link(api, item_exists, create_item, branch_index=0)
    link(api, update_item, existing_detail)
    link(api, existing_detail, existing_latest)
    link(api, create_item, new_detail)
    link(api, new_detail, new_latest)
    return add_processing_completion_guard(
        api,
        workflow_id,
        loop,
        title_prefix="Closure Checklist",
    )


def ensure_checklist_codes(api: NocoBaseApi) -> None:
    for record_id, code in CHECKLIST_CODES:
        row = api.request(
            "GET",
            "/api/t_document_checklist:get?"
            + urllib.parse.urlencode({"filterByTk": str(record_id)}),
        )
        if not isinstance(row, dict):
            raise ApiError(f"Checklist leaf {record_id} was not found")
        current = str(row.get("f_position_code") or "").strip()
        if current == code:
            print(f"existing_position_code={code}")
            continue
        if current:
            raise ApiError(
                f"Checklist {record_id} already has position_code {current!r}"
            )
        api.request(
            "POST",
            "/api/t_document_checklist:update?"
            + urllib.parse.urlencode({"filterByTk": str(record_id)}),
            {"f_position_code": code},
        )
        print(f"assigned_position_code={code}")


def ensure_application_type_enums(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    changed = False
    for bp in BPS:
        if any(item.get("value") == bp["application_type"] for item in options):
            print(f"existing_enum=f_application_type.{bp['application_type']}")
            continue
        options.append(
            {"value": bp["application_type"], "label": bp["application_label"]}
        )
        changed = True
        print(f"updated_enum=f_application_type.{bp['application_type']}")
    if changed:
        ui_schema["enum"] = options
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:update?"
            + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
            {"uiSchema": ui_schema},
        )


def build_create_graph(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    claim_succeeded = add_atomic_staging_claim(
        api,
        workflow_id,
        title_prefix="Closure CREATE",
    )
    add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claim_succeeded,
        title_prefix="Closure CREATE",
        reason="create_claim_rejected",
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        f"Parse staged {bp['key']} request body",
        closure_parse_config(bp),
    )
    home = create_node(
        api,
        workflow_id,
        "query",
        "Resolve Closure Home Record before Intake",
        query_config(
            "t_home_record",
            [{"id": {"$eq": context("f_rch_id")}}],
        ),
    )
    home_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Closure Home Record exists",
        exists_config(home, reject_on_false=False),
    )
    home_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Closure Home Record failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values("home_record_not_resolved"),
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "create",
        "Create Intake (fixed Closure type + Home Record)",
        {
            "collection": "t_intake_form",
            "params": {
                "values": {
                    "fk_intake_type": bp["intake_type_id"],
                    "fk_intake_source_rch": context("f_rch_id"),
                    "fk_task_owner_post": ref(parse, "ownerPost"),
                    "fk_intake_source": ref(parse, "sourceId"),
                    "fk_task_owner": ref(parse, "ownerId"),
                    "f_severity": ref(parse, "severity"),
                    "f_received_date": ref(parse, "receivedDate"),
                    "f_source_other": ref(parse, "sourceOther"),
                    "f_office_cd": ref(parse, "officeCode"),
                    "f_subject": ref(home, "f_rch_no"),
                    "f_comments": ref(parse, "comments"),
                    "f_api_create_staging_id": context("id"),
                    "createdBy": ref(parse, "submitterId"),
                },
                "appends": [],
            },
        },
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Find native-created Closure application",
        query_config(
            APPLICATION_COLLECTION,
            [{"fk_intake_form": {"$eq": ref(intake, "id")}}],
        ),
    )
    early_backfill = create_node(
        api,
        workflow_id,
        "update",
        "Backfill Closure Intake ID before native application lookup",
        processing_only_update_config(
            context("id"),
            {"f_intake_id": ref(intake, "id")},
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native Closure application exists",
        exists_config(application, reject_on_false=False),
    )
    apply_overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged overlay to native Closure",
        update_config(
            APPLICATION_COLLECTION,
            ref(application, "id"),
            overlay_values(bp, parse),
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark succeeded + backfill IDs",
        processing_only_update_config(
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(intake, "id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": context("f_rch_id"),
            },
        ),
    )
    failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark failed + backfill Intake ID",
        processing_only_update_config(
            context("id"),
            staging_failed_values(
                "native_closure_application_not_resolved",
                intake_id=ref(intake, "id"),
            ),
        ),
    )
    link(api, claim_succeeded, parse, branch_index=1)
    link(api, parse, home)
    link(api, home, home_exists)
    link(api, home_exists, home_failed, branch_index=0)
    link(api, home_exists, intake, branch_index=1)
    link(api, intake, early_backfill)
    link(api, early_backfill, application)
    link(api, application, exists)
    link(api, exists, apply_overlay, branch_index=1)
    link(api, exists, failed, branch_index=0)
    if not bp["include_checklist"]:
        completion = add_processing_completion_guard(
            api,
            workflow_id,
            apply_overlay,
            title_prefix="Closure overlay",
        )
        link(api, completion, succeeded, branch_index=1)
        return
    checklist_ok = add_checklist_graph(
        api,
        workflow_id,
        parse,
        application,
        apply_overlay,
        intake_id=ref(intake, "id"),
    )
    link(api, checklist_ok, succeeded, branch_index=1)


def build_update_graph(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    claim_succeeded = add_atomic_staging_claim(
        api,
        workflow_id,
        title_prefix="Closure UPDATE",
        require_ready_parent=True,
    )
    claim_rejected = add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claim_succeeded,
        title_prefix="Closure UPDATE",
        reason="update_claim_rejected",
    )
    add_deferred_received_finalizer(
        api,
        workflow_id,
        claim_rejected,
        bp,
        "rejected Closure Update claim",
        branch_index=1,
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        f"Parse staged {bp['key']} update body",
        closure_parse_config(bp),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
                {"f_status": {"$eq": "succeeded"}},
                {"f_application_status": {"$eq": "Accepted"}},
                {"f_intake_id": {"$notEmpty": True}},
                {"f_application_id": {"$notEmpty": True}},
            ],
        ),
    )
    original_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Accepted Closure parent CREATE exists",
        exists_config(original, reject_on_false=False),
    )
    original_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Closure update parent/lock failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values("update_parent_not_accepted_or_not_found"),
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Closure Intake",
        query_config(
            "t_intake_form",
            [{"id": {"$eq": ref(original, "f_intake_id")}}],
        ),
    )
    intake_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Closure Intake exists",
        exists_config(intake, reject_on_false=False),
    )
    intake_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Closure Intake failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values("linked_closure_intake_not_resolved"),
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Closure application",
        query_config(
            APPLICATION_COLLECTION,
            [{"id": {"$eq": ref(original, "f_application_id")}}],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Closure application exists",
        exists_config(application, reject_on_false=False),
    )
    application_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Closure application failure",
        processing_only_update_config(
            context("id"),
            staging_failed_values(
                "linked_closure_application_not_resolved",
                intake_id=ref(original, "f_intake_id"),
            ),
        ),
    )
    terminal_failures: list[Mapping[str, Any]] = [
        original_failed,
        intake_failed,
        application_failed,
    ]
    normalize = create_node(
        api,
        workflow_id,
        "script",
        f"Project guarded {bp['key']} Closure update patch",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "application", "value": ref(application)},
                {"name": "intake", "value": ref(intake)},
            ],
            "content": guarded_patch_script(bp),
            "timeout": 3000,
            "continue": False,
        },
    )
    scalar_map = SELF_WITHDRAW_SCALAR_FIELD_MAP
    patch_fields = sorted(
        {
            *scalar_map.values(),
            *CLOSURE_APPLICATION_CASE_FIELD_MAP.values(),
        }
    )
    apply_intake = create_node(
        api,
        workflow_id,
        "update",
        "Apply guarded Closure Intake update",
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            field_references(
                normalize,
                "intake_patch",
                sorted(CLOSURE_INTAKE_CASE_FIELD_MAP.values()),
            ),
        ),
    )
    apply_overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged Closure update overlay",
        update_config(
            APPLICATION_COLLECTION,
            ref(application, "id"),
            field_references(normalize, "patch", patch_fields),
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark update succeeded + backfill IDs",
        processing_only_update_config(
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(original, "f_intake_id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": ref(original, "f_rch_id"),
                "f_parent_create_id": ref(original, "id"),
            },
        ),
    )
    link(api, claim_succeeded, parse, branch_index=1)
    link(api, parse, original)
    link(api, original, original_exists)
    link(api, original_exists, original_failed, branch_index=0)
    link(api, original_exists, intake, branch_index=1)
    link(api, intake, intake_exists)
    link(api, intake_exists, intake_failed, branch_index=0)
    link(api, intake_exists, application, branch_index=1)
    link(api, application, exists)
    link(api, exists, application_failed, branch_index=0)
    link(api, exists, normalize, branch_index=1)
    if bp["include_checklist"]:
        checklist_preflight = add_checklist_preflight_graph(
            api,
            workflow_id,
            parse,
            application,
            normalize,
            intake_id=ref(original, "f_intake_id"),
        )
        add_deferred_received_finalizer(
            api,
            workflow_id,
            checklist_preflight,
            bp,
            "Closure checklist preflight failure",
            branch_index=0,
        )
        link(api, checklist_preflight, apply_intake, branch_index=1)
    else:
        link(api, normalize, apply_intake)
    link(api, apply_intake, apply_overlay)
    if bp["include_checklist"]:
        checklist_ok = add_checklist_graph(
            api,
            workflow_id,
            parse,
            application,
            apply_overlay,
            intake_id=ref(original, "f_intake_id"),
        )
        link(api, checklist_ok, succeeded, branch_index=1)
        add_deferred_received_finalizer(
            api,
            workflow_id,
            checklist_ok,
            bp,
            "Closure checklist commit failure",
            branch_index=0,
        )
        add_deferred_received_finalizer(
            api, workflow_id, succeeded, bp, "successful Closure Update"
        )
        for index, failure in enumerate(terminal_failures, start=1):
            add_deferred_received_finalizer(
                api,
                workflow_id,
                failure,
                bp,
                f"Closure terminal failure {index}",
            )
        return
    completion = add_processing_completion_guard(
        api,
        workflow_id,
        apply_overlay,
        title_prefix="Closure update",
    )
    link(api, completion, succeeded, branch_index=1)
    add_deferred_received_finalizer(
        api, workflow_id, succeeded, bp, "successful Closure Update"
    )
    for index, failure in enumerate(terminal_failures, start=1):
        add_deferred_received_finalizer(
            api,
            workflow_id,
            failure,
            bp,
            f"Closure terminal failure {index}",
        )


def build_create_bridge(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
                {
                    "$or": [
                        {"f_application_id": {"$eq": context("id")}},
                        {"f_intake_id": {"$eq": context("fk_intake_form")}},
                    ]
                },
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    create_cmtf = create_node(
        api,
        workflow_id,
        "create",
        f"Create CMTF {bp['key']} staging at Accepted",
        {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": bp["create_api_type"],
                    "f_application_type": bp["application_type"],
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": context("f_office_cd"),
                    "f_intake_id": context("fk_intake_form"),
                    "f_application_id": context("id"),
                    "f_rch_id": context("fk_home_record_id"),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        },
    )
    link(api, staging, exists)
    link(api, exists, create_cmtf, branch_index=0)


def build_received_bridge(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Closure application",
        query_config(
            APPLICATION_COLLECTION,
            [{"fk_intake_form": {"$eq": context("id")}}],
        ),
    )
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_intake_id": {"$eq": context("id")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging),
    )
    update_existing = create_node(
        api,
        workflow_id,
        "update",
        "Publish Received on existing CREATE staging",
        update_config(
            "t_api_request_staging",
            ref(staging, "id"),
            {
                "f_application_status": "Received",
                "f_application_id": ref(application, "id"),
                "f_office_code": context("f_office_cd"),
            },
        ),
    )
    link(api, application, staging)
    link(api, staging, exists)
    link(api, exists, update_existing, branch_index=1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=D")
    print("workflow_category=API Suorce")
    for bp in BPS:
        print(f"create_title={bp['create_title']}")
        print(f"update_title={bp['update_title']}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    created_ids: list[int] = []
    try:
        ensure_checklist_codes(api)
        ensure_application_type_enums(api)
        for bp in BPS:
            for title in (bp["create_title"], bp["update_title"]):
                require_absent(api, title)

            create_wf = create_workflow(
                api,
                title=bp["create_title"],
                collection="t_api_request_staging",
                mode=1,
                condition=external_source_condition("CREATE", bp["create_api_type"]),
            )
            created_ids.append(int(create_wf["id"]))
            build_create_graph(api, int(create_wf["id"]), bp)

            update_wf = create_workflow(
                api,
                title=bp["update_title"],
                collection="t_api_request_staging",
                mode=1,
                condition=external_source_condition("UPDATE", bp["update_api_type"]),
            )
            created_ids.append(int(update_wf["id"]))
            build_update_graph(api, int(update_wf["id"]), bp)

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            final = api.get_workflow(workflow_id)
            print(f"workflow_id={final.get('id')}")
            print(f"workflow_title={final.get('title')}")
            print(f"enabled={str(bool(final.get('enabled'))).lower()}")
            print(f"node_count={len(final.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
