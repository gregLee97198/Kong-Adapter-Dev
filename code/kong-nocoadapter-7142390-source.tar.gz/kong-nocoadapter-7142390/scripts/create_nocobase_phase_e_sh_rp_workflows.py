#!/usr/bin/env python3
"""Create Phase-E Specific Hour and RP staging workflows on NocoBase.

Native Create-From-Intake workflows already build the application when Intake
type matches and fk_intake_source_rch is set. New API workflows are mounted
under API Suorce.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    create_workflow,
    exists_config,
    link,
    parse_variable,
    query_config,
    require_absent,
    set_enabled,
    update_config,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import external_source_condition

CHECKLIST_CODES = (
    (378457901367296, "LORCHE_SPECIFIC_HOUR_001"),
    (378457976864768, "LORCHE_SPECIFIC_HOUR_002"),
    (378458033487872, "LORCHE_SPECIFIC_HOUR_003"),
    (378458228523008, "LORCHE_SPECIFIC_HOUR_004"),
    (378458291437568, "LORCHE_SPECIFIC_HOUR_005"),
    (378458337574912, "LORCHE_SPECIFIC_HOUR_006"),
    (379730415386624, "LORCHD_SPECIFIC_HOUR_001"),
    (379730876760064, "LORCHD_SPECIFIC_HOUR_002"),
    (379730912411648, "LORCHD_SPECIFIC_HOUR_003"),
    (379730941771776, "LORCHD_SPECIFIC_HOUR_004"),
    (379730973229056, "LORCHD_SPECIFIC_HOUR_005"),
    (379731002589184, "LORCHD_SPECIFIC_HOUR_006"),
    (379142509297670, "LORCHE_RP_001"),
    (379142509297676, "LORCHE_RP_002"),
    (379142509297682, "LORCHE_RP_003"),
    (379142511394816, "LORCHE_RP_004"),
)

BPS: tuple[dict[str, Any], ...] = (
    {
        "key": "sh",
        "application_type": "specific_hour",
        "application_label": "Specific Hour Application",
        "create_api_type": "create_intake_for_specific_hour",
        "update_api_type": "update_specific_hour_data",
        "intake_type_id": 378239147442176,
        "collection": "t_specific_hour_app",
        "intake_fk": "fk_intake_form",
        "home_fk": "fk_home_record",
        "checklist_use_for": "t_specific",
        "create_title": "API Request Staging — Create Specific Hour v1",
        "update_title": "API Request Staging — Update Specific Hour v1",
        "create_bridge_title": (
            "API Bridge — Specific Hour Application Created to Staging v1"
        ),
        "received_bridge_title": (
            "API Bridge — Specific Hour Intake Completed to Received v1"
        ),
    },
    {
        "key": "rp",
        "application_type": "responsible_person",
        "application_label": "Proposal of a Responsible Person (RP)",
        "create_api_type": "create_intake_for_rp",
        "update_api_type": "update_rp_data",
        "intake_type_id": 378414943305728,
        "collection": "t_rp_application",
        "intake_fk": "fk_intake_id",
        "home_fk": "fk_home_record_id",
        "checklist_use_for": "t_rp_application",
        "create_title": "API Request Staging — Create Responsible Person v1",
        "update_title": "API Request Staging — Update Responsible Person v1",
        "create_bridge_title": ("API Bridge — RP Application Created to Staging v1"),
        "received_bridge_title": ("API Bridge — RP Intake Completed to Received v1"),
    },
)


SH_SCALAR_FIELD_MAP = {
    "rch_care_level": "f_rch_care_level",
    "application_detail": "f_application_detail",
    "applicant_title": "f_applicant_title",
    "applicant_name_en": "f_applicant_name_en",
    "applicant_name_cn": "f_applicant_name_cn",
    "authorisation_method": "f_authorisation_method",
    "authorised_to_apply": "f_authorised_to_apply",
    "certificate_name_en": "f_certificate_name_en",
    "tentative_commencement_date": "f_tentative_commencement_date",
    "tentative_effective_date": "f_tentative_effective_date",
    "specific_hour_set_count": "f_specific_hour_set_count",
    "declaration_acknowledged": "f_declaration_acknowledged",
    "warning_acknowledged": "f_warning_acknowledged",
    "declared_at": "f_declared_at",
    "comments": "f_comments",
}

RP_SCALAR_FIELD_MAP = {
    "rp_title": "f_rp_title",
    "rp_name_en": "f_rp_name_en",
    "rp_name_cn": "f_rp_name_zh",
    "rp_hkid": "f_rp_hkid",
    "rp_hkid_no_1": "HKIC_number1",
    "rp_hkid_no_2": "HKIC_number2",
    "rp_hkid_no_3": "HKIC_number3",
    "rp_tel": "f_rp_tel",
    # The current RP page renders p3_Email.  Retain the historical field too
    # so existing reports and workflows do not lose the value.
    "rp_email": "p3_Email",
    "rp_address_en": "f_rp_address_en",
    "rp_address_cn": "f_rp_address_zh",
    "rp_position_type": "f_rp_position_type",
    "rp_other_home": "f_rp_other_home",
    "rp_application_type": "f_application_type",
    "change_reason": "f_change_reason",
    "change_reason_other": "f_change_reason_other",
    "ceased_status": "f_ceased_status",
    "cease_position_date": "f_cease_position_date",
    "new_rp_assume_office_date": "f_new_rp_assume_office_date",
    "notice_expected_issued_date": "f_notice_expected_issued_at",
    "authorised_rep_position": "f_authorised_rep_position",
    "comments": "f_comments",
}

RP_LEGAL_FIELD_MAP = {
    "q1": {
        "answer": "f_q1_answer",
        "case_status": "f_q1_case_status",
        "prosecuting_authority": "f_q1_prosecuting_authority",
        "place_of_proceeding": "f_fxeb5nzxq5f",
        "offence_involved": "f_q1_offence",
        "hearing_date": "f_q1_conviction_date",
        "court": "f_q2_court",
        "place_of_court": "q1Place_of",
        "offence_committed": "f_q2_offence",
        "penalty": "f_q1_penalty",
        "conviction_date": "f_q2_conviction_date",
    },
    "q2": {
        "answer": "f_q4_answer",
        "case_status": "q2being_and_has",
        "prosecuting_authority": "q2Prosecuting_Authority",
        "offence_involved": "q2Offence_involved",
        "hearing_date": "q2hearing",
        "court": "f_q3_court",
        "offence_committed": "f_q3_offence",
        "penalty": "f_q2_penalty",
        "conviction_date": "f_q3_conviction_date",
    },
    "q3": {
        "answer": "f_q3_answer",
        "case_status": "f_q3_case_status",
        "prosecuting_authority": "f_q3_court_place",
        "place_of_proceeding": "f_q4_prosecuting_authority",
        "offence_involved": "f_q4_offence",
        "hearing_date": "f_q4_hearing_date",
        "court": "f_q4_case_status",
        "place_of_court": "q3Place_of",
        "offence_committed": "q3Offence_Committed",
        "penalty": "f_q3_penalty",
        "conviction_date": "q3Date_of_Conviction",
    },
    "q4": {
        "answer": "q4_",
        "case_status": "q4being_has",
        "prosecuting_authority": "q4Prosecuting_Authority",
        "offence_involved": "q4Offence_involved",
        "hearing_date": "q4Date_of_hearing",
        "court": "q4Court",
        "offence_committed": "q4Offence_Committed",
        "penalty": "q4Penalty_imposed",
        "conviction_date": "q4Date_of_conviction",
    },
}

RP_OTHER_FIELD_MAP = {
    "q5": {
        "answer": "f_q5_answer",
        "date": "f_q5_date",
        "rch_no_and_name": "f_q5_rch_name",
        "reasons": "f_q5_reasons",
    },
    "q6": {
        "answer": "f_q6_answer",
        "adjudication_date": "f_q6_adjudication_date",
        "court": "f_q6_court",
    },
    "q7": {
        "answer": "f_q7_answer",
        "adjudication_date": "f_q7_adjudication_date",
        "repayment_proposal": "f_q7_court",
    },
    "q8": {
        "answer": "f_q8_answer",
        "company_name_en": "f_q8_company_name_en",
        "company_name_cn": "f_q8_company_name_zh",
        "business_registration_no": "f_q8_business_registration_no",
        "certificate_of_incorporation_no": "f_q8_certificate_incorporation_no",
        "registered_address": "q8Registered_address",
        "adjudication_date": "f_q8_adjudication_date",
        "court": "f_q8_court",
    },
}

RP_DECLARATION_FIELD_MAP = {
    "acknowledged": "p8_checked",
    "signature_date_of_rp": "f_signature_date_of_rp",
    "signature_date_of_applicant_representative_partner": (
        "f_signature_date_of_applicant_representative_partner"
    ),
}

INTAKE_UPDATE_FIELD_MAP = {
    "received_date": "f_received_date",
    "severity": "f_severity",
    "source_id": "fk_intake_source",
    "source_other": "f_source_other",
    "task_owner_user_id": "fk_task_owner",
    "task_owner_post_code": "fk_task_owner_post",
}

RP_CASE_STATUS_NATIVE_VALUES = {
    "q1": {
        "being_prosecuted_currently": "being prosecuted currently",
        "has_been_convicted": "has been convicted",
    },
    "q2": {
        "being_prosecuted_currently": "being prosecuted currently",
        "has_been_convicted": "has been convicted",
    },
    "q3": {
        "being_prosecuted_currently": "q3being",
        "has_been_convicted": "q3has",
    },
    "q4": {
        "being_prosecuted_currently": "q4being prosecuted currently",
        "has_been_convicted": "q4has been convicted",
    },
}


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def scope(node: Mapping[str, Any], field: str) -> str:
    return "{{$scopes." + str(node["key"]) + ".item." + field + "}}"


def parse_config(bp: Mapping[str, Any]) -> dict[str, Any]:
    example: dict[str, Any] = {
        "request_id": f"{bp['key'].upper()}-20260914-0001",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "lorche_d_no": "L0043",
                "received_date": "2026-09-14",
                "severity": "0",
                "source_id": 701,
                "source_other": "OP",
                "submitter_user_id": 12,
                "task_owner_user_id": 45,
                "task_owner_post_code": "S(LR)1",
            },
            "comments": "Phase E overlay",
            "checklist": [
                {
                    "position_code": (
                        "LORCHE_SPECIFIC_HOUR_001"
                        if bp["key"] == "sh"
                        else "LORCHE_RP_001"
                    ),
                    "attachment_id": 504,
                }
            ],
        },
    }
    variables = [
        parse_variable("form_data", "formData"),
        parse_variable("form_data.case_summary.office_code", "officeCode"),
        parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
        parse_variable("form_data.case_summary.received_date", "receivedDate"),
        parse_variable("form_data.case_summary.severity", "severity"),
        parse_variable("form_data.case_summary.source_id", "sourceId"),
        parse_variable("form_data.case_summary.source_other", "sourceOther"),
        parse_variable("form_data.case_summary.submitter_user_id", "submitterId"),
        parse_variable("form_data.case_summary.task_owner_user_id", "ownerId"),
        parse_variable("form_data.case_summary.task_owner_post_code", "ownerPost"),
        parse_variable("form_data.comments", "comments"),
        parse_variable("form_data.checklist", "checklist"),
        parse_variable("form_data.checklist[].position_code", "checklistPosition"),
        parse_variable("form_data.checklist[].attachment_id", "checklistAttachment"),
        parse_variable("create_id", "createId"),
    ]
    if bp["key"] == "sh":
        example["form_data"].update(
            {
                "application_detail": "approval",
                "applicant_title": "Mr",
                "applicant_name_en": "Example Applicant",
                "applicant_name_cn": "示例申请人",
                "authorisation_method": "written",
                "rch_care_level": "0",
                "tentative_commencement_date": "2026-12-31",
                "tentative_effective_date": "2026-12-31",
                "authorised_to_apply": True,
                "certificate_name_en": "Example Cert",
                "specific_hour_set_count": "0",
                "specific_hour_options": [
                    {
                        "set_no": "0",
                        "section": "workday_and_holiday",
                        "staffings": [
                            {
                                "staff_type_code": "AW",
                                "other_duties": "Care duties",
                                "time_rows": [
                                    {
                                        "work_hour_from": "08:00:00",
                                        "work_hour_to": "12:00:00",
                                        "remark": "Morning",
                                    }
                                ],
                            }
                        ],
                    }
                ],
                "declaration_acknowledged": True,
                "warning_acknowledged": True,
                "declared_at": "2026-09-14",
            }
        )
        variables.extend(
            [
                parse_variable("form_data.application_detail", "applicationDetail"),
                parse_variable("form_data.applicant_title", "applicantTitle"),
                parse_variable("form_data.applicant_name_en", "applicantNameEn"),
                parse_variable("form_data.applicant_name_cn", "applicantNameCn"),
                parse_variable("form_data.authorisation_method", "authorisationMethod"),
                parse_variable("form_data.authorised_to_apply", "authorisedToApply"),
                parse_variable("form_data.certificate_name_en", "certificateNameEn"),
                parse_variable("form_data.rch_care_level", "rchCareLevel"),
                parse_variable(
                    "form_data.tentative_commencement_date",
                    "tentativeCommencementDate",
                ),
                parse_variable(
                    "form_data.tentative_effective_date", "tentativeEffectiveDate"
                ),
                parse_variable(
                    "form_data.specific_hour_set_count", "specificHourSetCount"
                ),
                parse_variable(
                    "form_data.specific_hour_options", "specificHourOptions"
                ),
                parse_variable(
                    "form_data.declaration_acknowledged", "declarationAcknowledged"
                ),
                parse_variable("form_data.warning_acknowledged", "warningAcknowledged"),
                parse_variable("form_data.declared_at", "declaredAt"),
            ]
        )
    else:
        example["form_data"].update(
            {
                "rp_title": "mr",
                "rp_name_en": "Example RP",
                "rp_name_cn": "示例负责人",
                "rp_hkid": "A123456(7)",
                "rp_hkid_no_1": "A123456",
                "rp_hkid_no_2": "7",
                "rp_tel": "21234567",
                "rp_email": "rp@example.test",
                "rp_address_en": "Example Address",
                "rp_address_cn": "示例地址",
                "rp_position_type": "sole_proprietorship",
                "rp_other_home": "no",
                "currently_appointed_homes": [],
                "rp_application_type": "section_8",
                "change_reason": "written_notice",
                "change_reason_other": None,
                "ceased_status": "will_cease",
                "cease_position_date": "2026-10-01",
                "new_rp_assume_office_date": "2026-10-02",
                "notice_expected_issued_date": "2026-10-10",
                "authorised_rep_position": "Director",
                "other_particulars": {
                    **{key: {"answer": "no"} for key in ("q1", "q2", "q3", "q4")},
                    "q5": {"answer": "no"},
                    "q6": {"answer": "no"},
                    "q7": {"answer": "no"},
                    "q8": {"answer": "no"},
                },
                "declaration": {
                    "acknowledged": True,
                    "signature_date_of_rp": "2026-09-14",
                    "signature_date_of_applicant_representative_partner": (
                        "2026-09-14"
                    ),
                },
            }
        )
        variables.extend(
            [
                parse_variable("form_data.rp_title", "rpTitle"),
                parse_variable("form_data.rp_name_en", "rpNameEn"),
                parse_variable("form_data.rp_name_cn", "rpNameCn"),
                parse_variable("form_data.rp_hkid", "rpHkid"),
                parse_variable("form_data.rp_hkid_no_1", "rpHkid1"),
                parse_variable("form_data.rp_hkid_no_2", "rpHkid2"),
                parse_variable("form_data.rp_hkid_no_3", "rpHkid3"),
                parse_variable("form_data.rp_tel", "rpTel"),
                parse_variable("form_data.rp_email", "rpEmail"),
                parse_variable("form_data.rp_address_en", "rpAddressEn"),
                parse_variable("form_data.rp_address_cn", "rpAddressCn"),
                parse_variable("form_data.rp_position_type", "rpPositionType"),
                parse_variable("form_data.rp_other_home", "rpOtherHome"),
                parse_variable(
                    "form_data.currently_appointed_homes", "currentlyAppointedHomes"
                ),
                parse_variable("form_data.rp_application_type", "rpApplicationType"),
                parse_variable("form_data.change_reason", "changeReason"),
                parse_variable("form_data.change_reason_other", "changeReasonOther"),
                parse_variable("form_data.ceased_status", "ceasedStatus"),
                parse_variable("form_data.cease_position_date", "ceasePositionDate"),
                parse_variable(
                    "form_data.new_rp_assume_office_date", "newRpAssumeOfficeDate"
                ),
                parse_variable(
                    "form_data.notice_expected_issued_date", "noticeExpectedIssuedDate"
                ),
                parse_variable(
                    "form_data.authorised_rep_position", "authorisedRepPosition"
                ),
                parse_variable(
                    "form_data.declaration.acknowledged", "declarationAcknowledged"
                ),
                parse_variable(
                    "form_data.declaration.signature_date_of_rp",
                    "signatureDateOfRp",
                ),
                parse_variable(
                    "form_data.declaration."
                    "signature_date_of_applicant_representative_partner",
                    "signatureDateOfApplicant",
                ),
            ]
        )
        for question, mapping in {**RP_LEGAL_FIELD_MAP, **RP_OTHER_FIELD_MAP}.items():
            for public_field in mapping:
                variables.append(
                    parse_variable(
                        f"form_data.other_particulars.{question}.{public_field}",
                        f"{question}_{public_field}",
                    )
                )
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": example,
        "variables": variables,
    }


def overlay_values(
    bp: Mapping[str, Any],
    parse: Mapping[str, Any],
    rp_statuses: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    values = {
        bp["home_fk"]: context("f_rch_id"),
        "f_comments": ref(parse, "comments"),
    }
    if bp["key"] == "sh":
        values.update(
            {
                "f_rch_care_level": ref(parse, "rchCareLevel"),
                "f_application_detail": ref(parse, "applicationDetail"),
                "f_applicant_title": ref(parse, "applicantTitle"),
                "f_applicant_name_en": ref(parse, "applicantNameEn"),
                "f_applicant_name_cn": ref(parse, "applicantNameCn"),
                "f_authorisation_method": ref(parse, "authorisationMethod"),
                "f_authorised_to_apply": ref(parse, "authorisedToApply"),
                "f_certificate_name_en": ref(parse, "certificateNameEn"),
                "f_tentative_commencement_date": ref(
                    parse, "tentativeCommencementDate"
                ),
                "f_tentative_effective_date": ref(parse, "tentativeEffectiveDate"),
                "f_specific_hour_set_count": ref(parse, "specificHourSetCount"),
                "f_declaration_acknowledged": ref(parse, "declarationAcknowledged"),
                "f_warning_acknowledged": ref(parse, "warningAcknowledged"),
                "f_declared_at": ref(parse, "declaredAt"),
            }
        )
    else:
        values.update(
            {
                "f_office_code": ref(parse, "officeCode"),
                "f_rp_title": ref(parse, "rpTitle"),
                "f_rp_name_en": ref(parse, "rpNameEn"),
                "f_rp_name_zh": ref(parse, "rpNameCn"),
                "f_rp_hkid": ref(parse, "rpHkid"),
                "HKIC_number1": ref(parse, "rpHkid1"),
                "HKIC_number2": ref(parse, "rpHkid2"),
                "HKIC_number3": ref(parse, "rpHkid3"),
                "f_rp_tel": ref(parse, "rpTel"),
                "f_rp_email": ref(parse, "rpEmail"),
                "p3_Email": ref(parse, "rpEmail"),
                "f_rp_address_en": ref(parse, "rpAddressEn"),
                "f_rp_address_zh": ref(parse, "rpAddressCn"),
                "f_rp_position_type": ref(parse, "rpPositionType"),
                "f_rp_other_home": ref(parse, "rpOtherHome"),
                "f_application_type": ref(parse, "rpApplicationType"),
                "f_change_reason": ref(parse, "changeReason"),
                "f_change_reason_other": ref(parse, "changeReasonOther"),
                "f_ceased_status": ref(parse, "ceasedStatus"),
                "f_cease_position_date": ref(parse, "ceasePositionDate"),
                "f_new_rp_assume_office_date": ref(parse, "newRpAssumeOfficeDate"),
                "f_notice_expected_issued_at": ref(parse, "noticeExpectedIssuedDate"),
                "f_signature_date_of_rp": ref(parse, "signatureDateOfRp"),
                "f_signature_date_of_applicant_representative_partner": ref(
                    parse, "signatureDateOfApplicant"
                ),
                "f_authorised_rep_position": ref(parse, "authorisedRepPosition"),
                "p8_checked": ref(parse, "declarationAcknowledged"),
                "f_application_received_date": ref(parse, "receivedDate"),
            }
        )
        for question, mapping in {**RP_LEGAL_FIELD_MAP, **RP_OTHER_FIELD_MAP}.items():
            for public_field, native_field in mapping.items():
                if public_field == "case_status":
                    if rp_statuses is None:
                        raise ValueError("RP status normalizer is required")
                    values[native_field] = ref(rp_statuses, f"{question}_case_status")
                else:
                    values[native_field] = ref(parse, f"{question}_{public_field}")
    return values


def staging_failed_values(
    reason: str,
    *,
    intake_id: str | None = None,
    application_id: str | None = None,
) -> dict[str, Any]:
    values: dict[str, Any] = {
        "f_status": "failed",
        "f_error_message": reason,
    }
    if intake_id is not None:
        values["f_intake_id"] = intake_id
    if application_id is not None:
        values["f_application_id"] = application_id
    return values


def processing_staging_update_config(values: Mapping[str, Any]) -> dict[str, Any]:
    """CAS update: only the still-processing branch may finish the row."""

    config = update_config("t_api_request_staging", context("id"), values)
    config["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "processing"}},
        ]
    }
    return config


def atomic_claim_config(*, require_ready_parent: bool = False) -> dict[str, Any]:
    parent_guard = ""
    if require_ready_parent:
        parent_guard = (
            ' AND EXISTS (SELECT 1 FROM "t_api_request_staging" AS parent '
            'WHERE CAST(parent."id" AS text) = staged."f_parent_create_id" '
            'AND parent."f_request_event" = \'CREATE\' '
            'AND parent."f_status" = \'succeeded\' '
            'AND parent."f_application_status" = \'Accepted\' '
            'AND parent."f_intake_id" IS NOT NULL '
            'AND parent."f_application_id" IS NOT NULL '
            'AND staged."f_active_update_id" IS NOT NULL '
            'AND parent."f_active_update_id" = staged."f_active_update_id") '
            'AND NOT EXISTS (SELECT 1 FROM "t_api_request_staging" AS active '
            'WHERE active."f_request_event" = \'UPDATE\' '
            'AND active."f_parent_create_id" = staged."f_parent_create_id" '
            'AND active."id" <> staged."id" '
            'AND (active."f_status" = \'processing\' '
            'OR (active."id" < staged."id" '
            'AND active."f_status" = \'submitted\'))) '
        )
    return {
        "dataSource": "main",
        "sql": (
            'UPDATE "t_api_request_staging" AS staged '
            "SET \"f_status\" = 'processing' "
            'WHERE staged."id" = :stagingId '
            'AND staged."f_status" = \'submitted\' '
            + parent_guard
            + 'RETURNING staged."id";'
        ),
        "variables": [{"name": "stagingId", "value": context("id")}],
        "withMeta": False,
        "unsafeInjection": False,
    }


def add_rejected_staging_claim_finalizer(
    api: NocoBaseApi,
    workflow_id: int,
    claimed: Mapping[str, Any],
    *,
    title_prefix: str,
    reason: str,
) -> Mapping[str, Any]:
    """Fail only an unclaimed submitted row; never overwrite a winning run."""

    rejected = create_node(
        api,
        workflow_id,
        "sql",
        f"Finalize rejected {title_prefix} claim",
        {
            "dataSource": "main",
            "sql": (
                'UPDATE "t_api_request_staging" SET '
                '"f_status"=\'failed\', "f_error_message"=:reason '
                'WHERE "id"=:stagingId AND "f_status"=\'submitted\' '
                'RETURNING "id";'
            ),
            "variables": [
                {"name": "stagingId", "value": context("id")},
                {"name": "reason", "value": reason},
            ],
            "withMeta": False,
            "unsafeInjection": False,
        },
    )
    link(api, claimed, rejected, branch_index=0)
    row_count = create_node(
        api,
        workflow_id,
        "script",
        f"Validate rejected {title_prefix} claim row count",
        {
            "arguments": [{"name": "rows", "value": ref(rejected)}],
            "content": "return Array.isArray(rows) && rows.length === 1;",
            "timeout": 3000,
            "continue": False,
        },
    )
    finalized = create_node(
        api,
        workflow_id,
        "condition",
        f"Rejected {title_prefix} claim finalized",
        true_condition(ref(row_count)),
    )
    link(api, rejected, row_count)
    link(api, row_count, finalized)
    return finalized


def deferred_received_config(bp: Mapping[str, Any]) -> dict[str, Any]:
    """Publish a previously deferred Received transition after Update ends."""

    return {
        "dataSource": "main",
        "sql": (
            'UPDATE "t_api_request_staging" AS create_row SET '
            '"f_active_update_id"=NULL, '
            '"f_application_status"=CASE WHEN '
            'create_row."f_application_status"=\'Accepted\' '
            'AND EXISTS (SELECT 1 FROM "t_intake_form" AS intake '
            'WHERE CAST(intake."id" AS text)='
            'CAST(create_row."f_intake_id" AS text) '
            'AND CAST(intake."f_approval_status" AS text)=\'4\') '
            'AND NOT EXISTS (SELECT 1 FROM "t_api_request_staging" AS active '
            'WHERE active."f_request_event"=\'UPDATE\' '
            'AND active."f_parent_create_id"=CAST(create_row."id" AS text) '
            'AND active."f_status" IN (\'submitted\',\'processing\')) '
            'THEN \'Received\' ELSE create_row."f_application_status" END '
            'WHERE CAST(create_row."id" AS text)=:parentCreateId '
            'AND create_row."f_status"=\'succeeded\' '
            'AND create_row."f_request_event"=\'CREATE\' '
            'AND create_row."f_api_type"=:createApiType '
            'AND create_row."f_application_type"=:applicationType '
            'AND create_row."f_active_update_id"=:activeUpdateId '
            'RETURNING create_row."id";'
        ),
        "variables": [
            {"name": "parentCreateId", "value": context("f_parent_create_id")},
            {"name": "activeUpdateId", "value": context("f_active_update_id")},
            {"name": "createApiType", "value": bp["create_api_type"]},
            {"name": "applicationType", "value": bp["application_type"]},
        ],
        "withMeta": False,
        "unsafeInjection": False,
    }


def add_deferred_received_finalizer(
    api: NocoBaseApi,
    workflow_id: int,
    upstream: Mapping[str, Any],
    bp: Mapping[str, Any],
    title_suffix: str,
    *,
    branch_index: int | None = None,
) -> Mapping[str, Any]:
    node = create_node(
        api,
        workflow_id,
        "sql",
        f"Finalize deferred Received after {title_suffix}",
        deferred_received_config(bp),
    )
    link(api, upstream, node, branch_index=branch_index)
    return node


def claim_result_script() -> str:
    return """const values = Array.isArray(rows) ? rows : [];
return {claimed: values.length === 1};"""


def rp_case_status_script() -> str:
    mappings = json.dumps(RP_CASE_STATUS_NATIVE_VALUES, ensure_ascii=False)
    return f"""const mappings = {mappings};
const translate = (question, value) => {{
  if (value === null || typeof value === 'undefined' || value === '') return value;
  const translated = (mappings[question] || {{}})[value];
  if (typeof translated === 'undefined') {{
    throw new Error('Unsupported RP case_status for ' + question + ': ' + value);
  }}
  return translated;
}};
// NocoBase omits script arguments whose JSON-variable value is absent.  Use
// typeof so an unanswered optional question remains undefined instead of
// raising ReferenceError before the application can be created.
const values = {{
  q1: typeof q1CaseStatus === 'undefined' ? undefined : q1CaseStatus,
  q2: typeof q2CaseStatus === 'undefined' ? undefined : q2CaseStatus,
  q3: typeof q3CaseStatus === 'undefined' ? undefined : q3CaseStatus,
  q4: typeof q4CaseStatus === 'undefined' ? undefined : q4CaseStatus,
}};
return {{
  q1_case_status: translate('q1', values.q1),
  q2_case_status: translate('q2', values.q2),
  q3_case_status: translate('q3', values.q3),
  q4_case_status: translate('q4', values.q4),
}};"""


def guarded_patch_script(bp: Mapping[str, Any]) -> str:
    """Project only supplied fields while retaining every omitted value.

    NocoBase's update node will write ``undefined``/null-like variable results
    in some plugin versions.  Returning a complete patch based on the current
    record prevents a partial API Update from silently clearing page fields.
    Nested replacement is identified separately for the graph's validated,
    non-transactional replacement path.
    """

    mapping = SH_SCALAR_FIELD_MAP if bp["key"] == "sh" else RP_SCALAR_FIELD_MAP
    nested_mapping: dict[str, dict[str, str]] = {}
    declaration_mapping: dict[str, str] = {}
    if bp["key"] == "rp":
        nested_mapping = {**RP_LEGAL_FIELD_MAP, **RP_OTHER_FIELD_MAP}
        declaration_mapping = RP_DECLARATION_FIELD_MAP
    replacements = {
        "__MAP__": json.dumps(mapping, ensure_ascii=False),
        "__NESTED_MAP__": json.dumps(nested_mapping, ensure_ascii=False),
        "__DECLARATION_MAP__": json.dumps(declaration_mapping, ensure_ascii=False),
        "__NESTED_FIELD__": json.dumps(
            "specific_hour_options"
            if bp["key"] == "sh"
            else "currently_appointed_homes"
        ),
        "__IS_RP__": "true" if bp["key"] == "rp" else "false",
        "__CASE_STATUS_MAP__": json.dumps(
            RP_CASE_STATUS_NATIVE_VALUES, ensure_ascii=False
        ),
        "__INTAKE_MAP__": json.dumps(INTAKE_UPDATE_FIELD_MAP, ensure_ascii=False),
    }
    script = """const f = formData || {};
const current = application || {};
const currentIntake = intake || {};
const own = (value, key) => value
  && Object.prototype.hasOwnProperty.call(value, key);
const patch = {};
const intakePatch = {};
const summary = f.case_summary || {};
for (const [external, internal] of Object.entries(__INTAKE_MAP__)) {
  intakePatch[internal] = own(summary, external)
    ? summary[external] : currentIntake[internal];
}
const scalarMap = __MAP__;
for (const [external, internal] of Object.entries(scalarMap)) {
  patch[internal] = own(f, external) ? f[external] : current[internal];
}
const nestedMap = __NESTED_MAP__;
const particulars = f.other_particulars || {};
const caseStatusMap = __CASE_STATUS_MAP__;
for (const [question, fields] of Object.entries(nestedMap)) {
  const incoming = particulars[question] || {};
  for (const [external, internal] of Object.entries(fields)) {
    if (external === 'case_status' && own(incoming, external)) {
      const incomingStatus = incoming[external];
      if (incomingStatus === null) {
        patch[internal] = null;
      } else {
        const translated = (caseStatusMap[question] || {})[incomingStatus];
        if (typeof translated === 'undefined') {
          throw new Error('Unsupported RP case_status for ' + question);
        }
        patch[internal] = translated;
      }
    } else {
      patch[internal] = own(incoming, external)
        ? incoming[external] : current[internal];
    }
  }
}
const declarationMap = __DECLARATION_MAP__;
const declaration = f.declaration || {};
for (const [external, internal] of Object.entries(declarationMap)) {
  patch[internal] = own(declaration, external)
    ? declaration[external] : current[internal];
}
if (__IS_RP__) {
  patch.f_rp_email = own(f, 'rp_email') ? f.rp_email : current.f_rp_email;
  patch.p3_Email = own(f, 'rp_email') ? f.rp_email : current.p3_Email;
  patch.f_application_received_date = own(summary, 'received_date')
    ? summary.received_date : current.f_application_received_date;
}
return {
  patch,
  intake_patch: intakePatch,
  nested_replacement_requested: own(f, __NESTED_FIELD__),
};"""
    for marker, value in replacements.items():
        script = script.replace(marker, value)
    return script


def field_references(
    node: Mapping[str, Any], prefix: str, fields: list[str]
) -> dict[str, str]:
    return {field: ref(node, f"{prefix}.{field}") for field in fields}


def add_checklist_preflight_graph(
    api: NocoBaseApi,
    workflow_id: int,
    bp: Mapping[str, Any],
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    upstream: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Revalidate all checklist references before any Update business write."""

    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Preflight Checklist files",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
    )
    template = create_node(
        api,
        workflow_id,
        "query",
        "Preflight checklist template by position_code",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$eq": scope(loop, "position_code")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {"f_use_for": {"$anyOf": [bp["checklist_use_for"]]}},
            ],
        ),
    )
    template_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Preflight checklist template exists",
        exists_config(template, reject_on_false=False),
    )
    invalid_template = create_node(
        api,
        workflow_id,
        "update",
        "Mark checklist preflight template failure",
        processing_staging_update_config(
            staging_failed_values(
                "checklist_template_not_resolved",
                application_id=ref(application, "id"),
            )
        ),
    )
    attachment = create_node(
        api,
        workflow_id,
        "query",
        "Preflight Checklist attachment",
        query_config(
            "attachments",
            [{"id": {"$eq": scope(loop, "attachment_id")}}],
        ),
    )
    attachment_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Preflight Checklist attachment exists",
        exists_config(attachment, reject_on_false=False),
    )
    invalid_attachment = create_node(
        api,
        workflow_id,
        "update",
        "Mark checklist preflight attachment failure",
        processing_staging_update_config(
            staging_failed_values(
                "checklist_attachment_not_resolved",
                application_id=ref(application, "id"),
            )
        ),
    )
    item_ok = create_node(
        api,
        workflow_id,
        "script",
        "Checklist preflight item passed",
        {
            "arguments": [],
            "content": "return true;",
            "timeout": 3000,
            "continue": False,
        },
    )
    reload_staging = create_node(
        api,
        workflow_id,
        "query",
        "Reload processing Staging after Checklist preflight",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": context("id")}},
                {"f_status": {"$eq": "processing"}},
            ],
        ),
    )
    valid = create_node(
        api,
        workflow_id,
        "condition",
        "Checklist preflight completed without failure",
        exists_config(reload_staging, reject_on_false=False),
    )
    link(api, upstream, loop)
    link(api, loop, template, branch_index=0)
    link(api, template, template_exists)
    link(api, template_exists, invalid_template, branch_index=0)
    link(api, template_exists, attachment, branch_index=1)
    link(api, attachment, attachment_exists)
    link(api, attachment_exists, invalid_attachment, branch_index=0)
    link(api, attachment_exists, item_ok, branch_index=1)
    link(api, loop, reload_staging)
    link(api, reload_staging, valid)
    return valid


def add_checklist_graph(
    api: NocoBaseApi,
    workflow_id: int,
    bp: Mapping[str, Any],
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    upstream: Mapping[str, Any],
) -> dict[str, Any]:
    """Persist one Details history row before refreshing Latest.

    Missing templates or uploads update Staging to failed.  The final status
    reread means those failures can never be overwritten by succeeded.
    """

    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply Checklist files",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
    )
    template = create_node(
        api,
        workflow_id,
        "query",
        "Resolve checklist template by position_code",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$eq": scope(loop, "position_code")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {"f_use_for": {"$anyOf": [bp["checklist_use_for"]]}},
            ],
        ),
    )
    template_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Checklist template exists",
        exists_config(template, reject_on_false=False),
    )
    invalid_template = create_node(
        api,
        workflow_id,
        "update",
        "Mark checklist template failure",
        processing_staging_update_config(
            staging_failed_values(
                "checklist_template_not_resolved",
                application_id=ref(application, "id"),
            )
        ),
    )
    attachment = create_node(
        api,
        workflow_id,
        "query",
        "Load Checklist attachment",
        query_config(
            "attachments",
            [{"id": {"$eq": scope(loop, "attachment_id")}}],
        ),
    )
    attachment_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Checklist attachment exists",
        exists_config(attachment, reject_on_false=False),
    )
    invalid_attachment = create_node(
        api,
        workflow_id,
        "update",
        "Mark checklist attachment failure",
        processing_staging_update_config(
            staging_failed_values(
                "checklist_attachment_not_resolved",
                application_id=ref(application, "id"),
            )
        ),
    )
    item = create_node(
        api,
        workflow_id,
        "query",
        "Find native checklist item",
        query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"fk_document_checklist": {"$eq": ref(template, "id")}},
                {"f_business_type": {"$eq": bp["collection"]}},
            ],
        ),
    )
    item_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native checklist item exists",
        exists_config(item, reject_on_false=False),
    )
    update_item = create_node(
        api,
        workflow_id,
        "update",
        "Mark existing checklist item checked",
        update_config(
            "t_document_submitted_for_application",
            ref(item, "id"),
            {"f_is_checked": True},
        ),
    )
    create_item = create_node(
        api,
        workflow_id,
        "create",
        "Create checklist item without Latest",
        {
            "collection": "t_document_submitted_for_application",
            "params": {
                "values": {
                    "f_business_key": ref(application, "id"),
                    "f_business_type": bp["collection"],
                    "fk_document_checklist": ref(template, "id"),
                    "f_is_checked": True,
                },
                "appends": [],
            },
        },
    )

    def detail(parent: Mapping[str, Any], title: str) -> dict[str, Any]:
        return create_node(
            api,
            workflow_id,
            "create",
            title,
            {
                "collection": "t_document_submitted_for_application_details",
                "params": {
                    "values": {
                        "fk_documests_submitted_for_application_id": ref(parent, "id"),
                        "f_files": [scope(loop, "attachment_id")],
                        "f_file_name": ref(attachment, "filename"),
                        "f_file_date": ref(attachment, "createdAt"),
                    },
                    "appends": [],
                },
            },
        )

    existing_detail = detail(item, "Create existing Checklist upload Details")
    new_detail = detail(create_item, "Create new Checklist upload Details")
    latest = {
        "f_lastest_files": [scope(loop, "attachment_id")],
        "f_lastest_files_name": ref(attachment, "filename"),
        "f_lastest_file_date": ref(attachment, "createdAt"),
    }

    def latest_node(parent: Mapping[str, Any], title: str) -> dict[str, Any]:
        config = update_config(
            "t_document_submitted_for_application", ref(parent, "id"), latest
        )
        config["params"]["individualHooks"] = True
        return create_node(api, workflow_id, "update", title, config)

    existing_latest = latest_node(item, "Refresh existing Checklist Latest")
    new_latest = latest_node(create_item, "Refresh new Checklist Latest")
    reload_staging = create_node(
        api,
        workflow_id,
        "query",
        "Reload processing Staging after Checklist",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": context("id")}},
                {"f_status": {"$eq": "processing"}},
            ],
        ),
    )
    still_processing = create_node(
        api,
        workflow_id,
        "condition",
        "Checklist completed without failure",
        exists_config(reload_staging, reject_on_false=False),
    )

    link(api, upstream, loop)
    link(api, loop, template, branch_index=0)
    link(api, template, template_exists)
    link(api, template_exists, invalid_template, branch_index=0)
    link(api, template_exists, attachment, branch_index=1)
    link(api, attachment, attachment_exists)
    link(api, attachment_exists, invalid_attachment, branch_index=0)
    link(api, attachment_exists, item, branch_index=1)
    link(api, item, item_exists)
    link(api, item_exists, update_item, branch_index=1)
    link(api, item_exists, create_item, branch_index=0)
    link(api, update_item, existing_detail)
    link(api, existing_detail, existing_latest)
    link(api, create_item, new_detail)
    link(api, new_detail, new_latest)
    link(api, loop, reload_staging)
    link(api, reload_staging, still_processing)
    return still_processing


def add_specific_hour_children(
    api: NocoBaseApi,
    workflow_id: int,
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    upstream: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Create the canonical option -> staffing -> time-row hierarchy."""

    option_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Create Specific Hour options",
        {
            "target": ref(parse, "specificHourOptions"),
            "condition": False,
            "exit": 2,
        },
    )
    option = create_node(
        api,
        workflow_id,
        "create",
        "Create Specific Hour option",
        {
            "collection": "t_specific_hour_option",
            "params": {
                "values": {
                    # Use only the plural canonical association/FK chain.
                    "fk_specific_hour_app": ref(application, "id"),
                    "f_specific_hour_set_no": scope(option_loop, "set_no"),
                    "f_section": scope(option_loop, "section"),
                    "f_section_other": scope(option_loop, "section_other"),
                },
                "appends": [],
            },
        },
    )
    staffing_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Create Specific Hour staffings",
        {
            "target": scope(option_loop, "staffings"),
            "condition": False,
            "exit": 2,
        },
    )
    staff_type = create_node(
        api,
        workflow_id,
        "query",
        "Resolve Specific Hour staff type",
        query_config(
            "t_staff_type",
            [
                {"f_staff_code": {"$eq": scope(staffing_loop, "staff_type_code")}},
                {"f_enabled": {"$eq": True}},
            ],
        ),
    )
    staff_type_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Specific Hour staff type exists",
        exists_config(staff_type, reject_on_false=False),
    )
    invalid_staff = create_node(
        api,
        workflow_id,
        "update",
        "Mark Specific Hour staff type failure",
        processing_staging_update_config(
            staging_failed_values(
                "specific_hour_staff_type_not_resolved",
                application_id=ref(application, "id"),
            )
        ),
    )
    staffing = create_node(
        api,
        workflow_id,
        "create",
        "Create Specific Hour staffing",
        {
            "collection": "t_specific_hour_staffing",
            "params": {
                "values": {
                    "fk_specific_hour_option": ref(option, "id"),
                    "fk_staff_type": ref(staff_type, "id"),
                    "f_duty_description": scope(staffing_loop, "other_duties"),
                    "f_staff_ratio_requirement": scope(
                        staffing_loop,
                        "_rule_snapshot.staff_ratio_requirement",
                    ),
                    "f_minimum_required_hours": scope(
                        staffing_loop,
                        "_rule_snapshot.minimum_required_hours",
                    ),
                    "f_sort_order": scope(
                        staffing_loop,
                        "_rule_snapshot.sort_order",
                    ),
                },
                "appends": [],
            },
        },
    )
    time_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Create Specific Hour time rows",
        {
            "target": scope(staffing_loop, "time_rows"),
            "condition": False,
            "exit": 2,
        },
    )
    time_row = create_node(
        api,
        workflow_id,
        "create",
        "Create Specific Hour time row",
        {
            "collection": "t_specific_hour_data",
            "params": {
                "values": {
                    "fk_specific_hour_staffing": ref(staffing, "id"),
                    "f_work_hour_from": scope(time_loop, "work_hour_from"),
                    "f_work_hour_to": scope(time_loop, "work_hour_to"),
                    "f_duration_hours": scope(time_loop, "_duration_hours"),
                    "f_sort_order": scope(time_loop, "_sort_order"),
                    "f_remark": scope(time_loop, "remark"),
                },
                "appends": [],
            },
        },
    )
    link(api, upstream, option_loop)
    link(api, option_loop, option, branch_index=0)
    link(api, option, staffing_loop)
    link(api, staffing_loop, staff_type, branch_index=0)
    link(api, staff_type, staff_type_exists)
    link(api, staff_type_exists, invalid_staff, branch_index=0)
    link(api, staff_type_exists, staffing, branch_index=1)
    link(api, staffing, time_loop)
    link(api, time_loop, time_row, branch_index=0)
    return option_loop


def add_rp_currently_appointed(
    api: NocoBaseApi,
    workflow_id: int,
    parse: Mapping[str, Any],
    application: Mapping[str, Any],
    upstream: Mapping[str, Any],
) -> Mapping[str, Any]:
    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Create RP currently appointed homes",
        {
            "target": ref(parse, "currentlyAppointedHomes"),
            "condition": False,
            "exit": 2,
        },
    )
    row = create_node(
        api,
        workflow_id,
        "create",
        "Create RP currently appointed home",
        {
            "collection": "t_rp_currently_appointed",
            "params": {
                "values": {
                    "fk_t_rp_application_id": ref(application, "id"),
                    "f_rch_no": scope(loop, "rch_no"),
                    "f_rch_name": scope(loop, "rch_name"),
                },
                "appends": [],
            },
        },
    )
    link(api, upstream, loop)
    link(api, loop, row, branch_index=0)
    return loop


def destroy_config(collection: str, ids: str) -> dict[str, Any]:
    """Destroy only the exact IDs captured before replacement started."""

    return {
        "collection": collection,
        "params": {
            "filter": {"$and": [{"id": {"$in": ids}}]},
            "individualHooks": False,
        },
    }


def specific_hour_snapshot_script() -> str:
    return """const options = Array.isArray(rows) ? rows : [];
const staffings = options.flatMap((row) =>
  Array.isArray(row.f_specific_hour_staffings)
    ? row.f_specific_hour_staffings : []);
const times = staffings.flatMap((row) =>
  Array.isArray(row.f_specific_hour_time_rows)
    ? row.f_specific_hour_time_rows : []);
const ids = (values) => values
  .map((row) => row && row.id).filter((id) => id !== null && id !== undefined);
return {
  old_option_ids: ids(options),
  old_staffing_ids: ids(staffings),
  old_time_ids: ids(times),
};"""


def specific_hour_validation_script() -> str:
    return """const requested = typeof replacementRequested !== 'undefined'
  && Boolean(replacementRequested);
const expected = typeof requestedOptions !== 'undefined'
  && Array.isArray(requestedOptions) ? requestedOptions : [];
const rows = typeof currentOptions !== 'undefined'
  && Array.isArray(currentOptions) ? currentOptions : [];
const oldOptions = typeof oldOptionIds !== 'undefined'
  && Array.isArray(oldOptionIds) ? oldOptionIds : [];
const oldStaffings = typeof oldStaffingIds !== 'undefined'
  && Array.isArray(oldStaffingIds) ? oldStaffingIds : [];
const oldTimes = typeof oldTimeIds !== 'undefined'
  && Array.isArray(oldTimeIds) ? oldTimeIds : [];
const oldOptionSet = new Set(oldOptions.map(String));
const oldStaffSet = new Set(oldStaffings.map(String));
const oldTimeSet = new Set(oldTimes.map(String));
const newOptions = rows.filter((row) => row && !oldOptionSet.has(String(row.id)));
const text = (value) => value === null || typeof value === 'undefined'
  ? '' : String(value);
const ids = (values) => values
  .map((row) => row && row.id)
  .filter((id) => id !== null && typeof id !== 'undefined');
const staffCode = (row) => {
  const relation = row && row.f_staff_type_id;
  return relation && relation.f_staff_code
    ? String(relation.f_staff_code).toUpperCase() : '';
};
let valid = true;
if (!requested) {
  valid = newOptions.length === 0;
} else if (newOptions.length !== expected.length) {
  valid = false;
} else {
  for (const wantedOption of expected) {
    const matches = newOptions.filter((row) =>
      text(row.f_specific_hour_set_no) === text(wantedOption.set_no));
    if (matches.length !== 1) { valid = false; break; }
    const savedOption = matches[0];
    if (text(savedOption.f_section) !== text(wantedOption.section)
        || text(savedOption.f_section_other) !== text(wantedOption.section_other)) {
      valid = false; break;
    }
    const wantedStaff = Array.isArray(wantedOption.staffings)
      ? wantedOption.staffings : [];
    const savedStaff = Array.isArray(savedOption.f_specific_hour_staffings)
      ? savedOption.f_specific_hour_staffings.filter((row) =>
        row && !oldStaffSet.has(String(row.id))) : [];
    if (savedStaff.length !== wantedStaff.length) { valid = false; break; }
    for (const wanted of wantedStaff) {
      const matchesStaff = savedStaff.filter((row) =>
        staffCode(row) === text(wanted.staff_type_code).toUpperCase());
      if (matchesStaff.length !== 1) { valid = false; break; }
      const saved = matchesStaff[0];
      const rule = wanted._rule_snapshot || {};
      if (text(saved.f_duty_description) !== text(wanted.other_duties)
          || text(saved.f_staff_ratio_requirement)
             !== text(rule.staff_ratio_requirement)
          || Number(saved.f_minimum_required_hours || 0)
             !== Number(rule.minimum_required_hours || 0)
          || Number(saved.f_sort_order || 0) !== Number(rule.sort_order || 0)) {
        valid = false; break;
      }
      const wantedTimes = Array.isArray(wanted.time_rows) ? wanted.time_rows : [];
      const savedTimes = Array.isArray(saved.f_specific_hour_time_rows)
        ? saved.f_specific_hour_time_rows.filter((row) =>
          row && !oldTimeSet.has(String(row.id))) : [];
      if (savedTimes.length !== wantedTimes.length) { valid = false; break; }
      for (const wantedTime of wantedTimes) {
        const timeMatches = savedTimes.filter((row) =>
          Number(row.f_sort_order || 0) === Number(wantedTime._sort_order || 0)
          && text(row.f_work_hour_from) === text(wantedTime.work_hour_from)
          && text(row.f_work_hour_to) === text(wantedTime.work_hour_to)
          && Number(row.f_duration_hours || 0)
             === Number(wantedTime._duration_hours || 0)
          && text(row.f_remark) === text(wantedTime.remark));
        if (timeMatches.length !== 1) { valid = false; break; }
      }
      if (!valid) break;
    }
    if (!valid) break;
  }
}
return {
  valid,
  delete_time_ids: requested && valid ? oldTimes : [],
  delete_staffing_ids: requested && valid ? oldStaffings : [],
  delete_option_ids: requested && valid ? oldOptions : [],
  cleanup_time_ids: ids(newOptions.flatMap((option) => {
    const staffings = Array.isArray(option.f_specific_hour_staffings)
      ? option.f_specific_hour_staffings : [];
    return staffings.flatMap((staffing) =>
      Array.isArray(staffing.f_specific_hour_time_rows)
        ? staffing.f_specific_hour_time_rows : []);
  })),
  cleanup_staffing_ids: ids(newOptions.flatMap((option) =>
    Array.isArray(option.f_specific_hour_staffings)
      ? option.f_specific_hour_staffings : [])),
  cleanup_option_ids: ids(newOptions),
};"""


def rp_snapshot_script() -> str:
    return """const rows = Array.isArray(values) ? values : [];
return {old_ids: rows.map((row) => row && row.id)
  .filter((id) => id !== null && id !== undefined)};"""


def rp_validation_script() -> str:
    return """const requested = typeof replacementRequested !== 'undefined'
  && Boolean(replacementRequested);
const expectedProvided = typeof requestedHomes !== 'undefined'
  && Array.isArray(requestedHomes);
const oldProvided = typeof oldIds !== 'undefined' && Array.isArray(oldIds);
const currentProvided = typeof currentHomes !== 'undefined'
  && Array.isArray(currentHomes);
const expected = expectedProvided ? requestedHomes : [];
const old = oldProvided ? oldIds : [];
const rows = currentProvided ? currentHomes : [];
const oldSet = new Set(old.map(String));
const fresh = rows.filter((row) => row && !oldSet.has(String(row.id)));
const remaining = fresh.slice();
let valid = true;
if (!requested) {
  valid = fresh.length === 0;
} else if (!expectedProvided || !oldProvided || !currentProvided) {
  valid = false;
} else if (fresh.length !== expected.length) {
  valid = false;
} else {
  for (const wanted of expected) {
    const index = remaining.findIndex((row) =>
      String(row.f_rch_no || '') === String(wanted.rch_no || '')
      && String(row.f_rch_name || '') === String(wanted.rch_name || ''));
    if (index < 0) { valid = false; break; }
    remaining.splice(index, 1);
  }
  valid = valid && remaining.length === 0;
}
return {
  valid,
  delete_ids: requested && valid ? old : [],
  cleanup_ids: fresh.map((row) => row && row.id)
    .filter((id) => id !== null && typeof id !== 'undefined'),
};"""


def true_condition(value: str) -> dict[str, Any]:
    return {
        "rejectOnFalse": False,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "equal", "operands": [value, True]},
                ],
            }
        },
    }


def add_update_nested_replacement(
    api: NocoBaseApi,
    workflow_id: int,
    bp: Mapping[str, Any],
    parse: Mapping[str, Any],
    normalize: Mapping[str, Any],
    application: Mapping[str, Any],
    original: Mapping[str, Any],
    upstream: Mapping[str, Any],
    apply_intake: Mapping[str, Any],
    apply_overlay: Mapping[str, Any],
    terminal_failures: list[Mapping[str, Any]],
) -> Mapping[str, Any]:
    """Swap nested rows only after a complete read-back validation.

    The old IDs are captured before any insert.  Destroy filters consume only
    those immutable snapshots, never a parent FK, so newly-created rows cannot
    be selected accidentally.  Missing nested fields produce empty delete ID
    arrays; an explicit empty array validates as a requested clear operation.
    """

    if bp["key"] == "sh":
        old_rows = create_node(
            api,
            workflow_id,
            "query",
            "Snapshot old Specific Hour hierarchy",
            query_config(
                "t_specific_hour_option",
                [{"fk_specific_hour_app": {"$eq": ref(application, "id")}}],
                multiple=True,
                appends=(
                    "f_specific_hour_staffings",
                    "f_specific_hour_staffings.f_specific_hour_time_rows",
                ),
            ),
        )
        snapshot = create_node(
            api,
            workflow_id,
            "script",
            "Capture old Specific Hour child IDs",
            {
                "arguments": [{"name": "rows", "value": ref(old_rows)}],
                "content": specific_hour_snapshot_script(),
                "timeout": 3000,
                "continue": False,
            },
        )
        created = add_specific_hour_children(
            api, workflow_id, parse, application, snapshot
        )
        readback = create_node(
            api,
            workflow_id,
            "query",
            "Read back complete Specific Hour hierarchy",
            query_config(
                "t_specific_hour_option",
                [{"fk_specific_hour_app": {"$eq": ref(application, "id")}}],
                multiple=True,
                appends=(
                    "f_specific_hour_staffings",
                    "f_specific_hour_staffings.f_staff_type_id",
                    "f_specific_hour_staffings.f_specific_hour_time_rows",
                ),
            ),
        )
        validation = create_node(
            api,
            workflow_id,
            "script",
            "Validate replacement Specific Hour hierarchy",
            {
                "arguments": [
                    {
                        "name": "replacementRequested",
                        "value": ref(normalize, "nested_replacement_requested"),
                    },
                    {
                        "name": "requestedOptions",
                        "value": ref(parse, "specificHourOptions"),
                    },
                    {
                        "name": "oldOptionIds",
                        "value": ref(snapshot, "old_option_ids"),
                    },
                    {
                        "name": "oldStaffingIds",
                        "value": ref(snapshot, "old_staffing_ids"),
                    },
                    {
                        "name": "oldTimeIds",
                        "value": ref(snapshot, "old_time_ids"),
                    },
                    {"name": "currentOptions", "value": ref(readback)},
                ],
                "content": specific_hour_validation_script(),
                "timeout": 5000,
                "continue": False,
            },
        )
        link(api, upstream, old_rows, branch_index=1)
        link(api, old_rows, snapshot)
        link(api, created, readback)
        link(api, readback, validation)
    else:
        old_rows = create_node(
            api,
            workflow_id,
            "query",
            "Snapshot old RP currently appointed rows",
            query_config(
                "t_rp_currently_appointed",
                [{"fk_t_rp_application_id": {"$eq": ref(application, "id")}}],
                multiple=True,
            ),
        )
        snapshot = create_node(
            api,
            workflow_id,
            "script",
            "Capture old RP currently appointed IDs",
            {
                "arguments": [{"name": "values", "value": ref(old_rows)}],
                "content": rp_snapshot_script(),
                "timeout": 3000,
                "continue": False,
            },
        )
        created = add_rp_currently_appointed(
            api, workflow_id, parse, application, snapshot
        )
        readback = create_node(
            api,
            workflow_id,
            "query",
            "Read back RP currently appointed rows",
            query_config(
                "t_rp_currently_appointed",
                [{"fk_t_rp_application_id": {"$eq": ref(application, "id")}}],
                multiple=True,
            ),
        )
        validation = create_node(
            api,
            workflow_id,
            "script",
            "Validate replacement RP currently appointed rows",
            {
                "arguments": [
                    {
                        "name": "replacementRequested",
                        "value": ref(normalize, "nested_replacement_requested"),
                    },
                    {
                        "name": "requestedHomes",
                        "value": ref(parse, "currentlyAppointedHomes"),
                    },
                    {"name": "oldIds", "value": ref(snapshot, "old_ids")},
                    {"name": "currentHomes", "value": ref(readback)},
                ],
                "content": rp_validation_script(),
                "timeout": 3000,
                "continue": False,
            },
        )
        link(api, upstream, old_rows, branch_index=1)
        link(api, old_rows, snapshot)
        link(api, created, readback)
        link(api, readback, validation)

    valid = create_node(
        api,
        workflow_id,
        "condition",
        "Replacement hierarchy validated",
        true_condition(ref(validation, "valid")),
    )
    invalid = create_node(
        api,
        workflow_id,
        "update",
        "Mark nested replacement validation failed",
        processing_staging_update_config(
            staging_failed_values(
                "nested_replacement_readback_validation_failed",
                intake_id=ref(original, "f_intake_id"),
                application_id=ref(application, "id"),
            )
        ),
    )
    terminal_failures.append(invalid)
    if bp["key"] == "sh":
        cleanup_invalid_times = create_node(
            api,
            workflow_id,
            "destroy",
            "Cleanup invalid replacement Specific Hour time rows",
            destroy_config(
                "t_specific_hour_data", ref(validation, "cleanup_time_ids")
            ),
        )
        cleanup_invalid_staffings = create_node(
            api,
            workflow_id,
            "destroy",
            "Cleanup invalid replacement Specific Hour staffings",
            destroy_config(
                "t_specific_hour_staffing",
                ref(validation, "cleanup_staffing_ids"),
            ),
        )
        cleanup_invalid_options = create_node(
            api,
            workflow_id,
            "destroy",
            "Cleanup invalid replacement Specific Hour options",
            destroy_config(
                "t_specific_hour_option", ref(validation, "cleanup_option_ids")
            ),
        )
        link(api, cleanup_invalid_times, cleanup_invalid_staffings)
        link(api, cleanup_invalid_staffings, cleanup_invalid_options)
        link(api, cleanup_invalid_options, invalid)
        invalid_entry = cleanup_invalid_times
    else:
        cleanup_invalid_rows = create_node(
            api,
            workflow_id,
            "destroy",
            "Cleanup invalid replacement RP appointed rows",
            destroy_config(
                "t_rp_currently_appointed", ref(validation, "cleanup_ids")
            ),
        )
        link(api, cleanup_invalid_rows, invalid)
        invalid_entry = cleanup_invalid_rows
    processing = create_node(
        api,
        workflow_id,
        "query",
        "Reload processing Staging before nested swap",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": context("id")}},
                {"f_status": {"$eq": "processing"}},
            ],
        ),
    )
    may_swap = create_node(
        api,
        workflow_id,
        "condition",
        "Staging still processing before nested swap",
        exists_config(processing, reject_on_false=False),
    )
    link(api, validation, valid)
    link(api, valid, invalid_entry, branch_index=0)
    link(api, valid, processing, branch_index=1)
    link(api, processing, may_swap)
    link(api, may_swap, apply_intake, branch_index=1)
    link(api, apply_intake, apply_overlay)

    if bp["key"] == "sh":
        destroy_times = create_node(
            api,
            workflow_id,
            "destroy",
            "Destroy old Specific Hour time rows by snapshot IDs",
            destroy_config("t_specific_hour_data", ref(validation, "delete_time_ids")),
        )
        destroy_staffings = create_node(
            api,
            workflow_id,
            "destroy",
            "Destroy old Specific Hour staffings by snapshot IDs",
            destroy_config(
                "t_specific_hour_staffing",
                ref(validation, "delete_staffing_ids"),
            ),
        )
        destroy_options = create_node(
            api,
            workflow_id,
            "destroy",
            "Destroy old Specific Hour options by snapshot IDs",
            destroy_config(
                "t_specific_hour_option", ref(validation, "delete_option_ids")
            ),
        )
        link(api, apply_overlay, destroy_times)
        link(api, destroy_times, destroy_staffings)
        link(api, destroy_staffings, destroy_options)
        return destroy_options

    destroy_rows = create_node(
        api,
        workflow_id,
        "destroy",
        "Destroy old RP currently appointed rows by snapshot IDs",
        destroy_config("t_rp_currently_appointed", ref(validation, "delete_ids")),
    )
    link(api, apply_overlay, destroy_rows)
    return destroy_rows


def ensure_checklist_codes(api: NocoBaseApi) -> None:
    for record_id, code in CHECKLIST_CODES:
        row = api.request(
            "GET",
            "/api/t_document_checklist:get?"
            + urllib.parse.urlencode({"filterByTk": str(record_id)}),
        )
        if not isinstance(row, dict):
            raise ApiError(f"Checklist leaf {record_id} was not found")
        current = str(row.get("f_position_code") or "").strip()
        if current == code:
            print(f"existing_position_code={code}")
            continue
        if current:
            raise ApiError(
                f"Checklist {record_id} already has position_code {current!r}"
            )
        api.request(
            "POST",
            "/api/t_document_checklist:update?"
            + urllib.parse.urlencode({"filterByTk": str(record_id)}),
            {"f_position_code": code},
        )
        print(f"assigned_position_code={code}")


def ensure_application_type_enums(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    changed = False
    for bp in BPS:
        if any(item.get("value") == bp["application_type"] for item in options):
            print(f"existing_enum=f_application_type.{bp['application_type']}")
            continue
        options.append(
            {"value": bp["application_type"], "label": bp["application_label"]}
        )
        changed = True
        print(f"updated_enum=f_application_type.{bp['application_type']}")
    if changed:
        ui_schema["enum"] = options
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:update?"
            + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
            {"uiSchema": ui_schema},
        )


def build_create_graph(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    idempotency = create_node(
        api,
        workflow_id,
        "script",
        "Reject Create row with existing business IDs",
        {
            "arguments": [
                {"name": "intakeId", "value": context("f_intake_id")},
                {"name": "applicationId", "value": context("f_application_id")},
            ],
            "content": ("return {eligible: !intakeId && !applicationId};"),
            "timeout": 3000,
            "continue": False,
        },
    )
    eligible = create_node(
        api,
        workflow_id,
        "condition",
        "Create row has no prior business IDs",
        true_condition(ref(idempotency, "eligible")),
    )
    claim_sql = create_node(
        api,
        workflow_id,
        "sql",
        "Atomically claim submitted Create row",
        atomic_claim_config(),
    )
    claim_result = create_node(
        api,
        workflow_id,
        "script",
        "Inspect atomic Create claim result",
        {
            "arguments": [{"name": "rows", "value": ref(claim_sql)}],
            "content": claim_result_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    claim_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Atomic Create claim returned one row",
        true_condition(ref(claim_result, "claimed")),
    )
    add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claim_exists,
        title_prefix="Create",
        reason="create_claim_rejected",
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        f"Parse staged {bp['key']} request body",
        parse_config(bp),
    )
    rp_statuses: Mapping[str, Any] | None = None
    if bp["key"] == "rp":
        rp_statuses = create_node(
            api,
            workflow_id,
            "script",
            "Normalize RP case status values",
            {
                "arguments": [
                    {
                        "name": f"q{number}CaseStatus",
                        "value": ref(parse, f"q{number}_case_status"),
                    }
                    for number in range(1, 5)
                ],
                "content": rp_case_status_script(),
                "timeout": 3000,
                "continue": False,
            },
        )
    home = create_node(
        api,
        workflow_id,
        "query",
        "Resolve Home Record for Intake subject",
        query_config(
            "t_home_record",
            [{"id": {"$eq": context("f_rch_id")}}],
        ),
    )
    home_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Resolved Home Record exists",
        exists_config(home, reject_on_false=False),
    )
    home_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Home Record resolution failed",
        processing_staging_update_config(
            staging_failed_values("resolved_home_record_not_found")
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "create",
        "Create Intake (fixed type + Home Record)",
        {
            "collection": "t_intake_form",
            "params": {
                "values": {
                    "fk_intake_type": bp["intake_type_id"],
                    "fk_intake_source_rch": context("f_rch_id"),
                    "fk_task_owner_post": ref(parse, "ownerPost"),
                    "fk_intake_source": ref(parse, "sourceId"),
                    "fk_task_owner": ref(parse, "ownerId"),
                    "f_severity": ref(parse, "severity"),
                    "f_received_date": ref(parse, "receivedDate"),
                    "f_source_other": ref(parse, "sourceOther"),
                    "f_office_cd": ref(parse, "officeCode"),
                    "f_subject": ref(home, "f_rch_no"),
                    "f_comments": ref(parse, "comments"),
                    "f_api_create_staging_id": context("id"),
                    "createdBy": ref(parse, "submitterId"),
                },
                "appends": [],
            },
        },
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Find native-created application",
        query_config(
            bp["collection"],
            [{bp["intake_fk"]: {"$eq": ref(intake, "id")}}],
        ),
    )
    early_backfill = create_node(
        api,
        workflow_id,
        "update",
        "Backfill Intake ID before native application lookup",
        processing_staging_update_config({"f_intake_id": ref(intake, "id")}),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native application exists",
        exists_config(application, reject_on_false=False),
    )
    apply_overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged overlay",
        update_config(
            bp["collection"],
            ref(application, "id"),
            overlay_values(bp, parse, rp_statuses),
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark succeeded + backfill IDs",
        processing_staging_update_config(
            {
                "f_status": "succeeded",
                "f_intake_id": ref(intake, "id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": context("f_rch_id"),
            }
        ),
    )
    failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark failed + backfill Intake ID",
        processing_staging_update_config(
            staging_failed_values(
                "native_application_not_resolved",
                intake_id=ref(intake, "id"),
            )
        ),
    )
    link(api, idempotency, eligible)
    link(api, eligible, claim_sql, branch_index=1)
    link(api, claim_sql, claim_result)
    link(api, claim_result, claim_exists)
    link(api, claim_exists, parse, branch_index=1)
    if rp_statuses is None:
        link(api, parse, home)
    else:
        link(api, parse, rp_statuses)
        link(api, rp_statuses, home)
    link(api, home, home_exists)
    link(api, home_exists, home_failed, branch_index=0)
    link(api, home_exists, intake, branch_index=1)
    link(api, intake, early_backfill)
    link(api, early_backfill, application)
    link(api, application, exists)
    link(api, exists, apply_overlay, branch_index=1)
    link(api, exists, failed, branch_index=0)
    if bp["key"] == "sh":
        children_done = add_specific_hour_children(
            api, workflow_id, parse, application, apply_overlay
        )
    else:
        children_done = add_rp_currently_appointed(
            api, workflow_id, parse, application, apply_overlay
        )
    checklist_ok = add_checklist_graph(
        api, workflow_id, bp, parse, application, children_done
    )
    link(api, checklist_ok, succeeded, branch_index=1)


def build_update_graph(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    claim_sql = create_node(
        api,
        workflow_id,
        "sql",
        "Atomically claim submitted Update row",
        atomic_claim_config(require_ready_parent=True),
    )
    claim_result = create_node(
        api,
        workflow_id,
        "script",
        "Inspect atomic Update claim result",
        {
            "arguments": [{"name": "rows", "value": ref(claim_sql)}],
            "content": claim_result_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    claim_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Atomic Update claim returned one row",
        true_condition(ref(claim_result, "claimed")),
    )
    claim_rejected = add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claim_exists,
        title_prefix="Update",
        reason="update_claim_rejected",
    )
    add_deferred_received_finalizer(
        api,
        workflow_id,
        claim_rejected,
        bp,
        "rejected Update claim",
        branch_index=1,
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        f"Parse staged {bp['key']} update body",
        parse_config(bp),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
                {"f_status": {"$eq": "succeeded"}},
                {"f_application_status": {"$eq": "Accepted"}},
                {"f_intake_id": {"$notEmpty": True}},
                {"f_application_id": {"$notEmpty": True}},
            ],
        ),
    )
    original_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Accepted original CREATE exists",
        exists_config(original, reject_on_false=False),
    )
    original_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark update parent/lock failure",
        processing_staging_update_config(
            staging_failed_values("update_parent_not_accepted_or_not_found")
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Intake for guarded update",
        query_config(
            "t_intake_form",
            [{"id": {"$eq": ref(original, "f_intake_id")}}],
        ),
    )
    intake_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Intake exists",
        exists_config(intake, reject_on_false=False),
    )
    intake_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Intake failure",
        processing_staging_update_config(
            staging_failed_values("linked_intake_not_resolved")
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked application",
        query_config(
            bp["collection"],
            [{"id": {"$eq": ref(original, "f_application_id")}}],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked application exists",
        exists_config(application, reject_on_false=False),
    )
    application_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked application failure",
        processing_staging_update_config(
            staging_failed_values(
                "linked_application_not_resolved",
                intake_id=ref(original, "f_intake_id"),
            )
        ),
    )
    terminal_failures: list[Mapping[str, Any]] = [
        original_failed,
        intake_failed,
        application_failed,
    ]
    normalize = create_node(
        api,
        workflow_id,
        "script",
        f"Project guarded {bp['key']} update patch",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "application", "value": ref(application)},
                {"name": "intake", "value": ref(intake)},
            ],
            "content": guarded_patch_script(bp),
            "timeout": 3000,
            "continue": False,
        },
    )
    if bp["key"] == "sh":
        patch_fields = sorted(set(SH_SCALAR_FIELD_MAP.values()))
    else:
        patch_fields = sorted(
            {
                *RP_SCALAR_FIELD_MAP.values(),
                *RP_DECLARATION_FIELD_MAP.values(),
                *(
                    field
                    for mapping in {
                        **RP_LEGAL_FIELD_MAP,
                        **RP_OTHER_FIELD_MAP,
                    }.values()
                    for field in mapping.values()
                ),
                "f_rp_email",
                "f_application_received_date",
            }
        )
    apply_overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged update overlay",
        update_config(
            bp["collection"],
            ref(application, "id"),
            field_references(normalize, "patch", patch_fields),
        ),
    )
    apply_intake = create_node(
        api,
        workflow_id,
        "update",
        "Apply guarded Intake update",
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            field_references(
                normalize,
                "intake_patch",
                sorted(INTAKE_UPDATE_FIELD_MAP.values()),
            ),
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark update succeeded + backfill IDs",
        processing_staging_update_config(
            {
                "f_status": "succeeded",
                "f_intake_id": ref(original, "f_intake_id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": ref(original, "f_rch_id"),
                "f_parent_create_id": ref(original, "id"),
            }
        ),
    )
    link(api, claim_sql, claim_result)
    link(api, claim_result, claim_exists)
    link(api, claim_exists, parse, branch_index=1)
    link(api, parse, original)
    link(api, original, original_exists)
    link(api, original_exists, original_failed, branch_index=0)
    link(api, original_exists, intake, branch_index=1)
    link(api, intake, intake_exists)
    link(api, intake_exists, intake_failed, branch_index=0)
    link(api, intake_exists, application, branch_index=1)
    link(api, application, exists)
    link(api, exists, application_failed, branch_index=0)
    link(api, exists, normalize, branch_index=1)
    checklist_preflight = add_checklist_preflight_graph(
        api, workflow_id, bp, parse, application, normalize
    )
    add_deferred_received_finalizer(
        api,
        workflow_id,
        checklist_preflight,
        bp,
        "Checklist preflight failure",
        branch_index=0,
    )
    nested_done = add_update_nested_replacement(
        api,
        workflow_id,
        bp,
        parse,
        normalize,
        application,
        original,
        checklist_preflight,
        apply_intake,
        apply_overlay,
        terminal_failures,
    )
    checklist_ok = add_checklist_graph(
        api,
        workflow_id,
        bp,
        parse,
        application,
        nested_done,
    )
    link(api, checklist_ok, succeeded, branch_index=1)
    add_deferred_received_finalizer(
        api,
        workflow_id,
        checklist_ok,
        bp,
        "Checklist commit failure",
        branch_index=0,
    )
    add_deferred_received_finalizer(
        api, workflow_id, succeeded, bp, "successful Update"
    )
    for index, failure in enumerate(terminal_failures, start=1):
        add_deferred_received_finalizer(
            api, workflow_id, failure, bp, f"terminal failure {index}"
        )


def build_create_bridge(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
                {
                    "$or": [
                        {"f_application_id": {"$eq": context("id")}},
                        {"f_intake_id": {"$eq": context(bp["intake_fk"])}},
                    ]
                },
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    create_cmtf = create_node(
        api,
        workflow_id,
        "create",
        f"Create CMTF {bp['key']} staging at Accepted",
        {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": bp["create_api_type"],
                    "f_application_type": bp["application_type"],
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": context(
                        "f_office_code" if bp["key"] == "rp" else "f_office_cd"
                    ),
                    "f_intake_id": context(bp["intake_fk"]),
                    "f_application_id": context("id"),
                    "f_rch_id": context(bp["home_fk"]),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        },
    )
    link(api, staging, exists)
    link(api, exists, create_cmtf, branch_index=0)


def build_received_bridge(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked application",
        query_config(
            bp["collection"],
            [{bp["intake_fk"]: {"$eq": context("id")}}],
        ),
    )
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_intake_id": {"$eq": context("id")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging),
    )
    update_existing = create_node(
        api,
        workflow_id,
        "update",
        "Publish Received on existing CREATE staging",
        update_config(
            "t_api_request_staging",
            ref(staging, "id"),
            {
                "f_application_status": "Received",
                "f_application_id": ref(application, "id"),
                "f_office_code": context("f_office_cd"),
            },
        ),
    )
    link(api, application, staging)
    link(api, staging, exists)
    link(api, exists, update_existing, branch_index=1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=E")
    print("workflow_category=API Suorce")
    for bp in BPS:
        print(f"create_title={bp['create_title']}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    created_ids: list[int] = []
    try:
        ensure_checklist_codes(api)
        ensure_application_type_enums(api)
        for bp in BPS:
            for title in (bp["create_title"], bp["update_title"]):
                require_absent(api, title)
            create_wf = create_workflow(
                api,
                title=bp["create_title"],
                collection="t_api_request_staging",
                mode=1,
                condition=external_source_condition("CREATE", bp["create_api_type"]),
            )
            created_ids.append(int(create_wf["id"]))
            build_create_graph(api, int(create_wf["id"]), bp)

            update_wf = create_workflow(
                api,
                title=bp["update_title"],
                collection="t_api_request_staging",
                mode=1,
                condition=external_source_condition("UPDATE", bp["update_api_type"]),
            )
            created_ids.append(int(update_wf["id"]))
            build_update_graph(api, int(update_wf["id"]), bp)

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            final = api.get_workflow(workflow_id)
            print(f"workflow_id={final.get('id')}")
            print(f"workflow_title={final.get('title')}")
            print(f"enabled={str(bool(final.get('enabled'))).lower()}")
            print(f"node_count={len(final.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
