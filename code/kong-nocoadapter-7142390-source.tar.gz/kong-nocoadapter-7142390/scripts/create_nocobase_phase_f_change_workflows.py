#!/usr/bin/env python3
"""Create Phase-F Change Monitoring staging workflows on NocoBase.

Native Change Monitoring - 00 Create From Intake Form builds
t_change_monitoring_base when Intake type matches and source RCH is set.
Sidecar workflows write Staging, Intake, overlay and the matching child row.
New API workflows are mounted under API Suorce.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    create_workflow,
    exists_config,
    link,
    parse_variable,
    query_config,
    require_absent,
    set_enabled,
    update_config,
)
from create_nocobase_phase_e_sh_rp_workflows import (
    add_deferred_received_finalizer,
    add_rejected_staging_claim_finalizer,
    atomic_claim_config,
    claim_result_script,
    destroy_config,
    field_references,
    processing_staging_update_config,
    staging_failed_values,
    true_condition,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import external_source_condition

BPS: tuple[dict[str, Any], ...] = (
    {
        "key": "mgr",
        "application_type": "change_home_manager",
        "application_label": "Change of Home Manager (Home Profile)",
        "create_api_type": "create_intake_for_change_home_manager",
        "update_api_type": "update_change_home_manager_data",
        "intake_type_id": 383004177793024,
        "change_type": "home_manager",
        "child_collection": "t_change_home_manager",
        # The live 13001 initializer is enabled but has never produced an
        # execution.  Create the detail only after the native lookup proves it
        # absent; this leaves the native path untouched and prevents an empty
        # application shell for API-created records.
        "child_create_if_missing": True,
        "create_title": "API Request Staging — Create Change Home Manager v1",
        "update_title": "API Request Staging — Update Change Home Manager v1",
    },
    {
        "key": "beds",
        "application_type": "change_beds",
        "application_label": "Change of No. of Beds / Layout (Home Profile)",
        "create_api_type": "create_intake_for_change_beds",
        "update_api_type": "update_change_beds_data",
        "intake_type_id": 383004198764544,
        "change_type": "no_of_beds",
        "child_collection": "t_change_beds",
        "child_create_if_missing": True,
        "create_title": "API Request Staging — Create Change Beds v1",
        "update_title": "API Request Staging — Update Change Beds v1",
    },
    {
        "key": "mode",
        "application_type": "change_operation_mode",
        "application_label": "Change of Home Type (Home Profile)",
        "create_api_type": "create_intake_for_change_operation_mode",
        "update_api_type": "update_change_operation_mode_data",
        "intake_type_id": 383004215541760,
        "change_type": "home_type",
        "child_collection": "t_change_home_type",
        "child_create_if_missing": True,
        "create_title": "API Request Staging — Create Change Operation Mode v1",
        "update_title": "API Request Staging — Update Change Operation Mode v1",
    },
    {
        "key": "dir",
        "application_type": "change_directors",
        "application_label": "Change of Directors Monitoring",
        "create_api_type": "create_intake_for_change_directors",
        "update_api_type": "update_change_directors_data",
        "intake_type_id": 383302631882752,
        "change_type": None,
        "child_collection": "t_notice_of_change_of_directors_information",
        # The native Director initializer normally runs synchronously.  Keep a
        # lookup-first fallback for exceptional missing rows; it never runs
        # when the native detail exists.
        "child_create_if_missing": True,
        "create_title": "API Request Staging — Create Change Directors v1",
        "update_title": "API Request Staging — Update Change Directors v1",
    },
    {
        "key": "nurse",
        "application_type": "change_nurse_in_charge",
        "application_label": "Change of Nurse-in-Charge Monitoring",
        "create_api_type": "create_intake_for_change_nurse_in_charge",
        "update_api_type": "update_change_nurse_in_charge_data",
        "intake_type_id": 383004234416128,
        "change_type": "nurse_in_charge",
        "child_collection": "t_change_nurse_in_charge",
        # The live 13001 initializer has no executions.  Create only after the
        # lookup proves the native detail absent.
        "child_create_if_missing": True,
        "create_title": "API Request Staging — Create Change Nurse-in-Charge v1",
        "update_title": "API Request Staging — Update Change Nurse-in-Charge v1",
    },
)

BASE_PUBLIC_FIELD_MAP: dict[str, str] = {
    "case_summary.received_date": "f_application_received_date",
    "proposed_effective_date": "f_proposed_effective_date",
    "remarks": "f_remarks",
    "attachment_ids": "f_documents",
}

CHILD_PUBLIC_FIELD_MAPS: dict[str, dict[str, str]] = {
    "mgr": {
        "proposed_name": "f_proposed_name",
        "proposed_tel": "f_proposed_tel",
        "proposed_email": "f_proposed_email",
        "proposed_post": "f_proposed_post",
        "proposed_remark": "f_proposed_remark",
    },
    "beds": {
        "proposed_beds_self_care": "f_proposed_beds_self_care",
        "proposed_beds_meal": "f_proposed_beds_meal",
        "proposed_beds_nursing": "f_proposed_beds_nursing",
        "proposed_beds_care_and_attention": (
            "f_proposed_beds_care_and_attention"
        ),
        "proposed_residents_total_ab": "f_proposed_residents_total_ab",
        "proposed_residents_total_a": "f_proposed_residents_total_a",
        "proposed_residents_total_b": "f_proposed_residents_total_b",
        "proposed_residents_self_care": "f_proposed_residents_self_care",
        "proposed_residents_meal": "f_proposed_residents_meal",
        "proposed_residents_nursing": "f_proposed_residents_nursing",
        "proposed_residents_care_and_attention": (
            "f_proposed_residents_care_and_attention"
        ),
        "proposed_residents_nursing_beyond": (
            "f_proposed_residents_nursing_beyond"
        ),
        "proposed_residents_nonelderly_mental": (
            "f_proposed_residents_nonelderly_mental"
        ),
        "proposed_residents_nonelderly_intellectual": (
            "f_proposed_residents_nonelderly_intellectual"
        ),
        "proposed_residents_nonelderly_physical": (
            "f_proposed_residents_nonelderly_physical"
        ),
        "proposed_residents_nonelderly_others": (
            "f_proposed_residents_nonelderly_others"
        ),
        "proposed_residents_nonelderly_others_specify": (
            "f_proposed_residents_nonelderly_others_specify"
        ),
        "proposed_residents_nonelderly_other_details_num": (
            "f_proposed_residents_nonelderly_other_details_num"
        ),
    },
    "mode": {"proposed_rch_nature_code": "fk_proposed_rch_nature"},
    "dir": {
        "title": "f_title",
        "name_en": "f_name_eng",
        "name_cn": "f_name_chi",
        "hkid_no": "f_hkid_number",
        "date_of_directors_change": "f_date_of_directors_change",
        "position_in_rch": "f_position_in_the_rche_rche_nh",
        "authorised_to_apply": "f_authorised_to_apply",
        "means_of_authorisation": "f_means_of_authorisation",
        "signature_name_en": "f_signature_name_eng",
        "signature_name_cn": "f_signature_name_chi",
        "signature_title": "f_signature_title",
        "other_phone_number": "f_other_phone_number",
        "hkid_no_1": "f_hkid_no_1",
        "hkid_no_2": "f_hkid_no_2",
        "hkid_no_3": "f_hkid_no_3",
        "hkid_check_digit": "f_hkid_check_digit",
        "digital_organisation_certificate_name_en": (
            "f_name_eng_of_digital_organisation_certificate"
        ),
    },
    "nurse": {
        "person_title": "f_person_title",
        "name": "f_name",
        "tel": "f_tel",
        "email": "f_email",
        "position": "f_position",
        "attachment_ids": "f_documents",
    },
}


def context(field: str) -> str:
    return "{{$context.data." + field + "}" + "}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}" + "}"


def scope(node: Mapping[str, Any], field: str) -> str:
    return "{{$scopes." + str(node["key"]) + ".item." + field + "}}"


def parse_config(bp: Mapping[str, Any]) -> dict[str, Any]:
    example: dict[str, Any] = {
        "request_id": f"{bp['key'].upper()}-20260914-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "lorche_d_no": "L0043",
                "received_date": "2026-09-14",
                "severity": "0",
                "source_id": 701,
                "source_other": "OP",
                "submitter_user_id": 12,
                "task_owner_user_id": 45,
                "task_owner_post_code": "S(LR)1",
            },
            "proposed_effective_date": "2026-12-31",
            "remarks": "Phase F remarks",
            "comments": "Phase F overlay",
            "attachment_ids": [],
        },
    }
    variables = [
        parse_variable("form_data", "formData"),
        parse_variable("form_data.case_summary.office_code", "officeCode"),
        parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
        parse_variable("form_data.case_summary.received_date", "receivedDate"),
        parse_variable("form_data.case_summary.severity", "severity"),
        parse_variable("form_data.case_summary.source_id", "sourceId"),
        parse_variable("form_data.case_summary.source_other", "sourceOther"),
        parse_variable("form_data.case_summary.submitter_user_id", "submitterId"),
        parse_variable("form_data.case_summary.task_owner_user_id", "ownerId"),
        parse_variable("form_data.case_summary.task_owner_post_code", "ownerPost"),
        parse_variable("form_data.proposed_effective_date", "proposedEffectiveDate"),
        parse_variable("form_data.remarks", "remarks"),
        parse_variable("form_data.comments", "comments"),
        parse_variable("form_data.attachment_ids", "attachmentIds"),
        parse_variable("create_id", "createId"),
    ]
    if bp["key"] == "mgr":
        example["form_data"].update(
            {
                "proposed_name": "Example Manager",
                "proposed_tel": "21234567",
                "proposed_email": "mgr@example.com",
                "proposed_post": "Home Manager",
                "proposed_remark": "Phase F manager",
            }
        )
        variables.extend(
            [
                parse_variable("form_data.proposed_name", "proposedName"),
                parse_variable("form_data.proposed_tel", "proposedTel"),
                parse_variable("form_data.proposed_email", "proposedEmail"),
                parse_variable("form_data.proposed_post", "proposedPost"),
                parse_variable("form_data.proposed_remark", "proposedRemark"),
            ]
        )
    elif bp["key"] == "beds":
        example["form_data"].update(
            {
                "proposed_beds_self_care": 1,
                "proposed_beds_meal": 1,
                "proposed_beds_nursing": 1,
                "proposed_beds_care_and_attention": 1,
                "proposed_residents_total_ab": 4,
                "proposed_residents_total_a": 2,
                "proposed_residents_total_b": 2,
                "proposed_residents_self_care": 1,
                "proposed_residents_meal": 1,
                "proposed_residents_nursing": 1,
                "proposed_residents_care_and_attention": 1,
                "proposed_residents_nursing_beyond": 0,
                "proposed_residents_nonelderly_mental": 0,
                "proposed_residents_nonelderly_intellectual": 0,
                "proposed_residents_nonelderly_physical": 0,
                "proposed_residents_nonelderly_others": 0,
                "proposed_residents_nonelderly_others_specify": None,
                "proposed_residents_nonelderly_other_details_num": 0,
            }
        )
        variables.extend(
            [
                parse_variable("form_data.proposed_beds_self_care", "bedsSelfCare"),
                parse_variable("form_data.proposed_beds_meal", "bedsMeal"),
                parse_variable("form_data.proposed_beds_nursing", "bedsNursing"),
                parse_variable(
                    "form_data.proposed_beds_care_and_attention",
                    "bedsCareAndAttention",
                ),
                parse_variable("form_data.proposed_residents_total_ab", "residentsAb"),
                parse_variable("form_data.proposed_residents_total_a", "residentsA"),
                parse_variable("form_data.proposed_residents_total_b", "residentsB"),
                parse_variable(
                    "form_data.proposed_residents_self_care", "residentsSelfCare"
                ),
                parse_variable("form_data.proposed_residents_meal", "residentsMeal"),
                parse_variable(
                    "form_data.proposed_residents_nursing", "residentsNursing"
                ),
                parse_variable(
                    "form_data.proposed_residents_care_and_attention",
                    "residentsCareAndAttention",
                ),
                parse_variable(
                    "form_data.proposed_residents_nursing_beyond",
                    "residentsNursingBeyond",
                ),
                parse_variable(
                    "form_data.proposed_residents_nonelderly_mental",
                    "residentsNonelderlyMental",
                ),
                parse_variable(
                    "form_data.proposed_residents_nonelderly_intellectual",
                    "residentsNonelderlyIntellectual",
                ),
                parse_variable(
                    "form_data.proposed_residents_nonelderly_physical",
                    "residentsNonelderlyPhysical",
                ),
                parse_variable(
                    "form_data.proposed_residents_nonelderly_others",
                    "residentsNonelderlyOthers",
                ),
                parse_variable(
                    "form_data.proposed_residents_nonelderly_others_specify",
                    "residentsNonelderlyOthersSpecify",
                ),
                parse_variable(
                    "form_data.proposed_residents_nonelderly_other_details_num",
                    "residentsNonelderlyOtherDetailsNum",
                ),
            ]
        )
    elif bp["key"] == "mode":
        example["form_data"]["proposed_rch_nature_code"] = "PN"
        variables.append(
            parse_variable("form_data.proposed_rch_nature_code", "proposedNatureCode")
        )
    elif bp["key"] == "dir":
        example["form_data"].pop("attachment_ids", None)
        example["form_data"].update(
            {
                "title": "0",
                "name_en": "Example Director",
                "name_cn": "示例董事",
                "hkid_no": "A123456(7)",
                "date_of_directors_change": "2026-09-14",
                "position_in_rch": "Director",
                "authorised_to_apply": True,
                "means_of_authorisation": "0",
                "other_phone_number": "21234567",
                "digital_organisation_certificate_name_en": (
                    "Example Organisation"
                ),
                "documents": [],
            }
        )
        variables.extend(
            [
                parse_variable("form_data.title", "directorTitle"),
                parse_variable("form_data.name_en", "directorNameEn"),
                parse_variable("form_data.name_cn", "directorNameCn"),
                parse_variable("form_data.hkid_no", "directorHkid"),
                parse_variable(
                    "form_data.date_of_directors_change", "directorsChangeDate"
                ),
                parse_variable("form_data.position_in_rch", "directorPosition"),
                parse_variable("form_data.authorised_to_apply", "authorisedToApply"),
                parse_variable(
                    "form_data.means_of_authorisation", "meansOfAuthorisation"
                ),
                parse_variable("form_data.signature_name_en", "signatureNameEn"),
                parse_variable("form_data.signature_name_cn", "signatureNameCn"),
                parse_variable("form_data.signature_title", "signatureTitle"),
                parse_variable("form_data.other_phone_number", "otherPhone"),
                parse_variable("form_data.hkid_no_1", "directorHkid1"),
                parse_variable("form_data.hkid_no_2", "directorHkid2"),
                parse_variable("form_data.hkid_no_3", "directorHkid3"),
                parse_variable("form_data.hkid_check_digit", "directorHkidCheck"),
                parse_variable(
                    "form_data.digital_organisation_certificate_name_en",
                    "directorCertNameEn",
                ),
                parse_variable("form_data.documents", "directorDocuments"),
            ]
        )
    else:
        example["form_data"].update(
            {
                "person_title": "0",
                "name": "Example Nurse",
                "tel": "21234567",
                "email": "nurse@example.com",
                "position": "Nurse-in-Charge",
            }
        )
        variables.extend(
            [
                parse_variable("form_data.person_title", "nurseTitle"),
                parse_variable("form_data.name", "nurseName"),
                parse_variable("form_data.tel", "nurseTel"),
                parse_variable("form_data.email", "nurseEmail"),
                parse_variable("form_data.position", "nursePosition"),
            ]
        )
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": example,
        "variables": variables,
    }


def overlay_child(bp: Mapping[str, Any], parse: Mapping[str, Any]) -> dict[str, Any]:
    if bp["key"] == "mgr":
        return {
            "f_proposed_name": ref(parse, "proposedName"),
            "f_proposed_tel": ref(parse, "proposedTel"),
            "f_proposed_email": ref(parse, "proposedEmail"),
            "f_proposed_post": ref(parse, "proposedPost"),
            "f_proposed_remark": ref(parse, "proposedRemark"),
            "f_proposed_person_type": "home_manager",
        }
    if bp["key"] == "beds":
        return {
            "f_proposed_beds_self_care": ref(parse, "bedsSelfCare"),
            "f_proposed_beds_meal": ref(parse, "bedsMeal"),
            "f_proposed_beds_nursing": ref(parse, "bedsNursing"),
            "f_proposed_beds_care_and_attention": ref(parse, "bedsCareAndAttention"),
            "f_proposed_residents_total_ab": ref(parse, "residentsAb"),
            "f_proposed_residents_total_a": ref(parse, "residentsA"),
            "f_proposed_residents_total_b": ref(parse, "residentsB"),
            "f_proposed_residents_self_care": ref(parse, "residentsSelfCare"),
            "f_proposed_residents_meal": ref(parse, "residentsMeal"),
            "f_proposed_residents_nursing": ref(parse, "residentsNursing"),
            "f_proposed_residents_care_and_attention": ref(
                parse, "residentsCareAndAttention"
            ),
            "f_proposed_residents_nursing_beyond": ref(
                parse, "residentsNursingBeyond"
            ),
            "f_proposed_residents_nonelderly_mental": ref(
                parse, "residentsNonelderlyMental"
            ),
            "f_proposed_residents_nonelderly_intellectual": ref(
                parse, "residentsNonelderlyIntellectual"
            ),
            "f_proposed_residents_nonelderly_physical": ref(
                parse, "residentsNonelderlyPhysical"
            ),
            "f_proposed_residents_nonelderly_others": ref(
                parse, "residentsNonelderlyOthers"
            ),
            "f_proposed_residents_nonelderly_others_specify": ref(
                parse, "residentsNonelderlyOthersSpecify"
            ),
            "f_proposed_residents_nonelderly_other_details_num": ref(
                parse, "residentsNonelderlyOtherDetailsNum"
            ),
        }
    if bp["key"] == "mode":
        return {"fk_proposed_rch_nature": ref(parse, "proposedNatureCode")}
    if bp["key"] == "dir":
        return {
            "f_title": ref(parse, "directorTitle"),
            "f_name_eng": ref(parse, "directorNameEn"),
            "f_name_chi": ref(parse, "directorNameCn"),
            "f_hkid_number": ref(parse, "directorHkid"),
            "f_date_of_directors_change": ref(parse, "directorsChangeDate"),
            "f_position_in_the_rche_rche_nh": ref(parse, "directorPosition"),
            "f_authorised_to_apply": ref(parse, "authorisedToApply"),
            "f_means_of_authorisation": ref(parse, "meansOfAuthorisation"),
            "f_signature_name_eng": ref(parse, "signatureNameEn"),
            "f_signature_name_chi": ref(parse, "signatureNameCn"),
            "f_signature_title": ref(parse, "signatureTitle"),
            "f_other_phone_number": ref(parse, "otherPhone"),
            "f_hkid_no_1": ref(parse, "directorHkid1"),
            "f_hkid_no_2": ref(parse, "directorHkid2"),
            "f_hkid_no_3": ref(parse, "directorHkid3"),
            "f_hkid_check_digit": ref(parse, "directorHkidCheck"),
            "f_name_eng_of_digital_organisation_certificate": ref(
                parse, "directorCertNameEn"
            ),
        }
    return {
        "f_person_title": ref(parse, "nurseTitle"),
        "f_name": ref(parse, "nurseName"),
        "f_tel": ref(parse, "nurseTel"),
        "f_email": ref(parse, "nurseEmail"),
        "f_position": ref(parse, "nursePosition"),
        "f_documents": ref(parse, "attachmentIds"),
    }


def ensure_application_type_enums(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        "filterByTk=f_application_type",
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    changed = False
    for bp in BPS:
        if any(item.get("value") == bp["application_type"] for item in options):
            print(f"existing_enum=f_application_type.{bp['application_type']}")
            continue
        options.append(
            {"value": bp["application_type"], "label": bp["application_label"]}
        )
        changed = True
        print(f"updated_enum=f_application_type.{bp['application_type']}")
    if changed:
        ui_schema["enum"] = options
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:update?"
            "filterByTk=f_application_type",
            {"uiSchema": ui_schema},
        )



def director_document_loop(
    api: NocoBaseApi,
    workflow_id: int,
    documents: str,
    child: Mapping[str, Any],
    upstream: Mapping[str, Any],
    *,
    title: str,
) -> Mapping[str, Any]:
    loop = create_node(
        api,
        workflow_id,
        "loop",
        title,
        {"target": documents, "condition": False, "exit": 2},
    )
    row = create_node(
        api,
        workflow_id,
        "create",
        "Create typed Director document row",
        {
            "collection": "t_uploading_documents",
            "params": {
                "values": {
                    "fk_uploading_documents": ref(child, "id"),
                    "f_document_type": scope(loop, "document_type"),
                    "f_item_name": scope(loop, "document_type"),
                    "f_lastest_files": scope(loop, "attachment_ids"),
                    "f_remarks": scope(loop, "remarks"),
                    "f_status": "1",
                    "f_checked": True,
                },
                "appends": [],
            },
        },
    )
    link(api, upstream, loop)
    link(api, loop, row, branch_index=0)
    return loop


def director_document_upsert_loop(
    api: NocoBaseApi,
    workflow_id: int,
    documents: str,
    child: Mapping[str, Any],
    upstream: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Upsert requested Director documents before removing obsolete rows.

    The target deployment has no transaction node.  Updating/creating every
    requested type first makes retries convergent and, importantly, prevents a
    failed replacement from deleting the last good document set.
    """

    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Upsert replacement Director document rows",
        {"target": documents, "condition": False, "exit": 2},
    )
    existing_config = query_config(
        "t_uploading_documents",
        [
            {"fk_uploading_documents": {"$eq": ref(child, "id")}},
            {"f_document_type": {"$eq": scope(loop, "document_type")}},
        ],
    )
    # The lowest existing ID is the deterministic survivor when historical
    # duplicate rows exist.  Cleanup uses the same rule after the upsert.
    # Workflow query nodes use structured sort items in NocoBase 2.2.x.
    # REST list endpoints accept ``sort[]=id``, but persisting that string
    # form in a workflow node is rejected by the server schema.
    existing_config["params"]["sort"] = [
        {"field": "id", "direction": "asc"}
    ]
    existing = create_node(
        api,
        workflow_id,
        "query",
        "Find existing Director document by type",
        existing_config,
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing Director document type found",
        exists_config(existing, reject_on_false=False),
    )
    values = {
        "f_document_type": scope(loop, "document_type"),
        "f_item_name": scope(loop, "document_type"),
        "f_lastest_files": scope(loop, "attachment_ids"),
        "f_remarks": scope(loop, "remarks"),
        "f_status": "1",
        "f_checked": True,
    }
    update = create_node(
        api,
        workflow_id,
        "update",
        "Update existing Director document by type",
        update_config("t_uploading_documents", ref(existing, "id"), values),
    )
    create = create_node(
        api,
        workflow_id,
        "create",
        "Create missing Director document by type",
        {
            "collection": "t_uploading_documents",
            "params": {
                "values": {
                    "fk_uploading_documents": ref(child, "id"),
                    **values,
                },
                "appends": [],
            },
        },
    )
    link(api, upstream, loop)
    link(api, loop, existing, branch_index=0)
    link(api, existing, exists)
    link(api, exists, create, branch_index=0)
    link(api, exists, update, branch_index=1)
    return loop


def director_document_cleanup_script() -> str:
    """Return IDs from the pre-upsert snapshot that are no longer requested."""

    return """const current = Array.isArray(rows) ? rows : [];
const requested = Array.isArray(documents) ? documents : [];
const requestedTypes = new Set(requested.map((item) => item.document_type));
const seen = new Set();
const ids = [...current]
  .filter((row) => row && row.id != null)
  .sort((left, right) => Number(left.id) - Number(right.id))
  .filter((row) => {
    const type = row.f_document_type;
    if (!requestedTypes.has(type)) return true;
    if (seen.has(type)) return true;
    seen.add(type);
    return false;
  })
  .map((row) => row.id);
return {ids, has_obsolete: ids.length > 0};"""


def create_intake_patch_script() -> str:
    """Merge optional Create Intake values with native/database defaults."""

    return """const fd = formData && typeof formData === 'object' ? formData : {};
const summary = fd.case_summary && typeof fd.case_summary === 'object'
  ? fd.case_summary : {};
const row = intake && typeof intake === 'object' ? intake : {};
const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
return {
  f_received_date: own(summary, 'received_date')
    ? summary.received_date : row.f_received_date,
  f_severity: own(summary, 'severity') ? summary.severity : row.f_severity,
  fk_intake_source: own(summary, 'source_id')
    ? summary.source_id : row.fk_intake_source,
  f_source_other: own(summary, 'source_other')
    ? summary.source_other : row.f_source_other,
  f_comments: own(fd, 'comments') ? fd.comments : row.f_comments
};"""


def create_record_patch_script(field_map: Mapping[str, str]) -> str:
    """Project a Create overlay without clearing omitted native fields."""

    return f"""const fd = formData && typeof formData === 'object' ? formData : {{}};
const row = current && typeof current === 'object' ? current : {{}};
const mapping = {json.dumps(dict(field_map))};
const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
const pathValue = (obj, path) => {{
  const parts = path.split('.');
  let cursor = obj;
  for (const part of parts) {{
    if (!cursor || typeof cursor !== 'object' || !own(cursor, part)) {{
      return {{present: false, value: undefined}};
    }}
    cursor = cursor[part];
  }}
  return {{present: true, value: cursor}};
}};
const ids = (value) => Array.isArray(value)
  ? value.map((item) => item && typeof item === 'object' ? item.id : item)
      .filter((item) => item !== null && typeof item !== 'undefined')
  : [];
const patch = {{}};
for (const [publicName, nativeName] of Object.entries(mapping)) {{
  const submitted = pathValue(fd, publicName);
  if (submitted.present) {{
    patch[nativeName] = submitted.value;
  }} else if (nativeName === 'f_documents') {{
    patch[nativeName] = ids(row[nativeName]);
  }} else {{
    patch[nativeName] = row[nativeName];
  }}
}}
return {{patch}};"""


def _create_success(
    api: NocoBaseApi,
    workflow_id: int,
    bp: Mapping[str, Any],
    parse: Mapping[str, Any],
    intake: Mapping[str, Any],
    application: Mapping[str, Any],
    child: Mapping[str, Any],
    upstream: Mapping[str, Any],
) -> Mapping[str, Any]:
    terminal = upstream
    if bp["key"] == "dir":
        terminal = director_document_loop(
            api,
            workflow_id,
            ref(parse, "directorDocuments"),
            child,
            upstream,
            title="Create submitted Director document rows",
        )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark Create succeeded + backfill IDs",
        processing_staging_update_config(
            {
                "f_status": "succeeded",
                "f_error_message": None,
                "f_intake_id": ref(intake, "id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": context("f_rch_id"),
            }
        ),
    )
    link(api, terminal, succeeded)
    return succeeded


def guarded_patch_script(bp: Mapping[str, Any]) -> str:
    base_map = dict(BASE_PUBLIC_FIELD_MAP)
    if bp["key"] in {"nurse", "dir"}:
        base_map.pop("attachment_ids", None)
    child_map = CHILD_PUBLIC_FIELD_MAPS[bp["key"]]
    return f"""const fd = formData && typeof formData === 'object' ? formData : {{}};
const baseRow = base && typeof base === 'object' ? base : {{}};
const childRow = child && typeof child === 'object' ? child : {{}};
const intakeRow = intake && typeof intake === 'object' ? intake : {{}};
const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
const pathValue = (obj, path) => {{
  const parts = path.split('.');
  let cursor = obj;
  for (const part of parts) {{
    if (!cursor || typeof cursor !== 'object' || !own(cursor, part)) {{
      return {{present: false, value: undefined}};
    }}
    cursor = cursor[part];
  }}
  return {{present: true, value: cursor}};
}};
const ids = (value) => Array.isArray(value)
  ? value.map((item) => item && typeof item === 'object' ? item.id : item)
      .filter((item) => item !== null && typeof item !== 'undefined')
  : [];
const merge = (mapping, current) => {{
  const result = {{}};
  for (const [publicName, nativeName] of Object.entries(mapping)) {{
    const submitted = pathValue(fd, publicName);
    if (submitted.present) {{
      result[nativeName] = submitted.value;
    }} else if (nativeName === 'f_documents') {{
      result[nativeName] = ids(current[nativeName]);
    }} else {{
      result[nativeName] = current[nativeName];
    }}
  }}
  return result;
}};
const basePatch = merge({json.dumps(base_map)}, baseRow);
const childPatch = merge({json.dumps(child_map)}, childRow);
const intakePatch = {{
  f_comments: own(fd, 'comments') ? fd.comments : intakeRow.f_comments
}};
const documentsRequested = own(fd, 'documents');
const submittedDocuments = documentsRequested && Array.isArray(fd.documents)
  ? fd.documents
  : [];
const currentDocuments = Array.isArray(childRow.f_uploading_documents)
  ? childRow.f_uploading_documents
  : [];
const effectiveDocuments = documentsRequested
  ? submittedDocuments
  : currentDocuments;
let valid = true;
let error = null;
if ({json.dumps(bp['key'])} === 'beds') {{
  const n = (field) => Number(childPatch[field] || 0);
  const others = n('f_proposed_residents_nonelderly_others');
  const otherDetails = n('f_proposed_residents_nonelderly_other_details_num');
  if ((others > 0 || otherDetails > 0)
      && !String(
        childPatch.f_proposed_residents_nonelderly_others_specify || ''
      ).trim()) {{
    valid = false;
    error = 'beds_others_specify_required';
  }}
}}
if ({json.dumps(bp['key'])} === 'dir') {{
  if (childPatch.f_authorised_to_apply === true
      && (childPatch.f_means_of_authorisation === null
          || typeof childPatch.f_means_of_authorisation === 'undefined')) {{
    valid = false;
    error = 'directors_authorisation_method_required';
  }}
  if (childPatch.f_authorised_to_apply === true
      && childPatch.f_means_of_authorisation === '0'
      && !String(
        childPatch.f_name_eng_of_digital_organisation_certificate || ''
      ).trim()) {{
    valid = false;
    error = 'directors_certificate_name_required';
  }}
  if (childPatch.f_authorised_to_apply === true
      && childPatch.f_means_of_authorisation === '1'
      && !effectiveDocuments.some(
        (item) => item && item.document_type === 'AUTHORISATION_LETTER'
          || item && item.f_document_type === 'AUTHORISATION_LETTER'
      )) {{
    valid = false;
    error = 'directors_authorisation_letter_required';
  }}
}}
return {{
  valid,
  error,
  base_patch: basePatch,
  child_patch: childPatch,
  intake_patch: intakePatch,
  documents_requested: documentsRequested,
  documents: submittedDocuments
}};"""


def build_create_graph(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    claim_sql = create_node(
        api,
        workflow_id,
        "sql",
        "Atomically claim submitted Create row",
        atomic_claim_config(),
    )
    claim_result = create_node(
        api,
        workflow_id,
        "script",
        "Inspect atomic Create claim result",
        {
            "arguments": [{"name": "rows", "value": ref(claim_sql)}],
            "content": claim_result_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    claimed = create_node(
        api,
        workflow_id,
        "condition",
        "Atomic Create claim returned one row",
        true_condition(ref(claim_result, "claimed")),
    )
    add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claimed,
        title_prefix="Create",
        reason="create_claim_rejected",
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        f"Parse staged {bp['key']} request body",
        parse_config(bp),
    )
    home = create_node(
        api,
        workflow_id,
        "query",
        "Resolve canonical Home Record",
        query_config("t_home_record", [{"id": {"$eq": context("f_rch_id")}}]),
    )
    home_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Resolved Home Record exists",
        exists_config(home, reject_on_false=False),
    )
    home_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Home Record resolution failed",
        processing_staging_update_config(
            staging_failed_values("resolved_home_record_not_found")
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "create",
        "Create marked Intake (fixed type + Home Record)",
        {
            "collection": "t_intake_form",
            "params": {
                "values": {
                    "fk_intake_type": bp["intake_type_id"],
                    "fk_intake_source_rch": ref(home, "id"),
                    "fk_task_owner_post": ref(parse, "ownerPost"),
                    "fk_task_owner": ref(parse, "ownerId"),
                    "f_office_cd": ref(parse, "officeCode"),
                    "f_subject": ref(home, "f_rch_no"),
                    "f_api_create_staging_id": context("id"),
                    "createdBy": ref(parse, "submitterId"),
                },
                "appends": [],
            },
        },
    )
    normalize_intake = create_node(
        api,
        workflow_id,
        "script",
        "Merge optional Intake Create fields with native defaults",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "intake", "value": ref(intake)},
            ],
            "content": create_intake_patch_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    apply_intake = create_node(
        api,
        workflow_id,
        "update",
        "Apply supplied optional Intake Create fields",
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            {
                field: ref(normalize_intake, field)
                for field in [
                    "f_received_date",
                    "f_severity",
                    "fk_intake_source",
                    "f_source_other",
                    "f_comments",
                ]
            },
        ),
    )
    early_backfill = create_node(
        api,
        workflow_id,
        "update",
        "Backfill Intake ID before application lookup",
        processing_staging_update_config(
            {"f_intake_id": ref(intake, "id"), "f_rch_id": ref(home, "id")}
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Find native-created Change Monitoring",
        query_config(
            "t_change_monitoring_base",
            [
                {"fk_intake_form": {"$eq": ref(intake, "id")}},
                {"fk_intake_type": {"$eq": bp["intake_type_id"]}},
            ],
        ),
    )
    application_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native Change Monitoring exists",
        exists_config(application, reject_on_false=False),
    )
    application_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark native application resolution failed",
        processing_staging_update_config(
            staging_failed_values(
                "native_application_not_resolved", intake_id=ref(intake, "id")
            )
        ),
    )
    base_map = dict(BASE_PUBLIC_FIELD_MAP)
    if bp["key"] in {"nurse", "dir"}:
        base_map.pop("attachment_ids", None)
    normalize_base = create_node(
        api,
        workflow_id,
        "script",
        "Merge staged base Create fields with native defaults",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "current", "value": ref(application)},
            ],
            "content": create_record_patch_script(base_map),
            "timeout": 3000,
            "continue": False,
        },
    )
    apply_base = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged base fields only",
        update_config(
            "t_change_monitoring_base",
            ref(application, "id"),
            field_references(
                normalize_base,
                "patch",
                list(base_map.values()),
            ),
        ),
    )
    child_appends = ("f_documents",) if bp["key"] == "nurse" else ()
    child = create_node(
        api,
        workflow_id,
        "query",
        "Find native Change detail row",
        query_config(
            bp["child_collection"],
            [{"fk_change_monitoring": {"$eq": ref(application, "id")}}],
            appends=child_appends,
        ),
    )
    child_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native Change detail exists",
        exists_config(child, reject_on_false=False),
    )
    normalize_child = create_node(
        api,
        workflow_id,
        "script",
        "Merge staged detail Create fields with native defaults",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "current", "value": ref(child)},
            ],
            "content": create_record_patch_script(
                CHILD_PUBLIC_FIELD_MAPS[bp["key"]]
            ),
            "timeout": 3000,
            "continue": False,
        },
    )
    apply_child = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged detail fields",
        update_config(
            bp["child_collection"],
            ref(child, "id"),
            {
                **field_references(
                    normalize_child,
                    "patch",
                    list(CHILD_PUBLIC_FIELD_MAPS[bp["key"]].values()),
                ),
                **(
                    {"f_proposed_person_type": "home_manager"}
                    if bp["key"] == "mgr"
                    else {}
                ),
            },
        ),
    )
    link(api, claim_sql, claim_result)
    link(api, claim_result, claimed)
    link(api, claimed, parse, branch_index=1)
    link(api, parse, home)
    link(api, home, home_exists)
    link(api, home_exists, home_failed, branch_index=0)
    link(api, home_exists, intake, branch_index=1)
    link(api, intake, normalize_intake)
    link(api, normalize_intake, apply_intake)
    link(api, apply_intake, early_backfill)
    link(api, early_backfill, application)
    link(api, application, application_exists)
    link(api, application_exists, application_failed, branch_index=0)
    link(api, application_exists, normalize_base, branch_index=1)
    link(api, normalize_base, apply_base)
    link(api, apply_base, child)
    link(api, child, child_exists)
    link(api, child_exists, normalize_child, branch_index=1)
    link(api, normalize_child, apply_child)
    _create_success(
        api,
        workflow_id,
        bp,
        parse,
        intake,
        application,
        child,
        apply_child,
    )
    if bp["child_create_if_missing"]:
        create_child = create_node(
            api,
            workflow_id,
            "create",
            "Create missing Change detail owned by integration",
            {
                "collection": bp["child_collection"],
                "params": {
                    "values": {
                        "fk_change_monitoring": ref(application, "id"),
                        **overlay_child(bp, parse),
                    },
                    "appends": [],
                },
            },
        )
        link(api, child_exists, create_child, branch_index=0)
        _create_success(
            api,
            workflow_id,
            bp,
            parse,
            intake,
            application,
            create_child,
            create_child,
        )
    else:
        child_failed = create_node(
            api,
            workflow_id,
            "update",
            "Mark native Change detail resolution failed",
            processing_staging_update_config(
                staging_failed_values(
                    "native_change_detail_not_resolved",
                    intake_id=ref(intake, "id"),
                    application_id=ref(application, "id"),
                )
            ),
        )
        link(api, child_exists, child_failed, branch_index=0)


def build_update_graph(
    api: NocoBaseApi, workflow_id: int, bp: Mapping[str, Any]
) -> None:
    claim_sql = create_node(
        api,
        workflow_id,
        "sql",
        "Atomically claim submitted Update row",
        atomic_claim_config(require_ready_parent=True),
    )
    claim_result = create_node(
        api,
        workflow_id,
        "script",
        "Inspect atomic Update claim result",
        {
            "arguments": [{"name": "rows", "value": ref(claim_sql)}],
            "content": claim_result_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    claimed = create_node(
        api,
        workflow_id,
        "condition",
        "Atomic Update claim returned one row",
        true_condition(ref(claim_result, "claimed")),
    )
    rejected = add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claimed,
        title_prefix="Update",
        reason="update_claim_rejected",
    )
    add_deferred_received_finalizer(
        api, workflow_id, rejected, bp, "rejected Update claim", branch_index=1
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        f"Parse staged {bp['key']} update body",
        parse_config(bp),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve ready Accepted CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": bp["create_api_type"]}},
                {"f_application_type": {"$eq": bp["application_type"]}},
                {"f_status": {"$eq": "succeeded"}},
                {"f_application_status": {"$eq": "Accepted"}},
                {"f_intake_id": {"$notEmpty": True}},
                {"f_application_id": {"$notEmpty": True}},
            ],
        ),
    )
    original_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Ready Accepted CREATE staging exists",
        exists_config(original, reject_on_false=False),
    )
    original_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Update parent resolution failed",
        processing_staging_update_config(
            staging_failed_values("update_parent_not_accepted_or_not_found")
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Intake",
        query_config(
            "t_intake_form", [{"id": {"$eq": ref(original, "f_intake_id")}}]
        ),
    )
    intake_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Intake exists",
        exists_config(intake, reject_on_false=False),
    )
    intake_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Intake resolution failed",
        processing_staging_update_config(
            staging_failed_values("linked_intake_not_resolved")
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Change Monitoring",
        query_config(
            "t_change_monitoring_base",
            [
                {"id": {"$eq": ref(original, "f_application_id")}},
                {"fk_intake_form": {"$eq": ref(original, "f_intake_id")}},
            ],
            appends=("f_documents",),
        ),
    )
    application_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Change Monitoring exists",
        exists_config(application, reject_on_false=False),
    )
    application_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Change Monitoring resolution failed",
        processing_staging_update_config(
            staging_failed_values(
                "linked_application_not_resolved",
                intake_id=ref(original, "f_intake_id"),
            )
        ),
    )
    child_appends: tuple[str, ...] = ()
    if bp["key"] == "nurse":
        child_appends = ("f_documents",)
    elif bp["key"] == "dir":
        child_appends = (
            "f_uploading_documents",
            "f_uploading_documents.f_lastest_files",
        )
    child = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Change detail",
        query_config(
            bp["child_collection"],
            [{"fk_change_monitoring": {"$eq": ref(application, "id")}}],
            appends=child_appends,
        ),
    )
    child_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Change detail exists",
        exists_config(child, reject_on_false=False),
    )
    child_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Change detail resolution failed",
        processing_staging_update_config(
            staging_failed_values(
                "linked_change_detail_not_resolved",
                intake_id=ref(original, "f_intake_id"),
                application_id=ref(application, "id"),
            )
        ),
    )
    normalize = create_node(
        api,
        workflow_id,
        "script",
        f"Project guarded {bp['key']} update patch",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "base", "value": ref(application)},
                {"name": "child", "value": ref(child)},
                {"name": "intake", "value": ref(intake)},
            ],
            "content": guarded_patch_script(bp),
            "timeout": 3000,
            "continue": False,
        },
    )
    valid = create_node(
        api,
        workflow_id,
        "condition",
        "Merged Change patch is valid",
        true_condition(ref(normalize, "valid")),
    )
    invalid = create_node(
        api,
        workflow_id,
        "update",
        "Mark merged Change patch validation failed",
        processing_staging_update_config(
            staging_failed_values(
                ref(normalize, "error"),
                intake_id=ref(original, "f_intake_id"),
                application_id=ref(application, "id"),
            )
        ),
    )
    apply_intake = create_node(
        api,
        workflow_id,
        "update",
        "Apply guarded Intake comments patch",
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            field_references(normalize, "intake_patch", ["f_comments"]),
        ),
    )
    base_fields = list(BASE_PUBLIC_FIELD_MAP.values())
    if bp["key"] in {"nurse", "dir"}:
        base_fields.remove("f_documents")
    apply_base = create_node(
        api,
        workflow_id,
        "update",
        "Apply guarded base patch",
        update_config(
            "t_change_monitoring_base",
            ref(application, "id"),
            field_references(normalize, "base_patch", base_fields),
        ),
    )
    apply_child = create_node(
        api,
        workflow_id,
        "update",
        "Apply guarded detail patch",
        update_config(
            bp["child_collection"],
            ref(child, "id"),
            field_references(
                normalize,
                "child_patch",
                list(CHILD_PUBLIC_FIELD_MAPS[bp["key"]].values()),
            ),
        ),
    )

    def success_node(title: str) -> Mapping[str, Any]:
        return create_node(
            api,
            workflow_id,
            "update",
            title,
            processing_staging_update_config(
                {
                    "f_status": "succeeded",
                    "f_error_message": None,
                    "f_intake_id": ref(original, "f_intake_id"),
                    "f_application_id": ref(application, "id"),
                    "f_rch_id": ref(original, "f_rch_id"),
                    "f_parent_create_id": ref(original, "id"),
                }
            ),
        )

    link(api, claim_sql, claim_result)
    link(api, claim_result, claimed)
    link(api, claimed, parse, branch_index=1)
    link(api, parse, original)
    link(api, original, original_exists)
    link(api, original_exists, original_failed, branch_index=0)
    link(api, original_exists, intake, branch_index=1)
    link(api, intake, intake_exists)
    link(api, intake_exists, intake_failed, branch_index=0)
    link(api, intake_exists, application, branch_index=1)
    link(api, application, application_exists)
    link(api, application_exists, application_failed, branch_index=0)
    link(api, application_exists, child, branch_index=1)
    link(api, child, child_exists)
    link(api, child_exists, child_failed, branch_index=0)
    link(api, child_exists, normalize, branch_index=1)
    link(api, normalize, valid)
    link(api, valid, invalid, branch_index=0)
    link(api, valid, apply_intake, branch_index=1)
    link(api, apply_intake, apply_base)
    link(api, apply_base, apply_child)

    terminal_failures = [
        original_failed,
        intake_failed,
        application_failed,
        child_failed,
        invalid,
    ]
    for index, failure in enumerate(terminal_failures, start=1):
        add_deferred_received_finalizer(
            api, workflow_id, failure, bp, f"terminal failure {index}"
        )

    if bp["key"] != "dir":
        succeeded = success_node("Mark Update succeeded + backfill IDs")
        link(api, apply_child, succeeded)
        add_deferred_received_finalizer(
            api, workflow_id, succeeded, bp, "successful Update"
        )
        return

    replace_documents = create_node(
        api,
        workflow_id,
        "condition",
        "Director document replacement requested",
        true_condition(ref(normalize, "documents_requested")),
    )
    link(api, apply_child, replace_documents)
    unchanged = success_node("Mark Update succeeded without Director document swap")
    link(api, replace_documents, unchanged, branch_index=0)
    add_deferred_received_finalizer(
        api, workflow_id, unchanged, bp, "successful Update without document swap"
    )
    old_documents = create_node(
        api,
        workflow_id,
        "query",
        "Snapshot existing Director document rows",
        query_config(
            "t_uploading_documents",
            [{"fk_uploading_documents": {"$eq": ref(child, "id")}}],
            multiple=True,
        ),
    )
    cleanup_plan = create_node(
        api,
        workflow_id,
        "script",
        "Plan obsolete Director documents from pre-upsert snapshot",
        {
            "arguments": [
                {"name": "rows", "value": ref(old_documents)},
                {"name": "documents", "value": ref(normalize, "documents")},
            ],
            "content": director_document_cleanup_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    link(api, replace_documents, old_documents, branch_index=1)
    link(api, old_documents, cleanup_plan)
    documents_done = director_document_upsert_loop(
        api,
        workflow_id,
        ref(normalize, "documents"),
        child,
        cleanup_plan,
    )
    cleanup_needed = create_node(
        api,
        workflow_id,
        "condition",
        "Obsolete Director snapshot rows remain after upsert",
        true_condition(ref(cleanup_plan, "has_obsolete")),
    )
    destroy_obsolete = create_node(
        api,
        workflow_id,
        "destroy",
        "Destroy only obsolete pre-upsert Director document rows",
        destroy_config("t_uploading_documents", ref(cleanup_plan, "ids")),
    )
    link(api, documents_done, cleanup_needed)
    link(api, cleanup_needed, destroy_obsolete, branch_index=1)
    no_cleanup = success_node(
        "Mark Update succeeded after Director document upsert"
    )
    link(api, cleanup_needed, no_cleanup, branch_index=0)
    add_deferred_received_finalizer(
        api,
        workflow_id,
        no_cleanup,
        bp,
        "successful Director document Update without cleanup",
    )
    replaced = success_node(
        "Mark Update succeeded after Director document upsert + cleanup"
    )
    link(api, destroy_obsolete, replaced)
    add_deferred_received_finalizer(
        api, workflow_id, replaced, bp, "successful Director document Update"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=F")
    print("workflow_category=API Suorce")
    for bp in BPS:
        print(f"create_title={bp['create_title']}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    created_ids: list[int] = []
    try:
        ensure_application_type_enums(api)
        for bp in BPS:
            for title in (bp["create_title"], bp["update_title"]):
                require_absent(api, title)
            create_wf = create_workflow(
                api,
                title=bp["create_title"],
                collection="t_api_request_staging",
                mode=1,
                condition=external_source_condition("CREATE", bp["create_api_type"]),
            )
            created_ids.append(int(create_wf["id"]))
            build_create_graph(api, int(create_wf["id"]), bp)

            update_wf = create_workflow(
                api,
                title=bp["update_title"],
                collection="t_api_request_staging",
                mode=1,
                condition=external_source_condition("UPDATE", bp["update_api_type"]),
            )
            created_ids.append(int(update_wf["id"]))
            build_update_graph(api, int(update_wf["id"]), bp)

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            final = api.get_workflow(workflow_id)
            print(f"workflow_id={final.get('id')}")
            print(f"workflow_title={final.get('title')}")
            print(f"enabled={str(bool(final.get('enabled'))).lower()}")
            print(f"node_count={len(final.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
