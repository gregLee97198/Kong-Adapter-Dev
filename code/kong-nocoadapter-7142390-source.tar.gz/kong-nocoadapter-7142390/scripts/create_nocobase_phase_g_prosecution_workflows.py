#!/usr/bin/env python3
"""Create Phase-G Prosecution staging workflows on NocoBase.

036/037 share one Intake Type and one table. Native Create From Intake already
builds t_prosecution_conviction_records when type matches and source RCH is set.
New API workflows are mounted under API Suorce.
"""

from __future__ import annotations

import argparse
import os
import sys
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    create_workflow,
    exists_config,
    link,
    parse_variable,
    query_config,
    require_absent,
    scope,
    set_enabled,
    update_config,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import external_source_condition

INTAKE_TYPE_ID = 380975716106307
COLLECTION = "t_prosecution_conviction_records"
APPLICATION_TYPE = "prosecution"
APPLICATION_LABEL = "Prosecution"
CREATE_API_TYPE = "create_intake_for_prosecution"
UPDATE_API_TYPE = "update_prosecution_data"
CREATE_TITLE = "API Request Staging — Create Prosecution v1"
UPDATE_TITLE = "API Request Staging — Update Prosecution v1"
CREATE_BRIDGE_TITLE = "API Bridge — Prosecution Application Created to Staging v1"
RECEIVED_BRIDGE_TITLE = "API Bridge — Prosecution Intake Completed to Received v1"


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def parse_config() -> dict[str, Any]:
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": {
            "request_id": "PRO-20260914-0001",
            "create_id": "384761337741312",
            "form_data": {
                "case_summary": {
                    "office_code": "LORCHE",
                    "lorche_d_no": "L0043",
                    "received_date": "2026-09-14",
                    "severity": "0",
                    "source_id": 701,
                    "source_other": "OP",
                    "submitter_user_id": 12,
                    "task_owner_user_id": 45,
                    "task_owner_post_code": "S(LR)1",
                },
                "serial_no": "P-001",
                "court_case_no": "ESS12345/2026",
                "unlicenced_rch": False,
                "legal_advice_result": "Go for Prosecution",
                "date_of_advice_from_doj": "2026-09-01",
                "date_of_enforcement_action": "2026-09-10",
                "first_court_hearing_date": "2026-10-01",
                "last_court_hearing_date": "2026-10-15",
                "reason": "Phase G reason",
                "remarks": "Phase G remarks",
                "comments": "Phase G overlay",
                "offence_items": [
                    {
                        "name_of_defendant": "Example Defendant",
                        "name_of_defendant_chi": "示例被告人",
                        "type_of_defendant": "Natural Person",
                        "hkic_no": "A123456(7)",
                        "offence_charged": "Cap. 459 s.6",
                        "detail_of_offence": "Phase G offence",
                        "pg_png": "PG",
                    }
                ],
            },
        },
        "variables": [
            parse_variable("form_data.case_summary.office_code", "officeCode"),
            parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
            parse_variable("form_data.case_summary.received_date", "receivedDate"),
            parse_variable("form_data.case_summary.severity", "severity"),
            parse_variable("form_data.case_summary.source_id", "sourceId"),
            parse_variable("form_data.case_summary.source_other", "sourceOther"),
            parse_variable("form_data.case_summary.submitter_user_id", "submitterId"),
            parse_variable("form_data.case_summary.task_owner_user_id", "ownerId"),
            parse_variable("form_data.case_summary.task_owner_post_code", "ownerPost"),
            parse_variable("form_data.serial_no", "serialNo"),
            parse_variable("form_data.court_case_no", "courtCaseNo"),
            parse_variable("form_data.unlicenced_rch", "unlicencedRch"),
            parse_variable("form_data.legal_advice_result", "legalAdviceResult"),
            parse_variable("form_data.date_of_advice_from_doj", "adviceDate"),
            parse_variable("form_data.date_of_enforcement_action", "enforcementDate"),
            parse_variable("form_data.first_court_hearing_date", "firstHearing"),
            parse_variable("form_data.last_court_hearing_date", "lastHearing"),
            parse_variable("form_data.reason", "reason"),
            parse_variable("form_data.remarks", "remarks"),
            parse_variable("form_data.comments", "comments"),
            parse_variable("form_data.offence_items", "offenceItems"),
            parse_variable(
                "form_data.offence_items[].name_of_defendant", "offenceNameEn"
            ),
            parse_variable(
                "form_data.offence_items[].name_of_defendant_chi", "offenceNameCn"
            ),
            parse_variable(
                "form_data.offence_items[].type_of_defendant", "offenceType"
            ),
            parse_variable("form_data.offence_items[].hkic_no", "offenceHkic"),
            parse_variable(
                "form_data.offence_items[].date_of_birth", "offenceDob"
            ),
            parse_variable(
                "form_data.offence_items[].offence_charged", "offenceCharged"
            ),
            parse_variable(
                "form_data.offence_items[].offence_charged_items",
                "offenceChargedItems",
            ),
            parse_variable(
                "form_data.offence_items[].offence_charged_items_others",
                "offenceChargedOthers",
            ),
            parse_variable(
                "form_data.offence_items[].detail_of_offence", "offenceDetail"
            ),
            parse_variable("form_data.offence_items[].section_cap", "offenceSection"),
            parse_variable("form_data.offence_items[].pg_png", "offencePgPng"),
            parse_variable(
                "form_data.offence_items[].date_of_conviction", "offenceConvictionDate"
            ),
            parse_variable("form_data.offence_items[].sanction", "offenceSanction"),
            parse_variable(
                "form_data.offence_items[].court_disposal", "offenceDisposal"
            ),
            parse_variable("form_data.offence_items[].remark", "offenceRemark"),
            parse_variable("create_id", "createId"),
        ],
    }


def overlay_values(parse: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "f_home_record_id": context("f_rch_id"),
        "f_office_cd": ref(parse, "officeCode"),
        "f_serial_no": ref(parse, "serialNo"),
        "f_court_case_no": ref(parse, "courtCaseNo"),
        "f_unlicenced_rch": ref(parse, "unlicencedRch"),
        "f_result_of_seeking_legal_advice_from_doj": ref(parse, "legalAdviceResult"),
        "f_date_of_advice_from_doj": ref(parse, "adviceDate"),
        "f_date_of_enforcement_action": ref(parse, "enforcementDate"),
        "f_first_court_hearing_date": ref(parse, "firstHearing"),
        "f_last_court_hearing_date": ref(parse, "lastHearing"),
        "f_reason": ref(parse, "reason"),
        "f_remarks": ref(parse, "remarks"),
        "f_comments": ref(parse, "comments"),
    }


def ensure_application_type_enum(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        "filterByTk=f_application_type",
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    if any(item.get("value") == APPLICATION_TYPE for item in options):
        print(f"existing_enum=f_application_type.{APPLICATION_TYPE}")
        return
    options.append({"value": APPLICATION_TYPE, "label": APPLICATION_LABEL})
    ui_schema["enum"] = options
    api.request(
        "POST",
        "/api/collections/t_api_request_staging/fields:update?"
        "filterByTk=f_application_type",
        {"uiSchema": ui_schema},
    )
    print(f"updated_enum=f_application_type.{APPLICATION_TYPE}")


def attach_finish(
    api: NocoBaseApi,
    workflow_id: int,
    parse: Mapping[str, Any],
    intake: Mapping[str, Any],
    application: Mapping[str, Any],
    start: Mapping[str, Any],
) -> None:
    overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged overlay",
        update_config(COLLECTION, ref(application, "id"), overlay_values(parse)),
    )
    offence_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Create offence charged items",
        {"target": ref(parse, "offenceItems"), "condition": False, "exit": 2},
    )
    create_offence = create_node(
        api,
        workflow_id,
        "create",
        "Create offence charged item",
        {
            "collection": "t_offence_charged_items",
            "params": {
                "values": {
                    "fk_offence_charged_items": ref(application, "id"),
                    "f_name_of_defendant": scope(offence_loop, "name_of_defendant"),
                    "f_name_of_defendant_chi": scope(
                        offence_loop, "name_of_defendant_chi"
                    ),
                    "f_type_of_defendant": scope(offence_loop, "type_of_defendant"),
                    "f_hkic_no": scope(offence_loop, "hkic_no"),
                    "f_date_of_birth": scope(offence_loop, "date_of_birth"),
                    "f_offence_charged": scope(offence_loop, "offence_charged"),
                    "f_offence_charged_items": scope(
                        offence_loop, "offence_charged_items"
                    ),
                    "f_offence_charged_items_others": scope(
                        offence_loop, "offence_charged_items_others"
                    ),
                    "f_detail_of_offence": scope(offence_loop, "detail_of_offence"),
                    "f_section_cap_of_the_offences": scope(
                        offence_loop, "section_cap"
                    ),
                    "f_pg_png": scope(offence_loop, "pg_png"),
                    "f_date_of_conviction": scope(offence_loop, "date_of_conviction"),
                    "f_sanction": scope(offence_loop, "sanction"),
                    "f_court_disposal": scope(offence_loop, "court_disposal"),
                    "f_remark": scope(offence_loop, "remark"),
                    "f_business_registration_number_if_applicable": scope(
                        offence_loop, "business_registration_number"
                    ),
                    "f_certificate_of_incorporation_number_if_applicable": scope(
                        offence_loop, "certificate_of_incorporation_number"
                    ),
                    "f_brc_no": scope(offence_loop, "brc_no"),
                    "f_the_trust_number_if_applicable": scope(
                        offence_loop, "trust_number"
                    ),
                },
                "appends": [],
            },
        },
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark succeeded + backfill IDs",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(intake, "id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": context("f_rch_id"),
            },
        ),
    )
    link(api, start, overlay)
    link(api, overlay, offence_loop)
    link(api, offence_loop, create_offence, branch_index=0)
    link(api, offence_loop, succeeded)


def build_create_graph(api: NocoBaseApi, workflow_id: int) -> None:
    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    processing["config"]["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "submitted"}},
        ]
    }
    api.update_node(int(processing["id"]), {"config": processing["config"]})
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged prosecution request body",
        parse_config(),
    )
    intake = create_node(
        api,
        workflow_id,
        "create",
        "Create Intake (fixed type + Home Record)",
        {
            "collection": "t_intake_form",
            "params": {
                "values": {
                    "fk_intake_type": INTAKE_TYPE_ID,
                    "fk_intake_source_rch": context("f_rch_id"),
                    "fk_task_owner_post": ref(parse, "ownerPost"),
                    "fk_intake_source": ref(parse, "sourceId"),
                    "fk_task_owner": ref(parse, "ownerId"),
                    "f_severity": ref(parse, "severity"),
                    "f_received_date": ref(parse, "receivedDate"),
                    "f_source_other": ref(parse, "sourceOther"),
                    "f_office_cd": ref(parse, "officeCode"),
                    "f_subject": ref(parse, "lorcheDNo"),
                    "f_comments": ref(parse, "comments"),
                    "createdBy": ref(parse, "submitterId"),
                },
                "appends": [],
            },
        },
    )
    query_app = create_node(
        api,
        workflow_id,
        "query",
        "Find native-created Prosecution",
        query_config(COLLECTION, [{"fk_intake_form": {"$eq": ref(intake, "id")}}]),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Native Prosecution exists",
        exists_config(query_app, reject_on_false=False),
    )
    reuse = create_node(
        api,
        workflow_id,
        "query",
        "Load native Prosecution for overlay",
        query_config(COLLECTION, [{"id": {"$eq": ref(query_app, "id")}}]),
    )
    create_app = create_node(
        api,
        workflow_id,
        "create",
        "Create Prosecution if native missed",
        {
            "collection": COLLECTION,
            "params": {
                "values": {
                    "f_approval_status": "0",
                    "fk_intake_form": ref(intake, "id"),
                    "f_home_record_id": context("f_rch_id"),
                    "f_office_cd": ref(parse, "officeCode"),
                    "f_unlicenced_rch": False,
                },
                "appends": [],
            },
        },
    )
    link(api, processing, parse)
    link(api, parse, intake)
    link(api, intake, query_app)
    link(api, query_app, exists)
    link(api, exists, reuse, branch_index=1)
    link(api, exists, create_app, branch_index=0)
    attach_finish(api, workflow_id, parse, intake, reuse, reuse)
    attach_finish(api, workflow_id, parse, intake, create_app, create_app)


def build_update_graph(api: NocoBaseApi, workflow_id: int) -> None:
    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark update processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    processing["config"]["params"]["filter"] = {
        "$and": [
            {"id": {"$eq": context("id")}},
            {"f_status": {"$eq": "submitted"}},
        ]
    }
    api.update_node(int(processing["id"]), {"config": processing["config"]})
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged prosecution update body",
        parse_config(),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {"f_application_status": {"$eq": "Accepted"}},
            ],
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Prosecution",
        query_config(
            COLLECTION,
            [{"id": {"$eq": ref(original, "f_application_id")}}],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Prosecution exists",
        exists_config(application),
    )
    overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged update overlay",
        update_config(COLLECTION, ref(application, "id"), overlay_values(parse)),
    )
    offence_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Create offence charged items on update",
        {"target": ref(parse, "offenceItems"), "condition": False, "exit": 2},
    )
    create_offence = create_node(
        api,
        workflow_id,
        "create",
        "Create offence charged item on update",
        {
            "collection": "t_offence_charged_items",
            "params": {
                "values": {
                    "fk_offence_charged_items": ref(application, "id"),
                    "f_name_of_defendant": scope(offence_loop, "name_of_defendant"),
                    "f_name_of_defendant_chi": scope(
                        offence_loop, "name_of_defendant_chi"
                    ),
                    "f_type_of_defendant": scope(offence_loop, "type_of_defendant"),
                    "f_hkic_no": scope(offence_loop, "hkic_no"),
                    "f_offence_charged": scope(offence_loop, "offence_charged"),
                    "f_detail_of_offence": scope(offence_loop, "detail_of_offence"),
                    "f_pg_png": scope(offence_loop, "pg_png"),
                    "f_remark": scope(offence_loop, "remark"),
                },
                "appends": [],
            },
        },
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark update succeeded + backfill IDs",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(original, "f_intake_id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": ref(original, "f_rch_id"),
            },
        ),
    )
    link(api, processing, parse)
    link(api, parse, original)
    link(api, original, application)
    link(api, application, exists)
    link(api, exists, overlay, branch_index=1)
    link(api, overlay, offence_loop)
    link(api, offence_loop, create_offence, branch_index=0)
    link(api, offence_loop, succeeded)


def build_create_bridge(api: NocoBaseApi, workflow_id: int) -> None:
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {
                    "$or": [
                        {"f_application_id": {"$eq": context("id")}},
                        {"f_intake_id": {"$eq": context("fk_intake_form")}},
                    ]
                },
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    create_cmtf = create_node(
        api,
        workflow_id,
        "create",
        "Create CMTF prosecution staging at Accepted",
        {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": CREATE_API_TYPE,
                    "f_application_type": APPLICATION_TYPE,
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": context("f_office_cd"),
                    "f_intake_id": context("fk_intake_form"),
                    "f_application_id": context("id"),
                    "f_rch_id": context("fk_home_record_id"),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        },
    )
    link(api, staging, exists)
    link(api, exists, create_cmtf, branch_index=0)


def build_received_bridge(api: NocoBaseApi, workflow_id: int) -> None:
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Prosecution",
        query_config(COLLECTION, [{"fk_intake_form": {"$eq": context("id")}}]),
    )
    staging = create_node(
        api,
        workflow_id,
        "query",
        "Resolve existing CREATE staging",
        query_config(
            "t_api_request_staging",
            [
                {"f_intake_id": {"$eq": context("id")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
            ],
        ),
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "Existing CREATE staging exists",
        exists_config(staging),
    )
    update_existing = create_node(
        api,
        workflow_id,
        "update",
        "Publish Received on existing CREATE staging",
        update_config(
            "t_api_request_staging",
            ref(staging, "id"),
            {
                "f_application_status": "Received",
                "f_application_id": ref(application, "id"),
                "f_office_code": context("f_office_cd"),
            },
        ),
    )
    link(api, application, staging)
    link(api, staging, exists)
    link(api, exists, update_existing, branch_index=1)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=G")
    print("workflow_category=API Suorce")
    print(f"create_title={CREATE_TITLE}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    created_ids: list[int] = []
    try:
        ensure_application_type_enum(api)
        for title in (CREATE_TITLE, UPDATE_TITLE):
            require_absent(api, title)
        create_wf = create_workflow(
            api,
            title=CREATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("CREATE", CREATE_API_TYPE),
        )
        created_ids.append(int(create_wf["id"]))
        build_create_graph(api, int(create_wf["id"]))

        update_wf = create_workflow(
            api,
            title=UPDATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("UPDATE", UPDATE_API_TYPE),
        )
        created_ids.append(int(update_wf["id"]))
        build_update_graph(api, int(update_wf["id"]))

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            final = api.get_workflow(workflow_id)
            print(f"workflow_id={final.get('id')}")
            print(f"workflow_title={final.get('title')}")
            print(f"enabled={str(bool(final.get('enabled'))).lower()}")
            print(f"node_count={len(final.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
