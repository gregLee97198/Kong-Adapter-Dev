#!/usr/bin/env python3
"""Create Phase-H Expansion AIP staging workflows on NocoBase.

The native Expansion AIP workflow synchronously creates
``t_expansion_aip_for_licence`` when the Intake is created.  These API sidecar
workflows therefore reuse that one native record, overlay the explicitly
supported API fields, and only then execute the native Intake Submit subflow
as the business submitter and attach checklist uploads.

The command is dry-run by default.  It never edits the native AIP workflow.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    create_workflow,
    exists_config,
    link,
    list_existing,
    parse_variable,
    query_config,
    require_absent,
    set_enabled,
    update_config,
)
from create_nocobase_phase_e_sh_rp_workflows import (
    INTAKE_UPDATE_FIELD_MAP,
    add_checklist_graph,
    add_checklist_preflight_graph,
    add_deferred_received_finalizer,
    add_rejected_staging_claim_finalizer,
    atomic_claim_config,
    claim_result_script,
    field_references,
    processing_staging_update_config,
    scope,
    staging_failed_values,
    true_condition,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import (
    destroy_workflow_nodes,
    external_source_condition,
    revision_workflow,
)

INTAKE_TYPE_ID = 365214779310080
INTAKE_SUBMIT_WORKFLOW_KEY = "qdkj25b0793"
INTAKE_NATIVE_ACCEPT = "0"

COLLECTION = "t_expansion_aip_for_licence"
INTAKE_FK = "fk_intake_form"
HOME_FK = "fk_home_record_id"
CHECKLIST_USE_FOR = COLLECTION
CHECKLIST_LATEST_THROUGH = "t_m7xtadujokk"
CHECKLIST_LATEST_FOREIGN_KEY = "f_0d371a0nvmh"
APPLICATION_TYPE = "expansion_aip"
APPLICATION_LABEL = "Expansion AIP"
CREATE_API_TYPE = "create_intake_for_expansion_aip"
UPDATE_API_TYPE = "update_expansion_aip_data"
CREATE_TITLE = "API Request Staging — Create Expansion AIP v1"
UPDATE_TITLE = "API Request Staging — Update Expansion AIP v1"

RESOLVE_SUBMITTER_TITLE = "Resolve Expansion AIP business submitter"
APPLY_IDENTITY_TITLE = "Apply Expansion AIP submitter post to Intake"
LOAD_INTAKE_TITLE = "Load Expansion AIP Intake for native Submit"
SUBMIT_TITLE = "Run native Intake Form Submit for Expansion AIP"

AIP_PART_1_FIELD_MAP = {
    "title": "f_title",
    "name_chi": "f_name_chi",
    "name_eng": "f_name_eng",
    "authorised_to_apply_by_operator": "f_authorised_to_apply_by_operator",
    "means_of_authorisation": "f_means_of_authorisation",
    "authorised_name_eng": "f_authorised_name_eng",
    "hkic_number1": "f_hkic_number1",
    "hkic_number2": "f_hkic_number2",
}

AIP_PART_2_FIELD_MAP = {
    "address_chi_expansion": "f_address_chi_expansion",
    "address_eng_expansion": "f_address_eng_expansion",
    "tentative_licencing_capacity_expansion": (
        "f_tentative_licencing_capacity_expansion"
    ),
    "tentative_area_of_floor_space_expansion": (
        "f_existing_area_of_floor_space_expansion"
    ),
    "number_of_beds_expansion": "f_number_of_beds_expansion",
}

AIP_FIELD_MAP = {**AIP_PART_1_FIELD_MAP, **AIP_PART_2_FIELD_MAP}

BP: dict[str, Any] = {
    "key": "expansion_aip",
    "application_type": APPLICATION_TYPE,
    "application_label": APPLICATION_LABEL,
    "create_api_type": CREATE_API_TYPE,
    "update_api_type": UPDATE_API_TYPE,
    "intake_type_id": INTAKE_TYPE_ID,
    "collection": COLLECTION,
    "intake_fk": INTAKE_FK,
    "home_fk": HOME_FK,
    "checklist_use_for": CHECKLIST_USE_FOR,
}


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def parse_config() -> dict[str, Any]:
    """Describe only the fields consumed by the AIP sidecar workflows."""

    example = {
        "request_id": "AIP-20260924-0001",
        "create_id": "387900000000001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "lorche_d_no": "L0043",
                "received_date": "2026-09-24",
                "severity": "0",
                "source_id": 701,
                "source_other": "OP",
                "submitter_user_id": 12,
                "task_owner_user_id": 45,
                "task_owner_post_code": "S(LR)1",
            },
            "part_1": {
                "title": "0",
                "name_chi": "申請人",
                "name_eng": "Example Applicant",
                "authorised_to_apply_by_operator": True,
                "means_of_authorisation": "0",
                "authorised_name_eng": "Example Authorised Person",
                "hkic_number1": "A123456",
                "hkic_number2": "7",
            },
            "part_2": {
                "address_chi_expansion": "擴建地址",
                "address_eng_expansion": "Expansion address",
                "tentative_licencing_capacity_expansion": 20,
                "tentative_area_of_floor_space_expansion": 120.5,
                "number_of_beds_expansion": 20,
            },
            "part_3": {"checklist": []},
        },
    }
    variables = [
        parse_variable("form_data", "formData"),
        parse_variable("form_data.case_summary.office_code", "officeCode"),
        parse_variable("form_data.case_summary.lorche_d_no", "lorcheDNo"),
        parse_variable("form_data.case_summary.received_date", "receivedDate"),
        parse_variable("form_data.case_summary.severity", "severity"),
        parse_variable("form_data.case_summary.source_id", "sourceId"),
        parse_variable("form_data.case_summary.source_other", "sourceOther"),
        parse_variable(
            "form_data.case_summary.submitter_user_id", "submitterId"
        ),
        parse_variable(
            "form_data.case_summary.task_owner_user_id", "ownerId"
        ),
        parse_variable(
            "form_data.case_summary.task_owner_post_code", "ownerPost"
        ),
        *[
            parse_variable(f"form_data.part_1.{public_name}", public_name)
            for public_name in AIP_PART_1_FIELD_MAP
        ],
        *[
            parse_variable(f"form_data.part_2.{public_name}", public_name)
            for public_name in AIP_PART_2_FIELD_MAP
        ],
        parse_variable("form_data.part_3.checklist", "checklist"),
        parse_variable(
            "form_data.part_3.checklist[].position_code", "checklistPosition"
        ),
        parse_variable(
            "form_data.part_3.checklist[].attachment_id", "checklistAttachment"
        ),
        parse_variable("create_id", "createId"),
    ]
    return {
        "parseArray": False,
        "dataSource": context("f_request_body"),
        "example": example,
        "variables": variables,
    }


def create_overlay_values(parse: Mapping[str, Any]) -> dict[str, Any]:
    """Overlay writable API fields without copying Home-derived display data."""

    return {
        **{
            native_name: ref(parse, public_name)
            for public_name, native_name in AIP_FIELD_MAP.items()
        },
    }


def native_candidate_script() -> str:
    """Select one native row and reject both missing and duplicate records."""

    return """const values = Array.isArray(rows) ? rows : [];
return {
  exactly_one: values.length === 1,
  application: values.length === 1 ? values[0] : null,
  count: values.length,
};"""


def guarded_patch_script() -> str:
    """Preserve every omitted AIP and Intake field during partial Update."""

    part_1_map = json.dumps(AIP_PART_1_FIELD_MAP, ensure_ascii=False)
    part_2_map = json.dumps(AIP_PART_2_FIELD_MAP, ensure_ascii=False)
    intake_map = json.dumps(INTAKE_UPDATE_FIELD_MAP, ensure_ascii=False)
    return f"""const form = formData || {{}};
const summary = form.case_summary || {{}};
const part1 = form.part_1 || {{}};
const part2 = form.part_2 || {{}};
const part3 = form.part_3 || {{}};
const current = application || {{}};
const currentIntake = intake || {{}};
const own = (value, key) => value
  && Object.prototype.hasOwnProperty.call(value, key);
const patch = {{}};
const intakePatch = {{}};
const part1Map = {part_1_map};
const part2Map = {part_2_map};
const intakeMap = {intake_map};
for (const [external, internal] of Object.entries(part1Map)) {{
  patch[internal] = own(part1, external) ? part1[external] : current[internal];
}}
for (const [external, internal] of Object.entries(part2Map)) {{
  patch[internal] = own(part2, external) ? part2[external] : current[internal];
}}
for (const [external, internal] of Object.entries(intakeMap)) {{
  intakePatch[internal] = own(summary, external)
    ? summary[external] : currentIntake[internal];
}}
return {{
  patch,
  intake_patch: intakePatch,
  checklist_replacement_requested: own(part3, 'checklist'),
}};"""


def add_checklist_replacement_reset(
    api: NocoBaseApi,
    workflow_id: int,
    application: Mapping[str, Any],
    project: Mapping[str, Any],
    upstream: Mapping[str, Any],
    unchanged_target: Mapping[str, Any],
) -> Mapping[str, Any]:
    """Clear only Checklist Latest state before applying an explicit replacement.

    Details rows are immutable upload history and must remain available.  An
    omitted checklist bypasses this branch, while an explicit empty array
    clears every currently selected item.
    """

    existing = create_node(
        api,
        workflow_id,
        "query",
        "Load existing Expansion AIP Checklist items",
        query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"f_business_type": {"$eq": COLLECTION}},
            ],
            multiple=True,
        ),
    )
    selected = create_node(
        api,
        workflow_id,
        "script",
        "Select Expansion AIP Checklist items to reset",
        {
            "arguments": [
                {
                    "name": "replacementRequested",
                    "value": ref(project, "checklist_replacement_requested"),
                },
                {"name": "rows", "value": ref(existing)},
            ],
            "content": (
                "return {items: replacementRequested && Array.isArray(rows) "
                "? rows : []};"
            ),
            "timeout": 3000,
            "continue": False,
        },
    )
    loop = create_node(
        api,
        workflow_id,
        "loop",
        "Reset existing Expansion AIP Checklist Latest",
        {"target": ref(selected, "items"), "condition": False, "exit": 2},
    )
    reset = create_node(
        api,
        workflow_id,
        "update",
        "Clear existing Expansion AIP Checklist Latest item",
        update_config(
            "t_document_submitted_for_application",
            scope(loop, "id"),
            {
                "f_is_checked": False,
                # NocoBase treats [] as "leave many-to-many relation as-is" in
                # workflow update nodes.  null explicitly unlinks Latest while
                # preserving immutable Details history.
                "f_lastest_files": None,
                "f_lastest_files_name": None,
                "f_lastest_file_date": None,
            },
        ),
    )
    reset["config"]["params"]["individualHooks"] = True
    unlink = create_node(
        api,
        workflow_id,
        "sql",
        "Unlink existing Expansion AIP Checklist Latest files",
        {
            "dataSource": "main",
            "sql": (
                f'DELETE FROM "{CHECKLIST_LATEST_THROUGH}" '
                f'WHERE "{CHECKLIST_LATEST_FOREIGN_KEY}"=:checklistItemId '
                f'RETURNING "{CHECKLIST_LATEST_FOREIGN_KEY}";'
            ),
            "variables": [
                {"name": "checklistItemId", "value": scope(loop, "id")},
            ],
            "withMeta": False,
            "unsafeInjection": False,
        },
    )

    link(api, upstream, existing, branch_index=1)
    link(api, existing, selected)
    link(api, selected, loop)
    link(api, loop, reset, branch_index=0)
    link(api, reset, unlink)
    link(api, loop, unchanged_target)
    return loop


def ensure_application_type_enum(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
    )
    if not isinstance(field, dict):
        raise ApiError("f_application_type was not found")
    ui_schema = dict(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    matching = [item for item in options if item.get("value") == APPLICATION_TYPE]
    if len(matching) > 1:
        raise ApiError(f"duplicate f_application_type enum {APPLICATION_TYPE!r}")
    if matching:
        print(f"existing_enum=f_application_type.{APPLICATION_TYPE}")
        return
    options.append({"value": APPLICATION_TYPE, "label": APPLICATION_LABEL})
    ui_schema["enum"] = options
    api.request(
        "POST",
        "/api/collections/t_api_request_staging/fields:update?"
        + urllib.parse.urlencode({"filterByTk": "f_application_type"}),
        {"uiSchema": ui_schema},
    )
    print(f"updated_enum=f_application_type.{APPLICATION_TYPE}")


def validate_checklist_latest_relation(api: NocoBaseApi) -> None:
    """Fail closed if the hidden attachment join schema has drifted."""

    field = api.request(
        "GET",
        "/api/collections/t_document_submitted_for_application/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_lastest_files"}),
    )
    expected = (CHECKLIST_LATEST_THROUGH, CHECKLIST_LATEST_FOREIGN_KEY)
    actual = (
        field.get("through") if isinstance(field, dict) else None,
        field.get("foreignKey") if isinstance(field, dict) else None,
    )
    if actual != expected:
        raise ApiError(
            "Checklist Latest relation metadata changed: "
            f"expected {expected!r}, got {actual!r}"
        )
    print(
        "validated_relation="
        f"{CHECKLIST_LATEST_THROUGH}.{CHECKLIST_LATEST_FOREIGN_KEY}"
    )


def _add_submitter_failure(
    api: NocoBaseApi,
    workflow_id: int,
    guard: Mapping[str, Any],
) -> Mapping[str, Any]:
    failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Expansion AIP submitter resolution failed",
        processing_staging_update_config(
            staging_failed_values("business_submitter_not_resolved")
        ),
    )
    link(api, guard, failed, branch_index=0)
    return failed


def build_create_graph(api: NocoBaseApi, workflow_id: int) -> None:
    idempotency = create_node(
        api,
        workflow_id,
        "script",
        "Reject Expansion AIP Create row with existing business IDs",
        {
            "arguments": [
                {"name": "intakeId", "value": context("f_intake_id")},
                {"name": "applicationId", "value": context("f_application_id")},
            ],
            "content": "return {eligible: !intakeId && !applicationId};",
            "timeout": 3000,
            "continue": False,
        },
    )
    eligible = create_node(
        api,
        workflow_id,
        "condition",
        "Expansion AIP Create row has no prior business IDs",
        true_condition(ref(idempotency, "eligible")),
    )
    claim_sql = create_node(
        api,
        workflow_id,
        "sql",
        "Atomically claim submitted Expansion AIP Create row",
        atomic_claim_config(),
    )
    claim_result = create_node(
        api,
        workflow_id,
        "script",
        "Inspect Expansion AIP Create claim result",
        {
            "arguments": [{"name": "rows", "value": ref(claim_sql)}],
            "content": claim_result_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    claimed = create_node(
        api,
        workflow_id,
        "condition",
        "Expansion AIP Create claim returned one row",
        true_condition(ref(claim_result, "claimed")),
    )
    add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claimed,
        title_prefix="Expansion AIP Create",
        reason="create_claim_rejected",
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged Expansion AIP request body",
        parse_config(),
    )
    home = create_node(
        api,
        workflow_id,
        "query",
        "Resolve Expansion AIP Home Record",
        query_config(
            "t_home_record",
            [{"id": {"$eq": context("f_rch_id")}}],
        ),
    )
    home_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Expansion AIP Home Record exists",
        exists_config(home, reject_on_false=False),
    )
    home_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Expansion AIP Home Record resolution failed",
        processing_staging_update_config(
            staging_failed_values("resolved_home_record_not_found")
        ),
    )
    submitter = create_node(
        api,
        workflow_id,
        "query",
        RESOLVE_SUBMITTER_TITLE,
        query_config(
            "users",
            [{"id": {"$eq": ref(parse, "submitterId")}}],
            appends=("f_posts_code",),
        ),
    )
    submitter_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Expansion AIP business submitter exists",
        exists_config(submitter, reject_on_false=False),
    )
    submitter_failed = _add_submitter_failure(api, workflow_id, submitter_exists)
    intake = create_node(
        api,
        workflow_id,
        "create",
        "Create Expansion AIP Intake (fixed type + Home Record)",
        {
            "collection": "t_intake_form",
            "params": {
                "values": {
                    "fk_intake_type": INTAKE_TYPE_ID,
                    "fk_intake_source_rch": context("f_rch_id"),
                    "fk_task_owner_post": ref(parse, "ownerPost"),
                    "fk_intake_source": ref(parse, "sourceId"),
                    "fk_task_owner": ref(parse, "ownerId"),
                    "f_severity": ref(parse, "severity"),
                    "f_received_date": ref(parse, "receivedDate"),
                    "f_source_other": ref(parse, "sourceOther"),
                    "f_office_cd": ref(parse, "officeCode"),
                    "f_subject": ref(home, "f_rch_no"),
                    "f_intake_accept_reject": INTAKE_NATIVE_ACCEPT,
                    "f_api_create_staging_id": context("id"),
                    "createdBy": ref(submitter, "id"),
                },
                "appends": [],
            },
        },
    )
    identity = create_node(
        api,
        workflow_id,
        "update",
        APPLY_IDENTITY_TITLE,
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            {
                "fk_created_by_post": ref(
                    submitter, "f_posts_code.f_post_cd"
                ),
                "createdBy": ref(submitter, "id"),
            },
        ),
    )
    early_backfill = create_node(
        api,
        workflow_id,
        "update",
        "Backfill Expansion AIP Intake ID before native Submit",
        processing_staging_update_config({"f_intake_id": ref(intake, "id")}),
    )
    application_candidates = create_node(
        api,
        workflow_id,
        "query",
        "Find native-created Expansion AIP candidates",
        query_config(
            COLLECTION,
            [{INTAKE_FK: {"$eq": ref(intake, "id")}}],
            multiple=True,
        ),
    )
    select_application = create_node(
        api,
        workflow_id,
        "script",
        "Require exactly one native-created Expansion AIP",
        {
            "arguments": [
                {"name": "rows", "value": ref(application_candidates)}
            ],
            "content": native_candidate_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    exactly_one_application = create_node(
        api,
        workflow_id,
        "condition",
        "Exactly one native-created Expansion AIP exists",
        true_condition(ref(select_application, "exactly_one")),
    )
    candidate_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark native Expansion AIP candidate count failure",
        processing_staging_update_config(
            staging_failed_values(
                "native_application_count_not_one",
                intake_id=ref(intake, "id"),
            )
        ),
    )
    overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged Expansion AIP overlay",
        update_config(
            COLLECTION,
            ref(select_application, "application.id"),
            create_overlay_values(parse),
        ),
    )
    load_intake = create_node(
        api,
        workflow_id,
        "query",
        LOAD_INTAKE_TITLE,
        query_config(
            "t_intake_form",
            [{"id": {"$eq": ref(intake, "id")}}],
            appends=(
                "f_task_owner_post",
                "f_task_owner_post.parent",
                "f_intake_type",
            ),
        ),
    )
    native_submit = create_node(
        api,
        workflow_id,
        "subflow",
        SUBMIT_TITLE,
        {
            "workflow": INTAKE_SUBMIT_WORKFLOW_KEY,
            "context": {
                "data": ref(load_intake),
                "userId": ref(submitter, "id"),
                "roleName": None,
            },
        },
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Reload native Expansion AIP after native Submit",
        query_config(
            COLLECTION,
            [
                {
                    "id": {
                        "$eq": ref(select_application, "application.id")
                    }
                },
                {INTAKE_FK: {"$eq": ref(intake, "id")}},
            ],
        ),
    )
    application_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Same native Expansion AIP exists after Submit",
        exists_config(application, reject_on_false=False),
    )
    application_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark native Expansion AIP reload failed",
        processing_staging_update_config(
            staging_failed_values(
                "native_application_not_reloaded_after_submit",
                intake_id=ref(intake, "id"),
            )
        ),
    )
    application_ready = create_node(
        api,
        workflow_id,
        "script",
        "Expansion AIP read-back ready for Checklist",
        {
            "arguments": [],
            "content": "return true;",
            "timeout": 3000,
            "continue": False,
        },
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark Expansion AIP Create succeeded + backfill IDs",
        processing_staging_update_config(
            {
                "f_status": "succeeded",
                "f_intake_id": ref(intake, "id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": context("f_rch_id"),
            }
        ),
    )

    link(api, idempotency, eligible)
    link(api, eligible, claim_sql, branch_index=1)
    link(api, claim_sql, claim_result)
    link(api, claim_result, claimed)
    link(api, claimed, parse, branch_index=1)
    link(api, parse, home)
    link(api, home, home_exists)
    link(api, home_exists, home_failed, branch_index=0)
    link(api, home_exists, submitter, branch_index=1)
    link(api, submitter, submitter_exists)
    link(api, submitter_exists, intake, branch_index=1)
    link(api, intake, identity)
    link(api, identity, early_backfill)
    link(api, early_backfill, application_candidates)
    link(api, application_candidates, select_application)
    link(api, select_application, exactly_one_application)
    link(api, exactly_one_application, candidate_failed, branch_index=0)
    link(api, exactly_one_application, overlay, branch_index=1)
    link(api, overlay, load_intake)
    link(api, load_intake, native_submit)
    link(api, native_submit, application)
    link(api, application, application_exists)
    link(api, application_exists, application_failed, branch_index=0)
    link(api, application_exists, application_ready, branch_index=1)
    checklist_ok = add_checklist_graph(
        api,
        workflow_id,
        BP,
        parse,
        application,
        application_ready,
    )
    link(api, checklist_ok, succeeded, branch_index=1)

    # Keep local names alive for graph readers and make the intentional
    # terminal failure branches explicit.
    _ = (
        submitter_failed,
        home_failed,
        candidate_failed,
        application_failed,
    )


def build_update_graph(api: NocoBaseApi, workflow_id: int) -> None:
    claim_sql = create_node(
        api,
        workflow_id,
        "sql",
        "Atomically claim submitted Expansion AIP Update row",
        atomic_claim_config(require_ready_parent=True),
    )
    claim_result = create_node(
        api,
        workflow_id,
        "script",
        "Inspect Expansion AIP Update claim result",
        {
            "arguments": [{"name": "rows", "value": ref(claim_sql)}],
            "content": claim_result_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    claimed = create_node(
        api,
        workflow_id,
        "condition",
        "Expansion AIP Update claim returned one row",
        true_condition(ref(claim_result, "claimed")),
    )
    rejected = add_rejected_staging_claim_finalizer(
        api,
        workflow_id,
        claimed,
        title_prefix="Expansion AIP Update",
        reason="update_claim_rejected",
    )
    add_deferred_received_finalizer(
        api,
        workflow_id,
        rejected,
        BP,
        "rejected Expansion AIP Update claim",
        branch_index=1,
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse staged Expansion AIP update body",
        parse_config(),
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original Expansion AIP CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createId")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_application_type": {"$eq": APPLICATION_TYPE}},
                {"f_status": {"$eq": "succeeded"}},
                {"f_application_status": {"$eq": "Accepted"}},
                {"f_intake_id": {"$notEmpty": True}},
                {"f_application_id": {"$notEmpty": True}},
            ],
        ),
    )
    original_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Accepted Expansion AIP parent CREATE exists",
        exists_config(original, reject_on_false=False),
    )
    original_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark Expansion AIP Update parent or lock failure",
        processing_staging_update_config(
            staging_failed_values("update_parent_not_accepted_or_not_found")
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Expansion AIP Intake",
        query_config(
            "t_intake_form",
            [{"id": {"$eq": ref(original, "f_intake_id")}}],
        ),
    )
    intake_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Expansion AIP Intake exists",
        exists_config(intake, reject_on_false=False),
    )
    intake_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Expansion AIP Intake failure",
        processing_staging_update_config(
            staging_failed_values(
                "linked_intake_not_resolved",
                intake_id=ref(original, "f_intake_id"),
            )
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Resolve linked Expansion AIP application",
        query_config(
            COLLECTION,
            [{"id": {"$eq": ref(original, "f_application_id")}}],
        ),
    )
    application_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Linked Expansion AIP application exists",
        exists_config(application, reject_on_false=False),
    )
    application_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark linked Expansion AIP application failure",
        processing_staging_update_config(
            staging_failed_values(
                "linked_application_not_resolved",
                intake_id=ref(original, "f_intake_id"),
            )
        ),
    )
    project = create_node(
        api,
        workflow_id,
        "script",
        "Project guarded Expansion AIP update patch",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "application", "value": ref(application)},
                {"name": "intake", "value": ref(intake)},
            ],
            "content": guarded_patch_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    apply_intake = create_node(
        api,
        workflow_id,
        "update",
        "Apply guarded Expansion AIP Intake update",
        update_config(
            "t_intake_form",
            ref(intake, "id"),
            field_references(
                project,
                "intake_patch",
                sorted(INTAKE_UPDATE_FIELD_MAP.values()),
            ),
        ),
    )
    apply_overlay = create_node(
        api,
        workflow_id,
        "update",
        "Apply staged Expansion AIP update overlay",
        update_config(
            COLLECTION,
            ref(application, "id"),
            field_references(
                project,
                "patch",
                sorted(AIP_FIELD_MAP.values()),
            ),
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark Expansion AIP Update succeeded + backfill IDs",
        processing_staging_update_config(
            {
                "f_status": "succeeded",
                "f_intake_id": ref(original, "f_intake_id"),
                "f_application_id": ref(application, "id"),
                "f_rch_id": ref(original, "f_rch_id"),
                "f_parent_create_id": ref(original, "id"),
            }
        ),
    )

    link(api, claim_sql, claim_result)
    link(api, claim_result, claimed)
    link(api, claimed, parse, branch_index=1)
    link(api, parse, original)
    link(api, original, original_exists)
    link(api, original_exists, original_failed, branch_index=0)
    link(api, original_exists, intake, branch_index=1)
    link(api, intake, intake_exists)
    link(api, intake_exists, intake_failed, branch_index=0)
    link(api, intake_exists, application, branch_index=1)
    link(api, application, application_exists)
    link(api, application_exists, application_failed, branch_index=0)
    link(api, application_exists, project, branch_index=1)

    checklist_preflight = add_checklist_preflight_graph(
        api,
        workflow_id,
        BP,
        parse,
        application,
        project,
    )
    add_deferred_received_finalizer(
        api,
        workflow_id,
        checklist_preflight,
        BP,
        "Expansion AIP Checklist preflight failure",
        branch_index=0,
    )
    add_checklist_replacement_reset(
        api,
        workflow_id,
        application,
        project,
        checklist_preflight,
        apply_intake,
    )
    link(api, apply_intake, apply_overlay)
    checklist_ok = add_checklist_graph(
        api,
        workflow_id,
        BP,
        parse,
        application,
        apply_overlay,
    )
    link(api, checklist_ok, succeeded, branch_index=1)
    add_deferred_received_finalizer(
        api,
        workflow_id,
        checklist_ok,
        BP,
        "Expansion AIP Checklist commit failure",
        branch_index=0,
    )
    add_deferred_received_finalizer(
        api,
        workflow_id,
        succeeded,
        BP,
        "successful Expansion AIP Update",
    )
    for index, failure in enumerate(
        (original_failed, intake_failed, application_failed),
        start=1,
    ):
        add_deferred_received_finalizer(
            api,
            workflow_id,
            failure,
            BP,
            f"Expansion AIP terminal failure {index}",
        )


def revise_update_workflow(
    api: RootNocoBaseApi,
    backup_dir: Path,
) -> dict[str, Any]:
    """Install an editable revision while preserving the prior workflow."""

    enabled = [row for row in list_existing(api, UPDATE_TITLE) if row.get("enabled")]
    if len(enabled) != 1:
        raise ApiError(
            f"Expected one enabled workflow titled {UPDATE_TITLE!r}, "
            f"found {len(enabled)}"
        )
    source = api.get_workflow(int(enabled[0]["id"]))
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_path = backup_dir / f"expansion-aip-update-before-{stamp}.json"
    backup_path.write_text(
        json.dumps(source, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"backup={backup_path}")

    draft: dict[str, Any] | None = None
    try:
        draft = revision_workflow(api, int(source["id"]))
        destroy_workflow_nodes(api, draft)
        build_update_graph(api, int(draft["id"]))
        set_enabled(api, int(draft["id"]), True)
        installed = api.get_workflow(int(draft["id"]))
        if not installed.get("enabled"):
            raise ApiError("Expansion AIP Update revision did not enable")
        print(f"replaced_workflow_id={source['id']}")
        print(f"workflow_id={installed['id']}")
        print(f"workflow_title={installed.get('title')}")
        print(f"enabled={str(bool(installed.get('enabled'))).lower()}")
        print(f"node_count={len(installed.get('nodes') or [])}")
        return installed
    except Exception:
        if draft is not None:
            try:
                set_enabled(api, int(draft["id"]), False)
            except Exception:
                pass
            try:
                partial = api.get_workflow(int(draft["id"]))
                if not partial.get("enabled") and not partial.get("executed"):
                    api.request(
                        "POST",
                        "/api/workflows:destroy?"
                        + urllib.parse.urlencode(
                            {"filterByTk": str(partial["id"])}
                        ),
                        {},
                    )
            except Exception:
                pass
        try:
            set_enabled(api, int(source["id"]), True)
        except Exception:
            pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument(
        "--revise-update",
        action="store_true",
        help="revise the enabled Update workflow and preserve its prior revision",
    )
    parser.add_argument(
        "--backup-dir",
        type=Path,
        default=Path("/tmp/kong-nocoadapter-workflow-backups"),
    )
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=H")
    print("workflow_category=API Suorce")
    print(f"create_title={CREATE_TITLE}")
    print(f"update_title={UPDATE_TITLE}")
    print(f"intake_submit_workflow_key={INTAKE_SUBMIT_WORKFLOW_KEY}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = RootNocoBaseApi(args.base_url, token)
    validate_checklist_latest_relation(api)
    if args.revise_update:
        revise_update_workflow(api, args.backup_dir)
        print("mode=applied-update-revision")
        return 0
    created_ids: list[int] = []
    try:
        ensure_application_type_enum(api)
        for title in (CREATE_TITLE, UPDATE_TITLE):
            require_absent(api, title)

        create_workflow_row = create_workflow(
            api,
            title=CREATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("CREATE", CREATE_API_TYPE),
        )
        created_ids.append(int(create_workflow_row["id"]))
        build_create_graph(api, int(create_workflow_row["id"]))

        update_workflow_row = create_workflow(
            api,
            title=UPDATE_TITLE,
            collection="t_api_request_staging",
            mode=1,
            condition=external_source_condition("UPDATE", UPDATE_API_TYPE),
        )
        created_ids.append(int(update_workflow_row["id"]))
        build_update_graph(api, int(update_workflow_row["id"]))

        for workflow_id in created_ids:
            set_enabled(api, workflow_id, True)
            workflow = api.get_workflow(workflow_id)
            print(f"workflow_id={workflow.get('id')}")
            print(f"workflow_title={workflow.get('title')}")
            print(f"enabled={str(bool(workflow.get('enabled'))).lower()}")
            print(f"node_count={len(workflow.get('nodes') or [])}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in created_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
