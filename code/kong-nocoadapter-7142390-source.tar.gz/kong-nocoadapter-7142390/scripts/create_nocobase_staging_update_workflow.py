#!/usr/bin/env python3
"""Create the 181 staging workflow for update_new_licence_data.

The workflow is deliberately separate from the CREATE dispatcher.  It resolves
the original successful CREATE staging record by ``create_id`` and updates the
linked Intake, NLA and main address without running Intake Submit again and
without writing either business status field.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections.abc import Mapping
from typing import Any

from extend_nocobase_staging_relations import (
    ADDRESS_FIELDS,
    CHECKLIST_SPECIAL_NAMES,
    CONTACT_FIELDS,
    PREMISE_FIELDS,
    ApiError,
    NocoBaseApi,
    attach_api_source_category,
)

TITLE = "API Request Staging — Update New Licence Data v5"
SOURCE_SYSTEM = "OP"
UPDATE_API_TYPE = "update_new_licence_data"
CREATE_API_TYPE = "create_intake_for_new_licence"


def ref(node: Mapping[str, Any], field: str | None = None) -> str:
    suffix = f".{field}" if field else ""
    return "{{$jobsMapByNodeKey." + str(node["key"]) + suffix + "}}"


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def scope(node: Mapping[str, Any], field: str) -> str:
    return "{{$scopes." + str(node["key"]) + ".item." + field + "}}"


def update_config(
    collection: str,
    record_id: str,
    values: Any,
    *,
    individual_hooks: bool = False,
) -> dict[str, Any]:
    return {
        "collection": collection,
        "params": {
            "filter": {"$and": [{"id": {"$eq": record_id}}]},
            "values": values,
            "individualHooks": individual_hooks,
        },
    }


def query_config(
    collection: str,
    filters: list[dict[str, Any]],
    *,
    multiple: bool = False,
    appends: tuple[str, ...] = (),
) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": multiple,
        "params": {
            "filter": {"$and": filters},
            "sort": [],
            "page": 1,
            "pageSize": 500 if multiple else 1,
            "appends": list(appends),
        },
    }


def patch_script() -> str:
    intake_map = {
        "office_code": "f_office_cd",
        "received_date": "f_received_date",
        "severity": "f_severity",
        "source_id": "fk_intake_source",
        "source_other": "f_source_other",
        "task_owner_user_id": "fk_task_owner",
        "task_owner_post_code": "fk_task_owner_post",
    }
    nla_part1_map = {
        "application_received_date": "f_application_received_date",
        "application_type": "f_app_type",
        "tentative_commencement_date": "f_tentative_service_commencement_date",
    }
    nla_part2_map = {
        "rch_name_en": "f_rch_name_en",
        "rch_name_cn": "f_rch_name_cn",
        "operation_mode_id": "fk_rch_nature",
        "premises_type": "f_rch_premises",
        "monthly_fee_min": "f_monthly_fee_per_resident_min",
        "monthly_fee_max": "f_monthly_fee_per_resident_max",
        "gender": "f_rch_gender",
        "floor_area_sqm": "f_net_floor_area_sqm",
        "licence_capacity": "f_licence_capacity",
        "telephone_no": "f_telephone_no",
        "fax_no": "f_fax_no",
        "email": "f_email",
        "floors_total": "f_floors_total",
        "units_total": "f_units_total",
        "operation_mode_other": "f_rch_nature_other",
        "is_rcsv": "f_is_rcsv",
        "complies_lease_dmc": "f_complies_lease_dmc",
        "complies_lease_dmc_other": "f_complies_lease_dmc_other",
        "nursing_home_places": "f_beds_nursing",
        "care_and_attention_home_places": "f_beds_care_and_attention",
        "aged_home_places": "f_beds_meal",
        "self_care_hostel_places": "f_beds_self_care",
        "max_capacity": "f_max_capacity",
        "existing_capacity": "f_existing_capacity",
        "enrolment_residents": "f_enrolment_residents",
    }
    nla_part3_map = {
        "rch_business_status": "f_service_type",
        "applicant_operator_type": "f_business_ownership_type",
        "date_of_operation": "f_date_of_operation",
        "signature_date": "f_signature_date",
    }
    nla_part5_map = {
        "application_level": "f_application_level",
        "comments": "f_comments",
        "other_information": "f_other_information",
        "remarks": "f_remarks",
        "attachment_ids": "f_attachments_of_rchs",
    }
    address_map = {
        "full_name_en": "f_fullname_en",
        "full_name_cn": "f_fullname_cn",
        "lot_or_address_en": "f_lot_or_address_en",
        "lot_or_address_cn": "f_lot_or_address_cn",
        "block_no_en": "f_block_no_en",
        "block_no_cn": "f_block_no_cn",
        "block_type_en": "f_block_type_en",
        "block_type_cn": "f_block_type_cn",
        "floor_en": "f_floor_num_en",
        "floor_cn": "f_floor_num_cn",
        "unit_no_en": "f_unit_no_en",
        "unit_no_cn": "f_unit_no_cn",
        "unit_type_en": "f_unit_type_en",
        "unit_type_cn": "f_unit_type_cn",
        "building_name_en": "f_building_name_en",
        "building_name_cn": "f_building_name_cn",
        "estate_or_village_en": "f_estate_or_village_name_en",
        "estate_or_village_cn": "f_estate_or_village_name_cn",
        "street_no_en": "f_street_no_en",
        "street_no_cn": "f_street_no_cn",
        "street_name_en": "f_street_name_en",
        "street_name_cn": "f_street_name_cn",
        "phase_en": "f_phase_en",
        "phase_cn": "f_phase_cn",
    }
    replacements = {
        "__INTAKE_MAP__": json.dumps(intake_map, ensure_ascii=False),
        "__NLA_PART1_MAP__": json.dumps(nla_part1_map, ensure_ascii=False),
        "__NLA_PART2_MAP__": json.dumps(nla_part2_map, ensure_ascii=False),
        "__NLA_PART3_MAP__": json.dumps(nla_part3_map, ensure_ascii=False),
        "__NLA_PART5_MAP__": json.dumps(nla_part5_map, ensure_ascii=False),
        "__ADDRESS_MAP__": json.dumps(address_map, ensure_ascii=False),
        "__CONTACT_MAP__": json.dumps(CONTACT_FIELDS, ensure_ascii=False),
        "__PREMISE_MAP__": json.dumps(PREMISE_FIELDS, ensure_ascii=False),
        "__CHECKLIST_SPECIAL_NAMES__": json.dumps(
            CHECKLIST_SPECIAL_NAMES,
            ensure_ascii=False,
        ),
    }
    script = """const f = formData || {};
const currentIntake = intake || {};
const current = application || {};
const currentAddress = mainAddress || {};
const contactRows = Array.isArray(contacts) ? contacts : [];
const premiseRows = Array.isArray(premises) ? premises : [];
const checklistRows = Array.isArray(checklistSubmissions)
  ? checklistSubmissions : [];
const checklistTemplateRows = Array.isArray(checklistTemplates)
  ? checklistTemplates : [];
const addressRows = Array.isArray(addressOptions) ? addressOptions : [];
const own = (value, key) => value && Object.prototype.hasOwnProperty.call(value, key);
const assign = (target, source, mapping) => {
  for (const [external, internal] of Object.entries(mapping)) {
    if (own(source, external)) target[internal] = source[external];
  }
};
const currentValues = (source, fields) => Object.fromEntries(
  fields.map((field) => [field, own(source, field) ? source[field] : null]));
const addressPatchFor = (currentValue, incoming) => {
  const patch = currentValues(currentValue || {}, [
    ...Object.values(__ADDRESS_MAP__),
    'fk_region_en', 'fk_region_cn',
    'fk_district_name_en', 'fk_district_name_cn',
    'fk_sub_district_en', 'fk_sub_district_cn',
  ]);
  if (!incoming) return patch;
  assign(patch, incoming, __ADDRESS_MAP__);
  if (own(incoming, 'region_code')) {
    const byCode = new Map(addressRows.map((row) => [String(row.f_code), row]));
    const region = byCode.get(String(incoming.region_code));
    const district = byCode.get(String(incoming.district_code));
    const subDistrict = byCode.get(String(incoming.sub_district_code));
    if (!region || !district || !subDistrict
        || String(district.parentId) !== String(region.id)
        || String(subDistrict.parentId) !== String(district.id)) {
      throw new Error('Invalid Region/District/Sub-district code hierarchy');
    }
    patch.fk_region_en = region.f_name_en;
    patch.fk_region_cn = region.f_name_cn;
    patch.fk_district_name_en = district.f_name_en;
    patch.fk_district_name_cn = district.f_name_cn;
    patch.fk_sub_district_en = subDistrict.f_name_en;
    patch.fk_sub_district_cn = subDistrict.f_name_cn;
  }
  return patch;
};
const intakePatch = currentValues(currentIntake, [
  ...Object.values(__INTAKE_MAP__), 'f_subject', 'f_comments']);
const nlaPatch = currentValues(current, [
  ...Object.values(__NLA_PART1_MAP__),
  ...Object.values(__NLA_PART2_MAP__),
  ...Object.values(__NLA_PART3_MAP__),
  ...Object.values(__NLA_PART5_MAP__),
  'fk_type_of_rch',
  'f_beds_total',
]);
const addressPatch = addressPatchFor(currentAddress, (f.part_2 || {}).address);
const summary = f.case_summary || {};
const p1 = f.part_1 || {};
const p2 = f.part_2 || {};
const p3 = f.part_3 || {};
const p4 = f.part_4 || {};
const p5 = f.part_5 || {};
assign(intakePatch, summary, __INTAKE_MAP__);
assign(nlaPatch, p1, __NLA_PART1_MAP__);
assign(nlaPatch, p2, __NLA_PART2_MAP__);
assign(nlaPatch, p3, __NLA_PART3_MAP__);
assign(nlaPatch, p5, __NLA_PART5_MAP__);
if (!own(p5, 'attachment_ids')) {
  nlaPatch.f_attachments_of_rchs = Array.isArray(current.f_attachments_of_rchs)
    ? current.f_attachments_of_rchs.map((value) => value && value.id ? value.id : value)
    : [];
}
if (own(p2, 'rch_name_en')) intakePatch.f_subject = p2.rch_name_en;
if (own(p5, 'comments')) intakePatch.f_comments = p5.comments;
if (own(p2, 'rch_type_code')) {
  const rows = Array.isArray(rchTypeOptions) ? rchTypeOptions : [];
  const found = rows.find((row) => String(row.f_code) === String(p2.rch_type_code)
    && String(row.f_for_office) === String(summary.office_code || current.f_office_cd));
  if (!found) throw new Error('Unknown rch_type_code for office_code');
  nlaPatch.fk_type_of_rch = found.id;
}
const bedFields = [
  ['nursing_home_places', 'f_beds_nursing'],
  ['care_and_attention_home_places', 'f_beds_care_and_attention'],
  ['aged_home_places', 'f_beds_meal'],
  ['self_care_hostel_places', 'f_beds_self_care'],
];
if (bedFields.some(([external]) => own(p2, external))) {
  nlaPatch.f_beds_total = bedFields.reduce((total, [external, internal]) =>
    total + Number(own(p2, external) ? p2[external] : (current[internal] || 0)), 0);
}
const contactUpdates = [];
const contactUpdate = (incoming, relationField, label) => {
  if (!incoming) return;
  const requestedId = own(incoming, 'id') ? String(incoming.id) : '';
  const row = contactRows.find((value) =>
    String(value && value[relationField]) === String(current.id)
    && (!requestedId || String(value.id) === requestedId));
  if (!row) throw new Error('Unknown ' + label + ' contact id for this NLA');
  const patch = currentValues(row, Object.values(__CONTACT_MAP__));
  assign(patch, incoming, __CONTACT_MAP__);
  const currentContactAddress = row.f_address_correspondence || {};
  contactUpdates.push({
    id: row.id,
    address_id: row.fk_address_correspondence || 0,
    contact_patch: patch,
    address_patch: addressPatchFor(currentContactAddress, incoming.address),
  });
};
contactUpdate(p3.operator, 'fk_licence_contact_operator', 'operator');
contactUpdate(p3.company, 'fk_licence_contact_company', 'company');
contactUpdate(p4.authorised_representative,
  'fk_licence_contact_applicant', 'authorised representative');
if (Array.isArray(p3.personnel)) {
  for (const person of p3.personnel) {
    contactUpdate(person, 'fk_licence_contact_person', 'personnel');
  }
}
const premiseUpdates = [];
const premiseUpdate = (incoming, addressField, label) => {
  const candidates = premiseRows.filter((value) =>
    value && String(value.fk_licence_app_premise) === String(current.id)
    && Number(value[addressField] || 0) > 0);
  const requestedId = own(incoming, 'id') ? String(incoming.id) : '';
  let row = requestedId
    ? candidates.find((value) => String(value.id) === requestedId)
    : undefined;
  if (!row && !requestedId && own(incoming, 'sort_order')) {
    const matches = candidates.filter((value) =>
      String(value.f_sort_order) === String(incoming.sort_order));
    if (matches.length === 1) row = matches[0];
  }
  if (!row && !requestedId && candidates.length === 1) row = candidates[0];
  if (!row) throw new Error('Unknown ' + label + ' premise id for this NLA');
  const patch = currentValues(row, Object.values(__PREMISE_MAP__));
  assign(patch, incoming, __PREMISE_MAP__);
  const relationName = addressField === 'fk_address_self_owned'
    ? 'f_address_self_owned' : 'f_address_rented';
  premiseUpdates.push({
    id: row.id,
    address_id: row[addressField],
    premise_patch: patch,
    address_patch: addressPatchFor(row[relationName] || {}, incoming.address),
  });
};
const suppliedPremises = p2.premises || {};
if (Array.isArray(suppliedPremises.self_owned)) {
  for (const value of suppliedPremises.self_owned) {
    premiseUpdate(value, 'fk_address_self_owned', 'self-owned');
  }
}
if (Array.isArray(suppliedPremises.rented)) {
  for (const value of suppliedPremises.rented) {
    premiseUpdate(value, 'fk_address_rented', 'rented');
  }
}
const templatePosition = (template) => String(
  (template && template.f_position_code) || '');
const checklistUpdates = [];
if (Array.isArray(p5.checklist)) {
  for (const incoming of p5.checklist) {
    const row = checklistRows.find((value) => {
      const template = value.f_document_checklist
        || checklistTemplateRows.find((item) =>
          String(item.id) === String(value.fk_document_checklist));
      return templatePosition(template) === String(incoming.position_code);
    });
    if (!row) {
      throw new Error('Unknown checklist position_code for this NLA: '
        + String(incoming.position_code));
    }
    const patch = currentValues(row, ['f_is_checked', 'f_status', 'f_remarks']);
    if (own(incoming, 'checked')) patch.f_is_checked = incoming.checked;
    if (own(incoming, 'status')) patch.f_status = incoming.status;
    if (own(incoming, 'remarks')) patch.f_remarks = incoming.remarks;
    checklistUpdates.push({
      id: row.id,
      checklist_patch: patch,
      attachment_id: own(incoming, 'attachment_id')
        ? Number(incoming.attachment_id) : 0,
    });
  }
}
return {
  intake_patch: intakePatch,
  nla_patch: nlaPatch,
  address_patch: addressPatch,
  contact_updates: contactUpdates,
  premise_updates: premiseUpdates,
  checklist_updates: checklistUpdates,
};"""
    for marker, value in replacements.items():
        script = script.replace(marker, value)
    return script


def field_references(
    node: Mapping[str, Any], prefix: str, fields: list[str]
) -> dict[str, str]:
    return {field: ref(node, f"{prefix}.{field}") for field in fields}


def scope_field_references(
    node: Mapping[str, Any], prefix: str, fields: list[str]
) -> dict[str, str]:
    return {field: scope(node, f"{prefix}.{field}") for field in fields}


def create_node(
    api: NocoBaseApi,
    workflow_id: int,
    node_type: str,
    title: str,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    return dict(
        api.create_node(
            {
                "workflowId": workflow_id,
                "type": node_type,
                "title": title,
                "config": dict(config),
            }
        )
    )


def link(
    api: NocoBaseApi,
    upstream: Mapping[str, Any],
    downstream: Mapping[str, Any],
    *,
    branch_index: int | None = None,
) -> None:
    if branch_index is None:
        api.update_node(int(upstream["id"]), {"downstreamId": downstream["id"]})
    api.update_node(
        int(downstream["id"]),
        {
            "upstreamId": upstream["id"],
            "branchIndex": branch_index,
        },
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print(f"workflow_title={TITLE}")
    print("trigger=OP/UPDATE/update_new_licence_data/submitted")
    print("native_submit_count=0")
    print("business_status_write=no")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = NocoBaseApi(args.base_url, token)
    workflow = api.request(
        "POST",
        "/api/workflows:create",
        {
            "title": TITLE,
            "type": "collection",
            "sync": False,
            "enabled": False,
            "config": {
                "mode": 1,
                "appends": [],
                "collection": "t_api_request_staging",
                "condition": {
                    "$and": [
                        {"f_status": {"$eq": "submitted"}},
                        {"f_source_system": {"$ne": "CMTF"}},
                        {"f_request_event": {"$eq": "UPDATE"}},
                        {"f_api_type": {"$eq": UPDATE_API_TYPE}},
                    ]
                },
            },
        },
    )
    if not isinstance(workflow, dict) or workflow.get("id") is None:
        raise ApiError("Workflow create API returned no workflow ID")
    workflow_id = int(workflow["id"])
    attach_api_source_category(api, workflow_id)

    processing = create_node(
        api,
        workflow_id,
        "update",
        "Mark update processing",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "processing"},
        ),
    )
    parse = create_node(
        api,
        workflow_id,
        "json-variable-mapping",
        "Parse update request body",
        {
            "parseArray": False,
            "variables": [
                {
                    "key": "createid01",
                    "path": "create_id",
                    "name": "create_id",
                    "paths": ["create_id"],
                },
                {
                    "key": "formdata01",
                    "path": "form_data",
                    "name": "form_data",
                    "paths": ["form_data"],
                },
            ],
            "dataSource": context("f_request_body"),
            "example": {
                "create_id": "384761337741312",
                "form_data": {
                    "part_2": {"telephone_no": "21239999"},
                },
            },
        },
    )
    original = create_node(
        api,
        workflow_id,
        "query",
        "Resolve original CREATE staging record",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(parse, "createid01")}},
                {"f_source_system": {"$eq": SOURCE_SYSTEM}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": CREATE_API_TYPE}},
                {"f_status": {"$eq": "succeeded"}},
                {"f_application_status": {"$eq": "Accepted"}},
            ],
        ),
    )
    valid = create_node(
        api,
        workflow_id,
        "condition",
        "Original CREATE resolved?",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [ref(original, "id"), "0"],
                        }
                    ],
                }
            },
        },
    )
    failed = create_node(
        api,
        workflow_id,
        "update",
        "Reject unknown create_id",
        update_config(
            "t_api_request_staging",
            context("id"),
            {"f_status": "failed"},
        ),
    )
    intake = create_node(
        api,
        workflow_id,
        "query",
        "Load linked Intake",
        query_config(
            "t_intake_form",
            [{"id": {"$eq": ref(original, "f_intake_id")}}],
        ),
    )
    application = create_node(
        api,
        workflow_id,
        "query",
        "Load linked NLA",
        query_config(
            "t_licence_app",
            [{"id": {"$eq": ref(original, "f_application_id")}}],
            appends=("f_attachments_of_rchs",),
        ),
    )
    main_address = create_node(
        api,
        workflow_id,
        "query",
        "Load linked main RCH address",
        query_config(
            "t_address",
            [{"id": {"$eq": ref(application, "fk_rch_address")}}],
        ),
    )
    contacts = create_node(
        api,
        workflow_id,
        "query",
        "Load linked NLA contacts",
        query_config(
            "t_licence_contact",
            [
                {
                    "$or": [
                        {
                            "fk_licence_contact_applicant": {
                                "$eq": ref(application, "id")
                            }
                        },
                        {
                            "fk_licence_contact_operator": {
                                "$eq": ref(application, "id")
                            }
                        },
                        {"fk_licence_contact_company": {"$eq": ref(application, "id")}},
                        {"fk_licence_contact_person": {"$eq": ref(application, "id")}},
                    ]
                }
            ],
            multiple=True,
            appends=("f_address_correspondence",),
        ),
    )
    premises = create_node(
        api,
        workflow_id,
        "query",
        "Load linked NLA premises",
        query_config(
            "t_licence_app_premise",
            [{"fk_licence_app_premise": {"$eq": ref(application, "id")}}],
            multiple=True,
            appends=("f_address_self_owned", "f_address_rented"),
        ),
    )
    checklist_submissions = create_node(
        api,
        workflow_id,
        "query",
        "Load linked NLA Checklist records",
        query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"f_business_type": {"$eq": "t_licence_app"}},
            ],
            multiple=True,
            appends=("f_document_checklist",),
        ),
    )
    address_options = create_node(
        api,
        workflow_id,
        "query",
        "Load address code dictionary for update",
        query_config("f_tree_region_district", [], multiple=True),
    )
    rch_types = create_node(
        api,
        workflow_id,
        "query",
        "Load RCH type dictionary for update",
        query_config("f_rch_type_options", [], multiple=True),
    )
    checklist_templates = create_node(
        api,
        workflow_id,
        "query",
        "Load Checklist templates for portable positions",
        query_config(
            "t_document_checklist",
            [
                {"f_item_type": {"$eq": "2"}},
                {"f_active": {"$eq": True}},
            ],
            multiple=True,
        ),
    )
    normalize = create_node(
        api,
        workflow_id,
        "script",
        "Build non-destructive update patches",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formdata01")},
                {"name": "intake", "value": ref(intake)},
                {"name": "application", "value": ref(application)},
                {"name": "mainAddress", "value": ref(main_address)},
                {"name": "contacts", "value": ref(contacts)},
                {"name": "premises", "value": ref(premises)},
                {
                    "name": "checklistSubmissions",
                    "value": ref(checklist_submissions),
                },
                {"name": "addressOptions", "value": ref(address_options)},
                {"name": "rchTypeOptions", "value": ref(rch_types)},
                {
                    "name": "checklistTemplates",
                    "value": ref(checklist_templates),
                },
            ],
            "content": patch_script(),
            "timeout": 0,
            "continue": False,
        },
    )
    update_intake = create_node(
        api,
        workflow_id,
        "update",
        "Update linked Intake fields",
        update_config(
            "t_intake_form",
            ref(original, "f_intake_id"),
            field_references(
                normalize,
                "intake_patch",
                [
                    "f_office_cd",
                    "f_received_date",
                    "f_severity",
                    "fk_intake_source",
                    "f_source_other",
                    "fk_task_owner",
                    "fk_task_owner_post",
                    "f_subject",
                    "f_comments",
                ],
            ),
        ),
    )
    update_address = create_node(
        api,
        workflow_id,
        "update",
        "Update linked main RCH address",
        update_config(
            "t_address",
            ref(application, "fk_rch_address"),
            field_references(
                normalize,
                "address_patch",
                [
                    "f_fullname_en",
                    "f_fullname_cn",
                    "f_lot_or_address_en",
                    "f_lot_or_address_cn",
                    "f_block_no_en",
                    "f_block_no_cn",
                    "f_block_type_en",
                    "f_block_type_cn",
                    "f_floor_num_en",
                    "f_floor_num_cn",
                    "f_unit_no_en",
                    "f_unit_no_cn",
                    "f_unit_type_en",
                    "f_unit_type_cn",
                    "f_building_name_en",
                    "f_building_name_cn",
                    "f_estate_or_village_name_en",
                    "f_estate_or_village_name_cn",
                    "f_street_no_en",
                    "f_street_no_cn",
                    "f_street_name_en",
                    "f_street_name_cn",
                    "f_phase_en",
                    "f_phase_cn",
                    "fk_region_en",
                    "fk_region_cn",
                    "fk_district_name_en",
                    "fk_district_name_cn",
                    "fk_sub_district_en",
                    "fk_sub_district_cn",
                ],
            ),
        ),
    )
    update_application = create_node(
        api,
        workflow_id,
        "update",
        "Update linked NLA fields",
        update_config(
            "t_licence_app",
            ref(original, "f_application_id"),
            field_references(
                normalize,
                "nla_patch",
                [
                    "f_application_received_date",
                    "f_app_type",
                    "f_tentative_service_commencement_date",
                    "f_rch_name_en",
                    "f_rch_name_cn",
                    "fk_rch_nature",
                    "f_rch_premises",
                    "f_monthly_fee_per_resident_min",
                    "f_monthly_fee_per_resident_max",
                    "f_rch_gender",
                    "f_net_floor_area_sqm",
                    "f_licence_capacity",
                    "f_telephone_no",
                    "f_fax_no",
                    "f_email",
                    "f_floors_total",
                    "f_units_total",
                    "f_rch_nature_other",
                    "f_is_rcsv",
                    "f_complies_lease_dmc",
                    "f_complies_lease_dmc_other",
                    "f_beds_nursing",
                    "f_beds_care_and_attention",
                    "f_beds_meal",
                    "f_beds_self_care",
                    "f_beds_total",
                    "f_max_capacity",
                    "f_existing_capacity",
                    "f_enrolment_residents",
                    "f_service_type",
                    "f_business_ownership_type",
                    "f_date_of_operation",
                    "f_signature_date",
                    "f_application_level",
                    "f_comments",
                    "f_other_information",
                    "f_remarks",
                    "f_attachments_of_rchs",
                    "fk_type_of_rch",
                ],
            ),
        ),
    )
    contact_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply supplied contact updates",
        {
            "target": ref(normalize, "contact_updates"),
            "condition": False,
            "exit": 0,
        },
    )
    update_contact = create_node(
        api,
        workflow_id,
        "update",
        "Update current NLA contact",
        update_config(
            "t_licence_contact",
            scope(contact_loop, "id"),
            scope_field_references(
                contact_loop,
                "contact_patch",
                list(CONTACT_FIELDS.values()),
            ),
        ),
    )
    update_contact_address = create_node(
        api,
        workflow_id,
        "update",
        "Update current contact address",
        update_config(
            "t_address",
            scope(contact_loop, "address_id"),
            scope_field_references(
                contact_loop,
                "address_patch",
                [
                    *ADDRESS_FIELDS.values(),
                    "fk_region_en",
                    "fk_region_cn",
                    "fk_district_name_en",
                    "fk_district_name_cn",
                    "fk_sub_district_en",
                    "fk_sub_district_cn",
                ],
            ),
        ),
    )
    premise_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply supplied premise updates",
        {
            "target": ref(normalize, "premise_updates"),
            "condition": False,
            "exit": 0,
        },
    )
    update_premise = create_node(
        api,
        workflow_id,
        "update",
        "Update current NLA premise",
        update_config(
            "t_licence_app_premise",
            scope(premise_loop, "id"),
            scope_field_references(
                premise_loop,
                "premise_patch",
                list(PREMISE_FIELDS.values()),
            ),
        ),
    )
    update_premise_address = create_node(
        api,
        workflow_id,
        "update",
        "Update current premise address",
        update_config(
            "t_address",
            scope(premise_loop, "address_id"),
            scope_field_references(
                premise_loop,
                "address_patch",
                [
                    *ADDRESS_FIELDS.values(),
                    "fk_region_en",
                    "fk_region_cn",
                    "fk_district_name_en",
                    "fk_district_name_cn",
                    "fk_sub_district_en",
                    "fk_sub_district_cn",
                ],
            ),
        ),
    )
    checklist_loop = create_node(
        api,
        workflow_id,
        "loop",
        "Apply supplied Checklist updates",
        {
            "target": ref(normalize, "checklist_updates"),
            "condition": False,
            "exit": 0,
        },
    )
    update_checklist = create_node(
        api,
        workflow_id,
        "update",
        "Update current native Checklist item",
        update_config(
            "t_document_submitted_for_application",
            scope(checklist_loop, "id"),
            scope_field_references(
                checklist_loop,
                "checklist_patch",
                ["f_is_checked", "f_status", "f_remarks"],
            ),
        ),
    )
    attachment_supplied = create_node(
        api,
        workflow_id,
        "condition",
        "Checklist update contains attachment?",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [scope(checklist_loop, "attachment_id"), 0],
                        }
                    ],
                }
            },
        },
    )
    attachment = create_node(
        api,
        workflow_id,
        "query",
        "Load update Checklist attachment record",
        query_config(
            "attachments",
            [{"id": {"$eq": scope(checklist_loop, "attachment_id")}}],
        ),
    )
    attachment_exists = create_node(
        api,
        workflow_id,
        "condition",
        "Update Checklist attachment exists?",
        {
            "rejectOnFalse": True,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [ref(attachment, "id"), 0],
                        }
                    ],
                }
            },
        },
    )
    create_checklist_detail = create_node(
        api,
        workflow_id,
        "create",
        "Create update Checklist upload Details record",
        {
            "collection": "t_document_submitted_for_application_details",
            "params": {
                "values": {
                    "fk_documests_submitted_for_application_id": scope(
                        checklist_loop, "id"
                    ),
                    "f_files": [scope(checklist_loop, "attachment_id")],
                    "f_file_name": ref(attachment, "filename"),
                    "f_file_date": ref(attachment, "createdAt"),
                    "f_remarks": scope(checklist_loop, "checklist_patch.f_remarks"),
                },
                "appends": [],
            },
        },
    )
    update_checklist_latest = create_node(
        api,
        workflow_id,
        "update",
        "Update current Checklist latest file",
        update_config(
            "t_document_submitted_for_application",
            scope(checklist_loop, "id"),
            {
                "f_lastest_files": [scope(checklist_loop, "attachment_id")],
                "f_lastest_files_name": ref(attachment, "filename"),
                "f_lastest_file_date": ref(attachment, "createdAt"),
            },
            individual_hooks=True,
        ),
    )
    succeeded = create_node(
        api,
        workflow_id,
        "update",
        "Mark update succeeded + backfill IDs",
        update_config(
            "t_api_request_staging",
            context("id"),
            {
                "f_status": "succeeded",
                "f_intake_id": ref(original, "f_intake_id"),
                "f_application_id": ref(original, "f_application_id"),
            },
        ),
    )

    link(api, processing, parse)
    link(api, parse, original)
    link(api, original, valid)
    link(api, valid, failed, branch_index=0)
    link(api, valid, intake, branch_index=1)
    link(api, intake, application)
    link(api, application, main_address)
    link(api, main_address, contacts)
    link(api, contacts, premises)
    link(api, premises, checklist_submissions)
    link(api, checklist_submissions, address_options)
    link(api, address_options, rch_types)
    link(api, rch_types, checklist_templates)
    link(api, checklist_templates, normalize)
    link(api, normalize, update_intake)
    link(api, update_intake, update_address)
    link(api, update_address, update_application)
    link(api, update_application, contact_loop)
    link(api, contact_loop, update_contact, branch_index=0)
    link(api, update_contact, update_contact_address)
    link(api, contact_loop, premise_loop)
    link(api, premise_loop, update_premise, branch_index=0)
    link(api, update_premise, update_premise_address)
    link(api, premise_loop, checklist_loop)
    link(api, checklist_loop, update_checklist, branch_index=0)
    link(api, update_checklist, attachment_supplied)
    link(api, attachment_supplied, attachment, branch_index=1)
    link(api, attachment, attachment_exists)
    link(api, attachment_exists, create_checklist_detail, branch_index=1)
    link(api, create_checklist_detail, update_checklist_latest)
    link(api, checklist_loop, succeeded)

    verified = api.get_workflow(workflow_id)
    titles = {node.get("title") for node in verified.get("nodes") or []}
    required = {
        "Resolve original CREATE staging record",
        "Build non-destructive update patches",
        "Update linked Intake fields",
        "Update linked main RCH address",
        "Update linked NLA fields",
        "Apply supplied contact updates",
        "Apply supplied premise updates",
        "Apply supplied Checklist updates",
        "Create update Checklist upload Details record",
        "Mark update succeeded + backfill IDs",
    }
    missing = sorted(required - titles)
    if missing or verified.get("enabled"):
        raise ApiError(
            f"Update workflow verification failed: missing={missing}, "
            f"enabled={verified.get('enabled')}"
        )
    print(f"workflow_id={workflow_id}")
    print(f"workflow_key={verified['key']}")
    print("workflow_enabled=no")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
