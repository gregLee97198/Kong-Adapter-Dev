#!/usr/bin/env python3
"""Prepare disabled 13001 unified API Staging workflow candidates.

This is deliberately narrower than a deployment tool:

* ``--inspect`` is read-only;
* ``--prepare`` creates exactly one ingress and twelve marker workers, all
  disabled; and
* ``--validate`` readbacks an existing preparation manifest.

There is intentionally no cutover, enable, disable, or delete command.  A
separate reviewed tool must handle any production-like state transition after
the candidates have passed functional tests.

No credential is embedded.  Supply only an expiring 13001 administrator token
at execution time through ``NOCOBASE_TOKEN``.  This file is not executed by
the repository test suite and this change does not run it against 13001.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import re
import secrets
import sys
import tempfile
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError, attach_api_source_category
import migrate_nocobase_single_staging_dispatch_13001 as blueprint


PREPARED_ROOT = (
    Path(__file__).resolve().parents[1].parent
    / "kong-nocoadapter-artifacts" / "workflow-preparations"
)
MANIFEST_FORMAT = "nocobase-unified-api-staging-preparation/v1"
_MIGRATION_RE = re.compile(r"^[a-z0-9][a-z0-9-]{5,63}$")


class ExecutionError(RuntimeError):
    """A remote invariant or local preparation invariant failed."""


def _atomic_json(path: Path, value: Any) -> None:
    """Write private state atomically; never overwrite a different plan."""
    data = (json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n").encode()
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _new_migration_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%Sz").lower()
    return f"staging-{stamp}-{secrets.token_hex(3)}"


def _require_token() -> str:
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        raise ExecutionError("NOCOBASE_TOKEN is required")
    return token


def _api() -> RootNocoBaseApi:
    # The fixed endpoint is intentional.  This execution tool is 13001-only.
    return RootNocoBaseApi(blueprint.BASE_URL, _require_token())


def _workflow(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    row = dict(api.get_workflow(workflow_id))
    if row.get("id") != workflow_id:
        raise ExecutionError(f"workflow {workflow_id} readback is invalid")
    if not isinstance(row.get("nodes"), list):
        raise ExecutionError(f"workflow {workflow_id} does not include nodes")
    return row


def _list_workflows(api: RootNocoBaseApi, *, key: str | None = None) -> list[dict[str, Any]]:
    """Fetch complete workflow objects; detail reads avoid truncated list rows."""
    rows: list[dict[str, Any]] = []
    page = 1
    while True:
        params: list[tuple[str, str]] = [("page", str(page)), ("pageSize", "100")]
        if key is not None:
            params.append(("filter[key]", key))
        result = api.request("GET", "/api/workflows:list?" + urllib.parse.urlencode(params))
        if not isinstance(result, list):
            raise ExecutionError("workflow list did not return an array")
        rows.extend(dict(item) for item in result if isinstance(item, dict))
        if len(result) < 100:
            break
        page += 1
        if page > 1000:
            raise ExecutionError("workflow list pagination did not terminate")
    ids = sorted({int(row["id"]) for row in rows if isinstance(row.get("id"), int)})
    return [_workflow(api, workflow_id) for workflow_id in ids]


def _assert_source(
    row: Mapping[str, Any], *, workflow_id: int, expected_key: str, label: str
) -> None:
    config = row.get("config")
    if (
        row.get("id") != workflow_id
        or row.get("key") != expected_key
        or row.get("type") != "collection"
        or not isinstance(config, Mapping)
        or config.get("collection") != blueprint.COLLECTION
    ):
        raise ExecutionError(f"{label} source identity/config drifted")
    try:
        blueprint._node_index(row)
    except blueprint.PlanError as exc:
        raise ExecutionError(f"{label} source graph is not clone-safe: {exc}") from exc


def _source_snapshot(api: RootNocoBaseApi) -> dict[str, Any]:
    """Collect every remote source needed by prepare, before making a write."""
    result: dict[str, Any] = {"create": {}, "update": {}, "nla_parent": None}
    for business in blueprint.BUSINESSES:
        create = _workflow(api, business.create_source_id)
        _assert_source(create, workflow_id=business.create_source_id,
                       expected_key=business.create_source_key,
                       label=f"{business.name} CREATE")
        # Queue wrappers superseded the original Update workflows, so their
        # pre-queue IDs are archival identities, not live sources. The
        # approved local pre-FIFO snapshot is the clone source; the fresh
        # category export made before this preparation retains current live
        # wrappers as rollback evidence.
        update = blueprint.prepared_update_graph(business)
        result["create"][business.name] = create
        result["update"][business.name] = update
    nla = blueprint.BUSINESSES[0]
    if nla.legacy_parent_id is not None and nla.legacy_parent_key is not None:
        parent = _workflow(api, nla.legacy_parent_id)
        _assert_source(parent, workflow_id=nla.legacy_parent_id,
                       expected_key=nla.legacy_parent_key,
                       label="NLA legacy ingress")
        result["nla_parent"] = parent
    return result


def _workflow_title(kind: str, migration_id: str, business: blueprint.Business | None = None) -> str:
    label = "unified ingress dispatcher" if business is None else f"{business.title} unified CREATE/UPDATE worker"
    return f"API Staging — {label} [prepared {migration_id}]"


def _create_disabled_workflow(
    api: RootNocoBaseApi, *, title: str, config: Mapping[str, Any]
) -> dict[str, Any]:
    # Listing every workflow and then reading every graph is needlessly slow
    # on 13001.  A title-only query is enough to prevent an accidental second
    # candidate; exact title comparison remains the safety check.
    title_query = urllib.parse.urlencode(
        [("page", "1"), ("pageSize", "20"), ("filter[title]", title)]
    )
    rows = api.request("GET", "/api/workflows:list?" + title_query)
    existing = [row for row in (rows or []) if isinstance(row, Mapping) and row.get("title") == title]
    if existing:
        raise ExecutionError(f"candidate title already exists: {title!r}")
    created = api.request("POST", "/api/workflows:create", {
        "title": title,
        "type": "collection",
        "sync": False,
        "enabled": False,
        "config": copy.deepcopy(dict(config)),
    })
    if not isinstance(created, Mapping) or not isinstance(created.get("id"), int):
        raise ExecutionError(f"workflow create returned no ID for {title!r}")
    workflow_id = int(created["id"])
    attach_api_source_category(api, workflow_id)
    result = _workflow(api, workflow_id)
    if result.get("enabled") is not False or result.get("title") != title or result.get("config") != dict(config):
        raise ExecutionError(f"disabled candidate readback mismatch: {title!r}")
    return result


def _create_node(
    api: RootNocoBaseApi, workflow_id: int, *, node_type: str, title: str, config: Mapping[str, Any]
) -> dict[str, Any]:
    row = api.create_node({
        "workflowId": workflow_id,
        "type": node_type,
        "title": title,
        "config": copy.deepcopy(dict(config)),
    })
    if not isinstance(row.get("id"), int) or not isinstance(row.get("key"), str):
        raise ExecutionError(f"node create did not return ID/key: {title!r}")
    return dict(row)


def _node_with_id(workflow: Mapping[str, Any], node_id: int) -> Mapping[str, Any]:
    matches = [
        node for node in (workflow.get("nodes") or [])
        if isinstance(node, Mapping) and node.get("id") == node_id
    ]
    if len(matches) != 1:
        raise ExecutionError(f"node {node_id} could not be read back")
    return matches[0]


def _convergent_node_update(
    api: RootNocoBaseApi,
    workflow_id: int,
    node_id: int,
    values: Mapping[str, Any],
) -> None:
    """Apply a node update once; after a timeout, only accept a readback match.

    Mutating requests deliberately are not retried: NocoBase may commit them
    before the client loses the response.  A readback makes this safe for the
    large disabled graph preparation without accidentally duplicating work.
    """
    try:
        api.update_node(node_id, values)
        return
    except ApiError as exc:
        current = _node_with_id(_workflow(api, workflow_id), node_id)
        if all(current.get(key) == value for key, value in values.items()):
            return
        raise ExecutionError(
            f"node {node_id} update outcome is unknown and did not converge"
        ) from exc


def _link(
    api: RootNocoBaseApi,
    workflow_id: int,
    parent: Mapping[str, Any],
    child: Mapping[str, Any],
    branch: int | None,
) -> None:
    # Child-side upstream carries branchIndex.  Preserve source downstream too
    # when this is an ordinary continuation; condition branches keep it null.
    values: dict[str, Any] = {"upstreamId": parent["id"], "branchIndex": branch}
    _convergent_node_update(api, workflow_id, int(child["id"]), values)
    if branch is None:
        _convergent_node_update(
            api, workflow_id, int(parent["id"]), {"downstreamId": child["id"]}
        )


def _materialize_specs(
    api: RootNocoBaseApi, workflow_id: int, specs: list[dict[str, Any]]
) -> dict[str, dict[str, Any]]:
    """Create a simple planned graph (the ingress) and wire its exact edges."""
    actual: dict[str, dict[str, Any]] = {}
    for spec in specs:
        key = str(spec["key"])
        actual[key] = _create_node(api, workflow_id, node_type=str(spec["type"]),
                                   title=str(spec["title"]), config=dict(spec["config"]))
    for spec in specs:
        if spec.get("upstream") is None:
            continue
        _link(
            api,
            workflow_id,
            actual[str(spec["upstream"])],
            actual[str(spec["key"])],
            spec.get("branch"),
        )
    return actual


def _clone_graph(
    api: RootNocoBaseApi,
    workflow_id: int,
    graph: Mapping[str, Any],
    *,
    prefix: str,
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Clone a source graph in three safe passes.

    Pass 1 creates every disabled node.  Pass 2 rewrites node-key references
    after NocoBase has assigned every new key.  Pass 3 restores edges.  A
    write failure leaves only a disabled partial candidate for manual review.
    """
    indexed = blueprint._node_index(graph)
    ordered = sorted(indexed.values(), key=lambda node: str(node["key"]))
    actual: dict[str, dict[str, Any]] = {}
    for source in ordered:
        source_key = str(source["key"])
        actual[source_key] = _create_node(
            api, workflow_id, node_type=str(source["type"]),
            title=f"{prefix}/{source_key} — {source.get('title') or source['type']}",
            # References to old keys are harmless while the workflow is disabled.
            config=dict(source.get("config") or {}),
        )
    keymap = {old_key: str(row["key"]) for old_key, row in actual.items()}
    for source in ordered:
        source_key = str(source["key"])
        original_config = source.get("config") or {}
        config = blueprint._replace_refs(original_config, keymap)
        # Most nodes contain no node-key interpolation.  Their persisted
        # config is already valid, so avoid an unnecessary write.
        if config != original_config:
            _convergent_node_update(
                api, workflow_id, int(actual[source_key]["id"]), {"config": config}
            )
    for source in ordered:
        source_key = str(source["key"])
        upstream_id = source.get("upstreamId")
        if upstream_id not in (None, ""):
            parent_key = str(indexed[int(upstream_id)]["key"])
            _link(
                api,
                workflow_id,
                actual[parent_key],
                actual[source_key],
                source.get("branchIndex"),
            )
    source_root = next(node for node in indexed.values() if node.get("upstreamId") in (None, ""))
    recipe = {
        "source_graph_sha256": blueprint.digest(graph),
        "source_root_key": source_root["key"],
        "source_to_candidate_key": keymap,
        "source_to_candidate_id": {key: row["id"] for key, row in actual.items()},
    }
    return actual, recipe


def _worker_graph(
    api: RootNocoBaseApi,
    workflow_id: int,
    business: blueprint.Business,
    create_graph: Mapping[str, Any],
    update_graph: Mapping[str, Any],
) -> dict[str, Any]:
    branch = blueprint.event_branch_node(business)
    root = _create_node(api, workflow_id, node_type=str(branch["type"]),
                        title=str(branch["title"]), config=dict(branch["config"]))
    _create_actual, create_recipe = _clone_graph(api, workflow_id, create_graph, prefix="CREATE")
    _update_actual, update_recipe = _clone_graph(api, workflow_id, update_graph, prefix="UPDATE")
    create_root_key = str(create_recipe["source_root_key"])
    update_root_key = str(update_recipe["source_root_key"])
    create_root = _create_actual[create_root_key]
    update_root = _update_actual[update_root_key]
    _link(api, workflow_id, root, create_root, 1)
    _link(api, workflow_id, root, update_root, 0)
    return {
        "event_branch_id": root["id"], "event_branch_key": root["key"],
        "create": create_recipe, "update": update_recipe,
    }


def _refs_resolve(workflow: Mapping[str, Any]) -> bool:
    keys = {str(node.get("key")) for node in workflow.get("nodes") or []}
    for node in workflow.get("nodes") or []:
        for text in blueprint._walk_strings(node.get("config") or {}):
            for _scope, key in blueprint._REF_RE.findall(text):
                if key not in keys:
                    return False
    return True


def _validate_candidate(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    expected_config: Mapping[str, Any],
    expected_nodes: int,
) -> dict[str, Any]:
    row = _workflow(api, int(candidate["id"]))
    if row.get("enabled") is not False:
        raise ExecutionError(f"candidate {row.get('id')} unexpectedly enabled")
    if row.get("config") != dict(expected_config):
        raise ExecutionError(f"candidate {row.get('id')} trigger config drifted")
    if len(row.get("nodes") or []) != expected_nodes:
        raise ExecutionError(f"candidate {row.get('id')} node count drifted")
    if not _refs_resolve(row):
        raise ExecutionError(f"candidate {row.get('id')} has unresolved cloned node refs")
    return {
        "id": row["id"], "key": row.get("key"), "title": row.get("title"),
        "enabled": row.get("enabled"), "executed": row.get("executed"),
        "node_count": len(row.get("nodes") or []),
        "references_resolve": True,
    }


def _manifest_path(migration_id: str) -> Path:
    return PREPARED_ROOT / f"13001-unified-staging-{migration_id}" / "manifest.json"


def inspect() -> dict[str, Any]:
    api = _api()
    sources = _source_snapshot(api)
    return {
        "writes_remote": False,
        "environment": "13001",
        "base_url": blueprint.BASE_URL,
        "source_summary": {
            kind: {name: {"id": row["id"], "key": row.get("key"), "title": row.get("title"),
                          "enabled": row.get("enabled"), "executed": row.get("executed"),
                          "node_count": len(row.get("nodes") or [])}
                   for name, row in values.items()}
            for kind, values in (("create", sources["create"]), ("update", sources["update"]))
        },
        "nla_legacy_parent": ({"id": sources["nla_parent"]["id"], "key": sources["nla_parent"].get("key"),
                               "enabled": sources["nla_parent"].get("enabled"),
                               "node_count": len(sources["nla_parent"].get("nodes") or [])}
                              if sources["nla_parent"] else None),
        "plan_sha256": blueprint.digest(blueprint.static_plan()),
    }


def prepare(migration_id: str) -> dict[str, Any]:
    if not _MIGRATION_RE.fullmatch(migration_id):
        raise ExecutionError("migration ID must be lowercase letters/numbers/hyphens (6-64 chars)")
    manifest_path = _manifest_path(migration_id)
    if manifest_path.exists():
        raise ExecutionError(f"preparation manifest already exists: {manifest_path}")
    api = _api()
    # Entire source inventory is read and locally preserved before any POST.
    sources = _source_snapshot(api)
    update_graphs = {b.name: blueprint.prepared_update_graph(b) for b in blueprint.BUSINESSES}
    manifest: dict[str, Any] = {
        "format": MANIFEST_FORMAT,
        "phase": "preparing",
        "environment": "13001",
        "base_url": blueprint.BASE_URL,
        "migration_id": migration_id,
        "created_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "plan_sha256": blueprint.digest(blueprint.static_plan()),
        "remote_writes": [],
        "source_snapshot": sources,
        "candidates": {"ingress": None, "workers": {}},
        "cutover": "not implemented by this tool",
    }
    _atomic_json(manifest_path, manifest)
    try:
        ingress_title = _workflow_title("ingress", migration_id)
        ingress = _create_disabled_workflow(api, title=ingress_title, config=blueprint.ingress_config())
        ingress_nodes = _materialize_specs(api, int(ingress["id"]), blueprint.ingress_nodes())
        checked_ingress = _validate_candidate(api, ingress, expected_config=blueprint.ingress_config(),
                                              expected_nodes=len(ingress_nodes))
        manifest["candidates"]["ingress"] = {**checked_ingress, "node_map": {
            name: {"id": node["id"], "key": node["key"]} for name, node in ingress_nodes.items()}}
        manifest["remote_writes"].append({"kind": "create_disabled_ingress", "workflow_id": ingress["id"]})
        _atomic_json(manifest_path, manifest)
        for business in blueprint.BUSINESSES:
            title = _workflow_title("worker", migration_id, business)
            worker = _create_disabled_workflow(api, title=title, config=blueprint.worker_config(business))
            clone = _worker_graph(api, int(worker["id"]), business,
                                  sources["create"][business.name], update_graphs[business.name])
            expected_nodes = 1 + len(sources["create"][business.name]["nodes"]) + len(update_graphs[business.name]["nodes"])
            checked = _validate_candidate(api, worker, expected_config=blueprint.worker_config(business),
                                          expected_nodes=expected_nodes)
            manifest["candidates"]["workers"][business.name] = {
                **checked,
                "business": business.name,
                "route": business.route,
                "clone": clone,
            }
            manifest["remote_writes"].append({"kind": "create_disabled_worker", "business": business.name,
                                               "workflow_id": worker["id"]})
            _atomic_json(manifest_path, manifest)
    except Exception as exc:
        manifest["phase"] = "partial_disabled_candidates"
        manifest["error"] = str(exc)
        _atomic_json(manifest_path, manifest)
        raise
    manifest["phase"] = "prepared_disabled"
    manifest["prepared_at_utc"] = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    _atomic_json(manifest_path, manifest)
    return {"writes_remote": True, "phase": manifest["phase"], "manifest": str(manifest_path),
            "ingress_id": manifest["candidates"]["ingress"]["id"],
            "worker_count": len(manifest["candidates"]["workers"]),
            "all_candidates_enabled": False}


def validate(manifest_path: Path) -> dict[str, Any]:
    if not manifest_path.is_file():
        raise ExecutionError(f"manifest does not exist: {manifest_path}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ExecutionError(f"cannot read manifest: {exc}") from exc
    if manifest.get("format") != MANIFEST_FORMAT or manifest.get("environment") != "13001":
        raise ExecutionError("manifest does not describe a 13001 unified preparation")
    api = _api()
    ingress = manifest.get("candidates", {}).get("ingress")
    workers = manifest.get("candidates", {}).get("workers")
    if not isinstance(ingress, Mapping) or not isinstance(workers, Mapping) or set(workers) != {b.name for b in blueprint.BUSINESSES}:
        raise ExecutionError("manifest candidate set is incomplete")
    ingress_check = _validate_candidate(api, ingress, expected_config=blueprint.ingress_config(),
                                        expected_nodes=len(blueprint.ingress_nodes()))
    worker_checks: dict[str, Any] = {}
    for business in blueprint.BUSINESSES:
        update = blueprint.prepared_update_graph(business)
        # Source create count comes from exported manifest, avoiding a new
        # live mutation or any assumption that legacy nodes were unchanged.
        source = manifest.get("source_snapshot", {}).get("create", {}).get(business.name)
        if not isinstance(source, Mapping) or not isinstance(source.get("nodes"), list):
            raise ExecutionError(f"manifest lacks CREATE source for {business.name}")
        worker_checks[business.name] = _validate_candidate(
            api, workers[business.name], expected_config=blueprint.worker_config(business),
            expected_nodes=1 + len(source["nodes"]) + len(update["nodes"]),
        )
    return {"writes_remote": False, "phase": manifest.get("phase"), "manifest": str(manifest_path),
            "ingress": ingress_check, "workers": worker_checks,
            "all_candidates_disabled": all(item["enabled"] is False for item in [ingress_check, *worker_checks.values()])}


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--inspect", action="store_true", help="Read source workflow identities only.")
    action.add_argument("--prepare", action="store_true", help="Create 13 disabled candidates after local backup.")
    action.add_argument("--validate", type=Path, metavar="MANIFEST", help="Read back prepared disabled candidates.")
    parser.add_argument("--migration-id", help="Required with --prepare; unique lowercase label.")
    parser.add_argument("--confirm", help="Required literal for --prepare.")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if args.inspect:
            result = inspect()
        elif args.prepare:
            if args.confirm != blueprint.PREPARE_CONFIRM:
                raise ExecutionError("--prepare requires --confirm " + blueprint.PREPARE_CONFIRM)
            if not args.migration_id:
                raise ExecutionError("--prepare requires --migration-id")
            result = prepare(args.migration_id)
        else:
            if args.migration_id:
                raise ExecutionError("--migration-id is only valid with --prepare")
            result = validate(args.validate)
        print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except (ExecutionError, ApiError, blueprint.PlanError) as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
