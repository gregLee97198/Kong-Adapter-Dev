#!/usr/bin/env python3
# ruff: noqa: E501
"""Rename and retire only superseded API-Staging workflows on DEV 13001.

This is intentionally a *post-cutover* maintenance tool.  It may operate
only on the reviewed 13001 custom-action topology and only after taking a
fresh, read-only ``API Suorce`` export.  It never uses a title wildcard to
select a deletion target.

The narrow operation is:

1. save a fresh exact, GET-only snapshot of every workflow this tool can
   rename or delete (13 active + 27 deletion targets) through the retrying
   root-role client;
2. verify one active collection ingress and twelve active custom-action
   children have the direct multi-condition topology;
3. rename just those thirteen active workflows to stable, date-free titles;
4. delete exactly twenty-five disabled replaced listeners, one disabled
   serial prototype, and one disabled stale NLA serial child.

It deliberately does *not* touch native Intake/Application/Approval/Send
Letter workflows, the NLA Notice workflows, active Prosecution/Revoke routes,
or the four separately-reviewed older disabled staging rows.  The latter are
outside this executor's scope even though they are candidates for a later,
separately reviewed cleanup.

Deletion is not automatically reversible.  Before its first remote write the
executor saves a redacted, owner-only exact-target snapshot and records each
step in an owner-only checkpoint.  If a write fails it stops; it does not try
to recreate a deleted workflow or silently restore a title.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
import tempfile
import urllib.parse
import uuid
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

import backup_nocobase_api_source_workflows_13001 as workflow_backup
import execute_nocobase_unified_subflow_cutover_13001 as cutover
import plan_nocobase_unified_subflow_cutover_cleanup_13001 as cleanup
import plan_nocobase_unified_subflow_dispatch_13001 as topology
from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError, resolve_workflow_category_id

BASE_URL = topology.BASE_URL
MIGRATION_ID = "multibranch-20261019"
CLEANUP_CONFIRM = "CLEANUP_UNIFIED_API_STAGING_WORKFLOWS_13001"
ADMISSION_PAUSED_CONFIRM = "PUBLIC_CREATE_UPDATE_ADMISSION_PAUSED_13001"
CLEANUP_FORMAT = "nocobase-unified-subflow-cleanup/v1"
MAX_BACKUP_AGE = timedelta(minutes=30)
CLEANUP_ROOT = (
    Path(__file__).resolve().parents[1].parent
    / "kong-nocoadapter-artifacts"
    / "workflow-cleanups"
)


class CleanupError(RuntimeError):
    """A cleanup precondition, mutation, or recovery state is unsafe."""


@dataclass(frozen=True)
class ExactDeleteTarget:
    """An exact disabled workflow identity; no partial matching is allowed."""

    id: int
    key: str
    title: str
    role: str


# The 25 original public collection listeners were disabled by the controlled
# cutover.  These two are distinct abandoned serial prototypes.  Keep this
# list deliberately separate from the broader API Suorce history: it makes a
# later review of unrelated old revisions impossible to accidentally turn into
# a bulk deletion.
DELETE_TARGETS: tuple[ExactDeleteTarget, ...] = tuple(
    ExactDeleteTarget(target.id, target.key, target.title, f"legacy:{target.business}:{target.role}")
    for target in cleanup.PUBLIC_LEGACY
) + (
    ExactDeleteTarget(
        392914024398848,
        "7dms7pwosyw",
        "API Staging — unified external dispatcher",
        "obsolete:serial-dispatcher",
    ),
    ExactDeleteTarget(
        392927085461504,
        "1c4gm8hru5m",
        "API Staging — New Licence Application unified CREATE/UPDATE worker [prepared api-staging-20261019b]",
        "obsolete:stale-nla-serial-child",
    ),
)

PRESERVE_IDS = frozenset(target.id for target in cleanup.PRESERVE)
OPTIONAL_IDS = frozenset(target.id for target in cleanup.OPTIONAL_UNPUBLISHED)


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _write_private_json(path: Path, value: Mapping[str, Any]) -> None:
    """Write a fresh 0600 JSON record without ever overwriting evidence."""
    if path.exists():
        raise CleanupError(f"refusing to overwrite cleanup evidence: {path}")
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload = (_canonical(value) + "\n").encode("utf-8")
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CleanupError(f"cannot read JSON evidence {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise CleanupError(f"JSON object expected: {path}")
    return value


def _parse_timestamp(value: Any, *, label: str) -> datetime:
    if not isinstance(value, str):
        raise CleanupError(f"{label} timestamp is absent")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise CleanupError(f"{label} timestamp is invalid: {value!r}") from exc
    if parsed.tzinfo is None:
        raise CleanupError(f"{label} timestamp has no timezone")
    return parsed.astimezone(timezone.utc)


def _require_api() -> RootNocoBaseApi:
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        raise CleanupError("NOCOBASE_TOKEN is required for 13001 cleanup")
    return RootNocoBaseApi(BASE_URL, token)


def _assert_13001_api(api: Any) -> None:
    observed = getattr(api, "base_url", BASE_URL)
    if not isinstance(observed, str) or observed.rstrip("/") != BASE_URL:
        raise CleanupError(f"cleanup API endpoint is not fixed development 13001: {observed!r}")


def _api_source_category_id(api: RootNocoBaseApi) -> int:
    try:
        return resolve_workflow_category_id(api, topology.API_SOURCE_CATEGORY_TITLE)
    except ApiError as exc:
        raise CleanupError("API Suorce category is absent or ambiguous on 13001") from exc


def _candidate_manifest_path() -> Path:
    return topology._manifest_path(MIGRATION_ID).resolve()


def _load_candidate_manifest() -> dict[str, Any]:
    path = _candidate_manifest_path()
    manifest = _load_json(path)
    if (
        manifest.get("environment") != "13001"
        or manifest.get("migration_id") != MIGRATION_ID
        or manifest.get("architecture") != topology.ARCHITECTURE
    ):
        raise CleanupError("candidate manifest is not the reviewed 13001 multibranch migration")
    candidates = manifest.get("candidates")
    if not isinstance(candidates, Mapping):
        raise CleanupError("candidate manifest has no candidate identities")
    parent = candidates.get("parent")
    children = candidates.get("children")
    if not isinstance(parent, Mapping) or not isinstance(children, Mapping):
        raise CleanupError("candidate manifest parent/children are malformed")
    if not isinstance(parent.get("id"), int) or not isinstance(parent.get("key"), str):
        raise CleanupError("candidate manifest parent identity is malformed")
    expected_businesses = {business.name for business in topology.BUSINESSES}
    if set(children) != expected_businesses:
        raise CleanupError("candidate manifest does not contain exactly twelve business children")
    for business in topology.BUSINESSES:
        row = children[business.name]
        if not isinstance(row, Mapping) or not isinstance(row.get("id"), int) or not isinstance(row.get("key"), str):
            raise CleanupError(f"candidate manifest child identity is malformed: {business.name}")
    return manifest


def _clean_parent_title() -> str:
    return "API Staging — External Request Dispatcher"


def _clean_child_title(business: topology.Business) -> str:
    return f"API Staging — {business.title}"


def _active_target_specs(manifest: Mapping[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    candidates = manifest["candidates"]
    parent = dict(candidates["parent"])
    parent.update({"clean_title": _clean_parent_title(), "expected_type": "collection", "expected_sync": False})
    children: list[dict[str, Any]] = []
    for business in topology.BUSINESSES:
        item = dict(candidates["children"][business.name])
        item.update(
            {
                "business": business.name,
                "clean_title": _clean_child_title(business),
                "expected_type": "custom-action",
                "expected_sync": True,
            }
        )
        children.append(item)
    ids = [int(parent["id"]), *[int(item["id"]) for item in children]]
    if len(ids) != 13 or len(set(ids)) != len(ids):
        raise CleanupError("active target identity catalogue is not exactly thirteen distinct workflows")
    return parent, children


def _workflow_categories(api: RootNocoBaseApi, workflow_id: int) -> set[int]:
    query = urllib.parse.urlencode([("filterByTk", str(workflow_id)), ("appends[]", "categories")])
    try:
        value = api.request("GET", "/api/workflows:get?" + query)
    except ApiError as exc:
        raise CleanupError(f"cannot read workflow {workflow_id} categories") from exc
    if not isinstance(value, Mapping) or value.get("id") != workflow_id:
        raise CleanupError(f"workflow {workflow_id} category readback is invalid")
    values = value.get("categories")
    if not isinstance(values, list):
        raise CleanupError(f"workflow {workflow_id} categories are malformed")
    result: set[int] = set()
    for item in values:
        raw = item.get("id") if isinstance(item, Mapping) else item
        try:
            result.add(int(raw))
        except (TypeError, ValueError) as exc:
            raise CleanupError(f"workflow {workflow_id} has a malformed category ID") from exc
    return result


def _read_workflow(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    try:
        row = dict(api.get_workflow(workflow_id))
    except ApiError as exc:
        # Keep the HTTP status in the public error text.  ``_read_absent``
        # must distinguish a confirmed 404 after an idempotency-uncertain
        # destroy call from every other transport or authorization error.
        raise CleanupError(f"cannot read workflow {workflow_id}: {exc}") from exc
    if row.get("id") != workflow_id or not isinstance(row.get("nodes"), list):
        raise CleanupError(f"workflow {workflow_id} readback is incomplete")
    row["_category_ids"] = sorted(_workflow_categories(api, workflow_id))
    return row


def _assert_active_identity(row: Mapping[str, Any], target: Mapping[str, Any], *, category_id: int) -> None:
    workflow_id = int(target["id"])
    allowed_titles = {target.get("title"), target.get("clean_title")}
    if (
        row.get("id") != workflow_id
        or row.get("key") != target.get("key")
        or row.get("type") != target.get("expected_type")
        or row.get("title") not in allowed_titles
        or row.get("enabled") is not True
        or row.get("sync") is not target.get("expected_sync")
    ):
        raise CleanupError(f"active workflow {workflow_id} identity/state drifted")
    if category_id not in set(row.get("_category_ids") or []):
        raise CleanupError(f"active workflow {workflow_id} is outside API Suorce")


def _assert_delete_identity(row: Mapping[str, Any], target: ExactDeleteTarget, *, category_id: int) -> None:
    if (
        row.get("id") != target.id
        or row.get("key") != target.key
        or row.get("title") != target.title
        or row.get("type") != "collection"
        or row.get("enabled") is not False
    ):
        raise CleanupError(f"deletion target {target.id} identity/state drifted")
    if category_id not in set(row.get("_category_ids") or []):
        raise CleanupError(f"deletion target {target.id} is outside API Suorce")


def _assert_execution_idle(api: RootNocoBaseApi, workflow_id: int, *, label: str) -> dict[str, Any]:
    try:
        summary = cutover._execution_summary(api, workflow_id)
    except cutover.CutoverError as exc:
        raise CleanupError(f"cannot inspect executions for {label}: {exc}") from exc
    if int(summary.get("running") or 0) != 0 or int(summary.get("queued") or 0) != 0:
        raise CleanupError(f"{label} has a running or queued execution")
    return summary


def _assert_child_graph(
    row: Mapping[str, Any], business: topology.Business, manifest: Mapping[str, Any]
) -> None:
    if row.get("config") != topology.child_config():
        raise CleanupError(f"{business.name} child trigger config drifted")
    try:
        specs = topology._child_specs(manifest, business)
        actual = topology._actual_nodes(row, specs)
        if len(actual) != len(specs) or len(row["nodes"]) != len(specs):
            raise CleanupError(f"{business.name} child node count drifted")
        desired = topology._desired_child_configs(specs, actual)
        for spec in specs:
            identity = str(spec["identity"])
            node = actual[identity]
            if node.get("config") != desired[identity]:
                raise CleanupError(f"{business.name} child node config drifted: {spec['title']!r}")
            upstream = spec.get("upstream")
            if upstream is None:
                if node.get("upstreamId") not in (None, ""):
                    raise CleanupError(f"{business.name} child router has an upstream")
                continue
            parent = actual[str(upstream)]
            if node.get("upstreamId") != parent["id"] or node.get("branchIndex") != spec.get("branch"):
                raise CleanupError(f"{business.name} child edge drifted: {spec['title']!r}")
            if spec.get("branch") is None and parent.get("downstreamId") != node["id"]:
                raise CleanupError(f"{business.name} child continuation drifted: {spec['title']!r}")
        if not topology._references_resolve(row):
            raise CleanupError(f"{business.name} child has unresolved node-key references")
        router = actual["ROUTER"]
        conditions = router.get("config", {}).get("conditions") if isinstance(router.get("config"), Mapping) else None
        if (
            router.get("type") != "multi-conditions"
            or not isinstance(conditions, list)
            or [value.get("title") for value in conditions if isinstance(value, Mapping)] != ["CREATE", "UPDATE"]
        ):
            raise CleanupError(f"{business.name} child is not the required CREATE/UPDATE router")
        if any(
            topology.legacy.ROUTE_FIELD in _canonical(node.get("config") or {})
            for node in row.get("nodes") or []
            if isinstance(node, Mapping)
        ):
            raise CleanupError(f"{business.name} child still contains marker routing")
    except topology.PreparationError as exc:
        raise CleanupError(f"{business.name} child topology failed validation: {exc}") from exc


def _assert_parent_graph(
    row: Mapping[str, Any], child_rows: Mapping[str, Mapping[str, Any]]
) -> None:
    if row.get("config") != topology.ingress_config():
        raise CleanupError("ingress trigger config drifted")
    child_keys = {business: str(value["key"]) for business, value in child_rows.items()}
    try:
        specs = topology.ingress_nodes(child_keys)
        actual = topology._actual_nodes(row, specs)
        if len(actual) != len(specs) or len(row["nodes"]) != len(specs):
            raise CleanupError("ingress node count drifted")
        for spec in specs:
            node = actual[str(spec["identity"])]
            if node.get("config") != spec["config"]:
                raise CleanupError(f"ingress node config drifted: {spec['title']!r}")
            upstream = spec.get("upstream")
            if upstream is None:
                if node.get("upstreamId") not in (None, ""):
                    raise CleanupError("ingress router has an upstream")
                continue
            parent = actual[str(upstream)]
            if node.get("upstreamId") != parent["id"] or node.get("branchIndex") != spec.get("branch"):
                raise CleanupError(f"ingress edge drifted: {spec['title']!r}")
        router = actual["INGRESS_ROUTER"]
        conditions = router.get("config", {}).get("conditions") if isinstance(router.get("config"), Mapping) else None
        subflows = [node for identity, node in actual.items() if identity.startswith("INGRESS_SUBFLOW:")]
        if (
            router.get("type") != "multi-conditions"
            or not isinstance(conditions, list)
            or len(conditions) != len(topology.BUSINESSES)
            or len(subflows) != len(topology.BUSINESSES)
            or any(node.get("upstreamId") != router["id"] for node in subflows)
        ):
            raise CleanupError("ingress is not the required direct twelve-way router")
        if any(
            topology.legacy.ROUTE_FIELD in _canonical(node.get("config") or {})
            for node in row.get("nodes") or []
            if isinstance(node, Mapping)
        ):
            raise CleanupError("ingress still contains marker routing")
    except topology.PreparationError as exc:
        raise CleanupError(f"ingress topology failed validation: {exc}") from exc


def verify_active_topology(
    api: RootNocoBaseApi, manifest: Mapping[str, Any]
) -> dict[str, Any]:
    """Read and prove the already-active parent/children graph is exact."""
    _assert_13001_api(api)
    category_id = _api_source_category_id(api)
    parent_target, child_targets = _active_target_specs(manifest)
    parent_row = _read_workflow(api, int(parent_target["id"]))
    _assert_active_identity(parent_row, parent_target, category_id=category_id)
    child_rows: dict[str, dict[str, Any]] = {}
    for target in child_targets:
        row = _read_workflow(api, int(target["id"]))
        _assert_active_identity(row, target, category_id=category_id)
        business = next(item for item in topology.BUSINESSES if item.name == target["business"])
        _assert_child_graph(row, business, manifest)
        child_rows[business.name] = row
    _assert_parent_graph(parent_row, child_rows)
    return {
        "category_id": category_id,
        "parent": parent_row,
        "children": child_rows,
        "target_parent": parent_target,
        "target_children": child_targets,
    }


def _assert_static_catalogue() -> None:
    ids = [target.id for target in DELETE_TARGETS]
    if len(DELETE_TARGETS) != 27 or len(ids) != len(set(ids)):
        raise CleanupError("deletion catalogue must contain exactly 27 distinct workflows")
    if set(ids) & PRESERVE_IDS:
        raise CleanupError("deletion catalogue overlaps preserved Notice workflow")
    if set(ids) & OPTIONAL_IDS:
        raise CleanupError("deletion catalogue overlaps Prosecution/Revoke workflow")
    if any(target.id in cleanup.EXPECTED_ABSENT for target in DELETE_TARGETS):
        raise CleanupError("deletion catalogue includes an already-absent historical ID")


def preflight(api: RootNocoBaseApi, manifest: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Read-only remote gate. It does not export, rename, or delete."""
    _assert_13001_api(api)
    _assert_static_catalogue()
    manifest = dict(manifest or _load_candidate_manifest())
    topology_result = verify_active_topology(api, manifest)
    category_id = int(topology_result["category_id"])

    parent = topology_result["parent"]
    children = topology_result["children"]
    execution_summaries: dict[str, Any] = {
        str(parent["id"]): _assert_execution_idle(api, int(parent["id"]), label="active ingress")
    }
    for business, child in children.items():
        execution_summaries[str(child["id"])] = _assert_execution_idle(
            api, int(child["id"]), label=f"active child {business}"
        )

    deletion_rows: dict[str, dict[str, Any]] = {}
    for target in DELETE_TARGETS:
        row = _read_workflow(api, target.id)
        _assert_delete_identity(row, target, category_id=category_id)
        deletion_rows[str(target.id)] = row
        execution_summaries[str(target.id)] = _assert_execution_idle(
            api, target.id, label=f"deletion target {target.role}"
        )

    # The NLA Received Notice listener must remain active and outside the
    # destructive set.  This is a guard only; no Notice graph is revised here.
    notice = cleanup.PRESERVE[0]
    notice_row = _read_workflow(api, notice.id)
    if (
        notice_row.get("id") != notice.id
        or notice_row.get("key") != notice.key
        or notice_row.get("title") != notice.title
        or notice_row.get("enabled") is not True
        or category_id not in set(notice_row.get("_category_ids") or [])
    ):
        raise CleanupError("preserved NLA Received Notice workflow drifted")

    return {
        "writes_remote": False,
        "environment": "13001",
        "migration_id": MIGRATION_ID,
        "category_id": category_id,
        "active": {
            "parent": parent,
            "children": children,
            "target_parent": topology_result["target_parent"],
            "target_children": topology_result["target_children"],
        },
        "deletion_rows": deletion_rows,
        "execution_summaries": execution_summaries,
        "preserved_notice": {
            "id": notice.id,
            "key": notice.key,
            "title": notice.title,
        },
        "ready_for_cleanup": True,
    }


def _new_run_directory(root: Path) -> Path:
    root = root.resolve()
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    # Evidence can contain workflow configuration and must not be browsable by
    # another local account even when a previous run created the root under a
    # permissive umask.
    os.chmod(root, 0o700)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = root / f"subflow-cleanup-{stamp}-{uuid.uuid4().hex[:8]}"
    path.mkdir(mode=0o700)
    return path


def _export_fresh_backup(
    api: RootNocoBaseApi,
    output_root: Path,
    *,
    active_targets: Iterable[Mapping[str, Any]],
) -> Path:
    """Save a fresh exact GET-only snapshot using the root retrying client.

    The general category exporter is intentionally not used here: its plain
    GET client lacks the root header needed by this 13001 workflow API and can
    lose a long category export to a transport disconnect.  This narrower
    snapshot is stronger for a deletion operation: it captures exactly every
    workflow that this executor can rename/delete (13 + 27), through
    ``RootNocoBaseApi`` which retries reads and includes ``X-Role``. The
    protected Notice listener is guarded separately in preflight and is never
    included in a deletion or rename target.
    """
    _assert_13001_api(api)
    output = output_root.resolve()
    if output.exists():
        raise CleanupError(f"fresh exact backup directory already exists: {output}")
    targets = list(active_targets)
    target_ids = [int(target["id"]) for target in targets] + [target.id for target in DELETE_TARGETS]
    if len(target_ids) != len(set(target_ids)):
        raise CleanupError("fresh exact backup target list is not unique")
    if len(target_ids) != 40:
        raise CleanupError("fresh exact backup must contain exactly 13 active and 27 deletion targets")
    rows: dict[str, Any] = {}
    inventory: list[dict[str, Any]] = []
    for workflow_id in target_ids:
        row = _read_workflow(api, workflow_id)
        rows[str(workflow_id)] = workflow_backup._redact(copy.deepcopy(row))
        inventory.append(
            {
                "id": row.get("id"),
                "key": row.get("key"),
                "title": row.get("title"),
                "type": row.get("type"),
                "enabled": row.get("enabled"),
            }
        )
    captured = _now()
    details_path = output / "workflows.redacted.json"
    _write_private_json(details_path, {"workflows": rows})
    manifest = {
        "format": "nocobase-api-source-exact-workflow-backup/v1",
        "environment": "13001",
        "base_url": BASE_URL,
        "category": topology.API_SOURCE_CATEGORY_TITLE,
        "exported_at_utc": captured,
        "workflow_count": len(inventory),
        "workflows": sorted(inventory, key=lambda item: int(item["id"])),
        "details": str(details_path),
        "remote_write_operations": 0,
        "source": "RootNocoBaseApi GET-only exact target export",
    }
    _write_private_json(output / "manifest.json", manifest)
    return output


def _validate_fresh_backup(
    backup_dir: Path,
    *,
    active_targets: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    manifest_path = backup_dir / "manifest.json"
    manifest = _load_json(manifest_path)
    if (
        manifest.get("format") != "nocobase-api-source-exact-workflow-backup/v1"
        or manifest.get("environment") != "13001"
        or manifest.get("base_url") != BASE_URL
        or manifest.get("remote_write_operations") != 0
    ):
        raise CleanupError("fresh backup is not a read-only 13001 API Suorce exact export")
    exported_at = _parse_timestamp(manifest.get("exported_at_utc"), label="fresh backup")
    age = datetime.now(timezone.utc) - exported_at
    if age < timedelta(minutes=-1) or age > MAX_BACKUP_AGE:
        raise CleanupError(f"fresh backup is outside the {MAX_BACKUP_AGE} safety window")
    rows = manifest.get("workflows")
    if not isinstance(rows, list):
        raise CleanupError("fresh backup inventory is malformed")
    if manifest.get("workflow_count") != 40 or len(rows) != 40:
        raise CleanupError("fresh backup must inventory exactly 40 workflows")
    valid_rows = [
        row
        for row in rows
        if isinstance(row, Mapping) and isinstance(row.get("id"), int)
    ]
    by_id = {int(row["id"]): row for row in valid_rows}
    required = [*DELETE_TARGETS, *active_targets]
    if len(by_id) != len(valid_rows):
        raise CleanupError("fresh backup inventory contains duplicate workflow IDs")
    for target in required:
        identifier = int(target.id if isinstance(target, ExactDeleteTarget) else target["id"])
        row = by_id.get(identifier)
        if row is None:
            raise CleanupError(f"fresh backup omitted required workflow {identifier}")
        expected_key = target.key if isinstance(target, ExactDeleteTarget) else target["key"]
        if row.get("key") != expected_key:
            raise CleanupError(f"fresh backup identity drifted for workflow {identifier}")
    details_value = _load_json(backup_dir / "workflows.redacted.json")
    details = details_value.get("workflows")
    if not isinstance(details, Mapping):
        raise CleanupError("fresh backup details are malformed")
    for target in required:
        identifier = int(target.id if isinstance(target, ExactDeleteTarget) else target["id"])
        row = details.get(str(identifier))
        if not isinstance(row, Mapping) or row.get("id") != identifier:
            raise CleanupError(f"fresh backup details omitted required workflow {identifier}")
        expected_key = target.key if isinstance(target, ExactDeleteTarget) else target["key"]
        if row.get("key") != expected_key:
            raise CleanupError(f"fresh backup details identity drifted for workflow {identifier}")
    return {"directory": str(backup_dir), "manifest": str(manifest_path), "sha256": _sha256(manifest)}


def _exact_snapshot(preflight_result: Mapping[str, Any]) -> dict[str, Any]:
    active = preflight_result["active"]
    workflows: dict[str, Any] = {}
    parent = active["parent"]
    workflows[str(parent["id"])] = workflow_backup._redact(copy.deepcopy(parent))
    for row in active["children"].values():
        workflows[str(row["id"])] = workflow_backup._redact(copy.deepcopy(row))
    for workflow_id, row in preflight_result["deletion_rows"].items():
        workflows[str(workflow_id)] = workflow_backup._redact(copy.deepcopy(row))
    return {
        "format": CLEANUP_FORMAT,
        "environment": "13001",
        "captured_at_utc": _now(),
        "workflows": workflows,
        "execution_summaries": copy.deepcopy(preflight_result["execution_summaries"]),
        "preserved_notice": copy.deepcopy(preflight_result["preserved_notice"]),
        "manual_restore_guidance": (
            "Do not automatically recreate deleted workflows. Use this exact snapshot "
            "and the fresh category export to restore only after a human graph review. "
            "Renamed active workflows can be renamed back by their fixed workflow IDs; "
            "deleted workflows require deliberate recreation/import review."
        ),
    }


def _checkpoint(path: Path, state: dict[str, Any], action: str, details: Mapping[str, Any]) -> None:
    state["updated_at_utc"] = _now()
    events = state.setdefault("events", [])
    if not isinstance(events, list):
        raise CleanupError("cleanup checkpoint events are malformed")
    events.append({"at_utc": state["updated_at_utc"], "action": action, "details": copy.deepcopy(dict(details))})
    state["events"] = events[-200:]
    # A checkpoint is intentionally overwritten only within its own new run
    # directory.  Its first write is already protected by _write_private_json.
    payload = (_canonical(state) + "\n").encode("utf-8")
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _rename_active(api: RootNocoBaseApi, target: Mapping[str, Any], *, category_id: int) -> dict[str, Any]:
    workflow_id = int(target["id"])
    before = _read_workflow(api, workflow_id)
    _assert_active_identity(before, target, category_id=category_id)
    desired = str(target["clean_title"])
    if before.get("title") == desired:
        return before
    try:
        api.request(
            "POST",
            "/api/workflows:update?" + urllib.parse.urlencode({"filterByTk": str(workflow_id)}),
            {"title": desired},
        )
    except ApiError as exc:
        after = _read_workflow(api, workflow_id)
        if after.get("title") != desired:
            raise CleanupError(f"workflow {workflow_id} title update failed before commit") from exc
    after = _read_workflow(api, workflow_id)
    _assert_active_identity(after, target, category_id=category_id)
    if after.get("title") != desired:
        raise CleanupError(f"workflow {workflow_id} title update did not persist")
    return after


def _read_absent(api: RootNocoBaseApi, workflow_id: int) -> bool:
    """Return whether NocoBase confirms that this exact workflow is absent.

    This installation returns either an HTTP 404 *or* a successful
    ``{\"data\": null}`` response after a workflow is removed.  The latter is
    not a malformed workflow and must be treated as an idempotent delete
    outcome.  Any non-null malformed response, authentication failure, or
    transport failure remains a hard stop.
    """
    query = urllib.parse.urlencode(
        [("filterByTk", str(workflow_id)), ("appends[]", "nodes")]
    )
    try:
        raw = api.request("GET", "/api/workflows:get?" + query)
    except ApiError as exc:
        if "HTTP 404" in str(exc):
            return True
        raise CleanupError(
            f"cannot confirm workflow {workflow_id} presence: {exc}"
        ) from exc
    if raw is None:
        return True
    if not isinstance(raw, Mapping):
        raise CleanupError(
            f"workflow {workflow_id} presence readback is malformed"
        )
    return False


def _delete_exact(
    api: RootNocoBaseApi, target: ExactDeleteTarget, *, category_id: int
) -> str:
    """Delete one exact reviewed target, or record a confirmed prior removal.

    ``already_absent`` is permitted only after the caller has made the fresh
    backup and completed the exact preflight in this run.  The caller records
    it explicitly rather than pretending this executor performed a destroy.
    """
    if _read_absent(api, target.id):
        return "already_absent"
    row = _read_workflow(api, target.id)
    _assert_delete_identity(row, target, category_id=category_id)
    _assert_execution_idle(api, target.id, label=f"deletion target {target.role}")
    try:
        api.request(
            "POST",
            "/api/workflows:destroy?" + urllib.parse.urlencode({"filterByTk": str(target.id)}),
            {},
        )
    except ApiError as exc:
        if not _read_absent(api, target.id):
            raise CleanupError(f"workflow {target.id} deletion failed before commit") from exc
    if not _read_absent(api, target.id):
        raise CleanupError(f"workflow {target.id} deletion readback did not persist")
    return "destroyed"


def _build_state(
    *,
    run_directory: Path,
    category_backup: Mapping[str, Any],
    exact_backup_path: Path,
    preflight_result: Mapping[str, Any],
) -> dict[str, Any]:
    active = preflight_result["active"]
    parent = active["target_parent"]
    children = active["target_children"]
    return {
        "format": CLEANUP_FORMAT,
        "environment": "13001",
        "base_url": BASE_URL,
        "migration_id": MIGRATION_ID,
        "run_directory": str(run_directory),
        "phase": "preflight_complete",
        "category_backup": dict(category_backup),
        "exact_backup": str(exact_backup_path),
        "targets": {
            "rename_parent": {key: parent.get(key) for key in ("id", "key", "title", "clean_title", "expected_type")},
            "rename_children": [
                {key: child.get(key) for key in ("business", "id", "key", "title", "clean_title", "expected_type")}
                for child in children
            ],
            "delete_exact": [
                {"id": target.id, "key": target.key, "title": target.title, "role": target.role}
                for target in DELETE_TARGETS
            ],
            "preserved_notice_ids": sorted(PRESERVE_IDS),
            "excluded_optional_ids": sorted(OPTIONAL_IDS),
        },
        "rollback_guidance": {
            "automatic_rollback": "not implemented; deletions are never recreated automatically",
            "rename_only": "use pre-delete-target-backup.redacted.json to manually restore an original title by its fixed workflow ID after review",
            "deleted_workflows": "restore only from the fresh category backup after human graph/configuration review",
        },
        "events": [],
    }


def apply_cleanup(
    api: RootNocoBaseApi,
    *,
    output_root: Path = CLEANUP_ROOT,
    confirmation: str,
    admission_paused: str,
    exporter: Callable[..., Path] = _export_fresh_backup,
    manifest: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute the narrow cleanup.  It intentionally has no auto-rollback."""
    _assert_13001_api(api)
    _assert_static_catalogue()
    if confirmation != CLEANUP_CONFIRM:
        raise CleanupError("apply_cleanup requires explicit cleanup confirmation")
    if admission_paused != ADMISSION_PAUSED_CONFIRM:
        raise CleanupError("apply_cleanup requires explicit admission-paused confirmation")
    manifest = dict(manifest or _load_candidate_manifest())
    active_parent, active_children = _active_target_specs(manifest)
    active_targets = [active_parent, *active_children]

    run_directory = _new_run_directory(output_root)
    checkpoint_path = run_directory / "checkpoint.json"
    try:
        category_backup_dir = exporter(
            api,
            run_directory / "fresh-exact-backup",
            active_targets=active_targets,
        )
        category_backup = _validate_fresh_backup(category_backup_dir, active_targets=active_targets)
        preflight_result = preflight(api, manifest)
        exact_backup_path = run_directory / "pre-delete-target-backup.redacted.json"
        _write_private_json(exact_backup_path, _exact_snapshot(preflight_result))
        state = _build_state(
            run_directory=run_directory,
            category_backup=category_backup,
            exact_backup_path=exact_backup_path,
            preflight_result=preflight_result,
        )
        _write_private_json(checkpoint_path, state)
        _checkpoint(checkpoint_path, state, "fresh_backup_validated", category_backup)
        _checkpoint(checkpoint_path, state, "preflight_complete", {"delete_count": len(DELETE_TARGETS)})

        category_id = int(preflight_result["category_id"])
        state["phase"] = "renaming_active_topology"
        _checkpoint(checkpoint_path, state, "rename_started", {"count": len(active_targets)})
        _rename_active(api, active_parent, category_id=category_id)
        _checkpoint(checkpoint_path, state, "workflow_renamed", {"id": active_parent["id"], "title": active_parent["clean_title"]})
        for child in active_children:
            _rename_active(api, child, category_id=category_id)
            _checkpoint(checkpoint_path, state, "workflow_renamed", {"id": child["id"], "title": child["clean_title"]})

        # Verify the graph again after title-only mutations, before anything
        # destructive.  This also proves the clean names did not alter wiring.
        verify_active_topology(api, manifest)
        _checkpoint(checkpoint_path, state, "post_rename_topology_verified", {"count": len(active_targets)})

        state["phase"] = "deleting_exact_disabled_targets"
        _checkpoint(checkpoint_path, state, "delete_started", {"count": len(DELETE_TARGETS)})
        destroyed_ids: list[int] = []
        already_absent_ids: list[int] = []
        for target in DELETE_TARGETS:
            outcome = _delete_exact(api, target, category_id=category_id)
            if outcome == "destroyed":
                destroyed_ids.append(target.id)
                action = "workflow_deleted"
            elif outcome == "already_absent":
                already_absent_ids.append(target.id)
                action = "workflow_already_absent_after_preflight"
            else:  # pragma: no cover - keep any future outcome fail-closed.
                raise CleanupError(f"unexpected delete outcome for {target.id}: {outcome!r}")
            _checkpoint(
                checkpoint_path,
                state,
                action,
                {"id": target.id, "role": target.role},
            )

        verify_active_topology(api, manifest)
        if any(not _read_absent(api, target.id) for target in DELETE_TARGETS):
            raise CleanupError("one or more exact deletion targets remained after cleanup")
        state["phase"] = "cleanup_complete"
        _checkpoint(
            checkpoint_path,
            state,
            "post_delete_verification_passed",
            {
                "destroyed_ids": destroyed_ids,
                "already_absent_ids": already_absent_ids,
            },
        )
        return {
            "writes_remote": True,
            "environment": "13001",
            "cleanup_complete": True,
            "renamed_count": len(active_targets),
            "retired_count": len(DELETE_TARGETS),
            "deleted_count": len(destroyed_ids),
            "deleted_ids": destroyed_ids,
            "already_absent_ids": already_absent_ids,
            "checkpoint": str(checkpoint_path),
            "category_backup": category_backup["directory"],
            "exact_backup": str(exact_backup_path),
            "rollback": state["rollback_guidance"],
        }
    except Exception as exc:
        if checkpoint_path.exists():
            try:
                state = _load_json(checkpoint_path)
                state["phase"] = "stopped_after_error_manual_recovery_required"
                _checkpoint(checkpoint_path, state, "cleanup_failed", {"error": str(exc)})
            except Exception:
                pass
        if isinstance(exc, CleanupError):
            raise
        raise CleanupError(f"cleanup stopped; inspect {checkpoint_path}: {exc}") from exc


def _load_resumable_state(
    checkpoint_path: Path, *, active_targets: Iterable[Mapping[str, Any]]
) -> dict[str, Any]:
    """Load one interrupted run whose fresh exact snapshot is still usable.

    Resume is deliberately narrow: only an executor-generated checkpoint in
    the owner-only cleanup root is accepted, and its original exact backup
    must still satisfy the normal 30-minute freshness check.  It is not a
    general-purpose retry facility for arbitrary workflow IDs.
    """
    expected_root = CLEANUP_ROOT.resolve()
    resolved = checkpoint_path.resolve()
    if expected_root not in resolved.parents or resolved.name != "checkpoint.json":
        raise CleanupError("resume checkpoint is outside the controlled cleanup evidence root")
    state = _load_json(resolved)
    if (
        state.get("format") != CLEANUP_FORMAT
        or state.get("environment") != "13001"
        or state.get("base_url") != BASE_URL
        or state.get("migration_id") != MIGRATION_ID
        or state.get("phase") != "stopped_after_error_manual_recovery_required"
    ):
        raise CleanupError("checkpoint is not an interrupted reviewed 13001 cleanup run")
    targets = state.get("targets")
    if not isinstance(targets, Mapping):
        raise CleanupError("resume checkpoint has no target catalogue")
    saved_deletes = targets.get("delete_exact")
    expected_deletes = [
        {"id": item.id, "key": item.key, "title": item.title, "role": item.role}
        for item in DELETE_TARGETS
    ]
    if saved_deletes != expected_deletes:
        raise CleanupError("resume checkpoint deletion catalogue differs from this reviewed executor")
    category_backup = state.get("category_backup")
    if not isinstance(category_backup, Mapping) or not isinstance(category_backup.get("directory"), str):
        raise CleanupError("resume checkpoint has no fresh exact backup directory")
    _validate_fresh_backup(
        Path(str(category_backup["directory"])), active_targets=active_targets
    )
    events = state.get("events")
    if not isinstance(events, list) or not any(
        isinstance(event, Mapping) and event.get("action") == "delete_started"
        for event in events
    ):
        raise CleanupError("resume checkpoint never reached the reviewed deletion phase")
    return state


def resume_cleanup(
    api: RootNocoBaseApi,
    *,
    checkpoint_path: Path,
    confirmation: str,
    admission_paused: str,
    manifest: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Complete one explicitly evidenced, interrupted exact cleanup run.

    The prior run must have completed its fresh backup, full preflight and
    title-only renaming.  We reread every surviving exact target before a
    destroy call, and treat NocoBase's confirmed ``data:null`` response as an
    already-completed retirement rather than recreating or guessing anything.
    """
    _assert_13001_api(api)
    _assert_static_catalogue()
    if confirmation != CLEANUP_CONFIRM:
        raise CleanupError("resume_cleanup requires explicit cleanup confirmation")
    if admission_paused != ADMISSION_PAUSED_CONFIRM:
        raise CleanupError("resume_cleanup requires explicit admission-paused confirmation")
    manifest = dict(manifest or _load_candidate_manifest())
    active_parent, active_children = _active_target_specs(manifest)
    active_targets = [active_parent, *active_children]
    state = _load_resumable_state(checkpoint_path, active_targets=active_targets)
    checkpoint = checkpoint_path.resolve()

    try:
        topology_result = verify_active_topology(api, manifest)
        category_id = int(topology_result["category_id"])
        preexisting_absent: list[int] = []
        for item in DELETE_TARGETS:
            if _read_absent(api, item.id):
                preexisting_absent.append(item.id)
                continue
            row = _read_workflow(api, item.id)
            _assert_delete_identity(row, item, category_id=category_id)
            _assert_execution_idle(api, item.id, label=f"resume deletion target {item.role}")
        _checkpoint(
            checkpoint,
            state,
            "resume_preflight_complete",
            {"already_absent_ids": preexisting_absent},
        )

        destroyed_ids: list[int] = []
        already_absent_ids = list(preexisting_absent)
        for item in DELETE_TARGETS:
            outcome = _delete_exact(api, item, category_id=category_id)
            if outcome == "destroyed":
                destroyed_ids.append(item.id)
                action = "workflow_deleted_on_resume"
            elif outcome == "already_absent":
                if item.id not in already_absent_ids:
                    already_absent_ids.append(item.id)
                action = "workflow_already_absent_on_resume"
            else:  # pragma: no cover - keep future outcomes fail-closed.
                raise CleanupError(f"unexpected resume delete outcome for {item.id}: {outcome!r}")
            _checkpoint(
                checkpoint,
                state,
                action,
                {"id": item.id, "role": item.role},
            )

        verify_active_topology(api, manifest)
        if any(not _read_absent(api, item.id) for item in DELETE_TARGETS):
            raise CleanupError("one or more exact deletion targets remained after resumed cleanup")
        state["phase"] = "cleanup_complete"
        _checkpoint(
            checkpoint,
            state,
            "post_resume_delete_verification_passed",
            {
                "destroyed_ids": destroyed_ids,
                "already_absent_ids": already_absent_ids,
            },
        )
        return {
            "writes_remote": True,
            "environment": "13001",
            "cleanup_complete": True,
            "resumed_from": str(checkpoint),
            "retired_count": len(DELETE_TARGETS),
            "deleted_count": len(destroyed_ids),
            "deleted_ids": destroyed_ids,
            "already_absent_ids": already_absent_ids,
            "checkpoint": str(checkpoint),
            "category_backup": str(state["category_backup"]["directory"]),
            "exact_backup": state.get("exact_backup"),
            "rollback": state.get("rollback_guidance"),
        }
    except Exception as exc:
        try:
            state["phase"] = "stopped_after_error_manual_recovery_required"
            _checkpoint(checkpoint, state, "resume_cleanup_failed", {"error": str(exc)})
        except Exception:
            pass
        if isinstance(exc, CleanupError):
            raise
        raise CleanupError(f"resumed cleanup stopped; inspect {checkpoint}: {exc}") from exc


def static_plan() -> dict[str, Any]:
    """Local-only operation contract suitable for review and offline tests."""
    _assert_static_catalogue()
    return {
        "format": CLEANUP_FORMAT,
        "writes_remote": False,
        "environment": "13001 only",
        "base_url": BASE_URL,
        "migration_id": MIGRATION_ID,
        "fresh_backup": "required; saves an exact GET-only RootNocoBaseApi snapshot before any mutation",
        "active_rename_count": 13,
        "delete_count": len(DELETE_TARGETS),
        "delete_ids": [target.id for target in DELETE_TARGETS],
        "preserved_notice_ids": sorted(PRESERVE_IDS),
        "excluded_optional_ids": sorted(OPTIONAL_IDS),
        "excluded_other_stale_ids": [384624645046272, 384631051845632, 386590304305152, 386590352539648],
        "rollback": "manual guidance only; no automatic recreation or title restoration",
    }


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--preflight", action="store_true", help="Read and verify 13001 only; no export or write.")
    action.add_argument("--execute", action="store_true", help="Run fresh backup, rename, and exact deletion with confirmations.")
    action.add_argument(
        "--resume-checkpoint",
        type=Path,
        help="Resume one interrupted, evidenced cleanup checkpoint; requires the same confirmations.",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output.")
    parser.add_argument("--output-root", type=Path, default=CLEANUP_ROOT, help="Local owner-only cleanup evidence root.")
    parser.add_argument("--confirm", help=f"Required literal for --execute: {CLEANUP_CONFIRM}")
    parser.add_argument("--admission-paused", help=f"Required literal for --execute: {ADMISSION_PAUSED_CONFIRM}")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if not args.preflight and not args.execute and args.resume_checkpoint is None:
            result = static_plan()
        else:
            api = _require_api()
            if args.preflight:
                result = preflight(api)
            elif args.resume_checkpoint is not None:
                result = resume_cleanup(
                    api,
                    checkpoint_path=args.resume_checkpoint,
                    confirmation=args.confirm or "",
                    admission_paused=args.admission_paused or "",
                )
            else:
                result = apply_cleanup(
                    api,
                    output_root=args.output_root,
                    confirmation=args.confirm or "",
                    admission_paused=args.admission_paused or "",
                )
    except CleanupError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
