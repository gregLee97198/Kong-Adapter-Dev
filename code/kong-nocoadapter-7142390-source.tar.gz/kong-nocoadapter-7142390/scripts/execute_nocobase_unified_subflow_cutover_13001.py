#!/usr/bin/env python3
# ruff: noqa: E501
"""Perform a guarded, reversible 13001 cutover of API Staging listeners.

This is deliberately the *activation* companion to
``plan_nocobase_unified_subflow_dispatch_13001.py``.  It is not a workflow
builder and it has no deletion path.

The only topology it will activate is the reviewed ``multibranch-20261019``
preparation:

* one disabled collection-event ingress with a direct twelve-way
  ``multi-conditions`` router;
* twelve disabled ``custom-action`` children; and
* a single CREATE/UPDATE ``multi-conditions`` router in every child.

The public API admission point must be paused by the operator before a write
run.  NocoBase workflow enable flags cannot be atomically switched as a group,
so the command records a private local snapshot before its first write and
automatically restores the previous enable states if any later step fails:

``enable children -> disable exact 25 legacy listeners -> enable ingress``.

It never deletes workflows, does not touch the NLA Notice listener, and does
not include Prosecution/Revoke in its target list.  The endpoint is hard-coded
to development 13001; an environment variable cannot redirect it to 13000.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
import tempfile
import urllib.parse
import uuid
from collections.abc import Iterable, Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import backup_nocobase_api_source_workflows_13001 as workflow_backup
import plan_nocobase_unified_subflow_cutover_cleanup_13001 as cleanup
import plan_nocobase_unified_subflow_dispatch_13001 as topology
from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError, resolve_workflow_category_id

BASE_URL = topology.BASE_URL
MIGRATION_ID = "multibranch-20261019"
CUTOVER_CONFIRM = cleanup.CUTOVER_CONFIRM
ADMISSION_PAUSED_CONFIRM = "PUBLIC_CREATE_UPDATE_ADMISSION_PAUSED_13001"
ROLLBACK_CONFIRM = "ROLLBACK_UNIFIED_SUBFLOW_API_STAGING_13001"
CUTOVER_FORMAT = "nocobase-unified-subflow-controlled-cutover/v1"
CUTOVER_ROOT = (
    Path(__file__).resolve().parents[1].parent
    / "kong-nocoadapter-artifacts"
    / "workflow-cutovers"
)

# NocoBase execution statuses observed by the disposable custom-action probe:
# 1 is complete and negative values are terminal error/cancel outcomes.  Any
# other value is treated as active, deliberately fail-closed for cutover.
TERMINAL_EXECUTION_STATUSES = {1, -1, -2}


class CutoverError(RuntimeError):
    """A cutover precondition, mutation, or recovery action is unsafe."""


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _load_json(path: Path) -> dict[str, Any]:
    try:
        result = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CutoverError(f"cannot read JSON evidence {path}: {exc}") from exc
    if not isinstance(result, dict):
        raise CutoverError(f"JSON evidence must be an object: {path}")
    return result


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    """Atomically write a 0600 local checkpoint with no credential value."""
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload = (_canonical(value) + "\n").encode("utf-8")
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _create_private_json(path: Path, value: Mapping[str, Any]) -> None:
    if path.exists():
        raise CutoverError(f"refusing to overwrite local cutover evidence: {path}")
    _atomic_json(path, value)


def _require_api() -> RootNocoBaseApi:
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        raise CutoverError("NOCOBASE_TOKEN is required for 13001 preflight/cutover")
    # This is intentionally not configurable.  A cutover command must never
    # silently run against 13000 merely because an environment file changed.
    return RootNocoBaseApi(BASE_URL, token)


def _assert_13001_api(api: Any) -> None:
    observed = getattr(api, "base_url", BASE_URL)
    if not isinstance(observed, str) or observed.rstrip("/") != BASE_URL:
        raise CutoverError(
            f"cutover API endpoint is not fixed development 13001: {observed!r}"
        )


def _api_source_category_id(api: RootNocoBaseApi) -> int:
    try:
        return resolve_workflow_category_id(api, topology.API_SOURCE_CATEGORY_TITLE)
    except ApiError as exc:
        raise CutoverError("API Suorce category is absent or ambiguous on 13001") from exc


def _workflow_categories(api: RootNocoBaseApi, workflow_id: int) -> set[int]:
    query = urllib.parse.urlencode(
        [("filterByTk", str(workflow_id)), ("appends[]", "categories")]
    )
    try:
        value = api.request("GET", "/api/workflows:get?" + query)
    except ApiError as exc:
        raise CutoverError(f"cannot read workflow {workflow_id} categories") from exc
    if not isinstance(value, Mapping) or value.get("id") != workflow_id:
        raise CutoverError(f"workflow {workflow_id} category readback is invalid")
    categories = value.get("categories")
    if not isinstance(categories, list):
        raise CutoverError(f"workflow {workflow_id} categories are malformed")
    result: set[int] = set()
    for item in categories:
        raw = item.get("id") if isinstance(item, Mapping) else item
        try:
            result.add(int(raw))
        except (TypeError, ValueError) as exc:
            raise CutoverError(f"workflow {workflow_id} has malformed category ID") from exc
    return result


def _read_workflow(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    try:
        result = dict(api.get_workflow(workflow_id))
    except ApiError as exc:
        raise CutoverError(f"cannot read workflow {workflow_id}") from exc
    if result.get("id") != workflow_id or not isinstance(result.get("nodes"), list):
        raise CutoverError(f"workflow {workflow_id} readback is incomplete")
    result["_category_ids"] = sorted(_workflow_categories(api, workflow_id))
    return result


def _assert_identity(
    row: Mapping[str, Any],
    target: cleanup.WorkflowTarget,
    *,
    category_id: int,
) -> None:
    if row.get("id") != target.id:
        raise CutoverError(f"workflow ID drifted for {target.title!r}")
    if row.get("key") != target.key or row.get("title") != target.title:
        raise CutoverError(
            f"workflow {target.id} identity drifted; refusing to toggle a replacement"
        )
    if row.get("type") != "collection":
        raise CutoverError(f"workflow {target.id} is not the expected collection listener")
    if row.get("enabled") not in {True, False}:
        raise CutoverError(f"workflow {target.id} has non-boolean enabled state")
    if category_id not in set(row.get("_category_ids") or []):
        raise CutoverError(
            f"workflow {target.id} is outside the API Suorce category; refusing toggle"
        )


def _execution_rows(api: RootNocoBaseApi, workflow_id: int) -> list[dict[str, Any]]:
    """Read execution rows safely; cutover blocks on unknown active statuses."""
    result: list[dict[str, Any]] = []
    page = 1
    while True:
        query = urllib.parse.urlencode(
            {
                "filter[workflowId]": str(workflow_id),
                "page": page,
                "pageSize": 100,
                "sort[]": "createdAt",
            }
        )
        try:
            rows = api.request("GET", "/api/executions:list?" + query) or []
        except ApiError as exc:
            raise CutoverError(f"cannot read executions for workflow {workflow_id}") from exc
        if not isinstance(rows, list) or not all(isinstance(row, Mapping) for row in rows):
            raise CutoverError(f"execution list is malformed for workflow {workflow_id}")
        result.extend(dict(row) for row in rows)
        if len(rows) < 100:
            return result
        page += 1
        if page > 1000:
            raise CutoverError(f"execution list safety limit exceeded for workflow {workflow_id}")


def _execution_summary(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    rows = _execution_rows(api, workflow_id)
    active: list[int | str] = []
    terminal = 0
    for row in rows:
        status = row.get("status")
        if status in TERMINAL_EXECUTION_STATUSES:
            terminal += 1
        else:
            active.append(row.get("id", "<missing-id>"))
    # `cleanup.review_*` needs running/queued.  Any unknown/non-terminal
    # status is represented as running so it cannot pass a cutover precheck.
    return {
        "running": len(active),
        "queued": 0,
        "terminal": terminal,
        "active_execution_ids": active[:50],
    }


def _compact_row(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "id": row.get("id"),
        "key": row.get("key"),
        "title": row.get("title"),
        "type": row.get("type"),
        "enabled": row.get("enabled"),
    }


def _identity(value: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value.get(key) for key in ("id", "key", "title", "type")}


def _candidate_identity(value: Mapping[str, Any]) -> dict[str, Any]:
    ingress = value.get("ingress")
    children = value.get("children")
    if not isinstance(ingress, Mapping) or not isinstance(children, list):
        raise CutoverError("candidate evidence is structurally incomplete")
    result = {
        "ingress": _identity(ingress),
        "children": sorted(
            [
                {"business": row.get("business"), **_identity(row)}
                for row in children
                if isinstance(row, Mapping)
            ],
            key=lambda item: str(item["business"]),
        ),
        "child_enable_state_at_cutover": value.get("child_enable_state_at_cutover"),
    }
    if len(result["children"]) != len(topology.BUSINESSES):
        raise CutoverError("candidate evidence does not contain exactly twelve children")
    return result


def _expected_manifest_path() -> Path:
    return topology._manifest_path(MIGRATION_ID).resolve()


def _normalize_validation(validation: Mapping[str, Any]) -> dict[str, Any]:
    try:
        normalized = cleanup.normalize_executor_validation(validation)
    except cleanup.PlanError as exc:
        raise CutoverError(f"invalid disabled-candidate validation: {exc}") from exc
    if validation.get("migration_id") != MIGRATION_ID:
        raise CutoverError(
            f"cutover accepts only migration {MIGRATION_ID!r}, not {validation.get('migration_id')!r}"
        )
    raw_manifest = validation.get("manifest")
    if not isinstance(raw_manifest, str) or Path(raw_manifest).resolve() != _expected_manifest_path():
        raise CutoverError("validation does not reference the reviewed multibranch-20261019 manifest")
    if validation.get("cutover_not_implemented") is not True:
        raise CutoverError("validation must be a pre-cutover --validate result")
    if normalized.get("child_enable_state_at_cutover") != "enabled":
        raise CutoverError(
            "successful custom-action sentinel does not authorize enabling all child workflows"
        )
    return normalized


def _assert_validation_agrees(
    supplied: Mapping[str, Any], live: Mapping[str, Any]
) -> dict[str, Any]:
    supplied_normalized = _normalize_validation(supplied)
    live_normalized = _normalize_validation(live)
    for key in ("migration_id", "topology_sha256", "source_snapshot_sha256"):
        if supplied.get(key) != live.get(key):
            raise CutoverError(f"saved validation and fresh 13001 validation disagree on {key}")
    if _candidate_identity(supplied_normalized) != _candidate_identity(live_normalized):
        raise CutoverError("saved validation and fresh 13001 candidate identities differ")
    return live_normalized


def _read_validation_file(path: Path) -> dict[str, Any]:
    result = _load_json(path)
    _normalize_validation(result)
    return result


def _fresh_validation() -> dict[str, Any]:
    """Re-run the builder's strict disabled graph validation before writes."""
    try:
        return topology.validate_preparation(MIGRATION_ID, require_sentinel=True)
    except (topology.PreparationError, ApiError) as exc:
        raise CutoverError(f"fresh 13001 disabled-candidate validation failed: {exc}") from exc


def _assert_no_forbidden_targets() -> None:
    legacy_ids = {target.id for target in cleanup.PUBLIC_LEGACY}
    preserve_ids = {target.id for target in cleanup.PRESERVE}
    optional_ids = {target.id for target in cleanup.OPTIONAL_UNPUBLISHED}
    if len(cleanup.PUBLIC_LEGACY) != 25:
        raise CutoverError("cutover target catalogue must contain exactly 25 legacy listeners")
    if legacy_ids & preserve_ids:
        raise CutoverError("preserved Notice workflow overlaps a cutover target")
    if legacy_ids & optional_ids:
        raise CutoverError("Prosecution/Revoke workflow overlaps a cutover target")


def _snapshot_precheck(
    api: RootNocoBaseApi, validation: Mapping[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Capture exact target identity/state and prove it is safe to switch."""
    _assert_13001_api(api)
    _assert_no_forbidden_targets()
    category_id = _api_source_category_id(api)
    rows: list[dict[str, Any]] = []
    full_workflows: dict[str, Any] = {}
    executions: dict[str, Any] = {}

    for target in (*cleanup.PUBLIC_LEGACY, *cleanup.PRESERVE):
        row = _read_workflow(api, target.id)
        _assert_identity(row, target, category_id=category_id)
        rows.append(_compact_row(row))
        executions[str(target.id)] = _execution_summary(api, target.id)
        # Configurations may contain service credentials.  The local recovery
        # backup retains graph shape but redacts secret-looking material.
        full_workflows[str(target.id)] = workflow_backup._redact(copy.deepcopy(row))

    snapshot = {
        "environment": "13001",
        "migration_id": MIGRATION_ID,
        "workflows": rows,
        "executions": executions,
    }
    try:
        review = cleanup.review_executor_validation(snapshot, validation, phase="cutover")
    except cleanup.PlanError as exc:
        raise CutoverError(f"legacy/candidate precheck failed: {exc}") from exc

    # Capture candidate records separately so rollback can verify exact
    # identity even after the parent is enabled.
    normalized = _normalize_validation(validation)
    candidate_backup: dict[str, Any] = {}
    ingress = normalized["ingress"]
    candidate_ids = [int(ingress["id"])] + [
        int(child["id"]) for child in normalized["children"]
    ]
    for workflow_id in candidate_ids:
        row = _read_workflow(api, workflow_id)
        if category_id not in set(row.get("_category_ids") or []):
            raise CutoverError(f"candidate {workflow_id} is outside API Suorce category")
        candidate_backup[str(workflow_id)] = workflow_backup._redact(copy.deepcopy(row))

    backup = {
        "format": CUTOVER_FORMAT,
        "environment": "13001",
        "captured_at_utc": _now(),
        "category_id": category_id,
        "legacy_and_preserve": full_workflows,
        "candidates": candidate_backup,
        "snapshot": snapshot,
        "review": review,
    }
    return snapshot, backup


def _assert_toggle_target(
    api: RootNocoBaseApi,
    workflow_id: int,
    expected: Mapping[str, Any],
    *,
    category_id: int,
    expected_type: str,
) -> dict[str, Any]:
    row = _read_workflow(api, workflow_id)
    if _identity(row) != {
        "id": expected.get("id"),
        "key": expected.get("key"),
        "title": expected.get("title"),
        "type": expected_type,
    }:
        raise CutoverError(f"workflow {workflow_id} identity/type drifted during cutover")
    if category_id not in set(row.get("_category_ids") or []):
        raise CutoverError(f"workflow {workflow_id} lost API Suorce category during cutover")
    if row.get("enabled") not in {True, False}:
        raise CutoverError(f"workflow {workflow_id} has non-boolean enabled state during cutover")
    return row


def _set_enabled(
    api: RootNocoBaseApi,
    workflow_id: int,
    expected: Mapping[str, Any],
    *,
    category_id: int,
    expected_type: str,
    enabled: bool,
) -> dict[str, Any]:
    """Set one flag once; reconcile a lost mutation response by readback.

    A blind retry could cause a second remote write after a timeout.  Enable
    flags are idempotent, but uncertainty is still important during a cutover,
    so the only recovery is a strict readback of the exact same workflow.
    """
    before = _assert_toggle_target(
        api, workflow_id, expected, category_id=category_id, expected_type=expected_type
    )
    if before["enabled"] is enabled:
        return before
    try:
        api.request(
            "POST",
            "/api/workflows:update?" + urllib.parse.urlencode({"filterByTk": str(workflow_id)}),
            {"enabled": enabled},
        )
    except ApiError as exc:
        after = _assert_toggle_target(
            api, workflow_id, expected, category_id=category_id, expected_type=expected_type
        )
        if after["enabled"] is enabled:
            return after
        if after["enabled"] is before["enabled"]:
            raise CutoverError(
                f"workflow {workflow_id} enable update failed before commit"
            ) from exc
        raise CutoverError(
            f"workflow {workflow_id} enable update has ambiguous divergent state"
        ) from exc
    after = _assert_toggle_target(
        api, workflow_id, expected, category_id=category_id, expected_type=expected_type
    )
    if after["enabled"] is not enabled:
        raise CutoverError(f"workflow {workflow_id} enable readback did not persist")
    return after


def _checkpoint(path: Path, state: dict[str, Any], action: str, details: Mapping[str, Any]) -> None:
    state["updated_at_utc"] = _now()
    events = state.setdefault("events", [])
    if not isinstance(events, list):
        raise CutoverError("local checkpoint events are malformed")
    events.append(
        {"at_utc": state["updated_at_utc"], "action": action, "details": copy.deepcopy(dict(details))}
    )
    state["events"] = events[-300:]
    _atomic_json(path, state)


def _build_state(
    validation_path: Path,
    validation: Mapping[str, Any],
    normalized: Mapping[str, Any],
    backup_path: Path,
    snapshot: Mapping[str, Any],
) -> dict[str, Any]:
    legacy_initial = {
        str(row["id"]): bool(row["enabled"])
        for row in snapshot["workflows"]
        if row["id"] in {target.id for target in cleanup.PUBLIC_LEGACY}
    }
    parent = dict(normalized["ingress"])
    children = [dict(row) for row in normalized["children"]]
    return {
        "format": CUTOVER_FORMAT,
        "environment": "13001",
        "base_url": BASE_URL,
        "migration_id": MIGRATION_ID,
        "architecture": topology.ARCHITECTURE,
        "validation_path": str(validation_path.resolve()),
        "validation_sha256": hashlib.sha256(validation_path.read_bytes()).hexdigest(),
        "manifest": validation.get("manifest"),
        "topology_sha256": validation.get("topology_sha256"),
        "source_snapshot_sha256": validation.get("source_snapshot_sha256"),
        "backup_path": str(backup_path),
        "phase": "prechecked_no_remote_write",
        "initial": {
            "legacy_enabled": legacy_initial,
            "parent_enabled": False,
            "children_enabled": {str(item["id"]): False for item in children},
        },
        "targets": {
            "legacy": [
                {"id": target.id, "key": target.key, "title": target.title, "type": "collection"}
                for target in cleanup.PUBLIC_LEGACY
            ],
            "parent": {**_identity(parent), "type": "collection"},
            "children": [
                {"business": item["business"], **_identity(item), "type": "custom-action"}
                for item in children
            ],
            "preserved": [
                {"id": target.id, "key": target.key, "title": target.title}
                for target in cleanup.PRESERVE
            ],
            "excluded_optional": [
                {"id": target.id, "key": target.key, "title": target.title}
                for target in cleanup.OPTIONAL_UNPUBLISHED
            ],
        },
        "rollback_plan": {
            "order": [
                "disable_new_parent_first",
                "restore_exact_legacy_enabled_states",
                "restore_custom_action_children_to_disabled",
            ],
            "deletions": "forbidden",
            "notice_listener": "preserved",
            "prosecution_revoke": "excluded",
        },
        "events": [],
    }


def _target_index(state: Mapping[str, Any]) -> tuple[dict[int, dict[str, Any]], dict[int, dict[str, Any]], dict[str, Any]]:
    targets = state.get("targets")
    if not isinstance(targets, Mapping):
        raise CutoverError("cutover state targets are malformed")
    legacy_rows = targets.get("legacy")
    child_rows = targets.get("children")
    parent = targets.get("parent")
    if not isinstance(legacy_rows, list) or not isinstance(child_rows, list) or not isinstance(parent, Mapping):
        raise CutoverError("cutover state target arrays are malformed")
    legacy = {int(row["id"]): dict(row) for row in legacy_rows if isinstance(row, Mapping) and isinstance(row.get("id"), int)}
    children = {int(row["id"]): dict(row) for row in child_rows if isinstance(row, Mapping) and isinstance(row.get("id"), int)}
    if len(legacy) != 25 or len(children) != 12 or not isinstance(parent.get("id"), int):
        raise CutoverError("cutover state does not contain exact 25 legacy and 12 child targets")
    return legacy, children, dict(parent)


def _restore_previous_states(
    api: RootNocoBaseApi,
    state: dict[str, Any],
    checkpoint_path: Path,
    *,
    reason: str,
) -> None:
    """Best-effort but fail-loud restoration after a partial cutover.

    The parent is always turned off first so a failed recovery cannot leave a
    new listener and restored legacy listeners active at the same time.
    """
    category_id = _api_source_category_id(api)
    legacy, children, parent = _target_index(state)
    initial = state.get("initial")
    if not isinstance(initial, Mapping):
        raise CutoverError("cutover state has no initial enable snapshot")
    legacy_initial = initial.get("legacy_enabled")
    children_initial = initial.get("children_enabled")
    if not isinstance(legacy_initial, Mapping) or not isinstance(children_initial, Mapping):
        raise CutoverError("cutover state initial enable snapshot is malformed")

    errors: list[str] = []
    # Parent first: if this cannot be confirmed disabled, do not re-enable
    # legacy listeners and risk duplicate collection-event delivery.
    try:
        _set_enabled(
            api, int(parent["id"]), parent, category_id=category_id,
            expected_type="collection", enabled=False,
        )
        _checkpoint(checkpoint_path, state, "rollback_parent_disabled", {"reason": reason, "id": parent["id"]})
    except Exception as exc:
        _checkpoint(checkpoint_path, state, "rollback_parent_disable_failed", {"reason": reason, "error": str(exc)})
        raise CutoverError(
            "rollback could not prove new ingress disabled; legacy listeners were not restored"
        ) from exc

    for workflow_id, target in legacy.items():
        wanted = legacy_initial.get(str(workflow_id))
        if not isinstance(wanted, bool):
            errors.append(f"legacy {workflow_id}: initial state missing")
            continue
        try:
            _set_enabled(
                api, workflow_id, target, category_id=category_id,
                expected_type="collection", enabled=wanted,
            )
            _checkpoint(checkpoint_path, state, "rollback_legacy_restored", {"id": workflow_id, "enabled": wanted})
        except Exception as exc:  # noqa: PERF203 - preserve every recovery error
            errors.append(f"legacy {workflow_id}: {exc}")

    for workflow_id, target in children.items():
        wanted = children_initial.get(str(workflow_id))
        if not isinstance(wanted, bool):
            errors.append(f"child {workflow_id}: initial state missing")
            continue
        try:
            _set_enabled(
                api, workflow_id, target, category_id=category_id,
                expected_type="custom-action", enabled=wanted,
            )
            _checkpoint(checkpoint_path, state, "rollback_child_restored", {"id": workflow_id, "enabled": wanted})
        except Exception as exc:  # noqa: PERF203 - preserve every recovery error
            errors.append(f"child {workflow_id}: {exc}")

    if errors:
        _checkpoint(checkpoint_path, state, "rollback_incomplete", {"reason": reason, "errors": errors})
        raise CutoverError("partial rollback failed: " + "; ".join(errors))
    state["phase"] = "rolled_back"
    _checkpoint(checkpoint_path, state, "rollback_complete", {"reason": reason})


def _verify_post_cutover(
    api: RootNocoBaseApi, state: Mapping[str, Any]
) -> dict[str, Any]:
    category_id = _api_source_category_id(api)
    legacy, children, parent = _target_index(state)
    for workflow_id, target in legacy.items():
        row = _assert_toggle_target(
            api, workflow_id, target, category_id=category_id, expected_type="collection"
        )
        if row["enabled"] is not False:
            raise CutoverError(f"legacy workflow remained enabled: {workflow_id}")
    for workflow_id, target in children.items():
        row = _assert_toggle_target(
            api, workflow_id, target, category_id=category_id, expected_type="custom-action"
        )
        if row["enabled"] is not True:
            raise CutoverError(f"custom-action child was not enabled: {workflow_id}")
    row = _assert_toggle_target(
        api, int(parent["id"]), parent, category_id=category_id, expected_type="collection"
    )
    if row["enabled"] is not True:
        raise CutoverError("new collection ingress was not enabled")
    return {
        "legacy_disabled_ids": sorted(legacy),
        "child_enabled_ids": sorted(children),
        "parent_enabled_id": parent["id"],
    }


def preflight(
    api: RootNocoBaseApi,
    validation_path: Path,
) -> dict[str, Any]:
    """Remote read-only gate; no state changes and no local checkpoint writes."""
    _assert_13001_api(api)
    supplied = _read_validation_file(validation_path)
    live = _fresh_validation()
    normalized = _assert_validation_agrees(supplied, live)
    snapshot, _backup = _snapshot_precheck(api, live)
    return {
        "writes_remote": False,
        "writes_local": False,
        "environment": "13001",
        "migration_id": MIGRATION_ID,
        "validation_sha256": hashlib.sha256(validation_path.read_bytes()).hexdigest(),
        "validation": {
            "topology_sha256": live["topology_sha256"],
            "source_snapshot_sha256": live["source_snapshot_sha256"],
            "candidate": normalized,
        },
        "legacy_target_count": len(cleanup.PUBLIC_LEGACY),
        "preserved_notice_ids": [target.id for target in cleanup.PRESERVE],
        "excluded_optional_ids": [target.id for target in cleanup.OPTIONAL_UNPUBLISHED],
        "snapshot": snapshot,
        "ready_for_explicit_cutover": True,
    }


def _new_run_directory(root: Path) -> Path:
    root = root.resolve()
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = root / f"subflow-{MIGRATION_ID}-{stamp}-{uuid.uuid4().hex[:8]}"
    path.mkdir(mode=0o700)
    return path


def apply_cutover(
    api: RootNocoBaseApi,
    validation_path: Path,
    *,
    output_root: Path = CUTOVER_ROOT,
    confirmation: str,
    admission_paused: str,
) -> dict[str, Any]:
    """Execute the exact reversible cutover after strict fresh prechecks."""
    _assert_13001_api(api)
    if confirmation != CUTOVER_CONFIRM:
        raise CutoverError("apply_cutover requires explicit cutover confirmation")
    if admission_paused != ADMISSION_PAUSED_CONFIRM:
        raise CutoverError("apply_cutover requires explicit admission-paused confirmation")
    supplied = _read_validation_file(validation_path)
    live = _fresh_validation()
    normalized = _assert_validation_agrees(supplied, live)
    snapshot, backup = _snapshot_precheck(api, live)

    run_dir = _new_run_directory(output_root)
    backup_path = run_dir / "pre-cutover-backup.redacted.json"
    checkpoint_path = run_dir / "checkpoint.json"
    _create_private_json(backup_path, backup)
    state = _build_state(validation_path, live, normalized, backup_path, snapshot)
    state["run_directory"] = str(run_dir)
    _checkpoint(checkpoint_path, state, "precheck_complete", {
        "legacy_count": len(cleanup.PUBLIC_LEGACY),
        "child_count": len(topology.BUSINESSES),
        "parent_id": normalized["ingress"]["id"],
    })

    category_id = _api_source_category_id(api)
    legacy, children, parent = _target_index(state)
    state["phase"] = "switching_children"
    _checkpoint(checkpoint_path, state, "cutover_started", {
        "order": ["enable_children", "disable_legacy", "enable_parent"],
    })
    try:
        for workflow_id, target in children.items():
            _set_enabled(
                api, workflow_id, target, category_id=category_id,
                expected_type="custom-action", enabled=True,
            )
            _checkpoint(checkpoint_path, state, "child_enabled", {"id": workflow_id, "business": target.get("business")})

        state["phase"] = "switching_legacy"
        _checkpoint(checkpoint_path, state, "all_children_enabled", {"count": len(children)})
        for workflow_id, target in legacy.items():
            _set_enabled(
                api, workflow_id, target, category_id=category_id,
                expected_type="collection", enabled=False,
            )
            _checkpoint(checkpoint_path, state, "legacy_disabled", {"id": workflow_id})

        state["phase"] = "enabling_parent"
        _checkpoint(checkpoint_path, state, "all_legacy_disabled", {"count": len(legacy)})
        _set_enabled(
            api, int(parent["id"]), parent, category_id=category_id,
            expected_type="collection", enabled=True,
        )
        _checkpoint(checkpoint_path, state, "parent_enabled", {"id": parent["id"]})

        verification = _verify_post_cutover(api, state)
        state["phase"] = "cutover_complete_pending_functional_acceptance"
        _checkpoint(checkpoint_path, state, "post_cutover_readback_passed", verification)
        return {
            "writes_remote": True,
            "environment": "13001",
            "migration_id": MIGRATION_ID,
            "cutover_complete": True,
            "deletions": 0,
            "checkpoint": str(checkpoint_path),
            "backup": str(backup_path),
            "verification": verification,
            "next_step": "Run controlled functional acceptance before any separately authorized retirement; this executor has no delete command.",
        }
    except Exception as exc:
        state["phase"] = "cutover_failed_rollback_armed"
        _checkpoint(checkpoint_path, state, "cutover_failed", {"error": str(exc)})
        try:
            _restore_previous_states(
                api, state, checkpoint_path, reason=f"automatic recovery after cutover error: {exc}"
            )
        except Exception as rollback_exc:
            raise CutoverError(
                f"cutover failed ({exc}); automatic rollback also failed ({rollback_exc}); inspect {checkpoint_path} immediately"
            ) from rollback_exc
        raise CutoverError(
            f"cutover failed and prior enable states were restored; see {checkpoint_path}: {exc}"
        ) from exc


def rollback(
    api: RootNocoBaseApi, checkpoint_path: Path, *, confirmation: str
) -> dict[str, Any]:
    """Explicitly restore a local cutover checkpoint; never deletes anything."""
    _assert_13001_api(api)
    if confirmation != ROLLBACK_CONFIRM:
        raise CutoverError("rollback requires explicit rollback confirmation")
    path = checkpoint_path.resolve()
    state = _load_json(path)
    if state.get("format") != CUTOVER_FORMAT or state.get("environment") != "13001":
        raise CutoverError("checkpoint is not a 13001 controlled-cutover checkpoint")
    if state.get("migration_id") != MIGRATION_ID or state.get("architecture") != topology.ARCHITECTURE:
        raise CutoverError("checkpoint does not belong to the reviewed multibranch migration")
    _restore_previous_states(api, state, path, reason="operator-requested rollback")
    return {
        "writes_remote": True,
        "environment": "13001",
        "migration_id": MIGRATION_ID,
        "rollback_complete": True,
        "deletions": 0,
        "checkpoint": str(path),
    }


def static_plan() -> dict[str, Any]:
    """No-write contract suitable for review and offline tests."""
    _assert_no_forbidden_targets()
    return {
        "format": CUTOVER_FORMAT,
        "writes_remote": False,
        "environment": "13001 only",
        "base_url": BASE_URL,
        "migration_id": MIGRATION_ID,
        "confirmation": {
            "cutover": CUTOVER_CONFIRM,
            "admission_paused": ADMISSION_PAUSED_CONFIRM,
            "rollback": ROLLBACK_CONFIRM,
        },
        "preconditions": [
            "successful saved --validate evidence for multibranch-20261019",
            "fresh remote --validate proof that parent and 12 children are disabled/static-valid",
            "exact 25 legacy IDs/keys/titles/categories are idle",
            "external Create/Update admission has been paused by the operator",
        ],
        "topology": {
            "parent": "one collection root multi-conditions with twelve direct business subflow branches",
            "children": "twelve custom-action children; each has one CREATE/UPDATE multi-conditions root",
            "forbidden": ["serial condition chain", "marker routing", "per-business collection event", "timer/FIFO"],
        },
        "operation_order": [
            "enable_exact_12_custom_action_children",
            "disable_exact_25_legacy_public_listeners",
            "enable_exact_single_parent_last",
            "read_back_all_enable_states",
        ],
        "preserve_ids": [target.id for target in cleanup.PRESERVE],
        "excluded_ids": [target.id for target in cleanup.OPTIONAL_UNPUBLISHED],
        "deletions": "not implemented",
        "rollback": "disable parent first, restore exact legacy snapshot, restore child snapshot",
    }


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--preflight", action="store_true", help="Remote read-only checks; no local checkpoint or remote mutation.")
    mode.add_argument("--apply", action="store_true", help="Run reversible enable-state cutover; no deletion path exists.")
    mode.add_argument("--rollback", type=Path, metavar="CHECKPOINT", help="Restore one local checkpoint's enable states; no deletion.")
    parser.add_argument("--validation", type=Path, help="Saved successful output from the reviewed builder --validate command.")
    parser.add_argument("--confirm", help="Required literal for --apply or --rollback.")
    parser.add_argument("--admission-paused", help="Required operator assertion for --apply.")
    parser.add_argument("--output-root", type=Path, default=CUTOVER_ROOT, help="Private local checkpoint root for --apply.")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON result.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if args.apply:
            if args.validation is None:
                raise CutoverError("--apply requires --validation PATH")
            if args.confirm != CUTOVER_CONFIRM:
                raise CutoverError("--apply requires --confirm " + CUTOVER_CONFIRM)
            if args.admission_paused != ADMISSION_PAUSED_CONFIRM:
                raise CutoverError("--apply requires --admission-paused " + ADMISSION_PAUSED_CONFIRM)
            result = apply_cutover(
                _require_api(),
                args.validation,
                output_root=args.output_root,
                confirmation=args.confirm,
                admission_paused=args.admission_paused,
            )
        elif args.preflight:
            if args.validation is None:
                raise CutoverError("--preflight requires --validation PATH")
            if args.confirm or args.admission_paused:
                raise CutoverError("--preflight does not accept --confirm or --admission-paused")
            result = preflight(_require_api(), args.validation)
        elif args.rollback:
            if args.validation is not None or args.admission_paused:
                raise CutoverError("--rollback accepts only CHECKPOINT and --confirm")
            if args.confirm != ROLLBACK_CONFIRM:
                raise CutoverError("--rollback requires --confirm " + ROLLBACK_CONFIRM)
            result = rollback(
                _require_api(), args.rollback, confirmation=args.confirm
            )
        else:
            if args.validation is not None or args.confirm or args.admission_paused:
                raise CutoverError("--validation/--confirm/--admission-paused require --preflight, --apply, or --rollback")
            result = static_plan()
        print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except CutoverError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
