#!/usr/bin/env python3
"""Write Apifox/Postman environments for local Kong and 211."""

from __future__ import annotations

import json
import os
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
ENV_DIR = ROOT / "apifox" / "environments"

LOCAL_BASE_URL = "https://127.0.0.1:28443"
REMOTE_211_BASE_URL = "https://119.91.104.211"


def _values(account: str, password: str, base_url: str) -> list[dict[str, object]]:
    return [
        {
            "key": "baseUrl",
            "value": base_url,
            "enabled": True,
            "type": "default",
        },
        {
            "key": "account",
            "value": account,
            "enabled": True,
            "type": "default",
        },
        {
            "key": "password",
            "value": password,
            "enabled": True,
            "type": "secret",
        },
        {
            "key": "accessToken",
            "value": "",
            "enabled": True,
            "type": "secret",
        },
        {
            "key": "authenticator",
            "value": "basic",
            "enabled": True,
            "type": "default",
        },
    ]


def _postman_environment(name: str, base_url: str, account: str, password: str) -> dict[str, object]:
    return {
        "id": str(uuid4()),
        "name": name,
        "values": _values(account, password, base_url),
        "_postman_variable_scope": "environment",
        "_postman_exported_using": "kong-nocoadapter/scripts/export_apifox_environments.py",
    }


def _apifox_environment(name: str, base_url: str, account: str, password: str) -> dict[str, object]:
    return {
        "name": name,
        "baseUrl": base_url,
        "baseUrls": {"default": base_url},
        "variables": [
            {"name": "account", "value": account},
            {"name": "password", "value": password},
            {"name": "accessToken", "value": ""},
            {"name": "authenticator", "value": "basic"},
        ],
    }


def main() -> None:
    account = os.environ.get("ACCOUNT", "op-test")
    password = os.environ.get("PASSWORD", "")
    ENV_DIR.mkdir(parents=True, exist_ok=True)

    templates = [
        ("本地测试", LOCAL_BASE_URL, "local.postman_environment.template.json"),
        ("211 开发服务器", REMOTE_211_BASE_URL, "211.postman_environment.template.json"),
    ]
    for name, base_url, filename in templates:
        path = ENV_DIR / filename
        path.write_text(
            json.dumps(
                _postman_environment(name, base_url, account, ""),
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        print(f"Wrote {path}")

    if not password:
        print("PASSWORD is empty; skipped local secret environment files")
        return

    local_bundle = [
        _apifox_environment("本地测试", LOCAL_BASE_URL, account, password),
        _apifox_environment("211 开发服务器", REMOTE_211_BASE_URL, account, password),
    ]
    secret_files = {
        "local.postman_environment.json": _postman_environment(
            "本地测试", LOCAL_BASE_URL, account, password
        ),
        "211.postman_environment.json": _postman_environment(
            "211 开发服务器", REMOTE_211_BASE_URL, account, password
        ),
        "apifox-environments.local.json": local_bundle,
    }
    for filename, payload in secret_files.items():
        path = ENV_DIR / filename
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(f"Wrote {path}")


if __name__ == "__main__":
    main()
