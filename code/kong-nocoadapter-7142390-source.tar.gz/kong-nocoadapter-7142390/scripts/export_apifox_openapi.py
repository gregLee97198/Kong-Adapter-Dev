#!/usr/bin/env python3
"""Export Kong DB-less routes as an Apifox-ready OpenAPI document."""

from __future__ import annotations

import json
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from typing import Any

from app.main import ADAPTER_VERSION, create_app
from app.models import (
    CreateIntakeForChangeBedsRequest,
    CreateIntakeForChangeDirectorsRequest,
    CreateIntakeForChangeHomeManagerRequest,
    CreateIntakeForChangeNurseInChargeRequest,
    CreateIntakeForChangeOperationModeRequest,
    CreateIntakeForChangingHomeRequest,
    CreateIntakeForExpansionAipRequest,
    CreateIntakeForNewLicenceRequest,
    CreateIntakeForProsecutionRequest,
    CreateIntakeForRevokeLicenceRequest,
    CreateIntakeForRpRequest,
    CreateIntakeForSelfWithdrawRequest,
    CreateIntakeForSpecificHourRequest,
    CreateLicenceRenewalRequest,
    UpdateChangeBedsDataRequest,
    UpdateChangeDirectorsDataRequest,
    UpdateChangeHomeManagerDataRequest,
    UpdateChangeNurseInChargeDataRequest,
    UpdateChangeOperationModeDataRequest,
    UpdateChangingHomeDataRequest,
    UpdateExpansionAipDataRequest,
    UpdateLicenceRenewalDataRequest,
    UpdateNewLicenceDataRequest,
    UpdateProsecutionDataRequest,
    UpdateRevokeLicenceDataRequest,
    UpdateRpDataRequest,
    UpdateSelfWithdrawDataRequest,
    UpdateSpecificHourDataRequest,
)
from app.nocobase_config import NocoBaseProfile
from app.settings import Settings

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "apifox" / "nocobase-kong-dbless.openapi.yaml"
MODELS_OUTPUT = ROOT / "apifox" / "models" / "kong-request-bodies.openapi.yaml"

HOME_CASE = {
    "office_code": "LORCHE",
    "lorche_d_no": "L0043",
    "submitter_user_id": 12,
    "task_owner_user_id": 45,
    "task_owner_post_code": "S(LR)1",
    "source_other": "OP",
}

NLA_EXAMPLE = {
    "request_id": "NLA-20260903-0001",
    "form_data": {
        "case_summary": {
            "office_code": "LORCHE",
            "submitter_user_id": 12,
            "task_owner_user_id": 45,
            "task_owner_post_code": "S(LR)1",
        },
        "part_1": {
            "application_received_date": "2026-09-03",
            "tentative_commencement_date": "2026-12-01",
        },
        "part_2": {
            "rch_name_en": "Acceptance Test RCH",
            "rch_name_cn": "驗收測試院舍",
            "operation_mode_id": 1,
            "premises_type": "0",
            "monthly_fee_min": 8000,
            "monthly_fee_max": 12000,
            "gender": "1",
            "floor_area_sqm": 380.5,
            "licence_capacity": 48,
            "rch_type_code": "a1",
            "nursing_home_places": 12,
            "care_and_attention_home_places": 12,
            "aged_home_places": 12,
            "self_care_hostel_places": 12,
            "address": {
                "region_code": "0",
                "district_code": "C",
                "sub_district_code": "Admiralty",
                "full_name_en": "1 Test Road, Admiralty, Hong Kong",
                "full_name_cn": "香港金鐘測試道一號",
            },
            "premises": {
                "self_owned": [
                    {
                        "premise_type": "0",
                        "location": "Hong Kong",
                        "tenancy_from": "2026-01-01",
                        "tenancy_to": "2036-12-31",
                        "address": {
                            "region_code": "0",
                            "district_code": "C",
                            "sub_district_code": "Admiralty",
                            "full_name_en": "1 Test Road, Admiralty, Hong Kong",
                            "full_name_cn": "香港金鐘測試道一號",
                        },
                    }
                ],
                "rented": [],
            },
        },
        "part_3": {
            "rch_business_status": "0",
            "applicant_operator_type": "0",
            "operator": {"full_name_en": "Test Operator"},
            "personnel": [],
        },
        "part_4": {
            "authorised_representative": {"full_name_en": "Test Representative"}
        },
        "part_5": {
            "application_level": "normal",
            "comments": "Gateway acceptance test",
            "attachment_ids": [501],
            "checklist": [
                {
                    "position_code": "LORCHE_STAGE2:ROW:35",
                    "checked": True,
                    "status": "1",
                    "attachment_id": 502,
                }
            ],
        },
    },
}

AIP_EXAMPLE = {
    "request_id": "AIP-20260924-0001",
    "form_data": {
        "case_summary": {
            "office_code": "LORCHE",
            "lorche_d_no": "L0043",
            "received_date": "2026-09-24",
            "severity": "0",
        },
        "part_1": {
            "title": "0",
            "name_eng": "Example Applicant",
            "name_chi": "示例申请人",
            "authorised_to_apply_by_operator": True,
            "means_of_authorisation": "0",
            "authorised_name_eng": "Example Authorised Person",
            "hkic_number1": "A123456",
            "hkic_number2": "7",
        },
        "part_2": {
            "address_chi_expansion": "香港示例扩建地址",
            "address_eng_expansion": "Example expansion address, Hong Kong",
            "tentative_licencing_capacity_expansion": 120,
            "tentative_area_of_floor_space_expansion": 580.5,
            "number_of_beds_expansion": 100,
        },
        "part_3": {
            "checklist": [
                {
                    "position_code": "LORCHE_EXPANSION_AIP_001",
                    "attachment_id": 501,
                }
            ]
        },
    },
}

ACCEPTED_CREATE = {
    "accepted": True,
    "request_id": "REQ-001",
    "create_id": 9001,
    "status": "Accepted",
    "source_system": "OP",
    "request_event": "CREATE",
    "api_type": "create_intake_for_new_licence",
    "intake_id": None,
    "application_id": None,
    "message": "Request submitted",
    "message_zh": "请求已提交",
}

PATH_META: dict[str, dict[str, Any]] = {
    "/health/live": {
        "folder": "01-健康检查",
        "tag": "01-健康检查",
        "summary": "存活检查",
        "auth": False,
    },
    "/health/ready": {
        "folder": "01-健康检查",
        "tag": "01-健康检查",
        "summary": "就绪检查",
        "auth": False,
    },
    "/v1/auth/token": {
        "folder": "02-认证",
        "tag": "02-认证",
        "summary": "账号密码换 NocoBase 原生 Token",
        "auth": False,
    },
    "/simple-test": {
        "folder": "03-连通测试",
        "tag": "03-连通测试",
        "summary": "连通工作流",
        "auth": True,
    },
    "/homerecord-query": {
        "folder": "03-连通测试",
        "tag": "03-连通测试",
        "summary": "Home Record 查询",
        "auth": True,
    },
    "/v1/files": {
        "folder": "04-文件",
        "tag": "04-文件",
        "summary": "统一文件上传",
        "auth": True,
    },
    "/v1/files/{attachment_id}": {
        "folder": "04-文件",
        "tag": "04-文件",
        "summary": "按附件 ID 下载文件",
        "auth": True,
    },
    "/v1/requests/{record_id}": {
        "folder": "05-查询",
        "tag": "05-查询",
        "summary": "按 Staging 记录 ID 查询请求状态",
        "auth": True,
    },
    "/v1/request/{create_id}": {
        "folder": "05-查询",
        "tag": "05-查询",
        "summary": "按 create_id 查询请求详情",
        "auth": True,
    },
    "/v1/intakes": {
        "folder": "05-查询",
        "tag": "05-查询",
        "summary": "查询 Intake 列表",
        "auth": True,
    },
    "/v1/new-licence-applications": {
        "folder": "06-New Licence",
        "tag": "06-New Licence",
        "summary": "查询 New Licence Application",
        "auth": True,
    },
    "/v1/new-licence-checklist": {
        "folder": "06-New Licence",
        "tag": "06-New Licence",
        "summary": "查询 New Licence Checklist",
        "auth": True,
    },
    "/v1/create_intake_for_new_licence": {
        "folder": "06-New Licence",
        "tag": "06-New Licence",
        "summary": "创建 New Licence Intake",
        "auth": True,
        "model": CreateIntakeForNewLicenceRequest,
        "example": NLA_EXAMPLE,
    },
    "/v1/update_new_licence_data": {
        "folder": "06-New Licence",
        "tag": "06-New Licence",
        "summary": "更新 New Licence 数据",
        "auth": True,
        "model": UpdateNewLicenceDataRequest,
        "example": {
            "request_id": "NLA-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"part_5": {"comments": "Updated through API"}},
        },
    },
    "/v1/create_intake_for_changing_home": {
        "folder": "07-Changing Home",
        "tag": "07-Changing Home",
        "summary": "创建 Changing Home Intake",
        "auth": True,
        "model": CreateIntakeForChangingHomeRequest,
        "example": {
            "request_id": "CHI-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "is_change_name": True,
                "part_5": {"comments": "CHI gateway acceptance"},
            },
        },
    },
    "/v1/update_changing_home_data": {
        "folder": "07-Changing Home",
        "tag": "07-Changing Home",
        "summary": "更新 Changing Home 数据",
        "auth": True,
        "model": UpdateChangingHomeDataRequest,
        "example": {
            "request_id": "CHI-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"part_5": {"comments": "Updated through API"}},
        },
    },
    "/v1/changing-home-checklist": {
        "folder": "07-Changing Home",
        "tag": "07-Changing Home",
        "summary": "查询 Changing Home Checklist",
        "auth": True,
    },
    "/v1/create_intake_for_self_withdraw": {
        "folder": "08-Self Withdraw",
        "tag": "08-Self Withdraw",
        "summary": "创建 Self Withdraw Intake",
        "auth": True,
        "model": CreateIntakeForSelfWithdrawRequest,
        "example": {
            "request_id": "SW-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "reason_for_closure": "0",
                "comments": "Phase D self-withdraw",
            },
        },
    },
    "/v1/update_self_withdraw_data": {
        "folder": "08-Self Withdraw",
        "tag": "08-Self Withdraw",
        "summary": "更新 Self Withdraw 数据",
        "auth": True,
        "model": UpdateSelfWithdrawDataRequest,
        "example": {
            "request_id": "SW-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/self-withdraw-checklist": {
        "folder": "08-Self Withdraw",
        "tag": "08-Self Withdraw",
        "summary": "查询 Self Withdraw Checklist",
        "auth": True,
    },
    "/v1/create_intake_for_revoke_licence": {
        "folder": "09-Revoke Licence",
        "tag": "09-Revoke Licence",
        "summary": "创建 Revoke Licence Intake",
        "auth": True,
        "model": CreateIntakeForRevokeLicenceRequest,
        "example": {
            "request_id": "REV-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "comments": "Revoke licence",
            },
        },
    },
    "/v1/update_revoke_licence_data": {
        "folder": "09-Revoke Licence",
        "tag": "09-Revoke Licence",
        "summary": "更新 Revoke Licence 数据",
        "auth": True,
        "model": UpdateRevokeLicenceDataRequest,
        "example": {
            "request_id": "REV-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/create_intake_for_specific_hour": {
        "folder": "10-Specific Hour",
        "tag": "10-Specific Hour",
        "summary": "创建 Specific Hour Intake",
        "auth": True,
        "model": CreateIntakeForSpecificHourRequest,
        "example": {
            "request_id": "SH-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "application_detail": "approval",
                "rch_care_level": "0",
                "comments": "Phase E specific hour",
            },
        },
    },
    "/v1/update_specific_hour_data": {
        "folder": "10-Specific Hour",
        "tag": "10-Specific Hour",
        "summary": "更新 Specific Hour 数据",
        "auth": True,
        "model": UpdateSpecificHourDataRequest,
        "example": {
            "request_id": "SH-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/specific-hour-checklist": {
        "folder": "10-Specific Hour",
        "tag": "10-Specific Hour",
        "summary": "查询 Specific Hour Checklist",
        "auth": True,
    },
    "/v1/create_intake_for_rp": {
        "folder": "11-Responsible Person",
        "tag": "11-Responsible Person",
        "summary": "创建 Responsible Person Intake",
        "auth": True,
        "model": CreateIntakeForRpRequest,
        "example": {
            "request_id": "RP-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "rp_name_en": "Example RP",
                "comments": "Phase E RP",
            },
        },
    },
    "/v1/update_rp_data": {
        "folder": "11-Responsible Person",
        "tag": "11-Responsible Person",
        "summary": "更新 Responsible Person 数据",
        "auth": True,
        "model": UpdateRpDataRequest,
        "example": {
            "request_id": "RP-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/rp-checklist": {
        "folder": "11-Responsible Person",
        "tag": "11-Responsible Person",
        "summary": "查询 Responsible Person Checklist",
        "auth": True,
    },
    "/v1/create_intake_for_change_home_manager": {
        "folder": "12-Change Home Manager",
        "tag": "12-Change Home Manager",
        "summary": "创建 Change Home Manager Intake",
        "auth": True,
        "model": CreateIntakeForChangeHomeManagerRequest,
        "example": {
            "request_id": "CHG-MGR-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "proposed_name": "Example Manager",
                "comments": "Phase F home manager",
            },
        },
    },
    "/v1/update_change_home_manager_data": {
        "folder": "12-Change Home Manager",
        "tag": "12-Change Home Manager",
        "summary": "更新 Change Home Manager 数据",
        "auth": True,
        "model": UpdateChangeHomeManagerDataRequest,
        "example": {
            "request_id": "CHG-MGR-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/create_intake_for_change_beds": {
        "folder": "13-Change Beds",
        "tag": "13-Change Beds",
        "summary": "创建 Change Beds Intake",
        "auth": True,
        "model": CreateIntakeForChangeBedsRequest,
        "example": {
            "request_id": "CHG-BEDS-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "proposed_beds_nursing": 10,
                "comments": "Phase F change beds",
            },
        },
    },
    "/v1/update_change_beds_data": {
        "folder": "13-Change Beds",
        "tag": "13-Change Beds",
        "summary": "更新 Change Beds 数据",
        "auth": True,
        "model": UpdateChangeBedsDataRequest,
        "example": {
            "request_id": "CHG-BEDS-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/create_intake_for_change_operation_mode": {
        "folder": "14-Change Operation Mode",
        "tag": "14-Change Operation Mode",
        "summary": "创建 Change Operation Mode Intake",
        "auth": True,
        "model": CreateIntakeForChangeOperationModeRequest,
        "example": {
            "request_id": "CHG-OM-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "comments": "Phase F operation mode",
            },
        },
    },
    "/v1/update_change_operation_mode_data": {
        "folder": "14-Change Operation Mode",
        "tag": "14-Change Operation Mode",
        "summary": "更新 Change Operation Mode 数据",
        "auth": True,
        "model": UpdateChangeOperationModeDataRequest,
        "example": {
            "request_id": "CHG-OM-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/create_intake_for_change_directors": {
        "folder": "15-Change Directors",
        "tag": "15-Change Directors",
        "summary": "创建 Change Directors Intake",
        "auth": True,
        "model": CreateIntakeForChangeDirectorsRequest,
        "example": {
            "request_id": "CHG-DIR-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "comments": "Phase F directors",
            },
        },
    },
    "/v1/update_change_directors_data": {
        "folder": "15-Change Directors",
        "tag": "15-Change Directors",
        "summary": "更新 Change Directors 数据",
        "auth": True,
        "model": UpdateChangeDirectorsDataRequest,
        "example": {
            "request_id": "CHG-DIR-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/create_intake_for_change_nurse_in_charge": {
        "folder": "16-Change Nurse in Charge",
        "tag": "16-Change Nurse in Charge",
        "summary": "创建 Change Nurse in Charge Intake",
        "auth": True,
        "model": CreateIntakeForChangeNurseInChargeRequest,
        "example": {
            "request_id": "CHG-NURSE-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "name": "Example Nurse",
                "comments": "Phase F nurse in charge",
            },
        },
    },
    "/v1/update_change_nurse_in_charge_data": {
        "folder": "16-Change Nurse in Charge",
        "tag": "16-Change Nurse in Charge",
        "summary": "更新 Change Nurse in Charge 数据",
        "auth": True,
        "model": UpdateChangeNurseInChargeDataRequest,
        "example": {
            "request_id": "CHG-NURSE-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/create_intake_for_prosecution": {
        "folder": "17-Prosecution",
        "tag": "17-Prosecution",
        "summary": "创建 Prosecution Intake",
        "auth": True,
        "model": CreateIntakeForProsecutionRequest,
        "example": {
            "request_id": "PRO-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "legal_advice_result": "Go for Prosecution",
                "unlicenced_rch": False,
                "comments": "Phase G prosecution",
                "offence_items": [],
            },
        },
    },
    "/v1/update_prosecution_data": {
        "folder": "17-Prosecution",
        "tag": "17-Prosecution",
        "summary": "更新 Prosecution 数据",
        "auth": True,
        "model": UpdateProsecutionDataRequest,
        "example": {
            "request_id": "PRO-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"comments": "Updated through API"},
        },
    },
    "/v1/licence-renewal-checklist": {
        "folder": "18-Licence Renewal",
        "tag": "18-Licence Renewal",
        "summary": "查询 Licence Renewal Checklist",
        "auth": True,
    },
    "/v1/create_licence_renewal": {
        "folder": "18-Licence Renewal",
        "tag": "18-Licence Renewal",
        "summary": "创建 Licence Renewal",
        "auth": True,
        "model": CreateLicenceRenewalRequest,
        "example": {
            "request_id": "LRN-20260914-0001",
            "form_data": {
                "case_summary": HOME_CASE,
                "part_5": {"comments": "Renewal skeleton"},
            },
        },
    },
    "/v1/update_licence_renewal_data": {
        "folder": "18-Licence Renewal",
        "tag": "18-Licence Renewal",
        "summary": "更新 Licence Renewal 数据",
        "auth": True,
        "model": UpdateLicenceRenewalDataRequest,
        "example": {
            "request_id": "LRN-UPDATE-0001",
            "create_id": "9001",
            "form_data": {"part_5": {"comments": "Updated through API"}},
        },
    },
    "/v1/expansion-aip-checklist": {
        "folder": "19-Expansion AIP",
        "tag": "19-Expansion AIP",
        "summary": "查询 Expansion AIP Checklist",
        "auth": True,
    },
    "/v1/create_intake_for_expansion_aip": {
        "folder": "19-Expansion AIP",
        "tag": "19-Expansion AIP",
        "summary": "创建 Expansion AIP Intake",
        "auth": True,
        "model": CreateIntakeForExpansionAipRequest,
        "example": AIP_EXAMPLE,
    },
    "/v1/update_expansion_aip_data": {
        "folder": "19-Expansion AIP",
        "tag": "19-Expansion AIP",
        "summary": "更新 Expansion AIP 数据",
        "auth": True,
        "model": UpdateExpansionAipDataRequest,
        "example": {
            "request_id": "AIP-UPDATE-0001",
            "create_id": "9001",
            "form_data": {
                "case_summary": {
                    "received_date": "2026-09-25",
                    "severity": "1",
                },
                "part_2": {"number_of_beds_expansion": 110},
                "part_3": {
                    "checklist": [
                        {
                            "position_code": "LORCHE_EXPANSION_AIP_001",
                            "attachment_id": 502,
                        }
                    ]
                },
            },
        },
    },
}

SCHEMA_META: dict[str, dict[str, str]] = {
    "CreateIntakeForNewLicenceRequest": {
        "title": "NLA Create 请求",
        "x-apifox-folder": "数据模型/NLA",
        "description": "POST /v1/create_intake_for_new_licence",
    },
    "UpdateNewLicenceDataRequest": {
        "title": "NLA Update 请求",
        "x-apifox-folder": "数据模型/NLA",
        "description": "POST /v1/update_new_licence_data",
    },
    "NewLicenceFormData": {
        "title": "NLA form_data",
        "x-apifox-folder": "数据模型/NLA",
    },
    "UpdateNewLicenceFormData": {
        "title": "NLA Update form_data",
        "x-apifox-folder": "数据模型/NLA",
    },
    "CreateIntakeForChangingHomeRequest": {
        "title": "CHI Create 请求",
        "x-apifox-folder": "数据模型/CHI",
        "description": "POST /v1/create_intake_for_changing_home",
    },
    "UpdateChangingHomeDataRequest": {
        "title": "CHI Update 请求",
        "x-apifox-folder": "数据模型/CHI",
        "description": "POST /v1/update_changing_home_data",
    },
    "ChangingHomeFormData": {
        "title": "CHI form_data",
        "x-apifox-folder": "数据模型/CHI",
    },
    "UpdateChangingHomeFormData": {
        "title": "CHI Update form_data",
        "x-apifox-folder": "数据模型/CHI",
    },
    "CreateLicenceRenewalRequest": {
        "title": "LRN Create 请求",
        "x-apifox-folder": "数据模型/LRN",
        "description": "POST /v1/create_licence_renewal",
    },
    "UpdateLicenceRenewalDataRequest": {
        "title": "LRN Update 请求",
        "x-apifox-folder": "数据模型/LRN",
        "description": "POST /v1/update_licence_renewal_data",
    },
    "LicenceRenewalFormData": {
        "title": "LRN form_data",
        "x-apifox-folder": "数据模型/LRN",
    },
    "UpdateLicenceRenewalFormData": {
        "title": "LRN Update form_data",
        "x-apifox-folder": "数据模型/LRN",
    },
    "CreateIntakeForExpansionAipRequest": {
        "title": "Expansion AIP Create 请求",
        "x-apifox-folder": "数据模型/Expansion AIP",
        "description": "POST /v1/create_intake_for_expansion_aip",
    },
    "UpdateExpansionAipDataRequest": {
        "title": "Expansion AIP Update 请求",
        "x-apifox-folder": "数据模型/Expansion AIP",
        "description": "POST /v1/update_expansion_aip_data",
    },
    "ExpansionAipFormData": {
        "title": "Expansion AIP form_data",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "UpdateExpansionAipFormData": {
        "title": "Expansion AIP Update form_data",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "ExpansionAipPart1Payload": {
        "title": "Expansion AIP Part 1",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "ExpansionAipPart2Payload": {
        "title": "Expansion AIP Part 2",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "ExpansionAipPart3Payload": {
        "title": "Expansion AIP Part 3",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "UpdateExpansionAipPart1Payload": {
        "title": "Expansion AIP Update Part 1",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "UpdateExpansionAipPart2Payload": {
        "title": "Expansion AIP Update Part 2",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "UpdateExpansionAipPart3Payload": {
        "title": "Expansion AIP Update Part 3",
        "x-apifox-folder": "数据模型/Expansion AIP",
    },
    "CreateIntakeForSpecificHourRequest": {
        "title": "SH Create 请求",
        "x-apifox-folder": "数据模型/SH",
        "description": "POST /v1/create_intake_for_specific_hour",
    },
    "UpdateSpecificHourDataRequest": {
        "title": "SH Update 请求",
        "x-apifox-folder": "数据模型/SH",
        "description": "POST /v1/update_specific_hour_data",
    },
    "SpecificHourFormData": {
        "title": "SH form_data",
        "x-apifox-folder": "数据模型/SH",
    },
    "UpdateSpecificHourFormData": {
        "title": "SH Update form_data",
        "x-apifox-folder": "数据模型/SH",
    },
    "CreateIntakeForRpRequest": {
        "title": "RP Create 请求",
        "x-apifox-folder": "数据模型/RP",
        "description": "POST /v1/create_intake_for_rp",
    },
    "UpdateRpDataRequest": {
        "title": "RP Update 请求",
        "x-apifox-folder": "数据模型/RP",
        "description": "POST /v1/update_rp_data",
    },
    "ResponsiblePersonFormData": {
        "title": "RP form_data",
        "x-apifox-folder": "数据模型/RP",
    },
    "UpdateResponsiblePersonFormData": {
        "title": "RP Update form_data",
        "x-apifox-folder": "数据模型/RP",
    },
    "CreateIntakeForChangeHomeManagerRequest": {
        "title": "Change Home Manager Create 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/create_intake_for_change_home_manager",
    },
    "UpdateChangeHomeManagerDataRequest": {
        "title": "Change Home Manager Update 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/update_change_home_manager_data",
    },
    "ChangeHomeManagerFormData": {
        "title": "Change Home Manager form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "UpdateChangeHomeManagerFormData": {
        "title": "Change Home Manager Update form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "CreateIntakeForChangeBedsRequest": {
        "title": "Change Beds Create 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/create_intake_for_change_beds",
    },
    "UpdateChangeBedsDataRequest": {
        "title": "Change Beds Update 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/update_change_beds_data",
    },
    "ChangeBedsFormData": {
        "title": "Change Beds form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "UpdateChangeBedsFormData": {
        "title": "Change Beds Update form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "CreateIntakeForChangeOperationModeRequest": {
        "title": "Change Operation Mode Create 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/create_intake_for_change_operation_mode",
    },
    "UpdateChangeOperationModeDataRequest": {
        "title": "Change Operation Mode Update 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/update_change_operation_mode_data",
    },
    "ChangeOperationModeFormData": {
        "title": "Change Operation Mode form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "UpdateChangeOperationModeFormData": {
        "title": "Change Operation Mode Update form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "CreateIntakeForChangeDirectorsRequest": {
        "title": "Change Directors Create 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/create_intake_for_change_directors",
    },
    "UpdateChangeDirectorsDataRequest": {
        "title": "Change Directors Update 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/update_change_directors_data",
    },
    "ChangeDirectorsFormData": {
        "title": "Change Directors form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "UpdateChangeDirectorsFormData": {
        "title": "Change Directors Update form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "CreateIntakeForChangeNurseInChargeRequest": {
        "title": "Change Nurse in Charge Create 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/create_intake_for_change_nurse_in_charge",
    },
    "UpdateChangeNurseInChargeDataRequest": {
        "title": "Change Nurse in Charge Update 请求",
        "x-apifox-folder": "数据模型/Change",
        "description": "POST /v1/update_change_nurse_in_charge_data",
    },
    "ChangeNurseInChargeFormData": {
        "title": "Change Nurse in Charge form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "UpdateChangeNurseInChargeFormData": {
        "title": "Change Nurse in Charge Update form_data",
        "x-apifox-folder": "数据模型/Change",
    },
    "CreateIntakeForProsecutionRequest": {
        "title": "Prosecution Create 请求",
        "x-apifox-folder": "数据模型/Prosecution",
        "description": "POST /v1/create_intake_for_prosecution",
    },
    "UpdateProsecutionDataRequest": {
        "title": "Prosecution Update 请求",
        "x-apifox-folder": "数据模型/Prosecution",
        "description": "POST /v1/update_prosecution_data",
    },
    "ProsecutionFormData": {
        "title": "Prosecution form_data",
        "x-apifox-folder": "数据模型/Prosecution",
    },
    "UpdateProsecutionFormData": {
        "title": "Prosecution Update form_data",
        "x-apifox-folder": "数据模型/Prosecution",
    },
    "OffenceChargedItemPayload": {
        "title": "Prosecution 控罪项",
        "x-apifox-folder": "数据模型/Prosecution",
    },
    "AddressPayload": {
        "title": "公共 Address",
        "x-apifox-folder": "数据模型/公共",
    },
    "UpdateAddressPayload": {
        "title": "公共 Address Update",
        "x-apifox-folder": "数据模型/公共",
    },
    "CaseSummaryPayload": {
        "title": "公共 CaseSummary",
        "x-apifox-folder": "数据模型/公共",
    },
    "ChangingHomeCaseSummaryPayload": {
        "title": "公共 HomeBound CaseSummary",
        "x-apifox-folder": "数据模型/公共",
    },
    "UpdateCaseSummaryPayload": {
        "title": "公共 CaseSummary Update",
        "x-apifox-folder": "数据模型/公共",
    },
    "UpdateChangingHomeCaseSummaryPayload": {
        "title": "公共 HomeBound CaseSummary Update",
        "x-apifox-folder": "数据模型/公共",
    },
    "UpdateHomeBoundCaseSummaryPayload": {
        "title": "公共 HomeBound Intake CaseSummary Update",
        "x-apifox-folder": "数据模型/公共",
    },
    "ChecklistItemPayload": {
        "title": "公共 ChecklistItem",
        "x-apifox-folder": "数据模型/公共",
    },
    "ContactPayload": {
        "title": "公共 Contact",
        "x-apifox-folder": "数据模型/公共",
    },
    "PremisePayload": {
        "title": "公共 Premise",
        "x-apifox-folder": "数据模型/公共",
    },
    "PremisesPayload": {
        "title": "公共 Premises",
        "x-apifox-folder": "数据模型/公共",
    },
}


def _settings() -> Settings:
    profile = replace(
        NocoBaseProfile.load(ROOT / "config" / "nocobase.yaml"),
        base_url="http://example.test/cmtf2",
        storage_selection="default",
        storage_name=None,
    )
    return Settings(
        nocobase=profile,
        nocobase_config_token="unused-for-openapi",
        verify_tls=True,
        storage_cache_seconds=0,
        max_file_bytes=1024,
        allowed_mime_types=frozenset({"application/pdf"}),
        connect_timeout_seconds=1,
        request_timeout_seconds=1,
        upload_timeout_seconds=1,
        max_connections=5,
        log_level="INFO",
    )


def _json_schema(model: type) -> tuple[dict[str, Any], dict[str, Any]]:
    schema = model.model_json_schema(ref_template="#/components/schemas/{model}")
    defs = schema.pop("$defs", {}) or {}
    name = model.__name__
    defs[name] = schema
    return {"$ref": f"#/components/schemas/{name}"}, defs


TOKEN_CAPTURE_SCRIPT = """
try {
  const json = pm.response.json();
  const token = json && json.data && json.data.token;
  if (token) {
    pm.environment.set("accessToken", token);
  }
} catch (e) {
  console.log("failed to save accessToken", e);
}
""".strip()


def _json_body(schema: dict[str, Any], example: object | None = None) -> dict[str, Any]:
    media: dict[str, Any] = {"schema": schema}
    if example is not None:
        media["example"] = example
    return {
        "required": True,
        "content": {"application/json": media},
    }


def _auth_token_operation() -> dict[str, Any]:
    return {
        "tags": ["02-认证"],
        "summary": "账号密码换 NocoBase 原生 Token",
        "operationId": "issueNativeToken",
        "description": (
            "使用账号密码获取 NocoBase 原生 Token；错误返回统一 error 对象。"
            "账号和密码使用当前 Apifox 环境变量 `{{account}}` / `{{password}}`。"
            "成功后把 `data.token` 写入环境变量 `accessToken`，"
            "再切换环境即可测本地或 211。"
        ),
        "security": [],
        "x-apifox-folder": "02-认证",
        "x-apifox-status": "released",
        "x-apifox": {
            "afterScript": TOKEN_CAPTURE_SCRIPT,
        },
        "x-apifox-post-processors": [
            {"type": "customScript", "data": TOKEN_CAPTURE_SCRIPT},
        ],
        "requestBody": _json_body(
            {
                "type": "object",
                "required": ["account", "password"],
                "properties": {
                    "account": {"type": "string"},
                    "password": {"type": "string", "format": "password"},
                },
            },
            {
                "account": "{{account}}",
                "password": "{{password}}",
            },
        ),
        "responses": {
            "200": {
                "description": "登录成功，返回 NocoBase 原生 Token",
                "content": {
                    "application/json": {
                        "schema": {"type": "object", "additionalProperties": True},
                        "example": {
                            "data": {
                                "token": "{{accessToken}}",
                                "user": {"id": 12},
                            }
                        },
                    }
                },
            },
            "400": {"description": "缺少账号或密码"},
            "401": {"description": "凭据无效"},
            "429": {"description": "认证请求超过限流"},
            "502": {"description": "上游响应无效"},
            "503": {"description": "认证服务不可用"},
        },
    }


def build_spec() -> dict[str, Any]:
    spec = deepcopy(create_app(_settings()).openapi())
    spec["info"] = {
        "title": "nocobase-kong DB-less",
        "version": ADAPTER_VERSION,
        "description": (
            "当前开发中的 Kong DB-less 对外接口，用于 Apifox 项目 "
            "`nocobase-kong` 可视化调试。\n\n"
            "右上角切换环境：\n"
            "- 本地测试：`https://127.0.0.1:28443`（本机 Compose，上游 211:13001）\n"
            "- 211 开发服务器：`https://119.91.104.211`（443）\n\n"
            "初始测试账号使用环境变量 `account` / `password`。"
            "先跑 `POST /v1/auth/token`，再测其它接口。"
            "本机 HTTPS 是自签名证书，Apifox 需关闭 SSL 证书校验。\n"
            "除登录与健康检查外，均使用客户 NocoBase 原生 Bearer Token。"
            "旧 `/oauth2/token` 不再发布。"
        ),
    }
    spec["servers"] = [
        {
            "url": "https://127.0.0.1:28443",
            "description": "本地测试",
        },
        {
            "url": "https://119.91.104.211",
            "description": "211 开发服务器",
        },
    ]
    spec.setdefault("components", {})
    spec["components"].setdefault("schemas", {})
    spec["components"]["securitySchemes"] = {
        "bearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "NocoBase native token",
            "description": (
                "使用环境变量 {{accessToken}}。"
                "先在当前环境调用 POST /v1/auth/token。"
            ),
        }
    }
    spec["security"] = [{"bearerAuth": []}]

    spec["paths"]["/v1/auth/token"] = {"post": _auth_token_operation()}

    tags: list[dict[str, str]] = []
    seen_tags: set[str] = set()
    for path, meta in PATH_META.items():
        tag = meta["tag"]
        if tag not in seen_tags:
            tags.append({"name": tag})
            seen_tags.add(tag)
        methods = spec["paths"].setdefault(path, {})
        for method, operation in methods.items():
            if method.startswith("x-") or not isinstance(operation, dict):
                continue
            operation["tags"] = [tag]
            operation["summary"] = meta["summary"]
            operation["x-apifox-folder"] = meta["folder"]
            operation["x-apifox-status"] = "released"
            if meta.get("auth"):
                operation["security"] = [{"bearerAuth": []}]
                params = list(operation.get("parameters") or [])
                for param in params:
                    if (
                        isinstance(param, dict)
                        and param.get("name") == "Authorization"
                    ):
                        param["example"] = "Bearer {{accessToken}}"
                operation["parameters"] = params
            else:
                operation["security"] = []
            model = meta.get("model")
            if model is not None:
                schema, defs = _json_schema(model)
                example = meta.get("example")
                if example is not None:
                    defs[model.__name__]["example"] = example
                spec["components"]["schemas"].update(defs)
                operation["requestBody"] = _json_body(schema, example)
                if path.startswith("/v1/create_") or path.startswith("/v1/update_"):
                    example = deepcopy(ACCEPTED_CREATE)
                    if "create_" in path:
                        example["api_type"] = path.rsplit("/", 1)[-1]
                    else:
                        example["request_event"] = "UPDATE"
                        example["api_type"] = path.rsplit("/", 1)[-1]
                    operation.setdefault("responses", {}).setdefault(
                        "200",
                        {
                            "description": "Staging 已接收",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "additionalProperties": True,
                                    },
                                    "example": example,
                                }
                            },
                        },
                    )

    spec["tags"] = tags
    _annotate_schemas(spec["components"]["schemas"])
    return spec


def _annotate_schemas(schemas: dict[str, Any]) -> None:
    for name, schema in schemas.items():
        if not isinstance(schema, dict):
            continue
        meta = SCHEMA_META.get(name)
        if meta:
            schema["title"] = meta["title"]
            schema["x-apifox-folder"] = meta["x-apifox-folder"]
            if meta.get("description"):
                schema["description"] = meta["description"]
        properties = schema.get("properties")
        if isinstance(properties, dict) and properties:
            schema["x-apifox-orders"] = list(properties.keys())


def dump_yaml(data: dict[str, Any], path: Path) -> None:
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover
        raise SystemExit("PyYAML is required to write the OpenAPI file") from exc

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(
            data,
            allow_unicode=True,
            sort_keys=False,
            default_flow_style=False,
        ),
        encoding="utf-8",
    )


def main() -> None:
    spec = build_spec()
    dump_yaml(spec, OUTPUT)
    json_path = OUTPUT.with_suffix(".json")
    json_path.write_text(
        json.dumps(spec, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    named = [
        name
        for name, schema in spec["components"]["schemas"].items()
        if isinstance(schema, dict) and schema.get("x-apifox-folder", "").startswith(
            "数据模型/"
        )
    ]
    models_spec = {
        "openapi": spec.get("openapi", "3.1.0"),
        "info": {
            "title": "Kong 请求 Body 数据模型",
            "version": spec["info"]["version"],
            "description": (
                "NLA / CHI / LRN / Expansion AIP / SH / RP / 5 Change / "
                "Prosecution "
                "的 Create/Update 请求体数据模型。"
                "导入 OpenAPI 后会出现在 Apifox「数据模型」。"
            ),
        },
        "paths": {},
        "components": {"schemas": spec["components"]["schemas"]},
    }
    dump_yaml(models_spec, MODELS_OUTPUT)
    models_json = MODELS_OUTPUT.with_suffix(".json")
    models_json.write_text(
        json.dumps(models_spec, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Wrote {OUTPUT}")
    print(f"Wrote {json_path}")
    print(f"Wrote {MODELS_OUTPUT}")
    print(f"Wrote {models_json}")
    print(f"paths={len(spec['paths'])}")
    print(f"named_models={len(named)}")


if __name__ == "__main__":
    main()
