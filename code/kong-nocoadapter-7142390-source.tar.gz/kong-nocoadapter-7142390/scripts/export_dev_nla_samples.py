#!/usr/bin/env python3
"""Export public NLA API response examples from NocoBase DEV 13001.

Credentials and tokens are read in memory and never written to the output.
The script refuses to run against a different NocoBase environment.
"""

from __future__ import annotations

import argparse
import getpass
import json
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, NoReturn, Union, get_args, get_origin

from fastapi.testclient import TestClient
from pydantic import BaseModel, TypeAdapter, ValidationError

from app.main import create_app
from app.models import CreateIntakeForNewLicenceRequest, NewLicenceFormData
from app.settings import Settings


# This exporter is intentionally self-contained.  The former NLA sample
# generator is a historical, untracked developer utility and may be archived
# separately; exporting a documented response example must not depend on it.
DEV_BASE_URL = "http://119.91.104.211:13001/cmtf2"


def sign_in(password: str) -> str:
    """Authenticate only in memory against the fixed 13001 DEV endpoint."""
    request = urllib.request.Request(
        DEV_BASE_URL + "/api/auth:signIn",
        data=json.dumps({"account": "op-test", "password": password}).encode(),
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = json.load(response)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Sign-in failed with HTTP {exc.code}") from exc
    token = (body.get("data") or {}).get("token")
    if not isinstance(token, str) or not token:
        raise RuntimeError("Sign-in returned no token")
    return token

BUSINESS_STATUSES = frozenset(
    {
        "Accepted",
        "Received",
        "P_Number_Generated",
        "Acknowledged",
        "Confirmed",
        "Reminding",
        "Approved",
        "Closed",
    }
)
CREATE_FORBIDDEN_FIELDS = (
    ("form_data", "case_summary", "submitter_user_id"),
    ("form_data", "case_summary", "task_owner_user_id"),
    ("form_data", "case_summary", "task_owner_post_code"),
    ("form_data", "part_5", "attachment_ids"),
)
QUERY_ROOT_FIELDS = frozenset(
    {
        "request_id",
        "create_id",
        "office_code",
        "application_type",
        "status",
        "application_data",
        "notices",
    }
)
NOTICE_FIELDS = frozenset(
    {
        "notice_id",
        "third_party_name",
        "intake_type",
        "notice_type",
        "status",
        "content",
        "rch_no",
        "rch_name",
        "created_time",
        "attachments",
    }
)
NOTICE_ATTACHMENT_FIELDS = frozenset({"data_id", "filename", "size", "download_url"})


def _fail(path: str, reason: str) -> NoReturn:
    raise ValueError(f"{path}: {reason}")


def _require_object(value: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        _fail(path, "expected an object")
    return value


def _require_fields(
    value: dict[str, Any], path: str, allowed: frozenset[str], required: frozenset[str]
) -> None:
    for key in sorted(value.keys() - allowed):
        _fail(f"{path}.{key}", "not part of the public API contract")
    for key in sorted(required - value.keys()):
        _fail(f"{path}.{key}", "required by the public API contract")


def _require_string(value: Any, path: str, *, nullable: bool = False) -> None:
    if value is None and nullable:
        return
    if not isinstance(value, str) or not value:
        _fail(path, "expected a non-empty string" + (" or null" if nullable else ""))


def _require_positive_int(value: Any, path: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        _fail(path, "expected a positive integer")


def _require_utc_time(value: Any, path: str) -> None:
    _require_string(value, path)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        _fail(path, "expected an ISO 8601 UTC timestamp")
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
        _fail(path, "expected an ISO 8601 UTC timestamp")


def _walk_no_native_ids(value: Any, path: str) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            child_path = f"{path}.{key}"
            if key == "id" or (
                key.endswith("_id")
                and key
                not in {
                    "operation_mode_id",
                    "source_id",
                    "attachment_id",
                }
            ):
                _fail(child_path, "internal ID is not allowed in a public sample")
            _walk_no_native_ids(child, child_path)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _walk_no_native_ids(child, f"{path}[{index}]")


def _validate_create_request(body: Any) -> dict[str, Any]:
    body = _require_object(body, "Create")
    for path in CREATE_FORBIDDEN_FIELDS:
        current: Any = body
        for key in path[:-1]:
            current = current.get(key) if isinstance(current, dict) else None
        if isinstance(current, dict) and path[-1] in current:
            _fail("Create." + ".".join(path), "must not be supplied by OP")
    _walk_no_native_ids(body.get("form_data"), "Create.form_data")
    try:
        CreateIntakeForNewLicenceRequest.model_validate(body)
    except ValidationError as exc:
        first = exc.errors()[0]
        field = ".".join(str(part) for part in first["loc"])
        _fail(f"Create.{field}", first["msg"])
    _validate_public_model(
        body["form_data"],
        NewLicenceFormData,
        "Create.form_data",
        query_projection=False,
    )
    for index, item in enumerate(body["form_data"]["part_5"].get("checklist", [])):
        _require_fields(
            _require_object(item, f"Create.form_data.part_5.checklist[{index}]"),
            f"Create.form_data.part_5.checklist[{index}]",
            frozenset({"position_code", "attachment_id"}),
            frozenset({"position_code", "attachment_id"}),
        )
    return body


def _validate_public_model(
    value: Any,
    model: type[BaseModel],
    path: str,
    *,
    query_projection: bool,
) -> None:
    value = _require_object(value, path)
    for key, child in value.items():
        child_path = f"{path}.{key}"
        field = model.model_fields.get(key)
        if field is None:
            _fail(child_path, "not part of the public API contract")
        if key == "id" or key == "attachment_ids":
            _fail(child_path, "internal or withdrawn field is not public")
        if path.endswith(".case_summary") and key in {
            "submitter_user_id",
            "task_owner_user_id",
            "task_owner_post_code",
        }:
            _fail(child_path, "internal personnel assignment is not public")
        if query_projection and "status" in key.lower():
            _fail(child_path, "status fields are omitted from application_data")
        _validate_public_value(
            child,
            field.annotation,
            child_path,
            query_projection=query_projection,
        )
        if key == "attachment_id":
            _require_positive_int(child, child_path)


def _validate_public_value(
    value: Any, annotation: Any, path: str, *, query_projection: bool
) -> None:
    origin = get_origin(annotation)
    if origin is Union:
        alternatives = get_args(annotation)
        if value is None and type(None) in alternatives:
            return
        non_null = tuple(item for item in alternatives if item is not type(None))
        if len(non_null) == 1:
            _validate_public_value(
                value, non_null[0], path, query_projection=query_projection
            )
            return
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        _validate_public_model(
            value, annotation, path, query_projection=query_projection
        )
        return
    if origin is list:
        if not isinstance(value, list):
            _fail(path, "expected an array")
        for index, item in enumerate(value):
            _validate_public_value(
                item,
                get_args(annotation)[0],
                f"{path}[{index}]",
                query_projection=query_projection,
            )
        return
    if annotation is date:
        if not isinstance(value, str) or len(value) != 10:
            _fail(path, "expected a YYYY-MM-DD date")
    try:
        TypeAdapter(annotation).validate_json(json.dumps(value), strict=True)
    except (ValidationError, TypeError, ValueError):
        _fail(path, "has an invalid public API type or value")


def _compare_submitted_values(submitted: Any, queried: Any, path: str) -> None:
    """Check values present in Query without requiring the full Create echo."""
    if isinstance(submitted, dict) and isinstance(queried, dict):
        for key, value in submitted.items():
            if key not in queried or key == "display_name" or "status" in key.lower():
                continue
            _compare_submitted_values(value, queried[key], f"{path}.{key}")
    elif isinstance(submitted, list) and isinstance(queried, list):
        if len(submitted) != len(queried):
            _fail(path, "does not match the submitted Create array")
        for index, (original, current) in enumerate(zip(submitted, queried)):
            _compare_submitted_values(original, current, f"{path}[{index}]")
    elif type(submitted) is not type(queried) or submitted != queried:
        # A JSON integer is a valid representation of an integral JSON number.
        both_numbers = (
            type(submitted) in (int, float)
            and type(queried) in (int, float)
            and submitted == queried
        )
        if not both_numbers:
            _fail(path, "does not match the submitted Create value")


def _validate_query_response(
    result: Any, create_id: str, create_request: dict[str, Any] | None
) -> dict[str, Any]:
    result = _require_object(result, "Query")
    _require_fields(result, "Query", QUERY_ROOT_FIELDS, QUERY_ROOT_FIELDS)
    _require_string(result["request_id"], "Query.request_id")
    if result["create_id"] != create_id:
        _fail("Query.create_id", f"expected {create_id!r}")
    if not isinstance(result["office_code"], str) or result["office_code"] not in {
        "LORCHE",
        "LORCHD",
    }:
        _fail("Query.office_code", "expected LORCHE or LORCHD")
    application_type = _require_object(
        result["application_type"], "Query.application_type"
    )
    _require_fields(
        application_type,
        "Query.application_type",
        frozenset({"value", "label"}),
        frozenset({"value", "label"}),
    )
    if application_type != {
        "value": "new_licence",
        "label": "New Licence Applications",
    }:
        _fail("Query.application_type", "expected the New Licence value and label")
    if (
        not isinstance(result["status"], str)
        or result["status"] not in BUSINESS_STATUSES
    ):
        _fail("Query.status", "not a v0.76 New Licence business status")
    application_data = _require_object(
        result["application_data"], "Query.application_data"
    )
    _require_fields(
        application_data,
        "Query.application_data",
        frozenset({"form_data"}),
        frozenset({"form_data"}),
    )
    form_data = _require_object(
        application_data["form_data"], "Query.application_data.form_data"
    )
    _validate_public_model(
        form_data,
        NewLicenceFormData,
        "Query.application_data.form_data",
        query_projection=True,
    )
    query_office = (form_data.get("case_summary") or {}).get("office_code")
    if query_office != result["office_code"]:
        _fail(
            "Query.application_data.form_data.case_summary.office_code",
            "does not match Query.office_code",
        )
    if create_request is not None:
        create_form = create_request["form_data"]
        if result["request_id"] != create_request["request_id"]:
            _fail("Query.request_id", "does not match Create.request_id")
        if result["office_code"] != create_form["case_summary"]["office_code"]:
            _fail(
                "Query.office_code",
                "does not match Create.form_data.case_summary.office_code",
            )
        create_checklist = create_form["part_5"].get("checklist", [])
        query_checklist = (form_data.get("part_5") or {}).get("checklist", [])
        if query_checklist != create_checklist:
            _fail(
                "Query.application_data.form_data.part_5.checklist",
                "does not match Create checklist",
            )
        _compare_submitted_values(
            create_form,
            form_data,
            "Query.application_data.form_data",
        )
    notices = result["notices"]
    if not isinstance(notices, list):
        _fail("Query.notices", "expected an array")
    notice_ids: set[str] = set()
    for index, notice in enumerate(notices):
        path = f"Query.notices[{index}]"
        notice = _require_object(notice, path)
        _require_fields(
            notice,
            path,
            NOTICE_FIELDS,
            frozenset(
                {
                    "notice_id",
                    "third_party_name",
                    "intake_type",
                    "notice_type",
                    "status",
                    "created_time",
                    "attachments",
                }
            ),
        )
        _require_string(notice["notice_id"], f"{path}.notice_id")
        if notice["notice_id"] in notice_ids:
            _fail(f"{path}.notice_id", "duplicate Notice ID")
        notice_ids.add(notice["notice_id"])
        if notice["third_party_name"] != "OP":
            _fail(f"{path}.third_party_name", "must be OP")
        for field in ("intake_type", "notice_type", "content", "rch_no", "rch_name"):
            if (
                field in notice
                and notice[field] is not None
                and not isinstance(notice[field], str)
            ):
                _fail(f"{path}.{field}", "expected a string or null")
        if notice["status"] is not None and (
            not isinstance(notice["status"], str)
            or notice["status"] not in BUSINESS_STATUSES
        ):
            _fail(f"{path}.status", "not a v0.76 New Licence business status")
        _require_utc_time(notice["created_time"], f"{path}.created_time")
        attachments = notice["attachments"]
        if not isinstance(attachments, list):
            _fail(f"{path}.attachments", "expected an array")
        for file_index, attachment in enumerate(attachments):
            file_path = f"{path}.attachments[{file_index}]"
            attachment = _require_object(attachment, file_path)
            _require_fields(
                attachment,
                file_path,
                NOTICE_ATTACHMENT_FIELDS,
                frozenset({"data_id", "download_url"}),
            )
            _require_positive_int(attachment["data_id"], f"{file_path}.data_id")
            if attachment["download_url"] != f"/v1/files/{attachment['data_id']}":
                _fail(f"{file_path}.download_url", "does not match data_id")
            for field in ("filename", "size"):
                if field not in attachment or attachment[field] is None:
                    continue
                if field == "filename" and not isinstance(attachment[field], str):
                    _fail(f"{file_path}.filename", "expected a string or null")
                if field == "size" and (
                    isinstance(attachment[field], bool)
                    or not isinstance(attachment[field], int)
                    or attachment[field] < 0
                ):
                    _fail(
                        f"{file_path}.size", "expected a non-negative integer or null"
                    )
    if result["status"] == "Acknowledged" and not any(
        notice["status"] == "Acknowledged" and notice["attachments"]
        for notice in notices
    ):
        _fail(
            "Query.notices",
            "Acknowledged requires an issued acknowledgement attachment",
        )
    return result


def export(
    create_ids: list[str], output_dir: Path, *, query_only: bool = False
) -> None:
    settings = Settings.from_env()
    if settings.nocobase_base_url.rstrip("/") != DEV_BASE_URL:
        raise RuntimeError("This export is restricted to NocoBase DEV 13001")
    token = sign_in(getpass.getpass("OP password: "))
    headers = {"Authorization": f"Bearer {token}"}
    pending: list[tuple[str, dict[str, Any], dict[str, Any] | None]] = []
    with TestClient(create_app(settings)) as client:
        for create_id in create_ids:
            source_request = urllib.request.Request(
                DEV_BASE_URL + f"/api/t_api_request_staging:get?filterByTk={create_id}",
                headers={"Authorization": f"Bearer {token}"},
            )
            with urllib.request.urlopen(source_request, timeout=30) as source:
                source_row = json.load(source).get("data") or {}
            if (
                str(source_row.get("id")) != create_id
                or source_row.get("f_source_system") != "OP"
                or source_row.get("f_request_event") != "CREATE"
                or source_row.get("f_api_type") != "create_intake_for_new_licence"
                or source_row.get("f_application_type") != "new_licence"
            ):
                raise RuntimeError(
                    f"{create_id} is not an OP New Licence CREATE record"
                )
            public_request = source_row.get("f_request_body")
            try:
                checked_request = (
                    None if query_only else _validate_create_request(public_request)
                )
            except ValueError as exc:
                raise RuntimeError(f"Cannot export {create_id}: {exc}") from exc
            response = client.get(f"/v1/request/{create_id}", headers=headers)
            if response.status_code != 200:
                raise RuntimeError(
                    f"Query {create_id} failed with HTTP {response.status_code}: "
                    + json.dumps(response.json(), ensure_ascii=False)
                )
            result = response.json()
            try:
                checked_result = _validate_query_response(
                    result, create_id, checked_request
                )
            except ValueError as exc:
                raise RuntimeError(f"Cannot export {create_id}: {exc}") from exc
            if source_row.get("f_office_code") not in (
                None,
                checked_result["office_code"],
            ):
                raise RuntimeError(
                    f"Cannot export {create_id}: Query.office_code does not match "
                    "the Create record office"
                )
            if query_only and isinstance(public_request, dict):
                source_request_id = public_request.get("request_id")
                if source_request_id not in (None, checked_result["request_id"]):
                    raise RuntimeError(
                        f"Cannot export {create_id}: Query.request_id does not "
                        "match the Create record"
                    )
            pending.append((create_id, checked_result, checked_request))
    output_dir.mkdir(parents=True, exist_ok=True)
    for create_id, result, public_request in pending:
        path = output_dir / f"nla-request-{create_id}.json"
        path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        exported = [str(path)]
        if public_request is not None:
            request_path = output_dir / f"nla-create-{create_id}.json"
            request_path.write_text(
                json.dumps(public_request, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
            exported.append(str(request_path))
        print(
            f"exported={','.join(exported)} status={result.get('status')} "
            f"notice_count={len(result.get('notices') or [])}"
        )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("create_ids", nargs="+", help="Public Create IDs to query")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--query-only", action="store_true")
    args = parser.parse_args()
    export(args.create_ids, args.output_dir, query_only=args.query_only)


if __name__ == "__main__":
    main()
