#!/usr/bin/env python3
"""Add native NLA relation creation nodes to an editable staging workflow.

The source webhook workflow is used only as a version-compatible template for
NocoBase create/loop node configuration. Runtime processing remains collection
event based; it does not call the webhook.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping, MutableMapping
from typing import Any, Optional

SOURCE_WORKFLOW_ID = 380781660012544
DEFAULT_TARGET_WORKFLOW_ID = 384621457375232
# Existing 13001 category title; keep the current spelling so new API
# workflows land in the same admin folder.
API_SOURCE_CATEGORY_TITLE = "API Suorce"

SOURCE_NODE_IDS = (
    380781660012561,  # applicant loop
    380781660012565,  # applicant address
    380781660012566,  # applicant record
    380781660012549,  # operator loop
    380781660012567,  # operator address
    380781660012568,  # operator record
    380781660012557,  # company loop
    380781660012569,  # company address
    380781660012570,  # company record
    380781660012551,  # personnel loop
    380781660012550,  # personnel address
    380781660012546,  # personnel record
    380781660012556,  # self-owned loop
    380781660012552,  # self-owned address
    380781660012548,  # self-owned premise
    380781660012553,  # rented loop
    380781660012562,  # rented address
    380781660012563,  # rented premise
)

NORMALIZE_TITLE = "Normalize complete NLA relation data"

CONTACT_FIELDS = {
    "title": "f_person_title",
    "display_name": "f_display_name",
    "full_name_en": "f_full_name_en",
    "full_name_cn": "f_full_name_cn",
    "first_name_en": "f_name_en_first",
    "middle_name_en": "f_name_en_middle",
    "last_name_en": "f_name_en_last",
    "surname_cn": "f_name_cn_sur",
    "given_name_cn": "f_name_cn_given",
    "hkid_part_1": "f_hkid_no_1",
    "hkid_part_2": "f_hkid_no_2",
    "hkid_part_3": "f_hkid_no_3",
    "position_title": "f_position_title",
    "representative_position": "f_representative_position",
    "contact_relationship": "f_contact_relationship",
    "contact_relationship_other": "f_contact_relationship_other",
    "mobile_phone": "f_mobile_phone",
    "residential_phone": "f_residential_phone",
    "office_phone": "f_office_phone",
    "email": "f_email",
    "office_email": "f_office_email",
    "company_name_en": "f_compnay_name_en",
    "company_name_cn": "f_company_name_cn",
    "business_registration_no": "f_business_registration_no",
    "certificate_of_incorporation_no": "f_certificate_of_incorporation_no",
    "application_type": "f_body_corporate_application_type",
    "address_for_licence": "f_address_for_licence",
    "active": "f_is_active",
}

ADDRESS_FIELDS = {
    "full_name_en": "f_fullname_en",
    "full_name_cn": "f_fullname_cn",
    "lot_or_address_en": "f_lot_or_address_en",
    "lot_or_address_cn": "f_lot_or_address_cn",
    "block_no_en": "f_block_no_en",
    "block_no_cn": "f_block_no_cn",
    "block_type_en": "f_block_type_en",
    "block_type_cn": "f_block_type_cn",
    "floor_en": "f_floor_num_en",
    "floor_cn": "f_floor_num_cn",
    "unit_no_en": "f_unit_no_en",
    "unit_no_cn": "f_unit_no_cn",
    "unit_type_en": "f_unit_type_en",
    "unit_type_cn": "f_unit_type_cn",
    "building_name_en": "f_building_name_en",
    "building_name_cn": "f_building_name_cn",
    "estate_or_village_en": "f_estate_or_village_name_en",
    "estate_or_village_cn": "f_estate_or_village_name_cn",
    "street_no_en": "f_street_no_en",
    "street_no_cn": "f_street_no_cn",
    "street_name_en": "f_street_name_en",
    "street_name_cn": "f_street_name_cn",
    "phase_en": "f_phase_en",
    "phase_cn": "f_phase_cn",
}

PREMISE_FIELDS = {
    "premise_type": "f_premise_type",
    "location": "f_location",
    "tenancy_from": "f_tenancy_from",
    "tenancy_to": "f_tenancy_to",
    "sort_order": "f_sort_order",
}

CHECKLIST_SPECIAL_NAMES = {
    "FSI_314B": (
        "(ii) Fire Service Installation Plans for Prescribed Commercial "
        "Premises/Specified Commercial Buildings (FSI/314B); or"
    ),
    "FSI_314C": (
        "(iii) Fire Service Installation Plans for Composite Building/Domestic "
        "Building (FSI/314C); (as appropriate). Relevant fire service "
        "installation plan(s) with the stamp of the FSD and subsequent reply "
        "from the D of FS shall be included."
    ),
    "ELDERLY_HOME_LICENCE_APPLICATION_FORM": (
        "Elderly Home Licence Application Form"
    ),
    "PROOF_OF_ADDRESS": (
        "proof of Address (e.g. rates demand note, utility bills such as "
        "water/electricity)"
    ),
}


class ApiError(RuntimeError):
    pass


class NocoBaseApi:
    def __init__(self, base_url: str, token: str, *, role: str | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.role = role

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        if self.role is not None:
            headers["X-Role"] = self.role
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=payload,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:1200]
            raise ApiError(f"HTTP {exc.code} for {path}: {detail}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise ApiError(f"NocoBase error for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded

    def get_workflow(self, workflow_id: int) -> MutableMapping[str, Any]:
        query = urllib.parse.urlencode(
            {"filterByTk": str(workflow_id), "appends[]": "nodes"}
        )
        data = self.request("GET", f"/api/workflows:get?{query}")
        if not isinstance(data, dict):
            raise ApiError("Workflow API did not return an object")
        return data

    def create_node(self, values: Mapping[str, Any]) -> MutableMapping[str, Any]:
        data = self.request("POST", "/api/flow_nodes:create", values)
        if not isinstance(data, dict):
            raise ApiError("Node create API did not return an object")
        return data

    def update_node(self, node_id: int, values: Mapping[str, Any]) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(node_id)})
        self.request("POST", f"/api/flow_nodes:update?{query}", values)


def resolve_workflow_category_id(api: NocoBaseApi, title: str) -> int:
    query = urllib.parse.urlencode({"pageSize": 100, "filter[title]": title})
    rows = api.request("GET", f"/api/workflowCategories:list?{query}")
    found = [
        row
        for row in (rows or [])
        if isinstance(row, dict) and row.get("title") == title
    ]
    if len(found) != 1 or found[0].get("id") is None:
        raise ApiError(f"Expected one workflow category titled {title!r}")
    return int(found[0]["id"])


def attach_api_source_category(api: NocoBaseApi, workflow_id: int) -> int:
    """Mount a newly created API workflow under the API Suorce category."""
    category_id = resolve_workflow_category_id(api, API_SOURCE_CATEGORY_TITLE)
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow_id}",
        {"categories": [category_id]},
    )
    return category_id


def node_map(workflow: Mapping[str, Any]) -> dict[int, MutableMapping[str, Any]]:
    return {int(node["id"]): node for node in workflow.get("nodes") or []}


def node_by_title(workflow: Mapping[str, Any], title: str) -> MutableMapping[str, Any]:
    found = [node for node in workflow.get("nodes") or [] if node.get("title") == title]
    if len(found) != 1:
        raise ApiError(
            f"Expected exactly one node titled {title!r}, found {len(found)}"
        )
    return found[0]


def json_ref(node_key: str, name: str) -> str:
    return "{{$jobsMapByNodeKey." + node_key + "." + name + "}}"


def normalize_script() -> str:
    contact = json.dumps(CONTACT_FIELDS, separators=(",", ":"))
    address = json.dumps(ADDRESS_FIELDS, separators=(",", ":"))
    premise = json.dumps(PREMISE_FIELDS, separators=(",", ":"))
    checklist_special = json.dumps(
        CHECKLIST_SPECIAL_NAMES, ensure_ascii=False, separators=(",", ":")
    )
    return f"""const f = formData || {{}};
const contactFields = {contact};
const addressFields = {address};
const premiseFields = {premise};
const addressRows = (typeof addressOptions !== 'undefined'
  && Array.isArray(addressOptions))
  ? addressOptions : [];
const rchTypeRows = (typeof rchTypeOptions !== 'undefined'
  && Array.isArray(rchTypeOptions))
  ? rchTypeOptions : [];
const checklistRows = (typeof checklistOptions !== 'undefined'
  && Array.isArray(checklistOptions))
  ? checklistOptions : [];
const checklistSpecialNames = {checklist_special};
const present = (v) => v !== undefined && v !== null && v !== '';
const mapFields = (value, schema) => {{
  const result = {{}};
  for (const [external, internal] of Object.entries(schema)) {{
    if (present(value && value[external])) result[internal] = value[external];
  }}
  return result;
}};
const addressByCode = new Map(addressRows
  .filter((row) => present(row && row.f_code))
  .map((row) => [String(row.f_code), row]));
const address = (value) => {{
  const source = value || {{}};
  const result = mapFields(source, addressFields);
  if (Object.keys(source).length === 0) return result;
  const region = addressByCode.get(String(source.region_code || ''));
  const district = addressByCode.get(String(source.district_code || ''));
  const subDistrict = addressByCode.get(String(source.sub_district_code || ''));
  if (!region || !district || !subDistrict) {{
    throw new Error('Unknown region_code/district_code/sub_district_code');
  }}
  if (String(district.parentId) !== String(region.id)
      || String(subDistrict.parentId) !== String(district.id)) {{
    throw new Error('Invalid region/district/sub-district hierarchy');
  }}
  result.fk_region_en = region.f_name_en;
  result.fk_region_cn = region.f_name_cn;
  result.fk_district_name_en = district.f_name_en;
  result.fk_district_name_cn = district.f_name_cn;
  result.fk_sub_district_en = subDistrict.f_name_en;
  result.fk_sub_district_cn = subDistrict.f_name_cn;
  return result;
}};
const contact = (value) => {{
  const result = mapFields(value || {{}}, contactFields);
  result.address = address((value || {{}}).address || {{}});
  return result;
}};
const premises = (values) => (Array.isArray(values) ? values : []).map((value) => {{
  const result = mapFields(value || {{}}, premiseFields);
  result.address = address((value || {{}}).address || {{}});
  return result;
}});
const applicantValue = f.part_4 && f.part_4.authorised_representative;
const operatorValue = f.part_3 && f.part_3.operator;
const companyValue = f.part_3 && f.part_3.company;
const personnelValues = (f.part_3 && f.part_3.personnel) || [];
const premiseValues = (f.part_2 && f.part_2.premises) || {{}};
const applicantRows = present(applicantValue) ? [contact(applicantValue)] : [];
const operatorRows = present(operatorValue) ? [contact(operatorValue)] : [];
const companyRows = present(companyValue) ? [contact(companyValue)] : [];
const contactRows = (Array.isArray(personnelValues)
  ? personnelValues : []).map(contact);
const selfOwnedRows = premises(premiseValues.self_owned);
const rentedRows = premises(premiseValues.rented);
const rchAddress = address((f.part_2 && f.part_2.address) || {{}});
const rchTypeCode = String((f.part_2 && f.part_2.rch_type_code) || '');
const officeCode = String((f.case_summary && f.case_summary.office_code) || '');
const rchType = rchTypeRows.find((row) =>
  String(row && row.f_code) === rchTypeCode
  && String(row && row.f_for_office) === officeCode);
if (!rchType) throw new Error('Unknown rch_type_code for office_code');
const bedValues = [
  f.part_2.nursing_home_places,
  f.part_2.care_and_attention_home_places,
  f.part_2.aged_home_places,
  f.part_2.self_care_hostel_places,
];
const recommendationSource = String(
  ((f.part_5 || {{}}).recommendation) || '').trim().toLowerCase();
const recommendationValues = {{accept: '0', reject: '1'}};
const recommendationValue = recommendationSource
  ? recommendationValues[recommendationSource] : undefined;
if (recommendationSource && recommendationValue === undefined) {{
  throw new Error('Unknown recommendation value: ' + recommendationSource);
}}
const checklistItems = (((f.part_5 || {{}}).checklist) || []).map((value) => {{
  const positionCode = String((value || {{}}).position_code || '');
  const template = checklistRows.find((row) =>
    String(row && row.f_position_code) === positionCode
    && String(row && row.f_office_code) === officeCode
    && String(row && row.f_item_type) === '2'
    && row && row.f_active === true);
  if (!template) throw new Error('Unknown checklist position_code: ' + positionCode);
  const attachmentId = Number(value.attachment_id);
  if (!Number.isSafeInteger(attachmentId) || attachmentId <= 0) {{
    throw new Error(
      'Invalid attachment_id for Checklist position_code: ' + positionCode);
  }}
  return {{
    template_id: template.id,
    position_code: positionCode,
    checked: value.checked !== false,
    status: String(value.status || '1'),
    remarks: value.remarks,
    attachment_id: attachmentId,
    attachment_ids: [attachmentId],
  }};
}});
return {{
  rch_address: rchAddress,
  rch_type_id: rchType.id,
  beds_nursing: Number(f.part_2.nursing_home_places || 0),
  beds_care_and_attention: Number(f.part_2.care_and_attention_home_places || 0),
  beds_aged_home: Number(f.part_2.aged_home_places || 0),
  beds_self_care: Number(f.part_2.self_care_hostel_places || 0),
  beds_total: bedValues.reduce((sum, value) => sum + Number(value || 0), 0),
  recommendation_value: recommendationValue,
  checklist_items: checklistItems,
  main_attachment_ids: Array.isArray((f.part_5 || {{}}).attachment_ids)
    ? f.part_5.attachment_ids : [],
  activity_date: (f.case_summary || {{}}).received_date
    || (f.part_1 || {{}}).application_received_date,
  rel_applicant: applicantRows,
  rel_applicant_new: applicantRows,
  rel_operator: operatorRows,
  rel_operator_new: operatorRows,
  rel_company: companyRows,
  rel_company_new: companyRows,
  rel_contacts: contactRows,
  rel_contacts_new: contactRows,
  rel_self_owned_premises: selfOwnedRows,
  rel_self_owned_premises_new: selfOwnedRows,
  rel_rented_premises: rentedRows,
  rel_rented_premises_new: rentedRows,
}};"""


def deep_replace(value: Any, replacements: Mapping[str, str]) -> Any:
    if isinstance(value, str):
        result = value
        for old, new in replacements.items():
            result = result.replace(old, new)
        return result
    if isinstance(value, list):
        return [deep_replace(child, replacements) for child in value]
    if isinstance(value, dict):
        return {key: deep_replace(child, replacements) for key, child in value.items()}
    return value


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument(
        "--target-workflow-id", type=int, default=DEFAULT_TARGET_WORKFLOW_ID
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    target = api.get_workflow(args.target_workflow_id)
    source = api.get_workflow(SOURCE_WORKFLOW_ID)
    if target.get("enabled"):
        raise ApiError("Refusing to modify an enabled target workflow")
    if target.get("executed"):
        raise ApiError("Refusing to modify an executed target workflow")
    if (
        node_by_title(target, NORMALIZE_TITLE)
        if any(
            node.get("title") == NORMALIZE_TITLE for node in target.get("nodes") or []
        )
        else None
    ):
        raise ApiError("Relation nodes are already installed")

    parse_node = node_by_title(target, "Parse staged request body")
    parse_variables = (parse_node.get("config") or {}).get("variables") or []
    form_data_keys = [
        v.get("key") for v in parse_variables if v.get("path") == "form_data"
    ]
    if len(form_data_keys) != 1:
        raise ApiError("Could not resolve the parsed form_data output")

    condition = node_by_title(target, "NLA fields applied successfully?")
    checklist = node_by_title(target, "Apply Checklist files to native records")
    target_nla = node_by_title(target, "Find native-created NLA")
    target_intake = node_by_title(target, "Create Intake (fixed NLA type)")
    source_nodes = node_map(source)

    print(f"target_workflow_id={args.target_workflow_id}")
    print(f"relation_template_nodes={len(SOURCE_NODE_IDS)}")
    print("workflow_enabled=no")
    if not args.apply:
        print("mode=dry-run")
        return 0

    normalized = api.create_node(
        {
            "workflowId": args.target_workflow_id,
            "type": "script",
            "title": NORMALIZE_TITLE,
            "config": {
                "arguments": [
                    {
                        "name": "formData",
                        "value": json_ref(parse_node["key"], form_data_keys[0]),
                    }
                ],
                "content": normalize_script(),
                "timeout": 0,
                "continue": False,
            },
        }
    )

    created: dict[int, MutableMapping[str, Any]] = {}
    for source_id in SOURCE_NODE_IDS:
        original = source_nodes[source_id]
        created[source_id] = api.create_node(
            {
                "workflowId": args.target_workflow_id,
                "type": original["type"],
                "title": original["title"],
                "config": copy.deepcopy(original.get("config") or {}),
            }
        )

    replacements = {
        source_nodes[source_id]["key"]: created[source_id]["key"]
        for source_id in SOURCE_NODE_IDS
    }
    replacements.update(
        {
            "i0txc5domuy": normalized["key"],
            "nhoabcoqdih": target_nla["key"],
            "eou7q89ja7m": target_intake["key"],
        }
    )

    # Preserve the source workflow's tested nested loop topology.
    for source_id, new_node in created.items():
        original = source_nodes[source_id]
        upstream = original.get("upstreamId")
        downstream = original.get("downstreamId")
        values: dict[str, Any] = {
            "config": deep_replace(original.get("config") or {}, replacements),
            "branchIndex": original.get("branchIndex"),
            "upstreamId": created[upstream]["id"] if upstream in created else None,
            "downstreamId": (
                created[downstream]["id"] if downstream in created else None
            ),
        }
        api.update_node(int(new_node["id"]), values)

    applicant_loop = created[380781660012561]
    rented_loop = created[380781660012553]
    api.update_node(
        int(normalized["id"]),
        {
            "upstreamId": condition["id"],
            "downstreamId": applicant_loop["id"],
            "branchIndex": 1,
        },
    )
    api.update_node(
        int(applicant_loop["id"]),
        {"upstreamId": normalized["id"], "branchIndex": None},
    )
    api.update_node(
        int(rented_loop["id"]),
        {"downstreamId": checklist["id"]},
    )
    api.update_node(
        int(checklist["id"]),
        {"upstreamId": rented_loop["id"], "branchIndex": None},
    )

    final = api.get_workflow(args.target_workflow_id)
    final_titles = {node.get("title") for node in final.get("nodes") or []}
    missing = [
        source_nodes[node_id]["title"]
        for node_id in SOURCE_NODE_IDS
        if source_nodes[node_id]["title"] not in final_titles
    ]
    if missing:
        raise ApiError(f"Created workflow is missing node titles: {missing}")
    print(f"normalize_node_id={normalized['id']}")
    print(f"created_relation_nodes={len(created)}")
    print(f"total_nodes={len(final.get('nodes') or [])}")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
