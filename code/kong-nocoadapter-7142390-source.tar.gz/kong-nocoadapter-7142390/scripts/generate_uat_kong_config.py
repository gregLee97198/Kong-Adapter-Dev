#!/usr/bin/env python3
"""Derive Docker UAT runtime YAML from the current 211 Adapter routes.

All public routes, including native-token sign-in, target the Adapter. The
NocoBase upstream is configured only in the generated Adapter profile.
"""

from __future__ import annotations

import argparse
import copy
import sys
from pathlib import Path
from typing import Any

import yaml
from manage_environment import _profile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "config/kong.211-dbless.yml"
TARGET = ROOT / "config/kong.uat-dbless.yml"
ADAPTER_TARGET = ROOT / "config/nocobase.uat.yaml"
ADAPTER_HOST = "kong-nocoadapter"
HEADER = (
    "# UAT Kong route contract with upstream derived from .env.\n"
    "# Edit only .env after unpacking; do not edit this runtime file by hand.\n"
)
ADAPTER_HEADER = (
    "# Generated UAT Adapter profile from .env.\n"
    "# Edit only .env after unpacking; do not edit this runtime file by hand.\n"
)


def _load(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("services"), list):
        raise ValueError(f"invalid Kong YAML: {path}")
    return value


def candidate() -> dict[str, Any]:
    if not SOURCE.is_file():
        # The offline release contains the already-generated 211 route contract,
        # not the 211 source YAML. Only UAT runtime targets are changed.
        document = _load(TARGET)
        for service in document["services"]:
            name = service["name"]
            if name in {
                "nocobase-adapter-auth-service",
                "nocobase-file-adapter-service",
            }:
                service["host"] = ADAPTER_HOST
                service["port"] = 8080
            else:
                raise ValueError(f"unexpected UAT Kong service: {name}")
        return document

    source = _load(SOURCE)
    services = []
    for raw_service in source["services"]:
        service = copy.deepcopy(raw_service)
        if service["name"] in {
            "nocobase-adapter-auth-service",
            "nocobase-file-adapter-service",
        }:
            service["host"] = ADAPTER_HOST
            service["port"] = 8080
        else:
            raise ValueError(f"unexpected 211 service: {service['name']}")

        for route in service.get("routes", []):
            # UAT Nginx terminates TLS and forwards over the Docker host's
            # HTTP port; direct port access must be firewalled to Nginx.
            route["protocols"] = ["http", "https"]
            route.pop("https_redirect_status_code", None)
        services.append(service)

    return {
        "_format_version": source["_format_version"],
        "_transform": source.get("_transform", True),
        "services": services,
        "plugins": copy.deepcopy(source.get("plugins", [])),
    }


def render() -> str:
    return HEADER + yaml.safe_dump(
        candidate(), allow_unicode=True, sort_keys=False, width=100
    )


def render_adapter() -> str:
    # The current UAT profile is the only NocoBase YAML input. Its API paths,
    # version and storage mode are retained; only the upstream URL is changed.
    document = yaml.safe_load(ADAPTER_TARGET.read_text(encoding="utf-8"))
    if not isinstance(document, dict) or not isinstance(document.get("nocobase"), dict):
        raise ValueError(f"invalid UAT Adapter YAML: {ADAPTER_TARGET}")
    document["nocobase"]["base_url"] = _profile("uat")["upstream"]["base_url"]
    return ADAPTER_HEADER + yaml.safe_dump(
        document, allow_unicode=True, sort_keys=False, width=100
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--write", action="store_true", help="regenerate both UAT runtime files"
    )
    group.add_argument(
        "--check", action="store_true", help="fail if either UAT file is stale"
    )
    group.add_argument(
        "--preview", action="store_true", help="show .env target without writes"
    )
    args = parser.parse_args()
    expected = render()
    expected_adapter = render_adapter()
    if args.preview:
        print(f"uat_nocobase_upstream={_profile('uat')['upstream']['base_url']}")
        print("result=preview-only")
        return 0
    if args.write:
        TARGET.write_text(expected, encoding="utf-8")
        ADAPTER_TARGET.write_text(expected_adapter, encoding="utf-8")
        print(f"generated={TARGET.relative_to(ROOT)}")
        print(f"generated={ADAPTER_TARGET.relative_to(ROOT)}")
        return 0
    if (
        not TARGET.is_file()
        or TARGET.read_text(encoding="utf-8") != expected
        or ADAPTER_TARGET.read_text(encoding="utf-8") != expected_adapter
    ):
        print("error=stale UAT runtime candidate", file=sys.stderr)
        print(
            "next=python3 scripts/generate_uat_kong_config.py --write",
            file=sys.stderr,
        )
        return 1
    print("validation=passed files=Kong,Adapter")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
