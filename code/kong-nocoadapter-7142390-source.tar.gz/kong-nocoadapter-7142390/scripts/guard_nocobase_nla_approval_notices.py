#!/usr/bin/env python3
"""Guard DEV NLA approval-log Notices until the corresponding letter is sent.

Only the condition node ``NLA and CREATE staging exist`` changes. Its NLA
branch continues for the existing Acknowledgement approval event, but no
longer creates Confirmed, Approved, or Closed Notices from approval logs before
Send Letter has recorded a sent letter. The Intake Received and non-NLA
branches, all other nodes, and all edges are exact copies of the audited graph.

``audit`` and ``verify`` are GET-only. ``prepare`` creates a disabled revision;
``cutover`` and ``rollback`` never enable both versions. Mutations require
``--apply --ack-brief-nonatomic-cutover`` and are restricted to NocoBase DEV
13001. A brief both-disabled gap is possible during revision/cutover. Review
approval-log events from the printed UTC interval afterwards. Never run two
operators concurrently, or reuse this script against 13000.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError

BASE_URL = "http://119.91.104.211:13001/cmtf2"
SOURCE_ID = 390808738463744
SOURCE_KEY = "4sdmfosouk0"
SOURCE_TITLE = "Approval Log Sync Data"
SOURCE_NODE_COUNT = 39
SOURCE_FINGERPRINT = "ec3bbf2be2c4d4a73e91422deaf8aa3b6810813da617797a3f02c3ac2d803fe0"
TARGET_ID = 390808738463762
TARGET_KEY = "c87w5v7a8w0"
TARGET_TITLE = "NLA and CREATE staging exist"
NLA_TITLE = "Query NLA"
STAGING_TITLE = "Query NLA CREATE staging"
DETAILS_TITLE = "Query node persist config"
ACK_MAPPING_ID = 372067549446144
EXPECTED_TRIGGER = {
    "mode": 3,
    "appends": [],
    "changed": ["f_status", "f_completed_date"],
    "condition": {
        "$and": [
            {"f_collection_name": {"$notEmpty": True}},
            {
                "$or": [
                    {"f_application": {"$empty": True}},
                    {"f_completed_date": {"$notEmpty": True}},
                ]
            },
        ]
    },
    "collection": "t_approval_log",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ApiError(message)


def fingerprint(workflow: Mapping[str, Any]) -> str:
    body = {
        "key": workflow.get("key"),
        "title": workflow.get("title"),
        "config": workflow.get("config"),
        "nodes": sorted(
            [
                {
                    field: node.get(field)
                    for field in (
                        "id",
                        "key",
                        "title",
                        "type",
                        "workflowId",
                        "upstreamId",
                        "downstreamId",
                        "branchIndex",
                        "config",
                    )
                }
                for node in workflow.get("nodes") or []
            ],
            key=lambda node: node["id"],
        ),
    }
    encoded = json.dumps(
        body, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def node_by_title(workflow: Mapping[str, Any], title: str, kind: str) -> dict[str, Any]:
    matches = [
        node for node in workflow.get("nodes") or [] if node.get("title") == title
    ]
    require(len(matches) == 1, f"Expected exactly one {title!r} node")
    require(matches[0].get("type") == kind, f"Node type drifted: {title}")
    return dict(matches[0])


def ref(node: Mapping[str, Any], field: str) -> str:
    return "{{$jobsMapByNodeKey." + str(node["key"]) + "." + field + "}}"


def original_target_config(workflow: Mapping[str, Any]) -> dict[str, Any]:
    nla = node_by_title(workflow, NLA_TITLE, "query")
    staging = node_by_title(workflow, STAGING_TITLE, "query")
    return {
        "rejectOnFalse": False,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "gt", "operands": [ref(nla, "id"), 0]},
                    {"calculator": "gt", "operands": [ref(staging, "id"), 0]},
                ],
            }
        },
    }


def guarded_target_config(workflow: Mapping[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(original_target_config(workflow))
    details = node_by_title(workflow, DETAILS_TITLE, "query")
    config["calculation"]["group"]["calculations"].extend(
        [
            {
                "calculator": "equal",
                "operands": ["{{$context.data.f_collection_name}}", "t_licence_app"],
            },
            {"calculator": "equal", "operands": ["{{$context.data.f_node_val}}", "15"]},
            {"calculator": "equal", "operands": ["{{$context.data.f_status}}", "5"]},
            {
                "calculator": "notEqual",
                "operands": ["{{$context.data.f_completed_date}}", None],
            },
            {"calculator": "equal", "operands": [ref(details, "f_notice_type"), "a"]},
            {
                "calculator": "equal",
                "operands": [ref(details, "fk_notice_board_status"), 4],
            },
        ]
    )
    return config


def validate_source(workflow: Mapping[str, Any], *, enabled: bool) -> None:
    require(
        workflow.get("id") == SOURCE_ID
        and workflow.get("key") == SOURCE_KEY
        and workflow.get("title") == SOURCE_TITLE
        and workflow.get("type") == "collection"
        and workflow.get("sync") is False
        and workflow.get("enabled") is enabled
        and workflow.get("config") == EXPECTED_TRIGGER
        and len(workflow.get("nodes") or []) == SOURCE_NODE_COUNT
        and fingerprint(workflow) == SOURCE_FINGERPRINT,
        "Active Approval Log Sync Data no longer matches the audited DEV graph",
    )
    target = node_by_title(workflow, TARGET_TITLE, "condition")
    require(
        target.get("id") == TARGET_ID
        and target.get("key") == TARGET_KEY
        and target.get("workflowId") == SOURCE_ID
        and target.get("config") == original_target_config(workflow),
        "Audited NLA approval-log branch condition drifted",
    )


def graph_view(workflow: Mapping[str, Any]) -> dict[str, Any]:
    nodes = workflow.get("nodes") or []
    ids = [node.get("id") for node in nodes]
    keys = [node.get("key") for node in nodes]
    titles = [node.get("title") for node in nodes]
    require(
        len(ids) == len(set(ids))
        and len(keys) == len(set(keys))
        and len(titles) == len(set(titles))
        and all(isinstance(value, int) for value in ids)
        and all(isinstance(value, str) and value for value in keys + titles),
        "Workflow has missing or duplicate node identities",
    )
    id_to_title = {node["id"]: node["title"] for node in nodes}
    result: dict[str, Any] = {}
    for node in nodes:
        require(
            node.get("workflowId") == workflow.get("id"),
            f"Node belongs to a different workflow: {node['title']}",
        )
        upstream_id = node.get("upstreamId")
        downstream_id = node.get("downstreamId")
        require(
            upstream_id in (None, *id_to_title)
            and downstream_id in (None, *id_to_title),
            f"Node edge leaves workflow: {node['title']}",
        )
        result[node["title"]] = {
            "key": node["key"],
            "type": node.get("type"),
            "config": node.get("config"),
            "upstream": id_to_title.get(upstream_id),
            "downstream": id_to_title.get(downstream_id),
            "branchIndex": node.get("branchIndex"),
        }
    return result


def validate_candidate(
    source: Mapping[str, Any],
    candidate: Mapping[str, Any],
    *,
    patched: bool,
    enabled: bool,
) -> None:
    require(
        isinstance(candidate.get("id"), int)
        and candidate["id"] > SOURCE_ID
        and candidate.get("key") == SOURCE_KEY
        and candidate.get("title") == SOURCE_TITLE
        and candidate.get("enabled") is enabled
        and candidate.get("type") == source.get("type")
        and candidate.get("sync") == source.get("sync")
        and candidate.get("config") == source.get("config")
        and len(candidate.get("nodes") or []) == SOURCE_NODE_COUNT,
        "Approval Log Sync Data candidate identity or trigger drifted",
    )
    expected = graph_view(source)
    if patched:
        expected[TARGET_TITLE] = copy.deepcopy(expected[TARGET_TITLE])
        expected[TARGET_TITLE]["config"] = guarded_target_config(source)
    require(
        graph_view(candidate) == expected,
        "Candidate is not an exact graph copy with the reviewed NLA branch guard",
    )


def workflow_family(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"filter[key]": SOURCE_KEY, "pageSize": 100})
    rows = api.request("GET", "/api/workflows:list?" + query)
    require(
        isinstance(rows, list) and len(rows) < 100, "Workflow family query incomplete"
    )
    require(
        all(isinstance(row, dict) and row.get("key") == SOURCE_KEY for row in rows),
        "Workflow family response drifted",
    )
    return [dict(row) for row in rows]


def candidate_id(api: RootNocoBaseApi) -> int | None:
    family = workflow_family(api)
    require(
        sum(row.get("id") == SOURCE_ID for row in family) == 1,
        "Audited source version is missing or duplicated",
    )
    require(
        all(not row.get("enabled") for row in family if int(row["id"]) < SOURCE_ID),
        "Older Approval Log Sync Data version is enabled",
    )
    newer = [int(row["id"]) for row in family if int(row["id"]) > SOURCE_ID]
    require(len(newer) <= 1, "Unexpected additional Approval Log Sync Data revisions")
    return newer[0] if newer else None


def executions(api: RootNocoBaseApi, workflow_id: int) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(workflow_id), "pageSize": 1}
    )
    rows = api.request("GET", "/api/executions:list?" + query)
    require(isinstance(rows, list), "Execution query failed")
    return list(rows)


def validate_ack_mapping(api: RootNocoBaseApi) -> None:
    row = api.request(
        "GET", f"/api/t_status_name_map_details:get?filterByTk={ACK_MAPPING_ID}"
    )
    require(
        isinstance(row, dict)
        and row.get("id") == ACK_MAPPING_ID
        and row.get("f_code") == "15"
        and row.get("f_notice_board_persist") is True
        and row.get("f_notice_type") == "a"
        and row.get("fk_notice_board_status") == 4
        and row.get("f_notice_log_status") == "5",
        "NLA Acknowledgement mapping drifted",
    )
    status = api.request("GET", "/api/t_notice_board_status:get?filterByTk=4")
    require(
        isinstance(status, dict)
        and status.get("id") == 4
        and status.get("f_status") == "Acknowledged",
        "NLA Acknowledged Notice status drifted",
    )


def set_enabled(api: RootNocoBaseApi, workflow_id: int, desired: bool) -> None:
    before = api.get_workflow(workflow_id)
    require(isinstance(before.get("enabled"), bool), "Workflow enabled flag unknown")
    if before["enabled"] is not desired:
        api.request(
            "POST",
            f"/api/workflows:update?filterByTk={workflow_id}",
            {"enabled": desired},
        )
    require(
        api.get_workflow(workflow_id).get("enabled") is desired,
        f"Enabled readback failed for workflow {workflow_id}",
    )


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def print_gap_guidance() -> None:
    print(
        "gap_audit=Review approval-log events between printed UTC times; "
        "verify no NLA b/c/d Notice was created before a sent letter."
    )


def create_revision(api: RootNocoBaseApi, source: Mapping[str, Any]) -> int:
    validate_source(source, enabled=True)
    require(candidate_id(api) is None, "A newer revision already exists")
    print(f"prepare_gap_start_utc={now_utc()}", flush=True)
    revision_error: Exception | None = None
    revision_id: int | None = None
    try:
        set_enabled(api, SOURCE_ID, False)
        validate_source(api.get_workflow(SOURCE_ID), enabled=False)
        query = urllib.parse.urlencode(
            {"filterByTk": SOURCE_ID, "filter[key]": SOURCE_KEY}
        )
        try:
            result = api.request("POST", "/api/workflows:revision?" + query, {})
            require(
                isinstance(result, dict) and isinstance(result.get("id"), int),
                "Revision API returned no ID",
            )
            revision_id = result["id"]
        except Exception as exc:
            revision_error = exc
        discovered = candidate_id(api)
        require(
            discovered is not None
            and (revision_id is None or revision_id == discovered),
            "Revision write outcome unknown; inspect workflow family",
        )
        revision_id = discovered
        set_enabled(api, revision_id, False)
        validate_candidate(
            source, api.get_workflow(revision_id), patched=False, enabled=False
        )
    finally:
        discovered = candidate_id(api)
        if discovered is not None:
            set_enabled(api, discovered, False)
        set_enabled(api, SOURCE_ID, True)
        print(f"prepare_gap_end_utc={now_utc()}", flush=True)
        print_gap_guidance()
    validate_source(api.get_workflow(SOURCE_ID), enabled=True)
    require(revision_id is not None, "Revision was not created")
    validate_candidate(
        source, api.get_workflow(revision_id), patched=False, enabled=False
    )
    if revision_error is not None:
        print("revision_transport_error=recovered_by_exact_readback")
    return revision_id


def prepare(api: RootNocoBaseApi) -> int:
    validate_ack_mapping(api)
    source = dict(api.get_workflow(SOURCE_ID))
    validate_source(source, enabled=True)
    revision_id = candidate_id(api)
    if revision_id is None:
        revision_id = create_revision(api, source)
    candidate = dict(api.get_workflow(revision_id))
    require(not executions(api, revision_id), "Cannot edit an executed candidate")
    try:
        validate_candidate(source, candidate, patched=True, enabled=False)
        return revision_id
    except ApiError:
        validate_candidate(source, candidate, patched=False, enabled=False)
    target = node_by_title(candidate, TARGET_TITLE, "condition")
    try:
        api.update_node(int(target["id"]), {"config": guarded_target_config(source)})
    except ApiError:
        # A timed-out POST may have committed; only an exact readback is safe.
        validate_candidate(
            source, api.get_workflow(revision_id), patched=True, enabled=False
        )
    validate_candidate(
        source, api.get_workflow(revision_id), patched=True, enabled=False
    )
    validate_source(api.get_workflow(SOURCE_ID), enabled=True)
    return revision_id


def checked_pair(
    api: RootNocoBaseApi, *, source_enabled: bool, candidate_enabled: bool
) -> tuple[dict[str, Any], dict[str, Any]]:
    source = dict(api.get_workflow(SOURCE_ID))
    validate_source(source, enabled=source_enabled)
    revision_id = candidate_id(api)
    require(revision_id is not None, "Reviewed candidate is missing")
    candidate = dict(api.get_workflow(revision_id))
    validate_candidate(source, candidate, patched=True, enabled=candidate_enabled)
    require(not (source_enabled and candidate_enabled), "Both versions are enabled")
    return source, candidate


def cutover(api: RootNocoBaseApi) -> int:
    validate_ack_mapping(api)
    _, candidate = checked_pair(api, source_enabled=True, candidate_enabled=False)
    revision_id = int(candidate["id"])
    require(not executions(api, revision_id), "Candidate has already executed")
    print(f"cutover_gap_start_utc={now_utc()}", flush=True)
    try:
        set_enabled(api, SOURCE_ID, False)
        set_enabled(api, revision_id, True)
        checked_pair(api, source_enabled=False, candidate_enabled=True)
    except Exception as exc:
        try:
            set_enabled(api, revision_id, False)
            set_enabled(api, SOURCE_ID, True)
            checked_pair(api, source_enabled=True, candidate_enabled=False)
        except Exception as rollback_exc:
            raise ApiError(
                f"Cutover failed ({exc}); automatic rollback failed "
                f"({rollback_exc}); inspect enabled flags immediately"
            ) from rollback_exc
        raise ApiError(f"Cutover failed ({exc}); audited source restored") from exc
    finally:
        print(f"cutover_gap_end_utc={now_utc()}", flush=True)
        print_gap_guidance()
    return revision_id


def rollback(api: RootNocoBaseApi) -> None:
    checked_pair(api, source_enabled=False, candidate_enabled=True)
    revision_id = candidate_id(api)
    require(revision_id is not None, "Candidate is missing")
    print(f"rollback_gap_start_utc={now_utc()}", flush=True)
    try:
        set_enabled(api, revision_id, False)
        set_enabled(api, SOURCE_ID, True)
        checked_pair(api, source_enabled=True, candidate_enabled=False)
    except Exception as exc:
        try:
            set_enabled(api, SOURCE_ID, False)
            set_enabled(api, revision_id, True)
            checked_pair(api, source_enabled=False, candidate_enabled=True)
        except Exception as restore_exc:
            raise ApiError(
                f"Rollback failed ({exc}); restoring candidate also failed "
                f"({restore_exc}); inspect enabled flags immediately"
            ) from restore_exc
        raise ApiError(f"Rollback failed ({exc}); guarded candidate restored") from exc
    finally:
        print(f"rollback_gap_end_utc={now_utc()}", flush=True)
        print_gap_guidance()


def audit(api: RootNocoBaseApi) -> None:
    validate_ack_mapping(api)
    source = dict(api.get_workflow(SOURCE_ID))
    enabled = source.get("enabled")
    require(isinstance(enabled, bool), "Source enabled flag unknown")
    validate_source(source, enabled=enabled)
    revision_id = candidate_id(api)
    phase = "absent"
    candidate_enabled: bool | None = None
    if revision_id is not None:
        candidate = dict(api.get_workflow(revision_id))
        candidate_enabled = candidate.get("enabled")
        require(isinstance(candidate_enabled, bool), "Candidate enabled flag unknown")
        require(not (enabled and candidate_enabled), "Both versions are enabled")
        try:
            validate_candidate(
                source, candidate, patched=True, enabled=candidate_enabled
            )
            phase = "patched-active" if candidate_enabled else "patched-disabled"
        except ApiError:
            validate_candidate(source, candidate, patched=False, enabled=False)
            phase = "clone-disabled"
    print(f"source_id={SOURCE_ID} enabled={str(enabled).lower()}")
    print(f"source_fingerprint={fingerprint(source)}")
    print(f"candidate_id={revision_id} enabled={candidate_enabled} phase={phase}")
    print(
        "scope=one NLA condition; Intake Received/non-NLA and remaining "
        "38 nodes unchanged"
    )


def verify(api: RootNocoBaseApi) -> int:
    validate_ack_mapping(api)
    _, candidate = checked_pair(api, source_enabled=False, candidate_enabled=True)
    revision_id = int(candidate["id"])
    print(f"verified_active_candidate_id={revision_id}")
    return revision_id


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=("audit", "prepare", "cutover", "rollback", "verify")
    )
    parser.add_argument("--base-url", default=BASE_URL)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--ack-brief-nonatomic-cutover", action="store_true")
    args = parser.parse_args(argv)
    if args.base_url.rstrip("/") != BASE_URL:
        parser.error("Only 13001 development NocoBase is in scope")
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        parser.error("NOCOBASE_TOKEN is required")
    api = RootNocoBaseApi(BASE_URL, token)
    try:
        if args.command == "audit":
            audit(api)
            return 0
        if args.command == "verify":
            verify(api)
            return 0
        if not args.apply:
            audit(api)
            print(f"mode=read-only; planned_command={args.command}")
            return 0
        if not args.ack_brief_nonatomic_cutover:
            parser.error("--apply requires --ack-brief-nonatomic-cutover")
        if args.command == "prepare":
            print(f"prepared_candidate_id={prepare(api)}")
        elif args.command == "cutover":
            print(f"active_candidate_id={cutover(api)}")
        else:
            rollback(api)
            print(f"restored_source_id={SOURCE_ID}")
    except ApiError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
