#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROJECT_ID="${APIFOX_PROJECT_ID:-8759003}"
SPEC_JSON="$ROOT/apifox/nocobase-kong-dbless.openapi.json"
PYTHON="${PYTHON:-$ROOT/.venv/bin/python}"

if [[ ! -x "$PYTHON" ]]; then
  PYTHON="python3"
fi

cd "$ROOT"
PYTHONPATH="$ROOT" "$PYTHON" "$ROOT/scripts/export_apifox_openapi.py"
"$PYTHON" "$ROOT/scripts/export_apifox_environments.py"

if [[ -z "${APIFOX_ACCESS_TOKEN:-}" ]]; then
  cat <<EOF
OpenAPI 已生成：$SPEC_JSON
环境文件已生成：$ROOT/apifox/environments/

本机 Apifox 桌面端只能导出，不能直接写入项目。导入请：

1. 打开项目 nocobase-kong → 项目设置 → 导入数据 → OpenAPI
   覆盖已有接口，URL：http://127.0.0.1:18765/nocobase-kong-dbless.openapi.json
   导入后「数据模型」会出现 NLA / CHI / LRN / SH / RP / Change / Prosecution
2. 右上角环境管理 → 导入：
   - apifox/environments/local.postman_environment.json
   - apifox/environments/211.postman_environment.json
3. 项目设置关闭 SSL 证书校验（本机 HTTPS 为自签名）
4. 右上角切换「本地测试」或「211 开发服务器」
5. 先跑 POST /v1/auth/token，再测其它接口

CLI：export APIFOX_ACCESS_TOKEN='APS-...' && $0
EOF
  exit 2
fi

APIFOX_BIN="${APIFOX_BIN:-}"
if [[ -z "$APIFOX_BIN" ]]; then
  if command -v apifox >/dev/null 2>&1; then
    APIFOX_BIN="$(command -v apifox)"
  elif [[ -x /tmp/apifox-cli-tool/node_modules/.bin/apifox ]]; then
    APIFOX_BIN="/tmp/apifox-cli-tool/node_modules/.bin/apifox"
  else
    APIFOX_BIN="npx -y apifox-cli@latest"
  fi
fi

# shellcheck disable=SC2086
$APIFOX_BIN import \
  --access-token "$APIFOX_ACCESS_TOKEN" \
  --project "$PROJECT_ID" \
  --format openapi \
  --file "$SPEC_JSON"
