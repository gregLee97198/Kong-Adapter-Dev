#!/usr/bin/env python3
"""Print safe NocoBase collection metadata for workflow mapping work."""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request
from typing import Any


def request_json(base_url: str, token: str, path: str) -> Any:
    request = urllib.request.Request(
        base_url.rstrip("/") + path,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.load(response)
    return payload.get("data") if isinstance(payload, dict) else payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("collections", nargs="+")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    for collection in args.collections:
        query = urllib.parse.urlencode(
            {"filterByTk": collection, "appends[]": "fields"}
        )
        data = request_json(
            args.base_url,
            token,
            f"/api/collections:get?{query}",
        )
        print(f"\n[{collection}]")
        for field in data.get("fields", []):
            safe = {
                key: field.get(key)
                for key in (
                    "name",
                    "type",
                    "interface",
                    "target",
                    "foreignKey",
                    "sourceKey",
                    "targetKey",
                    "through",
                    "otherKey",
                    "collectionName",
                )
                if field.get(key) is not None
            }
            title = (field.get("uiSchema") or {}).get("title")
            if title:
                safe["title"] = title
            print(json.dumps(safe, ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
