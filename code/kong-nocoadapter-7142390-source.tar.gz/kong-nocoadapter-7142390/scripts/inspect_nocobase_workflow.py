#!/usr/bin/env python3
"""Print a NocoBase workflow graph without exposing authentication material."""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request
from typing import Any


def request_json(base_url: str, token: str, path: str) -> Any:
    request = urllib.request.Request(
        base_url.rstrip("/") + path,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = json.load(response)
    return payload.get("data") if isinstance(payload, dict) else payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", required=True, type=int)
    parser.add_argument("--config", action="store_true")
    parser.add_argument("--node-id", action="append", type=int, default=[])
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    query = urllib.parse.urlencode(
        {"filterByTk": str(args.workflow_id), "appends[]": "nodes"}
    )
    workflow = request_json(
        args.base_url,
        token,
        f"/api/workflows:get?{query}",
    )
    print(
        json.dumps(
            {
                key: workflow.get(key)
                for key in ("id", "key", "title", "type", "enabled", "executed")
            },
            ensure_ascii=False,
        )
    )
    selected_ids = set(args.node_id)
    for node in workflow.get("nodes") or []:
        if selected_ids and int(node.get("id")) not in selected_ids:
            continue
        summary = {
            key: node.get(key)
            for key in (
                "id",
                "key",
                "title",
                "type",
                "upstreamId",
                "downstreamId",
                "branchIndex",
            )
        }
        if args.config:
            summary["config"] = node.get("config")
        else:
            config = node.get("config") or {}
            summary["collection"] = config.get("collection")
            summary["appends"] = config.get("appends")
            params = config.get("params") or {}
            if isinstance(params, dict):
                summary["fields"] = sorted((params.get("values") or {}).keys())
        print(json.dumps(summary, ensure_ascii=False, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
