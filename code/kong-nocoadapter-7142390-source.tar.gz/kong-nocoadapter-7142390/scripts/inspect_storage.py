#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import httpx


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read the current default file storage configuration"
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv(
            "NOCOBASE_BASE_URL",
            "http://119.91.104.211:13001/cmtf2",
        ),
    )
    parser.add_argument(
        "--config-token-file",
        default=os.getenv("NOCOBASE_CONFIG_TOKEN_FILE", ""),
    )
    parser.add_argument(
        "--storage-name",
        default=os.getenv("NOCOBASE_STORAGE_NAME", ""),
    )
    parser.add_argument("--insecure", action="store_true")
    return parser.parse_args()


def read_config_token(path_value: str) -> str:
    direct = os.getenv("NOCOBASE_CONFIG_TOKEN", "").strip()
    if direct:
        return direct
    if not path_value:
        raise SystemExit(
            "Set NOCOBASE_CONFIG_TOKEN or pass --config-token-file; "
            "the token is never printed."
        )
    path = Path(path_value)
    if not path.is_file():
        raise SystemExit(f"Config token file does not exist: {path}")
    value = path.read_text(encoding="utf-8").strip()
    if not value:
        raise SystemExit(f"Config token file is empty: {path}")
    return value


def main() -> int:
    args = parse_args()
    config_token = read_config_token(args.config_token_file)
    endpoint = "/api/storages:getBasicInfo"
    if args.storage_name:
        endpoint = f"{endpoint}/{args.storage_name}"
    try:
        response = httpx.get(
            f"{args.base_url.rstrip('/')}{endpoint}",
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {config_token}",
                "X-Authenticator": os.getenv(
                    "NOCOBASE_AUTHENTICATOR", "basic"
                ),
            },
            timeout=20,
            verify=not args.insecure,
            follow_redirects=False,
        )
    except httpx.RequestError as exc:
        print(f"Connection failed: {type(exc).__name__}", file=sys.stderr)
        return 2
    if not 200 <= response.status_code < 300:
        print(f"HTTP {response.status_code}", file=sys.stderr)
        return 1
    payload = response.json()
    data = payload.get("data", payload) if isinstance(payload, dict) else payload
    if not isinstance(data, dict):
        print("Unexpected response format", file=sys.stderr)
        return 1
    allowed = {"id", "title", "name", "type", "rules", "baseUrl", "public"}
    sanitized = {key: value for key, value in data.items() if key in allowed}
    print(json.dumps(sanitized, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
