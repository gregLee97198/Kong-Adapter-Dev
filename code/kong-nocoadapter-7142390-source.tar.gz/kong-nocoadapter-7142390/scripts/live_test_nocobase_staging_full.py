#!/usr/bin/env python3
"""Run a complete 181 NLA staging test, including relations and attachments."""

from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import decimal
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from collections.abc import Mapping
from typing import Any, Optional

from extend_nocobase_staging_relations import CHECKLIST_SPECIAL_NAMES

WORKFLOW_ID = 384761304186880
FINAL_STATUSES = {"succeeded", "failed", "missing_required", "invalid_request"}
SUBMITTER_USER_ID = 12
SUBMITTER_POST_CODE = "S(LR)2"
INTAKE_OFFICER_USER_ID = 45
INTAKE_OFFICER_POST_CODE = "S(LR)1"


class TestError(RuntimeError):
    pass


class Api:
    def __init__(self, base_url: str, token: str, workflow_id: int) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.workflow_id = workflow_id

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        data = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        if body is not None:
            data = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:1200]
            raise TestError(f"HTTP {exc.code} for {path}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise TestError(f"Request failed for {path}: {exc.reason}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise TestError(f"NocoBase returned errors for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded

    def get(
        self, collection: str, record_id: int, appends: tuple[str, ...] = ()
    ) -> dict[str, Any]:
        query: list[tuple[str, str]] = [("filterByTk", str(record_id))]
        query.extend(("appends[]", field) for field in appends)
        value = self.request(
            "GET", f"/api/{collection}:get?{urllib.parse.urlencode(query)}"
        )
        if not isinstance(value, dict):
            raise TestError(f"{collection} record {record_id} was not returned")
        return value

    def list(
        self,
        collection: str,
        filters: Mapping[str, Any],
        appends: tuple[str, ...] = (),
    ) -> list[dict[str, Any]]:
        query: list[tuple[str, str]] = [
            ("filter", json.dumps(filters, separators=(",", ":"))),
            ("pageSize", "200"),
        ]
        query.extend(("appends[]", field) for field in appends)
        value = self.request(
            "GET", f"/api/{collection}:list?{urllib.parse.urlencode(query)}"
        )
        if not isinstance(value, list):
            raise TestError(f"{collection} list did not return an array")
        return value

    def set_workflow_enabled(self, enabled: bool) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(self.workflow_id)})
        self.request("POST", f"/api/workflows:update?{query}", {"enabled": enabled})

    def upload_test_attachment(self, position_code: str) -> dict[str, Any]:
        boundary = f"----codex-{uuid.uuid4().hex}"
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", position_code).strip("-")
        filename = f"nla-{safe_name.lower()}.txt"
        content = (
            "CMTF-II NLA attachment acceptance test\n"
            f"Position: {position_code}\n"
        ).encode()
        body = b"".join(
            [
                f"--{boundary}\r\n".encode(),
                (
                    'Content-Disposition: form-data; name="file"; '
                    f'filename="{filename}"\r\n'
                ).encode(),
                b"Content-Type: text/plain\r\n\r\n",
                content,
                b"\r\n",
                f"--{boundary}--\r\n".encode(),
            ]
        )
        request = urllib.request.Request(
            self.base_url + "/api/attachments:create",
            data=body,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=90) as response:
                decoded = json.loads(response.read())
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:1200]
            raise TestError(
                f"Attachment upload failed for {position_code}: "
                f"HTTP {exc.code}: {detail}"
            ) from exc
        value = decoded.get("data") if isinstance(decoded, dict) else None
        if not isinstance(value, dict) or value.get("id") is None:
            raise TestError(f"Attachment upload returned no ID for {position_code}")
        return value


def full_address(label: str, unit: str) -> dict[str, Any]:
    return {
        "region_code": "0",
        "district_code": "C",
        "sub_district_code": "Admiralty",
        "full_name_en": f"{unit}, {label} Building, 1 Test Road, Admiralty",
        "full_name_cn": f"金鐘測試道1號{label}大廈{unit}",
        "lot_or_address_en": "Inland Lot 100",
        "lot_or_address_cn": "內地段100號",
        "block_no_en": "A",
        "block_no_cn": "甲",
        "block_type_en": "0",
        "block_type_cn": "0",
        "floor_en": "10",
        "floor_cn": "十",
        "unit_no_en": unit,
        "unit_no_cn": unit,
        "unit_type_en": "3",
        "unit_type_cn": "3",
        "building_name_en": f"{label} Building",
        "building_name_cn": f"{label}大廈",
        "estate_or_village_en": "Acceptance Estate",
        "estate_or_village_cn": "驗收邨",
        "street_no_en": "1",
        "street_no_cn": "1",
        "street_name_en": "Test Road",
        "street_name_cn": "測試道",
        "phase_en": "Phase 1",
        "phase_cn": "第一期",
    }


def full_contact(label: str, suffix: str) -> dict[str, Any]:
    return {
        "title": "Mr",
        "display_name": f"{label} Contact",
        "full_name_en": f"{label.upper()} CHAN",
        "full_name_cn": f"{label}陳",
        "first_name_en": label,
        "middle_name_en": "Acceptance",
        "last_name_en": "Chan",
        "surname_cn": "陳",
        "given_name_cn": label,
        "hkid_part_1": "A",
        "hkid_part_2": f"12345{suffix}",
        "hkid_part_3": suffix,
        "position_title": f"{label} Manager",
        "representative_position": f"{label} Representative",
        "contact_relationship": "OTHER",
        "contact_relationship_other": "Integration acceptance",
        "mobile_phone": f"9123456{suffix}",
        "residential_phone": f"2123456{suffix}",
        "office_phone": f"3123456{suffix}",
        "email": f"{label.lower()}@example.com",
        "office_email": f"{label.lower()}.office@example.com",
        "company_name_en": "CMTF Acceptance Organisation",
        "company_name_cn": "CMTF 驗收機構",
        "business_registration_no": f"BR-2026-{suffix}",
        "certificate_of_incorporation_no": f"CI-2026-{suffix}",
        "application_type": "0",
        "address_for_licence": True,
        "active": True,
        "address": full_address(label, suffix),
    }


def build_payload(
    main_id: int, checklist_files: list[tuple[str, int]]
) -> dict[str, Any]:
    now = dt.datetime.now().astimezone()
    suffix = now.strftime("%Y%m%d-%H%M%S")
    request_id = f"NLA-STAGING-FULL-{suffix}"
    return {
        "request_id": request_id,
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "submitter_user_id": SUBMITTER_USER_ID,
                "received_date": now.date().isoformat(),
                "severity": "0",
                "source_id": 368984590778368,
                "source_other": "OP full-field integration acceptance",
                "task_owner_user_id": INTAKE_OFFICER_USER_ID,
                "task_owner_post_code": INTAKE_OFFICER_POST_CODE,
            },
            "part_1": {
                "application_received_date": now.date().isoformat(),
                "application_type": "0",
                "tentative_commencement_date": "2026-12-01",
            },
            "part_2": {
                "rch_name_en": f"CODEX FULL FIELD RCH {suffix}",
                "rch_name_cn": f"CODEX 全字段驗收院舍 {suffix}",
                "operation_mode_id": "CUM",
                "premises_type": "1",
                "monthly_fee_min": 8100,
                "monthly_fee_max": 12800,
                "gender": "1",
                "floor_area_sqm": 418.75,
                "licence_capacity": 52,
                "address": full_address("MainRCH", "10"),
                "telephone_no": "21234567",
                "fax_no": "21234568",
                "email": "full-field-rch@example.com",
                "floors_total": 2,
                "units_total": 4,
                "operation_mode_other": "Not applicable",
                "is_rcsv": True,
                "rch_type_code": "a1",
                "complies_lease_dmc": True,
                "complies_lease_dmc_other": "Verified by OP",
                "nursing_home_places": 12,
                "care_and_attention_home_places": 14,
                "aged_home_places": 16,
                "self_care_hostel_places": 10,
                "max_capacity": 60,
                "existing_capacity": 40,
                "enrolment_residents": 36,
                "premises": {
                    "self_owned": [
                        {
                            "premise_type": "0",
                            "location": "Self-owned east wing",
                            "tenancy_from": "2026-01-01",
                            "tenancy_to": "2036-12-31",
                            "sort_order": 1,
                            "address": full_address("SelfOwned", "11"),
                        }
                    ],
                    "rented": [
                        {
                            "premise_type": "1",
                            "location": "Rented west wing",
                            "tenancy_from": "2026-01-01",
                            "tenancy_to": "2028-12-31",
                            "sort_order": 2,
                            "address": full_address("Rented", "12"),
                        }
                    ],
                },
            },
            "part_3": {
                "rch_business_status": "0",
                "applicant_operator_type": "0",
                "date_of_operation": "2026-11-01",
                "signature_date": now.date().isoformat(),
                "operator": full_contact("Operator", "2"),
                "company": full_contact("Company", "3"),
                "personnel": [
                    full_contact("PartnerOne", "4"),
                    full_contact("PartnerTwo", "5"),
                ],
            },
            "part_4": {
                "authorised_representative": full_contact("Representative", "1")
            },
            "part_5": {
                "application_level": "normal",
                "comments": "Complete OP payload with explicit business identities",
                "other_information": "All API Spec fields populated for acceptance",
                "remarks": "181 development full-field test",
                "attachment_ids": [main_id],
                "checklist": [
                    {
                        "position_code": position_code,
                        "checked": True,
                        "status": "1",
                        "remarks": "Attachment supplied by OP staging UAT",
                        "attachment_id": attachment_id,
                    }
                    for position_code, attachment_id in checklist_files
                ],
            },
        },
    }


def as_ids(values: Any) -> set[int]:
    if not isinstance(values, list):
        return set()
    result: set[int] = set()
    for value in values:
        candidate = value.get("id") if isinstance(value, dict) else value
        try:
            result.add(int(candidate))
        except (TypeError, ValueError):
            continue
    return result


def assert_value(actual: Any, expected: Any, label: str, failures: list[str]) -> None:
    if isinstance(expected, bool) and isinstance(actual, str):
        normalized = actual.strip().lower()
        if normalized in {"true", "false"} and (normalized == "true") is expected:
            return
    if isinstance(expected, (int, float)) and not isinstance(expected, bool):
        try:
            if decimal.Decimal(str(actual)) == decimal.Decimal(str(expected)):
                return
        except decimal.InvalidOperation:
            pass
    if actual != expected:
        failures.append(f"{label}: expected {expected!r}, found {actual!r}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=WORKFLOW_ID)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--timeout-seconds", type=int, default=120)
    parser.add_argument(
        "--checklist-limit",
        type=int,
        default=69,
        help="Number of native Checklist attachment positions to exercise (1-69)",
    )
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    if not args.apply:
        print(
            "error=--apply is required because this test creates records",
            file=sys.stderr,
        )
        return 2
    if not 1 <= args.checklist_limit <= 69:
        raise TestError("--checklist-limit must be between 1 and 69")

    api = Api(args.base_url, token, args.workflow_id)
    workflow = api.get("workflows", args.workflow_id)
    if workflow.get("enabled"):
        raise TestError("Workflow must be Off before controlled execution")

    template_rows = api.list(
        "t_document_checklist",
        {
            "$and": [
                {"f_checklist_code": {"$eq": "LORCHE_STAGE2"}},
                {"f_office_code": {"$eq": "LORCHE"}},
                {"f_item_type": {"$eq": "2"}},
                {"f_active": {"$eq": True}},
            ]
        },
    )
    special_by_name = {value: key for key, value in CHECKLIST_SPECIAL_NAMES.items()}
    position_templates: dict[str, int] = {}
    for row in template_rows:
        source_row = row.get("f_source_excel_row_no")
        if source_row is not None:
            code = f"LORCHE_STAGE2:ROW:{int(source_row)}"
        else:
            alias = special_by_name.get(str(row.get("f_name_en") or ""))
            if not alias:
                raise TestError(
                    "Native Checklist document has no portable position code: "
                    f"template_id={row.get('id')}"
                )
            code = f"LORCHE_STAGE2:{alias}"
        position_templates[code] = int(row["id"])
    if len(position_templates) != 69:
        raise TestError(
            f"Expected 69 native attachment positions, found {len(position_templates)}"
        )
    position_templates = dict(
        sorted(position_templates.items())[: args.checklist_limit]
    )

    upload_codes = ["MAIN_APPLICATION"] + sorted(position_templates)
    uploaded: dict[str, dict[str, Any]] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        futures = {
            executor.submit(api.upload_test_attachment, code): code
            for code in upload_codes
        }
        for future in concurrent.futures.as_completed(futures):
            code = futures[future]
            uploaded[code] = future.result()
    print(f"uploaded_test_attachment_count={len(uploaded)}")
    checklist_files = [
        (code, int(uploaded[code]["id"])) for code in sorted(position_templates)
    ]
    main_attachment_id = int(uploaded["MAIN_APPLICATION"]["id"])
    payload = build_payload(main_attachment_id, checklist_files)
    form_data = payload["form_data"]

    staging_values = {
        "f_request_body": payload,
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_user_role": "root",
        "f_status": "received",
    }
    final: dict[str, Any] = {}
    primary_error: Optional[Exception] = None
    disable_error: Optional[Exception] = None
    try:
        api.set_workflow_enabled(True)
        print("workflow_enabled_for_test=true")
        created = api.request(
            "POST", "/api/t_api_request_staging:create", staging_values
        )
        if not isinstance(created, dict) or created.get("id") is None:
            raise TestError("Staging create response is missing an ID")
        print(f"request_id={payload['request_id']}")
        print(f"staging_id={created['id']}")
        deadline = time.monotonic() + args.timeout_seconds
        observed: list[str] = []
        while time.monotonic() < deadline:
            final = api.get("t_api_request_staging", int(created["id"]))
            status = str(final.get("f_status") or "")
            if not observed or observed[-1] != status:
                observed.append(status)
                print(f"observed_status={status}")
            if status in FINAL_STATUSES:
                break
            time.sleep(1)
        else:
            raise TestError("Staging workflow did not finish before timeout")
    except Exception as exc:
        primary_error = exc
    finally:
        try:
            api.set_workflow_enabled(False)
            print("workflow_restored_off=true")
        except Exception as exc:
            disable_error = exc
    if disable_error:
        raise TestError(f"Could not restore workflow Off: {disable_error}")
    if primary_error:
        raise primary_error

    failures: list[str] = []
    assert_value(final.get("f_status"), "succeeded", "staging status", failures)
    intake_id = int(final.get("f_intake_id") or 0)
    application_id = int(final.get("f_application_id") or 0)
    if not intake_id or not application_id:
        raise TestError("Staging record did not backfill both business IDs")
    print(f"intake_id={intake_id}")
    print(f"application_id={application_id}")

    intake = api.get("t_intake_form", intake_id, appends=("f_approval_post",))
    intake_expected = {
        "createdById": SUBMITTER_USER_ID,
        "fk_created_by_post": SUBMITTER_POST_CODE,
        "fk_task_owner": INTAKE_OFFICER_USER_ID,
        "fk_task_owner_post": INTAKE_OFFICER_POST_CODE,
        "fk_intake_type": 364490020880384,
        "f_office_cd": "LORCHE",
        "f_subject": form_data["part_2"]["rch_name_en"],
        # The public accept value is normalized to NocoBase value "0".  For
        # this non-GR S(LR)2 submitter, the native workflow completes the
        # Intake without a recommendation or case-closure approval task.
        "f_approval_status": "4",
        "fk_approval_post": None,
    }
    for field, expected in intake_expected.items():
        assert_value(intake.get(field), expected, f"Intake {field}", failures)

    nla = api.get("t_licence_app", application_id, appends=("f_attachments_of_rchs",))
    nla_expected = {
        "createdById": SUBMITTER_USER_ID,
        "fk_created_by_post": SUBMITTER_POST_CODE,
        "f_office_cd": "LORCHE",
        "f_p_no": None,
        "f_d_no": None,
        "f_app_type": "0",
        "f_application_received_date": (
            f"{form_data['part_1']['application_received_date']}T00:00:00.000Z"
        ),
        "f_tentative_service_commencement_date": "2026-12-01T00:00:00.000Z",
        "f_rch_name_en": form_data["part_2"]["rch_name_en"],
        "f_rch_name_cn": form_data["part_2"]["rch_name_cn"],
        "f_telephone_no": "21234567",
        "f_fax_no": "21234568",
        "f_email": "full-field-rch@example.com",
        "f_floors_total": 2,
        "f_units_total": 4,
        "fk_rch_nature": "CUM",
        "f_rch_nature_other": "Not applicable",
        "f_is_rcsv": True,
        "fk_type_of_rch": 375747212083200,
        "f_rch_premises": "1",
        "f_complies_lease_dmc": True,
        "f_complies_lease_dmc_other": "Verified by OP",
        "f_monthly_fee_per_resident_min": 8100,
        "f_monthly_fee_per_resident_max": 12800,
        "f_rch_gender": "1",
        "f_beds_nursing": 12,
        "f_beds_care_and_attention": 14,
        "f_beds_meal": 16,
        "f_beds_self_care": 10,
        "f_beds_total": 52,
        "f_net_floor_area_sqm": 418.75,
        "f_licence_capacity": 52,
        "f_service_type": "0",
        "f_business_ownership_type": "0",
        "f_application_level": "normal",
        "f_max_capacity": 60,
        "f_existing_capacity": 40,
        "f_enrolment_residents": 36,
        "f_other_information": "All API Spec fields populated for acceptance",
        "f_remarks": "181 development full-field test",
        # Completing the Intake starts the native NLA business process.  The
        # 181 enum value "6" is "Assigning Inspection Teams".
        "f_approval_status": "6",
    }
    for field, expected in nla_expected.items():
        assert_value(nla.get(field), expected, f"NLA {field}", failures)
    if main_attachment_id not in as_ids(nla.get("f_attachments_of_rchs")):
        failures.append("NLA main attachment relation is missing")

    main_address_id = int(nla.get("fk_rch_address") or 0)
    if not main_address_id:
        failures.append("NLA main RCH address relation is missing")
        main_address: dict[str, Any] = {}
    else:
        main_address = api.get("t_address", main_address_id)
        address_expected = {
            "fk_region_en": "Hong Kong",
            "fk_region_cn": "香港",
            "fk_district_name_en": "Central & Western District",
            "fk_district_name_cn": "中西區",
            "fk_sub_district_en": "Admiralty",
            "fk_sub_district_cn": "金鐘",
            "f_block_type_en": "0",
            "f_block_type_cn": "0",
            "f_unit_type_en": "3",
            "f_unit_type_cn": "3",
        }
        for field, expected in address_expected.items():
            assert_value(
                main_address.get(field), expected, f"Main address {field}", failures
            )
        if main_address.get("fk_address_select") is not None:
            failures.append("Main address unexpectedly populated Address Select")

    contact_specs = {
        "fk_licence_contact_applicant": (1, "REPRESENTATIVE CHAN"),
        "fk_licence_contact_operator": (1, "OPERATOR CHAN"),
        "fk_licence_contact_company": (1, "COMPANY CHAN"),
        "fk_licence_contact_person": (2, None),
    }
    contact_total = 0
    address_ids: set[int] = set()
    for foreign_key, (expected_count, expected_name) in contact_specs.items():
        rows = api.list("t_licence_contact", {foreign_key: application_id})
        contact_total += len(rows)
        if len(rows) != expected_count:
            failures.append(
                f"Contact {foreign_key}: expected {expected_count}, found {len(rows)}"
            )
        if expected_name and rows:
            assert_value(
                rows[0].get("f_full_name_en"),
                expected_name,
                f"Contact {foreign_key} name",
                failures,
            )
        for row in rows:
            if row.get("fk_address_correspondence"):
                address_ids.add(int(row["fk_address_correspondence"]))

    premises = api.list(
        "t_licence_app_premise", {"fk_licence_app_premise": application_id}
    )
    if len(premises) != 2:
        failures.append(f"Premises: expected 2, found {len(premises)}")
    for row in premises:
        address_id = row.get("fk_address_self_owned") or row.get("fk_address_rented")
        if address_id:
            address_ids.add(int(address_id))
    if len(address_ids) != 7:
        failures.append(f"Related addresses: expected 7, found {len(address_ids)}")

    checklists = api.list(
        "t_document_submitted_for_application",
        {"f_business_key": application_id, "f_business_type": "t_licence_app"},
        appends=("f_lastest_files", "f_document_checklist"),
    )
    checklist_by_template = {
        int(row["fk_document_checklist"]): row
        for row in checklists
        if row.get("fk_document_checklist") is not None
    }
    checklist_ids = [int(row["id"]) for row in checklists]
    details = api.list(
        "t_document_submitted_for_application_details",
        {
            "fk_documests_submitted_for_application_id": {
                "$in": checklist_ids
            }
        },
        appends=("f_files",),
    )
    details_by_parent: dict[int, list[dict[str, Any]]] = {}
    for detail in details:
        parent_id = int(
            detail.get("fk_documests_submitted_for_application_id") or 0
        )
        details_by_parent.setdefault(parent_id, []).append(detail)
    for code, template_id in position_templates.items():
        attachment_id = int(uploaded[code]["id"])
        row = checklist_by_template.get(template_id)
        if not row:
            failures.append(f"Native Checklist {code} was not created")
            continue
        if attachment_id not in as_ids(row.get("f_lastest_files")):
            failures.append(f"Native Checklist {code} latest attachment is missing")
        if row.get("f_lastest_files_name") != uploaded[code].get("filename"):
            failures.append(f"Native Checklist {code} latest filename was not queried")
        matching_details = [
            detail
            for detail in details_by_parent.get(int(row["id"]), [])
            if attachment_id in as_ids(detail.get("f_files"))
        ]
        if not matching_details:
            failures.append(f"Native Checklist {code} Details record is missing")
        elif matching_details[-1].get("f_file_name") != uploaded[code].get(
            "filename"
        ):
            failures.append(f"Native Checklist {code} Details filename is missing")

    activities = api.list(
        "t_intake_activity",
        {"fk_activity": intake_id},
        appends=("f_attachments",),
    )
    api_activities = [
        row
        for row in activities
        if row.get("f_activity") == "Online Platform"
        and row.get("f_activity_status") == "completed"
    ]
    if len(api_activities) != 1:
        failures.append(
            f"Intake API receipt Activity: expected 1, found {len(api_activities)}"
        )
        api_activity: dict[str, Any] = {}
    else:
        api_activity = api_activities[0]
        if main_attachment_id not in as_ids(api_activity.get("f_attachments")):
            failures.append("Intake Activity main attachment is missing")
        assert_value(
            api_activity.get("createdById"),
            SUBMITTER_USER_ID,
            "Intake Activity createdById",
            failures,
        )
        assert_value(
            api_activity.get("fk_received_by"),
            INTAKE_OFFICER_USER_ID,
            "Intake Activity fk_received_by",
            failures,
        )

    approval_logs = api.list(
        "t_approval_log",
        {"f_collection_name": "t_intake_form", "f_data_key": intake_id},
    )
    submitted_log = any(
        row.get("fk_completed_user") == SUBMITTER_USER_ID
        and row.get("fk_completed_post") == SUBMITTER_POST_CODE
        and str(row.get("f_node_val")) == "0"
        and str(row.get("f_status")) == "3"
        for row in approval_logs
    )
    unexpected_pending_approval = any(
        str(row.get("f_status")) == "8"
        and str(row.get("f_node_val")) in {"5", "6"}
        for row in approval_logs
    )
    if not submitted_log:
        failures.append("Native Intake submit audit log is missing")
    if unexpected_pending_approval:
        failures.append("Completed Intake unexpectedly has a pending approval task")

    print(f"intake_submitter_user_id={intake.get('createdById')}")
    print(f"intake_submitter_post={intake.get('fk_created_by_post')}")
    print(f"intake_officer_user_id={intake.get('fk_task_owner')}")
    print(f"intake_officer_post={intake.get('fk_task_owner_post')}")
    print(f"intake_approval_status={intake.get('f_approval_status')}")
    print(f"intake_approval_post={intake.get('fk_approval_post')}")
    print(f"nla_approval_status={nla.get('f_approval_status')}")
    print(f"approval_log_count={len(approval_logs)}")
    print(f"submit_audit_log_verified={str(submitted_log).lower()}")
    print(
        "no_pending_approval_verified="
        f"{str(not unexpected_pending_approval).lower()}"
    )
    print(f"main_rch_address_id={main_address_id}")
    print(f"main_address_select={main_address.get('fk_address_select')}")
    print(f"nla_main_attachment_ids={sorted(as_ids(nla.get('f_attachments_of_rchs')))}")
    print(f"contact_record_count={contact_total}")
    print(f"related_address_count={len(address_ids)}")
    print(f"premise_record_count={len(premises)}")
    print(f"api_checklist_record_count={len(checklists)}")
    print(f"checklist_details_record_count={len(details)}")
    print(f"intake_activity_id={api_activity.get('id')}")
    print(
        "intake_activity_attachment_ids="
        f"{sorted(as_ids(api_activity.get('f_attachments')))}"
    )
    print(f"native_attachment_position_count={len(position_templates)}")
    print(f"assertion_failure_count={len(failures)}")
    for failure in failures:
        print(f"assertion_failure={failure}")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
