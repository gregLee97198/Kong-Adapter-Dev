#!/usr/bin/env python3
"""Run one controlled partial-update test and always restore the workflow Off."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import time
import urllib.parse
from typing import Any

from extend_nocobase_staging_relations import (
    CHECKLIST_SPECIAL_NAMES,
    ApiError,
    NocoBaseApi,
)

DEFAULT_WORKFLOW_ID = 384765704011776
DEFAULT_CREATE_ID = 384761337741312
FINAL_STATUSES = {"succeeded", "failed", "missing_required", "invalid_request"}


def get_record(
    api: NocoBaseApi, collection: str, record_id: Any, *, appends: tuple[str, ...] = ()
) -> dict[str, Any]:
    query: list[tuple[str, str]] = [("filterByTk", str(record_id))]
    query.extend(("appends[]", value) for value in appends)
    value = api.request("GET", f"/api/{collection}:get?{urllib.parse.urlencode(query)}")
    if not isinstance(value, dict):
        raise ApiError(f"{collection} record {record_id} was not returned")
    return value


def list_records(
    api: NocoBaseApi,
    collection: str,
    filters: dict[str, Any],
    *,
    appends: tuple[str, ...] = (),
) -> list[dict[str, Any]]:
    query: list[tuple[str, str]] = [
        ("filter", json.dumps(filters, separators=(",", ":"))),
        ("pageSize", "500"),
    ]
    query.extend(("appends[]", value) for value in appends)
    value = api.request(
        "GET",
        f"/api/{collection}:list?{urllib.parse.urlencode(query)}",
    )
    if not isinstance(value, list):
        raise ApiError(f"{collection} list did not return an array")
    return value


def checklist_position(template: dict[str, Any]) -> str:
    source_row = template.get("f_source_excel_row_no")
    checklist_code = str(template.get("f_checklist_code") or "")
    if source_row is not None:
        return f"{checklist_code}:ROW:{int(source_row)}"
    special_by_name = {value: key for key, value in CHECKLIST_SPECIAL_NAMES.items()}
    special = special_by_name.get(str(template.get("f_name_en") or ""))
    return f"{checklist_code}:{special}" if special else ""


def update_workflow_enabled(api: NocoBaseApi, workflow_id: int, enabled: bool) -> None:
    api.request(
        "POST",
        f"/api/workflows:update?{urllib.parse.urlencode({'filterByTk': workflow_id})}",
        {"enabled": enabled},
    )


def require_equal(actual: Any, expected: Any, label: str, failures: list[str]) -> None:
    if actual != expected:
        failures.append(f"{label}: expected {expected!r}, found {actual!r}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument("--create-id", type=int, default=DEFAULT_CREATE_ID)
    parser.add_argument("--timeout-seconds", type=int, default=60)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    if not args.apply:
        print(
            "error=--apply is required because this test updates live test data",
            file=sys.stderr,
        )
        return 2

    api = NocoBaseApi(args.base_url, token)
    workflow = get_record(api, "workflows", args.workflow_id)
    if workflow.get("enabled"):
        print("error=workflow must be Off before the controlled test", file=sys.stderr)
        return 1

    create_staging = get_record(api, "t_api_request_staging", args.create_id)
    intake_id = create_staging.get("f_intake_id")
    application_id = create_staging.get("f_application_id")
    if (
        create_staging.get("f_status") != "succeeded"
        or not intake_id
        or not application_id
    ):
        print(
            "error=create-id is not a successful Create staging record", file=sys.stderr
        )
        return 1

    before_intake = get_record(api, "t_intake_form", intake_id)
    before_nla = get_record(
        api,
        "t_licence_app",
        application_id,
        appends=("f_attachments_of_rchs",),
    )
    address_id = before_nla.get("fk_rch_address")
    if not address_id:
        print("error=linked NLA has no main RCH address", file=sys.stderr)
        return 1
    before_address = get_record(api, "t_address", address_id)
    contact_filter = {
        "$or": [
            {"fk_licence_contact_applicant": {"$eq": application_id}},
            {"fk_licence_contact_operator": {"$eq": application_id}},
            {"fk_licence_contact_company": {"$eq": application_id}},
            {"fk_licence_contact_person": {"$eq": application_id}},
        ]
    }
    contacts = list_records(
        api,
        "t_licence_contact",
        contact_filter,
        appends=("f_address_correspondence",),
    )
    operator = next(
        (
            row
            for row in contacts
            if str(row.get("fk_licence_contact_operator")) == str(application_id)
        ),
        None,
    )
    if not operator or not operator.get("fk_address_correspondence"):
        print("error=linked NLA has no operator/contact address", file=sys.stderr)
        return 1
    premises = list_records(
        api,
        "t_licence_app_premise",
        {"fk_licence_app_premise": {"$eq": application_id}},
        appends=("f_address_self_owned", "f_address_rented"),
    )
    self_owned = next(
        (row for row in premises if row.get("fk_address_self_owned")),
        None,
    )
    if not self_owned:
        print("error=linked NLA has no self-owned premise", file=sys.stderr)
        return 1
    create_body = create_staging.get("f_request_body") or {}
    create_checklist = ((create_body.get("form_data") or {}).get("part_5") or {}).get(
        "checklist"
    ) or []
    attachment_by_position = {
        str(item["position_code"]): item["attachment_id"]
        for item in create_checklist
        if item.get("position_code") and item.get("attachment_id")
    }
    checklist_rows = list_records(
        api,
        "t_document_submitted_for_application",
        {
            "f_business_key": {"$eq": application_id},
            "f_business_type": {"$eq": "t_licence_app"},
            "fk_document_checklist": {"$ne": None},
        },
        appends=("f_document_checklist",),
    )
    checklist_row = next(
        (
            row
            for row in checklist_rows
            if isinstance(row.get("f_document_checklist"), dict)
            and checklist_position(row["f_document_checklist"])
            in attachment_by_position
        ),
        None,
    )
    if not checklist_row:
        print(
            "error=linked NLA has no supplied portable native Checklist item",
            file=sys.stderr,
        )
        return 1
    position_code = checklist_position(checklist_row["f_document_checklist"])
    attachment_id = attachment_by_position.get(position_code)
    if not attachment_id:
        print(
            "error=Create staging has no attachment for selected Checklist item",
            file=sys.stderr,
        )
        return 1
    before_details = list_records(
        api,
        "t_document_submitted_for_application_details",
        {"fk_documests_submitted_for_application_id": {"$eq": checklist_row["id"]}},
    )

    suffix = dt.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    expected = {
        "source_other": f"OP partial update acceptance {suffix}",
        "rch_name_en": f"CODEX UPDATED RCH {suffix}",
        "telephone_no": "21239999",
        "building_name_en": f"Updated MainRCH Building {suffix}",
        "remarks": f"Updated through update_new_licence_data {suffix}",
        "operator_mobile": "91239991",
        "operator_building": f"Updated Operator Building {suffix}",
        "premise_location": f"Updated self-owned east wing {suffix}",
        "premise_building": f"Updated Premise Building {suffix}",
        "checklist_status": "2",
        "checklist_remarks": f"Updated Checklist through API {suffix}",
    }
    request_body = {
        "request_id": f"NLA-UPDATE-{suffix}",
        "create_id": str(args.create_id),
        "form_data": {
            "case_summary": {"source_other": expected["source_other"]},
            "part_2": {
                "rch_name_en": expected["rch_name_en"],
                "telephone_no": expected["telephone_no"],
                "address": {"building_name_en": expected["building_name_en"]},
                "premises": {
                    "self_owned": [
                        {
                            "location": expected["premise_location"],
                            "address": {
                                "building_name_en": expected["premise_building"]
                            },
                        }
                    ]
                },
            },
            "part_3": {
                "operator": {
                    "id": operator["id"],
                    "mobile_phone": expected["operator_mobile"],
                    "address": {"building_name_en": expected["operator_building"]},
                }
            },
            "part_5": {
                "remarks": expected["remarks"],
                "checklist": [
                    {
                        "position_code": position_code,
                        "status": expected["checklist_status"],
                        "remarks": expected["checklist_remarks"],
                        "attachment_id": attachment_id,
                    }
                ],
            },
        },
    }
    staging_values = {
        "f_request_body": request_body,
        "f_source_system": "OP",
        "f_request_event": "UPDATE",
        "f_api_type": "update_new_licence_data",
        "f_user_role": "root",
        "f_status": "received",
    }

    final: dict[str, Any] = {}
    primary_error: Exception | None = None
    disable_error: Exception | None = None
    try:
        update_workflow_enabled(api, args.workflow_id, True)
        print("workflow_enabled_for_test=true")
        created = api.request(
            "POST", "/api/t_api_request_staging:create", staging_values
        )
        if not isinstance(created, dict) or created.get("id") is None:
            raise ApiError("Update staging create response is missing an ID")
        update_id = int(created["id"])
        print(f"request_id={request_body['request_id']}")
        print(f"create_id={args.create_id}")
        print(f"update_id={update_id}")

        deadline = time.monotonic() + args.timeout_seconds
        observed: list[str] = []
        while time.monotonic() < deadline:
            final = get_record(api, "t_api_request_staging", update_id)
            status = str(final.get("f_status") or "")
            if not observed or observed[-1] != status:
                observed.append(status)
                print(f"observed_status={status}")
            if status in FINAL_STATUSES:
                break
            time.sleep(1)
        else:
            raise ApiError(
                f"Update workflow did not finish in {args.timeout_seconds} seconds"
            )
    except Exception as exc:
        primary_error = exc
    finally:
        try:
            update_workflow_enabled(api, args.workflow_id, False)
            print("workflow_restored_off=true")
        except Exception as exc:
            disable_error = exc

    if disable_error:
        print(f"error=failed to restore workflow Off: {disable_error}", file=sys.stderr)
        return 1
    if primary_error:
        print(f"error={primary_error}", file=sys.stderr)
        return 1

    after_intake = get_record(api, "t_intake_form", intake_id)
    after_nla = get_record(
        api,
        "t_licence_app",
        application_id,
        appends=("f_attachments_of_rchs",),
    )
    after_address = get_record(api, "t_address", address_id)
    after_operator = get_record(api, "t_licence_contact", operator["id"])
    after_operator_address = get_record(
        api,
        "t_address",
        operator["fk_address_correspondence"],
    )
    after_premise = get_record(api, "t_licence_app_premise", self_owned["id"])
    after_premise_address = get_record(
        api,
        "t_address",
        self_owned["fk_address_self_owned"],
    )
    after_checklist = get_record(
        api,
        "t_document_submitted_for_application",
        checklist_row["id"],
        appends=("f_lastest_files",),
    )
    after_details = list_records(
        api,
        "t_document_submitted_for_application_details",
        {"fk_documests_submitted_for_application_id": {"$eq": checklist_row["id"]}},
        appends=("f_files",),
    )
    failures: list[str] = []

    require_equal(final.get("f_status"), "succeeded", "update staging status", failures)
    require_equal(
        str(final.get("f_intake_id")), str(intake_id), "backfilled Intake ID", failures
    )
    require_equal(
        str(final.get("f_application_id")),
        str(application_id),
        "backfilled NLA ID",
        failures,
    )
    require_equal(
        after_intake.get("f_source_other"),
        expected["source_other"],
        "Intake changed field",
        failures,
    )
    require_equal(
        after_intake.get("f_subject"),
        expected["rch_name_en"],
        "Intake derived subject",
        failures,
    )
    require_equal(
        after_nla.get("f_rch_name_en"),
        expected["rch_name_en"],
        "NLA changed name",
        failures,
    )
    require_equal(
        after_nla.get("f_telephone_no"),
        expected["telephone_no"],
        "NLA changed telephone",
        failures,
    )
    require_equal(
        after_nla.get("f_remarks"), expected["remarks"], "NLA changed remarks", failures
    )
    require_equal(
        after_address.get("f_building_name_en"),
        expected["building_name_en"],
        "Address changed field",
        failures,
    )
    require_equal(
        after_operator.get("f_mobile_phone"),
        expected["operator_mobile"],
        "Operator changed field",
        failures,
    )
    require_equal(
        after_operator_address.get("f_building_name_en"),
        expected["operator_building"],
        "Operator address changed field",
        failures,
    )
    require_equal(
        after_premise.get("f_location"),
        expected["premise_location"],
        "Premise changed field",
        failures,
    )
    require_equal(
        after_premise_address.get("f_building_name_en"),
        expected["premise_building"],
        "Premise address changed field",
        failures,
    )
    require_equal(
        after_checklist.get("f_status"),
        expected["checklist_status"],
        "Checklist changed status",
        failures,
    )
    require_equal(
        after_checklist.get("f_remarks"),
        expected["checklist_remarks"],
        "Checklist changed remarks",
        failures,
    )
    require_equal(
        len(after_details),
        len(before_details) + 1,
        "Checklist Details append",
        failures,
    )
    latest_files = after_checklist.get("f_lastest_files") or []
    latest_file_ids = [str(item.get("id")) for item in latest_files]
    if str(attachment_id) not in latest_file_ids:
        failures.append(
            f"Checklist latest file: attachment {attachment_id!r} not found"
        )

    for field in ("f_approval_status",):
        require_equal(
            after_intake.get(field),
            before_intake.get(field),
            f"Intake {field} preserved",
            failures,
        )
        require_equal(
            after_nla.get(field),
            before_nla.get(field),
            f"NLA {field} preserved",
            failures,
        )
    for field in (
        "f_email",
        "f_beds_total",
        "f_app_type",
        "f_application_received_date",
    ):
        require_equal(
            after_nla.get(field),
            before_nla.get(field),
            f"NLA omitted {field} preserved",
            failures,
        )
    for field in ("f_street_name_en", "fk_region_en"):
        require_equal(
            after_address.get(field),
            before_address.get(field),
            f"Address omitted {field} preserved",
            failures,
        )

    print(f"final_status={final.get('f_status')}")
    print(f"intake_id={intake_id}")
    print(f"application_id={application_id}")
    print(f"intake_approval_status_before={before_intake.get('f_approval_status')}")
    print(f"intake_approval_status_after={after_intake.get('f_approval_status')}")
    print(f"nla_approval_status_before={before_nla.get('f_approval_status')}")
    print(f"nla_approval_status_after={after_nla.get('f_approval_status')}")
    print(f"updated_operator_id={operator['id']}")
    print(f"updated_premise_id={self_owned['id']}")
    print(f"updated_checklist_id={checklist_row['id']}")
    print(f"updated_checklist_position={position_code}")
    print(f"checklist_details_before={len(before_details)}")
    print(f"checklist_details_after={len(after_details)}")
    updated_fields = json.dumps(
        expected,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    print(f"updated_fields={updated_fields}")
    print(f"assertion_failures={len(failures)}")
    for failure in failures:
        print(f"assertion_failure={failure}", file=sys.stderr)
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
