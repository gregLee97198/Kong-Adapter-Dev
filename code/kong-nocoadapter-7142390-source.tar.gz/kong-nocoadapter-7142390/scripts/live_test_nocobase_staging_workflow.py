#!/usr/bin/env python3
"""Run one controlled 181 staging-workflow test and restore the workflow to Off.

The script reuses the previously accepted UAT request body so enum values match the
development environment. It creates a new staging record, waits for the asynchronous
workflow, validates mapped Intake/NLA fields, and disables the workflow in a finally
block. Authentication is read from NOCOBASE_TOKEN and is never printed.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import decimal
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping
from typing import Any, Optional

WORKFLOW_ID = 384608150945792
SOURCE_STAGING_ID = 384607259656192
FINAL_STATUSES = {"succeeded", "failed", "missing_required", "invalid_request"}


class TestError(RuntimeError):
    pass


class Api:
    def __init__(self, base_url: str, token: str, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        data = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        if body is not None:
            data = json.dumps(body, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:800]
            raise TestError(f"HTTP {exc.code} for {path}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise TestError(f"Request failed for {path}: {exc.reason}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise TestError(f"NocoBase returned errors for {path}: {decoded['errors']}")
        return (
            decoded.get("data")
            if isinstance(decoded, dict) and "data" in decoded
            else decoded
        )

    def get(self, collection: str, record_id: int) -> dict[str, Any]:
        query = urllib.parse.urlencode({"filterByTk": str(record_id)})
        value = self.request("GET", f"/api/{collection}:get?{query}")
        if not isinstance(value, dict):
            raise TestError(f"{collection} record {record_id} was not returned")
        return value

    def set_workflow_enabled(self, enabled: bool) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(WORKFLOW_ID)})
        self.request("POST", f"/api/workflows:update?{query}", {"enabled": enabled})


def assert_equal(actual: Any, expected: Any, label: str, failures: list[str]) -> None:
    if actual != expected:
        failures.append(f"{label}: expected {expected!r}, found {actual!r}")


def assert_decimal_equal(
    actual: Any, expected: Any, label: str, failures: list[str]
) -> None:
    try:
        if decimal.Decimal(str(actual)) != decimal.Decimal(str(expected)):
            failures.append(f"{label}: expected {expected!r}, found {actual!r}")
    except decimal.InvalidOperation:
        failures.append(f"{label}: expected numeric {expected!r}, found {actual!r}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--timeout-seconds", type=int, default=45)
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    if not args.apply:
        print(
            "error=--apply is required because this test creates records",
            file=sys.stderr,
        )
        return 2

    api = Api(args.base_url, token)
    workflow = api.get("workflows", WORKFLOW_ID)
    if workflow.get("enabled"):
        print("error=workflow must be Off before the controlled test", file=sys.stderr)
        return 1

    source = api.get("t_api_request_staging", SOURCE_STAGING_ID)
    request_body = copy.deepcopy(source.get("f_request_body"))
    if not isinstance(request_body, dict):
        print("error=source staging record has no JSON request body", file=sys.stderr)
        return 1

    now = dt.datetime.now().astimezone()
    suffix = now.strftime("%Y%m%d-%H%M%S")
    request_id = f"NLA-STAGING-REPAIR-{suffix}"
    request_body["request_id"] = request_id
    form_data = request_body["form_data"]
    form_data["case_summary"]["received_date"] = now.isoformat(timespec="seconds")
    form_data["part_1"]["application_received_date"] = now.isoformat(timespec="seconds")
    form_data["part_1"].pop("application_ref", None)
    form_data["part_1"].pop("d_no", None)
    form_data["part_2"]["rch_name_en"] = f"CODEX REPAIR UAT RCH {suffix}"
    form_data["part_2"]["rch_name_cn"] = f"CODEX 修復驗收院舍 {suffix}"
    form_data["part_5"]["comments"] = "Codex controlled post-repair workflow UAT"

    staging_values = {
        "f_request_body": request_body,
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_user_role": "root",
        "f_status": "received",
    }

    created: dict[str, Any] = {}
    final: dict[str, Any] = {}
    disable_error: Optional[Exception] = None
    try:
        api.set_workflow_enabled(True)
        print("workflow_enabled_for_test=true")
        value = api.request("POST", "/api/t_api_request_staging:create", staging_values)
        if not isinstance(value, dict) or value.get("id") is None:
            raise TestError("staging create response is missing an ID")
        created = value
        print(f"request_id={request_id}")
        print(f"staging_id={created['id']}")

        deadline = time.monotonic() + args.timeout_seconds
        observed: list[str] = []
        while time.monotonic() < deadline:
            final = api.get("t_api_request_staging", int(created["id"]))
            status = str(final.get("f_status") or "")
            if not observed or observed[-1] != status:
                observed.append(status)
                print(f"observed_status={status}")
            if status in FINAL_STATUSES:
                break
            time.sleep(1)
        else:
            raise TestError(
                f"workflow did not finish in {args.timeout_seconds} seconds"
            )
    except Exception as exc:  # report after the workflow has been restored to Off
        primary_error: Optional[Exception] = exc
    else:
        primary_error = None
    finally:
        try:
            api.set_workflow_enabled(False)
            print("workflow_restored_off=true")
        except Exception as exc:
            disable_error = exc

    if disable_error:
        print(f"error=failed to restore workflow Off: {disable_error}", file=sys.stderr)
        return 1
    if primary_error:
        print(f"error={primary_error}", file=sys.stderr)
        return 1

    failures: list[str] = []
    assert_equal(final.get("f_status"), "succeeded", "staging status", failures)
    intake_id = final.get("f_intake_id")
    application_id = final.get("f_application_id")
    if not intake_id:
        failures.append("staging Intake ID was not backfilled")
    if not application_id:
        failures.append("staging Application ID was not backfilled")

    print(f"final_status={final.get('f_status')}")
    print(f"intake_id={intake_id}")
    print(f"application_id={application_id}")

    if intake_id:
        intake = api.get("t_intake_form", int(intake_id))
        assert_equal(
            intake.get("fk_intake_type"), 364490020880384, "Intake type", failures
        )
        assert_equal(intake.get("f_office_cd"), "LORCHE", "Intake office", failures)
        assert_equal(
            intake.get("f_subject"),
            form_data["part_2"]["rch_name_en"],
            "Intake subject",
            failures,
        )
        assert_equal(
            intake.get("f_comments"),
            form_data["part_5"]["comments"],
            "Intake comments",
            failures,
        )
        print(f"intake_office={intake.get('f_office_cd')}")
        print(f"intake_subject={intake.get('f_subject')}")

    if application_id:
        application = api.get("t_licence_app", int(application_id))
        expected_nla = {
            "f_office_cd": "LORCHE",
            "f_p_no": None,
            "f_d_no": None,
            "f_rch_name_en": form_data["part_2"]["rch_name_en"],
            "f_rch_name_cn": form_data["part_2"]["rch_name_cn"],
            "fk_rch_nature": "CUM",
            "f_rch_premises": "1",
            "f_monthly_fee_per_resident_min": 8000,
            "f_monthly_fee_per_resident_max": 12000,
            "f_rch_gender": "1",
            "f_net_floor_area_sqm": 380.5,
            "f_licence_capacity": 48,
            "f_service_type": "0",
            "f_business_ownership_type": "0",
            "f_application_level": "normal",
            "f_comments": form_data["part_5"]["comments"],
        }
        for field, expected in expected_nla.items():
            if field in {
                "f_monthly_fee_per_resident_min",
                "f_monthly_fee_per_resident_max",
                "f_net_floor_area_sqm",
                "f_licence_capacity",
            }:
                assert_decimal_equal(
                    application.get(field), expected, f"NLA {field}", failures
                )
            else:
                assert_equal(application.get(field), expected, f"NLA {field}", failures)
        print(f"nla_office={application.get('f_office_cd')}")
        print(f"nla_name_en={application.get('f_rch_name_en')}")
        print(f"nla_licence_capacity={application.get('f_licence_capacity')}")

    print(f"assertion_failure_count={len(failures)}")
    for failure in failures:
        print(f"assertion_failure={failure}")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
