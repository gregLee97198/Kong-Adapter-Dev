#!/usr/bin/env python3
"""Inspect and validate the deployable environment configuration profiles."""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import yaml

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / "config" / "environments.yaml"


class ProfileError(RuntimeError):
    pass


def _load_yaml(path: Path) -> dict[str, Any]:
    try:
        document = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except FileNotFoundError as exc:
        raise ProfileError(f"configuration file does not exist: {path}") from exc
    except yaml.YAMLError as exc:
        raise ProfileError(f"invalid YAML: {path}: {exc}") from exc
    if not isinstance(document, dict):
        raise ProfileError(f"YAML root must be an object: {path}")
    return document


def _manifest() -> dict[str, Any]:
    document = _load_yaml(MANIFEST_PATH)
    environments = document.get("environments")
    if not isinstance(environments, dict) or not environments:
        raise ProfileError("config/environments.yaml has no environments")
    return document


def _env_value(path: Path, key: str) -> str | None:
    if not path.is_file():
        return None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        current_key, value = line.split("=", 1)
        if current_key.strip() == key:
            result = value.strip()
            if len(result) >= 2 and result[0] == result[-1] and result[0] in {'"', "'"}:
                result = result[1:-1]
            return result
    return None


def _profile(name: str) -> dict[str, Any]:
    environments = _manifest()["environments"]
    value = environments.get(name)
    if not isinstance(value, dict):
        choices = ", ".join(sorted(environments))
        raise ProfileError(f"unknown environment {name!r}; choose: {choices}")
    profile = dict(value)
    upstream_env_file = profile.get("upstream_env_file")
    if upstream_env_file is not None:
        example_path = _repo_path(upstream_env_file, "upstream_env_file")
        env_override = os.getenv("UAT_ENV_FILE", "").strip()
        env_path = (
            Path(env_override) if env_override else ROOT / ".env"
        )
        if env_override and not env_path.is_absolute():
            env_path = ROOT / env_path
        raw_url = _env_value(env_path, "UAT_NOCOBASE_BASE_URL")
        if raw_url is None:
            raw_url = _env_value(example_path, "UAT_NOCOBASE_BASE_URL")
        if not raw_url:
            raise ProfileError(f"{name}: UAT_NOCOBASE_BASE_URL is missing")
        parsed = urlsplit(raw_url.strip())
        if (
            parsed.scheme not in {"http", "https"}
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
            or parsed.path.rstrip("/") != "/cmtf2"
        ):
            raise ProfileError(
                f"{name}: upstream URL must be an internal HTTP(S) /cmtf2 URL"
            )
        host = parsed.hostname or ""
        if not host or host in {"localhost", "127.0.0.1", "::1"}:
            raise ProfileError(
                f"{name}: upstream host must be reachable from Docker containers"
            )
        try:
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
        except ValueError as exc:
            raise ProfileError(f"{name}: invalid upstream port") from exc
        upstream = dict(_mapping(profile.get("upstream"), "upstream"))
        upstream.update(
            base_url=raw_url.strip().rstrip("/"),
            protocol=parsed.scheme,
            host=host,
            port=port,
            api_base_path="/cmtf2/api",
            auth_sign_in_path="/cmtf2/api/auth:signIn",
        )
        if profile.get("runtime") == "kubernetes":
            match = re.fullmatch(
                r"([a-z0-9-]+)\.([a-z0-9-]+)\.svc\.cluster\.local", host
            )
            if match is None:
                raise ProfileError(
                    f"{name}: upstream host must be a Kubernetes Service FQDN"
                )
            upstream.update(namespace=match.group(2), service=match.group(1))
        profile["upstream"] = upstream
    return profile


def _repo_path(value: Any, field: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ProfileError(f"{field} must be a repository-relative path")
    candidate = (ROOT / value).resolve()
    try:
        candidate.relative_to(ROOT)
    except ValueError as exc:
        raise ProfileError(f"{field} escapes the repository: {value}") from exc
    return candidate


def _mapping(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProfileError(f"{field} must be an object")
    return value


def _load_compose_env(path: Path) -> dict[str, str]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError as exc:
        raise ProfileError(f"Compose environment file does not exist: {path}") from exc
    values: dict[str, str] = {}
    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise ProfileError(
                f"invalid Compose environment line {path}:{line_number}"
            )
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise ProfileError(
                f"empty Compose environment key {path}:{line_number}"
            )
        values[key] = value.strip()
    return values


def _service_map(kong: dict[str, Any]) -> dict[str, dict[str, Any]]:
    services = kong.get("services")
    if not isinstance(services, list):
        raise ProfileError("Kong configuration must contain a services list")
    result: dict[str, dict[str, Any]] = {}
    for service in services:
        if not isinstance(service, dict) or not isinstance(service.get("name"), str):
            raise ProfileError("every Kong service must have a name")
        name = service["name"]
        if name in result:
            raise ProfileError(f"duplicate Kong service name: {name}")
        result[name] = service
    return result


def _validate_no_secrets(*paths: Path) -> None:
    patterns = {
        "JWT-like token": re.compile(
            r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"
        ),
        "Bearer credential": re.compile(
            r"Bearer\s+[A-Za-z0-9_-]{20,}", re.IGNORECASE
        ),
        "private key": re.compile(r"BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY"),
    }
    for path in paths:
        text = path.read_text(encoding="utf-8")
        for label, pattern in patterns.items():
            if pattern.search(text):
                raise ProfileError(f"{label} found in non-secret file: {path}")


def validate_environment(name: str) -> dict[str, Any]:
    profile = _profile(name)
    if profile.get("deployable", True) is not True:
        reason = profile.get("blocked_reason") or "profile is disabled"
        raise ProfileError(f"{name}: environment is not deployable: {reason}")
    kong_path = _repo_path(profile.get("kong_config"), "kong_config")
    nocobase_path = _repo_path(profile.get("nocobase_config"), "nocobase_config")
    compose_env_path: Path | None = None
    compose_values: dict[str, str] = {}
    if profile.get("runtime") == "docker-compose":
        compose_env_path = _repo_path(
            profile.get("compose_env_file"), "compose_env_file"
        )
        # The release builder validates against the secret-free template. The
        # downloaded release validates its editable .env without an override.
        if name == "uat" and os.getenv("UAT_ENV_FILE", "").strip():
            compose_env_path = _repo_path(
                os.environ["UAT_ENV_FILE"], "UAT_ENV_FILE"
            )
        compose_values = _load_compose_env(compose_env_path)
    kong = _load_yaml(kong_path)
    nocobase_document = _load_yaml(nocobase_path)
    nocobase = _mapping(nocobase_document.get("nocobase"), "nocobase")
    upstream = _mapping(profile.get("upstream"), "upstream")

    expected_base_url = str(upstream.get("base_url", "")).rstrip("/")
    actual_base_url = str(nocobase.get("base_url", "")).rstrip("/")
    if actual_base_url != expected_base_url:
        raise ProfileError(
            f"{name}: adapter base_url is {actual_base_url!r}; "
            f"expected {expected_base_url!r}"
        )

    services = _service_map(kong)
    expected_protocol = upstream.get("protocol")
    expected_host = upstream.get("host")
    expected_port = upstream.get("port")
    service_names = profile.get("kong_nocobase_services")
    if not isinstance(service_names, list):
        raise ProfileError(f"{name}: kong_nocobase_services must be a list")
    for service_name in service_names:
        service = services.get(str(service_name))
        if service is None:
            raise ProfileError(f"{name}: missing Kong service {service_name}")
        actual = (
            service.get("protocol"),
            service.get("host"),
            service.get("port"),
        )
        expected = (expected_protocol, expected_host, expected_port)
        if actual != expected:
            raise ProfileError(
                f"{name}: service {service_name} upstream is {actual}; "
                f"expected {expected}"
            )

    adapter_expected = _mapping(profile.get("adapter_service"), "adapter_service")
    adapter_name = str(adapter_expected.get("name", ""))
    adapter = services.get(adapter_name)
    if adapter is None:
        raise ProfileError(f"{name}: missing adapter service {adapter_name}")
    actual_adapter = (adapter.get("host"), adapter.get("port"))
    expected_adapter = (
        adapter_expected.get("host"),
        adapter_expected.get("port"),
    )
    if actual_adapter != expected_adapter:
        raise ProfileError(
            f"{name}: adapter service target is {actual_adapter}; "
            f"expected {expected_adapter}"
        )

    for service in services.values():
        if service.get("name") in service_names:
            continue
        if (service.get("host"), service.get("port")) != expected_adapter:
            raise ProfileError(
                f"{name}: service {service.get('name')} must target the Adapter"
            )

    auth_service = services.get("nocobase-adapter-auth-service")
    if auth_service is None or not any(
        "POST" in route.get("methods", [])
        and "~/v1/auth/token$" in route.get("paths", [])
        for route in auth_service.get("routes", [])
    ):
        raise ProfileError(f"{name}: auth route must target the Adapter")

    auth_path = str(upstream.get("auth_sign_in_path", ""))
    configured_auth_path = str(
        _mapping(nocobase.get("api"), "nocobase.api").get("auth_sign_in", "")
    )
    adapter_auth_path = (
        urlsplit(actual_base_url).path.rstrip("/") + configured_auth_path
    )
    if auth_path != adapter_auth_path:
        raise ProfileError(
            f"{name}: Adapter auth path {adapter_auth_path} does not match "
            f"expected {auth_path}"
        )

    kong_text = kong_path.read_text(encoding="utf-8")
    nocobase_text = nocobase_path.read_text(encoding="utf-8")
    combined = f"{kong_text}\n{nocobase_text}"
    for forbidden in profile.get("forbidden_upstream_hosts", []):
        if str(forbidden) in combined:
            raise ProfileError(f"{name}: forbidden upstream host found: {forbidden}")
    for forbidden in profile.get("forbidden_upstream_paths", []):
        if str(forbidden) in combined:
            raise ProfileError(f"{name}: forbidden upstream path found: {forbidden}")

    _validate_no_secrets(MANIFEST_PATH, kong_path, nocobase_path)
    compose_expectations = profile.get("compose_expectations")
    if compose_expectations is not None:
        expected = _mapping(compose_expectations, "compose_expectations")
        checks = {
            "COMPOSE_PROJECT_NAME": str(expected.get("project_name", "")),
            "KONG_IMAGE": str(expected.get("kong_image", "")),
            "ADAPTER_IMAGE": str(expected.get("adapter_image", "")),
            "KONG_HTTPS_BIND": str(expected.get("https_bind", "")),
            "KONG_HTTPS_PORT": str(expected.get("https_port", "")),
        }
        for key, expected_value in checks.items():
            actual_value = compose_values.get(key)
            if actual_value != expected_value:
                raise ProfileError(
                    f"{name}: {key} is {actual_value!r}; expected {expected_value!r}"
                )
        compose_upstream = compose_values.get("NOCOBASE_UPSTREAM_URL")
        if compose_upstream != actual_base_url:
            raise ProfileError(
                f"{name}: NOCOBASE_UPSTREAM_URL is {compose_upstream!r}; "
                f"expected {actual_base_url!r}"
            )

    summary = {
        "environment": name,
        "label": profile.get("label", name),
        "stage": profile.get("stage", "unspecified"),
        "deployable": profile.get("deployable", True),
        "runtime": profile.get("runtime"),
        "kong_config": kong_path.relative_to(ROOT).as_posix(),
        "nocobase_config": nocobase_path.relative_to(ROOT).as_posix(),
        "upstream_mode": upstream.get("mode"),
        "upstream_base_url": actual_base_url,
        "auth_sign_in_path": auth_path,
        "adapter_target": f"{actual_adapter[0]}:{actual_adapter[1]}",
    }
    if compose_env_path is not None:
        summary["compose_env_file"] = compose_env_path.relative_to(ROOT).as_posix()
        if compose_values.get("KONG_IMAGE"):
            summary["kong_image"] = compose_values["KONG_IMAGE"]
        if compose_values.get("ADAPTER_IMAGE"):
            summary["adapter_image"] = compose_values["ADAPTER_IMAGE"]
        if compose_values.get("KONG_HTTPS_BIND") and compose_values.get(
            "KONG_HTTPS_PORT"
        ):
            summary["https_listener"] = (
                f"{compose_values['KONG_HTTPS_BIND']}:"
                f"{compose_values['KONG_HTTPS_PORT']}"
            )
    return summary


def _get_value(name: str, dotted_field: str) -> Any:
    value: Any = _profile(name)
    for part in dotted_field.split("."):
        if not isinstance(value, dict) or part not in value:
            raise ProfileError(
                f"{name}: environment field does not exist: {dotted_field}"
            )
        value = value[part]
    if isinstance(value, (dict, list)):
        raise ProfileError(f"{dotted_field} is not a scalar value")
    return value


def _print_summary(summary: dict[str, Any]) -> None:
    for key, value in summary.items():
        print(f"{key}={value}")


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    for command in ("show", "validate"):
        child = subparsers.add_parser(command)
        child.add_argument("environment")

    value_parser = subparsers.add_parser("value")
    value_parser.add_argument("environment")
    value_parser.add_argument("field")

    args = parser.parse_args()
    try:
        if args.command in {"show", "validate"}:
            summary = validate_environment(args.environment)
            _print_summary(summary)
            if args.command == "validate":
                print("validation=passed")
        else:
            print(_get_value(args.environment, args.field))
    except ProfileError as exc:
        print(f"validation=failed\nerror={exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
