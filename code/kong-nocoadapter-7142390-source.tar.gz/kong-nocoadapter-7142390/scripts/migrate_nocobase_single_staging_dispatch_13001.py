#!/usr/bin/env python3
"""Offline blueprint for the 13001 API Staging dispatcher consolidation.

This script is intentionally **local-only**.  It does not import a NocoBase
client, does not read ``NOCOBASE_TOKEN``, and has no HTTP or Docker code.  It
turns the approved source catalogue into an auditable plan for a later,
separately-reviewed writer:

* one collection-event ingress on ``t_api_request_staging``;
* twelve exact marker workers, one per public business;
* a CREATE/UPDATE condition inside every marker worker; and
* a two-phase clone model which creates every node first, then rewrites all
  ``$jobsMapByNodeKey`` / ``$scopes`` references before wiring edges.

The writer must preserve these gates:

1. export all legacy workflow versions locally;
2. create and validate all new workflows disabled;
3. disable legacy triggers, enable marker workers, then enable ingress; and
4. delete legacy versions only after an explicit, separate acceptance gate.

No mutation is performed by this file.  ``--dry-run`` is therefore also safe
without an administrator token and is useful in code review/CI.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping


BASE_URL = "http://119.91.104.211:13001/cmtf2"
COLLECTION = "t_api_request_staging"
SOURCE_SYSTEM = "OP"
STATUS = "submitted"
ROUTE_FIELD = "f_dispatch_route"
API_SOURCE_CATEGORY_TITLE = "API Suorce"  # Existing category spelling.
REPO_ROOT = Path(__file__).resolve().parents[1]
BACKUP_ROOT = REPO_ROOT.parent / "kong-nocoadapter-artifacts" / "workflow-backups"

PREPARE_CONFIRM = "PREPARE_DISABLED_UNIFIED_API_STAGING_13001"
CUTOVER_CONFIRM = "CUTOVER_UNIFIED_API_STAGING_13001"
RETIRE_CONFIRM = "RETIRE_LEGACY_API_STAGING_13001"

_REF_RE = re.compile(r"\{\{\$(jobsMapByNodeKey|scopes)\.([A-Za-z0-9_-]+)")


class PlanError(ValueError):
    """The approved source graph is not safe to clone mechanically."""


@dataclass(frozen=True)
class Business:
    """The only public 13001 business tuple catalogue for this cutover."""

    name: str
    title: str
    application_type: str
    create_api_type: str
    update_api_type: str
    create_source_id: int
    create_source_key: str
    update_snapshot_name: str
    update_source_id: int
    update_source_key: str
    legacy_parent_id: int | None = None
    legacy_parent_key: str | None = None

    @property
    def route(self) -> str:
        # One marker per business; event selection occurs inside its graph.
        return f"unified_{self.name}"

    @property
    def update_snapshot(self) -> Path:
        return BACKUP_ROOT / self.update_snapshot_name


# Exact sources supplied by the 13001 graph audit.  Do not derive paths from
# request URLs: any renamed API requires an explicit catalogue review.
BUSINESSES: tuple[Business, ...] = (
    Business("new_licence", "New Licence Application", "new_licence",
             "create_intake_for_new_licence", "update_new_licence_data",
             392440992825344, "r7lno6pwm8k",
             "13001-nla-update-392438256041984-before-queue-gates-20261016.json",
             392438256041984, "w9mu1bnq8k7", 392438115532800, "7dms7pwosyw"),
    Business("changing_home", "Changing Home Information", "changing_home",
             "create_intake_for_changing_home", "update_changing_home_data",
             392534731390976, "4hkmccur7cy",
             "13001-changing-home-update-fifo-392534972563456-preimage.json",
             392534972563456, "p4o1zy78fjz"),
    Business("licence_renewal", "Licence Renewal", "licence_renewal",
             "create_licence_renewal", "update_licence_renewal_data",
             392233305571328, "6oea217lqvi",
             "13001-lrn-queue-worker-392467282722816-preimage.json",
             392467282722816, "ig5t8vyt336"),
    Business("expansion_aip", "Expansion AIP", "expansion_aip",
             "create_intake_for_expansion_aip", "update_expansion_aip_data",
             392238082883584, "9zw8wopo5zg",
             "13001-expansion_aip-update-fifo-392539179450368-preimage.json",
             392539179450368, "ovs6xo6bp6j"),
    Business("specific_hour", "Specific Hour", "specific_hour",
             "create_intake_for_specific_hour", "update_specific_hour_data",
             392243799719936, "j47w4mphtx8",
             "13001-specific_hour-update-fifo-392497360076800-preimage.json",
             392497360076800, "no5sgqavq34"),
    Business("responsible_person", "Responsible Person", "responsible_person",
             "create_intake_for_rp", "update_rp_data",
             392244160430080, "ghfvy2w2idk",
             "13001-responsible_person-update-fifo-392489135046656-preimage.json",
             392489135046656, "lwgijxcls00"),
    Business("self_withdraw", "Closure (Self-withdraw)", "self_withdraw",
             "create_intake_for_self_withdraw", "update_self_withdraw_data",
             392229543280640, "swbq3akxmhu",
             "13001-self_withdraw-update-fifo-392537006800897-preimage.json",
             392537006800897, "51ypnjgwdth"),
    Business("change_home_manager", "Change Home Manager", "change_home_manager",
             "create_intake_for_change_home_manager", "update_change_home_manager_data",
             392455628849152, "kempmczlabu",
             "13001-home_manager-update-worker-392501258682368-preimage.json",
             392501258682368, "h5yynm9td1s"),
    Business("change_beds", "Change Beds / Layout", "change_beds",
             "create_intake_for_change_beds", "update_change_beds_data",
             392455784038400, "6bksnfkg387",
             "13001-beds_layout-update-worker-392506430259203-preimage.json",
             392506430259203, "whzpt4zx7e5"),
    Business("change_operation_mode", "Change Operation Mode", "change_operation_mode",
             "create_intake_for_change_operation_mode", "update_change_operation_mode_data",
             392367489744896, "kt3o9h2vep0",
             "13001-operation_mode-update-worker-392508347056128-preimage.json",
             392508347056128, "a94acwmvst5"),
    Business("change_directors", "Change Directors", "change_directors",
             "create_intake_for_change_directors", "update_change_directors_data",
             392479720931328, "kcjz7jqffcn",
             "13001-directors-update-worker-392511457132544-preimage.json",
             392511457132544, "9seavn6ir3m"),
    Business("change_nurse_in_charge", "Change Nurse-in-Charge", "change_nurse_in_charge",
             "create_intake_for_change_nurse_in_charge", "update_change_nurse_in_charge_data",
             392479565742080, "bz8wn0djee9",
             "13001-nurse_in_charge-update-worker-392504505073664-preimage.json",
             392504505073664, "b9xfkbsaxbz"),
)


def _eq(field: str, value: Any) -> dict[str, Any]:
    return {field: {"$eq": value}}


def _ref(key: str, field: str) -> str:
    return "{{$jobsMapByNodeKey." + key + "." + field + "}}"


def tuple_condition(business: Business, event: str) -> dict[str, Any]:
    api_type = business.create_api_type if event == "CREATE" else business.update_api_type
    return {
        "$and": [
            _eq("f_source_system", SOURCE_SYSTEM),
            _eq("f_request_event", event),
            _eq("f_api_type", api_type),
            _eq("f_application_type", business.application_type),
        ]
    }


def ingress_config() -> dict[str, Any]:
    """Only initial external submitted writes wake the single ingress."""
    return {
        "mode": 3,
        "collection": COLLECTION,
        "appends": [],
        "changed": ["f_status"],
        "condition": {
            "$and": [
                _eq("f_source_system", SOURCE_SYSTEM),
                _eq("f_status", STATUS),
                {ROUTE_FIELD: {"$empty": True}},
                {"$or": [
                    tuple_condition(business, event)
                    for business in BUSINESSES for event in ("CREATE", "UPDATE")
                ]},
            ]
        },
    }


def worker_config(business: Business) -> dict[str, Any]:
    """Exact marker trigger; it never listens to broad ``submitted`` writes."""
    return {
        "mode": 2,
        "collection": COLLECTION,
        "appends": [],
        "changed": [ROUTE_FIELD],
        "condition": {
            "$and": [
                _eq("f_source_system", SOURCE_SYSTEM),
                _eq("f_status", STATUS),
                _eq(ROUTE_FIELD, business.route),
                {"$or": [
                    tuple_condition(business, "CREATE"),
                    tuple_condition(business, "UPDATE"),
                ]},
            ]
        },
    }


def ingress_nodes() -> list[dict[str, Any]]:
    """Mutually exclusive tuple chain, then one harmless ORM marker write."""
    nodes: list[dict[str, Any]] = []
    previous: str | None = None
    for index, business in enumerate(BUSINESSES):
        key = f"ingress_match_{business.name}"
        nodes.append({
            "key": key,
            "type": "condition",
            "title": f"Match {business.title} CREATE or UPDATE",
            "upstream": previous,
            "branch": None if index == 0 else 0,
            "config": {
                "rejectOnFalse": False,
                "engine": "basic",
                "calculation": {"group": {"type": "and", "calculations": [
                    {"calculator": "equal", "operands": [
                        "{{$context.data.f_application_type}}", business.application_type]},
                    {"group": {"type": "or", "calculations": [
                        {"group": {"type": "and", "calculations": [
                            {"calculator": "equal", "operands": [
                                "{{$context.data.f_request_event}}", "CREATE"]},
                            {"calculator": "equal", "operands": [
                                "{{$context.data.f_api_type}}", business.create_api_type]},
                        ]}},
                        {"group": {"type": "and", "calculations": [
                            {"calculator": "equal", "operands": [
                                "{{$context.data.f_request_event}}", "UPDATE"]},
                            {"calculator": "equal", "operands": [
                                "{{$context.data.f_api_type}}", business.update_api_type]},
                        ]}},
                    ]}},
                ]}},
            },
        })
        nodes.append({
            "key": f"ingress_mark_{business.name}",
            "type": "update",
            "title": f"Mark {business.title} unified worker",
            "upstream": key,
            "branch": 1,
            "config": {
                "collection": COLLECTION,
                "params": {
                    "individualHooks": True,
                    "filter": {"$and": [
                        {"id": {"$eq": "{{$context.data.id}}"}},
                        _eq("f_source_system", SOURCE_SYSTEM),
                        _eq("f_status", STATUS),
                        {ROUTE_FIELD: {"$empty": True}},
                        {"$or": [tuple_condition(business, "CREATE"),
                                 tuple_condition(business, "UPDATE")]},
                    ]},
                    "values": {ROUTE_FIELD: business.route},
                    "appends": [],
                },
            },
        })
        previous = key
    return nodes


def event_branch_node(business: Business) -> dict[str, Any]:
    """Worker root: branch 1=CREATE, branch 0=UPDATE."""
    return {
        "key": f"worker_{business.name}_event",
        "type": "condition",
        "title": f"{business.title}: CREATE or UPDATE",
        "upstream": None,
        "branch": None,
        "config": {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {"group": {"type": "and", "calculations": [
                {"calculator": "equal", "operands": [
                    "{{$context.data.f_request_event}}", "CREATE"]},
            ]}},
        },
    }


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _walk_strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, Mapping):
        for child in value.values():
            yield from _walk_strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_strings(child)


def _replace_refs(value: Any, keymap: Mapping[str, str]) -> Any:
    """Rewrite only NocoBase node-key references; reject unknown references."""
    if isinstance(value, str):
        def substitute(match: re.Match[str]) -> str:
            scope, old_key = match.groups()
            if old_key not in keymap:
                raise PlanError(f"graph contains external/unknown node key {old_key!r}")
            return "{{$" + scope + "." + keymap[old_key]
        return _REF_RE.sub(substitute, value)
    if isinstance(value, list):
        return [_replace_refs(child, keymap) for child in value]
    if isinstance(value, Mapping):
        return {str(key): _replace_refs(child, keymap) for key, child in value.items()}
    return value


def _node_index(graph: Mapping[str, Any]) -> dict[int, dict[str, Any]]:
    nodes = graph.get("nodes")
    if not isinstance(nodes, list) or not nodes:
        raise PlanError("source graph has no nodes")
    indexed: dict[int, dict[str, Any]] = {}
    keys: set[str] = set()
    for raw in nodes:
        if not isinstance(raw, Mapping):
            raise PlanError("source graph contains a non-object node")
        node = copy.deepcopy(dict(raw))
        node_id = node.get("id")
        key = node.get("key")
        if not isinstance(node_id, int) or not isinstance(key, str) or not key:
            raise PlanError("source node has no stable id/key")
        if node_id in indexed or key in keys:
            raise PlanError("source node IDs/keys are not unique")
        indexed[node_id] = node
        keys.add(key)
    for node in indexed.values():
        for relation in ("upstreamId", "downstreamId"):
            value = node.get(relation)
            if value not in (None, "") and value not in indexed:
                raise PlanError(f"source {relation} points outside graph: {value!r}")
        for text in _walk_strings(node.get("config", {})):
            for _scope, key in _REF_RE.findall(text):
                if key not in keys:
                    raise PlanError(f"source config refers to unknown key {key!r}")
    roots = [node for node in indexed.values() if node.get("upstreamId") in (None, "")]
    if len(roots) != 1:
        raise PlanError(f"source graph must have exactly one root; found {len(roots)}")
    return indexed


def _load_update_snapshot(business: Business) -> dict[str, Any]:
    path = business.update_snapshot
    if not path.is_file():
        raise PlanError(f"missing approved Update snapshot: {path}")
    try:
        graph = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PlanError(f"cannot load Update snapshot {path}: {exc}") from exc
    if not isinstance(graph, dict):
        raise PlanError(f"Update snapshot is not an object: {path}")
    if graph.get("id") != business.update_source_id or graph.get("key") != business.update_source_key:
        raise PlanError(f"Update snapshot identity drifted: {path}")
    return graph


def _remove_chi_queue_wait(graph: dict[str, Any]) -> dict[str, Any]:
    """Bypass only the known bounded *Update queue* wait/poll segment.

    Native CHI clone/snapshot readiness waits are deliberately retained.  This
    narrowly reconnects the validated-parent true branch to ``Resolve linked
    CHI`` and rejects any topology drift rather than guessing.
    """
    indexed = _node_index(graph)
    expected = {
        "parent": "fnytuhwywxd",
        "first": "35q5k9aydlm",
        "plan": "lrrha93z4hd",
        "wait": "763byp0q9u0",
        "poll": "ahzcocnq9xq",
        "delay": "5f19yp6llm0",
        "final": "i383l7964vz",
        "gate": "0hq2pgvomkb",
        "timeout": "5q47q4nrasm",
        "resolve": "4fdkje6cqhx",
    }
    by_key = {str(node["key"]): node for node in indexed.values()}
    if set(expected.values()) - set(by_key):
        raise PlanError("CHI queue bypass anchors changed; refusing to guess")
    parent, first, plan, wait, poll, delay, final, gate, timeout, resolve = (
        by_key[expected[name]] for name in
        ("parent", "first", "plan", "wait", "poll", "delay", "final", "gate", "timeout", "resolve")
    )
    if not (first.get("upstreamId") == parent["id"] and first.get("branchIndex") == 1):
        raise PlanError("CHI queue entry is no longer parent-valid true branch")
    if not (plan.get("upstreamId") == first["id"] and wait.get("upstreamId") == plan["id"]):
        raise PlanError("CHI queue plan/wait anchors changed")
    if not (final.get("upstreamId") == wait["id"] and gate.get("upstreamId") == final["id"]):
        raise PlanError("CHI queue final gate anchors changed")
    if not (resolve.get("upstreamId") == gate["id"] and resolve.get("branchIndex") == 1):
        raise PlanError("CHI Resolve linked anchor changed")
    if timeout.get("upstreamId") != gate["id"] or timeout.get("branchIndex") != 0:
        raise PlanError("CHI queue timeout anchor changed")
    remove_ids = {first["id"], plan["id"], wait["id"], poll["id"], delay["id"], final["id"], gate["id"], timeout["id"]}
    for node in indexed.values():
        if node["id"] in remove_ids:
            continue
        if node.get("upstreamId") in remove_ids:
            if node["id"] != resolve["id"]:
                raise PlanError("CHI queue has an unexpected surviving descendant")
        if node.get("downstreamId") in remove_ids and node["id"] != parent["id"]:
            raise PlanError("CHI queue has an unexpected surviving predecessor")
        for text in _walk_strings(node.get("config", {})):
            if any(key in text for key in (first["key"], plan["key"], wait["key"], poll["key"], delay["key"], final["key"], gate["key"], timeout["key"])):
                raise PlanError("CHI queue key is still referenced by a surviving node")
    result = copy.deepcopy(graph)
    for node in result["nodes"]:
        if node["id"] == resolve["id"]:
            node["upstreamId"] = parent["id"]
            node["branchIndex"] = 1
        if node["id"] == parent["id"]:
            # Branch edges use child.upstreamId; condition downstream remains null.
            node["downstreamId"] = None
    result["nodes"] = [node for node in result["nodes"] if node["id"] not in remove_ids]
    _node_index(result)
    return result


def _patch_aip_scope(graph: dict[str, Any]) -> dict[str, Any]:
    """Repair one audit-confirmed stale scope key before generic remapping."""
    old = "{{$scopes.388386449063940.item.id}}"
    new = "{{$scopes.x1aqgc2pa2x.item.id}}"
    serialized = _canonical(graph)
    if serialized.count(old) != 1 or "x1aqgc2pa2x" not in serialized:
        raise PlanError("AIP stale scope patch anchor changed; refusing to guess")
    patched = json.loads(serialized.replace(old, new, 1))
    _node_index(patched)
    return patched


def prepared_update_graph(business: Business) -> dict[str, Any]:
    graph = _load_update_snapshot(business)
    if business.name == "changing_home":
        graph = _remove_chi_queue_wait(graph)
    if business.name == "expansion_aip":
        graph = _patch_aip_scope(graph)
    _node_index(graph)
    return graph


def clone_instructions(graph: Mapping[str, Any], prefix: str) -> dict[str, Any]:
    """Return a deterministic two-pass clone recipe, without creating nodes."""
    indexed = _node_index(graph)
    root = next(node for node in indexed.values() if node.get("upstreamId") in (None, ""))
    ordered = sorted(indexed.values(), key=lambda node: str(node["key"]))
    # A live writer replaces ``<allocated:old-key>`` only after all node POSTs
    # have returned their new NocoBase keys.  This prevents broken forward refs.
    placeholders = {str(node["key"]): f"<allocated:{node['key']}>" for node in ordered}
    rewritten = {
        str(node["key"]): _replace_refs(node.get("config", {}), placeholders)
        for node in ordered
    }
    return {
        "source_graph_sha256": digest(graph),
        "root_source_key": root["key"],
        "node_count": len(ordered),
        "pass_1_create": [{
            "source_key": node["key"],
            "target_title": f"{prefix}/{node['key']} — {node.get('title') or node['type']}",
            "type": node["type"],
        } for node in ordered],
        "pass_2_rewrite_config": rewritten,
        "pass_3_edges": [{
            "source_key": node["key"],
            "upstream_source_key": (indexed[node["upstreamId"]]["key"]
                                     if node.get("upstreamId") not in (None, "") else None),
            "downstream_source_key": (indexed[node["downstreamId"]]["key"]
                                       if node.get("downstreamId") not in (None, "") else None),
            "branch_index": node.get("branchIndex"),
        } for node in ordered],
    }


def static_plan() -> dict[str, Any]:
    """Validate sources and produce the complete no-write migration recipe."""
    names = [business.name for business in BUSINESSES]
    for attr in ("name", "application_type", "create_api_type", "update_api_type", "route",
                 "create_source_id", "create_source_key", "update_source_id", "update_source_key"):
        values = [getattr(business, attr) for business in BUSINESSES]
        if len(values) != len(set(values)):
            raise PlanError(f"duplicate business catalogue attribute: {attr}")
    updates = {business.name: prepared_update_graph(business) for business in BUSINESSES}
    return {
        "format": "nocobase-unified-api-staging-plan/v1",
        "environment": "13001 development only",
        "writes_remote": False,
        "collection": COLLECTION,
        "source_system": SOURCE_SYSTEM,
        "category": API_SOURCE_CATEGORY_TITLE,
        "business_count": len(BUSINESSES),
        "ingress": {
            "title": "API Staging — unified ingress dispatcher [prepared]",
            "enabled": False,
            "config": ingress_config(),
            "nodes": ingress_nodes(),
        },
        "workers": [{
            **asdict(business),
            "route": business.route,
            "enabled": False,
            "title": f"API Staging — {business.title} unified CREATE/UPDATE worker [prepared]",
            "config": worker_config(business),
            "event_branch": event_branch_node(business),
            "create_source": {
                "live_workflow_id": business.create_source_id,
                "expected_key": business.create_source_key,
                "required_at_prepare": True,
            },
            "update_source": {
                "snapshot": str(business.update_snapshot),
                "source_workflow_id": business.update_source_id,
                "expected_key": business.update_source_key,
                "clone": clone_instructions(updates[business.name], "UPDATE"),
            },
            "create_clone_gate": "At prepare, GET live source, validate one root and use clone_instructions.",
        } for business in BUSINESSES],
        "cutover_gates": {
            "prepare": [
                "Export every legacy same-key version locally before any mutation.",
                "Create ingress and all 12 workers disabled, then validate node/key/reference/edge shapes.",
                "Never enable a candidate during prepare.",
            ],
            "cutover": [
                "Verify each candidate remains disabled and has zero executions.",
                "Disable legacy source triggers first (including NLA legacy parent).",
                "Enable 12 marker workers, then enable ingress last.",
                "Abort if any unrelated enabled t_api_request_staging workflow overlaps the 24 exact tuples.",
            ],
            "retire": [
                "After acceptance only, export a second local backup and delete exact disabled legacy workflow IDs.",
                "Do not delete native Intake/NLA, status bridge, Send Letter, Notice, or Completed-to-Received workflows.",
            ],
        },
        "confirmation_literals": {
            "prepare": PREPARE_CONFIRM,
            "cutover": CUTOVER_CONFIRM,
            "retire": RETIRE_CONFIRM,
        },
        "unsupported_by_design": [
            "No collection subflow: isolated direct-subflow probe did not execute reliably.",
            "No timer/FIFO dispatcher: the requested queue remains closed.",
            "No remote create/update/delete in this offline blueprint.",
        ],
        "source_names": names,
    }


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="Print the complete no-write plan (default).")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output.")
    parser.add_argument("--write-plan", type=Path, help="Write the no-secret plan JSON locally.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    # No flag can make this file perform a remote operation.  The literals are
    # exported solely for the separate reviewed writer/cutover command.
    try:
        plan = static_plan()
        if args.write_plan:
            path = args.write_plan.expanduser().resolve()
            if path.exists():
                raise PlanError(f"refusing to overwrite existing plan: {path}")
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            path.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            path.chmod(0o600)
            plan["local_plan_path"] = str(path)
        print(json.dumps(plan, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except PlanError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
