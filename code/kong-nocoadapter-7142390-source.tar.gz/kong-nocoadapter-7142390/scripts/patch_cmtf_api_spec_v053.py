#!/usr/bin/env python3
"""Patch CMTF-II API Specification v0.52 OOXML in place to produce v0.53.

Keeps original styles, headers, and Daniel comment ranges. Does not rebuild
the document with python-docx.
"""

from __future__ import annotations

import copy
import json
import random
import shutil
import zipfile
from pathlib import Path

from lxml import etree

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
W14 = "{http://schemas.microsoft.com/office/word/2010/wordml}"
XML = "{http://www.w3.org/XML/1998/namespace}"
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

SRC = Path(
    "/Users/work/NCSI-CM-Documents/SI&I/Interfaces/API Specification/"
    "CMTF-II API Specification v0.52.docx"
)
DST = Path(
    "/Users/work/NCSI-CM-Documents/SI&I/Interfaces/API Specification/"
    "CMTF-II API Specification v0.53.docx"
)
REPO_COPY = Path(
    "/Users/work/noco/kong-nocoadapter/deliverables/"
    "CMTF-II API Specification v0.53.docx"
)

CHI_CREATE_EXAMPLE = {
    "request_id": "CHI-CREATE-20260914-0001",
    "create_id": "384700000000001",
    "form_data": {
        "case_summary": {
            "office_code": "LORCHE",
            "rch_no": "L0043",
            "submitter_user_id": 12,
            "task_owner_user_id": 45,
            "task_owner_post_code": "S(LR)1",
            "source_other": "OP",
        },
        "is_change_name": True,
        "part_5": {"comments": "CHI create"},
    },
}

CHI_UPDATE_EXAMPLE = {
    "request_id": "CHI-UPDATE-20260914-0001",
    "create_id": "384777930997760",
    "form_data": {"part_5": {"comments": "Updated through API"}},
}

CHI_CREATE_FIELDS = [
    (
        "create_id",
        "body.create_id",
        "string/integer",
        "Conditional",
        "Existing Create response ID used first to resolve the Home Record. If it does not resolve, rch_no is tried, then p_no.",
    ),
    (
        "request_id",
        "body.request_id",
        "string 1–128",
        "Yes",
        "Client-generated operation reference; returned unchanged",
    ),
    (
        "form_data",
        "body.form_data",
        "object",
        "Yes",
        "Changing Home payload. Home Record is resolved from case_summary; only supplied overlay sections replace snapshot values.",
    ),
    (
        "form_data.case_summary",
        "body.form_data.case_summary",
        "object",
        "Yes",
        "Home Record lookup priority is create_id, then rch_no, then p_no. At least one must resolve.",
    ),
    (
        "form_data.case_summary.office_code",
        "body.form_data.case_summary.office_code",
        "enum string",
        "Yes",
        "LORCHE or LORCHD; must match the Checklist office_code",
    ),
    (
        "form_data.case_summary.rch_no",
        "body.form_data.case_summary.rch_no",
        "string",
        "Conditional",
        "RCH number. Tried when create_id does not resolve a Home Record",
    ),
    (
        "form_data.case_summary.p_no",
        "body.form_data.case_summary.p_no",
        "string",
        "Conditional",
        "Final P Number. Tried only after create_id and rch_no do not resolve a Home Record",
    ),
    (
        "form_data.case_summary.submitter_user_id",
        "body.form_data.case_summary.submitter_user_id",
        "integer",
        "Yes",
        "Business submitter. Native Intake Submit runs as this user, not the interface account",
    ),
    (
        "form_data.is_change_name",
        "body.form_data.is_change_name",
        "boolean",
        "Conditional",
        "Change RCH name. At least one of the five change flags must be true",
    ),
    (
        "form_data.is_change_address",
        "body.form_data.is_change_address",
        "boolean",
        "Conditional",
        "Change address",
    ),
    (
        "form_data.is_change_operator_or_operating_company",
        "body.form_data.is_change_operator_or_operating_company",
        "boolean",
        "Conditional",
        "Change operator or operating company",
    ),
    (
        "form_data.is_change_rch_type",
        "body.form_data.is_change_rch_type",
        "boolean",
        "Conditional",
        "Change RCH type",
    ),
    (
        "form_data.is_change_maximum_capacity",
        "body.form_data.is_change_maximum_capacity",
        "boolean",
        "Conditional",
        "Change maximum capacity",
    ),
    (
        "form_data.is_aip",
        "body.form_data.is_aip",
        "boolean",
        "No",
        "Approval in principle indicator when applicable",
    ),
    (
        "form_data.part_1 … part_4",
        "body.form_data.part_1 / part_2 / part_3 / part_4",
        "object",
        "No",
        "Optional overlay using the same New Licence field structures. Omitted sections keep the Home Record snapshot",
    ),
    (
        "form_data.part_5.comments",
        "body.form_data.part_5.comments",
        "string",
        "No",
        "CHI has no top-level comments field; put remarks in part_5",
    ),
    (
        "form_data.part_5.checklist",
        "body.form_data.part_5.checklist",
        "array<object>",
        "No",
        "Checklist items keyed by position_code from GET /v1/changing-home-checklist",
    ),
]

NOTICE_OBJECT_ROWS = [
    (
        "third_party_name",
        "string",
        "Yes",
        "Target 3rd party, for example OP. Each client retrieves only its own Notice List",
    ),
    (
        "intake_type",
        "string/null",
        "Yes",
        "Intake / application type value and label, for example New Licence Application or Renewal Licence",
    ),
    (
        "notice_type",
        "string/null",
        "Yes",
        "Notice / letter category value and label, for example Acknowledgement Letter, Advisory Letter, Warning Letter or Licence Letter",
    ),
    ("rch_no", "string/null", "No", "RCH number associated with the notice"),
    ("rch_name", "string/null", "No", "RCH name associated with the notice"),
    (
        "created_time",
        "datetime",
        "Yes",
        "Notice creation time in ISO 8601 format, taken when CMTF-II automatically generated the letter",
    ),
    (
        "attachments",
        "array<object>",
        "Yes",
        "Generated files. May be an empty array when the Notice has no attachment",
    ),
    (
        "attachments[].data_id",
        "positive integer",
        "Conditional",
        "Attachment ID used by GET /v1/files/{attachment_id}",
    ),
    ("attachments[].filename", "string/null", "No", "Generated file name"),
    ("attachments[].size", "integer/null", "No", "Generated file size in bytes"),
    (
        "attachments[].download_url",
        "string",
        "Yes",
        "Relative authenticated download path; equivalent to a curl GET against BASE_URL + download_url",
    ),
]

NOTICE_QUERY_ROWS = [
    (
        "notices",
        "array<object>",
        "Notice List for the authorised 3rd party",
        "Empty array when none. Auto-created when CMTF-II generates a letter; not a client-authored Notice Board message",
    ),
    (
        "notices[].third_party_name",
        "string",
        "Target 3rd party name",
        "For example OP",
    ),
    (
        "notices[].intake_type",
        "string/null",
        "Intake type name",
        "For example New Licence Application / Renewal Licence",
    ),
    (
        "notices[].notice_type",
        "string/null",
        "Notice type value",
        "For example Acknowledgement Letter or Warning Letter",
    ),
    ("notices[].rch_no", "string/null", "RCH number", ""),
    ("notices[].rch_name", "string/null", "RCH name", ""),
    ("notices[].created_time", "datetime", "Notice created time", "ISO 8601"),
    (
        "notices[].attachments",
        "array<object>",
        "Generated letter/licence file objects",
        "May be empty; download through the authenticated relative path",
    ),
    (
        "notices[].attachments[].data_id",
        "positive integer",
        "Attachment ID used by Download File",
        "",
    ),
    (
        "notices[].attachments[].filename",
        "string/null",
        "Attachment file name",
        "",
    ),
    ("notices[].attachments[].size", "integer/null", "Attachment size in bytes", ""),
    (
        "notices[].attachments[].download_url",
        "string",
        "Relative authenticated download path",
        "Use BASE_URL + download_url, or curl the same URL with the Bearer token",
    ),
]

LETTER_RELATION_ROWS = [
    ("data_id", "positive integer", "Conditional", "File ID used by GET /v1/files/{data_id}"),
    ("filename", "string/null", "No", "Generated file name"),
    ("size", "integer/null", "No", "Generated file size in bytes"),
    ("download_url", "string", "Conditional", "Relative authenticated download path"),
]


def qname(tag: str) -> str:
    return f"{W}{tag}"


def text_of(el) -> str:
    return "".join(el.xpath(".//w:t/text()", namespaces=NS))


def iter_body(doc):
    return list(doc.xpath("./w:body/*", namespaces=NS))


def set_text(el, value: str) -> None:
    nodes = el.xpath(".//w:t", namespaces=NS)
    if not nodes:
        p = el if el.tag == qname("p") else el.xpath(".//w:p", namespaces=NS)
        if isinstance(p, list):
            p = p[0] if p else None
        if p is None:
            raise RuntimeError("no w:t to set")
        r = etree.SubElement(p, qname("r"))
        t = etree.SubElement(r, qname("t"))
        t.set(f"{XML}space", "preserve")
        t.text = value
        return
    nodes[0].text = value
    nodes[0].set(f"{XML}space", "preserve")
    for node in nodes[1:]:
        node.text = ""


def set_code_block_text(el, value: str) -> None:
    """Replace a cloned code block without retaining its old line-break runs."""
    paragraphs = el.xpath(".//w:p", namespaces=NS)
    if not paragraphs:
        raise RuntimeError("no paragraph in code block")
    paragraph = paragraphs[0]
    paragraph_properties = paragraph.find(qname("pPr"))
    runs = paragraph.xpath("./w:r", namespaces=NS)
    run_properties = deep_clone(runs[0].find(qname("rPr"))) if runs and runs[0].find(qname("rPr")) is not None else None
    for child in list(paragraph):
        if child is not paragraph_properties:
            paragraph.remove(child)
    for extra in paragraphs[1:]:
        parent = extra.getparent()
        if parent is not None:
            parent.remove(extra)
    run = etree.SubElement(paragraph, qname("r"))
    if run_properties is not None:
        run.append(run_properties)
    lines = value.splitlines() or [value]
    for index, line in enumerate(lines):
        text = etree.SubElement(run, qname("t"))
        text.set(f"{XML}space", "preserve")
        text.text = line or " "
        if index < len(lines) - 1:
            etree.SubElement(run, qname("br"))


def cell_texts(tr) -> list:
    return tr.xpath("./w:tc", namespaces=NS)


def set_row(tr, values: list[str]) -> None:
    cells = cell_texts(tr)
    if len(cells) < len(values):
        raise RuntimeError(f"row has {len(cells)} cells, need {len(values)}")
    for cell, value in zip(cells, values):
        set_text(cell, value)


def clone_row(tbl, values: list[str]):
    rows = tbl.xpath("./w:tr", namespaces=NS)
    new_row = copy.deepcopy(rows[-1])
    strip_comments(new_row)
    refresh_para_ids(new_row)
    set_row(new_row, values)
    rows[-1].addnext(new_row)
    return new_row


def replace_data_rows(tbl, rows_data: list[list[str]], header_rows: int = 1) -> None:
    current = tbl.xpath("./w:tr", namespaces=NS)
    template = copy.deepcopy(current[header_rows] if len(current) > header_rows else current[0])
    strip_comments(template)
    for row in current[header_rows:]:
        row.getparent().remove(row)
    parent = tbl
    for values in rows_data:
        row = copy.deepcopy(template)
        refresh_para_ids(row)
        set_row(row, values)
        parent.append(row)


def strip_comments(el) -> None:
    for tag in ("commentRangeStart", "commentRangeEnd", "commentReference"):
        for node in el.xpath(f".//w:{tag}", namespaces=NS):
            parent = node.getparent()
            if parent is not None:
                parent.remove(node)


def refresh_para_ids(el) -> None:
    for p in el.xpath(".//w:p", namespaces=NS):
        p.set(f"{W14}paraId", f"{random.randrange(0, 2**32):08X}")
        p.set(f"{W14}textId", f"{random.randrange(0, 2**32):08X}")


def deep_clone(el):
    cloned = copy.deepcopy(el)
    strip_comments(cloned)
    refresh_para_ids(cloned)
    return cloned


def replace_in_element(el, mapping: list[tuple[str, str]]) -> None:
    # Replace at paragraph granularity so table cells stay independent.
    targets = el.xpath(".//w:p", namespaces=NS)
    if el.tag == qname("p"):
        targets = [el]
    for para in targets:
        blob = text_of(para)
        new_blob = blob
        for old, new in mapping:
            new_blob = new_blob.replace(old, new)
        if new_blob != blob:
            set_text(para, new_blob)


def heading_text(el) -> str:
    if el.tag != qname("p"):
        return ""
    return text_of(el)


def is_heading(el, level: str | None = None) -> bool:
    if el.tag != qname("p"):
        return False
    styles = el.xpath("./w:pPr/w:pStyle/@w:val", namespaces=NS)
    if not styles:
        return False
    style = styles[0]
    if level is None:
        return style.startswith("Heading")
    return style == f"Heading{level}"


def first_table_after(doc, heading: str):
    body = doc.xpath("./w:body", namespaces=NS)[0]
    found = False
    for child in list(body):
        if heading_text(child) == heading:
            found = True
            continue
        if found and child.tag == qname("tbl"):
            return child
    raise KeyError(heading)


def table_by_first_row(doc, first_cell: str, second_cell: str | None = None):
    for tbl in doc.xpath(".//w:tbl", namespaces=NS):
        rows = tbl.xpath("./w:tr", namespaces=NS)
        if not rows:
            continue
        cells = [text_of(c) for c in cell_texts(rows[0])]
        if cells and cells[0] == first_cell:
            if second_cell is None or (len(cells) > 1 and cells[1] == second_cell):
                return tbl
    raise KeyError((first_cell, second_cell))


def replace_paragraphs(doc, mapping: list[tuple[str, str]], skip_if=None) -> int:
    count = 0
    for p in doc.xpath(".//w:p", namespaces=NS):
        original = text_of(p)
        if skip_if and skip_if(p, original):
            continue
        updated = original
        for old, new in mapping:
            updated = updated.replace(old, new)
        if updated != original:
            set_text(p, updated)
            count += 1
    return count


def skip_historical(p, original: str) -> bool:
    if original in {
        "Fields Not Submitted by Clients",
        "Do not submit intake_type_id, application native status fields, or server-owned identifiers.",
    }:
        return True
    if original.startswith("v0.") or original.startswith("Init version"):
        return True
    if "Corrected Create Intake API return status" in original:
        return True
    if original.startswith("Applied Daniel review comments"):
        return True
    if original.startswith("Resolved applicable Daniel review comments"):
        return True
    if original.startswith("Resolved review comments; introduced stable API IDs"):
        return True
    return False


def json_pretty(payload) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2)


def notices_example_fragment() -> str:
    payload = {
        "notices": [
            {
                "third_party_name": "OP",
                "intake_type": "New Licence Application",
                "notice_type": "a",
                "rch_no": "L0043",
                "rch_name": "Example Residential Care Home",
                "created_time": "2026-09-14T02:24:00Z",
                "attachments": [
                    {
                        "data_id": 98780,
                        "filename": "acknowledgement-letter.pdf",
                        "size": 245760,
                        "download_url": "/v1/files/98780",
                    }
                ],
            }
        ]
    }
    return json.dumps(payload, ensure_ascii=False)


def patch_status_and_copy(doc) -> None:
    mapping = [
        (
            "Create a New Licence request and optionally update it while the mapped business status remains Submitted. Update is locked from Received onward.",
            "Create a New Licence or Changing Home request and optionally update it while the mapped business status remains Accepted. Update is locked from Received onward.",
        ),
        (
            "Returns the same response envelope while omitting protected personal values from application_data, notice_board and related person/contact objects.",
            "Returns the same response envelope while omitting protected personal values from application_data, notices and related person/contact objects.",
        ),
        (
            "HTTP status Accepted in a Create or Update response means that the API request was accepted for asynchronous processing. Capitalised Submitted in Section 3 and in GET /v1/request/{create_id} is a mapped business status. Internal Intake/Application status values in this table are reference data only and must not be used as the external notification contract.",
            "A successful Create or Update request returns HTTP status Accepted. GET /v1/request/{create_id} uses the same Accepted value as the initial mapped business status until the workflow pushes the application and the status becomes Received. Internal Intake/Application status values in this table are reference data only and must not be used as the external notification contract.",
        ),
        (
            "Allowed only while the mapped business status is Submitted; locked from Received onward",
            "Allowed only while the mapped business status is Accepted; locked from Received onward",
        ),
        (
            "Mapped business status is no longer Submitted",
            "Mapped business status is no longer Accepted",
        ),
        (
            "Update is allowed while the mapped business status is Submitted. The first transition to Received or any later mapped status permanently locks the Update interface for that create_id.",
            "Update is allowed while the mapped business status is Accepted. The first transition to Received or any later mapped status permanently locks the Update interface for that create_id.",
        ),
        (
            'Update is allowed only while status is Submitted.',
            'Update is allowed only while status is Accepted.',
        ),
        (
            "Immediately after Create, GET /v1/request/{create_id} returns mapped business status Submitted. application_data may still be null while asynchronous processing is in progress. create_id remains the only public lookup key.",
            "Immediately after Create, GET /v1/request/{create_id} returns mapped business status Accepted. application_data may still be null while asynchronous processing is in progress. create_id remains the only public lookup key.",
        ),
        (
            "Retrieve the mapped business status, authorised application projection, confirmed sent letters, Notice Board content and OP RCH reference",
            "Retrieve the mapped business status, authorised application projection, Notice List (with letter attachments) and OP RCH reference",
        ),
        (
            "Submitted, Received, P_Number_Generated, Acknowledged, Confirmed, Reminding, Approved or Rejected",
            "Accepted, Received, P_Number_Generated, Acknowledged, Confirmed, Reminding, Approved or Rejected",
        ),
        (
            "The response contains office_code, application_type, the single authoritative top-level status, application_data, confirmed letter_attachments, notice_board and op_rch_reference according to permission.",
            "The response contains office_code, application_type, the single authoritative top-level status, application_data, notices and op_rch_reference according to permission.",
        ),
        (
            "Optionally POST /v1/update_new_licence_data while status is Submitted",
            "Optionally POST /v1/update_new_licence_data while status is Accepted",
        ),
        (
            "Read status, authorised application_data, letters, notice_board and op_rch_reference",
            "Read status, authorised application_data, notices and op_rch_reference",
        ),
        (
            "Download confirmed letter or Notice Board files",
            "Download confirmed Notice List letter/licence files",
        ),
        (
            "Create returns status Accepted immediately after request acceptance. The client may Update while the mapped business status remains Submitted. The first transition to Received, P_Number_Generated, Acknowledged, Confirmed, Reminding, Approve",
            "Create returns status Accepted immediately after request acceptance. The client may Update while the mapped business status remains Accepted. The first transition to Received, P_Number_Generated, Acknowledged, Confirmed, Reminding, Approve",
        ),
        (
            "Create/Update returns HTTP status Accepted. Persist create_id as the sole public correlation and query key, including CMTF-initiated values. Query business status starts at Submitted.",
            "Create/Update returns HTTP status Accepted. Persist create_id as the sole public correlation and query key, including CMTF-initiated values. Query business status starts at Accepted.",
        ),
        (
            "Allow Update only while the mapped business status is Submitted; Received and later statuses lock Update. Handle 409 update_locked without retrying the same change.",
            "Allow Update only while the mapped business status is Accepted; Received and later statuses lock Update. Handle 409 update_locked without retrying the same change.",
        ),
        (
            "Download confirmed letter and Notice Board files only through the returned authenticated download path.",
            "Download confirmed Notice List files only through the returned authenticated download path.",
        ),
        (
            "Accepted; not the mapped business status Submitted",
            "Accepted; Query mapped business status starts at the same Accepted value",
        ),
        (
            "Immediate Create/Update HTTP status; not the mapped business status Submitted",
            "Immediate Create/Update HTTP status; Query mapped business status starts at the same Accepted value",
        ),
        (
            "Files and Checklist",
            "Files and Checklist",
        ),
    ]
    replace_paragraphs(doc, mapping, skip_if=skip_historical)

    # Catch remaining business-status Submitted mentions outside amendment history
    # and the "Fields Not Submitted" heading.
    for p in doc.xpath(".//w:p", namespaces=NS):
        original = text_of(p)
        if skip_historical(p, original):
            continue
        if "Fields Not Submitted" in original:
            continue
        updated = original
        updated = updated.replace(
            "mapped business status remains Submitted",
            "mapped business status remains Accepted",
        )
        updated = updated.replace(
            "mapped business status is Submitted",
            "mapped business status is Accepted",
        )
        updated = updated.replace(
            "business status Submitted",
            "business status Accepted",
        )
        updated = updated.replace(
            "status is Submitted",
            "status is Accepted",
        )
        updated = updated.replace("notice_board", "notices")
        updated = updated.replace("Notice Board Object", "Notice List Object")
        updated = updated.replace("Notice Board content", "Notice List")
        updated = updated.replace("Notice Board files", "Notice List files")
        updated = updated.replace("Notice Board messages", "Notice List records")
        if updated != original:
            set_text(p, updated)


def patch_tables(doc) -> None:
    tables = doc.xpath(".//w:tbl", namespaces=NS)

    # T02 amendment history
    amend = tables[2]
    clone_row(
        amend,
        [
            "v0.53",
            "Merged sent-letter files into the Notice List; changed the initial mapped business status from Submitted to Accepted; added Changing Home APIs and Home Record fallback lookup.",
            "3.4, 4.5–4.7, 5.3–5.4",
            "15 Sep 2026",
            "Gregory Lee",
        ],
    )
    # Keep the complete amendment history together instead of spilling one
    # short row onto an otherwise empty page.
    for run in amend.xpath(".//w:r", namespaces=NS):
        run_props = run.find(qname("rPr"))
        if run_props is None:
            run_props = etree.Element(qname("rPr"))
            run.insert(0, run_props)
        size = run_props.find(qname("sz"))
        if size is None:
            size = etree.SubElement(run_props, qname("sz"))
        size.set(qname("val"), "12")

    # T03 requirements
    req = tables[3]
    clone_row(
        req,
        [
            "Changing Home Information",
            "TBC",
            "TBC",
        ],
    )

    # T04 interface overview — Files and Checklist / Create
    overview = tables[4]
    set_row(
        overview.xpath("./w:tr", namespaces=NS)[2],
        [
            "Files and Checklist",
            "Client → CMTF-II",
            "Upload files and retrieve the office-specific Checklist catalogue before Create. New Licence uses GET /v1/new-licence-checklist; Changing Home uses GET /v1/changing-home-checklist.",
        ],
    )
    set_row(
        overview.xpath("./w:tr", namespaces=NS)[3],
        [
            "Create / Update",
            "Client → CMTF-II",
            "Create a New Licence or Changing Home request and optionally update it while the mapped business status remains Accepted. Update is locked from Received onward.",
        ],
    )

    # T12 business status mapping
    status_tbl = tables[12]
    status_rows = status_tbl.xpath("./w:tr", namespaces=NS)
    set_row(
        status_rows[1],
        [
            "Accepted",
            "Initial mapped business stage immediately after a successful Create or Update request. Same value as the HTTP response status Accepted.",
            "Yes",
            "N/A",
        ],
    )
    set_row(
        status_rows[2],
        [
            "Received",
            "Outgoing workflow status after the application is created from Intake / SWIT-SWO recommend-proceed. Update is not allowed from this status onward.",
            "No",
            "application_data",
        ],
    )
    for row in status_rows[4:]:
        cells = cell_texts(row)
        if len(cells) >= 4 and "letter_attachments" in text_of(cells[3]):
            set_text(cells[3], "application_data, notices")

    # T19 notice object
    notice_tbl = first_table_after(doc, "Notice List Object")
    replace_data_rows(
        notice_tbl,
        [[a, b, c, d] for a, b, c, d in NOTICE_OBJECT_ROWS],
    )

    # T20 letter attachment relation
    letter_heading = None
    for p in doc.xpath(".//w:p", namespaces=NS):
        if text_of(p) in {
            "Letter Attachment Object and Letter Types",
            "Notice Attachments (Letter Attachment)",
        }:
            letter_heading = p
            break
    if letter_heading is None:
        raise RuntimeError("letter heading missing")
    set_text(letter_heading, "Notice Attachments (Letter Attachment)")
    nxt = letter_heading.getnext()
    if nxt is not None and nxt.tag == qname("p"):
        set_text(
            nxt,
            "When CMTF-II automatically generates a letter for a 3rd party such as OP, it creates a Notice List record. The Notice may have no file; in that case attachments is an empty array. CMTF-II does not provide a screen or API for clients to compose or send Notice messages. Clients do not receive message subject, content, recipients or internal letter-record identifiers. Download available files with GET /v1/files/{data_id} using notices[].attachments[].download_url.",
        )
    letter_tbl = nxt.getnext() if nxt is not None else None
    if letter_tbl is None or letter_tbl.tag != qname("tbl"):
        raise RuntimeError("letter table missing")
    replace_data_rows(
        letter_tbl,
        [[a, b, c, d] for a, b, c, d in LETTER_RELATION_ROWS],
    )

    # T21 letter / notice types
    type_heading = None
    for p in doc.xpath(".//w:p", namespaces=NS):
        if text_of(p) in {"Letter Type Values", "Notice Type Values"}:
            style = "".join(p.xpath("./w:pPr/w:pStyle/@w:val", namespaces=NS))
            if style.startswith("Heading"):
                type_heading = p
                break
    if type_heading is None:
        raise RuntimeError("letter type heading missing")
    set_text(type_heading, "Notice Type Values")
    type_tbl = type_heading.getnext()
    clone_row(
        type_tbl,
        ["g", "Advisory Letter", "Advisory correspondence", "When issued and confirmed sent"],
    )
    clone_row(
        type_tbl,
        ["h", "Warning Letter", "Warning correspondence", "When issued and confirmed sent"],
    )
    # rename f label note already New Licence Letter; keep

    # T24 request.status note already handled via paragraph replace inside cells
    for tbl in tables:
        for tr in tbl.xpath("./w:tr", namespaces=NS):
            for tc in cell_texts(tr):
                original = text_of(tc)
                updated = original
                updated = updated.replace(
                    "Immediate Create/Update HTTP status; not the mapped business status Submitted",
                    "Immediate Create/Update HTTP status; Query mapped business status starts at the same Accepted value",
                )
                updated = updated.replace(
                    "Accepted; not the mapped business status Submitted",
                    "Accepted; Query mapped business status starts at the same Accepted value",
                )
                updated = updated.replace(
                    "Mapped business status is no longer Submitted",
                    "Mapped business status is no longer Accepted",
                )
                updated = updated.replace(
                    "Allowed only while the mapped business status is Submitted",
                    "Allowed only while the mapped business status is Accepted",
                )
                updated = updated.replace(
                    "Update is allowed only while status is Submitted.",
                    "Update is allowed only while status is Accepted.",
                )
                updated = updated.replace(
                    "Submitted, Received, P_Number_Generated",
                    "Accepted, Received, P_Number_Generated",
                )
                if updated != original and "Fields Not Submitted" not in original:
                    set_text(tc, updated)

    # Query success field table: merge letter_attachments + notice_board
    query_fields = None
    for tbl in tables:
        rows = tbl.xpath("./w:tr", namespaces=NS)
        if not rows:
            continue
        first = [text_of(c) for c in cell_texts(rows[0])]
        if first[:4] == ["Field", "Type", "Description", "Notes"]:
            second = [text_of(c) for c in cell_texts(rows[1])] if len(rows) > 1 else []
            if second and second[0] == "office_code":
                query_fields = tbl
                break
    if query_fields is None:
        raise RuntimeError("query field table missing")
    rows = query_fields.xpath("./w:tr", namespaces=NS)
    merge_rows = []
    for tr in rows:
        key = text_of(cell_texts(tr)[0])
        if (
            key.startswith("letter_attachments")
            or key.startswith("notice_board")
            or key == "notices"
            or key.startswith("notices[]")
        ):
            merge_rows.append(tr)
    if len(merge_rows) < len(NOTICE_QUERY_ROWS):
        raise RuntimeError("not enough query rows to merge notices")
    for tr, values in zip(merge_rows, NOTICE_QUERY_ROWS):
        set_row(tr, list(values))
    for tr in merge_rows[len(NOTICE_QUERY_ROWS) :]:
        tr.getparent().remove(tr)

    # Query example JSON
    example_tbl = None
    for tbl in tables:
        blob = text_of(tbl)
        if '"op_rch_reference"' in blob and '"application_type"' in blob and blob.strip().startswith("{"):
            example_tbl = tbl
            break
    if example_tbl is None:
        raise RuntimeError("query example missing")
    example = text_of(example_tbl)
    start = example.find('"letter_attachments"')
    if start < 0:
        start = example.find('"notices"')
    end = example.find('"op_rch_reference"')
    if start < 0 or end < 0:
        raise RuntimeError("query example anchors missing")
    notices_json = notices_example_fragment()
    # notices_example_fragment includes {"notices": ...}; we need the inner pair
    inner = notices_json[1:-1].strip()
    if not inner.endswith(","):
        inner = inner + ","
    new_example = example[:start] + inner + " " + example[end:]
    try:
        new_example = json.dumps(
            json.loads(new_example), ensure_ascii=False, indent=2
        )
    except json.JSONDecodeError:
        pass
    set_text(example_tbl, new_example)

    # E2E table
    e2e = tables[84]
    e2e_rows = e2e.xpath("./w:tr", namespaces=NS)
    set_row(
        e2e_rows[5],
        [
            "5",
            "Optionally POST /v1/update_new_licence_data while status is Accepted",
            "create_id",
        ],
    )
    set_row(
        e2e_rows[7],
        [
            "7",
            "GET /v1/request/{create_id} once after notification",
            "Read status, authorised application_data, notices and op_rch_reference",
        ],
    )
    set_row(
        e2e_rows[8],
        [
            "8",
            "GET /v1/files/{attachment_id}",
            "Download confirmed Notice List letter/licence files",
        ],
    )


def patch_notice_heading_and_intro(doc) -> None:
    for p in doc.xpath(".//w:p", namespaces=NS):
        if text_of(p) == "Notice Board Object":
            set_text(p, "Notice List Object")
            nxt = p.getnext()
            if nxt is not None and nxt.tag == qname("p"):
                set_text(
                    nxt,
                    "When CMTF-II automatically generates a letter (for example to OP), it creates a Notice List record. Each 3rd party retrieves only its own Notice List and details through Query. CMTF-II does not provide a user interface or an API for staff to compose or send notices. The Notice List carries 3rd party name, intake type, notice type, RCH number, RCH name, created time and attachments. Message subject, message content and recipients are omitted; the 3rd party applies its own notice-board logic. Attachments are the generated letter/licence files obtained from the related letter_attachment and downloaded with GET /v1/files/{attachment_id}.",
                )
            break
    for p in doc.xpath(".//w:p", namespaces=NS):
        t = text_of(p)
        if t.startswith("4.5.Notice Board Object"):
            set_text(p, t.replace("Notice Board Object", "Notice List Object"))
        elif t.startswith("4.6.Letter Attachment Object"):
            set_text(
                p,
                t.replace(
                    "Letter Attachment Object and Letter Types",
                    "Notice Attachments (Letter Attachment)",
                ),
            )
        elif t.startswith("4.7.Letter Type Values"):
            set_text(p, t.replace("Letter Type Values", "Notice Type Values"))


def patch_query_application_type_notes(doc) -> None:
    tables = doc.xpath(".//w:tbl", namespaces=NS)
    for tbl in tables:
        rows = tbl.xpath("./w:tr", namespaces=NS)
        if not rows:
            continue
        first = text_of(cell_texts(rows[0])[0])
        if first != "Field":
            continue
        for tr in rows:
            key = text_of(cell_texts(tr)[0])
            cells = cell_texts(tr)
            if key == "application_type.value" and len(cells) >= 4:
                set_text(cells[3], "new_licence or changing_home")
            elif key == "application_type.label" and len(cells) >= 4:
                set_text(
                    cells[3],
                    "New Licence Applications or Changing Home Information Application",
                )


def patch_layout(doc) -> None:
    """Allow long API tables/JSON examples to paginate without blank pages."""
    for row_props in doc.xpath(".//w:trPr", namespaces=NS):
        for child in list(row_props):
            if child.tag in {qname("cantSplit"), qname("trHeight")}:
                row_props.remove(child)
    for table in doc.xpath(".//w:tbl", namespaces=NS):
        content = text_of(table)
        if len(content) < 1200 or not content.lstrip().startswith(("{", "[")):
            continue
        rows = table.xpath("./w:tr", namespaces=NS)
        if not rows:
            continue
        row_template = rows[0]
        source_cells = row_template.xpath("./w:tc", namespaces=NS)
        if not source_cells:
            continue
        # The retained NLA Create/Update examples have valid JSON whose old
        # line breaks were flattened into a single w:t. Rebuild their visual
        # indentation without changing any key, value, or request hierarchy.
        try:
            lines = json_pretty(json.loads(content)).splitlines()
        except json.JSONDecodeError:
            lines = content.splitlines() or [content]
        paragraph_template = source_cells[0].xpath("./w:p", namespaces=NS)[0]
        run_templates = paragraph_template.xpath("./w:r", namespaces=NS)
        run_template = run_templates[0] if run_templates else etree.Element(qname("r"))
        for row in rows:
            table.remove(row)
        for offset in range(0, len(lines), 24):
            chunk = lines[offset : offset + 24]
            row = deep_clone(row_template)
            for prop in row.xpath("./w:trPr/w:cantSplit | ./w:trPr/w:trHeight", namespaces=NS):
                prop.getparent().remove(prop)
            cell = row.xpath("./w:tc", namespaces=NS)[0]
            tc_pr = cell.find(qname("tcPr"))
            for child in list(cell):
                if child is not tc_pr:
                    cell.remove(child)
            paragraph = deep_clone(paragraph_template)
            for run in paragraph.xpath("./w:r", namespaces=NS):
                paragraph.remove(run)
            for prop in paragraph.xpath(
                "./w:pPr/w:keepNext | ./w:pPr/w:keepLines | ./w:pPr/w:pageBreakBefore",
                namespaces=NS,
            ):
                prop.getparent().remove(prop)
            for index, line in enumerate(chunk):
                run = deep_clone(run_template)
                for child in list(run):
                    if child.tag != qname("rPr"):
                        run.remove(child)
                text = etree.SubElement(run, qname("t"))
                text.set(f"{XML}space", "preserve")
                text.text = line or " "
                if index < len(chunk) - 1:
                    etree.SubElement(run, qname("br"))
                paragraph.append(run)
            cell.append(paragraph)
            table.append(row)
    # Ask Word to refresh the existing TOC without rebuilding its styled runs.
    for fld in doc.xpath(".//w:fldChar[@w:fldCharType='begin']", namespaces=NS):
        paragraph = fld.getparent()
        text = text_of(paragraph.getparent()) if paragraph is not None and paragraph.getparent() is not None else ""
        if "TOC" in text or "Table of Contents" in text:
            fld.set(qname("dirty"), "true")


def patch_short_request_examples(doc) -> None:
    """Give short request bodies the same clear, multiline presentation."""
    for heading in doc.xpath("./w:body/w:p", namespaces=NS):
        if text_of(heading) != "Request Example":
            continue
        node = heading.getnext()
        if node is None or node.tag != qname("tbl"):
            continue
        content = text_of(node).strip()
        if content == (
            "multipart: file=@./application.pdf; "
            "externalRequestId=FILE-20260907-0001"
        ):
            set_code_block_text(
                node,
                "multipart/form-data\n"
                "file: @./application.pdf\n"
                "externalRequestId: FILE-20260907-0001",
            )
            continue
        if not content.startswith("{") or len(content) >= 1200:
            continue
        try:
            payload = json.loads(content)
        except json.JSONDecodeError:
            continue
        if node.xpath(
            ".//w:commentRangeStart | .//w:commentRangeEnd | .//w:commentReference",
            namespaces=NS,
        ):
            raise RuntimeError("A request example contains an anchored comment")
        set_code_block_text(node, json_pretty(payload))


def insert_chi_section(doc) -> None:
    body = doc.xpath("./w:body", namespaces=NS)[0]
    children = list(body)
    nla_h2 = None
    download_h2 = None
    for child in children:
        if is_heading(child, "2") and text_of(child) == "New Licence Applications":
            nla_h2 = child
        if is_heading(child, "2") and text_of(child) == "Download File":
            download_h2 = child
    if nla_h2 is None or download_h2 is None:
        raise RuntimeError("NLA or Download heading missing")

    # Slice NLA subsections by walking siblings
    nla_children = []
    el = nla_h2.getnext()
    while el is not None and el is not download_h2:
        nla_children.append(el)
        el = el.getnext()

    def find_h3(title: str):
        for item in nla_children:
            if is_heading(item, "3") and text_of(item) == title:
                return item
        raise KeyError(title)

    def take_until_next_h3(start_el):
        block = [start_el]
        cur = start_el.getnext()
        while cur is not None and cur is not download_h2 and not is_heading(cur, "3") and not is_heading(cur, "2"):
            block.append(cur)
            cur = cur.getnext()
        return block

    checklist_block = take_until_next_h3(find_h3("Query New Licence Checklist"))
    create_block = take_until_next_h3(find_h3("Create Intake for New Licence"))
    update_block = take_until_next_h3(find_h3("Update New Licence Data"))

    # Compact CHI create: property + headers + top-level body + example/success/errors
    create_keep = []
    skipping_field_refs = False
    for item in create_block:
        title = text_of(item) if item.tag == qname("p") else ""
        if is_heading(item, "4") and title.startswith("Create Request Body Field Reference"):
            skipping_field_refs = True
            continue
        if is_heading(item, "4") and title == "Fields Not Submitted by Clients":
            skipping_field_refs = True
            continue
        if skipping_field_refs:
            if is_heading(item, "4") and title == "Request Example":
                skipping_field_refs = False
            else:
                continue
        create_keep.append(item)

    chi_nodes = []

    h2 = deep_clone(nla_h2)
    set_text(h2, "Changing Home Applications")
    chi_nodes.append(h2)

    intro = deep_clone(nla_h2.getnext())
    set_text(
        intro,
        "This section defines the released Changing Home Information contract. Authentication, file upload, identifiers, status notification, Query by create_id, Update locking and error handling follow the same rules as New Licence Applications. Query uses GET /v1/request/{create_id} (CMTFII-API-3001).",
    )
    chi_nodes.append(intro)

    def clone_block(block, replacements: list[tuple[str, str]]):
        cloned = []
        for item in block:
            node = deep_clone(item)
            replace_in_element(node, replacements)
            cloned.append(node)
        return cloned

    checklist_repls = [
        ("Query New Licence Checklist", "Query Changing Home Checklist"),
        ("first New Licence Applications API", "Changing Home Checklist API"),
        ("CMTFII-API-1101", "CMTFII-API-1102"),
        ("/v1/new-licence-checklist", "/v1/changing-home-checklist"),
        ("New Licence Checklist catalogue", "Changing Home Checklist catalogue"),
        ("New Licence Checklist", "Changing Home Checklist"),
    ]
    chi_nodes.extend(clone_block(checklist_block, checklist_repls))

    create_repls = [
        ("Create Intake for New Licence", "Create Intake for Changing Home"),
        ("CMTFII-API-2001", "CMTFII-API-2003"),
        ("/v1/create_intake_for_new_licence", "/v1/create_intake_for_changing_home"),
        (
            "Create a New Licence Intake and begin New Licence Application processing",
            "Create a Changing Home Intake against an existing Home Record and begin Changing Home processing",
        ),
        ("Complete New Licence submission using the structures below", "Changing Home submission; see the field table below"),
        ("NLA-CREATE-20260914-0001", "CHI-CREATE-20260914-0001"),
    ]
    cloned_create = clone_block(create_keep, create_repls)
    # Expand the top-level body table
    for node in cloned_create:
        if node.tag != qname("tbl"):
            continue
        rows = node.xpath("./w:tr", namespaces=NS)
        if not rows:
            continue
        header = [text_of(c) for c in cell_texts(rows[0])]
        if header[:5] == ["Field", "JSON path", "Type", "Required", "Description"]:
            replace_data_rows(node, [list(row) for row in CHI_CREATE_FIELDS])
        blob = text_of(node)
        if blob.strip().startswith("{") and "request_id" in blob:
            set_code_block_text(node, json_pretty(CHI_CREATE_EXAMPLE))
        if header[:3] == ["HTTP", "Code", "Condition"]:
            clone_row(
                node,
                [
                    "422",
                    "home_record_not_found",
                    "create_id, rch_no and p_no do not resolve to a Home Record for the submitted office_code",
                ],
            )
            clone_row(
                node,
                [
                    "422",
                    "invalid_field",
                    "None of the five Changing Home change flags is true",
                ],
            )
    chi_nodes.extend(cloned_create)

    update_repls = [
        ("Update New Licence Data", "Update Changing Home Data"),
        ("CMTFII-API-2002", "CMTFII-API-2004"),
        ("/v1/update_new_licence_data", "/v1/update_changing_home_data"),
        (
            "Partially update the New Licence data associated with the original Create request. A full Create payload may be submitted again.",
            "Partially update the Changing Home data associated with the original Create request. Update is allowed only while status is Accepted.",
        ),
        ("NLA-UPDATE-20260914-0001", "CHI-UPDATE-20260914-0001"),
        (
            "form_data follows the Create hierarchy; submit only explicit changes. No Create-required field must be repeated unless it is being changed.",
            "form_data follows the Changing Home Create hierarchy; submit only explicit changes. Overlay parts are optional. comments remain in form_data.part_5.",
        ),
    ]
    cloned_update = clone_block(update_block, update_repls)
    for node in cloned_update:
        if node.tag != qname("tbl"):
            continue
        blob = text_of(node)
        if blob.strip().startswith("{") and "CHI-UPDATE" in blob:
            set_code_block_text(node, json_pretty(CHI_UPDATE_EXAMPLE))
    chi_nodes.extend(cloned_update)

    # Insert before Download File, preserving chi_nodes order.
    for node in chi_nodes:
        download_h2.addprevious(node)

    # TOC insert after 5.3.4
    toc_anchor = None
    for p in doc.xpath(".//w:p", namespaces=NS):
        if text_of(p).startswith("5.3.4.Query Requested Application"):
            toc_anchor = p
            break
    if toc_anchor is not None:
        toc_h2 = None
        for p in doc.xpath(".//w:p", namespaces=NS):
            if text_of(p).startswith("5.3.New Licence Applications"):
                toc_h2 = p
                break
        if toc_h2 is not None:
            entry = deep_clone(toc_h2)
            set_text(entry, "5.4.Changing Home Applications")
            toc_anchor.addnext(entry)
            # Insert CHI child TOC entries after the new 5.4 heading.
            cursor = entry
            toc_children = [
                "5.4.1.Query Changing Home Checklist",
                "5.4.2.Create Intake for Changing Home",
                "5.4.3.Update Changing Home Data",
            ]
            sample_toc3 = None
            for p in doc.xpath(".//w:p", namespaces=NS):
                if text_of(p).startswith("5.3.1.Query New Licence Checklist"):
                    sample_toc3 = p
                    break
            if sample_toc3 is not None:
                for title in toc_children:
                    child = deep_clone(sample_toc3)
                    set_text(child, title)
                    cursor.addnext(child)
                    cursor = child
        for p in doc.xpath(".//w:p", namespaces=NS):
            t = text_of(p)
            if t.startswith("5.4.Download File"):
                set_text(p, t.replace("5.4.", "5.5."))
            elif t.startswith("5.4.1.Request Headers") or t.startswith("5.4.2.Path Parameters") or t.startswith("5.4.3.Request Example") or t.startswith("5.4.4.Success Response") or t.startswith("5.4.5.Error Responses"):
                set_text(p, "5.5" + t[3:])
            elif t.startswith("5.5.Health Checks"):
                set_text(p, t.replace("5.5.", "5.6."))
            elif t.startswith("5.5.1.Health Live") or t.startswith("5.5.2.Health Ready"):
                set_text(p, t.replace("5.5.", "5.6."))


def patch_core(xml: bytes) -> bytes:
    core = etree.fromstring(xml)
    ns = {
        "dc": "http://purl.org/dc/elements/1.1/",
        "dcterms": "http://purl.org/dc/terms/",
        "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    }
    title = core.find("dc:title", ns)
    if title is not None:
        title.text = "CMTF-II Application Services API Specification v0.53"
    modified = core.find("dcterms:modified", ns)
    if modified is not None:
        modified.text = "2026-09-15T02:00:00Z"
    revision = core.find("cp:revision", ns)
    if revision is not None and revision.text and revision.text.isdigit():
        revision.text = str(int(revision.text) + 1)
    return etree.tostring(core, xml_declaration=True, encoding="UTF-8", standalone=True)


def write_docx(src: Path, dst: Path, document_xml: bytes, core_xml: bytes) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(
        dst, "w", compression=zipfile.ZIP_DEFLATED
    ) as zout:
        for info in zin.infolist():
            data = zin.read(info.filename)
            if info.filename == "word/document.xml":
                data = document_xml
            elif info.filename == "docProps/core.xml":
                data = core_xml
            zout.writestr(info, data)


def main() -> None:
    random.seed(53)
    with zipfile.ZipFile(SRC) as z:
        document_xml = z.read("word/document.xml")
        core_xml = z.read("docProps/core.xml")
        comments_xml = z.read("word/comments.xml")

    doc = etree.fromstring(document_xml)
    patch_notice_heading_and_intro(doc)
    patch_status_and_copy(doc)
    patch_tables(doc)
    patch_query_application_type_notes(doc)
    insert_chi_section(doc)
    patch_short_request_examples(doc)
    patch_layout(doc)

    comments = etree.fromstring(comments_xml)
    comment_ids = comments.xpath("//w:comment/@w:id", namespaces=NS)
    range_ids = doc.xpath("//w:commentRangeStart/@w:id", namespaces=NS)
    if len(comment_ids) != 34 or len(range_ids) != 34:
        raise SystemExit(
            f"comment mismatch: comments={len(comment_ids)} ranges={len(range_ids)}"
        )

    new_document = etree.tostring(
        doc, xml_declaration=True, encoding="UTF-8", standalone=True
    )
    new_core = patch_core(core_xml)
    write_docx(SRC, DST, new_document, new_core)
    REPO_COPY.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(DST, REPO_COPY)
    print(f"wrote {DST}")
    print(f"copied {REPO_COPY}")
    print(f"comments={len(comment_ids)} ranges={len(range_ids)}")


if __name__ == "__main__":
    main()
