#!/usr/bin/env python3
"""Produce v0.54 from the existing v0.53 without rebuilding the Word layout."""

from __future__ import annotations

import copy
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from lxml import etree

import patch_cmtf_api_spec_v053 as spec53


SOURCE = Path(
    "/Users/work/NCSI-CM-Documents/SI&I/Interfaces/API Specification/"
    "CMTF-II API Specification v0.53.docx"
)
OUTPUT = SOURCE.with_name("CMTF-II API Specification v0.54.docx")
REPO_COPY = Path(
    "/Users/work/noco/kong-nocoadapter/deliverables/"
    "CMTF-II API Specification v0.54.docx"
)


CHI_CREATE_EXAMPLE = {
    "request_id": "CHI-CREATE-20260915-0001",
    "form_data": {
        "case_summary": {
            "office_code": "LORCHE",
            "rch_no": "L0043",
            "received_date": "2026-09-15",
            "submitter_user_id": 12,
            "task_owner_user_id": 45,
            "task_owner_post_code": "S(LR)1",
            "source_other": "OP",
        },
        "is_change_name": True,
        "is_change_address": True,
        "is_change_operator_or_operating_company": True,
        "is_change_rch_type": True,
        "is_change_maximum_capacity": True,
        "is_aip": False,
        "part_2": {
            "rch_name_en": "Example Residential Care Home Revised",
            "rch_name_cn": "示例安老院修订",
            "rch_type_code": "a1",
            "max_capacity": 52,
            "address": {
                "region_code": "0",
                "district_code": "C",
                "sub_district_code": "Admiralty",
                "full_name_en": "1 Example Road, Admiralty, Hong Kong",
                "full_name_cn": "香港金钟示例道1号",
                "lot_or_address_en": "1 Example Road",
                "lot_or_address_cn": "示例道1号",
                "block_no_en": "Block A",
                "block_no_cn": "A座",
                "block_type_en": "0",
                "block_type_cn": "0",
                "floor_en": "2/F",
                "floor_cn": "2楼",
                "unit_no_en": "Units 1-4",
                "unit_no_cn": "1至4室",
                "unit_type_en": "0",
                "unit_type_cn": "0",
                "building_name_en": "Example Building",
                "building_name_cn": "示例大厦",
                "estate_or_village_en": "Example Estate",
                "estate_or_village_cn": "示例村",
                "street_no_en": "1",
                "street_no_cn": "1",
                "street_name_en": "Example Road",
                "street_name_cn": "示例道",
                "phase_en": "Phase 1",
                "phase_cn": "第一期",
            },
        },
        "part_3": {
            "operator": {
                "title": "Mr",
                "full_name_en": "Chan Tai Man",
                "full_name_cn": "陈大文",
                "mobile_phone": "91234567",
                "email": "operator@example.org",
            },
            "company": {
                "company_name_en": "Example Care Services Limited",
                "company_name_cn": "示例安老服务有限公司",
                "business_registration_no": "12345678",
                "office_phone": "21230000",
            },
        },
        "part_5": {
            "comments": "Change of name, address, operator, RCH type and capacity.",
            "checklist": [
                {
                    "position_code": "LORCHE_STAGE2_ELDERLY_HOME_LICENCE_APPLICATION_FORM",
                    "attachment_id": 98766,
                }
            ],
        },
    },
}


CHI_UPDATE_EXAMPLE = {
    "request_id": "CHI-UPDATE-20260915-0001",
    "create_id": "384777930997760",
    "form_data": {
        "part_2": {
            "rch_name_en": "Example Residential Care Home Final Name",
            "max_capacity": 54,
            "address": {
                "full_name_en": "2 Example Road, Admiralty, Hong Kong",
                "full_name_cn": "香港金钟示例道2号",
            },
        },
        "part_5": {
            "comments": "Revised name, address and capacity supplied.",
            "checklist": [
                {
                    "position_code": "LORCHE_STAGE2_ELDERLY_HOME_LICENCE_APPLICATION_FORM",
                    "attachment_id": 98769,
                }
            ],
        },
    },
}


def replace_request_examples(document: etree._Element) -> None:
    body = document.xpath("./w:body", namespaces=spec53.NS)[0]
    replaced = set()
    for paragraph in body.xpath("./w:p", namespaces=spec53.NS):
        if spec53.text_of(paragraph) != "Request Example":
            continue
        table = paragraph.getnext()
        if table is None or table.tag != spec53.qname("tbl"):
            continue
        original = spec53.text_of(table).strip()
        if table.xpath(
            ".//w:commentRangeStart | .//w:commentRangeEnd | .//w:commentReference",
            namespaces=spec53.NS,
        ):
            raise RuntimeError("A request example has an anchored comment")
        if "CHI-CREATE-" in original:
            spec53.set_code_block_text(table, spec53.json_pretty(CHI_CREATE_EXAMPLE))
            replaced.add("CHI Create")
        elif "CHI-UPDATE-" in original:
            spec53.set_code_block_text(table, spec53.json_pretty(CHI_UPDATE_EXAMPLE))
            replaced.add("CHI Update")
        elif original.startswith("GET ") and "Authorization:" in original:
            formatted = re.sub(r"(?<!\n)Authorization:", "\nAuthorization:", original)
            spec53.set_code_block_text(table, formatted)
    if replaced != {"CHI Create", "CHI Update"}:
        raise RuntimeError(f"Could not replace both CHI request examples: {replaced}")


def add_revision(document: etree._Element) -> None:
    for table in document.xpath(".//w:tbl", namespaces=spec53.NS):
        rows = table.xpath("./w:tr", namespaces=spec53.NS)
        if not rows or "Amendment History" not in spec53.text_of(rows[0]):
            continue
        if "v0.54" in spec53.text_of(table):
            raise RuntimeError("v0.54 revision already exists")
        row = copy.deepcopy(rows[-1])
        cells = row.xpath("./w:tc", namespaces=spec53.NS)
        if len(cells) != 5:
            raise RuntimeError("Unexpected Amendment History structure")
        for cell, value in zip(
            cells,
            (
                "v0.54",
                "Expanded Changing Home Create and Update request-body examples to match the New Licence form_data hierarchy; corrected GET request-example line breaks.",
                "5.1–5.5",
                "15 Sep 2026",
                "Gregory Lee",
            ),
        ):
            spec53.set_text(cell, value)
        table.append(row)
        return
    raise RuntimeError("Amendment History table not found")


def main() -> None:
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)
    with zipfile.ZipFile(SOURCE) as original:
        document = etree.fromstring(original.read("word/document.xml"))
        core = etree.fromstring(original.read("docProps/core.xml"))
        replace_request_examples(document)
        add_revision(document)
        # Keep the same document design while allowing longer JSON blocks to
        # paginate cleanly in the existing code-example tables.
        spec53.patch_layout(document)
        title = core.find("{http://purl.org/dc/elements/1.1/}title")
        if title is not None:
            title.text = (title.text or "").replace("v0.53", "v0.54")
        modified = core.find("{http://purl.org/dc/terms/}modified")
        if modified is not None:
            modified.text = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        revision = core.find(
            "{http://schemas.openxmlformats.org/package/2006/metadata/core-properties}revision"
        )
        if revision is not None and (revision.text or "").isdigit():
            revision.text = str(int(revision.text) + 1)
        OUTPUT.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(OUTPUT, "w") as final:
            for item in original.infolist():
                data = original.read(item.filename)
                if item.filename == "word/document.xml":
                    data = etree.tostring(
                        document, encoding="UTF-8", xml_declaration=True, standalone=True
                    )
                elif item.filename == "docProps/core.xml":
                    data = etree.tostring(
                        core, encoding="UTF-8", xml_declaration=True, standalone=True
                    )
                final.writestr(item, data)
    REPO_COPY.parent.mkdir(parents=True, exist_ok=True)
    REPO_COPY.write_bytes(OUTPUT.read_bytes())
    print(f"wrote {OUTPUT}")
    print(f"copied {REPO_COPY}")


if __name__ == "__main__":
    main()
