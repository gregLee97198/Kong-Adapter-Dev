#!/usr/bin/env python3
"""Patch enabled Create/Update Staging workflows: drop $eq OP, use $ne CMTF.

Does not rewrite workflow nodes. Only updates workflow.config.condition.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import NocoBaseApi
from workflow_source_condition import INTERNAL_SOURCE_SYSTEM, replace_op_eq_with_external


def list_workflows(api: NocoBaseApi) -> list[dict]:
    rows: list[dict] = []
    page = 1
    while True:
        data = api.request(
            "GET",
            "/api/workflows:list?"
            + urllib.parse.urlencode({"pageSize": 100, "page": page, "sort[]": "-id"}),
        )
        batch = data if isinstance(data, list) else []
        rows.extend(item for item in batch if isinstance(item, dict))
        if len(batch) < 100:
            break
        page += 1
    return rows


def is_staging_create_or_update(row: dict) -> bool:
    title = str(row.get("title") or "")
    config = row.get("config") or {}
    if config.get("collection") != "t_api_request_staging":
        return False
    if "API Request Staging" not in title:
        return False
    return any(token in title for token in ("Create", "Update", "Dispatch"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://119.91.104.211:13001/cmtf2")
    parser.add_argument("--token", default=os.environ.get("NOCOBASE_TOKEN", ""))
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    if not args.token:
        print("missing NOCOBASE_TOKEN", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, args.token)
    patched = 0
    skipped = 0
    for row in list_workflows(api):
        if not row.get("enabled") or not is_staging_create_or_update(row):
            continue
        config = dict(row.get("config") or {})
        original = config.get("condition")
        rewritten = replace_op_eq_with_external(original)
        if rewritten is None or rewritten == original:
            skipped += 1
            print(f"skip id={row.get('id')} title={row.get('title')}")
            continue
        print(
            f"{'apply' if args.apply else 'dry-run'} id={row.get('id')} "
            f"title={row.get('title')}"
        )
        print(f"  from={json.dumps(original, ensure_ascii=False)}")
        print(f"  to={json.dumps(rewritten, ensure_ascii=False)}")
        if args.apply:
            config["condition"] = rewritten
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={row['id']}",
                {"config": config},
            )
        patched += 1
    print(
        f"patched={patched} skipped={skipped} "
        f"internal_source={INTERNAL_SOURCE_SYSTEM} apply={args.apply}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
