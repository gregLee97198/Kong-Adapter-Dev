#!/usr/bin/env python3
"""Prepare and validate guarded Notice status workflows on NocoBase 13001.

The default commands are fail-closed and never enable a prepared candidate.
``activate`` is intentionally a separate, explicit command.  All
``validate-*`` commands are read-only: they issue GET requests only and never
repair metadata.

This script is restricted to the development NocoBase endpoint on port 13001.
It must be reviewed and migrated separately before production use.

Mutating commands are single-operator operations; do not run them concurrently
from multiple hosts.  If a crash or concurrent operator leaves duplicate
candidates, keep every candidate disabled, inspect executions, remove the
extra execution-free draft manually, and rerun ``prepare-*`` then
``validate-*`` before activation.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.parse
from collections import Counter
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError

BASE_URL = "http://119.91.104.211:13001/cmtf2"
NOTICE_COLLECTION = "t_notice_board"
NOTICE_TYPE_FIELD = "f_notice_type"
DEDUPE_FIELD = "f_dedupe_key"
DEDUPE_DESCRIPTION = "Stable Notice event dedupe key; non-empty values are unique."
STATUS_COLLECTION = "t_notice_board_status"

SENT_SOURCE_ID = 389126466895872
SENT_KEY = "75fzv69gij3"
SENT_SOURCE_TITLE = "API Notice — Sent Letter to Notice List v2"
SENT_DRAFT_TITLE = "API Notice — Sent Letter to Notice List v3"
SENT_PLAN_TITLE = "06 Build Staging-Optional Letter Notice"
SENT_CREATE_TITLE = "07 Create Notice Board Letter Record"
SENT_STATUS_QUERY_TITLE = "06A Resolve Letter Notice status by name"
SENT_STATUS_GUARD_TITLE = "06B Letter Notice status exists"

PN_TITLE = "API Notice — NLA P Number Generated v2"
PN_LEGACY_TITLE = "API Notice — NLA P Number Generated v1"
PN_RECEIVED_TITLE = "API Notice — NLA Received with Existing P Number v1"
PN_NOTICE_TYPE = "p_number_generated"
PN_NOTICE_LABEL = "P Number Generated"
PN_STATUS_NAME = "P_Number_Generated"
PN_SOURCE_WORKFLOW_ID = 373206148120576
PN_SOURCE_WORKFLOW_KEY = "ms1x4f3rd8e"


def sent_trigger_config() -> dict[str, Any]:
    return {
        "mode": 2,
        "appends": ["f_attachment", "f_home_record", "f_senduser"],
        "changed": ["f_sendtime"],
        "collection": "t_letter_attachment",
        "condition": {"$and": [{"f_sendtime": {"$notEmpty": True}}]},
    }


def p_number_trigger_config() -> dict[str, Any]:
    return {
        "mode": 2,
        "appends": [],
        "changed": ["f_p_no"],
        "collection": "t_licence_app",
        "condition": {"$and": [{"f_p_no": {"$notEmpty": True}}]},
    }


def received_p_number_trigger_config() -> dict[str, Any]:
    return {
        "mode": 2,
        "appends": [],
        "changed": ["f_application_status"],
        "collection": "t_api_request_staging",
        "condition": {
            "$and": [
                {"f_application_status": {"$eq": "Received"}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_application_type": {"$eq": "new_licence"}},
                {"f_application_id": {"$notEmpty": True}},
            ]
        },
    }


def validate_exact_collection_trigger(
    workflow: Mapping[str, Any],
    expected: Mapping[str, Any],
    *,
    error: str,
) -> None:
    """Reject widened triggers, including extra config keys."""
    if (
        workflow.get("type") != "collection"
        or workflow.get("sync") is not False
        or workflow.get("config") != expected
    ):
        raise ApiError(error)


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def ref(node: Mapping[str, Any], field: str) -> str:
    return "{{$jobsMapByNodeKey." + str(node["key"]) + "." + field + "}}"


def node_by_title(workflow: Mapping[str, Any], title: str) -> dict[str, Any]:
    rows = [
        dict(row) for row in workflow.get("nodes") or [] if row.get("title") == title
    ]
    if len(rows) != 1:
        raise ApiError(f"Expected one node {title!r}, found {len(rows)}")
    return rows[0]


def validate_node_types(
    workflow: Mapping[str, Any], expected: Mapping[str, str]
) -> None:
    for title, node_type in expected.items():
        node = node_by_title(workflow, title)
        if node.get("type") != node_type:
            raise ApiError(
                f"Node {title!r} has type {node.get('type')!r}, expected {node_type!r}"
            )


def create_node(
    api: RootNocoBaseApi,
    workflow_id: int,
    node_type: str,
    title: str,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    return dict(
        api.create_node(
            {
                "workflowId": workflow_id,
                "type": node_type,
                "title": title,
                "config": dict(config),
            }
        )
    )


def ensure_node(
    api: RootNocoBaseApi,
    workflow_id: int,
    node_type: str,
    title: str,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    """Create one missing node or reconcile the unique disabled node in place."""
    workflow = api.get_workflow(workflow_id)
    matches = [row for row in workflow.get("nodes") or [] if row.get("title") == title]
    if len(matches) > 1:
        raise ApiError(f"Duplicate workflow nodes found for {title!r}")
    if not matches:
        return create_node(api, workflow_id, node_type, title, config)
    node = dict(matches[0])
    if node.get("type") != node_type:
        raise ApiError(f"Node {title!r} has unexpected type {node.get('type')!r}")
    api.update_node(int(node["id"]), {"config": copy.deepcopy(dict(config))})
    node["config"] = copy.deepcopy(dict(config))
    return node


def link(
    api: RootNocoBaseApi,
    upstream: Mapping[str, Any],
    downstream: Mapping[str, Any],
    *,
    branch_index: int | None = None,
) -> None:
    if branch_index is None:
        api.update_node(int(upstream["id"]), {"downstreamId": downstream["id"]})
    api.update_node(
        int(downstream["id"]),
        {"upstreamId": upstream["id"], "branchIndex": branch_index},
    )


def query_config(
    collection: str,
    filters: list[dict[str, Any]],
    *,
    fail_on_empty: bool = False,
) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": False,
        "failOnEmpty": fail_on_empty,
        "params": {
            "filter": {"$and": filters},
            "page": 1,
            "pageSize": 2,
            "sort": [],
            "appends": [],
        },
    }


def exists_config(node: Mapping[str, Any], *, reject_on_false: bool) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject_on_false,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "gt", "operands": [ref(node, "id"), 0]}
                ],
            }
        },
    }


def missing_config(node: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "rejectOnFalse": False,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "equal", "operands": [ref(node, "id"), None]}
                ],
            }
        },
    }


def workflow_executions(api: RootNocoBaseApi, workflow_id: int) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode(
        {"pageSize": 2, "filter[workflowId]": str(workflow_id)}
    )
    return list(api.request("GET", "/api/executions:list?" + query) or [])


def status_row(api: RootNocoBaseApi, name: str) -> dict[str, Any]:
    query = urllib.parse.urlencode(
        {
            "pageSize": 10,
            "paginate": "false",
            "filter": json.dumps({"f_status": name}, separators=(",", ":")),
        }
    )
    rows = api.request("GET", f"/api/{STATUS_COLLECTION}:list?" + query) or []
    exact = [row for row in rows if row.get("f_status") == name]
    if len(exact) != 1 or exact[0].get("id") is None:
        raise ApiError(f"Expected exactly one Notice status {name!r}")
    return dict(exact[0])


def field_row(api: RootNocoBaseApi, name: str) -> dict[str, Any]:
    query = urllib.parse.urlencode({"filterByTk": name})
    row = api.request(
        "GET", f"/api/collections/{NOTICE_COLLECTION}/fields:get?" + query
    )
    if not isinstance(row, dict) or row.get("name") != name:
        raise ApiError(f"{NOTICE_COLLECTION}.{name} was not found")
    return dict(row)


def iter_notice_rows(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    """Read every Notice key before a unique constraint is requested."""
    page = 1
    result: list[dict[str, Any]] = []
    while True:
        query = urllib.parse.urlencode(
            {
                "page": page,
                "pageSize": 500,
                "fields[]": ["id", DEDUPE_FIELD],
                "sort[]": "id",
            },
            doseq=True,
        )
        rows = list(api.request("GET", f"/api/{NOTICE_COLLECTION}:list?" + query) or [])
        result.extend(dict(row) for row in rows)
        if len(rows) < 500:
            return result
        page += 1
        if page > 10000:
            raise ApiError("Notice duplicate scan exceeded the safety page limit")


def duplicate_dedupe_keys(api: RootNocoBaseApi) -> dict[str, list[Any]]:
    rows = iter_notice_rows(api)
    keys = [str(row[DEDUPE_FIELD]) for row in rows if row.get(DEDUPE_FIELD)]
    duplicated = {key for key, count in Counter(keys).items() if count > 1}
    return {
        key: [row.get("id") for row in rows if str(row.get(DEDUPE_FIELD)) == key]
        for key in sorted(duplicated)
    }


def validate_dedupe_constraint(api: RootNocoBaseApi) -> None:
    duplicates = duplicate_dedupe_keys(api)
    if duplicates:
        raise ApiError(f"Duplicate Notice dedupe keys exist: {duplicates}")
    field = field_row(api, DEDUPE_FIELD)
    if (
        field.get("unique") is not True
        or field.get("description") != DEDUPE_DESCRIPTION
        or (field.get("uiSchema") or {}).get("description") != DEDUPE_DESCRIPTION
    ):
        raise ApiError(
            f"{NOTICE_COLLECTION}.{DEDUPE_FIELD} unique metadata is incomplete"
        )


def ensure_dedupe_constraint(api: RootNocoBaseApi) -> bool:
    """Check duplicates first, then set and read back the unique constraint."""
    duplicates = duplicate_dedupe_keys(api)
    if duplicates:
        raise ApiError(f"Duplicate Notice dedupe keys exist: {duplicates}")
    field = field_row(api, DEDUPE_FIELD)
    ui_schema = copy.deepcopy(field.get("uiSchema") or {})
    changed = (
        field.get("unique") is not True
        or field.get("description") != DEDUPE_DESCRIPTION
        or ui_schema.get("description") != DEDUPE_DESCRIPTION
    )
    if changed:
        ui_schema["description"] = DEDUPE_DESCRIPTION
        query = urllib.parse.urlencode({"filterByTk": DEDUPE_FIELD})
        api.request(
            "POST",
            f"/api/collections/{NOTICE_COLLECTION}/fields:update?" + query,
            {
                "unique": True,
                "description": DEDUPE_DESCRIPTION,
                "uiSchema": ui_schema,
            },
        )
    readback = field_row(api, DEDUPE_FIELD)
    if (
        readback.get("unique") is not True
        or readback.get("description") != DEDUPE_DESCRIPTION
        or (readback.get("uiSchema") or {}).get("description") != DEDUPE_DESCRIPTION
    ):
        raise ApiError("Notice dedupe unique metadata read-back failed")
    if duplicate_dedupe_keys(api):
        raise ApiError("Notice dedupe keys changed during unique-constraint setup")
    return changed


def notice_type_options(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    return list(
        (field_row(api, NOTICE_TYPE_FIELD).get("uiSchema") or {}).get("enum") or []
    )


def validate_p_number_notice_type(api: RootNocoBaseApi) -> None:
    matches = [
        row for row in notice_type_options(api) if row.get("value") == PN_NOTICE_TYPE
    ]
    if matches != [{"value": PN_NOTICE_TYPE, "label": PN_NOTICE_LABEL}]:
        raise ApiError("P Number Notice Type enum is missing or conflicts")


def ensure_p_number_notice_type(api: RootNocoBaseApi) -> bool:
    field = field_row(api, NOTICE_TYPE_FIELD)
    schema = copy.deepcopy(field.get("uiSchema") or {})
    options = list(schema.get("enum") or [])
    matches = [row for row in options if row.get("value") == PN_NOTICE_TYPE]
    if matches:
        validate_p_number_notice_type(api)
        return False
    schema["enum"] = options + [{"value": PN_NOTICE_TYPE, "label": PN_NOTICE_LABEL}]
    query = urllib.parse.urlencode({"filterByTk": NOTICE_TYPE_FIELD})
    api.request(
        "POST",
        f"/api/collections/{NOTICE_COLLECTION}/fields:update?" + query,
        {"uiSchema": schema},
    )
    validate_p_number_notice_type(api)
    return True


def workflows_by_title(api: RootNocoBaseApi, title: str) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"pageSize": 100, "filter[title]": title})
    return [
        dict(row)
        for row in api.request("GET", "/api/workflows:list?" + query) or []
        if row.get("title") == title
    ]


def workflows_by_key(api: RootNocoBaseApi, key: str) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode({"pageSize": 100, "filter[key]": key})
    return [
        dict(row)
        for row in api.request("GET", "/api/workflows:list?" + query) or []
        if row.get("key") == key
    ]


def unique_workflow_by_title(api: RootNocoBaseApi, title: str) -> dict[str, Any] | None:
    rows = workflows_by_title(api, title)
    if len(rows) > 1:
        raise ApiError(f"More than one workflow is titled {title!r}")
    return api.get_workflow(int(rows[0]["id"])) if rows else None


def create_revision(
    api: RootNocoBaseApi, source_id: int, *, expected_key: str
) -> dict[str, Any]:
    source = api.get_workflow(source_id)
    if not source.get("enabled") or source.get("key") != expected_key:
        raise ApiError("Reviewed source workflow is not the current enabled revision")
    revision_id: int | None = None
    api.request(
        "POST", f"/api/workflows:update?filterByTk={source_id}", {"enabled": False}
    )
    try:
        query = urllib.parse.urlencode(
            {"filterByTk": source_id, "filter[key]": expected_key}
        )
        created = api.request("POST", "/api/workflows:revision?" + query, {})
        if not isinstance(created, dict) or not created.get("id"):
            raise ApiError("Workflow revision API returned no ID")
        revision_id = int(created["id"])
    finally:
        api.request(
            "POST", f"/api/workflows:update?filterByTk={source_id}", {"enabled": True}
        )
    if revision_id is None:
        raise ApiError("No workflow revision was created")
    draft = api.get_workflow(revision_id)
    if draft.get("enabled") or draft.get("key") != expected_key:
        raise ApiError("New revision is not a disabled same-key draft")
    return draft


def reconcile_sent(
    api: RootNocoBaseApi,
    workflow_id: int,
    *,
    source: Mapping[str, Any],
) -> dict[str, Any]:
    draft = api.get_workflow(workflow_id)
    validate_exact_collection_trigger(
        source,
        sent_trigger_config(),
        error="Sent Letter v2 trigger is not the reviewed field transition",
    )
    validate_exact_collection_trigger(
        draft,
        sent_trigger_config(),
        error="Sent Letter v3 trigger is not the reviewed field transition",
    )
    if draft.get("enabled"):
        raise ApiError("Refusing to mutate an enabled Sent Letter candidate")
    if draft.get("key") != SENT_KEY or workflow_executions(api, workflow_id):
        raise ApiError("Sent Letter recovery target is not a clean same-key draft")
    source_titles = {str(node.get("title")) for node in source.get("nodes") or []}
    allowed_titles = source_titles | {
        SENT_STATUS_QUERY_TITLE,
        SENT_STATUS_GUARD_TITLE,
    }
    draft_titles = {str(node.get("title")) for node in draft.get("nodes") or []}
    if unexpected := draft_titles - allowed_titles:
        raise ApiError(
            f"Sent Letter candidate has unexpected nodes: {sorted(unexpected)}"
        )
    if missing := source_titles - draft_titles:
        raise ApiError(f"Sent Letter candidate lost source nodes: {sorted(missing)}")

    plan_before = node_by_title(source, SENT_PLAN_TITLE)
    create_before = node_by_title(source, SENT_CREATE_TITLE)
    old_line = (
        "const noticeStatusId = type === 'a' ? 4 : type === 'b' ? 5 : "
        "['c','e','f'].includes(type) ? 7 : 2;"
    )
    plan_text = str((plan_before.get("config") or {}).get("content") or "")
    old_status = (
        ((create_before.get("config") or {}).get("params") or {}).get("values") or {}
    ).get("fk_status")
    if old_line not in plan_text or old_status != ref(plan_before, "noticeStatusId"):
        raise ApiError("Sent Letter v2 differs from the reviewed mapping")
    draft_id = int(draft["id"])
    plan = node_by_title(draft, SENT_PLAN_TITLE)
    create = node_by_title(draft, SENT_CREATE_TITLE)
    plan_config = copy.deepcopy(plan.get("config") or {})
    content = str(plan_config.get("content") or "")
    dynamic_line = (
        "const noticeStatusName = type === 'a' ? 'Acknowledged' "
        ": type === 'b' ? 'Confirmed' "
        ": ['c','e','f'].includes(type) ? 'Approved' : 'Received';"
    )
    if old_line in content:
        content = content.replace(old_line, dynamic_line, 1).replace(
            "  noticeStatusId,", "  noticeStatusName,", 1
        )
    elif dynamic_line not in content:
        raise ApiError("Sent Letter candidate has an unknown status mapping")
    if "noticeStatusId" in content or "noticeStatusName" not in content:
        raise ApiError("Sent Letter status-name rewrite failed closed")
    plan_config["content"] = content
    api.update_node(int(plan["id"]), {"config": plan_config})

    status = ensure_node(
        api,
        draft_id,
        "query",
        SENT_STATUS_QUERY_TITLE,
        query_config(
            STATUS_COLLECTION,
            [{"f_status": {"$eq": ref(plan, "noticeStatusName")}}],
        ),
    )
    guard = ensure_node(
        api,
        draft_id,
        "condition",
        SENT_STATUS_GUARD_TITLE,
        exists_config(status, reject_on_false=True),
    )
    create_config = copy.deepcopy(create.get("config") or {})
    values = copy.deepcopy((create_config.get("params") or {}).get("values") or {})
    values["fk_status"] = ref(status, "id")
    create_config.setdefault("params", {})["values"] = values
    api.update_node(int(create["id"]), {"config": create_config})
    link(api, plan, status)
    link(api, status, guard)
    link(api, guard, create, branch_index=1)
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={draft_id}",
        {"title": SENT_DRAFT_TITLE},
    )
    checked = api.get_workflow(draft_id)
    validate_sent(api, checked)
    return checked


def prepare_sent(api: RootNocoBaseApi) -> dict[str, Any]:
    source = api.get_workflow(SENT_SOURCE_ID)
    validate_exact_collection_trigger(
        source,
        sent_trigger_config(),
        error="Sent Letter v2 trigger is not the reviewed field transition",
    )
    if source.get("title") != SENT_SOURCE_TITLE or len(source.get("nodes") or []) != 7:
        raise ApiError("Sent Letter source differs from the reviewed seven-node v2")
    existing = unique_workflow_by_title(api, SENT_DRAFT_TITLE)
    recoverable: list[dict[str, Any]] = []
    if existing is not None:
        validate_exact_collection_trigger(
            existing,
            sent_trigger_config(),
            error="Sent Letter v3 trigger is not the reviewed field transition",
        )
    else:
        recoverable = [
            row
            for row in workflows_by_key(api, SENT_KEY)
            if int(row["id"]) > SENT_SOURCE_ID and not row.get("enabled")
        ]
        if len(recoverable) > 1:
            raise ApiError("More than one interrupted Sent Letter revision exists")
        if recoverable:
            validate_exact_collection_trigger(
                recoverable[0],
                sent_trigger_config(),
                error="Sent Letter v3 trigger is not the reviewed field transition",
            )

    ensure_dedupe_constraint(api)
    if existing is not None:
        if existing.get("enabled"):
            validate_sent(api, existing)
            return existing
        try:
            checked = reconcile_sent(api, int(existing["id"]), source=source)
        finally:
            restore_sent_source_after_interruption(api, source)
        return checked

    if recoverable:
        try:
            checked = reconcile_sent(api, int(recoverable[0]["id"]), source=source)
        finally:
            restore_sent_source_after_interruption(api, source)
        return checked

    if not source.get("enabled"):
        restore_sent_source_after_interruption(api, source)
    draft = create_revision(api, SENT_SOURCE_ID, expected_key=SENT_KEY)
    return reconcile_sent(api, int(draft["id"]), source=source)


def restore_sent_source_after_interruption(
    api: RootNocoBaseApi, source: Mapping[str, Any]
) -> None:
    """Restore the reviewed v2 only when a prior prepare died while it was off."""
    if source.get("enabled"):
        return
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={SENT_SOURCE_ID}",
        {"enabled": True},
    )
    restored = api.get_workflow(SENT_SOURCE_ID)
    if not restored.get("enabled"):
        raise ApiError("Interrupted Sent Letter source could not be restored")


def validate_sent(api: RootNocoBaseApi, workflow: Mapping[str, Any]) -> None:
    """Read-only structural and dictionary validation for Sent Letter v3."""
    validate_exact_collection_trigger(
        workflow,
        sent_trigger_config(),
        error="Sent Letter v3 trigger is not the reviewed field transition",
    )
    if workflow.get("key") != SENT_KEY or workflow.get("title") != SENT_DRAFT_TITLE:
        raise ApiError("Sent Letter v3 identity is unexpected")
    if len(workflow.get("nodes") or []) != 9:
        raise ApiError("Sent Letter v3 node count is unexpected")
    validate_node_types(
        workflow,
        {
            SENT_PLAN_TITLE: "script",
            SENT_STATUS_QUERY_TITLE: "query",
            SENT_STATUS_GUARD_TITLE: "condition",
            SENT_CREATE_TITLE: "create",
        },
    )
    plan = node_by_title(workflow, SENT_PLAN_TITLE)
    status = node_by_title(workflow, SENT_STATUS_QUERY_TITLE)
    guard = node_by_title(workflow, SENT_STATUS_GUARD_TITLE)
    create = node_by_title(workflow, SENT_CREATE_TITLE)
    content = str((plan.get("config") or {}).get("content") or "")
    values = ((create.get("config") or {}).get("params") or {}).get("values") or {}
    filters = ((status.get("config") or {}).get("params") or {}).get("filter") or {}
    mapping_markers = (
        "type === 'a' ? 'Acknowledged'",
        "type === 'b' ? 'Confirmed'",
        "['c','e','f'].includes(type) ? 'Approved' : 'Received'",
    )
    if (
        not all(marker in content for marker in mapping_markers)
        or "noticeStatusId" in content
        or status.get("upstreamId") != plan.get("id")
        or guard.get("upstreamId") != status.get("id")
        or create.get("upstreamId") != guard.get("id")
        or create.get("branchIndex") != 1
        or values.get("fk_status") != ref(status, "id")
        or filters != {"$and": [{"f_status": {"$eq": ref(plan, "noticeStatusName")}}]}
    ):
        raise ApiError("Sent Letter dynamic status chain validation failed")
    for name in ("Acknowledged", "Confirmed", "Approved", "Received"):
        status_row(api, name)
    validate_dedupe_constraint(api)


def p_number_trigger_script() -> str:
    return """
const applicationId = contextData && contextData.id == null
  ? '' : String(contextData.id);
const pNumber = contextData && contextData.f_p_no == null
  ? '' : String(contextData.f_p_no).trim();
if (!applicationId || !pNumber)
  throw new Error('P Number trigger identity is incomplete');
return {applicationId, pNumber};
""".strip()


def p_number_plan_script() -> str:
    return """
const pNumber = contextData && contextData.f_p_no == null
  ? '' : String(contextData.f_p_no).trim();
const rchNo = home && home.f_rch_no != null
  ? String(home.f_rch_no).trim() || null : null;
const homeRchName = home && home.f_rch_name_en != null
  ? String(home.f_rch_name_en).trim() : '';
const applicationRchName = contextData && contextData.f_rch_name_en == null
  ? '' : String(contextData.f_rch_name_en).trim();
const rchName = homeRchName || applicationRchName;
const stagingId = staging && staging.id == null ? '' : String(staging.id);
const statusId = status && status.id == null ? '' : String(status.id);
if (!pNumber || !stagingId || !statusId)
  throw new Error('P Number Notice source resolution incomplete');
return {
  eventCode: 'P_NUMBER_GENERATED',
  sourceEventId: ['nla','p-number',stagingId].join(':'),
  businessId: String(contextData.id),
  businessReference: pNumber,
  rchNo,
  rchName,
  statusName: 'P_Number_Generated',
  title: 'P Number generated — ' + pNumber,
  content: 'P Number ' + pNumber + ' was generated.',
  dedupeKey: ['nla','p-number',stagingId,statusId].join(':'),
  snapshot: {
    sourceWorkflowId: 373206148120576,
    sourceWorkflowKey: 'ms1x4f3rd8e',
    apiRequestStagingId: staging.id,
    pNumber,
    rchName,
    attachmentIds: [],
  },
};
""".strip()


def received_staging_trigger_script() -> str:
    return """
const stagingId = contextData && contextData.id == null
  ? '' : String(contextData.id);
const applicationId = contextData && contextData.f_application_id == null
  ? '' : String(contextData.f_application_id);
const applicationStatus = contextData && contextData.f_application_status == null
  ? '' : String(contextData.f_application_status);
if (!stagingId || !applicationId || applicationStatus !== 'Received')
  throw new Error('Received NLA CREATE staging identity is incomplete');
return {stagingId, applicationId};
""".strip()


def received_p_number_plan_script() -> str:
    return """
const pNumber = application && application.f_p_no == null
  ? '' : String(application.f_p_no).trim();
const rchNo = home && home.f_rch_no != null
  ? String(home.f_rch_no).trim() || null : null;
const homeRchName = home && home.f_rch_name_en != null
  ? String(home.f_rch_name_en).trim() : '';
const applicationRchName = application && application.f_rch_name_en == null
  ? '' : String(application.f_rch_name_en).trim();
const rchName = homeRchName || applicationRchName;
const stagingId = staging && staging.id == null ? '' : String(staging.id);
const statusId = status && status.id == null ? '' : String(status.id);
if (!pNumber || !stagingId || !statusId)
  throw new Error('Received P Number Notice source resolution incomplete');
return {
  eventCode: 'P_NUMBER_GENERATED',
  sourceEventId: ['nla','p-number',stagingId].join(':'),
  businessId: String(application.id),
  businessReference: pNumber,
  rchNo,
  rchName,
  statusName: 'P_Number_Generated',
  title: 'P Number generated — ' + pNumber,
  content: 'P Number ' + pNumber + ' was generated.',
  dedupeKey: ['nla','p-number',stagingId,statusId].join(':'),
  snapshot: {
    sourceWorkflowId: 373206148120576,
    sourceWorkflowKey: 'ms1x4f3rd8e',
    apiRequestStagingId: staging.id,
    pNumber,
    rchName,
    attachmentIds: [],
  },
};
""".strip()


def p_number_staging_filters(normalize: Mapping[str, Any]) -> list[dict[str, Any]]:
    return [
        {"f_application_id": {"$eq": ref(normalize, "applicationId")}},
        {"f_request_event": {"$eq": "CREATE"}},
        {"f_application_type": {"$eq": "new_licence"}},
        {"f_application_status": {"$eq": "Received"}},
    ]


def p_number_update_config(
    staging: Mapping[str, Any], normalize: Mapping[str, Any]
) -> dict[str, Any]:
    return {
        "collection": "t_api_request_staging",
        "params": {
            "individualHooks": True,
            "filter": {
                "$and": [
                    {"id": {"$eq": ref(staging, "id")}},
                    {"f_request_event": {"$eq": "CREATE"}},
                    {"f_application_type": {"$eq": "new_licence"}},
                    {"f_application_id": {"$eq": ref(normalize, "applicationId")}},
                    {"f_application_status": {"$eq": "Received"}},
                ]
            },
            "values": {"f_application_status": PN_STATUS_NAME},
            "appends": [],
        },
    }


def received_p_number_update_config(
    normalize: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "collection": "t_api_request_staging",
        "params": {
            "individualHooks": True,
            "filter": {
                "$and": [
                    {"id": {"$eq": ref(normalize, "stagingId")}},
                    {"f_request_event": {"$eq": "CREATE"}},
                    {"f_application_type": {"$eq": "new_licence"}},
                    {"f_application_id": {"$eq": ref(normalize, "applicationId")}},
                    {"f_application_status": {"$eq": "Received"}},
                ]
            },
            "values": {"f_application_status": PN_STATUS_NAME},
            "appends": [],
        },
    }


def reconcile_p_number(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    workflow = api.get_workflow(workflow_id)
    validate_exact_collection_trigger(
        workflow,
        p_number_trigger_config(),
        error="P Number trigger is not the reviewed field transition",
    )
    if workflow.get("enabled"):
        raise ApiError("Refusing to mutate an enabled P Number candidate")
    if workflow_executions(api, workflow_id):
        raise ApiError("Refusing to reconcile a candidate that has executions")
    allowed_titles = {
        "00 Normalize P Number trigger",
        "01 Resolve Received NLA CREATE staging",
        "02 Received NLA CREATE staging exists",
        "03 Resolve P_Number_Generated status by name",
        "04 P_Number_Generated status exists",
        "04A Resolve Home Record by final P Number",
        "05 Build P Number Notice",
        "06 Check unique P Number dedupe key",
        "07 Persist P Number status once",
        "08 Resolve NLA Intake",
        "09 NLA Intake exists",
        "10 Create P Number Notice without attachments",
        "11 Publish P_Number_Generated from Received",
        "12 Reconcile existing P Number Notice from Received",
    }
    unexpected = {
        str(node.get("title")) for node in workflow.get("nodes") or []
    } - allowed_titles
    if unexpected:
        raise ApiError(f"P Number candidate has unexpected nodes: {sorted(unexpected)}")

    normalize = ensure_node(
        api,
        workflow_id,
        "script",
        "00 Normalize P Number trigger",
        {
            "arguments": [{"name": "contextData", "value": "{{$context.data}}"}],
            "content": p_number_trigger_script(),
            "timeout": 5000,
            "continue": False,
        },
    )
    staging = ensure_node(
        api,
        workflow_id,
        "query",
        "01 Resolve Received NLA CREATE staging",
        query_config("t_api_request_staging", p_number_staging_filters(normalize)),
    )
    staging_exists = ensure_node(
        api,
        workflow_id,
        "condition",
        "02 Received NLA CREATE staging exists",
        exists_config(staging, reject_on_false=False),
    )
    status = ensure_node(
        api,
        workflow_id,
        "query",
        "03 Resolve P_Number_Generated status by name",
        query_config(STATUS_COLLECTION, [{"f_status": {"$eq": PN_STATUS_NAME}}]),
    )
    status_exists = ensure_node(
        api,
        workflow_id,
        "condition",
        "04 P_Number_Generated status exists",
        exists_config(status, reject_on_false=True),
    )
    home = ensure_node(
        api,
        workflow_id,
        "query",
        "04A Resolve Home Record by final P Number",
        query_config(
            "t_home_record",
            [{"f_final_o_no": {"$eq": ref(normalize, "pNumber")}}],
        ),
    )
    plan = ensure_node(
        api,
        workflow_id,
        "script",
        "05 Build P Number Notice",
        {
            "arguments": [
                {"name": "contextData", "value": "{{$context.data}}"},
                {
                    "name": "staging",
                    "value": "{{$jobsMapByNodeKey." + staging["key"] + "}}",
                },
                {
                    "name": "status",
                    "value": "{{$jobsMapByNodeKey." + status["key"] + "}}",
                },
                {
                    "name": "home",
                    "value": "{{$jobsMapByNodeKey." + home["key"] + "}}",
                },
            ],
            "content": p_number_plan_script(),
            "timeout": 5000,
            "continue": False,
        },
    )
    existing_notice = ensure_node(
        api,
        workflow_id,
        "query",
        "06 Check unique P Number dedupe key",
        query_config(
            NOTICE_COLLECTION, [{DEDUPE_FIELD: {"$eq": ref(plan, "dedupeKey")}}]
        ),
    )
    first = ensure_node(
        api,
        workflow_id,
        "condition",
        "07 Persist P Number status once",
        missing_config(existing_notice),
    )
    intake = ensure_node(
        api,
        workflow_id,
        "query",
        "08 Resolve NLA Intake",
        query_config("t_intake_form", [{"id": {"$eq": ref(staging, "f_intake_id")}}]),
    )
    intake_exists = ensure_node(
        api,
        workflow_id,
        "condition",
        "09 NLA Intake exists",
        exists_config(intake, reject_on_false=True),
    )
    notice = ensure_node(
        api,
        workflow_id,
        "create",
        "10 Create P Number Notice without attachments",
        {
            "collection": NOTICE_COLLECTION,
            "params": {
                "values": {
                    "f_third_party_name": "OP",
                    "f_notice_type": PN_NOTICE_TYPE,
                    "fk_status": ref(status, "id"),
                    "f_api_request": ref(staging, "id"),
                    "f_intake_type": ref(intake, "fk_intake_type"),
                    "f_event_code": ref(plan, "eventCode"),
                    "f_event_type": "status_change",
                    "f_source_event_id": ref(plan, "sourceEventId"),
                    "f_source_collection": "t_licence_app",
                    "f_source_record_id": context("id"),
                    "f_business_type_code": "t_licence_app",
                    "f_business_record_id": ref(plan, "businessId"),
                    "f_business_reference": ref(plan, "businessReference"),
                    "f_rch_no": ref(plan, "rchNo"),
                    "f_rch_name": ref(plan, "rchName"),
                    "f_business_status_code": PN_STATUS_NAME,
                    "f_business_status_name": PN_STATUS_NAME,
                    "f_status_phrase": PN_STATUS_NAME,
                    "f_source_workflow_key": PN_SOURCE_WORKFLOW_KEY,
                    "f_source_workflow_node": "New Lic App Create P No.",
                    "f_process_action": "Generate P Number",
                    "f_process_status": PN_STATUS_NAME,
                    "f_channels": ["record_only"],
                    "f_notify_rank_groups": [],
                    "f_recipient_snapshot": ref(plan, "snapshot"),
                    "f_title": ref(plan, "title"),
                    "f_content": ref(plan, "content"),
                    "f_dispatch_status": "recorded",
                    "f_dispatch_attempts": 0,
                    "f_external_targets": [],
                    DEDUPE_FIELD: ref(plan, "dedupeKey"),
                    "f_status_updated_at": "{{$system.now}}",
                },
                "appends": [],
            },
        },
    )
    publish_config = p_number_update_config(staging, normalize)
    publish = ensure_node(
        api,
        workflow_id,
        "update",
        "11 Publish P_Number_Generated from Received",
        publish_config,
    )
    reconcile = ensure_node(
        api,
        workflow_id,
        "update",
        "12 Reconcile existing P Number Notice from Received",
        copy.deepcopy(publish_config),
    )

    link(api, normalize, staging)
    link(api, staging, staging_exists)
    link(api, staging_exists, status, branch_index=1)
    link(api, status, status_exists)
    link(api, status_exists, home, branch_index=1)
    link(api, home, plan)
    link(api, plan, existing_notice)
    link(api, existing_notice, first)
    link(api, first, intake, branch_index=1)
    link(api, first, reconcile, branch_index=0)
    link(api, intake, intake_exists)
    link(api, intake_exists, notice, branch_index=1)
    link(api, notice, publish)
    checked = api.get_workflow(workflow_id)
    validate_p_number(api, checked)
    return checked


def prepare_p_number(api: RootNocoBaseApi) -> dict[str, Any]:
    source = api.get_workflow(PN_SOURCE_WORKFLOW_ID)
    source_values = (
        (node_by_title(source, "更新数据").get("config") or {}).get("params") or {}
    ).get("values") or {}
    if (
        not source.get("enabled")
        or source.get("key") != PN_SOURCE_WORKFLOW_KEY
        or source_values.get("f_p_no") is None
    ):
        raise ApiError("Reviewed P Number business source is no longer current")
    existing = unique_workflow_by_title(api, PN_TITLE)
    if existing is not None:
        validate_exact_collection_trigger(
            existing,
            p_number_trigger_config(),
            error="P Number trigger is not the reviewed field transition",
        )
    status_row(api, PN_STATUS_NAME)
    ensure_p_number_notice_type(api)
    ensure_dedupe_constraint(api)

    if existing is not None:
        if existing.get("enabled"):
            validate_p_number(api, existing)
            return existing
        return reconcile_p_number(api, int(existing["id"]))

    created = api.request(
        "POST",
        "/api/workflows:create",
        {
            "title": PN_TITLE,
            "type": "collection",
            "sync": False,
            "enabled": False,
            "config": p_number_trigger_config(),
        },
    )
    if not isinstance(created, dict) or created.get("id") is None:
        raise ApiError("P Number workflow creation returned no ID")
    return reconcile_p_number(api, int(created["id"]))


def validate_p_number(api: RootNocoBaseApi, workflow: Mapping[str, Any]) -> None:
    """Pure read-only validation of the P Number workflow and prerequisites."""
    if workflow.get("title") != PN_TITLE:
        raise ApiError("P Number workflow title is unexpected")
    validate_exact_collection_trigger(
        workflow,
        p_number_trigger_config(),
        error="P Number trigger is not the reviewed field transition",
    )
    if len(workflow.get("nodes") or []) != 14:
        raise ApiError("P Number workflow node count is unexpected")
    validate_node_types(
        workflow,
        {
            "00 Normalize P Number trigger": "script",
            "01 Resolve Received NLA CREATE staging": "query",
            "02 Received NLA CREATE staging exists": "condition",
            "03 Resolve P_Number_Generated status by name": "query",
            "04 P_Number_Generated status exists": "condition",
            "04A Resolve Home Record by final P Number": "query",
            "05 Build P Number Notice": "script",
            "06 Check unique P Number dedupe key": "query",
            "07 Persist P Number status once": "condition",
            "08 Resolve NLA Intake": "query",
            "09 NLA Intake exists": "condition",
            "10 Create P Number Notice without attachments": "create",
            "11 Publish P_Number_Generated from Received": "update",
            "12 Reconcile existing P Number Notice from Received": "update",
        },
    )

    normalize = node_by_title(workflow, "00 Normalize P Number trigger")
    staging = node_by_title(workflow, "01 Resolve Received NLA CREATE staging")
    staging_exists = node_by_title(workflow, "02 Received NLA CREATE staging exists")
    status = node_by_title(workflow, "03 Resolve P_Number_Generated status by name")
    status_exists = node_by_title(workflow, "04 P_Number_Generated status exists")
    home = node_by_title(workflow, "04A Resolve Home Record by final P Number")
    plan = node_by_title(workflow, "05 Build P Number Notice")
    existing = node_by_title(workflow, "06 Check unique P Number dedupe key")
    first = node_by_title(workflow, "07 Persist P Number status once")
    intake = node_by_title(workflow, "08 Resolve NLA Intake")
    intake_exists = node_by_title(workflow, "09 NLA Intake exists")
    notice = node_by_title(workflow, "10 Create P Number Notice without attachments")
    publish = node_by_title(workflow, "11 Publish P_Number_Generated from Received")
    reconcile = node_by_title(
        workflow, "12 Reconcile existing P Number Notice from Received"
    )

    staging_filters = ((staging.get("config") or {}).get("params") or {}).get(
        "filter"
    ) or {}
    status_filters = ((status.get("config") or {}).get("params") or {}).get(
        "filter"
    ) or {}
    home_filters = ((home.get("config") or {}).get("params") or {}).get("filter") or {}
    dedupe_filters = ((existing.get("config") or {}).get("params") or {}).get(
        "filter"
    ) or {}
    values = ((notice.get("config") or {}).get("params") or {}).get("values") or {}
    publish_params = (publish.get("config") or {}).get("params") or {}
    reconcile_params = (reconcile.get("config") or {}).get("params") or {}
    expected_update = p_number_update_config(staging, normalize)["params"]
    forbidden = {"f_letter_attachment", "fk_letter_attachment"} & set(values)
    if (
        staging_filters != {"$and": p_number_staging_filters(normalize)}
        or staging.get("upstreamId") != normalize.get("id")
        or staging_exists.get("upstreamId") != staging.get("id")
        or (staging_exists.get("config") or {})
        != exists_config(staging, reject_on_false=False)
        or status_filters != {"$and": [{"f_status": {"$eq": PN_STATUS_NAME}}]}
        or status.get("upstreamId") != staging_exists.get("id")
        or status.get("branchIndex") != 1
        or status_exists.get("upstreamId") != status.get("id")
        or (status_exists.get("config") or {})
        != exists_config(status, reject_on_false=True)
        or home.get("upstreamId") != status_exists.get("id")
        or home.get("branchIndex") != 1
        or home_filters
        != {"$and": [{"f_final_o_no": {"$eq": ref(normalize, "pNumber")}}]}
        or plan.get("upstreamId") != home.get("id")
        or existing.get("upstreamId") != plan.get("id")
        or dedupe_filters != {"$and": [{DEDUPE_FIELD: {"$eq": ref(plan, "dedupeKey")}}]}
        or first.get("upstreamId") != existing.get("id")
        or (first.get("config") or {}) != missing_config(existing)
        or intake.get("upstreamId") != first.get("id")
        or intake.get("branchIndex") != 1
        or intake_exists.get("upstreamId") != intake.get("id")
        or (intake_exists.get("config") or {})
        != exists_config(intake, reject_on_false=True)
        or notice.get("upstreamId") != intake_exists.get("id")
        or notice.get("branchIndex") != 1
        or values.get("fk_status") != ref(status, "id")
        or values.get("f_api_request") != ref(staging, "id")
        or values.get("f_notice_type") != PN_NOTICE_TYPE
        or values.get("f_rch_no") != ref(plan, "rchNo")
        or values.get("f_rch_name") != ref(plan, "rchName")
        or values.get(DEDUPE_FIELD) != ref(plan, "dedupeKey")
        or values.get("f_channels") != ["record_only"]
        or values.get("f_external_targets") != []
        or forbidden
        or publish.get("upstreamId") != notice.get("id")
        or publish_params != expected_update
        or reconcile.get("upstreamId") != first.get("id")
        or reconcile.get("branchIndex") != 0
        or reconcile_params != expected_update
    ):
        raise ApiError("P Number workflow safety validation failed")
    content = str((plan.get("config") or {}).get("content") or "")
    if not all(
        marker in content
        for marker in (
            "attachmentIds: []",
            "const rchNo = home",
            "applicationRchName",
            "dedupeKey",
        )
    ):
        raise ApiError("P Number Notice plan is incomplete")
    status_row(api, PN_STATUS_NAME)
    validate_p_number_notice_type(api)
    validate_dedupe_constraint(api)


def reconcile_received_p_number(
    api: RootNocoBaseApi, workflow_id: int
) -> dict[str, Any]:
    workflow = api.get_workflow(workflow_id)
    validate_exact_collection_trigger(
        workflow,
        received_p_number_trigger_config(),
        error="Received/P Number trigger is not fail-closed",
    )
    if workflow.get("enabled"):
        raise ApiError("Refusing to mutate an enabled Received/P Number candidate")
    if workflow_executions(api, workflow_id):
        raise ApiError("Refusing to reconcile a candidate that has executions")
    allowed_titles = {
        "00 Normalize Received NLA CREATE staging",
        "01 Resolve NLA with an existing P Number",
        "02 Existing P Number application found",
        "03 Resolve P_Number_Generated status by name",
        "04 P_Number_Generated status exists",
        "04A Resolve Home Record by final P Number",
        "05 Build Received P Number Notice",
        "06 Check shared P Number dedupe key",
        "07 Persist Received P Number status once",
        "08 Resolve NLA Intake",
        "09 NLA Intake exists",
        "10 Create Received P Number Notice without attachments",
        "11 Publish P_Number_Generated from Received",
        "12 Reconcile existing P Number Notice from Received",
    }
    unexpected = {
        str(node.get("title")) for node in workflow.get("nodes") or []
    } - allowed_titles
    if unexpected:
        raise ApiError(
            f"Received/P Number candidate has unexpected nodes: {sorted(unexpected)}"
        )

    normalize = ensure_node(
        api,
        workflow_id,
        "script",
        "00 Normalize Received NLA CREATE staging",
        {
            "arguments": [{"name": "contextData", "value": "{{$context.data}}"}],
            "content": received_staging_trigger_script(),
            "timeout": 5000,
            "continue": False,
        },
    )
    application = ensure_node(
        api,
        workflow_id,
        "query",
        "01 Resolve NLA with an existing P Number",
        query_config(
            "t_licence_app",
            [
                {"id": {"$eq": ref(normalize, "applicationId")}},
                {"f_p_no": {"$notEmpty": True}},
            ],
        ),
    )
    application_exists = ensure_node(
        api,
        workflow_id,
        "condition",
        "02 Existing P Number application found",
        exists_config(application, reject_on_false=False),
    )
    status = ensure_node(
        api,
        workflow_id,
        "query",
        "03 Resolve P_Number_Generated status by name",
        query_config(STATUS_COLLECTION, [{"f_status": {"$eq": PN_STATUS_NAME}}]),
    )
    status_exists = ensure_node(
        api,
        workflow_id,
        "condition",
        "04 P_Number_Generated status exists",
        exists_config(status, reject_on_false=True),
    )
    home = ensure_node(
        api,
        workflow_id,
        "query",
        "04A Resolve Home Record by final P Number",
        query_config(
            "t_home_record",
            [{"f_final_o_no": {"$eq": ref(application, "f_p_no")}}],
        ),
    )
    plan = ensure_node(
        api,
        workflow_id,
        "script",
        "05 Build Received P Number Notice",
        {
            "arguments": [
                {"name": "staging", "value": "{{$context.data}}"},
                {
                    "name": "application",
                    "value": "{{$jobsMapByNodeKey." + application["key"] + "}}",
                },
                {
                    "name": "status",
                    "value": "{{$jobsMapByNodeKey." + status["key"] + "}}",
                },
                {
                    "name": "home",
                    "value": "{{$jobsMapByNodeKey." + home["key"] + "}}",
                },
            ],
            "content": received_p_number_plan_script(),
            "timeout": 5000,
            "continue": False,
        },
    )
    existing_notice = ensure_node(
        api,
        workflow_id,
        "query",
        "06 Check shared P Number dedupe key",
        query_config(
            NOTICE_COLLECTION, [{DEDUPE_FIELD: {"$eq": ref(plan, "dedupeKey")}}]
        ),
    )
    first = ensure_node(
        api,
        workflow_id,
        "condition",
        "07 Persist Received P Number status once",
        missing_config(existing_notice),
    )
    intake = ensure_node(
        api,
        workflow_id,
        "query",
        "08 Resolve NLA Intake",
        query_config("t_intake_form", [{"id": {"$eq": context("f_intake_id")}}]),
    )
    intake_exists = ensure_node(
        api,
        workflow_id,
        "condition",
        "09 NLA Intake exists",
        exists_config(intake, reject_on_false=True),
    )
    notice = ensure_node(
        api,
        workflow_id,
        "create",
        "10 Create Received P Number Notice without attachments",
        {
            "collection": NOTICE_COLLECTION,
            "params": {
                "values": {
                    "f_third_party_name": "OP",
                    "f_notice_type": PN_NOTICE_TYPE,
                    "fk_status": ref(status, "id"),
                    "f_api_request": context("id"),
                    "f_intake_type": ref(intake, "fk_intake_type"),
                    "f_event_code": ref(plan, "eventCode"),
                    "f_event_type": "status_change",
                    "f_source_event_id": ref(plan, "sourceEventId"),
                    "f_source_collection": "t_licence_app",
                    "f_source_record_id": ref(application, "id"),
                    "f_business_type_code": "t_licence_app",
                    "f_business_record_id": ref(plan, "businessId"),
                    "f_business_reference": ref(plan, "businessReference"),
                    "f_rch_no": ref(plan, "rchNo"),
                    "f_rch_name": ref(plan, "rchName"),
                    "f_business_status_code": PN_STATUS_NAME,
                    "f_business_status_name": PN_STATUS_NAME,
                    "f_status_phrase": PN_STATUS_NAME,
                    "f_source_workflow_key": PN_SOURCE_WORKFLOW_KEY,
                    "f_source_workflow_node": "New Lic App Create P No.",
                    "f_process_action": "Generate P Number",
                    "f_process_status": PN_STATUS_NAME,
                    "f_channels": ["record_only"],
                    "f_notify_rank_groups": [],
                    "f_recipient_snapshot": ref(plan, "snapshot"),
                    "f_title": ref(plan, "title"),
                    "f_content": ref(plan, "content"),
                    "f_dispatch_status": "recorded",
                    "f_dispatch_attempts": 0,
                    "f_external_targets": [],
                    DEDUPE_FIELD: ref(plan, "dedupeKey"),
                    "f_status_updated_at": "{{$system.now}}",
                },
                "appends": [],
            },
        },
    )
    # Both entry workflows intentionally use the same database-unique dedupe key.
    # NocoBase has no reviewed error branch for a create-node uniqueness failure,
    # so a simultaneous loser stops here without publishing the status; the winner
    # creates the sole Notice and performs the guarded Received -> Generated update.
    update_config = received_p_number_update_config(normalize)
    publish = ensure_node(
        api,
        workflow_id,
        "update",
        "11 Publish P_Number_Generated from Received",
        update_config,
    )
    reconcile = ensure_node(
        api,
        workflow_id,
        "update",
        "12 Reconcile existing P Number Notice from Received",
        copy.deepcopy(update_config),
    )

    link(api, normalize, application)
    link(api, application, application_exists)
    link(api, application_exists, status, branch_index=1)
    link(api, status, status_exists)
    link(api, status_exists, home, branch_index=1)
    link(api, home, plan)
    link(api, plan, existing_notice)
    link(api, existing_notice, first)
    link(api, first, intake, branch_index=1)
    link(api, first, reconcile, branch_index=0)
    link(api, intake, intake_exists)
    link(api, intake_exists, notice, branch_index=1)
    link(api, notice, publish)
    checked = api.get_workflow(workflow_id)
    validate_received_p_number(api, checked)
    return checked


def prepare_received_p_number(api: RootNocoBaseApi) -> dict[str, Any]:
    existing = unique_workflow_by_title(api, PN_RECEIVED_TITLE)
    if existing is not None:
        validate_exact_collection_trigger(
            existing,
            received_p_number_trigger_config(),
            error="Received/P Number trigger is not fail-closed",
        )
    status_row(api, PN_STATUS_NAME)
    ensure_p_number_notice_type(api)
    ensure_dedupe_constraint(api)
    if existing is not None:
        if existing.get("enabled"):
            validate_received_p_number(api, existing)
            return existing
        return reconcile_received_p_number(api, int(existing["id"]))
    created = api.request(
        "POST",
        "/api/workflows:create",
        {
            "title": PN_RECEIVED_TITLE,
            "type": "collection",
            "sync": False,
            "enabled": False,
            "config": received_p_number_trigger_config(),
        },
    )
    if not isinstance(created, dict) or created.get("id") is None:
        raise ApiError("Received/P Number workflow creation returned no ID")
    return reconcile_received_p_number(api, int(created["id"]))


def validate_received_p_number(
    api: RootNocoBaseApi, workflow: Mapping[str, Any]
) -> None:
    """Read-only validation for the Received-after-P-Number race reconciler."""
    if workflow.get("title") != PN_RECEIVED_TITLE:
        raise ApiError("Received/P Number workflow title is unexpected")
    validate_exact_collection_trigger(
        workflow,
        received_p_number_trigger_config(),
        error="Received/P Number trigger is not fail-closed",
    )
    if len(workflow.get("nodes") or []) != 14:
        raise ApiError("Received/P Number trigger is not fail-closed")
    validate_node_types(
        workflow,
        {
            "00 Normalize Received NLA CREATE staging": "script",
            "01 Resolve NLA with an existing P Number": "query",
            "02 Existing P Number application found": "condition",
            "03 Resolve P_Number_Generated status by name": "query",
            "04 P_Number_Generated status exists": "condition",
            "04A Resolve Home Record by final P Number": "query",
            "05 Build Received P Number Notice": "script",
            "06 Check shared P Number dedupe key": "query",
            "07 Persist Received P Number status once": "condition",
            "08 Resolve NLA Intake": "query",
            "09 NLA Intake exists": "condition",
            "10 Create Received P Number Notice without attachments": "create",
            "11 Publish P_Number_Generated from Received": "update",
            "12 Reconcile existing P Number Notice from Received": "update",
        },
    )

    normalize = node_by_title(workflow, "00 Normalize Received NLA CREATE staging")
    application = node_by_title(workflow, "01 Resolve NLA with an existing P Number")
    application_exists = node_by_title(
        workflow, "02 Existing P Number application found"
    )
    status = node_by_title(workflow, "03 Resolve P_Number_Generated status by name")
    status_exists = node_by_title(workflow, "04 P_Number_Generated status exists")
    home = node_by_title(workflow, "04A Resolve Home Record by final P Number")
    plan = node_by_title(workflow, "05 Build Received P Number Notice")
    existing = node_by_title(workflow, "06 Check shared P Number dedupe key")
    first = node_by_title(workflow, "07 Persist Received P Number status once")
    intake = node_by_title(workflow, "08 Resolve NLA Intake")
    intake_exists = node_by_title(workflow, "09 NLA Intake exists")
    notice = node_by_title(
        workflow, "10 Create Received P Number Notice without attachments"
    )
    publish = node_by_title(workflow, "11 Publish P_Number_Generated from Received")
    reconcile = node_by_title(
        workflow, "12 Reconcile existing P Number Notice from Received"
    )
    app_filters = ((application.get("config") or {}).get("params") or {}).get(
        "filter"
    ) or {}
    status_filters = ((status.get("config") or {}).get("params") or {}).get(
        "filter"
    ) or {}
    home_filters = ((home.get("config") or {}).get("params") or {}).get("filter") or {}
    dedupe_filters = ((existing.get("config") or {}).get("params") or {}).get(
        "filter"
    ) or {}
    values = ((notice.get("config") or {}).get("params") or {}).get("values") or {}
    publish_params = (publish.get("config") or {}).get("params") or {}
    expected_update = received_p_number_update_config(normalize)["params"]
    content = str((plan.get("config") or {}).get("content") or "")
    if (
        app_filters
        != {
            "$and": [
                {"id": {"$eq": ref(normalize, "applicationId")}},
                {"f_p_no": {"$notEmpty": True}},
            ]
        }
        or application.get("upstreamId") != normalize.get("id")
        or application_exists.get("upstreamId") != application.get("id")
        or (application_exists.get("config") or {})
        != exists_config(application, reject_on_false=False)
        or status_filters != {"$and": [{"f_status": {"$eq": PN_STATUS_NAME}}]}
        or status.get("upstreamId") != application_exists.get("id")
        or status.get("branchIndex") != 1
        or status_exists.get("upstreamId") != status.get("id")
        or (status_exists.get("config") or {})
        != exists_config(status, reject_on_false=True)
        or home.get("upstreamId") != status_exists.get("id")
        or home.get("branchIndex") != 1
        or home_filters
        != {"$and": [{"f_final_o_no": {"$eq": ref(application, "f_p_no")}}]}
        or plan.get("upstreamId") != home.get("id")
        or existing.get("upstreamId") != plan.get("id")
        or dedupe_filters != {"$and": [{DEDUPE_FIELD: {"$eq": ref(plan, "dedupeKey")}}]}
        or first.get("upstreamId") != existing.get("id")
        or (first.get("config") or {}) != missing_config(existing)
        or intake.get("upstreamId") != first.get("id")
        or intake.get("branchIndex") != 1
        or intake_exists.get("upstreamId") != intake.get("id")
        or (intake_exists.get("config") or {})
        != exists_config(intake, reject_on_false=True)
        or notice.get("upstreamId") != intake_exists.get("id")
        or notice.get("branchIndex") != 1
        or values.get("f_api_request") != context("id")
        or values.get("f_source_record_id") != ref(application, "id")
        or values.get("f_rch_no") != ref(plan, "rchNo")
        or values.get("f_rch_name") != ref(plan, "rchName")
        or values.get(DEDUPE_FIELD) != ref(plan, "dedupeKey")
        or publish.get("upstreamId") != notice.get("id")
        or publish_params != expected_update
        or reconcile.get("upstreamId") != first.get("id")
        or reconcile.get("branchIndex") != 0
        or (reconcile.get("config") or {}).get("params") != expected_update
        or "['nla','p-number',stagingId,statusId].join(':')" not in content
        or "const rchNo = home" not in content
        or "applicationRchName" not in content
        or "attachmentIds: []" not in content
    ):
        raise ApiError("Received/P Number workflow safety validation failed")
    status_row(api, PN_STATUS_NAME)
    validate_p_number_notice_type(api)
    validate_dedupe_constraint(api)


def activate(api: RootNocoBaseApi, workflow_id: int, *, kind: str) -> dict[str, Any]:
    candidate = api.get_workflow(workflow_id)
    same_title = workflows_by_title(api, str(candidate.get("title") or ""))
    if [int(row["id"]) for row in same_title] != [workflow_id]:
        raise ApiError("Activation requires exactly one candidate with this title")
    if candidate.get("enabled"):
        raise ApiError("Candidate is already enabled; activation is not a no-op")
    if workflow_executions(api, workflow_id):
        raise ApiError("Candidate already has executions")
    if kind == "sent":
        validate_sent(api, candidate)
        old_id: int | None = SENT_SOURCE_ID
    elif kind == "p-number":
        validate_p_number(api, candidate)
        legacy = [
            row
            for row in workflows_by_title(api, PN_LEGACY_TITLE)
            if row.get("enabled")
        ]
        if len(legacy) > 1:
            raise ApiError("More than one legacy P Number workflow is enabled")
        old_id = int(legacy[0]["id"]) if legacy else None
    elif kind == "p-number-on-received":
        validate_received_p_number(api, candidate)
        primary = [
            row for row in workflows_by_title(api, PN_TITLE) if row.get("enabled")
        ]
        if len(primary) != 1:
            raise ApiError(
                "Enable exactly one guarded P Number v2 workflow before the "
                "Received reconciler"
            )
        validate_p_number(api, api.get_workflow(int(primary[0]["id"])))
        old_id = None
    else:
        raise ApiError("Unknown activation kind")

    if old_id is not None:
        api.request(
            "POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": False}
        )
    try:
        api.request(
            "POST", f"/api/workflows:update?filterByTk={workflow_id}", {"enabled": True}
        )
        enabled = api.get_workflow(workflow_id)
        if not enabled.get("enabled"):
            raise ApiError("Candidate did not enable")
        return enabled
    except Exception:
        try:
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={workflow_id}",
                {"enabled": False},
            )
        finally:
            if old_id is not None:
                api.request(
                    "POST",
                    f"/api/workflows:update?filterByTk={old_id}",
                    {"enabled": True},
                )
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default=BASE_URL)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("audit")
    sub.add_parser("prepare-sent")
    sub.add_parser("prepare-p-number")
    sub.add_parser("prepare-p-number-on-received")
    for command in (
        "validate-sent",
        "validate-p-number",
        "validate-p-number-on-received",
        "activate-sent",
        "activate-p-number",
        "activate-p-number-on-received",
    ):
        item = sub.add_parser(command)
        item.add_argument("workflow_id", type=int)
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    if args.base_url.rstrip("/") != BASE_URL:
        raise ApiError("This deployment tool is restricted to NocoBase 13001")
    api = RootNocoBaseApi(args.base_url, token)

    if args.command == "audit":
        print(f"sent_v3_candidates={len(workflows_by_title(api, SENT_DRAFT_TITLE))}")
        print(f"p_number_v2_candidates={len(workflows_by_title(api, PN_TITLE))}")
        print(
            "p_number_on_received_candidates="
            f"{len(workflows_by_title(api, PN_RECEIVED_TITLE))}"
        )
        print(f"duplicate_dedupe_keys={len(duplicate_dedupe_keys(api))}")
        dedupe_field = field_row(api, DEDUPE_FIELD)
        unique = dedupe_field.get("unique") is True
        description_ok = (
            dedupe_field.get("description") == DEDUPE_DESCRIPTION
            and (dedupe_field.get("uiSchema") or {}).get("description")
            == DEDUPE_DESCRIPTION
        )
        print(f"dedupe_unique={str(unique).lower()}")
        print(f"dedupe_description_ok={str(description_ok).lower()}")
        return 0
    if args.command == "prepare-sent":
        result = prepare_sent(api)
    elif args.command == "prepare-p-number":
        result = prepare_p_number(api)
    elif args.command == "prepare-p-number-on-received":
        result = prepare_received_p_number(api)
    else:
        result = api.get_workflow(args.workflow_id)
        if args.command == "validate-sent":
            validate_sent(api, result)
        elif args.command == "validate-p-number":
            validate_p_number(api, result)
        elif args.command == "validate-p-number-on-received":
            validate_received_p_number(api, result)
        elif args.command == "activate-sent":
            result = activate(api, args.workflow_id, kind="sent")
        elif args.command == "activate-p-number":
            result = activate(api, args.workflow_id, kind="p-number")
        elif args.command == "activate-p-number-on-received":
            result = activate(api, args.workflow_id, kind="p-number-on-received")
        else:  # pragma: no cover
            raise ApiError("Unhandled command")
    enabled = str(bool(result.get("enabled"))).lower()
    print(
        f"workflow_id={result['id']} enabled={enabled} "
        f"nodes={len(result.get('nodes') or [])}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
