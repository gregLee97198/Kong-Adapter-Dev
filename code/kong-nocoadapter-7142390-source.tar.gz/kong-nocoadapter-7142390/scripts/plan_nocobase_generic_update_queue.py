#!/usr/bin/env python3
"""Offline plan for one v0.8.1 CREATE/UPDATE Staging ingress.

This planner has no API client and never changes NocoBase.  It extends the
shared CREATE blueprint with all *public* UPDATE pairs, but is not an
installer.  In particular, every UPDATE child still needs a separately
verified same-key worker revision, and every CREATE child needs a proven
success-only FIFO pump.  The active NLA parent must not be replaced by the
older CREATE-only plan.
"""

from __future__ import annotations

import copy
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from plan_nocobase_shared_create_dispatch import (
    CLAIM_FIELD,
    CLAIMED_AT_FIELD,
    COLLECTION,
    PUBLIC_CREATE_FAMILIES,
    ROUTE_FIELD,
    SOURCE,
    CreateFamily,
    SharedCreatePlanError,
    _eq,
    _ref,
    _sql_text,
    _sql_tuple,
    _tuple_condition,
)
from plan_nocobase_shared_create_dispatch import (
    parent_nodes as create_parent_nodes,
)
from update_queue_contract import ATOMIC_FIFO_DISPATCH_SQL


@dataclass(frozen=True)
class UpdateFamily:
    create: CreateFamily
    update_api_type: str
    update_route: str
    requires_intake: bool = True

    @property
    def name(self) -> str:
        return self.create.name

    @property
    def application_type(self) -> str:
        return self.create.application_type


# This list deliberately excludes old Revoke and Prosecution routes.  Keep it
# separate from the public CREATE catalogue so an API rename is reviewed, not
# silently derived from a URL or a client-provided request body.
_UPDATE_API_BY_NAME = {
    "new_licence": "update_new_licence_data",
    "changing_home": "update_changing_home_data",
    "licence_renewal": "update_licence_renewal_data",
    "expansion_aip": "update_expansion_aip_data",
    "specific_hour": "update_specific_hour_data",
    "responsible_person": "update_rp_data",
    "self_withdraw": "update_self_withdraw_data",
    "change_home_manager": "update_change_home_manager_data",
    "change_beds": "update_change_beds_data",
    "change_operation_mode": "update_change_operation_mode_data",
    "change_directors": "update_change_directors_data",
    "change_nurse_in_charge": "update_change_nurse_in_charge_data",
}
PUBLIC_UPDATE_FAMILIES: tuple[UpdateFamily, ...] = tuple(
    UpdateFamily(
        create=family,
        update_api_type=_UPDATE_API_BY_NAME[family.name],
        update_route=(
            "nla_update" if family.name == "new_licence" else f"{family.name}_update"
        ),
        requires_intake=family.name != "licence_renewal",
    )
    for family in PUBLIC_CREATE_FAMILIES
)


def _event_tuple(family: UpdateFamily, event: str, status: str) -> dict[str, Any]:
    api_type = family.create.api_type if event == "CREATE" else family.update_api_type
    clauses = [
        _eq("f_request_event", event),
        _eq("f_api_type", api_type),
        _eq("f_status", status),
    ]
    if event == "UPDATE":
        clauses += [
            _eq("f_queue_counted", True),
            {"f_active_update_id": {"$notEmpty": True}},
        ]
    return {"$and": clauses}


def parent_trigger_config() -> dict[str, Any]:
    """One dispatcher for ingress and completion-driven FIFO wake-ups.

    A Create completion is observed twice by the same collection listener:
    first when the Create row becomes ``succeeded`` and again whenever a
    finished child UPDATE releases the Create row's active reservation.  The
    latter event changes ``f_active_update_id``.  This avoids one timer per
    application type and leaves the native business workflows unchanged.
    """
    family_conditions = [
        {
            "$and": [
                _eq("f_application_type", family.application_type),
                {
                    "$or": [
                        _event_tuple(family, "CREATE", "submitted"),
                        _event_tuple(family, "CREATE", "succeeded"),
                        _event_tuple(family, "UPDATE", "queued"),
                        _event_tuple(family, "UPDATE", "submitted"),
                    ]
                },
            ]
        }
        for family in PUBLIC_UPDATE_FAMILIES
    ]
    return {
        "mode": 3,
        "collection": COLLECTION,
        "appends": [],
        "changed": ["f_status", "f_active_update_id"],
        "condition": {
            "$and": [
                _eq("f_source_system", SOURCE),
                {"$or": family_conditions},
            ]
        },
    }


def legacy_parent_trigger_config() -> dict[str, Any]:
    """The 56-node candidate trigger retained only for safe in-place upgrade.

    This is not an alternate runtime plan.  It identifies the disabled
    candidate that was prepared before the completion-driven pump was added,
    so that it can be extended without creating another workflow revision.
    """
    config = copy.deepcopy(parent_trigger_config())
    config["changed"] = ["f_status"]
    for family_arm in config["condition"]["$and"][1]["$or"]:
        tuples = family_arm["$and"][1]["$or"]
        family_arm["$and"][1]["$or"] = [
            item
            for item in tuples
            if not (
                item.get("$and", [{}])[0] == _eq("f_request_event", "CREATE")
                and item.get("$and", [{}])[-1] == _eq("f_status", "succeeded")
            )
        ]
    return config


def _replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise SharedCreatePlanError("FIFO SQL source changed; manual review required")
    return text.replace(old, new, 1)


def generic_fifo_dispatch_sql() -> str:
    """Reuse child-first atomic FIFO SQL with a server-pinned family mapping.

    The one SQL invocation is scoped to one exact CREATE ID.  It can reserve
    at most the oldest counted UPDATE child of that CREATE, not a collection
    of applications.  Its CAS/lock order comes from the proven NLA contract.
    """
    values = ",\n       ".join(
        "("
        + ", ".join(
            _sql_text(value)
            for value in (
                family.application_type,
                family.create.api_type,
                family.update_api_type,
            )
        )
        + ")"
        for family in PUBLIC_UPDATE_FAMILIES
    )
    sql = _replace_once(
        ATOMIC_FIFO_DISPATCH_SQL,
        "WITH parent_guard AS MATERIALIZED (",
        "WITH contract(application_type, create_api_type, update_api_type) "
        "AS MATERIALIZED (\n  SELECT approved.application_type, "
        "approved.create_api_type, approved.update_api_type\n"
        "  FROM (VALUES\n       " + values + "\n  ) AS "
        "approved(application_type, create_api_type, update_api_type)\n"
        "  WHERE approved.application_type = :applicationType\n), "
        "parent_guard AS MATERIALIZED (",
    )
    sql = _replace_once(
        sql,
        'FROM "t_api_request_staging" AS parent\n  WHERE',
        'FROM "t_api_request_staging" AS parent\n'
        '  JOIN contract ON contract.application_type = parent."f_application_type"\n'
        "  WHERE",
    )
    sql = _replace_once(
        sql,
        'parent."f_api_type" = :createApiType',
        'parent."f_api_type" = contract.create_api_type',
    )
    sql = _replace_once(
        sql,
        'staged."f_api_type" = :updateApiType',
        'staged."f_api_type" = (SELECT update_api_type FROM contract)',
    )
    # The original NLA SQL lists historical applications.  The exact VALUES
    # contract above is the only allowed catalogue for this public revision.
    sql = _replace_once(
        sql,
        """    AND parent."f_application_type" IN (
      'new_licence', 'changing_home', 'self_withdraw', 'revoke_licence',
      'specific_hour', 'responsible_person', 'change_home_manager',
      'change_beds', 'change_operation_mode', 'change_directors',
      'change_nurse_in_charge', 'prosecution', 'expansion_aip',
      'licence_renewal'
    )
""",
        "",
    )
    return sql


def _update_sql_tuple(family: UpdateFamily) -> str:
    """Exact submitted UPDATE route, including the reserved CREATE slot."""
    parent = family.create
    intake_guard = (
        'AND parent."f_intake_id" IS NOT NULL' if family.requires_intake else ""
    )
    guards = [
        f'staged."f_source_system" = {_sql_text(SOURCE)}',
        "staged.\"f_request_event\" = 'UPDATE'",
        f'staged."f_api_type" = {_sql_text(family.update_api_type)}',
        f'staged."f_application_type" = {_sql_text(family.application_type)}',
        'staged."f_queue_counted" IS TRUE',
        'staged."f_queue_sequence" IS NOT NULL',
        'staged."f_active_update_id" IS NOT NULL',
        'staged."f_queue_phase" IS NULL',
        'COALESCE(staged."f_attempt_count", 0) > 0',
        f'''EXISTS (
         SELECT 1 FROM "{COLLECTION}" AS parent
         WHERE CAST(parent."id" AS text) = staged."f_parent_create_id"
           AND parent."f_source_system" = {_sql_text(SOURCE)}
           AND parent."f_request_event" = 'CREATE'
           AND parent."f_api_type" = {_sql_text(parent.api_type)}
           AND parent."f_application_type" = {_sql_text(family.application_type)}
           AND parent."f_application_status" = 'Accepted'
           AND parent."f_status" = 'succeeded'
           AND parent."f_application_id" IS NOT NULL
           {intake_guard}
           AND parent."f_active_update_id" = staged."f_active_update_id"
       )''',
    ]
    return " AND ".join(guards)


def submitted_claim_sql() -> str:
    """Single exact-ID CAS for the 12 CREATE plus 12 reserved UPDATE routes."""
    cases = [
        f"      WHEN ({_sql_tuple(family.create)}) "
        f"THEN {_sql_text(family.create.route)}"
        for family in PUBLIC_UPDATE_FAMILIES
    ] + [
        f"      WHEN ({_update_sql_tuple(family)}) "
        f"THEN {_sql_text(family.update_route)}"
        for family in PUBLIC_UPDATE_FAMILIES
    ]
    where = "\n      OR ".join(
        [
            *(f"({_sql_tuple(family.create)})" for family in PUBLIC_UPDATE_FAMILIES),
            *(f"({_update_sql_tuple(family)})" for family in PUBLIC_UPDATE_FAMILIES),
        ]
    )
    return f'''WITH eligible AS MATERIALIZED (
  SELECT staged."id",
         CASE
{chr(10).join(cases)}
         END AS route
  FROM "{COLLECTION}" AS staged
  WHERE staged."id" = :stagingId
    AND staged."f_status" = 'submitted'
    AND staged."{CLAIM_FIELD}" IS NULL
    AND staged."{ROUTE_FIELD}" IS NULL
    AND (
      {where}
    )
  FOR UPDATE OF staged SKIP LOCKED
)
UPDATE "{COLLECTION}" AS staged
SET "{CLAIM_FIELD}" = eligible.route,
    "{CLAIMED_AT_FIELD}" = NOW()
FROM eligible
WHERE staged."id" = eligible."id"
  AND eligible.route IS NOT NULL
  AND staged."{CLAIM_FIELD}" IS NULL
  AND staged."{ROUTE_FIELD}" IS NULL
RETURNING staged."id", staged."{CLAIM_FIELD}";'''


def _submitted_update_condition(family: UpdateFamily) -> dict[str, Any]:
    return {
        "$and": [
            _eq("f_source_system", SOURCE),
            _eq("f_request_event", "UPDATE"),
            _eq("f_api_type", family.update_api_type),
            _eq("f_application_type", family.application_type),
            _eq("f_queue_counted", True),
            {"f_active_update_id": {"$notEmpty": True}},
        ]
    }


def _update_wake_filter(family: UpdateFamily) -> dict[str, Any]:
    return {
        "$and": [
            {"id": {"$eq": "{{$context.data.id}}"}},
            *_submitted_update_condition(family)["$and"],
            _eq("f_status", "submitted"),
            _eq(CLAIM_FIELD, family.update_route),
            {ROUTE_FIELD: {"$empty": True}},
        ]
    }


def update_child_trigger_config(family: UpdateFamily) -> dict[str, Any]:
    """Existing UPDATE business graph is awakened by route marker only."""
    if family not in PUBLIC_UPDATE_FAMILIES:
        raise SharedCreatePlanError("Unapproved UPDATE child family")
    return {
        "mode": 2,
        "collection": COLLECTION,
        "appends": [],
        "changed": [ROUTE_FIELD],
        "condition": {
            "$and": [
                *_submitted_update_condition(family)["$and"],
                _eq("f_status", "submitted"),
                _eq(CLAIM_FIELD, family.update_route),
                _eq(ROUTE_FIELD, family.update_route),
            ]
        },
    }


def _sql_config(sql: str, variables: dict[str, str]) -> dict[str, Any]:
    return {
        "dataSource": "main",
        "sql": sql,
        "variables": [
            {"name": name, "value": value} for name, value in variables.items()
        ],
        "withMeta": False,
        "unsafeInjection": False,
    }


def _pump_nodes(
    prefix: str,
    *,
    create_id: str,
    application_type: str,
    upstream: str,
    branch: int | None = None,
) -> list[dict[str, Any]]:
    sql_key, map_key, gate_key = (f"{prefix}_sql", f"{prefix}_map", f"{prefix}_gate")
    return [
        {
            "key": sql_key,
            "type": "sql",
            "title": "Reserve one oldest UPDATE for this CREATE",
            "upstream": upstream,
            "branch": branch,
            "config": _sql_config(
                generic_fifo_dispatch_sql(),
                {
                    "createId": create_id,
                    "sourceSystem": SOURCE,
                    "applicationType": application_type,
                },
            ),
        },
        {
            "key": map_key,
            "type": "json-variable-mapping",
            "title": "Read exact FIFO reservation",
            "upstream": sql_key,
            "branch": None,
            "config": {
                "parseArray": True,
                "dataSource": "{{$jobsMapByNodeKey." + sql_key + "}}",
                "variables": [
                    {
                        "key": "next_id",
                        "path": "0.id",
                        "name": "next_id",
                        "paths": ["0", "id"],
                    },
                    {
                        "key": "next_reservation",
                        "path": "0.f_active_update_id",
                        "name": "next_reservation",
                        "paths": ["0", "f_active_update_id"],
                    },
                    {
                        "key": "next_parent",
                        "path": "0.f_parent_create_id",
                        "name": "next_parent",
                        "paths": ["0", "f_parent_create_id"],
                    },
                ],
                "example": [
                    {
                        "id": 1,
                        "f_active_update_id": "reservation",
                        "f_parent_create_id": "2",
                    }
                ],
            },
        },
        {
            "key": gate_key,
            "type": "condition",
            "title": "Stop when no exact UPDATE was reserved",
            "upstream": map_key,
            "branch": None,
            "config": {
                "rejectOnFalse": False,
                "engine": "basic",
                "calculation": {
                    "group": {
                        "type": "and",
                        "calculations": [
                            {
                                "calculator": "gt",
                                "operands": [_ref(map_key, "next_id"), 0],
                            }
                        ],
                    }
                },
            },
        },
        {
            "key": f"{prefix}_wake",
            "type": "update",
            "title": "ORM wake exactly one reserved UPDATE",
            "upstream": gate_key,
            "branch": 1,
            "config": {
                "collection": COLLECTION,
                "params": {
                    "individualHooks": True,
                    "filter": {
                        "$and": [
                            {"id": {"$eq": _ref(map_key, "next_id")}},
                            _eq("f_parent_create_id", _ref(map_key, "next_parent")),
                            _eq("f_status", "queued"),
                            _eq("f_queue_counted", True),
                            _eq(
                                "f_active_update_id", _ref(map_key, "next_reservation")
                            ),
                        ]
                    },
                    "values": {"f_status": "submitted"},
                    "appends": [],
                },
            },
        },
    ]


def parent_nodes() -> list[dict[str, Any]]:
    """Completion pump, queued pump, then one exact submitted route chain."""
    base = copy.deepcopy(create_parent_nodes(PUBLIC_CREATE_FAMILIES))
    base[0]["config"]["sql"] = submitted_claim_sql()
    base[0]["upstream"] = "generic_is_queued_update"
    base[0]["branch"] = 0
    base[1]["config"]["params"]["filter"]["$and"][-1] = {
        "$or": [
            *[_tuple_condition(family.create) for family in PUBLIC_UPDATE_FAMILIES],
            *[_submitted_update_condition(family) for family in PUBLIC_UPDATE_FAMILIES],
        ]
    }
    first = {
        "key": "generic_is_queued_update",
        "type": "condition",
        "title": "Only queued UPDATE enters FIFO Pump",
        "upstream": "generic_is_create_completion",
        "branch": 0,
        "config": {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": ["{{$context.data.f_status}}", "queued"],
                        },
                        {
                            "calculator": "equal",
                            "operands": ["{{$context.data.f_request_event}}", "UPDATE"],
                        },
                    ],
                }
            },
        },
    }
    completion = {
        "key": "generic_is_create_completion",
        "type": "condition",
        "title": "Only released OP CREATE enters completion FIFO Pump",
        "upstream": None,
        "branch": None,
        "config": {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [
                                "{{$context.data.f_request_event}}", "CREATE"
                            ],
                        },
                        {
                            "calculator": "equal",
                            "operands": [
                                "{{$context.data.f_status}}", "succeeded"
                            ],
                        },
                        {
                            "calculator": "equal",
                            "operands": [
                                "{{$context.data.f_active_update_id}}", None
                            ],
                        },
                    ],
                }
            },
        },
    }
    nodes = [
        completion,
        *_pump_nodes(
            "generic_create_completion_pump",
            create_id="{{$context.data.id}}",
            application_type="{{$context.data.f_application_type}}",
            upstream=completion["key"],
            branch=1,
        ),
        first,
        *_pump_nodes(
            "generic_parent_pump",
            create_id="{{$context.data.f_parent_create_id}}",
            application_type="{{$context.data.f_application_type}}",
            upstream=first["key"],
            branch=1,
        ),
        *base,
    ]
    previous = f"shared_create_is_{PUBLIC_UPDATE_FAMILIES[-1].name}"
    for family in PUBLIC_UPDATE_FAMILIES:
        key = f"generic_is_{family.name}_update"
        nodes.append(
            {
                "key": key,
                "type": "condition",
                "title": f"Match reserved {family.name} UPDATE",
                "upstream": previous,
                "branch": 0,
                "config": {
                    "rejectOnFalse": False,
                    "engine": "basic",
                    "calculation": {
                        "group": {
                            "type": "and",
                            "calculations": [
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", "f_source_system"),
                                        SOURCE,
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", "f_request_event"),
                                        "UPDATE",
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", "f_api_type"),
                                        family.update_api_type,
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref(
                                            "shared_create_read", "f_application_type"
                                        ),
                                        family.application_type,
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", CLAIM_FIELD),
                                        family.update_route,
                                    ],
                                },
                            ],
                        }
                    },
                },
            }
        )
        nodes.append(
            {
                "key": f"generic_wake_{family.name}_update",
                "type": "update",
                "title": f"Wake {family.name} UPDATE via ORM marker",
                "upstream": key,
                "branch": 1,
                "config": {
                    "collection": COLLECTION,
                    "params": {
                        "individualHooks": True,
                        "filter": _update_wake_filter(family),
                        "values": {ROUTE_FIELD: family.update_route},
                        "appends": [],
                    },
                },
            }
        )
        previous = key
    return nodes


def legacy_parent_nodes() -> list[dict[str, Any]]:
    """Return the original 56-node blueprint for disabled-candidate audit."""
    nodes = copy.deepcopy(parent_nodes())
    completion_keys = {
        "generic_is_create_completion",
        "generic_create_completion_pump_sql",
        "generic_create_completion_pump_map",
        "generic_create_completion_pump_gate",
        "generic_create_completion_pump_wake",
    }
    nodes = [node for node in nodes if node["key"] not in completion_keys]
    root = next(node for node in nodes if node["key"] == "generic_is_queued_update")
    root["upstream"] = None
    root["branch"] = None
    if len(nodes) != 56:
        raise SharedCreatePlanError("legacy dispatcher blueprint count drifted")
    return nodes


def create_success_pump(
    family: UpdateFamily, success_node_key: str
) -> list[dict[str, Any]]:
    """Append only after that family's verified succeeded+IDs terminal node."""
    if family not in PUBLIC_UPDATE_FAMILIES or not success_node_key:
        raise SharedCreatePlanError("Unknown family or unverified success anchor")
    return _pump_nodes(
        f"generic_{family.name}_create_success_pump",
        create_id="{{$context.data.id}}",
        application_type=family.application_type,
        upstream=success_node_key,
    )


def validate_plan() -> dict[str, Any]:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from app.update_queue_service import PUBLIC_UPDATE_QUEUE_TYPES

    if (
        len(PUBLIC_UPDATE_FAMILIES) != 12
        or {family.application_type for family in PUBLIC_UPDATE_FAMILIES}
        != PUBLIC_UPDATE_QUEUE_TYPES
        or len({family.update_api_type for family in PUBLIC_UPDATE_FAMILIES}) != 12
        or len({family.update_route for family in PUBLIC_UPDATE_FAMILIES}) != 12
    ):
        raise SharedCreatePlanError("Public queue catalogue drifted")
    config = parent_trigger_config()
    nodes = parent_nodes()
    sql = generic_fifo_dispatch_sql()
    if config["changed"] != ["f_status", "f_active_update_id"] or config["mode"] != 3:
        raise SharedCreatePlanError("Parent event guard drifted")
    if len(config["condition"]["$and"][1]["$or"]) != 12:
        raise SharedCreatePlanError("Trigger outer OR exceeds planned catalogue")
    if len(nodes) != 61 or len({node["key"] for node in nodes}) != len(nodes):
        raise SharedCreatePlanError("Shared graph keys/count drifted")
    if any(node["type"] == "subflow" for node in nodes):
        raise SharedCreatePlanError("Async collection subflow is unproven")
    if (
        sql.count("FOR UPDATE OF staged SKIP LOCKED") != 1
        or 'FROM "t_api_request_staging" AS staged\n  JOIN parent_guard' not in sql
        or "parent.\"f_status\" = 'succeeded'" not in sql
        or "parent.\"f_application_status\" = 'Accepted'" not in sql
        or 'parent."f_active_update_id" IS NULL' not in sql
        or "revoke_licence" in sql
        or "prosecution" in sql
    ):
        raise SharedCreatePlanError("Generic FIFO scope/fence drifted")
    claim = next(
        node["config"]["sql"]
        for node in nodes
        if node["key"] == "shared_create_claim"
    )
    if (
        claim.count("WHEN (") != 24
        or claim.count("FOR UPDATE OF staged SKIP LOCKED") != 1
    ):
        raise SharedCreatePlanError("Submitted claim is not exact-ID 24-way")
    return {
        "writes": False,
        "activation": False,
        "target_environment": "13001 after isolated revision checks",
        "family_count": 12,
        "parent_event_tuple_count": 48,
        "outer_or_arms": 12,
        "changed": config["changed"],
        "parent_node_count": len(nodes),
        "one_fifo_reservation_per_event": True,
        "completion_pump": "one shared Create-row listener; no worker graft",
        "nla_queue_source": "retain active NLA pilot until same-key cutover",
        "trigger_or_limit": (
            "unverified on 13001; disabled revision readback and "
            "one-event pilot required"
        ),
    }


if __name__ == "__main__":
    print(json.dumps(validate_plan(), sort_keys=True))
