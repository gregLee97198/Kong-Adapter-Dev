#!/usr/bin/env python3
"""Plan two disabled Q3 Custom Actions; no live NocoBase I/O."""

from __future__ import annotations

import hashlib
import re
from typing import Any

from update_queue_contract import (
    ATOMIC_ADMIT_PENDING_SQL,
    ATOMIC_FIFO_DISPATCH_SQL,
    ATOMIC_REJECT_UNADMITTED_SQL,
)

COLLECTION = "t_api_request_staging"
# Historical title of the already-installed, disabled Q3 action.  Its SQL
# must be revised under the SAME workflow key before activation: it now only
# increments the parent count and marks the child counted.  A subsequent ORM
# update, not this SQL node, changes f_status to queued and wakes Collection
# Events.  Retain this title to address the exact disabled source revision.
ADMISSION_TITLE = "Q3 UPDATE Admission — guarded pending to queued"
REJECTION_TITLE = "Q3 UPDATE Rejection — Received won before admission"
DISPATCH_TITLE = "Q3 UPDATE FIFO Dispatch — guarded queued to submitted"

# This is a server-owned mapping.  Never take CREATE/UPDATE API types from a
# client body or a mutable Staging field when deciding which family to run.
FAMILY_APIS = {
    "new_licence": (
        "create_intake_for_new_licence", "update_new_licence_data"
    ),
    "changing_home": (
        "create_intake_for_changing_home", "update_changing_home_data"
    ),
    "self_withdraw": (
        "create_intake_for_self_withdraw", "update_self_withdraw_data"
    ),
    "revoke_licence": (
        "create_intake_for_revoke_licence", "update_revoke_licence_data"
    ),
    "specific_hour": (
        "create_intake_for_specific_hour", "update_specific_hour_data"
    ),
    "responsible_person": (
        "create_intake_for_rp", "update_rp_data"
    ),
    "change_home_manager": (
        "create_intake_for_change_home_manager", "update_change_home_manager_data"
    ),
    "change_beds": (
        "create_intake_for_change_beds", "update_change_beds_data"
    ),
    "change_operation_mode": (
        "create_intake_for_change_operation_mode",
        "update_change_operation_mode_data",
    ),
    "change_directors": (
        "create_intake_for_change_directors", "update_change_directors_data"
    ),
    "change_nurse_in_charge": (
        "create_intake_for_change_nurse_in_charge",
        "update_change_nurse_in_charge_data",
    ),
    "prosecution": (
        "create_intake_for_prosecution", "update_prosecution_data"
    ),
    "expansion_aip": (
        "create_intake_for_expansion_aip", "update_expansion_aip_data"
    ),
    "licence_renewal": (
        "create_licence_renewal", "update_licence_renewal_data"
    ),
}


def _sql_case(column: str, *, index: int) -> str:
    if not re.fullmatch(r'[a-z_]+\."f_application_type"', column):
        raise ValueError("Only a fixed application-type SQL column is allowed")
    cases = " ".join(
        f"WHEN '{application_type}' THEN '{api_pair[index]}'"
        for application_type, api_pair in FAMILY_APIS.items()
    )
    return f"(CASE {column} {cases} END)"


def admission_sql() -> str:
    original_update = 'child."f_api_type" = :updateApiType'
    original_create = 'parent."f_api_type" = :createApiType'
    if (
        ATOMIC_ADMIT_PENDING_SQL.count(original_update) != 1
        or ATOMIC_ADMIT_PENDING_SQL.count(original_create) != 1
    ):
        raise ValueError("Admission SQL API binding drifted")
    sql = ATOMIC_ADMIT_PENDING_SQL.replace(
        original_update,
        'child."f_api_type" = ' + _sql_case('child."f_application_type"', index=1),
    ).replace(
        original_create,
        'parent."f_api_type" = ' + _sql_case('pending."f_application_type"', index=0),
    )
    if (
        'SET "f_queue_counted" = TRUE' not in sql
        or "SET \"f_status\" = 'queued'" in sql
    ):
        raise ValueError("Admission SQL must leave pending status for ORM wake")
    return sql


def legacy_admission_sql() -> str:
    """Exact pre-native SQL in the installed, disabled Admission action.

    This is only for pinned source verification before same-key revision.
    Never activate it: its SQL changes ``f_status`` directly and therefore
    cannot wake a NocoBase Collection Event.
    """
    # This pinned snapshot is independent of the new admission-sequence
    # contract.  Never derive it from the future SQL: the installed disabled
    # action must be compared with the exact old candidate before revision.
    sql = """
WITH pending AS MATERIALIZED (
  SELECT child."id", child."f_application_type",
         child."f_parent_create_id"
  FROM "t_api_request_staging" AS child
  WHERE child."id" = :updateId
    AND child."f_parent_create_id" = :createId
    AND child."f_request_event" = 'UPDATE'
    AND child."f_source_system" = :sourceSystem
    AND child."f_api_type" = :updateApiType
    AND child."f_application_type" = :applicationType
    AND child."f_status" = 'admission_pending'
    AND child."f_queue_counted" IS NOT TRUE
    AND child."f_active_update_id" IS NOT NULL
    AND child."f_client_request_id" IS NOT NULL
  FOR UPDATE OF child SKIP LOCKED
), admitted_parent AS (
  UPDATE "t_api_request_staging" AS parent
  SET "f_queue_pending_count" =
      COALESCE(parent."f_queue_pending_count", 0) + 1
  FROM pending
  WHERE CAST(parent."id" AS text) = pending."f_parent_create_id"
    AND parent."f_request_event" = 'CREATE'
    AND parent."f_source_system" = :sourceSystem
    AND parent."f_api_type" = :createApiType
    AND parent."f_application_type" = :applicationType
    AND parent."f_status" IN ('submitted', 'processing', 'succeeded')
    AND parent."f_application_status" = 'Accepted'
  RETURNING parent."id"
), admitted_child AS (
  UPDATE "t_api_request_staging" AS child
  SET "f_status" = 'queued', "f_queue_counted" = TRUE
  FROM pending, admitted_parent
  WHERE child."id" = pending."id"
    AND child."f_status" = 'admission_pending'
    AND CAST(admitted_parent."id" AS text) = pending."f_parent_create_id"
  RETURNING child."id"
), result AS (
  SELECT (SELECT COUNT(*) FROM admitted_parent) AS parent_rows,
         (SELECT COUNT(*) FROM admitted_child) AS child_rows,
         (SELECT "id" FROM admitted_child) AS update_id
)
SELECT parent_rows, child_rows, update_id,
       CASE WHEN parent_rows = 0 THEN 0 ELSE 1 / child_rows END
         AS consistency_guard
FROM result;
""".strip()
    return sql.replace(
        'child."f_api_type" = :updateApiType',
        'child."f_api_type" = '
        + _sql_case('child."f_application_type"', index=1),
    ).replace(
        'parent."f_api_type" = :createApiType',
        'parent."f_api_type" = '
        + _sql_case('pending."f_application_type"', index=0),
    )


def dispatch_sql() -> str:
    original_update = 'staged."f_api_type" = :updateApiType'
    original_create = 'parent."f_api_type" = :createApiType'
    if (
        ATOMIC_FIFO_DISPATCH_SQL.count(original_update) != 1
        or ATOMIC_FIFO_DISPATCH_SQL.count(original_create) != 1
    ):
        raise ValueError("Dispatch SQL API binding drifted")
    return ATOMIC_FIFO_DISPATCH_SQL.replace(
        original_update,
        'staged."f_api_type" = '
        + _sql_case('staged."f_application_type"', index=1),
    ).replace(
        original_create,
        'parent."f_api_type" = '
        + _sql_case('parent."f_application_type"', index=0),
    )


def legacy_rejection_sql() -> str:
    """Exact pre-fence SQL of the installed, disabled Reject action."""
    return """
UPDATE "t_api_request_staging" AS child
SET "f_status" = 'failed', "f_error_message" = 'update_locked'
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_parent_create_id" = :createId
  AND child."f_request_event" = 'UPDATE'
  AND child."f_source_system" = :sourceSystem
  AND child."f_api_type" = :updateApiType
  AND child."f_status" = 'admission_pending'
  AND child."f_queue_counted" IS NOT TRUE
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_request_event" = 'CREATE'
  AND parent."f_application_type" = child."f_application_type"
  AND parent."f_application_status" <> 'Accepted'
RETURNING child."id";
""".strip()


def legacy_dispatch_sql() -> str:
    """Exact pre-fence SQL of the installed, disabled FIFO action."""
    sql = dispatch_sql()
    counted_fragment = '        AND older."f_queue_counted" IS TRUE\n'
    final_guard = (
        '  AND staged."f_queue_counted" IS TRUE\n'
        '  AND staged."f_queue_sequence" IS NOT NULL\n'
        '  AND staged."f_active_update_id" = candidate."f_active_update_id"\n'
    )
    new_set = 'SET "f_queue_claimed_at" = NOW(),'
    old_set = 'SET "f_status" = \'submitted\',\n    "f_queue_claimed_at" = NOW(),'
    if (
        sql.count(counted_fragment) != 1
        or sql.count(final_guard) != 1
        or sql.count(new_set) != 1
    ):
        raise ValueError("Reserved-only FIFO SQL shape drifted")
    return (
        sql.replace(counted_fragment, "")
        .replace(final_guard, "")
        .replace(new_set, old_set)
        .replace('older."f_queue_sequence" < staged."f_queue_sequence"',
                 'older."id" < staged."id"')
        .replace('ORDER BY staged."f_queue_sequence"',
                 'ORDER BY staged."id"')
        .replace('    AND staged."f_queue_sequence" IS NOT NULL\n', "")
        .replace('  AND staged."f_queue_sequence" IS NOT NULL\n', "")
    )


def action_config(kind: str) -> dict[str, Any]:
    common_variables = [
        {"name": "updateId", "value": "{{$context.data.id}}"},
        {"name": "createId", "value": "{{$context.data.f_parent_create_id}}"},
        {"name": "sourceSystem", "value": "{{$context.data.f_source_system}}"},
        {"name": "applicationType", "value": "{{$context.data.f_application_type}}"},
    ]
    if kind == "admit":
        sql = admission_sql()
        variables = common_variables
        title = ADMISSION_TITLE
    elif kind == "reject":
        sql = ATOMIC_REJECT_UNADMITTED_SQL
        variables = [
            *common_variables,
            {"name": "updateApiType", "value": "{{$context.data.f_api_type}}"},
        ]
        title = REJECTION_TITLE
    elif kind == "dispatch":
        sql = dispatch_sql()
        variables = [
            {"name": "createId", "value": "{{$context.data.id}}"},
            {"name": "sourceSystem", "value": "{{$context.data.f_source_system}}"},
            {
                "name": "applicationType",
                "value": "{{$context.data.f_application_type}}",
            },
        ]
        title = DISPATCH_TITLE
    else:
        raise ValueError("Unknown Q3 action")
    return {
        "title": title,
        "workflow": {
            "title": title,
            "type": "custom-action",
            "sync": True,
            "enabled": False,
            "config": {"type": 1, "collection": COLLECTION, "appends": []},
        },
        "node": {
            "type": "sql",
            "title": "Q3 guarded SQL — " + kind,
            "config": {
                "dataSource": "main",
                "sql": sql,
                "variables": variables,
                "withMeta": False,
                "unsafeInjection": False,
            },
        },
        "sql_sha256": hashlib.sha256(sql.encode()).hexdigest(),
    }


def strict_staging_trigger_preflight(workflows: list[dict[str, Any]]) -> int:
    """Refuse any enabled Collection Event with a non-exclusionary condition."""

    inspected = 0
    for workflow in workflows:
        config = workflow.get("config") or {}
        if (
            workflow.get("type") != "collection"
            or workflow.get("enabled") is not True
            or config.get("collection") != COLLECTION
        ):
            continue
        inspected += 1
        condition = config.get("condition") or {}
        conjuncts = condition.get("$and") if isinstance(condition, dict) else None
        if not isinstance(conjuncts, list):
            raise ValueError(f"Workflow {workflow.get('id')} lacks top-level AND")
        submitted = {"f_status": {"$eq": "submitted"}}
        received = {"f_application_status": {"$eq": "Received"}}
        create = {"f_request_event": {"$eq": "CREATE"}}
        if submitted in conjuncts or (received in conjuncts and create in conjuncts):
            continue
        raise ValueError(
            f"Workflow {workflow.get('id')} may match a Q3 pending/queued row"
        )
    return inspected
