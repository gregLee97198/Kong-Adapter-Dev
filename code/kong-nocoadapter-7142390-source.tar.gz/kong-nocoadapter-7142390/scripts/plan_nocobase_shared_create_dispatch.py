#!/usr/bin/env python3
"""Offline blueprint for one OP CREATE Staging dispatcher on 13001.

This file deliberately has no NocoBase client, HTTP calls, Docker calls, or
workflow writer.  It does not install or activate anything.  The existing NLA
CREATE-only pilot stays untouched.  UPDATE is excluded because this blueprint
does not include the separately gated FIFO worker or its status preflight.

The route catalogue is pinned to the read-only 13001 inventory dated
2026-10-16.  Existing workflow UIDs/keys below are observations, not proposed
candidate IDs.  A future installer must discover any new same-key revision ID
from NocoBase and compare the business-node graph before a guarded cutover.
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from typing import Any

COLLECTION = "t_api_request_staging"
SOURCE = "OP"
STATUS = "submitted"
CLAIM_FIELD = "f_dispatch_claim"
ROUTE_FIELD = "f_dispatch_route"
CLAIMED_AT_FIELD = "f_dispatch_claimed_at"


class SharedCreatePlanError(ValueError):
    """A requested route violates the pinned CREATE-only blueprint."""


@dataclass(frozen=True)
class CreateFamily:
    name: str
    application_type: str
    api_type: str
    route: str
    observed_direct_uid: int
    observed_workflow_key: str

    @property
    def tuple4(self) -> tuple[str, str, str, str]:
        return (SOURCE, "CREATE", self.api_type, self.application_type)


# The 12 OP CREATE families in API Specification v0.8.1. 13001 also has old
# Prosecution and Revoke workflows, but neither belongs in this public release
# scope; including either would silently broaden the dispatcher's trigger.
# The NLA direct UID is the old disabled version; its same-key marker candidate
# is already active in the existing pilot.  No candidate UID is guessed here.
PUBLIC_CREATE_FAMILIES: tuple[CreateFamily, ...] = (
    CreateFamily(
        "new_licence",
        "new_licence",
        "create_intake_for_new_licence",
        "nla_create",
        390779244118016,
        "r7lno6pwm8k",
    ),
    CreateFamily(
        "changing_home",
        "changing_home",
        "create_intake_for_changing_home",
        "changing_home_create",
        392235065081856,
        "4hkmccur7cy",
    ),
    CreateFamily(
        "licence_renewal",
        "licence_renewal",
        "create_licence_renewal",
        "licence_renewal_create",
        392233305571328,
        "6oea217lqvi",
    ),
    CreateFamily(
        "expansion_aip",
        "expansion_aip",
        "create_intake_for_expansion_aip",
        "expansion_aip_create",
        392238082883584,
        "9zw8wopo5zg",
    ),
    CreateFamily(
        "specific_hour",
        "specific_hour",
        "create_intake_for_specific_hour",
        "specific_hour_create",
        392243799719936,
        "j47w4mphtx8",
    ),
    CreateFamily(
        "responsible_person",
        "responsible_person",
        "create_intake_for_rp",
        "responsible_person_create",
        392244160430080,
        "ghfvy2w2idk",
    ),
    CreateFamily(
        "self_withdraw",
        "self_withdraw",
        "create_intake_for_self_withdraw",
        "self_withdraw_create",
        392229543280640,
        "swbq3akxmhu",
    ),
    CreateFamily(
        "change_home_manager",
        "change_home_manager",
        "create_intake_for_change_home_manager",
        "change_home_manager_create",
        388252417982464,
        "kempmczlabu",
    ),
    CreateFamily(
        "change_beds",
        "change_beds",
        "create_intake_for_change_beds",
        "change_beds_create",
        388253852434432,
        "6bksnfkg387",
    ),
    CreateFamily(
        "change_operation_mode",
        "change_operation_mode",
        "create_intake_for_change_operation_mode",
        "change_operation_mode_create",
        388254481580032,
        "kt3o9h2vep0",
    ),
    CreateFamily(
        "change_directors",
        "change_directors",
        "create_intake_for_change_directors",
        "change_directors_create",
        388255865700352,
        "kcjz7jqffcn",
    ),
    CreateFamily(
        "change_nurse_in_charge",
        "change_nurse_in_charge",
        "create_intake_for_change_nurse_in_charge",
        "change_nurse_in_charge_create",
        388255286886400,
        "bz8wn0djee9",
    ),
)

EXCLUDED_PUBLIC_CREATE = (
    ("revoke_licence", "create_intake_for_revoke_licence"),
    ("prosecution", "create_intake_for_prosecution"),
)
_BY_NAME = {family.name: family for family in PUBLIC_CREATE_FAMILIES}


def _require_public_family(family: CreateFamily) -> None:
    if family not in PUBLIC_CREATE_FAMILIES:
        raise SharedCreatePlanError("Unapproved public CREATE tuple")


def _require_public_routes(families: tuple[CreateFamily, ...]) -> None:
    if not families or families[0].name != "new_licence":
        raise SharedCreatePlanError("NLA pilot must be retained first")
    if len(families) != len(set(families)):
        raise SharedCreatePlanError("Duplicate CREATE family")
    for family in families:
        _require_public_family(family)


def _eq(field: str, value: str) -> dict[str, Any]:
    return {field: {"$eq": value}}


def _tuple_condition(family: CreateFamily) -> dict[str, Any]:
    return {
        "$and": [
            _eq("f_source_system", SOURCE),
            _eq("f_request_event", "CREATE"),
            _eq("f_api_type", family.api_type),
            _eq("f_application_type", family.application_type),
        ]
    }


def select_families(names: Iterable[str]) -> tuple[CreateFamily, ...]:
    """Explicit, ordered allowlist; including a family never activates it."""
    requested = list(names)
    if not requested or len(requested) != len(set(requested)):
        raise SharedCreatePlanError("Select at least one distinct CREATE family")
    unknown = set(requested) - set(_BY_NAME)
    if unknown:
        raise SharedCreatePlanError(
            f"Unapproved public CREATE family: {sorted(unknown)}"
        )
    if "new_licence" not in requested:
        raise SharedCreatePlanError(
            "Shared revision must retain active NLA CREATE pilot"
        )
    return tuple(
        family for family in PUBLIC_CREATE_FAMILIES if family.name in requested
    )


def parent_config(families: tuple[CreateFamily, ...]) -> dict[str, Any]:
    _require_public_routes(families)
    return {
        "mode": 3,
        "collection": COLLECTION,
        "appends": [],
        "changed": ["f_status"],
        "condition": {
            "$and": [
                _eq("f_source_system", SOURCE),
                _eq("f_status", STATUS),
                {"$or": [_tuple_condition(family) for family in families]},
            ]
        },
    }


def _sql_text(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _sql_tuple(family: CreateFamily) -> str:
    return " AND ".join(
        (
            f'staged."f_source_system" = {_sql_text(SOURCE)}',
            "staged.\"f_request_event\" = 'CREATE'",
            f'staged."f_api_type" = {_sql_text(family.api_type)}',
            f'staged."f_application_type" = {_sql_text(family.application_type)}',
        )
    )


def claim_sql(families: tuple[CreateFamily, ...]) -> str:
    """Claim without ORM wake.  Every CASE/WHERE arm is an exact 4-tuple."""
    _require_public_routes(families)
    cases = "\n".join(
        f"      WHEN ({_sql_tuple(family)}) THEN {_sql_text(family.route)}"
        for family in families
    )
    where = "\n      OR ".join(f"({_sql_tuple(family)})" for family in families)
    return f'''WITH eligible AS MATERIALIZED (
  SELECT staged."id",
         CASE
{cases}
         END AS route
  FROM "{COLLECTION}" AS staged
  WHERE staged."id" = :stagingId
    AND staged."f_status" = '{STATUS}'
    AND staged."{CLAIM_FIELD}" IS NULL
    AND staged."{ROUTE_FIELD}" IS NULL
    AND (
      {where}
    )
  FOR UPDATE OF staged SKIP LOCKED
)
UPDATE "{COLLECTION}" AS staged
SET "{CLAIM_FIELD}" = eligible.route,
    "{CLAIMED_AT_FIELD}" = NOW()
FROM eligible
WHERE staged."id" = eligible."id"
  AND eligible.route IS NOT NULL
  AND staged."{CLAIM_FIELD}" IS NULL
  AND staged."{ROUTE_FIELD}" IS NULL
RETURNING staged."id", staged."{CLAIM_FIELD}";'''


def child_config(family: CreateFamily) -> dict[str, Any]:
    _require_public_family(family)
    return {
        "mode": 2,
        "collection": COLLECTION,
        "appends": [],
        "changed": [ROUTE_FIELD],
        "condition": {
            "$and": [
                *_tuple_condition(family)["$and"],
                _eq("f_status", STATUS),
                _eq(CLAIM_FIELD, family.route),
                _eq(ROUTE_FIELD, family.route),
            ]
        },
    }


def _wake_filter(family: CreateFamily) -> dict[str, Any]:
    return {
        "$and": [
            {"id": {"$eq": "{{$context.data.id}}"}},
            *_tuple_condition(family)["$and"],
            _eq("f_status", STATUS),
            _eq(CLAIM_FIELD, family.route),
            {ROUTE_FIELD: {"$empty": True}},
        ]
    }


def _ref(key: str, field: str) -> str:
    return "{{$jobsMapByNodeKey." + key + "." + field + "}}"


def parent_nodes(families: tuple[CreateFamily, ...]) -> list[dict[str, Any]]:
    """Stable-key graph: a mutually exclusive explicit condition chain."""
    _require_public_routes(families)
    whitelist = {"$or": [_tuple_condition(family) for family in families]}
    nodes: list[dict[str, Any]] = [
        {
            "key": "shared_create_claim",
            "type": "sql",
            "upstream": None,
            "branch": None,
            "title": "Claim exact OP CREATE submitted row",
            "config": {
                "dataSource": "main",
                "sql": claim_sql(families),
                "variables": [{"name": "stagingId", "value": "{{$context.data.id}}"}],
                "withMeta": False,
                "unsafeInjection": False,
            },
        },
        {
            "key": "shared_create_read",
            "type": "query",
            "upstream": "shared_create_claim",
            "branch": None,
            "title": "Read claimed OP CREATE row",
            "config": {
                "collection": COLLECTION,
                "multiple": False,
                "failOnEmpty": False,
                "params": {
                    "filter": {
                        "$and": [
                            {"id": {"$eq": "{{$context.data.id}}"}},
                            _eq("f_status", STATUS),
                            {CLAIM_FIELD: {"$notEmpty": True}},
                            {ROUTE_FIELD: {"$empty": True}},
                            whitelist,
                        ]
                    },
                    "page": 1,
                    "pageSize": 1,
                    "sort": [],
                    "appends": [],
                },
            },
        },
        {
            "key": "shared_create_claimed",
            "type": "condition",
            "upstream": "shared_create_read",
            "branch": None,
            "title": "Claim exists and route is empty",
            "config": {
                "rejectOnFalse": True,
                "engine": "basic",
                "calculation": {
                    "group": {
                        "type": "and",
                        "calculations": [
                            {
                                "calculator": "gt",
                                "operands": [_ref("shared_create_read", "id"), 0],
                            }
                        ],
                    }
                },
            },
        },
    ]
    previous = "shared_create_claimed"
    for index, family in enumerate(families):
        condition_key = f"shared_create_is_{family.name}"
        nodes.append(
            {
                "key": condition_key,
                "type": "condition",
                "upstream": previous,
                "branch": 1 if index == 0 else 0,
                "title": f"Match exact OP CREATE {family.name}",
                "config": {
                    "rejectOnFalse": False,
                    "engine": "basic",
                    "calculation": {
                        "group": {
                            "type": "and",
                            "calculations": [
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", "f_source_system"),
                                        SOURCE,
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", "f_request_event"),
                                        "CREATE",
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", "f_api_type"),
                                        family.api_type,
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref(
                                            "shared_create_read", "f_application_type"
                                        ),
                                        family.application_type,
                                    ],
                                },
                                {
                                    "calculator": "equal",
                                    "operands": [
                                        _ref("shared_create_read", CLAIM_FIELD),
                                        family.route,
                                    ],
                                },
                            ],
                        }
                    },
                },
            }
        )
        nodes.append(
            {
                "key": f"shared_create_wake_{family.name}",
                "type": "update",
                "upstream": condition_key,
                "branch": 1,
                "title": f"Wake {family.name} Create with ORM route marker",
                "config": {
                    "collection": COLLECTION,
                    "params": {
                        "individualHooks": True,
                        "filter": _wake_filter(family),
                        "values": {ROUTE_FIELD: family.route},
                        "appends": [],
                    },
                },
            }
        )
        previous = condition_key
    return nodes


def validate_plan(families: tuple[CreateFamily, ...]) -> None:
    _require_public_routes(families)
    for attr in (
        "name",
        "application_type",
        "api_type",
        "route",
        "observed_direct_uid",
        "observed_workflow_key",
    ):
        values = [getattr(family, attr) for family in families]
        if len(values) != len(set(values)):
            raise SharedCreatePlanError(f"Duplicate CREATE family {attr}")
    config = parent_config(families)
    nodes = parent_nodes(families)
    if config["mode"] != 3 or config["changed"] != ["f_status"]:
        raise SharedCreatePlanError("Parent may recurse on marker")
    if len(nodes) != 3 + 2 * len(families):
        raise SharedCreatePlanError("Branch graph node count drifted")
    if len({node["key"] for node in nodes}) != len(nodes):
        raise SharedCreatePlanError("Branch graph contains duplicate keys")
    for family in families:
        child = child_config(family)
        if child["mode"] != 2 or child["changed"] != [ROUTE_FIELD]:
            raise SharedCreatePlanError(f"Unsafe marker child {family.name}")
    for node in nodes:
        if node["type"] == "subflow":
            raise SharedCreatePlanError("Collection Subflow is not proven")
        if node["type"] == "update":
            if set(node["config"]["params"]["values"]) != {ROUTE_FIELD}:
                raise SharedCreatePlanError("ORM wake must update only the route")
            route = node["config"]["params"]["values"][ROUTE_FIELD]
            if "{{" in route or "}}" in route:
                raise SharedCreatePlanError("Dynamic route binding is unproven")


def plan(names: Iterable[str]) -> dict[str, Any]:
    families = select_families(names)
    validate_plan(families)
    return {
        "writes": False,
        "environment": "offline-only; proposed for 13001",
        "activation": "blocked; each family requires a guarded live cutover",
        "update_dispatch": "off; no UPDATE route may be enabled",
        "existing_nla_pilot": (
            "preserve active marker child and parent until reviewed revision"
        ),
        "families": [
            asdict(family) | {"tuple4": family.tuple4, "candidate_uid": None}
            for family in families
        ],
        "excluded_public_create": EXCLUDED_PUBLIC_CREATE,
        "parent_config_candidate": parent_config(families),
        "parent_nodes_candidate": parent_nodes(families),
        "child_configs_candidate": {
            family.name: child_config(family) for family in families
        },
        "validation_gates": [
            "fresh read-only 13001 source UID/key and graph digest for each family",
            "same-key disabled child revision preserves business-node graph",
            "new parent same-key revision preserves active NLA CREATE route",
            "explicit branch/ORM marker execution proven for each family",
            "exact tuple idle, in-flight, execution-count and gap reconciliation",
            "one real Create has one parent+child and one Intake+Application",
            "rollback and no marker-trigger recursion evidenced",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "family",
        nargs="*",
        default=["new_licence"],
        help="Public CREATE family names; NLA must be included",
    )
    args = parser.parse_args()
    print(json.dumps(plan(args.family), ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
