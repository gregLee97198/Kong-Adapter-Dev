#!/usr/bin/env python3
"""Offline guardrails for the 13001 API-Staging cutover and cleanup.

This file deliberately has **no HTTP client**, never reads ``NOCOBASE_TOKEN``
and cannot write to NocoBase.  It is the reviewed companion to
``plan_nocobase_unified_subflow_dispatch_13001.py``:

* one collection-event ingress with a twelve-way ``multi-conditions`` router;
* twelve ``custom-action`` children, each with one CREATE/UPDATE router; and
* retirement of only the exact superseded collection workflows listed below.

It exists to prevent a broad category/title cleanup from accidentally touching
native Intake, application, approval, Send Letter, attachment, reminder or
Notice workflows.  A future executor must consume a fresh read-only snapshot
and this plan, then require separate explicit cutover and retirement approval.

The default output is a local review plan.  ``--review`` validates two local
JSON evidence files and emits an ordered operation list; it still cannot make
a network request or delete a workflow.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import plan_nocobase_unified_subflow_dispatch_13001 as topology


PLAN_FORMAT = "nocobase-unified-subflow-cutover-cleanup-plan/v1"
ENVIRONMENT = "13001"
RETIRE_CONFIRM = "RETIRE_LEGACY_API_STAGING_AFTER_SUBFLOW_ACCEPTANCE_13001"
CUTOVER_CONFIRM = "CUTOVER_UNIFIED_SUBFLOW_API_STAGING_13001"


class PlanError(ValueError):
    """A local evidence file does not satisfy the approved safety gates."""


@dataclass(frozen=True)
class WorkflowTarget:
    """An exact workflow identity.  Never match by partial title/category."""

    id: int
    key: str
    title: str
    business: str
    role: str
    disposition: str


# These are the active 13001 collection workflows exported at
# 2026-10-19T04:38:57Z.  The public 12-business cutover replaces every item
# in this list; the NLA parent is included because it is itself a collection
# event listener.  There are intentionally no title wildcard rules.
PUBLIC_LEGACY: tuple[WorkflowTarget, ...] = (
    WorkflowTarget(392438115532800, "7dms7pwosyw", "API Staging — NLA guarded ingress dispatcher", "new_licence", "legacy_parent", "default_retire"),
    WorkflowTarget(392440992825344, "r7lno6pwm8k", "API Request Staging — Dispatch by Source/Event/API Type — Address Codes v2 [Sparse Checklist]", "new_licence", "create", "default_retire"),
    WorkflowTarget(392500067500032, "w9mu1bnq8k7", "API Request Staging — Update New Licence Data v5 [Sparse Checklist]", "new_licence", "update", "default_retire"),
    WorkflowTarget(392534731390976, "4hkmccur7cy", "API Request Staging — Create Changing Home Information v1", "changing_home", "create", "default_retire"),
    WorkflowTarget(392534972563456, "p4o1zy78fjz", "API Request Staging — Update Changing Home Information v1", "changing_home", "update", "default_retire"),
    WorkflowTarget(392233305571328, "6oea217lqvi", "API Request Staging — Create Licence Renewal v1", "licence_renewal", "create", "default_retire"),
    WorkflowTarget(392475375632384, "ig5t8vyt336", "OP LRN Update — guarded Checklist Detail revision [disabled]", "licence_renewal", "update", "default_retire"),
    WorkflowTarget(392238082883584, "9zw8wopo5zg", "API Request Staging — Create Expansion AIP v1", "expansion_aip", "create", "default_retire"),
    WorkflowTarget(392539179450368, "ovs6xo6bp6j", "API Request Staging — Update Expansion AIP v1", "expansion_aip", "update", "default_retire"),
    WorkflowTarget(392243799719936, "j47w4mphtx8", "API Request Staging — Create Specific Hour v1", "specific_hour", "create", "default_retire"),
    WorkflowTarget(392497360076800, "no5sgqavq34", "API Request Staging — Update Specific Hour v1", "specific_hour", "update", "default_retire"),
    WorkflowTarget(392244160430080, "ghfvy2w2idk", "API Request Staging — Create Responsible Person v1", "responsible_person", "create", "default_retire"),
    WorkflowTarget(392492660359168, "lwgijxcls00", "API Request Staging — Update Responsible Person v1 [optional input guard]", "responsible_person", "update", "default_retire"),
    WorkflowTarget(392229543280640, "swbq3akxmhu", "API Request Staging — Create Self-withdraw Licence v1", "self_withdraw", "create", "default_retire"),
    WorkflowTarget(392537006800897, "51ypnjgwdth", "API Request Staging — Update Self-withdraw Licence v1", "self_withdraw", "update", "default_retire"),
    WorkflowTarget(392455628849152, "kempmczlabu", "API Request Staging — Create Change Home Manager v1", "change_home_manager", "create", "default_retire"),
    WorkflowTarget(392501258682368, "h5yynm9td1s", "API Request Staging — Update Change Home Manager v1", "change_home_manager", "update", "default_retire"),
    WorkflowTarget(392455784038400, "6bksnfkg387", "API Request Staging — Create Change Beds v1", "change_beds", "create", "default_retire"),
    WorkflowTarget(392506430259203, "whzpt4zx7e5", "API Request Staging — Update Change Beds v1", "change_beds", "update", "default_retire"),
    WorkflowTarget(392367489744896, "kt3o9h2vep0", "API Request Staging — Create Change Operation Mode v1", "change_operation_mode", "create", "default_retire"),
    WorkflowTarget(392508347056128, "a94acwmvst5", "API Request Staging — Update Change Operation Mode v1", "change_operation_mode", "update", "default_retire"),
    WorkflowTarget(392479720931328, "kcjz7jqffcn", "API Request Staging — Create Change Directors v1", "change_directors", "create", "default_retire"),
    WorkflowTarget(392511457132544, "9seavn6ir3m", "API Request Staging — Update Change Directors v1", "change_directors", "update", "default_retire"),
    WorkflowTarget(392479565742080, "bz8wn0djee9", "API Request Staging — Create Change Nurse-in-Charge v1", "change_nurse_in_charge", "create", "default_retire"),
    WorkflowTarget(392504505073664, "b9xfkbsaxbz", "API Request Staging — Update Change Nurse-in-Charge v1", "change_nurse_in_charge", "update", "default_retire"),
)

# These routes are not part of the twelve-business v0.8.1 contract.  They are
# backed up but intentionally require a separate explicit retirement choice:
# an unpublished Adapter route might still invoke them.
OPTIONAL_UNPUBLISHED: tuple[WorkflowTarget, ...] = (
    WorkflowTarget(386591126388736, "t94xgf90rla", "API Request Staging — Create Prosecution v1", "prosecution", "create", "optional_retire"),
    WorkflowTarget(386593907212288, "ejgrlidyfe9", "API Request Staging — Update Prosecution v1", "prosecution", "update", "optional_retire"),
    WorkflowTarget(388199490060288, "j8y64r0jty2", "API Request Staging — Create Revoke Licence v1", "revoke_licence", "create", "optional_retire"),
    WorkflowTarget(388199729135616, "gvx0eyjfpzh", "API Request Staging — Update Revoke Licence v1", "revoke_licence", "update", "optional_retire"),
)

# A disabled serial prototype is not native logic.  It may be removed only
# after the new custom-action topology has passed its sentinel and candidate
# graph validation.  The partial `api-staging-...d` candidate is kept out of
# the default list until the new writer declares it obsolete; this avoids
# racing a resumable recovery attempt.
OBSOLETE_PROTOTYPES: tuple[WorkflowTarget, ...] = (
    WorkflowTarget(392914024398848, "7dms7pwosyw", "API Staging — unified external dispatcher", "prototype", "serial_dispatcher", "post_acceptance_retire"),
)

PRESERVE: tuple[WorkflowTarget, ...] = (
    WorkflowTarget(390051643523072, "786j92ko3yp", "API Notice — NLA Received with Existing P Number v1", "notice", "notice_listener", "preserve"),
)

# These were already removed under the former cleanup authorization.  A new
# executor must not repeat destructive calls for IDs which are expected to be
# absent.  If one reappears, stop for manual review rather than deleting by
# inference.
EXPECTED_ABSENT: dict[int, str] = {
    392554480271360: "former Changing Home bounded FIFO drain",
    392550738952192: "former Change Directors bounded FIFO drain",
    392549921062912: "former Change Nurse-in-Charge bounded FIFO drain",
    392548744560640: "former Change Operation Mode bounded FIFO drain",
    392547322691584: "former Change Beds bounded FIFO drain",
    392546408333312: "former Change Home Manager bounded FIFO drain",
    392545179402240: "former Responsible Person bounded FIFO drain",
    392543057084419: "former Specific Hour bounded FIFO drain",
    392541853319168: "former Expansion AIP bounded FIFO drain",
    392538158137344: "former Closure bounded FIFO drain",
    392472213127168: "former Licence Renewal bounded FIFO drain",
    392467834273792: "former NLA bounded FIFO drain",
    392439008919552: "former Q3 rejection diagnostic",
    392374034956288: "former Q3 admission diagnostic",
    392369236672512: "former Q3 FIFO dispatch diagnostic",
    392927045615616: "removed partial unified ingress candidate b",
    392927525863424: "removed partial unified ingress candidate c",
    392927563612160: "removed partial NLA worker candidate c",
}

# This candidate is known to be disabled and incomplete (23/24 ingress nodes)
# at the time this plan was written.  It is not an automatic target because a
# separate resumable builder may still inspect it.  Once the subflow writer
# declares it superseded, add it to an explicit follow-up retirement batch.
PENDING_OBSOLETE_CANDIDATE = WorkflowTarget(
    392928347947008,
    "<generated>",
    "API Staging — unified ingress dispatcher [prepared api-staging-20261019d]",
    "prototype",
    "incomplete_serial_candidate",
    "manual_post_subflow_retire",
)


def _targets(*groups: Iterable[WorkflowTarget]) -> list[WorkflowTarget]:
    return [target for group in groups for target in group]


def _assert_static_catalogue() -> None:
    topology.static_plan()
    public = list(PUBLIC_LEGACY)
    ids = [target.id for target in _targets(PUBLIC_LEGACY, OPTIONAL_UNPUBLISHED, OBSOLETE_PROTOTYPES, PRESERVE)]
    if len(ids) != len(set(ids)):
        raise PlanError("workflow identity appears in more than one catalogue group")
    if len(public) != 25:
        raise PlanError("the default legacy retirement catalogue must contain exactly 25 workflows")
    expected_businesses = {business.name for business in topology.BUSINESSES}
    observed = {target.business for target in public}
    if observed != expected_businesses:
        raise PlanError("default retirement catalogue no longer matches the twelve public businesses")
    for business in expected_businesses:
        roles = [target.role for target in public if target.business == business]
        wanted = ["legacy_parent", "create", "update"] if business == "new_licence" else ["create", "update"]
        if sorted(roles) != sorted(wanted):
            raise PlanError(f"legacy retirement roles drifted for {business}")
    if set(EXPECTED_ABSENT) & set(ids):
        raise PlanError("already-deleted IDs overlap a live target catalogue")
    if PENDING_OBSOLETE_CANDIDATE.id in set(ids) | set(EXPECTED_ABSENT):
        raise PlanError("pending candidate overlaps another workflow category")


def static_plan() -> dict[str, Any]:
    """Build the no-write, exact-identity cutover/cleanup plan."""
    _assert_static_catalogue()
    return {
        "format": PLAN_FORMAT,
        "environment": "13001 development only",
        "writes_remote": False,
        "architecture": topology.ARCHITECTURE,
        "category": topology.API_SOURCE_CATEGORY_TITLE,
        "topology_contract": {
            "collection_event_workflow_count": 1,
            "ingress_router_type": "multi-conditions",
            "ingress_business_branch_count": 12,
            "custom_action_child_count": 12,
            "child_router_type": "multi-conditions",
            "child_event_branches": ["CREATE", "UPDATE"],
            "prohibited": topology.static_plan()["prohibited"],
        },
        "preserve_exact": [asdict(target) for target in PRESERVE],
        "default_legacy_retirement": [asdict(target) for target in PUBLIC_LEGACY],
        "optional_unpublished_retirement": [asdict(target) for target in OPTIONAL_UNPUBLISHED],
        "post_acceptance_obsolete_prototypes": [asdict(target) for target in OBSOLETE_PROTOTYPES],
        "pending_manual_candidate": asdict(PENDING_OBSOLETE_CANDIDATE),
        "expected_already_absent": EXPECTED_ABSENT,
        "confirmation_literals": {
            "cutover": CUTOVER_CONFIRM,
            "retire": RETIRE_CONFIRM,
        },
        "runbook": [
            "0. Export a fresh local backup of every target and candidate; record exact IDs, keys, nodes and executions.",
            "1. Run the disposable custom-action sentinel. It must execute parent=1 and child=1 exactly once and clean itself in finally.",
            "2. Create/validate one disabled ingress and twelve custom-action children. Verify direct twelve-way multi-condition branches; no serial condition chain, marker worker, schedule or FIFO trigger.",
            "3. Keep ingress disabled. Children may be enabled only if the sentinel proves that NocoBase requires it; custom-action children do not subscribe to collection events.",
            "4. Quiesce public Create/Update admission before changing listeners; retain the observed staging high-water mark and wait for each legacy listener to be idle.",
            "5. In the quiesced intake window, disable the exact 25 legacy public listeners. Read each one back as disabled; do not touch the preserved Notice listener.",
            "6. Enable the verified ingress last, then resume public admission. Perform controlled NLA CREATE plus one non-NLA CREATE/UPDATE test and save executions/readbacks.",
            "7. On test failure: quiesce admission, disable the new ingress, re-enable only the exact legacy listeners from the snapshot, then stop. Do not delete anything.",
            "8. After acceptance and a second fresh backup, delete the 25 disabled legacy listeners. Retire Prosecution/Revoke and stale prototypes only under their separate explicit scope.",
        ],
        "hard_stops": [
            "Snapshot environment is not exactly 13001.",
            "A preserved Notice workflow is missing, disabled, or included in a target set.",
            "Any default legacy workflow identity (id/key/title) drifted.",
            "Any legacy workflow has a currently running/queued execution.",
            "New topology is not exactly one collection ingress + twelve custom-action children.",
            "Ingress has a serial chain or a marker write instead of a twelve-way multi-conditions router.",
            "Any expected-absent ID appears again; require manual review rather than inferred delete.",
        ],
    }


def _read_json(path: Path) -> Mapping[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PlanError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, Mapping):
        raise PlanError(f"JSON object expected: {path}")
    return value


def _rows_by_id(snapshot: Mapping[str, Any]) -> dict[int, Mapping[str, Any]]:
    rows = snapshot.get("workflows")
    if not isinstance(rows, list):
        raise PlanError("snapshot.workflows must be an array")
    result: dict[int, Mapping[str, Any]] = {}
    for row in rows:
        if not isinstance(row, Mapping) or not isinstance(row.get("id"), int):
            raise PlanError("snapshot has a workflow without integer id")
        if row["id"] in result:
            raise PlanError(f"snapshot has duplicate workflow id {row['id']}")
        result[row["id"]] = row
    return result


def _verify_identity(row: Mapping[str, Any], target: WorkflowTarget) -> None:
    observed = (row.get("key"), row.get("title"))
    if target.key != "<generated>" and observed != (target.key, target.title):
        raise PlanError(
            f"workflow {target.id} identity drifted: expected {(target.key, target.title)!r}, got {observed!r}"
        )


def _verify_candidate_identity(row: Mapping[str, Any], candidate: Mapping[str, Any], *, label: str) -> None:
    """Protect post-cutover review against candidate replacement/drift.

    Candidate IDs alone are normally stable, but the validation document also
    carries the server-returned key/title.  Require all three values again
    after controlled traffic has run before authorizing legacy deletion.
    """
    expected_id = candidate.get("id")
    expected_key = candidate.get("key")
    expected_title = candidate.get("title")
    if not isinstance(expected_id, int) or not isinstance(expected_key, str) or not expected_key or not isinstance(expected_title, str) or not expected_title:
        raise PlanError(f"candidate {label} identity is incomplete")
    if row.get("id") != expected_id or row.get("key") != expected_key or row.get("title") != expected_title:
        raise PlanError(f"post-cutover candidate {label} identity drifted")


def _execution_is_idle(snapshot: Mapping[str, Any], workflow_id: int) -> bool:
    executions = snapshot.get("executions")
    if not isinstance(executions, Mapping):
        raise PlanError("snapshot.executions must map workflow IDs to execution summaries")
    value = executions.get(str(workflow_id), executions.get(workflow_id))
    if not isinstance(value, Mapping):
        raise PlanError(f"snapshot lacks execution summary for workflow {workflow_id}")
    return int(value.get("running", 0)) == 0 and int(value.get("queued", 0)) == 0


def _validate_candidate_evidence(evidence: Mapping[str, Any]) -> dict[str, Any]:
    if evidence.get("environment") != ENVIRONMENT:
        raise PlanError("candidate evidence is not explicitly from 13001")
    if evidence.get("architecture") != topology.ARCHITECTURE:
        raise PlanError("candidate evidence architecture mismatch")
    if evidence.get("sentinel", {}).get("passed") is not True:
        raise PlanError("custom-action sentinel evidence is missing or failed")
    sentinel = evidence["sentinel"]
    if sentinel.get("parent_execution_delta") != 1 or sentinel.get("child_execution_delta") != 1:
        raise PlanError("custom-action sentinel must execute exactly one parent and one child")
    if sentinel.get("cleanup_confirmed") is not True:
        raise PlanError("custom-action sentinel cleanup was not confirmed")
    ingress = evidence.get("ingress")
    if not isinstance(ingress, Mapping):
        raise PlanError("candidate evidence has no ingress")
    if (
        ingress.get("type") != "collection"
        or ingress.get("router_type") != "multi-conditions"
        or ingress.get("business_branch_count") != 12
        or ingress.get("collection_event_workflow_count") != 1
        or ingress.get("serial_condition_chain") is not False
        or ingress.get("marker_write") is not False
        or ingress.get("category") != topology.API_SOURCE_CATEGORY_TITLE
    ):
        raise PlanError("ingress is not the approved direct twelve-way multi-branch topology")
    if (
        not isinstance(ingress.get("id"), int)
        or not isinstance(ingress.get("key"), str)
        or not ingress["key"]
        or not isinstance(ingress.get("title"), str)
        or not ingress["title"]
    ):
        raise PlanError("candidate ingress identity is incomplete")
    children = evidence.get("children")
    if not isinstance(children, list) or len(children) != 12:
        raise PlanError("candidate evidence must contain exactly twelve children")
    expected = {business.name for business in topology.BUSINESSES}
    found = {child.get("business") for child in children if isinstance(child, Mapping)}
    if found != expected:
        raise PlanError("candidate children do not cover the exact twelve public businesses")
    for child in children:
        if not isinstance(child, Mapping):
            raise PlanError("candidate child is not an object")
        if child.get("type") != "custom-action" or child.get("router_type") != "multi-conditions":
            raise PlanError(f"child {child.get('business')!r} is not a custom-action multi-conditions workflow")
        if child.get("event_branches") != ["CREATE", "UPDATE"]:
            raise PlanError(f"child {child.get('business')!r} does not have only CREATE/UPDATE branches")
        if child.get("marker_write") is not False:
            raise PlanError(f"child {child.get('business')!r} contains forbidden marker routing")
        if child.get("category") != topology.API_SOURCE_CATEGORY_TITLE:
            raise PlanError(f"child {child.get('business')!r} is not attached to API Suorce")
        if (
            not isinstance(child.get("id"), int)
            or not isinstance(child.get("key"), str)
            or not child["key"]
            or not isinstance(child.get("title"), str)
            or not child["title"]
        ):
            raise PlanError(f"candidate child identity is incomplete: {child.get('business')!r}")
        if child.get("executed", 0) not in (0, 1):
            raise PlanError(f"child {child.get('business')!r} execution count is unexpected")
    child_enable_state = evidence.get("child_enable_state_at_cutover", "enabled")
    if child_enable_state not in {"enabled", "disabled"}:
        raise PlanError("candidate evidence child enable state is invalid")
    return {
        "ingress": {
            "id": ingress.get("id"),
            "key": ingress.get("key"),
            "title": ingress.get("title"),
        },
        "children": [
            {
                "id": child.get("id"),
                "key": child.get("key"),
                "title": child.get("title"),
                "business": child.get("business"),
            }
            for child in children
        ],
        "child_enable_state_at_cutover": child_enable_state,
    }


def _runtime_record_is_bound(
    validation: Mapping[str, Any], runtime_record: Mapping[str, Any] | None
) -> bool:
    """Check local post-cutover evidence without re-contacting 13001.

    ``--validate`` is deliberately a *pre-cutover* command: it rejects an
    enabled/executed candidate.  The later ``--record-runtime-evidence``
    result is therefore a second, local-only document bound to the same
    migration/manifest.  It is not safe to pretend a pre-cutover validation
    can itself prove a real submitted request after the cutover.
    """
    if runtime_record is None:
        return False
    if runtime_record.get("writes_remote") is not False:
        raise PlanError("runtime record must be local-only")
    if runtime_record.get("migration_id") != validation.get("migration_id"):
        raise PlanError("runtime record migration ID does not match executor validation")
    if runtime_record.get("manifest") != validation.get("manifest"):
        raise PlanError("runtime record manifest does not match executor validation")
    for field in ("topology_sha256", "source_snapshot_sha256"):
        value = validation.get(field)
        if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
            raise PlanError(f"executor validation has malformed {field}")
        if runtime_record.get(field) != value:
            raise PlanError(f"runtime record {field} does not match executor validation")
    if validation.get("topology_sha256") != topology._topology_digest():
        raise PlanError("executor validation topology checksum does not match this reviewed guard")
    prerequisites = runtime_record.get("runtime_acceptance_prerequisites")
    expected = {"created_by_id", "op_role_mapping", "direct_create_submitted_trigger"}
    if not isinstance(prerequisites, Mapping) or set(prerequisites) != expected:
        raise PlanError("runtime record acceptance prerequisites are incomplete")
    if any(prerequisites.get(key) != "passed" for key in expected):
        raise PlanError("runtime record does not mark every acceptance prerequisite passed")
    evidence = runtime_record.get("runtime_evidence")
    if (
        not isinstance(evidence, Mapping)
        or evidence.get("state") != "passed"
        or not isinstance(evidence.get("evidence_sha256"), str)
        or not evidence.get("evidence_sha256")
    ):
        raise PlanError("runtime record does not contain sealed passed evidence")
    outcomes = evidence.get("outcomes")
    if not isinstance(outcomes, Mapping) or set(outcomes) != expected:
        raise PlanError("runtime record does not contain the three required outcome observations")
    for key in expected:
        item = outcomes.get(key)
        if (
            not isinstance(item, Mapping)
            or item.get("passed") is not True
            or not isinstance(item.get("observation"), str)
            or not item["observation"].strip()
        ):
            raise PlanError(f"runtime record outcome is incomplete: {key}")
    return True


def normalize_executor_validation(
    validation: Mapping[str, Any],
    *,
    runtime_record: Mapping[str, Any] | None = None,
    require_runtime_acceptance: bool = False,
) -> dict[str, Any]:
    """Convert the new builder's read-only ``--validate`` result to guard evidence.

    The builder intentionally proves the actual remote graph and returns a
    mapping keyed by business name.  The cutover guard needs a compact,
    implementation-independent evidence shape.  This normalizer is strict on
    the fields that prove the direct multi-branch architecture.  In
    The normalizer supports two safe stages.  Before cutover, it accepts a
    fully disabled graph and the disposable sentinel only.  Before legacy
    deletion, it additionally requires a separate local runtime-evidence
    record from the actual controlled request after cutover.
    """
    if validation.get("environment") != ENVIRONMENT:
        raise PlanError("executor validation is not explicitly from 13001")
    if validation.get("writes_remote") is not False or validation.get("validated_disabled") is not True:
        raise PlanError("executor result is not a read-only validation of disabled candidates")
    if validation.get("cutover_not_implemented") is not True:
        raise PlanError("executor validation must precede cutover")
    migration_id = validation.get("migration_id")
    if not isinstance(migration_id, str) or not migration_id:
        raise PlanError("executor validation has no migration ID")
    manifest = validation.get("manifest")
    if not isinstance(manifest, str) or not manifest:
        raise PlanError("executor validation has no manifest path")
    topology_sha256 = validation.get("topology_sha256")
    source_snapshot_sha256 = validation.get("source_snapshot_sha256")
    for field, value in {
        "topology_sha256": topology_sha256,
        "source_snapshot_sha256": source_snapshot_sha256,
    }.items():
        if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
            raise PlanError(f"executor validation has malformed {field}")
    if topology_sha256 != topology._topology_digest():
        raise PlanError("executor validation topology checksum does not match this reviewed guard")
    sentinel = validation.get("sentinel")
    if not isinstance(sentinel, Mapping) or sentinel.get("state") != "passed":
        raise PlanError("executor validation lacks successful custom-action sentinel evidence")
    if sentinel.get("parent_execution_delta") != 1 or sentinel.get("child_execution_delta") != 1:
        raise PlanError("executor sentinel did not prove exactly one parent and one child execution")
    if not isinstance(sentinel.get("evidence_sha256"), str) or not sentinel.get("evidence_sha256"):
        raise PlanError("executor sentinel evidence is not sealed locally")

    prerequisites = validation.get("runtime_acceptance_prerequisites")
    required_prerequisites = {
        "created_by_id",
        "op_role_mapping",
        "direct_create_submitted_trigger",
    }
    if not isinstance(prerequisites, Mapping) or set(prerequisites) != required_prerequisites:
        raise PlanError("executor validation has incomplete runtime acceptance prerequisites")
    runtime_passed = _runtime_record_is_bound(validation, runtime_record)
    # A record can be created only after the real controlled test.  The
    # pre-cutover validation itself may still say not_yet_tested.
    if require_runtime_acceptance and not runtime_passed:
        waiting = sorted(name for name in required_prerequisites if prerequisites.get(name) != "passed")
        suffix = (": " + ", ".join(waiting)) if waiting else ""
        raise PlanError("runtime acceptance evidence is required before retirement" + suffix)

    parent = validation.get("parent")
    if not isinstance(parent, Mapping):
        raise PlanError("executor validation lacks parent evidence")
    expected_parent = {
        "type": "collection",
        "router_type": "multi-conditions",
        "business_branch_count": 12,
        "collection_event_workflow_count": 1,
        "serial_condition_chain": False,
        "marker_write": False,
        "category": topology.API_SOURCE_CATEGORY_TITLE,
        "enabled": False,
        "executed": 0,
    }
    for key, value in expected_parent.items():
        if parent.get(key) != value:
            raise PlanError(f"executor parent evidence mismatch for {key!r}")

    children_map = validation.get("children")
    if not isinstance(children_map, Mapping):
        raise PlanError("executor validation children must be a mapping")
    expected_businesses = {business.name for business in topology.BUSINESSES}
    if set(children_map) != expected_businesses:
        raise PlanError("executor validation does not cover the exact twelve business children")
    children: list[dict[str, Any]] = []
    for business in topology.BUSINESSES:
        child = children_map[business.name]
        if not isinstance(child, Mapping):
            raise PlanError(f"executor child is malformed: {business.name}")
        for key, value in {
            "type": "custom-action",
            "router_type": "multi-conditions",
            "event_branches": ["CREATE", "UPDATE"],
            "marker_write": False,
            "category": topology.API_SOURCE_CATEGORY_TITLE,
            "enabled": False,
            "executed": 0,
        }.items():
            if child.get(key) != value:
                raise PlanError(f"executor child evidence mismatch for {business.name}.{key}")
        children.append({
            "id": child.get("id"),
            "key": child.get("key"),
            "title": child.get("title"),
            "business": business.name,
            "type": child["type"],
            "router_type": child["router_type"],
            "event_branches": child["event_branches"],
            "marker_write": child["marker_write"],
            "category": child["category"],
            "executed": child["executed"],
        })
    return {
        "environment": ENVIRONMENT,
        "architecture": topology.ARCHITECTURE,
        "sentinel": {
            "passed": True,
            "parent_execution_delta": 1,
            "child_execution_delta": 1,
            # Probe success is returned only after its finally cleanup passed.
            "cleanup_confirmed": True,
        },
        "ingress": {
            "id": parent.get("id"),
            "key": parent.get("key"),
            "title": parent.get("title"),
            "type": parent["type"],
            "router_type": parent["router_type"],
            "business_branch_count": parent["business_branch_count"],
            "collection_event_workflow_count": parent["collection_event_workflow_count"],
            "serial_condition_chain": parent["serial_condition_chain"],
            "marker_write": parent["marker_write"],
            "category": parent["category"],
        },
        "children": children,
        "child_enable_state_at_cutover": sentinel.get("child_enable_state_at_cutover"),
        "runtime_acceptance_passed": runtime_passed,
    }


def _review_common(
    snapshot: Mapping[str, Any], evidence: Mapping[str, Any]
) -> tuple[dict[str, Any], dict[str, Any], dict[int, Mapping[str, Any]]]:
    """Validate identities that are required at both cutover and retirement."""
    plan = static_plan()
    if snapshot.get("environment") != ENVIRONMENT:
        raise PlanError("workflow snapshot is not explicitly from 13001")
    candidate = _validate_candidate_evidence(evidence)
    rows = _rows_by_id(snapshot)

    for target in PRESERVE:
        row = rows.get(target.id)
        if row is None:
            raise PlanError(f"preserved workflow is absent: {target.id}")
        _verify_identity(row, target)
        if row.get("enabled") is not True:
            raise PlanError(f"preserved workflow must remain enabled: {target.id}")

    for target in PUBLIC_LEGACY:
        row = rows.get(target.id)
        if row is None:
            raise PlanError(f"default legacy workflow is absent: {target.id}")
        _verify_identity(row, target)
        if not _execution_is_idle(snapshot, target.id):
            raise PlanError(f"legacy workflow has a running/queued execution: {target.id}")

    # `expected_absent` is a forensic check, not an automatic second delete.
    unexpectedly_present = sorted(workflow_id for workflow_id in EXPECTED_ABSENT if workflow_id in rows)
    if unexpectedly_present:
        raise PlanError(
            "previously deleted Q3/FIFO/candidate workflow IDs reappeared; manual review required: "
            + ", ".join(map(str, unexpectedly_present))
        )

    return plan, candidate, rows


def review_cutover(snapshot: Mapping[str, Any], evidence: Mapping[str, Any]) -> dict[str, Any]:
    """Emit only the no-delete pre-cutover operation order.

    Runtime evidence is intentionally not required here: it can only be
    produced after a real request has traversed the newly enabled ingress.
    """
    plan, candidate, rows = _review_common(snapshot, evidence)
    # A legacy worker may already be intentionally disabled (for example the
    # historic guarded LRN Update worker).  That is not a safety failure:
    # cutover still explicitly reads every target back as disabled before the
    # new ingress is enabled.  Requiring all 25 to be enabled would make a
    # safe replacement impossible solely because one old path was already
    # dormant.
    invalid_states = [
        target.id
        for target in PUBLIC_LEGACY
        if rows[target.id].get("enabled") not in {True, False}
    ]
    if invalid_states:
        raise PlanError(
            "pre-cutover legacy listener state is not boolean: "
            + ", ".join(map(str, invalid_states))
        )
    return {
        "format": "nocobase-unified-subflow-cutover-review/v1",
        "environment": ENVIRONMENT,
        "writes_remote": False,
        "candidate": candidate,
        "ready_for_manual_cutover": True,
        "operation_order": [
            {
                "step": 1,
                "action": "quiesce_public_create_update_admission",
                "confirmation": CUTOVER_CONFIRM,
                "note": "Pause only external Create/Update admission; record the staging high-water mark and wait for all 25 legacy execution summaries to be idle.",
            },
            {
                "step": 2,
                "action": "disable_exact_workflows",
                "ids": [target.id for target in PUBLIC_LEGACY],
                "confirmation": CUTOVER_CONFIRM,
                "note": "Read back each disabled state before enabling ingress. Do not disable Notice/native workflows.",
            },
            {
                "step": 3,
                "action": "enable_verified_ingress_last",
                "id": candidate["ingress"]["id"],
                "confirmation": CUTOVER_CONFIRM,
                "note": "Custom-action children follow the successful sentinel runtime state; they are not collection listeners.",
            },
            {
                "step": 4,
                "action": "resume_public_create_update_admission",
                "confirmation": CUTOVER_CONFIRM,
                "note": "Resume external admission only after the new ingress readback confirms enabled.",
            },
            {
                "step": 5,
                "action": "functional_acceptance",
                "note": "Controlled NLA CREATE and one non-NLA CREATE/UPDATE, then use the builder's local --record-runtime-evidence. This review never authorizes deletion.",
            },
        ],
        "preserved_ids": [target.id for target in PRESERVE],
        "optional_not_in_default_delete": [target.id for target in _targets(OPTIONAL_UNPUBLISHED, OBSOLETE_PROTOTYPES)] + [PENDING_OBSOLETE_CANDIDATE.id],
        "plan": plan,
    }


def _require_post_cutover_candidate_state(
    snapshot: Mapping[str, Any],
    rows: Mapping[int, Mapping[str, Any]],
    candidate: Mapping[str, Any],
) -> None:
    ingress_candidate = candidate.get("ingress")
    if not isinstance(ingress_candidate, Mapping):
        raise PlanError("post-cutover verified ingress identity is invalid")
    ingress_id = ingress_candidate.get("id")
    if not isinstance(ingress_id, int) or ingress_id not in rows:
        raise PlanError("post-cutover snapshot lacks the verified ingress")
    ingress = rows[ingress_id]
    _verify_candidate_identity(ingress, ingress_candidate, label="ingress")
    if ingress.get("type") != "collection" or ingress.get("enabled") is not True:
        raise PlanError("post-cutover verified ingress is not enabled")
    if not _execution_is_idle(snapshot, ingress_id):
        raise PlanError("post-cutover ingress still has a running/queued execution")
    child_enabled = candidate.get("child_enable_state_at_cutover") == "enabled"
    child_candidates = candidate.get("children")
    if not isinstance(child_candidates, list) or len(child_candidates) != 12:
        raise PlanError("post-cutover child identity list is invalid")
    child_ids = [child.get("id") for child in child_candidates if isinstance(child, Mapping)]
    if len(child_ids) != 12 or any(not isinstance(value, int) for value in child_ids) or len(set(child_ids)) != 12:
        raise PlanError("post-cutover child identity list is invalid")
    for child_candidate in child_candidates:
        if not isinstance(child_candidate, Mapping):
            raise PlanError("post-cutover child identity is malformed")
        workflow_id = child_candidate.get("id")
        if not isinstance(workflow_id, int) or workflow_id not in rows:
            raise PlanError("post-cutover snapshot lacks a verified child")
        child = rows[workflow_id]
        _verify_candidate_identity(child, child_candidate, label=str(child_candidate.get("business")))
        if child.get("type") != "custom-action" or child.get("enabled") is not child_enabled:
            raise PlanError(f"post-cutover child state drifted: {workflow_id}")
        if not _execution_is_idle(snapshot, workflow_id):
            raise PlanError(f"post-cutover child has a running/queued execution: {workflow_id}")


def review_retirement(snapshot: Mapping[str, Any], evidence: Mapping[str, Any]) -> dict[str, Any]:
    """Authorize only the exact legacy deletion list after acceptance evidence."""
    if evidence.get("runtime_acceptance_passed") is not True:
        raise PlanError("runtime acceptance evidence is required before legacy retirement")
    plan, candidate, rows = _review_common(snapshot, evidence)
    enabled = [target.id for target in PUBLIC_LEGACY if rows[target.id].get("enabled") is not False]
    if enabled:
        raise PlanError("legacy listener must be disabled before retirement: " + ", ".join(map(str, enabled)))
    _require_post_cutover_candidate_state(snapshot, rows, candidate)
    return {
        "format": "nocobase-unified-subflow-retirement-review/v1",
        "environment": ENVIRONMENT,
        "writes_remote": False,
        "candidate": candidate,
        "ready_for_manual_retirement": True,
        "operation_order": [
            {
                "step": 1,
                "action": "fresh_backup_exact_workflows",
                "ids": [target.id for target in PUBLIC_LEGACY],
                "note": "Export exact disabled legacy workflows plus new ingress/children before deletion.",
            },
            {
                "step": 2,
                "action": "delete_exact_disabled_legacy",
                "ids": [target.id for target in PUBLIC_LEGACY],
                "confirmation": RETIRE_CONFIRM,
                "note": "No title/category wildcard. Preserve Notice/native workflows; separate scope is required for optional unpublished/prototype records.",
            },
        ],
        "preserved_ids": [target.id for target in PRESERVE],
        "optional_not_in_default_delete": [target.id for target in _targets(OPTIONAL_UNPUBLISHED, OBSOLETE_PROTOTYPES)] + [PENDING_OBSOLETE_CANDIDATE.id],
        "plan": plan,
    }


def review(snapshot: Mapping[str, Any], evidence: Mapping[str, Any]) -> dict[str, Any]:
    """Compatibility alias: a review defaults to the safe pre-cutover stage."""
    return review_cutover(snapshot, evidence)


def review_executor_validation(
    snapshot: Mapping[str, Any],
    validation: Mapping[str, Any],
    *,
    phase: str = "cutover",
    runtime_record: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate an executor ``--validate`` JSON result without contacting 13001."""
    if phase not in {"cutover", "retirement"}:
        raise PlanError("phase must be cutover or retirement")
    evidence = normalize_executor_validation(
        validation,
        runtime_record=runtime_record,
        require_runtime_acceptance=(phase == "retirement"),
    )
    return review_retirement(snapshot, evidence) if phase == "retirement" else review_cutover(snapshot, evidence)


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output.")
    parser.add_argument("--write-plan", type=Path, help="Write the no-secret plan JSON locally.")
    parser.add_argument("--snapshot", type=Path, help="Read-only 13001 workflow snapshot JSON for --review.")
    parser.add_argument("--candidate-evidence", type=Path, help="Validated new-topology evidence JSON for --review.")
    parser.add_argument("--executor-validation", type=Path, help="Read-only JSON output from the subflow builder's --validate command.")
    parser.add_argument("--runtime-record", type=Path, help="Local JSON output from the builder's --record-runtime-evidence command; required only for --phase retirement.")
    parser.add_argument("--phase", choices=("cutover", "retirement"), default="cutover", help="Review stage; default cutover never emits a delete operation.")
    parser.add_argument("--review", action="store_true", help="Validate local evidence and emit a no-write operation order.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if args.review:
            if args.snapshot is None:
                raise PlanError("--review requires --snapshot")
            if (args.candidate_evidence is None) == (args.executor_validation is None):
                raise PlanError("--review requires exactly one of --candidate-evidence or --executor-validation")
            raw_snapshot = _read_json(args.snapshot)
            if args.executor_validation is not None:
                runtime_record = _read_json(args.runtime_record) if args.runtime_record else None
                value = review_executor_validation(
                    raw_snapshot,
                    _read_json(args.executor_validation),
                    phase=args.phase,
                    runtime_record=runtime_record,
                )
            else:
                if args.runtime_record is not None:
                    raise PlanError("--runtime-record requires --executor-validation")
                if args.phase == "retirement":
                    raise PlanError(
                        "--phase retirement requires --executor-validation and --runtime-record; "
                        "generic candidate evidence cannot authorize legacy deletion"
                    )
                evidence = _read_json(args.candidate_evidence)
                value = review_retirement(raw_snapshot, evidence) if args.phase == "retirement" else review_cutover(raw_snapshot, evidence)
        else:
            if args.snapshot is not None or args.candidate_evidence is not None or args.executor_validation is not None or args.runtime_record is not None:
                raise PlanError("--snapshot/--candidate-evidence/--executor-validation/--runtime-record require --review")
            if args.phase != "cutover":
                raise PlanError("--phase requires --review")
            value = static_plan()
        if args.write_plan:
            path = args.write_plan.expanduser().resolve()
            if path.exists():
                raise PlanError(f"refusing to overwrite existing plan: {path}")
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            path.chmod(0o600)
            value = dict(value)
            value["local_plan_path"] = str(path)
        print(json.dumps(value, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except PlanError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
