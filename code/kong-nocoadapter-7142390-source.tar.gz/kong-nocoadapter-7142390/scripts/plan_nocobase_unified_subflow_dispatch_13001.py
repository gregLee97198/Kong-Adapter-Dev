#!/usr/bin/env python3
"""Plan and safely prepare one API-Staging dispatcher on 13001.

This is the replacement design for the earlier marker-worker prototype.  Its
default mode is local-only; its explicitly-confirmed preparation mode can
create disabled 13001 candidates but has no enable, cutover, or deletion path.

Runtime topology
================

``t_api_request_staging`` has exactly one new *collection-event* workflow:

    collection event -> multi-conditions (12 business branches)
                     -> one Invoke Workflow node per business
                     -> custom-action child
                     -> multi-conditions (CREATE / UPDATE)
                     -> cloned business graph

The child is deliberately a ``custom-action`` workflow, not another
collection-event listener.  Therefore a request has one collection listener,
one direct branch, and one child execution; there is no marker update and no
second collection hook.  The child receives ``context.data`` plus the
internally recorded ``createdById`` as its execution identity; this is never
an external request parameter.  The cloned graph retains its existing data
references.

The default invocation is an entirely offline plan.  The optional ``--prepare``
mode is deliberately narrow and recovery-friendly: it creates only *disabled*
candidate workflows, never enables, disables, deletes, or cuts over any live
workflow.  Every remote mutation is checkpointed in a private local manifest;
after a timeout the script reads by an exact deterministic title before it
considers a retry.

The separately-reviewed writer/operator must first run the disposable sentinel
in ``probe_nocobase_custom_action_subflow_13001.py``.  It decides whether a
custom-action child must be enabled at cutover.  A missing proof never enables
anything: it is recorded as ``unknown`` in the preparation manifest, and a
future cutover must refuse it.  No cutover is implemented by this script.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import sys
import tempfile
import urllib.parse
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

# The current catalogue and graph-clone validators are local/offline code.
# Reusing it prevents a second, subtly different list of the 12 public
# applications from being maintained.
import migrate_nocobase_single_staging_dispatch_13001 as legacy
from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError, resolve_workflow_category_id


BASE_URL = legacy.BASE_URL
COLLECTION = legacy.COLLECTION
SOURCE_SYSTEM = legacy.SOURCE_SYSTEM
STATUS = legacy.STATUS
API_SOURCE_CATEGORY_TITLE = legacy.API_SOURCE_CATEGORY_TITLE
BUSINESSES = legacy.BUSINESSES
Business = legacy.Business

ARCHITECTURE = "single-collection-multibranch-custom-action-subflows/v1"
PLAN_FORMAT = "nocobase-unified-api-staging-subflow-plan/v1"
PREPARATION_FORMAT = "nocobase-unified-api-staging-subflow-preparation/v1"
RUNTIME_EVIDENCE_FORMAT = "nocobase-unified-api-staging-runtime-acceptance/v1"
PREPARE_CONFIRM = "PREPARE_DISABLED_UNIFIED_API_STAGING_SUBFLOWS_13001"
# An update request is idempotent only for the exact node and field values
# below.  The production 13001 API occasionally closes the response after
# accepting a ``flow_nodes:update`` request, so a single readback cannot tell
# us whether the write was lost or merely the response was lost.  Keep the
# bounded retry deliberately small: this is recovery from a transport error,
# not a general retry queue.
PATCH_MAX_ATTEMPTS = 3
PREPARED_ROOT = (
    Path(__file__).resolve().parents[1].parent
    / "kong-nocoadapter-artifacts"
    / "workflow-preparations"
)
_MIGRATION_RE = re.compile(r"^[a-z0-9][a-z0-9-]{5,63}$")
RUNTIME_ACCEPTANCE_KEYS = (
    "created_by_id",
    "op_role_mapping",
    "direct_create_submitted_trigger",
)


class PlanError(ValueError):
    """The static topology is internally inconsistent."""


class PreparationError(RuntimeError):
    """A disabled candidate cannot safely be prepared or resumed."""


def _context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def _equal(field: str, value: Any) -> dict[str, Any]:
    return {
        "calculator": "equal",
        "operands": [_context(field), value],
    }


def _and(*calculations: Mapping[str, Any]) -> dict[str, Any]:
    return {"group": {"type": "and", "calculations": [dict(item) for item in calculations]}}


def _or(*calculations: Mapping[str, Any]) -> dict[str, Any]:
    return {"group": {"type": "or", "calculations": [dict(item) for item in calculations]}}


def _branch(uid: str, title: str, calculation: Mapping[str, Any]) -> dict[str, Any]:
    """One NocoBase ``multi-conditions`` branch definition.

    Branch indexes are assigned by the node in the order of this array and are
    one-based in NocoBase.  This is why callers enumerate from one instead of
    using the older condition node's true/false ``1/0`` branches.
    """
    return {
        "uid": uid,
        "title": title,
        "engine": "basic",
        "calculation": copy.deepcopy(dict(calculation)),
    }


def event_calculation(business: Business, event: str) -> dict[str, Any]:
    """An exact tuple check retained inside the business child as a guard."""
    if event not in {"CREATE", "UPDATE"}:
        raise PlanError(f"unsupported event {event!r}")
    api_type = business.create_api_type if event == "CREATE" else business.update_api_type
    return _and(
        _equal("f_source_system", SOURCE_SYSTEM),
        _equal("f_status", STATUS),
        _equal("f_application_type", business.application_type),
        _equal("f_request_event", event),
        _equal("f_api_type", api_type),
    )


def business_calculation(business: Business) -> dict[str, Any]:
    """The ingress branch: one business with either permitted event."""
    return _or(
        event_calculation(business, "CREATE"),
        event_calculation(business, "UPDATE"),
    )


def ingress_config() -> dict[str, Any]:
    """One exact collection-event trigger for all approved external tuples."""
    return {
        "mode": 3,
        "collection": COLLECTION,
        "appends": [],
        "changed": ["f_status"],
        "condition": {
            "$and": [
                {"f_source_system": {"$eq": SOURCE_SYSTEM}},
                {"f_status": {"$eq": STATUS}},
                {
                    "$or": [
                        legacy.tuple_condition(business, event)
                        for business in BUSINESSES
                        for event in ("CREATE", "UPDATE")
                    ]
                },
            ]
        },
    }


def child_config() -> dict[str, Any]:
    """Custom Action input contract for every direct child.

    ``type=1`` is NocoBase's SINGLE_RECORD context type.  It matches the
    collection-record object passed by the parent's Subflow node and avoids a
    second collection-event subscription entirely.
    """
    return {"type": 1, "collection": COLLECTION, "appends": []}


def ingress_router_node() -> dict[str, Any]:
    return {
        "identity": "INGRESS_ROUTER",
        "type": "multi-conditions",
        "title": "Route API Staging request to one business child",
        "upstream": None,
        "branch": None,
        "config": {
            # No default branch: only reviewed, exact public tuples can run.
            "continueOnNoMatch": False,
            "conditions": [
                _branch(
                    f"stagingBusiness{index:02d}",
                    business.title,
                    business_calculation(business),
                )
                for index, business in enumerate(BUSINESSES, 1)
            ],
        },
    }


def child_key_placeholder(business: Business) -> str:
    """Writer replacement value after disabled child workflows are created."""
    return f"<allocated:custom-action-child:{business.name}>"


def ingress_nodes(
    child_keys: Mapping[str, str] | None = None,
) -> list[dict[str, Any]]:
    """One multi-condition router followed by twelve direct subflow branches."""
    result = [ingress_router_node()]
    for index, business in enumerate(BUSINESSES, 1):
        child_key = (child_keys or {}).get(business.name, child_key_placeholder(business))
        result.append(
            {
                "identity": f"INGRESS_SUBFLOW:{business.name}",
                "type": "subflow",
                "title": f"Invoke {business.title} API Staging child",
                "upstream": "INGRESS_ROUTER",
                # NocoBase multi-conditions branch index is one-based.
                "branch": index,
                "config": {
                    "workflow": child_key,
                    # NocoBase requires an execution user for a custom-action
                    # child. This is the internally recorded creator of the
                    # staging row, not an external API parameter.
                    "context": {
                        "data": "{{$context.data}}",
                        "userId": "{{$context.data.createdById}}",
                        "roleName": None,
                    },
                },
            }
        )
    return result


def child_router_node(business: Business) -> dict[str, Any]:
    """The sole branch router inside a business custom-action child."""
    return {
        "identity": f"CHILD_ROUTER:{business.name}",
        "type": "multi-conditions",
        "title": f"{business.title}: CREATE or UPDATE",
        "upstream": None,
        "branch": None,
        "config": {
            "continueOnNoMatch": False,
            "conditions": [
                _branch(
                    f"{business.name}Create",
                    "CREATE",
                    event_calculation(business, "CREATE"),
                ),
                _branch(
                    f"{business.name}Update",
                    "UPDATE",
                    event_calculation(business, "UPDATE"),
                ),
            ],
        },
    }


def child_clone_plan(business: Business) -> dict[str, Any]:
    """The graph materialisation recipe after child/custom-action proof.

    The Create source is read live by the future writer only after identity
    verification; Update intentionally uses the approved pre-FIFO snapshot.
    This is exactly the prior reviewed source selection, merely placed below a
    custom-action child rather than a second collection trigger.
    """
    update = legacy.prepared_update_graph(business)
    return {
        "root": child_router_node(business),
        "create_branch_index": 1,
        "update_branch_index": 2,
        "create_source": {
            "live_workflow_id": business.create_source_id,
            "expected_key": business.create_source_key,
            "writer_action": "GET, validate identity, clone full graph, link root to branch 1",
        },
        "update_source": {
            "snapshot": str(business.update_snapshot),
            "expected_workflow_id": business.update_source_id,
            "expected_key": business.update_source_key,
            "clone": legacy.clone_instructions(update, "UPDATE"),
            "writer_action": "clone approved direct-update graph, link root to branch 2",
        },
    }


def ingress_title(migration_id: str = "<migration-id>") -> str:
    return f"API Staging — unified multi-branch ingress [prepared {migration_id}]"


def child_title(business: Business, migration_id: str = "<migration-id>") -> str:
    return (
        f"API Staging — {business.title} unified CREATE/UPDATE child "
        f"[prepared {migration_id}]"
    )


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _validate() -> None:
    names = [business.name for business in BUSINESSES]
    if len(names) != 12 or len(names) != len(set(names)):
        raise PlanError("expected exactly 12 uniquely named public businesses")
    tuples = {
        (SOURCE_SYSTEM, business.application_type, event,
         business.create_api_type if event == "CREATE" else business.update_api_type)
        for business in BUSINESSES
        for event in ("CREATE", "UPDATE")
    }
    if len(tuples) != len(BUSINESSES) * 2:
        raise PlanError("every source/application/event/API-type route must be unique")
    nodes = ingress_nodes()
    if len(nodes) != 13 or nodes[0]["type"] != "multi-conditions":
        raise PlanError("ingress must be one router plus twelve direct subflows")
    branches = nodes[0]["config"]["conditions"]
    if len(branches) != 12:
        raise PlanError("ingress router must have twelve branches")
    for index, node in enumerate(nodes[1:], 1):
        if node["type"] != "subflow" or node["branch"] != index:
            raise PlanError("ingress subflow branch indexes must be one-based and contiguous")
        if node["config"].get("context") != {
            "data": "{{$context.data}}",
            "userId": "{{$context.data.createdById}}",
            "roleName": None,
        }:
            raise PlanError("subflow must pass the staging record and internal execution identity")
    for business in BUSINESSES:
        router = child_router_node(business)
        conditions = router["config"]["conditions"]
        if router["type"] != "multi-conditions" or [row["title"] for row in conditions] != ["CREATE", "UPDATE"]:
            raise PlanError(f"{business.name} child must have exactly CREATE/UPDATE branches")
        if child_config() != {"type": 1, "collection": COLLECTION, "appends": []}:
            raise PlanError("custom-action child config drifted")
        # Snapshot identity/readability is verified without network access.
        legacy.prepared_update_graph(business)


def static_plan() -> dict[str, Any]:
    """Return the complete no-write architecture and writer instructions."""
    _validate()
    return {
        "format": PLAN_FORMAT,
        "architecture": ARCHITECTURE,
        "environment": "13001 development only",
        "writes_remote": False,
        "collection": COLLECTION,
        "source_system": SOURCE_SYSTEM,
        "status_transition": STATUS,
        "category": API_SOURCE_CATEGORY_TITLE,
        "business_count": len(BUSINESSES),
        "collection_event_workflow_count": 1,
        "collection_event_workflow_count_scope": "candidate topology only; legacy listeners remain until cutover",
        "candidate_collection_parent_count": 1,
        "custom_action_child_count": len(BUSINESSES),
        "ingress": {
            "title": ingress_title(),
            "type": "collection",
            "sync": False,
            "enabled_during_prepare": False,
            "config": ingress_config(),
            "nodes": ingress_nodes(),
        },
        "children": [
            {
                **asdict(business),
                "title": child_title(business),
                "type": "custom-action",
                "sync": True,
                "enabled_during_prepare": False,
                "config": child_config(),
                "subflow_key_placeholder": child_key_placeholder(business),
                "graph": child_clone_plan(business),
            }
            for business in BUSINESSES
        ],
        "required_sentinel": {
            "script": "scripts/probe_nocobase_custom_action_subflow_13001.py",
            "first_test": "enabled custom-action child with one temporary exact staging row",
            "optional_second_test": "disabled child only after enabled path passes",
            "required_evidence": [
                "parent execution delta exactly one",
                "child execution delta exactly one",
                "sentinel row marker changed only by child",
                "all temporary workflows and row removed in finally",
            ],
        },
        "runtime_acceptance_prerequisites": {
            "created_by_id": (
                "Every submitted staging row must retain createdById; the parent "
                "passes it only as the internal custom-action execution context."
            ),
            "op_role_mapping": (
                "A controlled OP-created staging row must prove the selected "
                "execution identity can run the native child graph."
            ),
            "direct_create_submitted_trigger": (
                "After a separately approved cutover, one real submitted CREATE "
                "row must execute exactly one parent and one intended child."
            ),
            "cutover_guard": (
                "This tool has no enable/delete/cutover command; its candidates "
                "remain disabled until the three checks are recorded."
            ),
        },
        "writer_sequence": [
            "Export current API Suorce workflows locally.",
            "Run the disposable custom-action subflow sentinel and record whether the child must be enabled.",
            "Create one ingress plus twelve custom-action children disabled; attach category API Suorce.",
            "Clone each business CREATE and direct UPDATE graph under its child; rewrite node-key references and verify edges while all candidates are disabled.",
            "Read back: one collection trigger, 12 subflow edges, 12 children each with exact CREATE/UPDATE branches, zero candidate executions.",
            "Only after an explicit cutover review: enable child workflows if the sentinel requires it, then enable the single ingress; do not enable any marker collection worker.",
            "Functional-test a sentinel-equivalent harmless row and one controlled real test before disabling/deleting legacy flows.",
        ],
        "prohibited": [
            "No f_dispatch_route marker write.",
            "No per-business collection-event worker.",
            "No FIFO or schedule trigger.",
            "No serial chain of twelve condition nodes.",
            "No legacy deletion before the new topology has passed acceptance.",
        ],
    }


# ---------------------------------------------------------------------------
# Disabled-candidate preparation executor
# ---------------------------------------------------------------------------
#
# This section intentionally lives next to the no-write plan instead of in the
# old marker-worker executor.  It shares the catalogue and graph validators,
# but has no marker field, timer, queue, or second collection-event listener.
# A caller must explicitly select --prepare; importing the module or printing
# the plan has no network side effects.


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _atomic_json(path: Path, value: Any) -> None:
    """Atomically persist 0600 local recovery state without credentials."""
    payload = (json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n").encode()
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def _write_new_private_json(path: Path, value: Mapping[str, Any]) -> Path:
    """Create a 0600 evidence file without ever replacing an existing one.

    A cutover needs an immutable copy of the exact successful ``--validate``
    output.  Shell redirection is easy to mistype and can overwrite a prior
    proof, so this helper uses ``O_EXCL`` and writes the JSON directly to the
    newly allocated file.  The result itself never contains the runtime token.
    """
    destination = path.expanduser().resolve()
    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload = (
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n"
    ).encode()
    try:
        descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise PreparationError(
            f"refusing to overwrite validation evidence: {destination}"
        ) from exc
    try:
        # Be explicit rather than relying on the caller's umask: the cutover
        # evidence is intentionally owner-readable only.
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except Exception:
        try:
            destination.unlink()
        except FileNotFoundError:
            pass
        raise
    return destination


def _topology_digest() -> str:
    """Fingerprint only the reviewed topology, not a live source graph."""
    return digest(
        {
            "format": PLAN_FORMAT,
            "architecture": ARCHITECTURE,
            "ingress": {
                "config": ingress_config(),
                "nodes": ingress_nodes(),
            },
            "children": [
                {
                    "business": asdict(business),
                    "config": child_config(),
                    "root": child_router_node(business),
                    "update_clone": child_clone_plan(business)["update_source"]["clone"],
                }
                for business in BUSINESSES
            ],
        }
    )


def _validate_migration_id(migration_id: str) -> None:
    if not _MIGRATION_RE.fullmatch(migration_id):
        raise PreparationError(
            "migration ID must be lowercase letters/numbers/hyphens, 6-64 characters"
        )


def _manifest_path(migration_id: str) -> Path:
    _validate_migration_id(migration_id)
    return PREPARED_ROOT / f"subflow-{migration_id}" / "manifest.json"


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PreparationError(f"cannot read {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise PreparationError(f"{path} is not a JSON object")
    return value


def _valid_sentinel_evidence(path: Path) -> dict[str, Any]:
    """Accept only a full successful disposable-probe result.

    The probe deliberately returns a small, portable result, so an operator
    can save it with shell redirection and pass the filename here.  The result
    contains no token and no persistent NocoBase object ID.
    """
    raw = _load_json(path)
    marker = raw.get("row_marker")
    if (
        raw.get("probe") != "passed"
        or raw.get("parent_execution_delta") != 1
        or raw.get("child_execution_delta") != 1
        or not isinstance(raw.get("child_enabled"), bool)
        or not isinstance(marker, str)
        or not marker.startswith("custom-action-subflow-sentinel:")
    ):
        raise PreparationError(
            "sentinel evidence is not a complete successful custom-action subflow result"
        )
    encoded = path.read_bytes()
    return {
        "state": "passed",
        "evidence_path": str(path.resolve()),
        "evidence_sha256": hashlib.sha256(encoded).hexdigest(),
        # All candidates remain disabled in this tool.  This records the
        # state that a later, separately-reviewed cutover must apply.
        "child_enable_state_at_cutover": "enabled" if raw["child_enabled"] else "disabled",
        "parent_execution_delta": 1,
        "child_execution_delta": 1,
    }


def _sentinel_state(
    evidence: Path | None, *, require_evidence: bool
) -> dict[str, Any]:
    if evidence is None:
        if require_evidence:
            raise PreparationError("--require-sentinel requires --sentinel-evidence PATH")
        return {
            "state": "not_recorded",
            "child_enable_state_at_cutover": "unknown",
            "cutover_blocked": True,
        }
    result = _valid_sentinel_evidence(evidence)
    result["cutover_blocked"] = False
    return result


def _new_manifest(migration_id: str, sentinel: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "format": PREPARATION_FORMAT,
        "environment": "13001",
        "base_url": BASE_URL,
        "migration_id": migration_id,
        "architecture": ARCHITECTURE,
        "topology_sha256": _topology_digest(),
        "created_at_utc": _now(),
        "sentinel": copy.deepcopy(dict(sentinel)),
        "runtime_acceptance_prerequisites": {
            "created_by_id": "not_yet_tested",
            "op_role_mapping": "not_yet_tested",
            "direct_create_submitted_trigger": "not_yet_tested",
        },
        "phase": "created_no_remote_write",
        "source_snapshot": None,
        "candidates": {"parent": None, "children": {}},
        "events": [],
    }


def _manifest(
    migration_id: str,
    *,
    evidence: Path | None = None,
    require_evidence: bool = False,
) -> tuple[Path, dict[str, Any]]:
    """Open/create durable preparation state, never silently changing plan."""
    path = _manifest_path(migration_id)
    if not path.exists():
        supplied = _sentinel_state(evidence, require_evidence=require_evidence)
        result = _new_manifest(migration_id, supplied)
        _atomic_json(path, result)
        return path, result
    result = _load_json(path)
    expected = {
        "format": PREPARATION_FORMAT,
        "environment": "13001",
        "base_url": BASE_URL,
        "migration_id": migration_id,
        "architecture": ARCHITECTURE,
        "topology_sha256": _topology_digest(),
    }
    if any(result.get(key) != value for key, value in expected.items()):
        raise PreparationError("existing preparation manifest does not match this reviewed topology")
    existing_sentinel = result.get("sentinel")
    if not isinstance(existing_sentinel, Mapping):
        raise PreparationError("existing preparation manifest has malformed sentinel state")
    if evidence is not None:
        supplied = _sentinel_state(evidence, require_evidence=require_evidence)
        # Upgrading not-recorded evidence is allowed.  Replacing a recorded
        # successful proof with a conflicting enable-state is not.
        old_state = existing_sentinel.get("state")
        old_enable = existing_sentinel.get("child_enable_state_at_cutover")
        new_enable = supplied.get("child_enable_state_at_cutover")
        if old_state == "passed" and old_enable != new_enable:
            raise PreparationError("new sentinel proof conflicts with the recorded child enable state")
        if old_state != "passed":
            result["sentinel"] = supplied
            _atomic_json(path, result)
    elif require_evidence and existing_sentinel.get("state") != "passed":
        raise PreparationError("successful sentinel evidence has not been recorded")
    return path, result


def _existing_manifest(
    migration_id: str, *, require_evidence: bool = False
) -> tuple[Path, dict[str, Any]]:
    """Open an existing manifest without creating local state for inspection."""
    path = _manifest_path(migration_id)
    if not path.is_file():
        raise PreparationError(f"preparation manifest does not exist: {path}")
    return _manifest(migration_id, require_evidence=require_evidence)


def _valid_runtime_evidence(
    path: Path, manifest: Mapping[str, Any]
) -> dict[str, Any]:
    """Validate post-cutover acceptance evidence without contacting 13001.

    This deliberately does not prescribe the implementation of the controlled
    test.  It binds its observations to the exact preparation's migration and
    frozen source graph, then insists on the three facts a future cutover
    guard needs: ``createdById`` survives, the OP-mapped role can execute the
    child, and one submitted CREATE runs exactly the intended direct path.
    """
    raw = _load_json(path)
    source_digest = manifest.get("source_snapshot_sha256")
    if not isinstance(source_digest, str):
        raise PreparationError("cannot record runtime evidence before sources are frozen")
    frozen_sources = manifest.get("source_snapshot")
    if not isinstance(frozen_sources, Mapping) or digest(frozen_sources) != source_digest:
        raise PreparationError("frozen source snapshot checksum drifted")
    required = {
        "format": RUNTIME_EVIDENCE_FORMAT,
        "migration_id": manifest.get("migration_id"),
        "topology_sha256": manifest.get("topology_sha256"),
        "source_snapshot_sha256": source_digest,
    }
    if any(raw.get(key) != value for key, value in required.items()):
        raise PreparationError("runtime evidence is not bound to this preparation manifest")
    outcomes = raw.get("outcomes")
    if not isinstance(outcomes, Mapping):
        raise PreparationError("runtime evidence outcomes is malformed")
    normalized: dict[str, dict[str, str | bool]] = {}
    for key in RUNTIME_ACCEPTANCE_KEYS:
        item = outcomes.get(key)
        if not isinstance(item, Mapping) or item.get("passed") is not True:
            raise PreparationError(f"runtime evidence does not prove {key}")
        observation = item.get("observation")
        if not isinstance(observation, str) or not observation.strip():
            raise PreparationError(f"runtime evidence {key} needs a non-empty observation")
        normalized[key] = {"passed": True, "observation": observation.strip()}
    encoded = path.read_bytes()
    return {
        "state": "passed",
        "evidence_path": str(path.resolve()),
        "evidence_sha256": hashlib.sha256(encoded).hexdigest(),
        "outcomes": normalized,
    }


def _sentinel_acceptance_passed(manifest: Mapping[str, Any]) -> bool:
    """Whether a later cutover has a documented child enable-state decision."""
    sentinel = manifest.get("sentinel")
    return (
        isinstance(sentinel, Mapping)
        and sentinel.get("state") == "passed"
        and sentinel.get("child_enable_state_at_cutover") in {"enabled", "disabled"}
    )


def record_runtime_evidence(migration_id: str, evidence: Path) -> dict[str, Any]:
    """Persist validated post-cutover evidence locally; it never uses HTTP."""
    path, manifest = _existing_manifest(migration_id)
    if not _sentinel_acceptance_passed(manifest):
        raise PreparationError(
            "cannot record runtime acceptance before successful sentinel evidence "
            "records the child enable state"
        )
    accepted = _valid_runtime_evidence(evidence, manifest)
    existing = manifest.get("runtime_evidence")
    if isinstance(existing, Mapping) and existing.get("state") == "passed":
        if existing.get("evidence_sha256") != accepted["evidence_sha256"]:
            raise PreparationError("different runtime evidence is already recorded for this migration")
        return {
            "writes_remote": False,
            "writes_local": False,
            "migration_id": migration_id,
            "manifest": str(path),
            "topology_sha256": manifest["topology_sha256"],
            "source_snapshot_sha256": manifest["source_snapshot_sha256"],
            "runtime_acceptance_prerequisites": manifest["runtime_acceptance_prerequisites"],
            "runtime_evidence": existing,
            "cutover_prerequisites_passed": _cutover_prerequisites_passed(manifest),
        }
    manifest["runtime_evidence"] = accepted
    manifest["runtime_acceptance_prerequisites"] = {
        key: "passed" for key in RUNTIME_ACCEPTANCE_KEYS
    }
    _checkpoint(path, manifest, "runtime_acceptance_evidence_recorded", {
        "evidence_sha256": accepted["evidence_sha256"],
        "outcomes": list(RUNTIME_ACCEPTANCE_KEYS),
    })
    return {
        "writes_remote": False,
        "writes_local": True,
        "migration_id": migration_id,
        "manifest": str(path),
        "topology_sha256": manifest["topology_sha256"],
        "source_snapshot_sha256": manifest["source_snapshot_sha256"],
        "runtime_acceptance_prerequisites": manifest["runtime_acceptance_prerequisites"],
        "runtime_evidence": accepted,
        "cutover_prerequisites_passed": _cutover_prerequisites_passed(manifest),
    }


def _runtime_acceptance_passed(manifest: Mapping[str, Any]) -> bool:
    state = manifest.get("runtime_acceptance_prerequisites")
    return isinstance(state, Mapping) and all(state.get(key) == "passed" for key in RUNTIME_ACCEPTANCE_KEYS)


def _cutover_prerequisites_passed(manifest: Mapping[str, Any]) -> bool:
    """One boolean for a later read-only cutover guard; this script never cuts over."""
    return _sentinel_acceptance_passed(manifest) and _runtime_acceptance_passed(manifest)


def _checkpoint(path: Path, manifest: dict[str, Any], action: str, details: Mapping[str, Any]) -> None:
    """Persist a bounded append-only local operation journal."""
    manifest["updated_at_utc"] = _now()
    events = manifest.setdefault("events", [])
    if not isinstance(events, list):
        raise PreparationError("manifest events is malformed")
    events.append({"at_utc": manifest["updated_at_utc"], "action": action,
                   "details": copy.deepcopy(dict(details))})
    manifest["events"] = events[-500:]
    _atomic_json(path, manifest)


def _require_api() -> RootNocoBaseApi:
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        raise PreparationError("NOCOBASE_TOKEN is required for remote inspect/prepare")
    # The hard-coded 13001 endpoint is intentional: this tool must never be
    # pointed at 13000 or another NocoBase instance by an environment variable.
    return RootNocoBaseApi(BASE_URL, token)


def _workflow(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    try:
        row = dict(api.get_workflow(workflow_id))
    except ApiError as exc:
        raise PreparationError(f"cannot read workflow {workflow_id}") from exc
    if row.get("id") != workflow_id or not isinstance(row.get("nodes"), list):
        raise PreparationError(f"workflow {workflow_id} readback is incomplete")
    return row


def _workflows_by_title(api: RootNocoBaseApi, title: str) -> list[dict[str, Any]]:
    query = urllib.parse.urlencode(
        [("page", "1"), ("pageSize", "100"), ("filter[title]", title)]
    )
    try:
        rows = api.request("GET", "/api/workflows:list?" + query)
    except ApiError as exc:
        raise PreparationError(f"cannot query workflow title {title!r}") from exc
    ids = sorted(
        {
            int(row["id"])
            for row in (rows or [])
            if isinstance(row, Mapping)
            and row.get("title") == title
            and isinstance(row.get("id"), int)
        }
    )
    if len(ids) > 1:
        raise PreparationError(f"multiple workflows have deterministic title {title!r}: {ids}")
    return [_workflow(api, workflow_id) for workflow_id in ids]


def _candidate_categories(api: RootNocoBaseApi, workflow_id: int) -> set[int]:
    query = urllib.parse.urlencode(
        [("filterByTk", str(workflow_id)), ("appends[]", "categories")]
    )
    try:
        row = api.request("GET", "/api/workflows:get?" + query)
    except ApiError as exc:
        raise PreparationError(f"cannot read categories for workflow {workflow_id}") from exc
    if not isinstance(row, Mapping) or row.get("id") != workflow_id:
        raise PreparationError(f"workflow {workflow_id} category readback is invalid")
    result: set[int] = set()
    categories = row.get("categories") or []
    if not isinstance(categories, list):
        raise PreparationError(f"workflow {workflow_id} categories are malformed")
    for item in categories:
        value = item.get("id") if isinstance(item, Mapping) else item
        if isinstance(value, int):
            result.add(value)
        elif isinstance(value, str) and value.isdigit():
            result.add(int(value))
    return result


def _ensure_category(
    api: RootNocoBaseApi,
    workflow_id: int,
    *,
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> None:
    try:
        category_id = resolve_workflow_category_id(api, API_SOURCE_CATEGORY_TITLE)
    except ApiError as exc:
        raise PreparationError("cannot resolve API Suorce category") from exc
    current = _candidate_categories(api, workflow_id)
    if category_id in current:
        return
    values = {"categories": sorted(current | {category_id})}
    try:
        api.request("POST", f"/api/workflows:update?filterByTk={workflow_id}", values)
    except ApiError as exc:
        if category_id not in _candidate_categories(api, workflow_id):
            raise PreparationError(
                f"category update outcome is unknown for workflow {workflow_id}; rerun resume"
            ) from exc
        checkpoint("category_reconciled_after_timeout", {
            "workflow_id": workflow_id,
            "category_id": category_id,
        })
        return
    if category_id not in _candidate_categories(api, workflow_id):
        raise PreparationError(f"API Suorce category did not persist for workflow {workflow_id}")
    checkpoint("category_attached", {"workflow_id": workflow_id, "category_id": category_id})


def _assert_api_source_category(api: RootNocoBaseApi, workflow_id: int) -> int:
    """Require the reviewed category on every candidate during readback.

    A title is not enough: a partially completed timeout recovery could leave
    an otherwise valid disabled graph outside the operational API Suorce
    grouping.  This helper is read-only and is used by validation as well as
    the final reconciliation readback.
    """
    try:
        category_id = resolve_workflow_category_id(api, API_SOURCE_CATEGORY_TITLE)
    except ApiError as exc:
        raise PreparationError("cannot resolve API Suorce category") from exc
    if category_id not in _candidate_categories(api, workflow_id):
        raise PreparationError(
            f"workflow {workflow_id} is not attached to API Suorce category"
        )
    return category_id


def _assert_parent_candidate(row: Mapping[str, Any], title: str) -> None:
    if (
        row.get("title") != title
        or row.get("type") != "collection"
        or row.get("sync") is not False
        or row.get("enabled") is not False
        or row.get("config") != ingress_config()
    ):
        raise PreparationError(f"parent candidate identity/state/config drifted: {row.get('id')}")


def _assert_child_candidate(row: Mapping[str, Any], title: str) -> None:
    if (
        row.get("title") != title
        or row.get("type") != "custom-action"
        or row.get("sync") is not True
        or row.get("enabled") is not False
        or row.get("config") != child_config()
    ):
        raise PreparationError(f"child candidate identity/state/config drifted: {row.get('id')}")


def _create_or_find_candidate(
    api: RootNocoBaseApi,
    *,
    title: str,
    workflow_type: str,
    sync: bool,
    config: Mapping[str, Any],
    validator: Callable[[Mapping[str, Any], str], None],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Create once, or reconcile a timeout through exact title discovery."""
    found = _workflows_by_title(api, title)
    if found:
        candidate = found[0]
    else:
        try:
            created = api.request(
                "POST",
                "/api/workflows:create",
                {
                    "title": title,
                    "type": workflow_type,
                    "sync": sync,
                    "enabled": False,
                    "config": copy.deepcopy(dict(config)),
                },
            )
        except ApiError as exc:
            found = _workflows_by_title(api, title)
            if not found:
                raise PreparationError(
                    f"candidate create outcome is unknown for {title!r}; rerun after connectivity recovers"
                ) from exc
            candidate = found[0]
            checkpoint("candidate_create_reconciled_after_timeout", {
                "workflow_id": candidate["id"], "title": title,
            })
        else:
            if not isinstance(created, Mapping) or not isinstance(created.get("id"), int):
                raise PreparationError(f"candidate create returned no ID for {title!r}")
            candidate = _workflow(api, int(created["id"]))
            checkpoint("candidate_created", {"workflow_id": candidate["id"], "title": title})
    validator(candidate, title)
    _ensure_category(api, int(candidate["id"]), checkpoint=checkpoint)
    return candidate


def _node_matches(workflow: Mapping[str, Any], title: str) -> list[dict[str, Any]]:
    return [
        dict(node)
        for node in (workflow.get("nodes") or [])
        if isinstance(node, Mapping) and node.get("title") == title
    ]


def _node_by_title(
    workflow: Mapping[str, Any], *, title: str, expected_type: str
) -> dict[str, Any] | None:
    found = _node_matches(workflow, title)
    if len(found) > 1:
        raise PreparationError(
            f"workflow {workflow.get('id')} has duplicate deterministic node title {title!r}"
        )
    if not found:
        return None
    if found[0].get("type") != expected_type:
        raise PreparationError(
            f"node {title!r} type drifted: {found[0].get('type')!r} != {expected_type!r}"
        )
    return found[0]


def _ensure_node(
    api: RootNocoBaseApi,
    workflow_id: int,
    nodes: dict[str, dict[str, Any]],
    *,
    identity: str,
    title: str,
    node_type: str,
    config: Mapping[str, Any],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Create a deterministic node once; do not retry an ambiguous POST."""
    current = nodes.get(identity)
    if current is not None:
        if current.get("title") != title or current.get("type") != node_type:
            raise PreparationError(f"candidate node identity drifted: {identity}")
        return current
    try:
        created = api.create_node(
            {
                "workflowId": workflow_id,
                "type": node_type,
                "title": title,
                "config": copy.deepcopy(dict(config)),
            }
        )
    except ApiError as exc:
        # A mutation might have committed just before a socket timeout.  A
        # single exact-title read makes restart safe and avoids duplicate rows.
        refreshed = _workflow(api, workflow_id)
        resolved = _node_by_title(refreshed, title=title, expected_type=node_type)
        if resolved is None:
            raise PreparationError(
                f"node create outcome is unknown for {title!r}; rerun after checking 13001"
            ) from exc
        nodes[identity] = resolved
        checkpoint("node_create_reconciled_after_timeout", {
            "workflow_id": workflow_id, "node_id": resolved.get("id"), "identity": identity,
        })
        return resolved
    if not isinstance(created, Mapping) or not isinstance(created.get("id"), int) or not isinstance(created.get("key"), str):
        raise PreparationError(f"node create returned no id/key for {title!r}")
    result = dict(created)
    nodes[identity] = result
    checkpoint("node_created", {
        "workflow_id": workflow_id,
        "node_id": result["id"],
        "node_key": result["key"],
        "identity": identity,
    })
    return result


def _patch_node(
    api: RootNocoBaseApi,
    workflow_id: int,
    node: dict[str, Any],
    values: Mapping[str, Any],
    *,
    checkpoint: Callable[[str, Mapping[str, Any]], None],
    reason: str,
) -> None:
    """Safely apply one exact disabled-candidate node patch.

    After a transport ``ApiError``, the function always reads the exact node
    before doing anything else.  It accepts a committed target state, retries
    only when the fields owned by this patch remain exactly as observed before
    the first request, and refuses a partial or divergent state.  That keeps
    retrying safe for a disabled candidate without ever treating a flow-node
    update like a create operation.
    """
    if all(node.get(key) == value for key, value in values.items()):
        return
    node_id = node.get("id")
    if not isinstance(node_id, int):
        raise PreparationError(f"node {reason} has no ID")
    # Do not let a later concurrent or partial mutation masquerade as an
    # unchanged timeout.  Only the exact fields this patch owns participate in
    # this comparison; NocoBase may update unrelated metadata while serving
    # the readback.
    before = {key: copy.deepcopy(node.get(key)) for key in values}
    target = copy.deepcopy(dict(values))
    for attempt in range(1, PATCH_MAX_ATTEMPTS + 1):
        try:
            api.update_node(node_id, copy.deepcopy(target))
        except ApiError as exc:
            refreshed = _workflow(api, workflow_id)
            after = next(
                (raw for raw in refreshed["nodes"] if raw.get("id") == node_id),
                None,
            )
            if not isinstance(after, Mapping):
                raise PreparationError(
                    f"node {node_id} {reason} disappeared after API error; refusing retry"
                ) from exc
            if all(after.get(key) == value for key, value in target.items()):
                node.update(copy.deepcopy(dict(after)))
                checkpoint("node_patch_reconciled_after_timeout", {
                    "workflow_id": workflow_id,
                    "node_id": node_id,
                    "reason": reason,
                    "attempt": attempt,
                })
                return
            if not all(after.get(key) == value for key, value in before.items()):
                raise PreparationError(
                    f"node {node_id} {reason} diverged after API error; refusing retry"
                ) from exc
            node.update(copy.deepcopy(dict(after)))
            if attempt == PATCH_MAX_ATTEMPTS:
                raise PreparationError(
                    f"node {node_id} {reason} remained unchanged after "
                    f"{PATCH_MAX_ATTEMPTS} bounded attempts; rerun after checking 13001"
                ) from exc
            checkpoint("node_patch_retry_after_unchanged_timeout", {
                "workflow_id": workflow_id,
                "node_id": node_id,
                "reason": reason,
                "attempt": attempt,
                "max_attempts": PATCH_MAX_ATTEMPTS,
            })
            continue
        node.update(copy.deepcopy(target))
        checkpoint("node_patched", {
            "workflow_id": workflow_id,
            "node_id": node_id,
            "reason": reason,
            "attempt": attempt,
        })
        return


def _assert_source_graph(graph: Mapping[str, Any], business: Business, kind: str) -> None:
    expected_id = business.create_source_id if kind == "CREATE" else business.update_source_id
    expected_key = business.create_source_key if kind == "CREATE" else business.update_source_key
    if graph.get("id") != expected_id or graph.get("key") != expected_key:
        raise PreparationError(f"{business.name} {kind} source identity drifted")
    try:
        legacy._node_index(graph)
    except legacy.PlanError as exc:
        raise PreparationError(f"{business.name} {kind} source graph is unsafe to clone") from exc
    # The former marker topology stored this field on workflow *triggers*.
    # A node-level occurrence would make a child mutate/observe routing state,
    # which is expressly excluded from the direct-subflow design.
    if any(
        legacy.ROUTE_FIELD in _canonical(node.get("config") or {})
        for node in graph.get("nodes") or []
        if isinstance(node, Mapping)
    ):
        raise PreparationError(
            f"{business.name} {kind} source still contains marker routing in a node config"
        )


def _capture_sources(api: RootNocoBaseApi) -> dict[str, Any]:
    """Freeze every source before the first candidate mutation."""
    result: dict[str, Any] = {"create": {}, "update": {}}
    for business in BUSINESSES:
        create = _workflow(api, business.create_source_id)
        if (
            create.get("type") != "collection"
            or not isinstance(create.get("config"), Mapping)
            or create["config"].get("collection") != COLLECTION
        ):
            raise PreparationError(f"{business.name} live CREATE source is not the expected staging workflow")
        _assert_source_graph(create, business, "CREATE")
        update = legacy.prepared_update_graph(business)
        _assert_source_graph(update, business, "UPDATE")
        result["create"][business.name] = copy.deepcopy(create)
        result["update"][business.name] = copy.deepcopy(update)
    return result


def _frozen_graph(manifest: Mapping[str, Any], business: Business, kind: str) -> dict[str, Any]:
    snapshot = manifest.get("source_snapshot")
    if not isinstance(snapshot, Mapping) or not isinstance(snapshot.get(kind.lower()), Mapping):
        raise PreparationError("manifest has no frozen source snapshot")
    graph = snapshot[kind.lower()].get(business.name)
    if not isinstance(graph, Mapping):
        raise PreparationError(f"manifest lacks {business.name} {kind} source")
    result = copy.deepcopy(dict(graph))
    _assert_source_graph(result, business, kind)
    return result


def _clone_node_title(prefix: str, source: Mapping[str, Any]) -> str:
    return f"{prefix}/{source['key']} — {source.get('title') or source['type']}"


def _child_specs(
    manifest: Mapping[str, Any], business: Business
) -> list[dict[str, Any]]:
    """Build deterministic graph specs for a single custom-action child."""
    result: list[dict[str, Any]] = [
        {
            "identity": "ROUTER",
            "title": str(child_router_node(business)["title"]),
            "type": "multi-conditions",
            "initial_config": copy.deepcopy(dict(child_router_node(business)["config"])),
            "config_source": None,
            "upstream": None,
            "branch": None,
            "prefix": None,
            "source_key": None,
        }
    ]
    for prefix in ("CREATE", "UPDATE"):
        graph = _frozen_graph(manifest, business, prefix)
        indexed = legacy._node_index(graph)
        roots = [node for node in indexed.values() if node.get("upstreamId") in (None, "")]
        if len(roots) != 1:
            raise PreparationError(f"{business.name} {prefix} source has no unique root")
        for source in sorted(indexed.values(), key=lambda row: str(row["key"])):
            source_key = str(source["key"])
            source_upstream = source.get("upstreamId")
            if source_upstream in (None, ""):
                upstream, branch = "ROUTER", 1 if prefix == "CREATE" else 2
            else:
                upstream = f"{prefix}:{indexed[int(source_upstream)]['key']}"
                branch = source.get("branchIndex")
            result.append(
                {
                    "identity": f"{prefix}:{source_key}",
                    "title": _clone_node_title(prefix, source),
                    "type": str(source["type"]),
                    "initial_config": copy.deepcopy(dict(source.get("config") or {})),
                    "config_source": copy.deepcopy(dict(source.get("config") or {})),
                    "upstream": upstream,
                    "branch": branch,
                    "prefix": prefix,
                    "source_key": source_key,
                }
            )
    titles = [str(spec["title"]) for spec in result]
    if len(titles) != len(set(titles)):
        raise PreparationError(f"{business.name} child deterministic node titles are not unique")
    return result


def _actual_nodes(
    workflow: Mapping[str, Any], specs: Iterable[Mapping[str, Any]]
) -> dict[str, dict[str, Any]]:
    specs = list(specs)
    expected = {str(spec["title"]): spec for spec in specs}
    unexpected = [
        raw.get("title")
        for raw in (workflow.get("nodes") or [])
        if isinstance(raw, Mapping) and raw.get("title") not in expected
    ]
    if unexpected:
        raise PreparationError(
            f"candidate {workflow.get('id')} has unexpected nodes: {unexpected[:3]!r}"
        )
    result: dict[str, dict[str, Any]] = {}
    for spec in specs:
        node = _node_by_title(
            workflow, title=str(spec["title"]), expected_type=str(spec["type"])
        )
        if node is not None:
            result[str(spec["identity"])] = node
    return result


def _desired_child_configs(
    specs: Iterable[Mapping[str, Any]], nodes: Mapping[str, Mapping[str, Any]]
) -> dict[str, dict[str, Any]]:
    specs_list = list(specs)
    result: dict[str, dict[str, Any]] = {}
    for spec in specs_list:
        identity = str(spec["identity"])
        source_config = spec.get("config_source")
        if source_config is None:
            result[identity] = copy.deepcopy(dict(spec["initial_config"]))
            continue
        prefix = str(spec["prefix"])
        keymap = {
            str(other["source_key"]): str(nodes[str(other["identity"])]["key"])
            for other in specs_list
            if other.get("prefix") == prefix and other.get("source_key") is not None
        }
        try:
            rewritten = legacy._replace_refs(source_config, keymap)
        except legacy.PlanError as exc:
            raise PreparationError(f"cannot rewrite cloned references for {identity}") from exc
        if not isinstance(rewritten, Mapping):
            raise PreparationError(f"rewritten config for {identity} is not an object")
        result[identity] = copy.deepcopy(dict(rewritten))
    return result


def _references_resolve(workflow: Mapping[str, Any]) -> bool:
    keys = {str(node.get("key")) for node in workflow.get("nodes") or []}
    for node in workflow.get("nodes") or []:
        if not isinstance(node, Mapping):
            return False
        for text in legacy._walk_strings(node.get("config") or {}):
            for _scope, key in legacy._REF_RE.findall(text):
                if key not in keys:
                    return False
    return True


def _validate_child(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    business: Business,
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    row = _workflow(api, int(candidate["id"]))
    _assert_child_candidate(row, str(candidate["title"]))
    category_id = _assert_api_source_category(api, int(row["id"]))
    specs = _child_specs(manifest, business)
    actual = _actual_nodes(row, specs)
    if len(actual) != len(specs) or len(row["nodes"]) != len(specs):
        raise PreparationError(
            f"{business.name} child is incomplete: {len(actual)}/{len(specs)} nodes"
        )
    desired = _desired_child_configs(specs, actual)
    for spec in specs:
        identity = str(spec["identity"])
        node = actual[identity]
        if node.get("config") != desired[identity]:
            raise PreparationError(f"{business.name} node config drifted: {spec['title']!r}")
        upstream = spec.get("upstream")
        if upstream is None:
            if node.get("upstreamId") not in (None, ""):
                raise PreparationError(f"{business.name} router unexpectedly has an upstream")
            continue
        parent = actual[str(upstream)]
        if node.get("upstreamId") != parent["id"] or node.get("branchIndex") != spec.get("branch"):
            raise PreparationError(f"{business.name} graph edge drifted: {spec['title']!r}")
        if spec.get("branch") is None and parent.get("downstreamId") != node["id"]:
            raise PreparationError(f"{business.name} continuation edge drifted: {spec['title']!r}")
    if not _references_resolve(row):
        raise PreparationError(f"{business.name} child has unresolved node-key references")
    router = actual["ROUTER"]
    conditions = router.get("config", {}).get("conditions") if isinstance(router.get("config"), Mapping) else None
    if (
        router.get("type") != "multi-conditions"
        or not isinstance(conditions, list)
        or [condition.get("title") for condition in conditions if isinstance(condition, Mapping)]
        != ["CREATE", "UPDATE"]
    ):
        raise PreparationError(f"{business.name} child router is not the expected CREATE/UPDATE split")
    marker_write = any(
        legacy.ROUTE_FIELD in _canonical(node.get("config") or {})
        for node in row["nodes"]
        if isinstance(node, Mapping)
    )
    if marker_write:
        raise PreparationError(f"{business.name} child contains forbidden marker routing")
    return {
        "id": row["id"],
        "key": row.get("key"),
        "title": row.get("title"),
        "type": "custom-action",
        "enabled": row.get("enabled"),
        "executed": row.get("executed"),
        "node_count": len(row["nodes"]),
        "router_type": "multi-conditions",
        "event_branches": ["CREATE", "UPDATE"],
        "marker_write": False,
        "category": API_SOURCE_CATEGORY_TITLE,
        "category_id": category_id,
        "child_enable_state_at_cutover": manifest["sentinel"]["child_enable_state_at_cutover"],
    }


def _reconcile_child(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    business: Business,
    manifest: Mapping[str, Any],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Build/recover one disabled child with only three graph passes.

    Successful flow-node writes use their returned node key directly.  This is
    much cheaper than a GET after every node.  Only ambiguous timeouts force a
    readback, and every phase finishes with a full graph readback.
    """
    workflow_id = int(candidate["id"])
    _assert_child_candidate(_workflow(api, workflow_id), str(candidate["title"]))
    specs = _child_specs(manifest, business)
    nodes = _actual_nodes(_workflow(api, workflow_id), specs)
    # Pass 1: obtain every allocated candidate key.
    for spec in specs:
        _ensure_node(
            api,
            workflow_id,
            nodes,
            identity=str(spec["identity"]),
            title=str(spec["title"]),
            node_type=str(spec["type"]),
            config=dict(spec["initial_config"]),
            checkpoint=checkpoint,
        )
    nodes = _actual_nodes(_workflow(api, workflow_id), specs)
    if len(nodes) != len(specs):
        raise PreparationError(f"{business.name} child node creation did not converge")
    # Pass 2: now every old key can be replaced by a candidate key.
    desired = _desired_child_configs(specs, nodes)
    for spec in specs:
        identity = str(spec["identity"])
        _patch_node(
            api,
            workflow_id,
            nodes[identity],
            {"config": desired[identity]},
            checkpoint=checkpoint,
            reason=f"config:{business.name}:{identity}",
        )
    # Pass 3: link one ordinary/branch edge at a time.  Keeping config and
    # edge updates separate avoids the 13001 multi-field flow_nodes timeout
    # seen in the discarded marker candidate.
    for spec in specs:
        upstream = spec.get("upstream")
        if upstream is None:
            continue
        parent = nodes[str(upstream)]
        child = nodes[str(spec["identity"])]
        _patch_node(
            api,
            workflow_id,
            child,
            {"upstreamId": parent["id"], "branchIndex": spec.get("branch")},
            checkpoint=checkpoint,
            reason=f"edge:{business.name}:{spec['identity']}",
        )
        if spec.get("branch") is None:
            _patch_node(
                api,
                workflow_id,
                parent,
                {"downstreamId": child["id"]},
                checkpoint=checkpoint,
                reason=f"continuation:{business.name}:{upstream}->{spec['identity']}",
            )
    return _validate_child(api, candidate, business=business, manifest=manifest)


def _parent_specs(child_keys: Mapping[str, str]) -> list[dict[str, Any]]:
    return ingress_nodes(child_keys)


def _validate_parent(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    child_keys: Mapping[str, str],
) -> dict[str, Any]:
    row = _workflow(api, int(candidate["id"]))
    _assert_parent_candidate(row, str(candidate["title"]))
    category_id = _assert_api_source_category(api, int(row["id"]))
    specs = _parent_specs(child_keys)
    actual = _actual_nodes(row, specs)
    if len(actual) != len(specs) or len(row["nodes"]) != len(specs):
        raise PreparationError(f"parent candidate is incomplete: {len(actual)}/{len(specs)} nodes")
    for spec in specs:
        identity = str(spec["identity"])
        node = actual[identity]
        if node.get("config") != spec["config"]:
            raise PreparationError(f"parent node config drifted: {spec['title']!r}")
        upstream = spec.get("upstream")
        if upstream is None:
            if node.get("upstreamId") not in (None, ""):
                raise PreparationError("parent router unexpectedly has an upstream")
            continue
        parent = actual[str(upstream)]
        if node.get("upstreamId") != parent["id"] or node.get("branchIndex") != spec.get("branch"):
            raise PreparationError(f"parent graph edge drifted: {spec['title']!r}")
    router = actual["INGRESS_ROUTER"]
    conditions = router.get("config", {}).get("conditions") if isinstance(router.get("config"), Mapping) else None
    subflows = [node for identity, node in actual.items() if identity.startswith("INGRESS_SUBFLOW:")]
    if (
        router.get("type") != "multi-conditions"
        or not isinstance(conditions, list)
        or len(conditions) != len(BUSINESSES)
        or len(subflows) != len(BUSINESSES)
        or any(node.get("upstreamId") != router["id"] for node in subflows)
    ):
        raise PreparationError("parent is not the required direct 12-branch multi-condition router")
    marker_write = any(
        legacy.ROUTE_FIELD in _canonical(node.get("config") or {})
        for node in row["nodes"]
        if isinstance(node, Mapping)
    )
    if marker_write:
        raise PreparationError("parent contains forbidden marker routing")
    return {
        "id": row["id"], "key": row.get("key"), "title": row.get("title"), "type": "collection",
        "enabled": row.get("enabled"), "executed": row.get("executed"),
        "node_count": len(row["nodes"]),
        "router_type": "multi-conditions",
        "business_branch_count": len(BUSINESSES),
        "collection_event_workflow_count": 1,
        "serial_condition_chain": False,
        "marker_write": False,
        "category": API_SOURCE_CATEGORY_TITLE,
        "category_id": category_id,
    }


def _reconcile_parent(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    child_keys: Mapping[str, str],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    workflow_id = int(candidate["id"])
    _assert_parent_candidate(_workflow(api, workflow_id), str(candidate["title"]))
    specs = _parent_specs(child_keys)
    nodes = _actual_nodes(_workflow(api, workflow_id), specs)
    for spec in specs:
        _ensure_node(
            api,
            workflow_id,
            nodes,
            identity=str(spec["identity"]),
            title=str(spec["title"]),
            node_type=str(spec["type"]),
            config=dict(spec["config"]),
            checkpoint=checkpoint,
        )
    nodes = _actual_nodes(_workflow(api, workflow_id), specs)
    if len(nodes) != len(specs):
        raise PreparationError("parent node creation did not converge")
    for spec in specs:
        identity = str(spec["identity"])
        _patch_node(
            api, workflow_id, nodes[identity], {"config": spec["config"]},
            checkpoint=checkpoint, reason=f"parent-config:{identity}",
        )
    for spec in specs:
        upstream = spec.get("upstream")
        if upstream is None:
            continue
        parent = nodes[str(upstream)]
        child = nodes[str(spec["identity"])]
        _patch_node(
            api,
            workflow_id,
            child,
            {"upstreamId": parent["id"], "branchIndex": spec.get("branch")},
            checkpoint=checkpoint,
            reason=f"parent-edge:{spec['identity']}",
        )
    return _validate_parent(api, candidate, child_keys=child_keys)


def _prepare_source_snapshot(
    api: RootNocoBaseApi,
    manifest_path: Path,
    manifest: dict[str, Any],
) -> None:
    if manifest.get("source_snapshot") is not None:
        # Validate the frozen content before relying on it on a resume.
        stored_digest = manifest.get("source_snapshot_sha256")
        if not isinstance(stored_digest, str) or stored_digest != digest(manifest["source_snapshot"]):
            raise PreparationError("frozen source snapshot checksum drifted")
        for business in BUSINESSES:
            _frozen_graph(manifest, business, "CREATE")
            _frozen_graph(manifest, business, "UPDATE")
        return
    snapshot = _capture_sources(api)
    manifest["source_snapshot"] = snapshot
    manifest["source_snapshot_sha256"] = digest(snapshot)
    manifest["phase"] = "sources_frozen_before_remote_candidate_write"
    _checkpoint(manifest_path, manifest, "source_snapshot_frozen", {
        "create_workflow_count": len(snapshot["create"]),
        "update_workflow_count": len(snapshot["update"]),
    })


def _assert_no_unmanifested_candidates(api: RootNocoBaseApi, migration_id: str) -> None:
    """Never adopt a remote candidate if its frozen source manifest was lost."""
    titles = [ingress_title(migration_id)] + [
        child_title(business, migration_id) for business in BUSINESSES
    ]
    found: list[int] = []
    for title in titles:
        found.extend(int(row["id"]) for row in _workflows_by_title(api, title))
    if found:
        raise PreparationError(
            "matching remote candidate exists but this manifest has no frozen source snapshot; "
            f"refusing to adopt workflow IDs {sorted(set(found))}"
        )


def _candidate_entry(manifest: dict[str, Any], business: Business) -> dict[str, Any] | None:
    candidates = manifest.get("candidates")
    if not isinstance(candidates, Mapping):
        raise PreparationError("manifest candidates is malformed")
    children = candidates.get("children")
    if not isinstance(children, Mapping):
        raise PreparationError("manifest candidate children is malformed")
    value = children.get(business.name)
    return dict(value) if isinstance(value, Mapping) else None


def _child_keys_from_manifest(manifest: Mapping[str, Any]) -> dict[str, str]:
    candidates = manifest.get("candidates")
    children = candidates.get("children") if isinstance(candidates, Mapping) else None
    if not isinstance(children, Mapping):
        return {}
    result: dict[str, str] = {}
    for business in BUSINESSES:
        row = children.get(business.name)
        if isinstance(row, Mapping) and isinstance(row.get("key"), str) and row["key"]:
            result[business.name] = str(row["key"])
    return result


def inspect_preparation(migration_id: str) -> dict[str, Any]:
    """Read a preparation state only.  It never modifies 13001."""
    path, manifest = _existing_manifest(migration_id)
    api = _require_api()
    result: dict[str, Any] = {
        "writes_remote": False,
        "environment": "13001",
        "migration_id": migration_id,
        "manifest": str(path),
        "phase": manifest.get("phase"),
        "sentinel": manifest.get("sentinel"),
        "parent": None,
        "children": {},
    }
    parent_rows = _workflows_by_title(api, ingress_title(migration_id))
    if parent_rows:
        parent = parent_rows[0]
        _assert_parent_candidate(parent, ingress_title(migration_id))
        result["parent"] = {
            "id": parent["id"], "enabled": parent.get("enabled"),
            "node_count": len(parent.get("nodes") or []),
            "expected_node_count": 13,
        }
    for business in BUSINESSES:
        rows = _workflows_by_title(api, child_title(business, migration_id))
        if not rows:
            result["children"][business.name] = {"present": False}
            continue
        child = rows[0]
        _assert_child_candidate(child, child_title(business, migration_id))
        expected = _child_specs(manifest, business) if manifest.get("source_snapshot") else []
        result["children"][business.name] = {
            "present": True,
            "id": child["id"],
            "enabled": child.get("enabled"),
            "node_count": len(child.get("nodes") or []),
            "expected_node_count": len(expected) if expected else None,
        }
    return result


def prepare_disabled_candidates(
    migration_id: str,
    *,
    business_name: str | None = None,
    sentinel_evidence: Path | None = None,
    require_sentinel: bool = False,
) -> dict[str, Any]:
    """Create/recover only disabled candidates; never enable/delete/cut over.

    ``business_name`` is a deliberate performance/safety valve: it lets an
    operator materialise one large source graph per execution.  The direct
    parent is created only when all twelve disabled children have a validated
    graph and an allocated workflow key.
    """
    path, manifest = _manifest(
        migration_id, evidence=sentinel_evidence, require_evidence=require_sentinel
    )
    api = _require_api()
    if manifest.get("source_snapshot") is None:
        _assert_no_unmanifested_candidates(api, migration_id)
    _prepare_source_snapshot(api, path, manifest)

    selected = [
        business for business in BUSINESSES
        if business_name is None or business.name == business_name
    ]
    if not selected:
        valid = ", ".join(business.name for business in BUSINESSES)
        raise PreparationError(f"unknown --business {business_name!r}; expected one of: {valid}")

    def checkpoint(action: str, details: Mapping[str, Any]) -> None:
        _checkpoint(path, manifest, action, details)

    candidates = manifest.setdefault("candidates", {"parent": None, "children": {}})
    if not isinstance(candidates, dict):
        raise PreparationError("manifest candidates is malformed")
    children = candidates.setdefault("children", {})
    if not isinstance(children, dict):
        raise PreparationError("manifest children is malformed")

    completed: dict[str, Any] = {}
    for business in selected:
        candidate = _create_or_find_candidate(
            api,
            title=child_title(business, migration_id),
            workflow_type="custom-action",
            sync=True,
            config=child_config(),
            validator=_assert_child_candidate,
            checkpoint=checkpoint,
        )
        validated = _reconcile_child(
            api, candidate, business=business, manifest=manifest, checkpoint=checkpoint
        )
        children[business.name] = validated
        manifest["phase"] = "partial_disabled_children"
        checkpoint("child_validated_disabled", {
            "business": business.name,
            "workflow_id": validated["id"],
            "node_count": validated["node_count"],
        })
        completed[business.name] = validated

    child_keys = _child_keys_from_manifest(manifest)
    parent_result: dict[str, Any] | None = None
    if len(child_keys) == len(BUSINESSES):
        # Re-read all children before wiring the parent: no stale local key can
        # point a direct Subflow branch at the wrong business.
        for business in BUSINESSES:
            rows = _workflows_by_title(api, child_title(business, migration_id))
            if len(rows) != 1:
                raise PreparationError(
                    f"recorded child candidate disappeared or became ambiguous: {business.name}"
                )
            child = rows[0]
            current = _validate_child(api, child, business=business, manifest=manifest)
            children[business.name] = current
            child_keys[business.name] = str(current["key"])
        parent = _create_or_find_candidate(
            api,
            title=ingress_title(migration_id),
            workflow_type="collection",
            sync=False,
            config=ingress_config(),
            validator=_assert_parent_candidate,
            checkpoint=checkpoint,
        )
        parent_result = _reconcile_parent(
            api, parent, child_keys=child_keys, checkpoint=checkpoint
        )
        candidates["parent"] = parent_result
        manifest["phase"] = "prepared_disabled"
        manifest["prepared_at_utc"] = _now()
        checkpoint("parent_validated_disabled", {
            "workflow_id": parent_result["id"], "node_count": parent_result["node_count"],
        })
    else:
        checkpoint("parent_deferred_until_all_children_validated", {
            "validated_child_count": len(child_keys), "required_child_count": len(BUSINESSES),
        })

    return {
        "writes_remote": True,
        "environment": "13001",
        "migration_id": migration_id,
        "manifest": str(path),
        "topology_sha256": manifest["topology_sha256"],
        "source_snapshot_sha256": manifest["source_snapshot_sha256"],
        "phase": manifest.get("phase"),
        "children_completed_this_run": completed,
        "parent": parent_result,
        "all_created_candidates_disabled": True,
        "fully_prepared": manifest.get("phase") == "prepared_disabled",
        "sentinel": manifest["sentinel"],
        "runtime_acceptance_prerequisites": manifest["runtime_acceptance_prerequisites"],
        "runtime_acceptance_passed": _runtime_acceptance_passed(manifest),
        "cutover_prerequisites_passed": _cutover_prerequisites_passed(manifest),
        "cutover_not_implemented": True,
    }


def validate_preparation(migration_id: str, *, require_sentinel: bool = False) -> dict[str, Any]:
    """Strictly validate a fully built disabled topology without changing it."""
    path, manifest = _existing_manifest(migration_id, require_evidence=require_sentinel)
    if manifest.get("source_snapshot") is None:
        raise PreparationError("no frozen source snapshot exists")
    source_snapshot = manifest["source_snapshot"]
    source_digest = manifest.get("source_snapshot_sha256")
    if not isinstance(source_snapshot, Mapping) or not isinstance(source_digest, str):
        raise PreparationError("frozen source snapshot is malformed")
    if digest(source_snapshot) != source_digest:
        raise PreparationError("frozen source snapshot checksum drifted")
    api = _require_api()
    child_keys: dict[str, str] = {}
    children: dict[str, Any] = {}
    for business in BUSINESSES:
        rows = _workflows_by_title(api, child_title(business, migration_id))
        if len(rows) != 1:
            raise PreparationError(f"missing child candidate: {business.name}")
        child = _validate_child(api, rows[0], business=business, manifest=manifest)
        if child.get("enabled") is not False or int(child.get("executed") or 0) != 0:
            raise PreparationError(f"child candidate is not inert: {business.name}")
        children[business.name] = child
        child_keys[business.name] = str(child["key"])
    rows = _workflows_by_title(api, ingress_title(migration_id))
    if len(rows) != 1:
        raise PreparationError("missing collection parent candidate")
    parent = _validate_parent(api, rows[0], child_keys=child_keys)
    if parent.get("enabled") is not False or int(parent.get("executed") or 0) != 0:
        raise PreparationError("parent candidate is not inert")
    return {
        "writes_remote": False,
        "environment": "13001",
        "migration_id": migration_id,
        "manifest": str(path),
        "topology_sha256": manifest["topology_sha256"],
        "source_snapshot_sha256": source_digest,
        "validated_disabled": True,
        "parent": parent,
        "children": children,
        "sentinel": manifest["sentinel"],
        "runtime_acceptance_prerequisites": manifest["runtime_acceptance_prerequisites"],
        "runtime_acceptance_passed": _runtime_acceptance_passed(manifest),
        "runtime_evidence": manifest.get("runtime_evidence"),
        "cutover_prerequisites_passed": _cutover_prerequisites_passed(manifest),
        "cutover_not_implemented": True,
    }


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group()
    action.add_argument(
        "--prepare",
        action="store_true",
        help="Create/recover disabled candidates only; requires explicit confirmation.",
    )
    action.add_argument("--inspect", action="store_true", help="Read one preparation manifest/candidate set.")
    action.add_argument("--validate", action="store_true", help="Strictly validate a fully disabled candidate set.")
    action.add_argument(
        "--record-runtime-evidence",
        type=Path,
        metavar="PATH",
        help="Validate and record local post-cutover acceptance evidence; never uses HTTP.",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON.")
    parser.add_argument("--write-plan", type=Path, help="Write the no-secret plan locally.")
    parser.add_argument(
        "--write-validation",
        type=Path,
        help=(
            "Create a private, non-overwritable 0600 copy of this --validate "
            "result for the controlled cutover executor."
        ),
    )
    parser.add_argument("--migration-id", help="Required for --prepare, --inspect, --validate, and --record-runtime-evidence.")
    parser.add_argument(
        "--business",
        help="Prepare one business child only; omit to prepare all 12 and then the parent.",
    )
    parser.add_argument(
        "--sentinel-evidence",
        type=Path,
        help="Saved successful output from the disposable custom-action sentinel.",
    )
    parser.add_argument(
        "--require-sentinel",
        action="store_true",
        help="Refuse prepare/validate unless successful sentinel evidence is recorded.",
    )
    parser.add_argument("--confirm", help="Required literal for --prepare.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if args.prepare:
            if not args.migration_id:
                raise PreparationError("--prepare requires --migration-id")
            if args.write_plan or args.write_validation:
                raise PreparationError(
                    "--write-plan/--write-validation cannot be combined with --prepare"
                )
            if args.confirm != PREPARE_CONFIRM:
                raise PreparationError("--prepare requires --confirm " + PREPARE_CONFIRM)
            result = prepare_disabled_candidates(
                args.migration_id,
                business_name=args.business,
                sentinel_evidence=args.sentinel_evidence,
                require_sentinel=args.require_sentinel,
            )
        elif args.inspect:
            if not args.migration_id:
                raise PreparationError("--inspect requires --migration-id")
            if args.business or args.sentinel_evidence or args.write_plan or args.write_validation:
                raise PreparationError("--inspect accepts only --migration-id and --pretty")
            result = inspect_preparation(args.migration_id)
        elif args.validate:
            if not args.migration_id:
                raise PreparationError("--validate requires --migration-id")
            if args.business or args.sentinel_evidence or args.write_plan:
                raise PreparationError(
                    "--validate accepts only --migration-id, --require-sentinel, "
                    "--write-validation and --pretty"
                )
            result = validate_preparation(args.migration_id, require_sentinel=args.require_sentinel)
            if args.write_validation:
                path = _write_new_private_json(args.write_validation, result)
                result = dict(result)
                result["local_validation_path"] = str(path)
        elif args.record_runtime_evidence:
            if not args.migration_id:
                raise PreparationError("--record-runtime-evidence requires --migration-id")
            if (
                args.business
                or args.sentinel_evidence
                or args.write_plan
                or args.write_validation
                or args.require_sentinel
                or args.confirm
            ):
                raise PreparationError("--record-runtime-evidence accepts only --migration-id, PATH and --pretty")
            result = record_runtime_evidence(args.migration_id, args.record_runtime_evidence)
        else:
            if (
                args.migration_id
                or args.business
                or args.sentinel_evidence
                or args.require_sentinel
                or args.confirm
                or args.write_validation
            ):
                raise PreparationError("migration/prepare options require --prepare, --inspect, or --validate")
            result = static_plan()
            if args.write_plan:
                path = args.write_plan.expanduser().resolve()
                if path.exists():
                    raise PlanError(f"refusing to overwrite existing plan: {path}")
                path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                path.chmod(0o600)
                result["local_plan_path"] = str(path)
        print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except (PlanError, PreparationError, ApiError) as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
