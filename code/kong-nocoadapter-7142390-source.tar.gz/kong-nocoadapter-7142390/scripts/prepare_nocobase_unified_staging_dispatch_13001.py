#!/usr/bin/env python3
"""Prepare, but never activate, one generic API Staging dispatcher on 13001.

The candidate is created through NocoBase's same-key revision mechanism from
the active NLA dispatcher.  The active source is disabled only for the small
revision window and is verified/restored before this command succeeds.  The
candidate remains disabled.  It is therefore safe to review the graph before
the existing family-specific timer drains are retired.

This does not alter native Intake/application workflows or any Staging row.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import API_SOURCE_CATEGORY_TITLE, ApiError
from plan_nocobase_generic_update_queue import (
    legacy_parent_nodes,
    legacy_parent_trigger_config,
    parent_nodes,
    parent_trigger_config,
)
from workflow_source_condition import destroy_workflow_nodes


BASE_URL = "http://119.91.104.211:13001/cmtf2"
SOURCE_UID = 392438115532800
SOURCE_KEY = "7dms7pwosyw"
SOURCE_TITLE = "API Staging — NLA guarded ingress dispatcher"
CONFIRM = "PREPARE_DISABLED_UNIFIED_STAGING_DISPATCH_13001"
BACKUP_ROOT = Path("/Users/work/noco/kong-nocoadapter-artifacts/workflow-backups")


class PreparationError(ApiError):
    """A live workflow differs from the approved cutover baseline."""


def _sha(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True,
                   separators=(",", ":"), default=str).encode()
    ).hexdigest()


def _node_shape(row: Mapping[str, Any]) -> list[dict[str, Any]]:
    by_id = {node.get("id"): node.get("key") for node in row.get("nodes", [])}
    return sorted(
        [
            {
                "key": node.get("key"), "type": node.get("type"),
                "title": node.get("title"), "config": node.get("config"),
                "upstream_key": by_id.get(node.get("upstreamId")),
                "downstream_key": by_id.get(node.get("downstreamId")),
                "branch_index": node.get("branchIndex"),
            }
            for node in row.get("nodes", [])
        ],
        key=lambda item: str(item["key"]),
    )


def graph_digest(row: Mapping[str, Any]) -> str:
    return _sha({
        "id": row.get("id"), "key": row.get("key"), "type": row.get("type"),
        "title": row.get("title"), "sync": row.get("sync"),
        "config": row.get("config"), "nodes": _node_shape(row),
    })


def _workflow(api: RootNocoBaseApi, uid: int) -> dict[str, Any]:
    row = dict(api.get_workflow(uid))
    if row.get("id") != uid:
        raise PreparationError(f"workflow {uid} readback failed")
    return row


def _versions(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    rows = api.request("GET", "/api/workflows:list?" +
                       "pageSize=100&filter[key]=" + SOURCE_KEY)
    if not isinstance(rows, list):
        raise PreparationError("same-key workflow listing is unavailable")
    rows = [dict(row) for row in rows if row.get("key") == SOURCE_KEY]
    if not rows or len({row.get("id") for row in rows}) != len(rows):
        raise PreparationError("same-key workflow listing is incomplete")
    return rows


def _category_id(api: RootNocoBaseApi) -> int:
    rows = api.request("GET", "/api/workflowCategories:list?pageSize=100")
    matches = [row for row in rows if isinstance(row, dict)
               and row.get("title") == API_SOURCE_CATEGORY_TITLE]
    if len(matches) != 1 or not isinstance(matches[0].get("id"), int):
        raise PreparationError("API Suorce category is absent or ambiguous")
    return matches[0]["id"]


def _category_ids(api: RootNocoBaseApi, uid: int) -> list[int]:
    row = api.request("GET", "/api/workflows:get?filterByTk=" + str(uid)
                      + "&appends[]=categories")
    categories = row.get("categories") if isinstance(row, dict) else None
    if not isinstance(categories, list):
        raise PreparationError("workflow category readback is unavailable")
    result = []
    for item in categories:
        value = item.get("id") if isinstance(item, dict) else item
        if not isinstance(value, int):
            raise PreparationError("workflow category has invalid ID")
        result.append(value)
    return sorted(set(result))


def _write_private(path: Path, data: Any) -> None:
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, default=str)
        stream.write("\n")


def _replace_refs(value: Any, keymap: Mapping[str, str]) -> Any:
    if isinstance(value, str):
        for planned, actual in keymap.items():
            value = value.replace(
                "{{$jobsMapByNodeKey." + planned + ".",
                "{{$jobsMapByNodeKey." + actual + ".",
            )
            value = value.replace(
                "{{$jobsMapByNodeKey." + planned + "}}",
                "{{$jobsMapByNodeKey." + actual + "}}",
            )
            value = value.replace(
                "{{$scopes." + planned + ".",
                "{{$scopes." + actual + ".",
            )
        return value
    if isinstance(value, list):
        return [_replace_refs(item, keymap) for item in value]
    if isinstance(value, dict):
        return {key: _replace_refs(item, keymap) for key, item in value.items()}
    return value


def _no_planned_refs(value: Any, planned_keys: set[str]) -> bool:
    if isinstance(value, str):
        return not any(
            re.search(r"\{\{\$(?:jobsMapByNodeKey|scopes)\."
                      + re.escape(key) + r"(?:\.|\}\})", value)
            for key in planned_keys
        )
    if isinstance(value, list):
        return all(_no_planned_refs(item, planned_keys) for item in value)
    if isinstance(value, dict):
        return all(_no_planned_refs(item, planned_keys) for item in value.values())
    return True


def _assert_source(row: Mapping[str, Any], expected_digest: str) -> None:
    if (
        row.get("id") != SOURCE_UID or row.get("key") != SOURCE_KEY
        or row.get("title") != SOURCE_TITLE or row.get("type") != "collection"
        or row.get("sync") is not False or row.get("enabled") is not True
        or not row.get("nodes")
    ):
        raise PreparationError("active NLA dispatcher identity/state drifted")
    if expected_digest and graph_digest(row) != expected_digest:
        raise PreparationError("active NLA dispatcher graph digest drifted")


def inspect(api: RootNocoBaseApi) -> dict[str, Any]:
    source = _workflow(api, SOURCE_UID)
    _assert_source(source, "")
    candidates = []
    for row in _versions(api):
        if row.get("id") == SOURCE_UID:
            continue
        full = _workflow(api, int(row["id"]))
        if full.get("title") == "API Staging — unified external dispatcher":
            candidates.append(full)
    if len(candidates) > 1:
        raise PreparationError("multiple unified dispatcher candidates exist")
    return {
        "environment": "13001", "writes": False,
        "source_uid": SOURCE_UID, "source_key": SOURCE_KEY,
        "source_graph_sha256": graph_digest(source),
        "source_execution_count": source.get("executed"),
        "candidate": {
            "id": candidates[0].get("id"), "enabled": candidates[0].get("enabled"),
            "node_count": len(candidates[0].get("nodes") or []),
        } if candidates else None,
        "planned_node_count": len(parent_nodes()),
        "planned_trigger": parent_trigger_config(),
    }


def prepare(api: RootNocoBaseApi, expected_digest: str) -> dict[str, Any]:
    source = _workflow(api, SOURCE_UID)
    _assert_source(source, expected_digest)
    before_versions = _versions(api)
    if any(row.get("enabled") is True and row.get("id") != SOURCE_UID
           for row in before_versions):
        raise PreparationError("same-key dispatcher has another enabled version")
    if any(
        _workflow(api, int(row["id"])).get("title")
        == "API Staging — unified external dispatcher"
        for row in before_versions if row.get("id") != SOURCE_UID
    ):
        raise PreparationError("unified dispatcher candidate already exists")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = BACKUP_ROOT / f"13001-unified-dispatch-prepare-{stamp}"
    backup.mkdir(mode=0o700, parents=True, exist_ok=False)
    _write_private(backup / "source-before.json", source)
    _write_private(backup / "intent.json", {
        "source_uid": SOURCE_UID, "source_key": SOURCE_KEY,
        "source_graph_sha256": graph_digest(source),
        "planned_node_count": len(parent_nodes()),
        "planned_trigger": parent_trigger_config(),
    })

    created_id: int | None = None
    error: Exception | None = None
    try:
        api.request("POST", f"/api/workflows:update?filterByTk={SOURCE_UID}",
                    {"enabled": False})
        if _workflow(api, SOURCE_UID).get("enabled") is not False:
            raise PreparationError("source did not stop for revision")
        created = api.request(
            "POST", "/api/workflows:revision?filterByTk=" + str(SOURCE_UID)
            + "&filter[key]=" + SOURCE_KEY, {})
        if not isinstance(created, dict) or not isinstance(created.get("id"), int):
            raise PreparationError("revision result is ambiguous")
        created_id = created["id"]
        candidate = _workflow(api, created_id)
        if candidate.get("enabled") is not False or candidate.get("executed"):
            raise PreparationError("new candidate is not disabled and empty")
        destroy_workflow_nodes(api, candidate)
        api.request("POST", f"/api/workflows:update?filterByTk={created_id}", {
            "title": "API Staging — unified external dispatcher",
            "config": parent_trigger_config(),
        })
        actual: dict[str, dict[str, Any]] = {}
        specs = parent_nodes()
        planned_keys = {str(spec["key"]) for spec in specs}
        for spec in specs:
            config = _replace_refs(copy.deepcopy(spec["config"]),
                                   {key: row["key"] for key, row in actual.items()})
            if not _no_planned_refs(config, planned_keys - set(actual)):
                raise PreparationError(
                    f"node {spec['title']} has a forward workflow reference"
                )
            row = api.create_node({
                "workflowId": created_id, "type": spec["type"],
                "title": spec["title"], "config": config,
            })
            if not isinstance(row.get("id"), int) or not isinstance(row.get("key"), str):
                raise PreparationError(f"node {spec['title']} create is ambiguous")
            actual[str(spec["key"])] = dict(row)
        for spec in specs:
            upstream = spec.get("upstream")
            if upstream is None:
                continue
            parent = actual[str(upstream)]
            child = actual[str(spec["key"])]
            values: dict[str, Any] = {"upstreamId": parent["id"]}
            if spec.get("branch") is None:
                api.update_node(int(parent["id"]), {"downstreamId": child["id"]})
            else:
                values["branchIndex"] = spec["branch"]
            api.update_node(int(child["id"]), values)
        category_id = _category_id(api)
        categories = _category_ids(api, created_id)
        if category_id not in categories:
            api.request("POST", f"/api/workflows:update?filterByTk={created_id}",
                        {"categories": sorted(set(categories) | {category_id})})
        final = _workflow(api, created_id)
        if (
            final.get("enabled") is not False
            or final.get("title") != "API Staging — unified external dispatcher"
            or final.get("config") != parent_trigger_config()
            or len(final.get("nodes") or []) != len(specs)
            or category_id not in _category_ids(api, created_id)
        ):
            raise PreparationError("candidate readback differs from plan")
        _write_private(backup / "candidate-disabled.json", final)
    except Exception as exc:
        error = exc
    finally:
        enabled = [row for row in _versions(api) if row.get("enabled") is True]
        if enabled:
            if len(enabled) != 1 or enabled[0].get("id") != SOURCE_UID:
                raise PreparationError("unexpected enabled dispatcher during restoration")
        else:
            api.request("POST", f"/api/workflows:update?filterByTk={SOURCE_UID}",
                        {"enabled": True})
        restored = _workflow(api, SOURCE_UID)
        if restored.get("enabled") is not True or graph_digest(restored) != graph_digest(source):
            raise PreparationError("source restoration readback failed")
    if error is not None:
        raise PreparationError(
            f"candidate preparation failed; candidate_uid={created_id}; backup={backup}"
        ) from error
    return {
        "environment": "13001", "writes": True, "source_uid": SOURCE_UID,
        "source_restored": True, "candidate_uid": created_id,
        "candidate_enabled": False, "candidate_node_count": len(parent_nodes()),
        "backup_dir": str(backup),
    }


def _actual_nodes_by_spec(
    candidate: Mapping[str, Any], specs: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Match persisted nodes to the immutable plan without relying on node keys.

    NocoBase allocates a fresh node key on each create.  A connection failure
    after a node POST is therefore reconciled by the stable title/type pair,
    rather than by retrying the POST and risking a duplicate node.
    """
    expected = {
        (str(spec["title"]), str(spec["type"]))
        for spec in specs
    }
    available = [dict(row) for row in candidate.get("nodes") or []]
    actual: dict[str, dict[str, Any]] = {}
    for spec in specs:
        signature = (str(spec["title"]), str(spec["type"]))
        if signature not in expected:
            raise PreparationError("dispatcher plan has an invalid node signature")
        candidates = [
            row for row in available
            if (str(row.get("title")), str(row.get("type"))) == signature
        ]
        if not candidates:
            continue
        if len(candidates) > 1:
            # The two FIFO pumps deliberately share human-readable titles.
            # Their resolved configs contain the already allocated upstream
            # NocoBase keys, which makes the match deterministic in plan order.
            expected_config = _replace_refs(
                copy.deepcopy(spec["config"]),
                {key: row["key"] for key, row in actual.items()},
            )
            exact = [row for row in candidates if row.get("config") == expected_config]
            if len(exact) != 1:
                raise PreparationError(
                    "candidate has ambiguous duplicate dispatcher node signatures"
                )
            candidates = exact
        row = candidates[0]
        if not isinstance(row.get("id"), int) or not isinstance(row.get("key"), str):
            raise PreparationError("candidate node identity is invalid")
        actual[str(spec["key"])] = row
        available.remove(row)
    if available:
        raise PreparationError(
            "candidate has a node outside the approved generic dispatcher plan"
        )
    return actual


def _connect_and_verify_candidate(
    api: RootNocoBaseApi,
    candidate_id: int,
    actual: dict[str, dict[str, Any]],
    specs: list[dict[str, Any]],
) -> dict[str, Any]:
    """Wire a fully materialized disabled candidate and verify it exactly."""
    for spec in specs:
        upstream = spec.get("upstream")
        if upstream is None:
            continue
        parent = actual[str(upstream)]
        child = actual[str(spec["key"])]
        values: dict[str, Any] = {"upstreamId": parent["id"]}
        if spec.get("branch") is None:
            if parent.get("downstreamId") != child["id"]:
                api.update_node(int(parent["id"]), {"downstreamId": child["id"]})
                parent["downstreamId"] = child["id"]
        else:
            values["branchIndex"] = spec["branch"]
        if (
            child.get("upstreamId") != parent["id"]
            or (
                spec.get("branch") is not None
                and child.get("branchIndex") != spec["branch"]
            )
        ):
            api.update_node(int(child["id"]), values)
            child.update(values)

    category_id = _category_id(api)
    categories = _category_ids(api, candidate_id)
    if category_id not in categories:
        api.request("POST", f"/api/workflows:update?filterByTk={candidate_id}", {
            "categories": sorted(set(categories) | {category_id})
        })
    final = _workflow(api, candidate_id)
    if (
        final.get("enabled") is not False
        or final.get("title") != "API Staging — unified external dispatcher"
        or final.get("config") != parent_trigger_config()
        or len(final.get("nodes") or []) != len(specs)
        or category_id not in _category_ids(api, candidate_id)
    ):
        raise PreparationError("candidate readback differs from plan")
    _assert_edge_shape(final, specs)
    return final


def _assert_edge_shape(
    candidate: Mapping[str, Any], specs: list[dict[str, Any]],
) -> None:
    """Validate the complete graph topology after a stopped candidate write."""
    actual = _actual_nodes_by_spec(candidate, specs)
    if len(actual) != len(specs):
        raise PreparationError("candidate node set differs from the approved plan")
    for spec in specs:
        child = actual[str(spec["key"])]
        upstream = spec.get("upstream")
        if upstream is None:
            if child.get("upstreamId") is not None:
                raise PreparationError(f"root {spec['title']} unexpectedly has upstream")
            continue
        parent = actual[str(upstream)]
        if child.get("upstreamId") != parent["id"]:
            raise PreparationError(f"edge into {spec['title']} differs from plan")
        if child.get("branchIndex") != spec.get("branch"):
            raise PreparationError(f"branch into {spec['title']} differs from plan")
        if spec.get("branch") is None and parent.get("downstreamId") != child["id"]:
            raise PreparationError(f"continuation from {parent['title']} differs from plan")


def resume_partial_candidate(
    api: RootNocoBaseApi, expected_digest: str, candidate_id: int,
) -> dict[str, Any]:
    """Safely continue a disabled candidate left by an uncertain node POST.

    This operation never disables or edits the active source dispatcher.  It
    only appends plan nodes absent from a disabled, never-executed candidate,
    then attaches the planned edges and category.
    """
    source = _workflow(api, SOURCE_UID)
    _assert_source(source, expected_digest)
    versions = _versions(api)
    enabled = [row for row in versions if row.get("enabled") is True]
    if len(enabled) != 1 or enabled[0].get("id") != SOURCE_UID:
        raise PreparationError("active source dispatcher is not the sole enabled version")
    candidate = _workflow(api, candidate_id)
    if (
        candidate.get("key") != SOURCE_KEY
        or candidate.get("title") != "API Staging — unified external dispatcher"
        or candidate.get("enabled") is not False
        or candidate.get("executed")
        or candidate.get("config") != parent_trigger_config()
    ):
        raise PreparationError("partial candidate identity/state/config drifted")

    specs = parent_nodes()
    actual = _actual_nodes_by_spec(candidate, specs)
    if len(actual) > len(specs):
        raise PreparationError("candidate has more nodes than the approved plan")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = BACKUP_ROOT / f"13001-unified-dispatch-resume-{stamp}"
    backup.mkdir(mode=0o700, parents=True, exist_ok=False)
    _write_private(backup / "candidate-before.json", candidate)
    _write_private(backup / "intent.json", {
        "candidate_uid": candidate_id,
        "source_uid": SOURCE_UID,
        "source_graph_sha256": graph_digest(source),
        "existing_node_count": len(actual),
        "planned_node_count": len(specs),
    })

    planned_keys = {str(spec["key"]) for spec in specs}
    created_count = 0
    for spec in specs:
        planned_key = str(spec["key"])
        if planned_key in actual:
            continue
        config = _replace_refs(
            copy.deepcopy(spec["config"]),
            {key: row["key"] for key, row in actual.items()},
        )
        if not _no_planned_refs(config, planned_keys - set(actual)):
            raise PreparationError(
                f"node {spec['title']} has a forward workflow reference"
            )
        row = api.create_node({
            "workflowId": candidate_id,
            "type": spec["type"],
            "title": spec["title"],
            "config": config,
        })
        if not isinstance(row.get("id"), int) or not isinstance(row.get("key"), str):
            raise PreparationError(f"node {spec['title']} create is ambiguous")
        actual[planned_key] = dict(row)
        created_count += 1

    final = _connect_and_verify_candidate(api, candidate_id, actual, specs)
    _write_private(backup / "candidate-disabled.json", final)
    restored = _workflow(api, SOURCE_UID)
    if restored.get("enabled") is not True or graph_digest(restored) != graph_digest(source):
        raise PreparationError("source dispatcher changed during candidate resume")
    return {
        "environment": "13001", "writes": True,
        "source_uid": SOURCE_UID, "source_unchanged": True,
        "candidate_uid": candidate_id, "candidate_enabled": False,
        "candidate_node_count": len(specs), "created_node_count": created_count,
        "backup_dir": str(backup),
    }


def augment_completion_pump(
    api: RootNocoBaseApi, expected_digest: str, candidate_id: int,
) -> dict[str, Any]:
    """Extend the disabled 56-node candidate with one shared completion pump.

    The dispatcher wakes the next FIFO UPDATE only after the CREATE row has
    become succeeded *and* its active reservation is empty.  A worker release
    changes that CREATE-row field, so no per-family timer and no native
    business-workflow revision is required.
    """
    source = _workflow(api, SOURCE_UID)
    _assert_source(source, expected_digest)
    versions = _versions(api)
    enabled = [row for row in versions if row.get("enabled") is True]
    if len(enabled) != 1 or enabled[0].get("id") != SOURCE_UID:
        raise PreparationError("active source dispatcher is not the sole enabled version")
    candidate = _workflow(api, candidate_id)
    old_specs = legacy_parent_nodes()
    new_specs = parent_nodes()
    if (
        candidate.get("key") != SOURCE_KEY
        or candidate.get("title") != "API Staging — unified external dispatcher"
        or candidate.get("enabled") is not False
        or candidate.get("executed")
        or candidate.get("config") != legacy_parent_trigger_config()
    ):
        raise PreparationError("56-node candidate identity/state/config drifted")
    actual = _actual_nodes_by_spec(candidate, old_specs)
    _assert_edge_shape(candidate, old_specs)
    if len(actual) != len(old_specs):
        raise PreparationError("candidate is not the expected 56-node baseline")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = BACKUP_ROOT / f"13001-unified-dispatch-completion-pump-{stamp}"
    backup.mkdir(mode=0o700, parents=True, exist_ok=False)
    _write_private(backup / "candidate-before.json", candidate)
    _write_private(backup / "intent.json", {
        "candidate_uid": candidate_id,
        "source_uid": SOURCE_UID,
        "source_graph_sha256": graph_digest(source),
        "old_node_count": len(old_specs),
        "new_node_count": len(new_specs),
        "completion_trigger_fields": parent_trigger_config()["changed"],
    })

    api.request("POST", f"/api/workflows:update?filterByTk={candidate_id}", {
        "config": parent_trigger_config(),
    })
    planned_keys = {str(spec["key"]) for spec in new_specs}
    for spec in new_specs:
        planned_key = str(spec["key"])
        if planned_key in actual:
            continue
        config = _replace_refs(
            copy.deepcopy(spec["config"]),
            {key: row["key"] for key, row in actual.items()},
        )
        if not _no_planned_refs(config, planned_keys - set(actual)):
            raise PreparationError(
                f"node {spec['title']} has a forward workflow reference"
            )
        row = api.create_node({
            "workflowId": candidate_id,
            "type": spec["type"],
            "title": spec["title"],
            "config": config,
        })
        if not isinstance(row.get("id"), int) or not isinstance(row.get("key"), str):
            raise PreparationError(f"node {spec['title']} create is ambiguous")
        actual[planned_key] = dict(row)

    final = _connect_and_verify_candidate(api, candidate_id, actual, new_specs)
    _write_private(backup / "candidate-disabled.json", final)
    restored = _workflow(api, SOURCE_UID)
    if restored.get("enabled") is not True or graph_digest(restored) != graph_digest(source):
        raise PreparationError("source dispatcher changed during candidate augmentation")
    return {
        "environment": "13001", "writes": True,
        "source_uid": SOURCE_UID, "source_unchanged": True,
        "candidate_uid": candidate_id, "candidate_enabled": False,
        "candidate_node_count": len(new_specs),
        "completion_nodes_added": len(new_specs) - len(old_specs),
        "backup_dir": str(backup),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--token-file", type=Path, required=True)
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--expected-source-sha256", default="")
    parser.add_argument("--confirm", default="")
    args = parser.parse_args()
    if args.prepare and args.confirm != CONFIRM:
        raise SystemExit(f"--prepare requires --confirm {CONFIRM}")
    if args.prepare and not re.fullmatch(r"[0-9a-f]{64}", args.expected_source_sha256):
        raise SystemExit("--prepare requires the exact source graph SHA-256")
    token = args.token_file.read_text(encoding="utf-8").strip()
    if not token:
        raise SystemExit("empty token file")
    api = RootNocoBaseApi(BASE_URL, token)
    report = prepare(api, args.expected_source_sha256) if args.prepare else inspect(api)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
