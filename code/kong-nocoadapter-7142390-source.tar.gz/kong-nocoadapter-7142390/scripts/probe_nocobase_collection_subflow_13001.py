#!/usr/bin/env python3
"""Prove that one collection workflow can invoke a disabled collection worker.

This is an isolated 13001-only probe used before converting the API Staging
entry points to a single dispatcher.  It creates two temporary workflows and
one uniquely marked staging row, verifies that an enabled parent invokes a
*disabled* collection child through NocoBase's existing Invoke Workflow node,
and removes all three objects in ``finally``.

It never reads or changes a native Intake/application workflow.  Authentication
is supplied in ``NOCOBASE_TOKEN`` and is never printed or persisted.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import urllib.parse
from datetime import datetime, timezone
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    attach_api_source_category,
    create_node,
    set_enabled,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi


BASE_URL = "http://119.91.104.211:13001/cmtf2"
COLLECTION = "t_api_request_staging"
# ``OP`` is an existing staging enumeration value.  The API type is a unique
# sentinel, so no public worker can match the probe row.
PROBE_SOURCE = "OP"
PROBE_API_TYPE = "__dispatcher_subflow_probe__"
PROBE_STATUS = "submitted"
PROBE_INITIAL_STATUS = "invalid_request"


def _trigger_config() -> dict[str, Any]:
    """A create-only, exact probe trigger that cannot match public requests."""
    return {
        # Match the deployed dispatcher style: process a state transition,
        # not the initial REST create itself.
        "mode": 3,
        "appends": [],
        "changed": ["f_status"],
        "collection": COLLECTION,
        "condition": {
            "$and": [
                {"f_source_system": {"$eq": PROBE_SOURCE}},
                {"f_api_type": {"$eq": PROBE_API_TYPE}},
                {"f_status": {"$eq": PROBE_STATUS}},
            ]
        },
    }


def _create_workflow(api: RootNocoBaseApi, title: str) -> dict[str, Any]:
    result = api.request(
        "POST",
        "/api/workflows:create",
        {
            "title": title,
            "type": "collection",
            "sync": False,
            "enabled": False,
            "config": _trigger_config(),
        },
    )
    if not isinstance(result, dict) or not isinstance(result.get("id"), int):
        raise ApiError("Temporary workflow creation returned no ID")
    attach_api_source_category(api, int(result["id"]))
    return dict(result)


def _destroy_workflow(api: RootNocoBaseApi, workflow_id: int) -> None:
    api.request(
        "POST",
        "/api/workflows:destroy?"
        + urllib.parse.urlencode({"filterByTk": str(workflow_id)}),
        {},
    )


def _destroy_staging(api: RootNocoBaseApi, staging_id: int) -> None:
    api.request(
        "POST",
        f"/api/{COLLECTION}:destroy?"
        + urllib.parse.urlencode({"filterByTk": str(staging_id)}),
        {},
    )


def _count(api: RootNocoBaseApi, workflow_id: int) -> int:
    value = api.get_workflow(workflow_id).get("executed")
    return int(value or 0)


def _wait_for_count(
    api: RootNocoBaseApi, workflow_id: int, before: int, timeout: int
) -> int:
    deadline = time.monotonic() + timeout
    current = before
    while time.monotonic() < deadline:
        current = _count(api, workflow_id)
        if current > before:
            return current
        time.sleep(0.5)
    raise ApiError(
        f"Workflow {workflow_id} did not execute within {timeout} seconds"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default=BASE_URL)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--timeout-seconds", type=int, default=20)
    args = parser.parse_args()

    if not args.apply:
        print("mode=dry-run")
        print("purpose=verify_disabled_collection_child_can_be_called_as_subflow")
        return 0
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    child_id: int | None = None
    parent_id: int | None = None
    staging_id: int | None = None
    primary_error: Exception | None = None
    cleanup_errors: list[str] = []

    try:
        child = _create_workflow(
            api, f"API Suorce — collection subflow probe child {stamp}"
        )
        child_id = int(child["id"])
        child = api.get_workflow(child_id)
        child_key = str(child.get("key") or "")
        if not child_key or child.get("enabled"):
            raise ApiError("Probe child is not disabled with a usable key")

        parent = _create_workflow(
            api, f"API Suorce — collection subflow probe parent {stamp}"
        )
        parent_id = int(parent["id"])
        parent = api.get_workflow(parent_id)
        before_parent = _count(api, parent_id)
        before_child = _count(api, child_id)
        node = create_node(
            api,
            parent_id,
            "subflow",
            "Invoke disabled probe child",
            {
                "workflow": child_key,
                "context": {"data": "{{$context.data}}"},
            },
        )
        if node.get("type") != "subflow":
            raise ApiError("Probe subflow node did not persist")
        set_enabled(api, parent_id, True)
        if not api.get_workflow(parent_id).get("enabled"):
            raise ApiError("Probe parent did not enable")
        # NocoBase registers a collection-event listener asynchronously after
        # an enable action.  Give that registration a bounded moment before
        # creating the isolated row; this mirrors a real cutover guard.
        time.sleep(1.5)

        # Workflow configuration requires the root role, but an external API
        # request is handled through the ordinary role.  Use the latter for
        # the probe row so the test exercises the same collection hook path.
        request_api = NocoBaseApi(args.base_url, token)
        created = request_api.request(
            "POST",
            f"/api/{COLLECTION}:create",
            {
                "f_request_body": {"request_id": f"subflow-probe-{stamp}"},
                "f_source_system": PROBE_SOURCE,
                "f_request_event": "PROBE",
                "f_api_type": PROBE_API_TYPE,
                "f_user_role": "root",
                "f_status": PROBE_INITIAL_STATUS,
            },
        )
        if not isinstance(created, dict) or not isinstance(created.get("id"), int):
            raise ApiError("Probe staging row creation returned no ID")
        staging_id = int(created["id"])
        persisted = request_api.request(
            "GET",
            f"/api/{COLLECTION}:get?"
            + urllib.parse.urlencode({"filterByTk": str(staging_id)}),
        )
        if not isinstance(persisted, dict):
            raise ApiError("Probe staging row readback failed")
        print(
            "probe_row="
            + ",".join(
                f"{name}={persisted.get(name)!s}"
                for name in ("f_source_system", "f_api_type", "f_status")
            )
        )
        request_api.request(
            "POST",
            f"/api/{COLLECTION}:update?"
            + urllib.parse.urlencode({"filterByTk": str(staging_id)}),
            {"f_status": PROBE_STATUS},
        )
        after_parent = _wait_for_count(
            api, parent_id, before_parent, args.timeout_seconds
        )
        after_child = _wait_for_count(
            api, child_id, before_child, args.timeout_seconds
        )
        if after_parent != before_parent + 1 or after_child != before_child + 1:
            raise ApiError(
                "Probe execution count is not exactly one parent and one child"
            )
        print("probe=passed")
        print("parent_execution_delta=1")
        print("child_execution_delta=1")
        print("child_enabled=false")
    except Exception as exc:
        primary_error = exc
    finally:
        if parent_id is not None:
            try:
                set_enabled(api, parent_id, False)
            except Exception as exc:  # pragma: no cover - remote cleanup guard
                cleanup_errors.append(f"parent_disable:{exc}")
        if staging_id is not None:
            try:
                _destroy_staging(api, staging_id)
            except Exception as exc:  # pragma: no cover - remote cleanup guard
                cleanup_errors.append(f"staging_destroy:{exc}")
        for workflow_id in (parent_id, child_id):
            if workflow_id is None:
                continue
            try:
                _destroy_workflow(api, workflow_id)
            except Exception as exc:  # pragma: no cover - remote cleanup guard
                cleanup_errors.append(f"workflow_destroy:{workflow_id}:{exc}")

    if cleanup_errors:
        raise ApiError("Probe cleanup failed: " + " | ".join(cleanup_errors))
    if primary_error:
        raise primary_error
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
