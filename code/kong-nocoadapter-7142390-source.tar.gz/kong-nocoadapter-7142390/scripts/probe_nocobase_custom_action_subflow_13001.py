#!/usr/bin/env python3
"""Disposable 13001 proof for collection -> custom-action Subflow.

The earlier diagnostic established that a collection parent cannot safely call
another *collection* workflow as a child.  This probe instead checks the
architecture now required for API Staging consolidation:

* one temporary collection event parent;
* one temporary ``custom-action`` child (single-record context, sync mode);
* one ``multi-conditions`` parent branch; and
* one uniquely labelled ``t_api_request_staging`` row.

The child changes only the temporary row's ``f_error_message``.  All objects
are disabled/destroyed in ``finally`` even when the assertion fails.  The
script defaults to a no-write structural plan.  ``--apply`` is deliberately
guarded by an explicit confirmation and must only be used on 13001.

It initially tests an *enabled* custom-action child.  This is the conservative
runtime setting because a disabled collection child failed on 13001.  The
official Subflow documentation says disabled children may work, but that is an
optional later probe; it must not be assumed for a cutover.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.parse
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    attach_api_source_category,
    create_node,
    link,
    set_enabled,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi


BASE_URL = "http://119.91.104.211:13001/cmtf2"
COLLECTION = "t_api_request_staging"
CONFIRM = "RUN_ENABLED_CUSTOM_ACTION_SUBFLOW_SENTINEL_13001"

# These values are intentionally outside every public API tuple.  The source
# value is not OP or CMTF, so existing API Source collection workflows cannot
# match it.  NocoBase select fields persist their string value; if an instance
# later enforces an enum here, creation fails before the temporary parent is
# enabled and the script cleans up.
SENTINEL_SOURCE = "__CUSTOM_ACTION_SUBFLOW_SENTINEL__"
SENTINEL_EVENT = "SENTINEL"
SENTINEL_API_TYPE = "__custom_action_subflow_sentinel__"
INITIAL_STATUS = "invalid_request"
TRIGGER_STATUS = "submitted"


def _context(field: str) -> str:
    return "{{$context.data." + field + "}}"


def _equal(field: str, value: Any) -> dict[str, Any]:
    return {"calculator": "equal", "operands": [_context(field), value]}


def _and(*calculations: Mapping[str, Any]) -> dict[str, Any]:
    return {"group": {"type": "and", "calculations": [dict(item) for item in calculations]}}


def parent_trigger_config(marker: str) -> dict[str, Any]:
    """Exact mode-3 collection trigger; no public request can match it."""
    return {
        "mode": 3,
        "collection": COLLECTION,
        "appends": [],
        "changed": ["f_status"],
        "condition": {
            "$and": [
                {"f_source_system": {"$eq": SENTINEL_SOURCE}},
                {"f_request_event": {"$eq": SENTINEL_EVENT}},
                {"f_api_type": {"$eq": SENTINEL_API_TYPE}},
                {"f_client_request_id": {"$eq": marker}},
                {"f_status": {"$eq": TRIGGER_STATUS}},
            ]
        },
    }


def child_config() -> dict[str, Any]:
    """NocoBase custom-action SINGLE_RECORD context configuration."""
    return {"type": 1, "collection": COLLECTION, "appends": []}


def router_config(marker: str) -> dict[str, Any]:
    """A one-branch multi-condition router used by the temporary parent."""
    return {
        "continueOnNoMatch": False,
        "conditions": [
            {
                "uid": f"customActionSubflowSentinel{marker.replace('-', '')}",
                "title": "Exact sentinel row",
                "engine": "basic",
                "calculation": _and(
                    _equal("f_source_system", SENTINEL_SOURCE),
                    _equal("f_request_event", SENTINEL_EVENT),
                    _equal("f_api_type", SENTINEL_API_TYPE),
                    _equal("f_client_request_id", marker),
                    _equal("f_status", TRIGGER_STATUS),
                ),
            }
        ],
    }


def child_update_config(marker: str) -> dict[str, Any]:
    """The only data mutation: an exact, throwaway-row marker write."""
    return {
        "collection": COLLECTION,
        "params": {
            "filter": {
                "$and": [
                    {"id": {"$eq": _context("id")}},
                    {"f_source_system": {"$eq": SENTINEL_SOURCE}},
                    {"f_request_event": {"$eq": SENTINEL_EVENT}},
                    {"f_api_type": {"$eq": SENTINEL_API_TYPE}},
                    {"f_client_request_id": {"$eq": marker}},
                    {"f_status": {"$eq": TRIGGER_STATUS}},
                ]
            },
            "values": {"f_error_message": f"custom-action-subflow-sentinel:{marker}"},
            # The sentinel does not need to invoke model hooks after proving
            # context propagation.  This also ensures no second collection
            # event can be caused by the marker itself.
            "individualHooks": False,
            "appends": [],
        },
    }


def subflow_config(child_key: str) -> dict[str, Any]:
    return {
        "workflow": child_key,
        # Custom-action subflows require an execution user. createdById is
        # populated by NocoBase from the caller token; it is internal audit
        # context and never a third-party request parameter.
        "context": {
            "data": "{{$context.data}}",
            "userId": "{{$context.data.createdById}}",
            "roleName": None,
        },
    }


def _read_workflow(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    result = dict(api.get_workflow(workflow_id))
    if result.get("id") != workflow_id:
        raise ApiError(f"workflow {workflow_id} readback mismatch")
    return result


def _execution_rows(api: RootNocoBaseApi, workflow_id: int) -> list[dict[str, Any]]:
    """Return the durable execution rows for one temporary workflow.

    ``workflows.executed`` / ``allExecuted`` are not cumulative counters on
    the target NocoBase instance.  In particular, live workflows can expose
    zero for both fields while ``executions:list`` contains completed rows.
    A sentinel must therefore prove exact-once delivery using the execution
    records themselves, rather than sampling a transient workflow statistic.
    """
    result: list[dict[str, Any]] = []
    page = 1
    while True:
        query = urllib.parse.urlencode(
            {
                "filter[workflowId]": str(workflow_id),
                "page": page,
                "pageSize": 100,
                "sort[]": "createdAt",
            }
        )
        rows = api.request("GET", "/api/executions:list?" + query) or []
        if not isinstance(rows, list) or not all(isinstance(row, Mapping) for row in rows):
            raise ApiError("execution list returned an unexpected payload")
        result.extend(dict(row) for row in rows)
        if len(rows) < 100:
            return result
        page += 1
        if page > 1000:
            raise ApiError("execution list exceeded the sentinel safety page limit")


def _execution_snapshot(
    api: RootNocoBaseApi, workflow_id: int
) -> dict[int, dict[str, Any]]:
    """Index durable execution rows by ID, rejecting malformed IDs."""
    result: dict[int, dict[str, Any]] = {}
    for row in _execution_rows(api, workflow_id):
        identifier = row.get("id")
        if not isinstance(identifier, int):
            raise ApiError("execution list contains a row without an integer ID")
        if identifier in result:
            raise ApiError(f"execution list repeated execution ID {identifier}")
        result[identifier] = row
    return result


def _execution_row_matches_staging(
    row: Mapping[str, Any], *, staging_id: int, marker: str
) -> bool:
    """Check that an execution is for this disposable row, not just its flow."""
    context = row.get("context")
    if not isinstance(context, Mapping):
        return False
    data = context.get("data")
    return (
        isinstance(data, Mapping)
        and data.get("id") == staging_id
        and data.get("f_source_system") == SENTINEL_SOURCE
        and data.get("f_request_event") == SENTINEL_EVENT
        and data.get("f_api_type") == SENTINEL_API_TYPE
        and data.get("f_client_request_id") == marker
        and data.get("f_status") == TRIGGER_STATUS
    )


def _execution_observation(
    rows: Mapping[int, Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Compact non-secret diagnostics for a failed exact-once assertion."""
    return [
        {
            "id": identifier,
            "status": row.get("status"),
            "parentExecutionId": row.get("parentExecutionId"),
        }
        for identifier, row in sorted(rows.items())
    ]


def _wait_for_marker(
    api: RootNocoBaseApi,
    request_api: NocoBaseApi,
    *,
    staging_id: int,
    parent_id: int,
    child_id: int,
    before_parent: Mapping[int, Mapping[str, Any]],
    before_child: Mapping[int, Mapping[str, Any]],
    marker: str,
    expected_marker: str,
    timeout_seconds: int,
) -> dict[str, Any]:
    deadline = time.monotonic() + timeout_seconds
    row: dict[str, Any] | None = None
    last_parent: dict[int, dict[str, Any]] = {}
    last_child: dict[int, dict[str, Any]] = {}
    while time.monotonic() < deadline:
        loaded = request_api.request(
            "GET",
            f"/api/{COLLECTION}:get?"
            + urllib.parse.urlencode({"filterByTk": str(staging_id)}),
        )
        row = dict(loaded) if isinstance(loaded, Mapping) else None
        parent_after = _execution_snapshot(api, parent_id)
        child_after = _execution_snapshot(api, child_id)
        last_parent = {
            identifier: execution
            for identifier, execution in parent_after.items()
            if identifier not in before_parent
        }
        last_child = {
            identifier: execution
            for identifier, execution in child_after.items()
            if identifier not in before_child
        }
        parent_rows = list(last_parent.values())
        child_rows = list(last_child.values())
        parent_id_set = set(last_parent)
        if (
            row is not None
            and row.get("f_error_message") == expected_marker
            and len(parent_rows) == 1
            and len(child_rows) == 1
            and _execution_row_matches_staging(
                parent_rows[0], staging_id=staging_id, marker=marker
            )
            and _execution_row_matches_staging(
                child_rows[0], staging_id=staging_id, marker=marker
            )
            and parent_rows[0].get("status") == 1
            and child_rows[0].get("status") == 1
            and child_rows[0].get("parentExecutionId") in parent_id_set
        ):
            return {
                "parent_execution_delta": len(parent_rows),
                "child_execution_delta": len(child_rows),
                "row_marker": row.get("f_error_message"),
            }
        time.sleep(0.5)
    raise ApiError(
        "custom-action subflow sentinel did not complete exactly once; "
        f"last_row_marker={(row or {}).get('f_error_message')!r}; "
        f"parent_new_executions={json.dumps(_execution_observation(last_parent), ensure_ascii=False)}; "
        f"child_new_executions={json.dumps(_execution_observation(last_child), ensure_ascii=False)}"
    )


def _destroy(api: RootNocoBaseApi, resource: str, identifier: int) -> None:
    api.request(
        "POST",
        f"/api/{resource}:destroy?" + urllib.parse.urlencode({"filterByTk": str(identifier)}),
        {},
    )


def dry_run() -> dict[str, Any]:
    marker = "<uuid-v4>"
    return {
        "writes_remote": False,
        "environment": "13001 only",
        "confirmation": CONFIRM,
        "parent": {
            "type": "collection",
            "sync": False,
            "enabled_during_execution": True,
            "config": parent_trigger_config(marker),
            "nodes": [
                {"type": "multi-conditions", "config": router_config(marker), "branchIndex": None},
                {"type": "subflow", "config": subflow_config("<child-key>"), "branchIndex": 1},
            ],
        },
        "child": {
            "type": "custom-action",
            "sync": True,
            "enabled_during_execution": True,
            "config": child_config(),
            "node": {"type": "update", "config": child_update_config(marker)},
        },
        "staging_row": {
            "source_system": SENTINEL_SOURCE,
            "request_event": SENTINEL_EVENT,
            "api_type": SENTINEL_API_TYPE,
            "status_transition": f"{INITIAL_STATUS} -> {TRIGGER_STATUS}",
        },
        "cleanup": "disable parent and child; destroy staging row; destroy parent and child in finally",
    }


def apply(timeout_seconds: int) -> dict[str, Any]:
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        raise ApiError("NOCOBASE_TOKEN is required")
    api = RootNocoBaseApi(BASE_URL, token)
    request_api = NocoBaseApi(BASE_URL, token)
    marker = str(uuid.uuid4())
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    child_id: int | None = None
    parent_id: int | None = None
    staging_id: int | None = None
    cleanup_errors: list[str] = []
    primary_error: Exception | None = None
    result: dict[str, Any] | None = None

    try:
        child = api.request(
            "POST",
            "/api/workflows:create",
            {
                "title": f"API Suorce — custom-action subflow sentinel child {stamp}",
                "type": "custom-action",
                "sync": True,
                "enabled": False,
                "config": child_config(),
            },
        )
        if not isinstance(child, Mapping) or not isinstance(child.get("id"), int):
            raise ApiError("sentinel child creation returned no ID")
        child_id = int(child["id"])
        attach_api_source_category(api, child_id)
        child = _read_workflow(api, child_id)
        if child.get("type") != "custom-action" or child.get("sync") is not True or child.get("enabled") is not False:
            raise ApiError("sentinel child configuration did not persist")
        child_node = create_node(
            api,
            child_id,
            "update",
            "Mark exact custom-action subflow sentinel row",
            child_update_config(marker),
        )
        if child_node.get("type") != "update":
            raise ApiError("sentinel child update node did not persist")

        child_key = str(child.get("key") or "")
        if not child_key:
            raise ApiError("sentinel child has no workflow key")
        parent = api.request(
            "POST",
            "/api/workflows:create",
            {
                "title": f"API Suorce — custom-action subflow sentinel parent {stamp}",
                "type": "collection",
                "sync": False,
                "enabled": False,
                "config": parent_trigger_config(marker),
            },
        )
        if not isinstance(parent, Mapping) or not isinstance(parent.get("id"), int):
            raise ApiError("sentinel parent creation returned no ID")
        parent_id = int(parent["id"])
        attach_api_source_category(api, parent_id)
        parent = _read_workflow(api, parent_id)
        router = create_node(
            api,
            parent_id,
            "multi-conditions",
            "Route exact custom-action subflow sentinel",
            router_config(marker),
        )
        invoke = create_node(
            api,
            parent_id,
            "subflow",
            "Invoke exact custom-action sentinel child",
            subflow_config(child_key),
        )
        # multi-conditions branch indexes are one-based.
        link(api, router, invoke, branch_index=1)
        parent = _read_workflow(api, parent_id)
        if len(parent.get("nodes") or []) != 2 or parent.get("enabled") is not False:
            raise ApiError("sentinel parent graph did not persist")

        # Create an inert row before either temporary workflow is enabled.
        created = request_api.request(
            "POST",
            f"/api/{COLLECTION}:create",
            {
                "f_request_body": {"request_id": f"custom-action-subflow-{marker}"},
                "f_source_system": SENTINEL_SOURCE,
                "f_request_event": SENTINEL_EVENT,
                "f_api_type": SENTINEL_API_TYPE,
                "f_application_type": "subflow_sentinel",
                "f_client_request_id": marker,
                "f_user_role": "root",
                "f_status": INITIAL_STATUS,
            },
        )
        if not isinstance(created, Mapping) or not isinstance(created.get("id"), int):
            raise ApiError("sentinel staging row creation returned no ID")
        staging_id = int(created["id"])

        before_parent = _execution_snapshot(api, parent_id)
        before_child = _execution_snapshot(api, child_id)
        set_enabled(api, child_id, True)
        set_enabled(api, parent_id, True)
        if not _read_workflow(api, child_id).get("enabled") or not _read_workflow(api, parent_id).get("enabled"):
            raise ApiError("temporary sentinel workflow did not enable")
        # Listener registration is asynchronous after an enable call.
        time.sleep(1.5)
        request_api.request(
            "POST",
            f"/api/{COLLECTION}:update?" + urllib.parse.urlencode({"filterByTk": str(staging_id)}),
            {"f_status": TRIGGER_STATUS},
        )
        expected_marker = f"custom-action-subflow-sentinel:{marker}"
        result = {
            "probe": "passed",
            "marker": marker,
            "child_enabled": True,
            **_wait_for_marker(
                api,
                request_api,
                staging_id=staging_id,
                parent_id=parent_id,
                child_id=child_id,
                before_parent=before_parent,
                before_child=before_child,
                marker=marker,
                expected_marker=expected_marker,
                timeout_seconds=timeout_seconds,
            ),
        }
    except Exception as exc:  # Cleanup still runs for every failed assertion.
        primary_error = exc
    finally:
        for workflow_id, label in ((parent_id, "parent"), (child_id, "child")):
            if workflow_id is None:
                continue
            try:
                set_enabled(api, workflow_id, False)
            except Exception as exc:  # pragma: no cover - remote cleanup guard
                cleanup_errors.append(f"{label}_disable:{exc}")
        if staging_id is not None:
            try:
                _destroy(api, COLLECTION, staging_id)
            except Exception as exc:  # pragma: no cover - remote cleanup guard
                cleanup_errors.append(f"staging_destroy:{exc}")
        for workflow_id, label in ((parent_id, "parent"), (child_id, "child")):
            if workflow_id is None:
                continue
            try:
                _destroy(api, "workflows", workflow_id)
            except Exception as exc:  # pragma: no cover - remote cleanup guard
                cleanup_errors.append(f"{label}_destroy:{exc}")
    if cleanup_errors:
        raise ApiError("sentinel cleanup failed: " + " | ".join(cleanup_errors))
    if primary_error is not None:
        raise primary_error
    if result is None:  # pragma: no cover - defensive completeness
        raise ApiError("sentinel returned no result")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true", help="Run the disposable 13001 probe.")
    parser.add_argument("--confirm", default="")
    parser.add_argument("--timeout-seconds", type=int, default=25)
    parser.add_argument(
        "--result-file",
        type=Path,
        help=(
            "Write the successful, non-secret probe result as a new 0600 JSON file. "
            "The file can be supplied to the disabled-candidate preparation guard."
        ),
    )
    args = parser.parse_args()
    if args.timeout_seconds < 5 or args.timeout_seconds > 60:
        parser.error("--timeout-seconds must be between 5 and 60")
    if not args.apply:
        print(json.dumps(dry_run(), ensure_ascii=False, indent=2))
        return 0
    if args.confirm != CONFIRM:
        parser.error(f"--apply requires --confirm {CONFIRM}")
    try:
        result = apply(args.timeout_seconds)
        if args.result_file is not None:
            destination = args.result_file.resolve()
            destination.parent.mkdir(parents=True, exist_ok=True)
            # Evidence must be immutable once recorded; it is intentionally
            # non-secret, but restrictive permissions avoid accidental edits.
            descriptor = os.open(
                destination,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL,
                0o600,
            )
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                    json.dump(result, stream, ensure_ascii=False, indent=2)
                    stream.write("\n")
            except Exception:
                try:
                    destination.unlink()
                except FileNotFoundError:
                    pass
                raise
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
