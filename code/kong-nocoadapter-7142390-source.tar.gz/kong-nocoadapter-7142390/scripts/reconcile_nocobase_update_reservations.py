#!/usr/bin/env python3
"""Audit and explicitly recover one stale API Update reservation.

The default mode is read-only. Recovery is deliberately fail-closed: a lock
is recoverable only when one matching UPDATE staging row exists, that row has
already reached a terminal state, both rows are older than the configured
threshold, and their API/application identity matches the reviewed contract.

Reservations with no child row are *not* automatically recoverable. The
adapter may have persisted the parent compare-and-set immediately before an
interruption while creating the child row. Likewise, a submitted/processing
child may still own business writes even when it is old. Both cases require
manual workflow/execution inspection.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping, Sequence
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import ApiError

COLLECTION = "t_api_request_staging"
ACTIVE_STATUSES = ("submitted", "processing")
TERMINAL_STATUSES = ("succeeded", "failed")
CONFIRMATION_PHRASE = "CLEAR_STALE_UPDATE_RESERVATION"

# Only application families whose adapter path reserves f_active_update_id and
# whose reviewed workflow puts f_status into a terminal value before its final
# lock-release node may be recovered by this tool.
SUPPORTED_UPDATE_APIS = {
    "self_withdraw": "update_self_withdraw_data",
    "revoke_licence": "update_revoke_licence_data",
    "specific_hour": "update_specific_hour_data",
    "responsible_person": "update_rp_data",
    "change_home_manager": "update_change_home_manager_data",
    "change_beds": "update_change_beds_data",
    "change_operation_mode": "update_change_operation_mode_data",
    "change_directors": "update_change_directors_data",
    "change_nurse_in_charge": "update_change_nurse_in_charge_data",
}
SUPPORTED_CREATE_APIS = {
    "self_withdraw": "create_intake_for_self_withdraw",
    "revoke_licence": "create_intake_for_revoke_licence",
    "specific_hour": "create_intake_for_specific_hour",
    "responsible_person": "create_intake_for_rp",
    "change_home_manager": "create_intake_for_change_home_manager",
    "change_beds": "create_intake_for_change_beds",
    "change_operation_mode": "create_intake_for_change_operation_mode",
    "change_directors": "create_intake_for_change_directors",
    "change_nurse_in_charge": "create_intake_for_change_nurse_in_charge",
}


def parse_timestamp(value: object) -> Optional[datetime]:
    if not isinstance(value, str) or not value.strip():
        return None
    normalized = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _list(
    api: RootNocoBaseApi,
    filters: Mapping[str, Any],
    *,
    page_size: int = 500,
) -> list[dict[str, Any]]:
    """Read every matching row instead of silently trusting the first page."""

    result: list[dict[str, Any]] = []
    page = 1
    while True:
        query = urllib.parse.urlencode(
            {
                "filter": json.dumps(filters, separators=(",", ":")),
                "page": page,
                "pageSize": page_size,
                "sort[]": "id",
            }
        )
        rows = api.request("GET", f"/api/{COLLECTION}:list?{query}") or []
        page_rows = [dict(row) for row in rows if isinstance(row, dict)]
        result.extend(page_rows)
        if len(page_rows) < page_size:
            return result
        page += 1


def reservation_children(
    api: RootNocoBaseApi,
    *,
    parent_id: object,
    reservation_id: str,
) -> list[dict[str, Any]]:
    return _list(
        api,
        {
            "$and": [
                {"f_request_event": {"$eq": "UPDATE"}},
                {"f_parent_create_id": {"$eq": str(parent_id)}},
                {"f_active_update_id": {"$eq": reservation_id}},
            ]
        },
    )


def active_children(
    api: RootNocoBaseApi,
    *,
    parent_id: object,
    reservation_id: str | None = None,
) -> list[dict[str, Any]]:
    filters: list[dict[str, Any]] = [
        {"f_request_event": {"$eq": "UPDATE"}},
        {"f_parent_create_id": {"$eq": str(parent_id)}},
        {
            "$or": [
                {"f_status": {"$eq": status}} for status in ACTIVE_STATUSES
            ]
        },
    ]
    if reservation_id is not None:
        filters.append({"f_active_update_id": {"$eq": reservation_id}})
    return _list(api, {"$and": filters})


def _identity_reasons(
    parent: Mapping[str, Any], child: Mapping[str, Any]
) -> list[str]:
    reasons: list[str] = []
    application_type = str(parent.get("f_application_type") or "")
    expected_update_api = SUPPORTED_UPDATE_APIS.get(application_type)
    expected_create_api = SUPPORTED_CREATE_APIS.get(application_type)
    if expected_update_api is None or expected_create_api is None:
        reasons.append("unsupported_application_type")
    if parent.get("f_request_event") != "CREATE":
        reasons.append("parent_is_not_create")
    if parent.get("f_status") != "succeeded":
        reasons.append("parent_is_not_succeeded")
    if parent.get("f_application_status") != "Accepted":
        reasons.append("parent_is_not_accepted")
    if parent.get("f_api_type") != expected_create_api:
        reasons.append("parent_create_api_mismatch")
    if parent.get("f_intake_id") in (None, ""):
        reasons.append("parent_intake_id_missing")
    if parent.get("f_application_id") in (None, ""):
        reasons.append("parent_application_id_missing")
    if child.get("f_application_type") != application_type:
        reasons.append("child_application_type_mismatch")
    if child.get("f_api_type") != expected_update_api:
        reasons.append("child_update_api_mismatch")
    return reasons


def assess_reservation(
    api: RootNocoBaseApi,
    parent: Mapping[str, Any],
    *,
    now: datetime,
    stale_after: timedelta,
) -> tuple[str, dict[str, Any]]:
    """Return ``recoverable``, ``active`` or ``manual_review`` and evidence."""

    parent_id = parent.get("id")
    reservation_id = str(parent.get("f_active_update_id") or "")
    children = reservation_children(
        api,
        parent_id=parent_id,
        reservation_id=reservation_id,
    )
    active_for_parent = active_children(api, parent_id=parent_id)
    threshold = now.astimezone(timezone.utc) - stale_after
    parent_updated_at = parse_timestamp(parent.get("updatedAt"))
    summary: dict[str, Any] = {
        "id": parent_id,
        "reservation_id": reservation_id,
        "updated_at": parent.get("updatedAt"),
        "intake_id": parent.get("f_intake_id"),
        "application_id": parent.get("f_application_id"),
        "application_type": parent.get("f_application_type"),
        "application_status": parent.get("f_application_status"),
        "child_ids": [row.get("id") for row in children],
        "child_statuses": [row.get("f_status") for row in children],
        "child_errors": [row.get("f_error_message") for row in children],
        "active_child_ids": [row.get("id") for row in active_for_parent],
        "reasons": [],
    }

    if not reservation_id:
        summary["reasons"] = ["reservation_id_missing"]
        return "manual_review", summary
    if len(children) == 0:
        summary["reasons"] = ["no_matching_update_child"]
        if parent_updated_at is not None and parent_updated_at > threshold:
            return "active", summary
        return "manual_review", summary
    if len(children) != 1:
        summary["reasons"] = ["multiple_matching_update_children"]
        return "manual_review", summary

    child = children[0]
    child_status = child.get("f_status")
    child_updated_at = parse_timestamp(child.get("updatedAt"))
    summary["child_updated_at"] = child.get("updatedAt")
    if child_status in ACTIVE_STATUSES:
        reason = (
            "stale_active_update_child"
            if child_updated_at is not None and child_updated_at <= threshold
            else "active_update_child"
        )
        summary["reasons"] = [reason]
        return (
            "manual_review" if reason == "stale_active_update_child" else "active"
        ), summary
    if child_status not in TERMINAL_STATUSES:
        summary["reasons"] = ["unknown_update_child_status"]
        return "manual_review", summary
    if active_for_parent:
        summary["reasons"] = ["another_active_update_child_exists"]
        return "manual_review", summary
    if parent_updated_at is None or child_updated_at is None:
        summary["reasons"] = ["missing_or_invalid_timestamp"]
        return "manual_review", summary
    if parent_updated_at > threshold or child_updated_at > threshold:
        summary["reasons"] = ["terminal_child_finalizer_grace_period"]
        return "active", summary

    identity_reasons = _identity_reasons(parent, child)
    if identity_reasons:
        summary["reasons"] = identity_reasons
        return "manual_review", summary
    summary["reasons"] = ["terminal_child_finalizer_stale"]
    return "recoverable", summary


def audit_reservations(
    api: RootNocoBaseApi,
    *,
    now: datetime,
    stale_after: timedelta,
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
]:
    parents = _list(
        api,
        {
            "$and": [
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_active_update_id": {"$notEmpty": True}},
            ]
        },
    )
    recoverable: list[dict[str, Any]] = []
    manual_review: list[dict[str, Any]] = []
    active: list[dict[str, Any]] = []
    buckets = {
        "recoverable": recoverable,
        "manual_review": manual_review,
        "active": active,
    }
    for parent in parents:
        classification, summary = assess_reservation(
            api,
            parent,
            now=now,
            stale_after=stale_after,
        )
        buckets[classification].append(summary)
    return recoverable, manual_review, active


def _one_parent(
    api: RootNocoBaseApi,
    *,
    parent_id: object,
    reservation_id: str | None = None,
) -> dict[str, Any]:
    filters: list[dict[str, Any]] = [
        {"id": {"$eq": parent_id}},
        {"f_request_event": {"$eq": "CREATE"}},
    ]
    if reservation_id is not None:
        filters.append({"f_active_update_id": {"$eq": reservation_id}})
    rows = _list(api, {"$and": filters}, page_size=2)
    if len(rows) != 1:
        raise ApiError("Expected exactly one matching CREATE staging parent")
    return rows[0]


def intake_is_complete(api: RootNocoBaseApi, intake_id: object) -> bool:
    if intake_id in (None, ""):
        return False
    query = urllib.parse.urlencode({"filterByTk": str(intake_id)})
    row = api.request("GET", f"/api/t_intake_form:get?{query}")
    return isinstance(row, dict) and str(row.get("f_approval_status")) == "4"


def _clear_reservation_cas(
    api: RootNocoBaseApi,
    *,
    parent: Mapping[str, Any],
    reservation_id: str,
    publish_received: bool,
) -> None:
    filters = {
        "$and": [
            {"id": {"$eq": parent.get("id")}},
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_status": {"$eq": "succeeded"}},
            {"f_application_status": {"$eq": "Accepted"}},
            {
                "f_application_type": {
                    "$eq": parent.get("f_application_type")
                }
            },
            {"f_active_update_id": {"$eq": reservation_id}},
        ]
    }
    query = urllib.parse.urlencode(
        {"filter": json.dumps(filters, separators=(",", ":"))}
    )
    values: dict[str, Any] = {"f_active_update_id": None}
    if publish_received:
        values["f_application_status"] = "Received"
    api.request("POST", f"/api/{COLLECTION}:update?{query}", values)


def publish_received_if_complete(
    api: RootNocoBaseApi,
    *,
    parent_id: object,
    intake_id: object,
) -> bool:
    if not intake_is_complete(api, intake_id):
        return False
    filters = {
        "$and": [
            {"id": {"$eq": parent_id}},
            {"f_status": {"$eq": "succeeded"}},
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_application_status": {"$eq": "Accepted"}},
            {"f_active_update_id": {"$empty": True}},
        ]
    }
    query = urllib.parse.urlencode(
        {"filter": json.dumps(filters, separators=(",", ":"))}
    )
    api.request(
        "POST",
        f"/api/{COLLECTION}:update?{query}",
        {"f_application_status": "Received"},
    )
    parent = _one_parent(api, parent_id=parent_id)
    return bool(
        parent.get("f_application_status") == "Received"
        and not parent.get("f_active_update_id")
    )


def recover_reservation(
    api: RootNocoBaseApi,
    *,
    parent_id: object,
    reservation_id: str,
    now: datetime,
    stale_after: timedelta,
) -> dict[str, Any]:
    """Re-evaluate and compare-and-set one explicitly identified lock."""

    parent = _one_parent(
        api,
        parent_id=parent_id,
        reservation_id=reservation_id,
    )
    classification, evidence = assess_reservation(
        api,
        parent,
        now=now,
        stale_after=stale_after,
    )
    if classification != "recoverable":
        reasons = ",".join(str(value) for value in evidence["reasons"])
        raise ApiError(f"Reservation is not recoverable: {reasons}")

    complete_before_clear = intake_is_complete(api, parent.get("f_intake_id"))
    _clear_reservation_cas(
        api,
        parent=parent,
        reservation_id=reservation_id,
        publish_received=complete_before_clear,
    )
    current = _one_parent(api, parent_id=parent_id)
    if current.get("f_active_update_id"):
        raise ApiError("Reservation compare-and-set did not clear the expected lock")
    if complete_before_clear and current.get("f_application_status") != "Received":
        raise ApiError("Completed Intake was not atomically published as Received")

    # If Intake completed concurrently with the compare-and-set, publish only
    # while the parent is still Accepted and no new Update owns the lock.
    received = current.get("f_application_status") == "Received"
    if not received:
        received = publish_received_if_complete(
            api,
            parent_id=parent_id,
            intake_id=parent.get("f_intake_id"),
        )
    return {
        **evidence,
        "cleared": True,
        "received": received,
    }


def _print_rows(prefix: str, rows: Sequence[Mapping[str, Any]]) -> None:
    for row in rows:
        print(
            prefix
            + "="
            + json.dumps(dict(row), ensure_ascii=False, separators=(",", ":"))
        )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--stale-minutes", type=int, default=60)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--recover-parent-id")
    parser.add_argument("--expected-reservation-id")
    parser.add_argument("--operator")
    parser.add_argument("--reason")
    parser.add_argument("--confirm")
    args = parser.parse_args(argv)
    if args.stale_minutes < 15:
        print("error=stale-minutes must be at least 15", file=sys.stderr)
        return 2
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    recovery_values = (
        args.recover_parent_id,
        args.expected_reservation_id,
        args.operator,
        args.reason,
    )
    if args.apply and (
        not all(recovery_values) or args.confirm != CONFIRMATION_PHRASE
    ):
        print(
            "error=targeted recovery requires --recover-parent-id, "
            "--expected-reservation-id, --operator, --reason and "
            f"--confirm {CONFIRMATION_PHRASE}",
            file=sys.stderr,
        )
        return 2
    if not args.apply and any(recovery_values):
        print(
            "error=recovery selectors are accepted only together with --apply",
            file=sys.stderr,
        )
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    now = datetime.now(timezone.utc)
    stale_after = timedelta(minutes=args.stale_minutes)
    recoverable, manual_review, active = audit_reservations(
        api,
        now=now,
        stale_after=stale_after,
    )
    print(f"recoverable_count={len(recoverable)}")
    print(f"manual_review_count={len(manual_review)}")
    print(f"active_or_grace_count={len(active)}")
    _print_rows("recoverable", recoverable)
    _print_rows("manual_review", manual_review)
    _print_rows("active_or_grace", active)
    if not args.apply:
        print("mode=dry-run")
        return 0

    try:
        result = recover_reservation(
            api,
            parent_id=args.recover_parent_id,
            reservation_id=args.expected_reservation_id,
            now=now,
            stale_after=stale_after,
        )
    except ApiError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1
    event = {
        "action": "clear_stale_update_reservation",
        "performed_at": now.isoformat(),
        "operator": args.operator,
        "reason": args.reason,
        **result,
    }
    print(
        "recovery_event="
        + json.dumps(event, ensure_ascii=False, separators=(",", ":"))
    )
    print("mode=targeted-recovery")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ApiError as exc:
        print(f"error={exc}", file=sys.stderr)
        raise SystemExit(1) from exc
