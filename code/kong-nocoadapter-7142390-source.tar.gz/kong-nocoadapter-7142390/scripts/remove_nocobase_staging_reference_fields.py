#!/usr/bin/env python3
"""Remove external Application Ref. and LORCHE/D No. workflow mappings.

The external create-NLA contract does not accept these fields.  The staging
workflow must therefore neither parse them nor write NLA ``f_p_no`` or
``f_d_no``.  The script refuses enabled or unsafe auto-close workflow graphs
and verifies the single-Submit terminal topology before and after the change.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from extend_nocobase_staging_relations import (
    ApiError,
    NocoBaseApi,
    node_by_title,
)

DEFAULT_WORKFLOW_ID = 384761304186880
PARSE_TITLE = "Parse staged request body"
APPLY_TITLE = "Apply staged data to native NLA"
SUBMIT_TITLE = "Run native Intake Form Submit as business submitter"
SUCCESS_TITLE = "Mark succeeded + backfill IDs"
REMOVED_PATHS = {
    "form_data.part_1.application_ref",
    "form_data.part_1.d_no",
}
REMOVED_NLA_FIELDS = {"f_p_no", "f_d_no"}
UNSAFE_CLOSE_TITLES = {
    "Reload Intake for native Close",
    "Run native Intake Close as approval assignee",
    "Close Intake after API submit without recursive hooks",
}


def require_safe_topology(workflow: Mapping[str, Any]) -> None:
    if workflow.get("enabled"):
        raise ApiError("Workflow must be Off before inspection or modification")
    titles = {node.get("title") for node in workflow.get("nodes") or []}
    unsafe = sorted(UNSAFE_CLOSE_TITLES & titles)
    if unsafe:
        raise ApiError(f"Unsafe auto-close nodes are present: {unsafe}")
    submit = node_by_title(workflow, SUBMIT_TITLE)
    success = node_by_title(workflow, SUCCESS_TITLE)
    if submit.get("downstreamId") != success.get("id"):
        raise ApiError("Native Submit must directly precede staging success")
    if success.get("upstreamId") != submit.get("id"):
        raise ApiError("Staging success must directly follow native Submit")


def removed_variable_keys(parse_node: Mapping[str, Any]) -> set[str]:
    return {
        str(variable["key"])
        for variable in (parse_node.get("config") or {}).get("variables") or []
        if variable.get("path") in REMOVED_PATHS and variable.get("key")
    }


def reference_users(
    workflow: Mapping[str, Any], variable_keys: set[str]
) -> set[str]:
    users: set[str] = set()
    for node in workflow.get("nodes") or []:
        serialized = json.dumps(node.get("config") or {}, separators=(",", ":"))
        if any(f".{key}}}}}" in serialized for key in variable_keys):
            users.add(str(node.get("title") or node.get("id")))
    return users


def cleaned_parse_config(parse_node: Mapping[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(parse_node.get("config") or {})
    config["variables"] = [
        variable
        for variable in config.get("variables") or []
        if variable.get("path") not in REMOVED_PATHS
    ]
    example = config.get("example")
    if isinstance(example, dict):
        form_data = example.get("form_data")
        if isinstance(form_data, dict):
            part_1 = form_data.get("part_1")
            if isinstance(part_1, dict):
                part_1.pop("application_ref", None)
                part_1.pop("d_no", None)
    return config


def cleaned_apply_config(apply_node: Mapping[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(apply_node.get("config") or {})
    values = (config.setdefault("params", {})).setdefault("values", {})
    for field in REMOVED_NLA_FIELDS:
        values.pop(field, None)
    return config


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument(
        "--revision",
        action="store_true",
        help="Create an editable workflow revision before removing the fields",
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    require_safe_topology(workflow)
    if args.revision:
        print(f"source_workflow_id={args.workflow_id}")
        if not args.apply:
            print("create_revision=yes")
            print("mode=dry-run")
            return 0
        query = urllib.parse.urlencode(
            {
                "filterByTk": str(args.workflow_id),
                "filter[key]": str(workflow["key"]),
            }
        )
        revision = api.request("POST", f"/api/workflows:revision?{query}", {})
        if not isinstance(revision, dict) or revision.get("id") is None:
            raise ApiError("Workflow revision API did not return a workflow")
        workflow = api.get_workflow(int(revision["id"]))
        require_safe_topology(workflow)
    parse_node = node_by_title(workflow, PARSE_TITLE)
    apply_node = node_by_title(workflow, APPLY_TITLE)
    variable_keys = removed_variable_keys(parse_node)
    users = reference_users(workflow, variable_keys)
    if users - {APPLY_TITLE}:
        raise ApiError(
            "Removed request variables are referenced by unexpected nodes: "
            f"{sorted(users - {APPLY_TITLE})}"
        )

    print(f"workflow_id={workflow['id']}")
    print("workflow_enabled=no")
    print("remove_request_fields=application_ref,d_no")
    print("remove_nla_fields=f_p_no,f_d_no")
    print("native_submit_count=1")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api.update_node(
        int(apply_node["id"]), {"config": cleaned_apply_config(apply_node)}
    )
    api.update_node(
        int(parse_node["id"]), {"config": cleaned_parse_config(parse_node)}
    )

    verified = api.get_workflow(int(workflow["id"]))
    require_safe_topology(verified)
    verified_parse = node_by_title(verified, PARSE_TITLE)
    verified_apply = node_by_title(verified, APPLY_TITLE)
    remaining_paths = {
        variable.get("path")
        for variable in (verified_parse.get("config") or {}).get("variables") or []
    }
    remaining_fields = set(
        ((verified_apply.get("config") or {}).get("params") or {})
        .get("values", {})
    )
    if REMOVED_PATHS & remaining_paths:
        raise ApiError("Removed request fields remain in the parser")
    if REMOVED_NLA_FIELDS & remaining_fields:
        raise ApiError("Removed fields remain in the NLA update node")

    print("workflow_verified=yes")
    print("workflow_enabled=no")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
