#!/usr/bin/env python3
"""Write a UAT-only environment manifest for an offline release archive."""

from __future__ import annotations

import argparse
import copy
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "config/environments.yaml"
HEADER = (
    "# UAT-only offline release profile.\n"
    "# Edit .env after unpacking; no other environment profile is included.\n"
)
OTHER_ENVIRONMENT_MARKERS = (
    "119.91.104.211",
    "cmtf2sit.swd.hksarg",
    "local_test",
    "online_test",
    "development",
    "production",
    "13000",
    "13001",
    "211",
)


def render() -> str:
    source = yaml.safe_load(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(source, dict):
        raise ValueError("invalid source environment manifest")
    environments = source.get("environments")
    if not isinstance(environments, dict) or not isinstance(
        environments.get("uat"), dict
    ):
        raise ValueError("UAT environment profile is missing")
    uat: dict[str, Any] = copy.deepcopy(environments["uat"])
    if (
        uat.get("runtime") != "docker-compose"
        or uat.get("compose_env_file") != ".env"
        or uat.get("upstream_env_file") != ".env"
    ):
        raise ValueError("UAT release must use Docker Compose and its own .env")
    # These source-only denylist entries name other environments. A released
    # UAT profile contains only its own editable parameters and path guard.
    uat.pop("forbidden_upstream_hosts", None)
    document = {
        "schema_version": source.get("schema_version", "1.1"),
        "default_environment": "uat",
        "environments": {"uat": uat},
    }
    return HEADER + yaml.safe_dump(
        document, allow_unicode=True, sort_keys=False, width=100
    )


def validate_stage(stage: Path) -> None:
    """Refuse a release carrying other environments' text parameters."""
    for path in stage.rglob("*"):
        if not path.is_file():
            continue
        value = path.read_text(encoding="utf-8")
        for marker in OTHER_ENVIRONMENT_MARKERS:
            if marker in value:
                relative = path.relative_to(stage)
                raise ValueError(
                    f"other environment parameter in {relative}: {marker}"
                )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--check-dir", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render(), encoding="utf-8")
    if args.check_dir is not None:
        validate_stage(args.check_dir)
    print(f"generated={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
