#!/usr/bin/env python3
"""Assign stable position codes to the seven Expansion AIP checklist leaves.

Only ``f_position_code`` on the seven active leaf rows is ever changed.  Root
and section rows must keep a null code, and all names/catalogue content are
left untouched.  The command is dry-run by default and creates a JSON backup
before the first write when ``--apply`` is used.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

COLLECTION = "t_document_checklist"
USE_FOR = "t_expansion_aip_for_licence"
EXPECTED_CODES = tuple(
    f"LORCHE_EXPANSION_AIP_{index:03d}" for index in range(1, 8)
)


class RepairError(RuntimeError):
    """Raised when the checklist cannot be repaired without guessing."""


@dataclass(frozen=True)
class UpdateAction:
    record_id: int
    values: dict[str, Any]


def _text(value: Any) -> str:
    return str(value).strip() if value is not None else ""


def _record_id(row: Mapping[str, Any]) -> int:
    try:
        return int(row["id"])
    except (KeyError, TypeError, ValueError) as exc:
        raise RepairError("checklist row is missing a valid id") from exc


def _uses_aip(row: Mapping[str, Any]) -> bool:
    value = row.get("f_use_for") or []
    if isinstance(value, str):
        return value == USE_FOR
    return USE_FOR in value


def _sort_key(row: Mapping[str, Any]) -> tuple[int, int]:
    try:
        order = int(row.get("f_sort_order") or 0)
    except (TypeError, ValueError):
        order = 0
    return order, _record_id(row)


def target_rows(rows: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    return [
        row
        for row in rows
        if _uses_aip(row) and row.get("f_active") is not False
    ]


def target_leaves(rows: Sequence[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    return sorted(
        (
            row
            for row in target_rows(rows)
            if _text(row.get("f_item_type")) == "2"
        ),
        key=_sort_key,
    )


def build_repair_plan(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[UpdateAction, ...]:
    """Return deterministic leaf-only writes or reject an unsafe catalogue."""

    leaves = target_leaves(rows)
    if len(leaves) != len(EXPECTED_CODES):
        raise RepairError(
            "Expansion AIP expected exactly "
            f"{len(EXPECTED_CODES)} active leaves, found {len(leaves)}"
        )

    for row in target_rows(rows):
        if _text(row.get("f_item_type")) == "2":
            continue
        code = _text(row.get("f_position_code"))
        if code:
            raise RepairError(
                f"Expansion AIP root/section {_record_id(row)} must keep "
                f"f_position_code NULL, found {code!r}"
            )

    owners: dict[str, int] = {}
    for row in rows:
        code = _text(row.get("f_position_code"))
        if not code:
            continue
        record_id = _record_id(row)
        if code in owners:
            raise RepairError(
                f"duplicate position code {code!r} on "
                f"{owners[code]} and {record_id}"
            )
        owners[code] = record_id

    actions: list[UpdateAction] = []
    for row, expected in zip(leaves, EXPECTED_CODES):
        record_id = _record_id(row)
        current = _text(row.get("f_position_code"))
        if current == expected:
            continue
        if current:
            raise RepairError(
                f"Expansion AIP checklist {record_id} has conflicting "
                f"position code {current!r}; expected {expected!r}"
            )
        other_owner = owners.get(expected)
        if other_owner is not None and other_owner != record_id:
            raise RepairError(
                f"required position code {expected!r} is already used by "
                f"checklist {other_owner}"
            )
        actions.append(
            UpdateAction(record_id, {"f_position_code": expected})
        )
        owners[expected] = record_id
    return tuple(actions)


def simulate_plan(
    rows: Sequence[Mapping[str, Any]],
    plan: Sequence[UpdateAction],
) -> list[dict[str, Any]]:
    result = [copy.deepcopy(dict(row)) for row in rows]
    by_id = {_record_id(row): row for row in result}
    for action in plan:
        by_id[action.record_id].update(copy.deepcopy(action.values))
    return result


def validate_catalogue(rows: Sequence[Mapping[str, Any]]) -> list[str]:
    problems: list[str] = []
    leaves = target_leaves(rows)
    if len(leaves) != len(EXPECTED_CODES):
        problems.append(
            f"leaf_count={len(leaves)} expected={len(EXPECTED_CODES)}"
        )
    for row in target_rows(rows):
        if _text(row.get("f_item_type")) != "2" and _text(
            row.get("f_position_code")
        ):
            problems.append(
                f"root_or_section_code_not_null={_record_id(row)}"
            )
    actual = tuple(_text(row.get("f_position_code")) for row in leaves)
    if actual != EXPECTED_CODES:
        problems.append("position_codes_do_not_match_required_order")
    nonempty_codes = [
        _text(row.get("f_position_code"))
        for row in rows
        if _text(row.get("f_position_code"))
    ]
    if len(nonempty_codes) != len(set(nonempty_codes)):
        problems.append("duplicate_position_code")
    return problems


class RootNocoBaseApi:
    def __init__(self, base_url: str, token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token

    def request(
        self,
        method: str,
        path: str,
        body: Optional[Mapping[str, Any]] = None,
    ) -> Any:
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "X-Role": "root",
        }
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=payload,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:1600]
            raise RepairError(f"HTTP {exc.code} for {path}: {detail}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise RepairError(f"NocoBase error for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded

    def list_catalogue(self) -> list[dict[str, Any]]:
        query = urllib.parse.urlencode(
            [
                ("paginate", "false"),
                ("pageSize", "5000"),
                ("sort[]", "f_sort_order"),
                ("sort[]", "id"),
            ]
        )
        data = self.request("GET", f"/api/{COLLECTION}:list?{query}")
        if isinstance(data, Mapping):
            data = data.get("data")
        if not isinstance(data, list):
            raise RepairError("checklist list response is not an array")
        return [dict(row) for row in data if isinstance(row, Mapping)]

    def update(self, record_id: int, values: Mapping[str, Any]) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(record_id)})
        self.request("POST", f"/api/{COLLECTION}:update?{query}", values)


def _backup_path(directory: Path) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return directory / f"13001-expansion-aip-checklist-before-{stamp}.json"


def write_backup(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "collection": COLLECTION,
        "records": list(rows),
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument(
        "--backup-dir",
        type=Path,
        default=Path("deliverables"),
    )
    parser.add_argument("--apply", action="store_true")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    try:
        before = api.list_catalogue()
        plan = build_repair_plan(before)
        predicted = simulate_plan(before, plan)
        problems = validate_catalogue(predicted)
        print(f"target_leaf_count={len(target_leaves(before))}")
        print(f"planned_change_count={len(plan)}")
        for action in plan:
            print(
                f"planned_update_id={action.record_id} "
                f"position_code={action.values['f_position_code']}"
            )
        if problems:
            for problem in problems:
                print(f"predicted_problem={problem}", file=sys.stderr)
            return 1
        print("predicted_validation=passed")
        if not args.apply:
            print("mode=dry-run")
            return 0

        if plan:
            backup_path = _backup_path(args.backup_dir)
            write_backup(backup_path, before)
            print(f"backup_path={backup_path.resolve()}")
            for action in plan:
                api.update(action.record_id, action.values)
                print(
                    f"updated_checklist_id={action.record_id} "
                    f"position_code={action.values['f_position_code']}"
                )
        else:
            print("backup_path=not-required-no-changes")

        after = api.list_catalogue()
        remaining = build_repair_plan(after)
        post_problems = validate_catalogue(after)
        for problem in post_problems:
            print(f"post_problem={problem}", file=sys.stderr)
        print(f"post_remaining_change_count={len(remaining)}")
        if post_problems or remaining:
            return 1
        print("post_validation=passed")
        return 0
    except (RepairError, json.JSONDecodeError, OSError) as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
