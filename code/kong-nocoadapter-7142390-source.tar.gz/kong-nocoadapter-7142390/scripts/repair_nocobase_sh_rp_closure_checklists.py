#!/usr/bin/env python3
"""Audit and repair SH, RP, and Closure checklist catalogues.

The command is dry-run by default.  Pass ``--apply`` to write the reviewed
repair to NocoBase.  Authentication is read only from ``NOCOBASE_TOKEN`` and
is never accepted as a command-line option or included in output/backups.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

COLLECTION = "t_document_checklist"
OFFICES = ("LORCHE", "LORCHD")


class RepairError(RuntimeError):
    """Raised when the catalogue cannot be repaired without guessing."""


@dataclass(frozen=True)
class CatalogueSpec:
    key: str
    use_for: str
    position_middle: str
    leaf_count: int

    def codes(self, office: str) -> tuple[str, ...]:
        return tuple(
            f"{office}_{self.position_middle}_{index:03d}"
            for index in range(1, self.leaf_count + 1)
        )


SPECS = (
    CatalogueSpec("sh", "t_specific", "SPECIFIC_HOUR", 6),
    CatalogueSpec("rp", "t_rp_application", "RP", 4),
    CatalogueSpec(
        "closure",
        "t_self_withdraw_licence_application",
        "SELF_WITHDRAW",
        4,
    ),
)
SPEC_BY_KEY = {spec.key: spec for spec in SPECS}

# Audit/association fields are intentionally excluded.  Only ordinary
# catalogue values are copied when the Closure LORCHD tree is created.
CLONE_FIELDS = (
    "f_template_version",
    "f_parent_item_code",
    "f_is_mandatory_default",
    "f_is_selectable",
    "f_default_remark",
    "f_item_no",
    "f_checklist_code",
    "f_content_first_layer",
    "f_active",
    "f_name_cn",
    "f_use_for",
    "f_field_type",
    "f_section",
    "f_item_type",
    "f_content_second_layer",
    "f_source_excel_row_no",
    "f_item_code",
    "f_sort_order",
    "f_autofill_by_home_record",
    "f_notes",
    "f_office_code",
    "f_level",
    "f_name_en",
    "f_editable_by",
)
CODE_FIELDS = (
    "f_parent_item_code",
    "f_checklist_code",
    "f_item_code",
    "f_section",
)


@dataclass(frozen=True)
class UpdateAction:
    record_id: int
    values: dict[str, Any]
    reason: str


@dataclass(frozen=True)
class CreateAction:
    values: dict[str, Any]
    reason: str
    source_id: int
    expected_position_code: Optional[str] = None


@dataclass(frozen=True)
class RepairPlan:
    updates: tuple[UpdateAction, ...]
    closure_root: Optional[CreateAction]
    closure_leaves: tuple[CreateAction, ...]
    existing_closure_root_id: Optional[int]

    @property
    def change_count(self) -> int:
        return (
            len(self.updates)
            + int(self.closure_root is not None)
            + len(self.closure_leaves)
        )


def _text(value: Any) -> str:
    return str(value).strip() if value is not None else ""


def _record_id(row: Mapping[str, Any]) -> int:
    try:
        return int(row["id"])
    except (KeyError, TypeError, ValueError) as exc:
        raise RepairError("checklist row is missing a valid id") from exc


def _sort_key(row: Mapping[str, Any]) -> tuple[int, int]:
    try:
        order = int(row.get("f_sort_order") or 0)
    except (TypeError, ValueError):
        order = 0
    return order, _record_id(row)


def _uses(row: Mapping[str, Any], collection: str) -> bool:
    value = row.get("f_use_for") or []
    if isinstance(value, str):
        return value == collection
    return collection in value


def _is_leaf(row: Mapping[str, Any], spec: CatalogueSpec, office: str) -> bool:
    return (
        _text(row.get("f_item_type")) == "2"
        and _text(row.get("f_office_code")) == office
        and _uses(row, spec.use_for)
        and row.get("f_active") is not False
    )


def target_leaves(
    rows: Sequence[Mapping[str, Any]], spec: CatalogueSpec, office: str
) -> list[Mapping[str, Any]]:
    return sorted((row for row in rows if _is_leaf(row, spec, office)), key=_sort_key)


def _name_patch(row: Mapping[str, Any]) -> dict[str, str]:
    name_en = _text(row.get("f_name_en"))
    name_cn = _text(row.get("f_name_cn"))
    if not name_en and name_cn:
        return {"f_name_en": name_cn}
    if name_en and not name_cn:
        return {"f_name_cn": name_en}
    if not name_en and not name_cn:
        raise RepairError(f"checklist {_record_id(row)} has no English/Chinese name")
    return {}


def _clone_values(row: Mapping[str, Any], *, office: str) -> dict[str, Any]:
    values = {
        field: copy.deepcopy(row[field]) for field in CLONE_FIELDS if field in row
    }
    values["f_office_code"] = office
    for field in CODE_FIELDS:
        value = values.get(field)
        if isinstance(value, str):
            values[field] = value.replace("LORCHE", office)
    return values


def _closure_source(
    rows: Sequence[Mapping[str, Any]], spec: CatalogueSpec
) -> tuple[Mapping[str, Any], list[Mapping[str, Any]]]:
    leaves = target_leaves(rows, spec, "LORCHE")
    if len(leaves) != spec.leaf_count:
        raise RepairError(
            f"closure LORCHE expected {spec.leaf_count} leaves, found {len(leaves)}"
        )
    parent_ids = {_text(row.get("parentId")) for row in leaves}
    if "" in parent_ids or len(parent_ids) != 1:
        raise RepairError("closure LORCHE leaves do not share one valid parent")
    parent_id = next(iter(parent_ids))
    parents = [row for row in rows if _text(row.get("id")) == parent_id]
    if len(parents) != 1:
        raise RepairError("closure LORCHE root was not found uniquely")
    return parents[0], leaves


def _target_closure_root(
    rows: Sequence[Mapping[str, Any]], leaves: Sequence[Mapping[str, Any]]
) -> Optional[Mapping[str, Any]]:
    if leaves:
        parent_ids = {_text(row.get("parentId")) for row in leaves}
        if "" in parent_ids or len(parent_ids) != 1:
            raise RepairError("closure LORCHD leaves do not share one valid parent")
        parent_id = next(iter(parent_ids))
        parents = [row for row in rows if _text(row.get("id")) == parent_id]
        if len(parents) != 1:
            raise RepairError("closure LORCHD root was not found uniquely")
        return parents[0]

    spec = SPEC_BY_KEY["closure"]
    candidates = [
        row
        for row in rows
        if _text(row.get("f_office_code")) == "LORCHD"
        and _text(row.get("f_item_type")) != "2"
        and _uses(row, spec.use_for)
        and row.get("f_active") is not False
    ]
    if len(candidates) > 1:
        raise RepairError("multiple closure LORCHD roots were found")
    return candidates[0] if candidates else None


def build_repair_plan(rows: Sequence[Mapping[str, Any]]) -> RepairPlan:
    """Build a deterministic, non-destructive repair plan."""
    updates: list[UpdateAction] = []

    for spec in (SPEC_BY_KEY["sh"], SPEC_BY_KEY["rp"]):
        for office in OFFICES:
            leaves = target_leaves(rows, spec, office)
            if len(leaves) != spec.leaf_count:
                raise RepairError(
                    f"{spec.key} {office} expected {spec.leaf_count} leaves, "
                    f"found {len(leaves)}"
                )
            expected_codes = spec.codes(office)
            for index, row in enumerate(leaves):
                values = _name_patch(row)
                if spec.key == "rp" and office == "LORCHD":
                    current = _text(row.get("f_position_code"))
                    expected = expected_codes[index]
                    if not current:
                        values["f_position_code"] = expected
                    elif current != expected:
                        raise RepairError(
                            f"RP LORCHD checklist {_record_id(row)} has "
                            "unexpected position code "
                            f"{current!r}; expected {expected!r}"
                        )
                if values:
                    updates.append(
                        UpdateAction(
                            record_id=_record_id(row),
                            values=values,
                            reason=f"repair_{spec.key}_{office.lower()}_leaf",
                        )
                    )

    closure = SPEC_BY_KEY["closure"]
    source_root, source_leaves = _closure_source(rows, closure)
    target = target_leaves(rows, closure, "LORCHD")
    if len(target) > closure.leaf_count:
        raise RepairError(
            f"closure LORCHD expected at most {closure.leaf_count} leaves, "
            f"found {len(target)}"
        )
    target_root = _target_closure_root(rows, target)

    root_action: Optional[CreateAction] = None
    existing_root_id: Optional[int] = None
    if target_root is None:
        values = _clone_values(source_root, office="LORCHD")
        values["parentId"] = None
        values.update(_name_patch(values))
        root_action = CreateAction(
            values=values,
            reason="clone_closure_lorchd_root",
            source_id=_record_id(source_root),
        )
    else:
        existing_root_id = _record_id(target_root)
        root_patch = _name_patch(target_root)
        if root_patch:
            updates.append(
                UpdateAction(
                    existing_root_id,
                    root_patch,
                    "repair_closure_lorchd_root_name",
                )
            )

    expected_codes = closure.codes("LORCHD")
    target_by_code: dict[str, Mapping[str, Any]] = {}
    uncoded: list[Mapping[str, Any]] = []
    for row in target:
        code = _text(row.get("f_position_code"))
        if code:
            if code not in expected_codes:
                raise RepairError(
                    f"Closure LORCHD checklist {_record_id(row)} has "
                    f"unexpected position code {code!r}"
                )
            if code in target_by_code:
                raise RepairError(f"duplicate position code {code!r}")
            target_by_code[code] = row
        else:
            uncoded.append(row)

    # Map pre-existing uncoded leaves by stable catalogue order.  This also
    # makes a rerun recover safely if a previous clone stopped midway.
    missing_codes = [code for code in expected_codes if code not in target_by_code]
    for row, code in zip(uncoded, missing_codes):
        values = _name_patch(row)
        values["f_position_code"] = code
        updates.append(
            UpdateAction(_record_id(row), values, "repair_closure_lorchd_leaf")
        )
        target_by_code[code] = row
    missing_codes = [code for code in expected_codes if code not in target_by_code]

    source_by_index = dict(zip(expected_codes, source_leaves))
    create_leaves: list[CreateAction] = []
    for code in missing_codes:
        source = source_by_index[code]
        values = _clone_values(source, office="LORCHD")
        values["f_position_code"] = code
        values.update(_name_patch(values))
        # Filled with the created/existing root ID immediately before write.
        values.pop("parentId", None)
        create_leaves.append(
            CreateAction(
                values=values,
                reason="clone_closure_lorchd_leaf",
                source_id=_record_id(source),
                expected_position_code=code,
            )
        )

    return RepairPlan(
        updates=tuple(updates),
        closure_root=root_action,
        closure_leaves=tuple(create_leaves),
        existing_closure_root_id=existing_root_id,
    )


def simulate_plan(
    rows: Sequence[Mapping[str, Any]], plan: RepairPlan
) -> list[dict[str, Any]]:
    """Apply a plan in memory so dry-run can prove the expected end state."""
    result = [copy.deepcopy(dict(row)) for row in rows]
    by_id = {_record_id(row): row for row in result}
    for action in plan.updates:
        by_id[action.record_id].update(copy.deepcopy(action.values))

    next_id = -1
    root_id = plan.existing_closure_root_id
    if plan.closure_root is not None:
        root_id = next_id
        root = copy.deepcopy(plan.closure_root.values)
        root["id"] = root_id
        result.append(root)
        next_id -= 1
    if root_id is None and plan.closure_leaves:
        raise RepairError("closure LORCHD root is unavailable for leaf creation")
    for action in plan.closure_leaves:
        leaf = copy.deepcopy(action.values)
        leaf.update({"id": next_id, "parentId": root_id})
        next_id -= 1
        result.append(leaf)
    return result


def validate_catalogue(rows: Sequence[Mapping[str, Any]]) -> list[str]:
    """Return all catalogue contract violations without mutating data."""
    problems: list[str] = []
    all_codes: dict[str, int] = {}
    by_id = {_text(row.get("id")): row for row in rows if _text(row.get("id"))}
    for spec in SPECS:
        for office in OFFICES:
            leaves = target_leaves(rows, spec, office)
            prefix = f"{spec.key}.{office}"
            if len(leaves) != spec.leaf_count:
                problems.append(
                    f"{prefix}: leaf_count={len(leaves)} expected={spec.leaf_count}"
                )
            actual_codes = {_text(row.get("f_position_code")) for row in leaves}
            expected_codes = set(spec.codes(office))
            if actual_codes != expected_codes:
                problems.append(
                    f"{prefix}: position_codes do not match the required set"
                )
            for row in leaves:
                record_id = _record_id(row)
                name_en = _text(row.get("f_name_en"))
                name_cn = _text(row.get("f_name_cn"))
                if not name_en or not name_cn:
                    problems.append(
                        f"{prefix}: checklist {record_id} has an empty name"
                    )
                code = _text(row.get("f_position_code"))
                if code:
                    if code in all_codes:
                        problems.append(
                            f"duplicate position_code={code} on "
                            f"{all_codes[code]} and {record_id}"
                        )
                    all_codes[code] = record_id
                parent = by_id.get(_text(row.get("parentId")))
                if parent is None:
                    problems.append(f"{prefix}: checklist {record_id} has no parent")
                elif _text(parent.get("f_office_code")) != office:
                    problems.append(
                        f"{prefix}: checklist {record_id} parent office mismatches"
                    )
    return problems


class RootNocoBaseApi:
    def __init__(self, base_url: str, token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "X-Role": "root",
        }
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode()
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=payload,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")[:1600]
            raise RepairError(f"HTTP {exc.code} for {path}: {detail}") from exc
        decoded = json.loads(raw) if raw else None
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise RepairError(f"NocoBase error for {path}: {decoded['errors']}")
        return decoded.get("data") if isinstance(decoded, dict) else decoded

    def list_catalogue(self) -> list[dict[str, Any]]:
        query = urllib.parse.urlencode(
            [
                ("paginate", "false"),
                ("pageSize", "5000"),
                ("sort[]", "f_sort_order"),
                ("sort[]", "id"),
            ]
        )
        data = self.request("GET", f"/api/{COLLECTION}:list?{query}")
        if isinstance(data, Mapping):
            data = data.get("data")
        if not isinstance(data, list):
            raise RepairError("checklist list response is not an array")
        return [dict(row) for row in data if isinstance(row, Mapping)]

    def update(self, record_id: int, values: Mapping[str, Any]) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(record_id)})
        self.request("POST", f"/api/{COLLECTION}:update?{query}", values)

    def create(self, values: Mapping[str, Any]) -> Mapping[str, Any]:
        data = self.request("POST", f"/api/{COLLECTION}:create", values)
        if not isinstance(data, Mapping) or data.get("id") is None:
            raise RepairError("created checklist response does not include an id")
        return data


def _backup_path(directory: Path) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return directory / f"13001-sh-rp-closure-checklists-before-{stamp}.json"


def write_backup(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "collection": COLLECTION,
        "records": list(rows),
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def apply_plan(api: RootNocoBaseApi, plan: RepairPlan) -> None:
    for action in plan.updates:
        api.update(action.record_id, action.values)
        print(f"updated_checklist_id={action.record_id} reason={action.reason}")

    root_id = plan.existing_closure_root_id
    if plan.closure_root is not None:
        root = api.create(plan.closure_root.values)
        root_id = int(root["id"])
        print(f"created_closure_root_id={root_id}")
    if root_id is None and plan.closure_leaves:
        raise RepairError("closure LORCHD root is unavailable for leaf creation")
    for action in plan.closure_leaves:
        values = copy.deepcopy(action.values)
        values["parentId"] = root_id
        row = api.create(values)
        print(
            "created_closure_leaf_id="
            f"{row['id']} position_code={action.expected_position_code}"
        )


def _print_plan(plan: RepairPlan) -> None:
    print(f"planned_change_count={plan.change_count}")
    print(f"planned_update_count={len(plan.updates)}")
    print(f"planned_closure_root_create={int(plan.closure_root is not None)}")
    print(f"planned_closure_leaf_create_count={len(plan.closure_leaves)}")
    for action in plan.updates:
        print(f"planned_update_id={action.record_id} reason={action.reason}")
    for action in plan.closure_leaves:
        print(f"planned_create_position_code={action.expected_position_code}")


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument(
        "--backup-dir",
        type=Path,
        default=Path("deliverables"),
        help="directory for the pre-write JSON backup (used only with --apply)",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="write the repair; without this flag the command is dry-run only",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    try:
        before = api.list_catalogue()
        plan = build_repair_plan(before)
        _print_plan(plan)
        predicted_problems = validate_catalogue(simulate_plan(before, plan))
        if predicted_problems:
            for problem in predicted_problems:
                print(f"predicted_problem={problem}", file=sys.stderr)
            return 1
        print("predicted_validation=passed")
        if not args.apply:
            print("mode=dry-run")
            return 0

        if plan.change_count:
            backup = _backup_path(args.backup_dir)
            write_backup(backup, before)
            print(f"backup_path={backup.resolve()}")
            apply_plan(api, plan)
        else:
            print("backup_path=not-required-no-changes")

        after = api.list_catalogue()
        problems = validate_catalogue(after)
        if problems:
            for problem in problems:
                print(f"post_problem={problem}", file=sys.stderr)
            return 1
        # Re-plan is the idempotency proof: a successful repair must be a no-op.
        remaining = build_repair_plan(after)
        print(f"post_remaining_change_count={remaining.change_count}")
        print("post_validation=passed")
        return 0 if remaining.change_count == 0 else 1
    except (RepairError, json.JSONDecodeError, OSError) as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
