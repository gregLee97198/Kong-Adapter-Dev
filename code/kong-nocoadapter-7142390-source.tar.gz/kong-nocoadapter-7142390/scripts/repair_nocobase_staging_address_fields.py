#!/usr/bin/env python3
"""Install portable address/type lookup and the missing native NLA fields.

The public API sends address content plus region/district/sub-district codes. It
never sends a NocoBase address record ID or the UI-only Address Select value.
This repair keeps the collection workflow Off while editing it and resolves all
environment-specific IDs inside NocoBase at runtime.
"""

from __future__ import annotations

import argparse
import copy
import os
import sys

from extend_nocobase_staging_relations import (
    ADDRESS_FIELDS,
    ApiError,
    NocoBaseApi,
    node_by_title,
    normalize_script,
)

DEFAULT_WORKFLOW_ID = 384624645046272
ADDRESS_LOOKUP_TITLE = "Resolve Region District Sub-district codes"
RCH_TYPE_LOOKUP_TITLE = "Resolve RCH type code for office"
MAIN_ADDRESS_TITLE = "Create main RCH address from API data"


def reference(node_key: str, suffix: str = "") -> str:
    tail = f".{suffix}" if suffix else ""
    return "{{$jobsMapByNodeKey." + node_key + tail + "}}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    if workflow.get("enabled"):
        raise ApiError("Refusing to modify an enabled workflow")
    if workflow.get("executed"):
        raise ApiError("Refusing to modify an executed workflow version")
    installed = {
        str(node.get("title")): node
        for node in workflow.get("nodes") or []
        if node.get("title")
        in {ADDRESS_LOOKUP_TITLE, RCH_TYPE_LOOKUP_TITLE, MAIN_ADDRESS_TITLE}
    }

    parse = node_by_title(workflow, "Parse staged request body")
    find_nla = node_by_title(workflow, "Find native-created NLA")
    apply_nla = node_by_title(workflow, "Apply staged data to native NLA")
    condition = node_by_title(workflow, "NLA fields applied successfully?")
    normalize = node_by_title(workflow, "Normalize complete NLA relation data")
    applicant_loop = node_by_title(workflow, "04A 申请人及地址－新增")
    address_template = node_by_title(
        workflow, "04A 申请人及地址－建立通讯地址"
    )
    form_data_variables = [
        variable
        for variable in (parse.get("config") or {}).get("variables") or []
        if variable.get("path") == "form_data"
    ]
    if len(form_data_variables) != 1:
        raise ApiError("Expected one parsed form_data variable")
    form_data_ref = reference(parse["key"], form_data_variables[0]["key"])

    print(f"workflow_id={args.workflow_id}")
    print("public_address_select_field=no")
    print("address_dictionary=f_tree_region_district.f_code")
    print("rch_type_dictionary=f_rch_type_options.f_code")
    print("workflow_enabled=no")
    print(f"existing_repair_nodes={len(installed)}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    address_lookup = installed.get(ADDRESS_LOOKUP_TITLE)
    if address_lookup is None:
        address_lookup = api.create_node(
            {
            "workflowId": args.workflow_id,
            "type": "query",
            "title": ADDRESS_LOOKUP_TITLE,
            "config": {
                "collection": "f_tree_region_district",
                "multiple": True,
                "params": {
                    "filter": {},
                    "sort": [],
                    "page": 1,
                    "pageSize": 200,
                    "appends": [],
                },
            },
            }
        )
    rch_type_lookup = installed.get(RCH_TYPE_LOOKUP_TITLE)
    if rch_type_lookup is None:
        rch_type_lookup = api.create_node(
            {
            "workflowId": args.workflow_id,
            "type": "query",
            "title": RCH_TYPE_LOOKUP_TITLE,
            "config": {
                "collection": "f_rch_type_options",
                "multiple": True,
                "params": {
                    "filter": {},
                    "sort": [],
                    "page": 1,
                    "pageSize": 50,
                    "appends": [],
                },
            },
            }
        )

    normalize_config = copy.deepcopy(normalize.get("config") or {})
    normalize_config["arguments"] = [
        {"name": "formData", "value": form_data_ref},
        {"name": "addressOptions", "value": reference(address_lookup["key"])},
        {"name": "rchTypeOptions", "value": reference(rch_type_lookup["key"])},
    ]
    normalize_config["content"] = normalize_script()

    main_address_values = {
        field: reference(normalize["key"], f"rch_address.{field}")
        for field in ADDRESS_FIELDS.values()
    }
    main_address_values.update(
        {
            "fk_region_en": reference(normalize["key"], "rch_address.fk_region_en"),
            "fk_region_cn": reference(normalize["key"], "rch_address.fk_region_cn"),
            "fk_district_name_en": reference(
                normalize["key"], "rch_address.fk_district_name_en"
            ),
            "fk_district_name_cn": reference(
                normalize["key"], "rch_address.fk_district_name_cn"
            ),
            "fk_sub_district_en": reference(
                normalize["key"], "rch_address.fk_sub_district_en"
            ),
            "fk_sub_district_cn": reference(
                normalize["key"], "rch_address.fk_sub_district_cn"
            ),
        }
    )
    address_config = copy.deepcopy(address_template.get("config") or {})
    address_config.setdefault("params", {})["values"] = main_address_values
    main_address = installed.get(MAIN_ADDRESS_TITLE)
    if main_address is None:
        main_address = api.create_node(
            {
            "workflowId": args.workflow_id,
            "type": "create",
            "title": MAIN_ADDRESS_TITLE,
            "config": address_config,
            }
        )
    else:
        api.update_node(int(main_address["id"]), {"config": address_config})

    apply_config = copy.deepcopy(apply_nla.get("config") or {})
    values = apply_config.setdefault("params", {}).setdefault("values", {})
    values.update(
        {
            "fk_rch_address": reference(main_address["key"], "id"),
            "fk_type_of_rch": reference(normalize["key"], "rch_type_id"),
            "f_beds_nursing": reference(normalize["key"], "beds_nursing"),
            "f_beds_care_and_attention": reference(
                normalize["key"], "beds_care_and_attention"
            ),
            "f_beds_meal": reference(normalize["key"], "beds_aged_home"),
            "f_beds_self_care": reference(normalize["key"], "beds_self_care"),
            "f_beds_total": reference(normalize["key"], "beds_total"),
        }
    )

    api.update_node(int(normalize["id"]), {"config": normalize_config})
    api.update_node(
        int(find_nla["id"]), {"downstreamId": address_lookup["id"]}
    )
    api.update_node(
        int(address_lookup["id"]),
        {
            "upstreamId": find_nla["id"],
            "downstreamId": rch_type_lookup["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(rch_type_lookup["id"]),
        {
            "upstreamId": address_lookup["id"],
            "downstreamId": normalize["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(normalize["id"]),
        {
            "upstreamId": rch_type_lookup["id"],
            "downstreamId": main_address["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(main_address["id"]),
        {
            "upstreamId": normalize["id"],
            "downstreamId": apply_nla["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(apply_nla["id"]),
        {
            "config": apply_config,
            "upstreamId": main_address["id"],
            "downstreamId": condition["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(condition["id"]), {"upstreamId": apply_nla["id"]}
    )
    api.update_node(
        int(applicant_loop["id"]),
        {"upstreamId": condition["id"], "branchIndex": 1},
    )

    verified = api.get_workflow(args.workflow_id)
    verified_normalize = node_by_title(
        verified, "Normalize complete NLA relation data"
    )
    verified_apply = node_by_title(verified, "Apply staged data to native NLA")
    verified_main_address = node_by_title(verified, MAIN_ADDRESS_TITLE)
    verified_values = (
        (verified_apply.get("config") or {}).get("params") or {}
    ).get("values") or {}
    workflow_text = str(verified)
    checks = {
        "workflow_off": not verified.get("enabled"),
        "find_to_address_lookup": node_by_title(
            verified, "Find native-created NLA"
        ).get("downstreamId")
        == node_by_title(verified, ADDRESS_LOOKUP_TITLE).get("id"),
        "normalizer_has_dictionaries": len(
            (verified_normalize.get("config") or {}).get("arguments") or []
        )
        == 3,
        "main_address_to_apply": verified_main_address.get("downstreamId")
        == verified_apply.get("id"),
        "all_bed_fields": {
            "f_beds_nursing",
            "f_beds_care_and_attention",
            "f_beds_meal",
            "f_beds_self_care",
            "f_beds_total",
        }.issubset(verified_values),
        "no_address_select": "address_select" not in workflow_text.lower(),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ApiError(f"Post-repair verification failed: {failed}")
    print(f"address_lookup_node_id={address_lookup['id']}")
    print(f"rch_type_lookup_node_id={rch_type_lookup['id']}")
    print(f"main_address_node_id={main_address['id']}")
    print("repair_verified=yes")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
