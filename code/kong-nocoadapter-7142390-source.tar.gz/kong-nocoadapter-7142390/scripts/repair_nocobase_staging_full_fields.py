#!/usr/bin/env python3
"""Repair relation loops, submitter post, and main attachments after live UAT."""

from __future__ import annotations

import argparse
import copy
import os
import sys
from typing import Any

from extend_nocobase_staging_relations import (
    ApiError,
    NocoBaseApi,
    node_by_title,
    normalize_script,
)

DEFAULT_WORKFLOW_ID = 384624645046272
SUBMITTER_PATH = "form_data.case_summary.submitter_user_id"
RESOLVE_TITLE = "Resolve business submitter and post"
APPLY_IDENTITY_TITLE = "Apply submitter post to Intake"


def reference(node_key: str, suffix: str) -> str:
    return "{{$jobsMapByNodeKey." + node_key + "." + suffix + "}}"


def parsed_key(node: dict[str, Any], path: str) -> str:
    matches = [
        variable.get("key")
        for variable in (node.get("config") or {}).get("variables") or []
        if variable.get("path") == path
    ]
    if len(matches) != 1 or not isinstance(matches[0], str):
        raise ApiError(f"Expected one parsed variable for {path!r}")
    return matches[0]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    if workflow.get("enabled") or workflow.get("executed"):
        raise ApiError("Target workflow must be editable, unexecuted, and Off")
    if any(
        node.get("title") in {RESOLVE_TITLE, APPLY_IDENTITY_TITLE}
        for node in workflow.get("nodes") or []
    ):
        raise ApiError("Full-field UAT repair nodes are already present")

    parse = node_by_title(workflow, "Parse staged request body")
    intake = node_by_title(workflow, "Create Intake (fixed NLA type)")
    find_nla = node_by_title(workflow, "Find native-created NLA")
    apply_nla = node_by_title(workflow, "Apply staged data to native NLA")
    normalize = node_by_title(workflow, "Normalize complete NLA relation data")
    submitter_key = parsed_key(parse, SUBMITTER_PATH)
    submitter_ref = reference(parse["key"], submitter_key)

    print(f"workflow_id={args.workflow_id}")
    print("repair_relation_loop_targets=yes")
    print("repair_main_attachment_hooks=yes")
    print("resolve_submitter_post=yes")
    if not args.apply:
        print("mode=dry-run")
        return 0

    resolve = api.create_node(
        {
            "workflowId": args.workflow_id,
            "type": "query",
            "title": RESOLVE_TITLE,
            "config": {
                "collection": "users",
                "multiple": False,
                "params": {
                    "filter": {"$and": [{"id": {"$eq": submitter_ref}}]},
                    "sort": [],
                    "page": 1,
                    "pageSize": 1,
                    "appends": ["f_posts_code"],
                },
            },
        }
    )
    apply_identity = api.create_node(
        {
            "workflowId": args.workflow_id,
            "type": "update",
            "title": APPLY_IDENTITY_TITLE,
            "config": {
                "collection": "t_intake_form",
                "params": {
                    "filter": {
                        "$and": [{"id": {"$eq": reference(intake["key"], "id")}}]
                    },
                    "values": {
                        "fk_created_by_post": reference(
                            resolve["key"], "f_posts_code.f_post_cd"
                        )
                    },
                    "individualHooks": False,
                },
            },
        }
    )

    normalize_config = copy.deepcopy(normalize.get("config") or {})
    normalize_config["content"] = normalize_script()
    apply_config = copy.deepcopy(apply_nla.get("config") or {})
    apply_config.setdefault("params", {})["individualHooks"] = True

    api.update_node(int(normalize["id"]), {"config": normalize_config})
    api.update_node(int(apply_nla["id"]), {"config": apply_config})
    api.update_node(
        int(parse["id"]),
        {"downstreamId": resolve["id"]},
    )
    api.update_node(
        int(resolve["id"]),
        {
            "upstreamId": parse["id"],
            "downstreamId": intake["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(intake["id"]),
        {
            "upstreamId": resolve["id"],
            "downstreamId": apply_identity["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(apply_identity["id"]),
        {
            "upstreamId": intake["id"],
            "downstreamId": find_nla["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(find_nla["id"]),
        {"upstreamId": apply_identity["id"]},
    )

    verified = api.get_workflow(args.workflow_id)
    verified_resolve = node_by_title(verified, RESOLVE_TITLE)
    verified_identity = node_by_title(verified, APPLY_IDENTITY_TITLE)
    verified_apply = node_by_title(verified, "Apply staged data to native NLA")
    verified_normalize = node_by_title(verified, "Normalize complete NLA relation data")
    checks = {
        "parse_to_resolve": node_by_title(verified, "Parse staged request body").get(
            "downstreamId"
        )
        == verified_resolve.get("id"),
        "identity_to_nla": verified_identity.get("downstreamId")
        == node_by_title(verified, "Find native-created NLA").get("id"),
        "attachment_hooks": (verified_apply.get("config") or {})
        .get("params", {})
        .get("individualHooks")
        is True,
        "relation_aliases": "rel_applicant: applicantRows"
        in (verified_normalize.get("config") or {}).get("content", ""),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ApiError(f"Repair verification failed: {failed}")
    print(f"resolve_node_id={resolve['id']}")
    print(f"apply_identity_node_id={apply_identity['id']}")
    print("repair_verified=yes")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
