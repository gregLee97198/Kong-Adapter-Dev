#!/usr/bin/env python3
"""Append the native Intake Submit action to the staging workflow.

The staging request names the business submitter explicitly.  The subflow is
therefore executed as that user, rather than as the API token owner, so the
existing Intake workflow can make its normal post/rank-based routing decision
and write its normal approval log.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse

from extend_nocobase_staging_relations import ApiError, NocoBaseApi, node_by_title

DEFAULT_WORKFLOW_ID = 384633060917248
INTAKE_SUBMIT_WORKFLOW_KEY = "qdkj25b0793"
LOAD_TITLE = "Load Intake for native Submit"
SUBMIT_TITLE = "Run native Intake Form Submit as business submitter"


def reference(node_key: str, suffix: str | None = None) -> str:
    path = node_key if suffix is None else f"{node_key}.{suffix}"
    return "{{$jobsMapByNodeKey." + path + "}}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument(
        "--revision",
        action="store_true",
        help="Create an editable revision before installing the nodes",
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    if workflow.get("enabled"):
        raise ApiError("Source workflow must be Off before revision or editing")

    if args.revision:
        print(f"source_workflow_id={args.workflow_id}")
        if not args.apply:
            print("create_revision=yes")
            print("mode=dry-run")
            return 0
        query = urllib.parse.urlencode(
            {
                "filterByTk": str(args.workflow_id),
                "filter[key]": str(workflow["key"]),
            }
        )
        revision = api.request("POST", f"/api/workflows:revision?{query}", {})
        if not isinstance(revision, dict) or not revision.get("id"):
            raise ApiError("Workflow revision API did not return a workflow")
        workflow = api.get_workflow(int(revision["id"]))

    workflow_id = int(workflow["id"])
    if workflow.get("enabled") or workflow.get("executed"):
        raise ApiError("Target workflow must be editable, unexecuted, and Off")

    intake = node_by_title(workflow, "Create Intake (fixed NLA type)")
    submitter = node_by_title(workflow, "Resolve business submitter and post")
    checklist = node_by_title(workflow, "Apply Checklist files to native records")
    succeeded = node_by_title(workflow, "Mark succeeded + backfill IDs")
    if checklist.get("downstreamId") != succeeded.get("id"):
        raise ApiError("Unexpected final workflow topology")

    print(f"workflow_id={workflow_id}")
    print(f"intake_submit_workflow_key={INTAKE_SUBMIT_WORKFLOW_KEY}")
    print("submit_identity=business_submitter")
    print("workflow_enabled=no")
    if not args.apply:
        print("mode=dry-run")
        return 0

    existing_load = [
        node for node in workflow.get("nodes") or [] if node.get("title") == LOAD_TITLE
    ]
    existing_submit = [
        node
        for node in workflow.get("nodes") or []
        if node.get("title") == SUBMIT_TITLE
    ]
    if len(existing_load) > 1 or len(existing_submit) > 1:
        raise ApiError("Duplicate native Intake Submit repair nodes found")

    load_values = {
        "workflowId": workflow_id,
        "type": "query",
        "title": LOAD_TITLE,
        "config": {
            "collection": "t_intake_form",
            "multiple": False,
            "params": {
                "filter": {"$and": [{"id": {"$eq": reference(intake["key"], "id")}}]},
                "sort": [],
                "page": 1,
                "pageSize": 1,
                "appends": [
                    "f_task_owner_post",
                    "f_task_owner_post.parent",
                    "f_intake_type",
                ],
            },
        },
    }
    load_intake = existing_load[0] if existing_load else api.create_node(load_values)
    if existing_load:
        api.update_node(
            int(load_intake["id"]),
            {
                "type": load_values["type"],
                "title": LOAD_TITLE,
                "config": load_values["config"],
            },
        )

    submit_values = {
        "workflowId": workflow_id,
        "type": "subflow",
        "title": SUBMIT_TITLE,
        "config": {
            "workflow": INTAKE_SUBMIT_WORKFLOW_KEY,
            "context": {
                "data": reference(load_intake["key"]),
                "userId": reference(submitter["key"], "id"),
                "roleName": None,
            },
        },
    }
    submit = existing_submit[0] if existing_submit else api.create_node(submit_values)
    if existing_submit:
        api.update_node(
            int(submit["id"]),
            {
                "type": submit_values["type"],
                "title": SUBMIT_TITLE,
                "config": submit_values["config"],
            },
        )

    api.update_node(
        int(checklist["id"]),
        {"downstreamId": load_intake["id"]},
    )
    api.update_node(
        int(load_intake["id"]),
        {
            "upstreamId": checklist["id"],
            "downstreamId": submit["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(submit["id"]),
        {
            "upstreamId": load_intake["id"],
            "downstreamId": succeeded["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(succeeded["id"]),
        {"upstreamId": submit["id"], "branchIndex": None},
    )

    verified = api.get_workflow(workflow_id)
    verified_load = node_by_title(verified, LOAD_TITLE)
    verified_submit = node_by_title(verified, SUBMIT_TITLE)
    verified_succeeded = node_by_title(verified, "Mark succeeded + backfill IDs")
    checks = {
        "checklist_to_load": node_by_title(
            verified, "Apply Checklist files to native records"
        ).get("downstreamId")
        == verified_load.get("id"),
        "load_to_submit": verified_load.get("downstreamId")
        == verified_submit.get("id"),
        "submit_to_succeeded": verified_submit.get("downstreamId")
        == verified_succeeded.get("id"),
        "native_submit_key": (verified_submit.get("config") or {}).get("workflow")
        == INTAKE_SUBMIT_WORKFLOW_KEY,
        "business_user": (verified_submit.get("config") or {})
        .get("context", {})
        .get("userId")
        == reference(submitter["key"], "id"),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ApiError(f"Native submit installation verification failed: {failed}")

    print(f"load_intake_node_id={load_intake['id']}")
    print(f"submit_node_id={submit['id']}")
    print("repair_verified=yes")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
