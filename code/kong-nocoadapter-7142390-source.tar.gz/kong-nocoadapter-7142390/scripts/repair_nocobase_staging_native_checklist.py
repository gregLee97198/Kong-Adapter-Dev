#!/usr/bin/env python3
"""Map portable attachment position codes to native NLA checklist rows."""

from __future__ import annotations

import argparse
import copy
import os
import sys
from typing import Any

from extend_nocobase_staging_relations import (
    ApiError,
    NocoBaseApi,
    node_by_title,
    normalize_script,
)

DEFAULT_WORKFLOW_ID = 384631051845632
LOOKUP_TITLE = "Load native NLA Checklist attachment positions"
DISABLED_CREATE_TITLE = "Disabled legacy custom Checklist row creation"
ATTACHMENT_DETAILS_TITLE = "Create Checklist upload Details record"


def reference(node_key: str, suffix: str = "") -> str:
    tail = f".{suffix}" if suffix else ""
    return "{{$jobsMapByNodeKey." + node_key + tail + "}}"


def variable_ref(parse: dict[str, Any], path: str) -> str:
    keys = [
        variable.get("key")
        for variable in (parse.get("config") or {}).get("variables") or []
        if variable.get("path") == path
    ]
    if len(keys) != 1:
        raise ApiError(f"Expected exactly one Checklist variable for {path!r}")
    return reference(parse["key"], str(keys[0]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    if workflow.get("enabled") or workflow.get("executed"):
        raise ApiError("Target workflow must be editable, unexecuted, and Off")
    if any(
        node.get("title") == ATTACHMENT_DETAILS_TITLE
        for node in workflow.get("nodes") or []
    ):
        raise ApiError(
            "Attachment Details upgrade is already installed; do not run the "
            "legacy native-checklist repair against this workflow"
        )

    rch_type_lookup = node_by_title(workflow, "Resolve RCH type code for office")
    normalize = node_by_title(workflow, "Normalize complete NLA relation data")
    checklist_loop = node_by_title(
        workflow, "Apply Checklist files to native records"
    )
    parse_item = node_by_title(workflow, "Parse current Checklist item")
    find_native = node_by_title(workflow, "Find native Checklist item")
    native_exists = node_by_title(workflow, "Native Checklist item exists?")
    update_native = node_by_title(workflow, "Update native Checklist item + files")
    legacy_create_nodes = [
        node
        for node in workflow.get("nodes") or []
        if node.get("title")
        in {"Create missing Checklist item + files", DISABLED_CREATE_TITLE}
    ]
    if len(legacy_create_nodes) != 1:
        raise ApiError("Expected one legacy create-missing Checklist node")
    create_missing = legacy_create_nodes[0]
    existing = [
        node
        for node in workflow.get("nodes") or []
        if node.get("title") == LOOKUP_TITLE
    ]
    if len(existing) > 1:
        raise ApiError("More than one native Checklist lookup node exists")

    print(f"workflow_id={args.workflow_id}")
    print("native_attachment_positions=69")
    print("legacy_custom_row_creation=disabled")
    print("workflow_enabled=no")
    if not args.apply:
        print("mode=dry-run")
        return 0

    if existing:
        lookup = existing[0]
    else:
        lookup = api.create_node(
            {
                "workflowId": args.workflow_id,
                "type": "query",
                "title": LOOKUP_TITLE,
                "config": {
                    "collection": "t_document_checklist",
                    "multiple": True,
                    "params": {
                        "filter": {
                            "$and": [
                                {"f_checklist_code": {"$eq": "LORCHE_STAGE2"}},
                                {"f_office_code": {"$eq": "LORCHE"}},
                                {"f_item_type": {"$eq": "2"}},
                                {"f_active": {"$eq": True}},
                            ]
                        },
                        "sort": [],
                        "page": 1,
                        "pageSize": 100,
                        "appends": [],
                    },
                },
            }
        )

    normalize_config = copy.deepcopy(normalize.get("config") or {})
    arguments = [
        argument
        for argument in normalize_config.get("arguments") or []
        if argument.get("name") != "checklistOptions"
    ]
    arguments.append(
        {"name": "checklistOptions", "value": reference(lookup["key"])}
    )
    normalize_config["arguments"] = arguments
    normalize_config["content"] = normalize_script()

    parse_config = copy.deepcopy(parse_item.get("config") or {})
    parse_config["variables"] = [
        {
            "key": "position001",
            "path": "position_code",
            "name": "position_code",
            "paths": ["position_code"],
        },
        {
            "key": "template001",
            "path": "template_id",
            "name": "template_id",
            "paths": ["template_id"],
        },
        {
            "key": "checked0001",
            "path": "checked",
            "name": "checked",
            "paths": ["checked"],
        },
        {
            "key": "status00001",
            "path": "status",
            "name": "status",
            "paths": ["status"],
        },
        {
            "key": "remarks0001",
            "path": "remarks",
            "name": "remarks",
            "paths": ["remarks"],
        },
        {
            "key": "fileids0001",
            "path": "file_ids",
            "name": "file_ids",
            "paths": ["file_ids"],
        },
        {
            "key": "filename001",
            "path": "latest_file_name",
            "name": "latest_file_name",
            "paths": ["latest_file_name"],
        },
        {
            "key": "filedate001",
            "path": "latest_file_date",
            "name": "latest_file_date",
            "paths": ["latest_file_date"],
        },
    ]
    parse_config["example"] = {
        "position_code": "LORCHE_STAGE2:ROW:35",
        "template_id": 369569483653120,
        "checked": True,
        "status": "1",
        "remarks": "OP supplied",
        "file_ids": [502],
        "latest_file_name": "sample.txt",
        "latest_file_date": "2026-09-03",
    }

    find_config = copy.deepcopy(find_native.get("config") or {})
    find_config["collection"] = "t_document_submitted_for_application"
    find_config["multiple"] = False
    find_config.setdefault("params", {})["filter"] = {
        "$and": [
            {
                "f_business_key": {
                    "$eq": reference(
                        node_by_title(workflow, "Find native-created NLA")["key"],
                        "id",
                    )
                }
            },
            {
                "fk_document_checklist": {
                    "$eq": variable_ref(
                        {**parse_item, "config": parse_config}, "template_id"
                    )
                }
            },
            {"f_business_type": {"$eq": "t_licence_app"}},
        ]
    }

    update_config = copy.deepcopy(update_native.get("config") or {})
    update_params = update_config.setdefault("params", {})
    update_params["individualHooks"] = True
    update_params["filter"] = {
        "$and": [{"id": {"$eq": reference(find_native["key"], "id")}}]
    }
    parse_for_refs = {**parse_item, "config": parse_config}
    update_params["values"] = {
        "f_is_checked": variable_ref(parse_for_refs, "checked"),
        "f_status": variable_ref(parse_for_refs, "status"),
        "f_remarks": variable_ref(parse_for_refs, "remarks"),
        "f_lastest_files": variable_ref(parse_for_refs, "file_ids"),
        "f_lastest_files_name": variable_ref(
            parse_for_refs, "latest_file_name"
        ),
        "f_lastest_file_date": variable_ref(
            parse_for_refs, "latest_file_date"
        ),
    }

    exists_config = copy.deepcopy(native_exists.get("config") or {})
    exists_config["rejectOnFalse"] = True
    loop_config = copy.deepcopy(checklist_loop.get("config") or {})
    loop_config["target"] = reference(normalize["key"], "checklist_items")

    api.update_node(int(normalize["id"]), {"config": normalize_config})
    api.update_node(
        int(rch_type_lookup["id"]), {"downstreamId": lookup["id"]}
    )
    api.update_node(
        int(lookup["id"]),
        {
            "upstreamId": rch_type_lookup["id"],
            "downstreamId": normalize["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(normalize["id"]), {"upstreamId": lookup["id"]}
    )
    api.update_node(
        int(checklist_loop["id"]), {"config": loop_config}
    )
    api.update_node(
        int(parse_item["id"]),
        {"config": parse_config, "downstreamId": find_native["id"]},
    )
    api.update_node(
        int(find_native["id"]),
        {"config": find_config, "upstreamId": parse_item["id"]},
    )
    api.update_node(
        int(native_exists["id"]), {"config": exists_config}
    )
    api.update_node(int(update_native["id"]), {"config": update_config})
    api.update_node(
        int(create_missing["id"]),
        {
            "title": DISABLED_CREATE_TITLE,
            "upstreamId": None,
            "downstreamId": None,
            "branchIndex": None,
        },
    )

    verified = api.get_workflow(args.workflow_id)
    verified_normalize = node_by_title(
        verified, "Normalize complete NLA relation data"
    )
    verified_loop = node_by_title(
        verified, "Apply Checklist files to native records"
    )
    verified_find = node_by_title(verified, "Find native Checklist item")
    verified_disabled = node_by_title(verified, DISABLED_CREATE_TITLE)
    checks = {
        "workflow_off": not verified.get("enabled"),
        "checklist_dictionary_argument": any(
            argument.get("name") == "checklistOptions"
            for argument in (
                (verified_normalize.get("config") or {}).get("arguments") or []
            )
        ),
        "loop_uses_resolved_items": "checklist_items"
        in str((verified_loop.get("config") or {}).get("target")),
        "native_business_type": "t_licence_app"
        in str(verified_find.get("config") or {}),
        "legacy_create_detached": verified_disabled.get("upstreamId") is None,
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ApiError(f"Checklist repair verification failed: {failed}")
    print(f"checklist_lookup_node_id={lookup['id']}")
    print("repair_verified=yes")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
