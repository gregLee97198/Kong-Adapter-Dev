#!/usr/bin/env python3
"""Repair and audit the editable NocoBase NLA staging workflow version.

The JSON variable mapping plugin regenerates variable keys whenever its example is
parsed again. Downstream workflow nodes store those generated keys, so their field
references can silently become stale. This utility resolves every mapping by JSON
path, updates the workflow graph, and then re-reads the workflow to verify it.

Authentication is read only from the NOCOBASE_TOKEN environment variable. The
token is never accepted as a command-line argument or printed.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Iterable, Mapping, MutableMapping
from dataclasses import dataclass
from typing import Any, Optional

DEFAULT_WORKFLOW_ID = 384608150945792


@dataclass(frozen=True)
class NodeIds:
    dispatch: int = 384608150945795
    processing: int = 384608150945793
    parse_request: int = 384608150945794
    create_intake: int = 384608150945796
    find_nla: int = 384608150945798
    nla_updated: int = 384608150945797
    apply_nla: int = 384608150945799
    failed: int = 384608150945800
    succeeded: int = 384608150945801
    reject: int = 384608150945802
    checklist_loop: int = 384608150945803
    parse_checklist: int = 384608150945805


NODE_IDS = NodeIds()
PARSE_REQUEST_NODE_KEY = "vbq3yzrzr0g"
APPLY_NLA_NODE_KEY = "zl71unut3yd"
CREATE_INTAKE_NODE_KEY = "5clu7cbh9e5"
FIND_NLA_NODE_KEY = "c0pu2omivx0"

EXPECTED_TITLES = {
    NODE_IDS.processing: "Mark processing",
    NODE_IDS.parse_request: "Parse staged request body",
    NODE_IDS.create_intake: "Create Intake (fixed NLA type)",
    NODE_IDS.find_nla: "Find native-created NLA",
    NODE_IDS.nla_updated: (
        "NLA created successfully?",
        "NLA fields applied successfully?",
    ),
    NODE_IDS.apply_nla: "Apply staged data to native NLA",
    NODE_IDS.failed: "Mark failed + backfill Intake ID",
    NODE_IDS.succeeded: "Mark succeeded + backfill IDs",
    NODE_IDS.reject: "Reject unsupported classification",
    NODE_IDS.checklist_loop: "Apply Checklist files to native records",
}


INTAKE_FIELDS = {
    "fk_intake_type": 364490020880384,
    "fk_task_owner_post": "form_data.case_summary.task_owner_post_code",
    "fk_intake_source": "form_data.case_summary.source_id",
    "fk_task_owner": "form_data.case_summary.task_owner_user_id",
    "f_intake_accept_reject": "form_data.part_5.recommendation",
    "f_severity": "form_data.case_summary.severity",
    "f_received_date": "form_data.case_summary.received_date",
    "f_source_other": "form_data.case_summary.source_other",
    "f_office_cd": "form_data.case_summary.office_code",
    "f_subject": "form_data.part_2.rch_name_en",
    "f_comments": "form_data.part_5.comments",
    # The business submitter is explicit and can differ from the API token owner.
    # Native Intake/NLA workflows propagate this record creator identity.
    "createdBy": "form_data.case_summary.submitter_user_id",
}


NLA_FIELDS = {
    "f_application_received_date": "form_data.part_1.application_received_date",
    "f_licence_capacity": "form_data.part_2.licence_capacity",
    "f_signature_date": "form_data.part_3.signature_date",
    "f_app_type": "form_data.part_1.application_type",
    "f_max_capacity": "form_data.part_2.max_capacity",
    "f_rch_name_en": "form_data.part_2.rch_name_en",
    "f_rch_name_cn": "form_data.part_2.rch_name_cn",
    "f_telephone_no": "form_data.part_2.telephone_no",
    "f_fax_no": "form_data.part_2.fax_no",
    "f_email": "form_data.part_2.email",
    "f_floors_total": "form_data.part_2.floors_total",
    "f_units_total": "form_data.part_2.units_total",
    "f_rch_nature_other": "form_data.part_2.operation_mode_other",
    "f_is_rcsv": "form_data.part_2.is_rcsv",
    "f_rch_premises": "form_data.part_2.premises_type",
    "f_beds_nursing": "form_data.part_2.nursing_home_places",
    "f_net_floor_area_sqm": "form_data.part_2.floor_area_sqm",
    "f_service_type": "form_data.part_3.rch_business_status",
    "f_complies_lease_dmc": "form_data.part_2.complies_lease_dmc",
    "f_complies_lease_dmc_other": "form_data.part_2.complies_lease_dmc_other",
    "f_business_ownership_type": "form_data.part_3.applicant_operator_type",
    "f_application_level": "form_data.part_5.application_level",
    "f_attachments_of_rchs": "form_data.part_5.attachment_ids",
    "f_comments": "form_data.part_5.comments",
    "f_monthly_fee_per_resident_min": "form_data.part_2.monthly_fee_min",
    "f_monthly_fee_per_resident_max": "form_data.part_2.monthly_fee_max",
    "f_other_information": "form_data.part_5.other_information",
    "f_rch_gender": "form_data.part_2.gender",
    "f_remarks": "form_data.part_5.remarks",
    "f_date_of_operation": "form_data.part_3.date_of_operation",
    "f_existing_capacity": "form_data.part_2.existing_capacity",
    "f_enrolment_residents": "form_data.part_2.enrolment_residents",
    "f_tentative_service_commencement_date": (
        "form_data.part_1.tentative_commencement_date"
    ),
    "f_office_cd": "form_data.case_summary.office_code",
    "fk_rch_address": "form_data.part_2.rch_address_id",
    "fk_rch_nature": "form_data.part_2.operation_mode_id",
    "fk_type_of_rch": "form_data.part_2.rch_type_id",
}


class ApiError(RuntimeError):
    pass


class NocoBaseApi:
    def __init__(self, base_url: str, token: str, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def request(
        self, method: str, path: str, body: Optional[Mapping[str, Any]] = None
    ) -> Any:
        payload = None
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        }
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            self.base_url + path,
            data=payload,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:800]
            raise ApiError(f"HTTP {exc.code} for {path}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise ApiError(f"Request failed for {path}: {exc.reason}") from exc
        if not raw:
            return None
        decoded = json.loads(raw)
        if isinstance(decoded, dict) and decoded.get("errors"):
            raise ApiError(f"NocoBase returned errors for {path}: {decoded['errors']}")
        return (
            decoded.get("data")
            if isinstance(decoded, dict) and "data" in decoded
            else decoded
        )

    def get_workflow(self, workflow_id: int) -> MutableMapping[str, Any]:
        query = urllib.parse.urlencode(
            {"filterByTk": str(workflow_id), "appends[]": "nodes"}
        )
        data = self.request("GET", f"/api/workflows:get?{query}")
        if not isinstance(data, dict):
            raise ApiError("Workflow response does not contain an object")
        return data

    def update_node(self, node_id: int, values: Mapping[str, Any]) -> None:
        query = urllib.parse.urlencode({"filterByTk": str(node_id)})
        self.request("POST", f"/api/flow_nodes:update?{query}", values)


def nodes_by_id(workflow: Mapping[str, Any]) -> dict[int, MutableMapping[str, Any]]:
    nodes = workflow.get("nodes")
    if not isinstance(nodes, list):
        raise ApiError("Workflow response is missing the nodes array")
    return {int(node["id"]): node for node in nodes}


def require_editable_workflow(
    workflow: Mapping[str, Any], node_map: Mapping[int, Mapping[str, Any]]
) -> None:
    if workflow.get("enabled"):
        raise ApiError("Refusing to modify an enabled workflow; turn it off first")
    if int(workflow.get("id", -1)) != DEFAULT_WORKFLOW_ID:
        # The CLI allows another ID, but this release is tied to a known node graph.
        raise ApiError(
            f"Workflow ID {workflow.get('id')} is not the reviewed editable version "
            f"{DEFAULT_WORKFLOW_ID}"
        )
    for node_id, expected_title in EXPECTED_TITLES.items():
        node = node_map.get(node_id)
        if node is None:
            raise ApiError(f"Expected node {node_id} is missing")
        accepted_titles = (
            expected_title if isinstance(expected_title, tuple) else (expected_title,)
        )
        if node.get("title") not in accepted_titles:
            raise ApiError(
                f"Node {node_id} title changed: expected {expected_title!r}, "
                f"found {node.get('title')!r}"
            )


def variable_keys(parse_node: Mapping[str, Any]) -> dict[str, str]:
    variables = (parse_node.get("config") or {}).get("variables") or []
    result: dict[str, str] = {}
    for variable in variables:
        path = variable.get("path")
        key = variable.get("key")
        if isinstance(path, str) and isinstance(key, str):
            result[path] = key
    return result


def parsed_ref(path: str, keys: Mapping[str, str]) -> str:
    try:
        key = keys[path]
    except KeyError as exc:
        raise ApiError(
            f"Parsed request schema is missing required JSON path: {path}"
        ) from exc
    return "{{$jobsMapByNodeKey." + PARSE_REQUEST_NODE_KEY + "." + key + "}}"


def resolved_values(spec: Mapping[str, Any], keys: Mapping[str, str]) -> dict[str, Any]:
    values: dict[str, Any] = {}
    for field, value in spec.items():
        if isinstance(value, str) and value.startswith("form_data."):
            values[field] = parsed_ref(value, keys)
        else:
            values[field] = value
    return values


def config_with_values(
    node: Mapping[str, Any], values: Mapping[str, Any]
) -> dict[str, Any]:
    config = copy.deepcopy(node.get("config") or {})
    params = config.setdefault("params", {})
    params["values"] = dict(values)
    return config


def build_updates(
    node_map: Mapping[int, Mapping[str, Any]],
) -> list[tuple[int, dict[str, Any]]]:
    keys = variable_keys(node_map[NODE_IDS.parse_request])
    # Resolve all paths before issuing any write so a schema mismatch is atomic.
    intake_values = resolved_values(INTAKE_FIELDS, keys)
    nla_values = resolved_values(NLA_FIELDS, keys)
    checklist_target = parsed_ref("form_data.part_5.checklist", keys)

    processing_config = config_with_values(
        node_map[NODE_IDS.processing], {"f_status": "processing"}
    )
    intake_config = config_with_values(node_map[NODE_IDS.create_intake], intake_values)
    nla_config = config_with_values(node_map[NODE_IDS.apply_nla], nla_values)
    failed_config = config_with_values(
        node_map[NODE_IDS.failed],
        {
            "f_status": "failed",
            "f_intake_id": "{{$jobsMapByNodeKey." + CREATE_INTAKE_NODE_KEY + ".id}}",
            "f_application_id": "{{$jobsMapByNodeKey." + FIND_NLA_NODE_KEY + ".id}}",
        },
    )
    reject_config = config_with_values(
        node_map[NODE_IDS.reject], {"f_status": "failed"}
    )

    condition_config = copy.deepcopy(node_map[NODE_IDS.nla_updated].get("config") or {})
    condition_config["calculation"] = {
        "group": {
            "type": "and",
            "calculations": [
                {
                    "calculator": "gt",
                    "operands": [
                        "{{$jobsMapByNodeKey." + APPLY_NLA_NODE_KEY + "}}",
                        "0",
                    ],
                }
            ],
        }
    }

    loop_config = copy.deepcopy(node_map[NODE_IDS.checklist_loop].get("config") or {})
    loop_config["target"] = checklist_target

    return [
        (NODE_IDS.processing, {"config": processing_config}),
        (NODE_IDS.create_intake, {"config": intake_config}),
        (
            NODE_IDS.apply_nla,
            {
                "config": nla_config,
                "upstreamId": NODE_IDS.find_nla,
                "downstreamId": NODE_IDS.nla_updated,
                "branchIndex": None,
            },
        ),
        (NODE_IDS.find_nla, {"downstreamId": NODE_IDS.apply_nla}),
        (
            NODE_IDS.nla_updated,
            {
                "title": "NLA fields applied successfully?",
                "config": condition_config,
                "upstreamId": NODE_IDS.apply_nla,
            },
        ),
        (
            NODE_IDS.checklist_loop,
            {
                "config": loop_config,
                "upstreamId": NODE_IDS.nla_updated,
                "branchIndex": 1,
            },
        ),
        (
            NODE_IDS.failed,
            {
                "config": failed_config,
                "upstreamId": NODE_IDS.nla_updated,
                "branchIndex": 0,
            },
        ),
        (NODE_IDS.reject, {"config": reject_config}),
    ]


REFERENCE_PATTERN = re.compile(
    r"\{\{\$jobsMapByNodeKey\.([^.}]+)\.([^.}]+)(?:\.[^}]*)?\}\}"
)


def iter_references(value: Any) -> Iterable[tuple[str, str]]:
    if isinstance(value, str):
        yield from REFERENCE_PATTERN.findall(value)
    elif isinstance(value, dict):
        for child in value.values():
            yield from iter_references(child)
    elif isinstance(value, list):
        for child in value:
            yield from iter_references(child)


def audit(workflow: Mapping[str, Any]) -> list[str]:
    problems: list[str] = []
    node_map = nodes_by_id(workflow)
    keys = variable_keys(node_map[NODE_IDS.parse_request])
    valid_request_keys = set(keys.values())
    checklist_keys = set(variable_keys(node_map[NODE_IDS.parse_checklist]).values())

    if workflow.get("enabled"):
        problems.append(
            "workflow is enabled; expected Off outside a controlled test window"
        )

    for node in node_map.values():
        for source_key, variable_key in iter_references(node.get("config")):
            if (
                source_key == PARSE_REQUEST_NODE_KEY
                and variable_key not in valid_request_keys
            ):
                problems.append(
                    f"node {node['id']} ({node.get('title')}): "
                    f"stale request variable {variable_key}"
                )
            if source_key == "ybdsatmwf2b" and variable_key not in checklist_keys:
                problems.append(
                    f"node {node['id']} ({node.get('title')}): "
                    f"stale checklist variable {variable_key}"
                )

    processing_values = (
        (node_map[NODE_IDS.processing].get("config") or {}).get("params") or {}
    ).get("values")
    if processing_values != {"f_status": "processing"}:
        problems.append("Mark processing does not write f_status=processing")

    apply_node = node_map[NODE_IDS.apply_nla]
    find_node = node_map[NODE_IDS.find_nla]
    condition_node = node_map[NODE_IDS.nla_updated]
    loop_node = node_map[NODE_IDS.checklist_loop]
    failed_node = node_map[NODE_IDS.failed]
    expected_links = [
        (find_node.get("downstreamId"), NODE_IDS.apply_nla, "Find NLA downstream"),
        (apply_node.get("upstreamId"), NODE_IDS.find_nla, "Apply NLA upstream"),
        (apply_node.get("downstreamId"), NODE_IDS.nla_updated, "Apply NLA downstream"),
        (apply_node.get("branchIndex"), None, "Apply NLA branch"),
        (
            condition_node.get("upstreamId"),
            NODE_IDS.apply_nla,
            "Success condition upstream",
        ),
        (loop_node.get("upstreamId"), NODE_IDS.nla_updated, "Checklist loop upstream"),
        (loop_node.get("branchIndex"), 1, "Checklist loop branch"),
        (failed_node.get("upstreamId"), NODE_IDS.nla_updated, "Failed node upstream"),
        (failed_node.get("branchIndex"), 0, "Failed node branch"),
    ]
    for actual, expected, label in expected_links:
        if actual != expected:
            problems.append(f"{label}: expected {expected!r}, found {actual!r}")

    condition_text = json.dumps(
        condition_node.get("config") or {}, separators=(",", ":")
    )
    if "{{$jobsMapByNodeKey." + APPLY_NLA_NODE_KEY + "}}" not in condition_text:
        problems.append("Success condition does not test the Apply NLA update count")

    intake_values = (
        (node_map[NODE_IDS.create_intake].get("config") or {}).get("params") or {}
    ).get("values") or {}
    nla_values = (
        (node_map[NODE_IDS.apply_nla].get("config") or {}).get("params") or {}
    ).get("values") or {}
    missing_intake_fields = set(INTAKE_FIELDS) - set(intake_values)
    unexpected_intake_fields = (
        set(intake_values)
        - set(INTAKE_FIELDS)
        - {
            # The first repaired version was executed before collection metadata proved
            # this legacy field does not exist. NocoBase ignores it on create. Any
            # future editable copy should omit it, as build_updates() now does.
            "application_level"
        }
    )
    if missing_intake_fields:
        problems.append(
            "Create Intake is missing reviewed fields: "
            + ", ".join(sorted(missing_intake_fields))
        )
    if unexpected_intake_fields:
        problems.append(
            "Create Intake contains unexpected fields: "
            + ", ".join(sorted(unexpected_intake_fields))
        )
    if set(nla_values) != set(NLA_FIELDS):
        problems.append("Apply NLA field set does not match the reviewed mapping")
    if "f_rch_nature" in nla_values:
        problems.append("Apply NLA still contains invalid duplicate field f_rch_nature")

    return problems


def print_summary(
    workflow: Mapping[str, Any], problems: list[str], prefix: str
) -> None:
    node_map = nodes_by_id(workflow)
    intake_count = len(
        (
            (node_map[NODE_IDS.create_intake].get("config") or {}).get("params") or {}
        ).get("values")
        or {}
    )
    nla_count = len(
        ((node_map[NODE_IDS.apply_nla].get("config") or {}).get("params") or {}).get(
            "values"
        )
        or {}
    )
    print(f"{prefix}_workflow_id={workflow.get('id')}")
    print(f"{prefix}_enabled={str(bool(workflow.get('enabled'))).lower()}")
    print(f"{prefix}_intake_field_count={intake_count}")
    print(f"{prefix}_nla_field_count={nla_count}")
    print(f"{prefix}_audit_problem_count={len(problems)}")
    for problem in problems:
        print(f"{prefix}_problem={problem}")


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument(
        "--apply",
        action="store_true",
        help="write the reviewed repair; without this flag the command is audit-only",
    )
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    try:
        workflow = api.get_workflow(args.workflow_id)
        node_map = nodes_by_id(workflow)
        if args.apply:
            require_editable_workflow(workflow, node_map)
            updates = build_updates(node_map)
            print(f"planned_node_update_count={len(updates)}")
            for node_id, values in updates:
                api.update_node(node_id, values)
                print(f"updated_node_id={node_id}")
            workflow = api.get_workflow(args.workflow_id)
        problems = audit(workflow)
        print_summary(workflow, problems, "post" if args.apply else "audit")
        return 0 if not problems else 1
    except (ApiError, json.JSONDecodeError) as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
