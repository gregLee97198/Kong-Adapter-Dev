#!/usr/bin/env python3
"""Resumable builder for *disabled* 13001 unified API-Staging candidates.

This is the recovery companion to
``execute_nocobase_unified_staging_dispatch_13001.py``.  The original writer
stops on an uncertain ``flow_nodes`` mutation so it cannot accidentally post a
duplicate node.  That is the correct default, but it leaves a harmless,
disabled partial candidate after a network timeout.  This tool reconciles that
candidate safely:

* candidates are found only by their exact deterministic migration title;
* nodes are found only by their exact deterministic title;
* a failed POST is followed by a GET and is accepted only if that one expected
  object is now present; and
* every mutation is checkpointed locally.  The remote graph is always the
  source of truth when the command is run again.

It can create or append **only disabled** candidates.  It has no command to
enable, disable, delete, or cut over any workflow.  ``--resume`` is deliberately
confirmation-gated and is intended to be run by an operator after review, not
by this script's tests.

The immediate recovery case is migration ``api-staging-20261019d`` ingress
workflow ``392928347947008``: its final deterministic ingress node can be
created and linked without recreating the prior 23 nodes.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping

import execute_nocobase_unified_staging_dispatch_13001 as original
import migrate_nocobase_single_staging_dispatch_13001 as blueprint
from create_nocobase_phase_c_chi_workflows import RootNocoBaseApi
from extend_nocobase_staging_relations import (
    ApiError,
    resolve_workflow_category_id,
)


RESUME_CONFIRM = "RESUME_DISABLED_UNIFIED_API_STAGING_13001"
RESUME_FORMAT = "nocobase-unified-api-staging-resume/v1"
PREPARED_ROOT = original.PREPARED_ROOT


class ResumeError(RuntimeError):
    """A candidate cannot be reconciled without risking an unintended graph."""


def _atomic_json(path: Path, value: Any) -> None:
    """Reuse the original writer's private, atomic local checkpoint writer."""
    original._atomic_json(path, value)


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _require_token() -> str:
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        raise ResumeError("NOCOBASE_TOKEN is required")
    return token


def _api() -> RootNocoBaseApi:
    return RootNocoBaseApi(blueprint.BASE_URL, _require_token())


def _workflow(api: RootNocoBaseApi, workflow_id: int) -> dict[str, Any]:
    try:
        row = dict(api.get_workflow(workflow_id))
    except ApiError as exc:
        raise ResumeError(f"cannot read workflow {workflow_id}") from exc
    if row.get("id") != workflow_id or not isinstance(row.get("nodes"), list):
        raise ResumeError(f"workflow {workflow_id} readback is incomplete")
    return row


def _title_query(api: RootNocoBaseApi, title: str) -> list[dict[str, Any]]:
    """Return exact-title workflow details, rejecting ambiguous discovery."""
    query = urllib.parse.urlencode(
        [("page", "1"), ("pageSize", "100"), ("filter[title]", title)]
    )
    try:
        rows = api.request("GET", "/api/workflows:list?" + query)
    except ApiError as exc:
        raise ResumeError(f"cannot query candidate title {title!r}") from exc
    exact = [dict(row) for row in (rows or [])
             if isinstance(row, Mapping) and row.get("title") == title]
    ids = sorted({int(row["id"]) for row in exact if isinstance(row.get("id"), int)})
    if len(ids) > 1:
        raise ResumeError(f"multiple workflows have candidate title {title!r}: {ids}")
    return [_workflow(api, workflow_id) for workflow_id in ids]


def _find_candidate(api: RootNocoBaseApi, title: str) -> dict[str, Any] | None:
    rows = _title_query(api, title)
    return rows[0] if rows else None


def _assert_candidate(
    row: Mapping[str, Any], *, title: str, config: Mapping[str, Any]
) -> None:
    if row.get("title") != title:
        raise ResumeError("candidate title drifted")
    if row.get("enabled") is not False:
        raise ResumeError(f"candidate {row.get('id')} is enabled; refusing to touch it")
    if row.get("type") != "collection":
        raise ResumeError(f"candidate {row.get('id')} is not a collection workflow")
    if row.get("config") != dict(config):
        raise ResumeError(f"candidate {row.get('id')} trigger configuration drifted")


def _candidate_category_ids(api: RootNocoBaseApi, workflow_id: int) -> set[int]:
    """Read category membership explicitly; normal workflow GET omits it."""
    query = urllib.parse.urlencode(
        [("filterByTk", str(workflow_id)), ("appends[]", "categories")]
    )
    try:
        row = api.request("GET", "/api/workflows:get?" + query)
    except ApiError as exc:
        raise ResumeError(f"cannot read categories for candidate {workflow_id}") from exc
    if not isinstance(row, Mapping) or row.get("id") != workflow_id:
        raise ResumeError(f"category readback is invalid for candidate {workflow_id}")
    categories = row.get("categories") or []
    if not isinstance(categories, list):
        raise ResumeError(f"candidate {workflow_id} categories readback is malformed")
    result: set[int] = set()
    for item in categories:
        raw = item.get("id") if isinstance(item, Mapping) else item
        if isinstance(raw, int):
            result.add(raw)
        elif isinstance(raw, str) and raw.isdigit():
            result.add(int(raw))
    return result


def _ensure_api_source_category(
    api: RootNocoBaseApi,
    workflow_id: int,
    *,
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> None:
    """Idempotently add API Suorce while preserving any existing category.

    This has the same no-retry rule as flow-node writes: after a timeout we
    only accept the operation if the membership is visible on a fresh GET.
    """
    try:
        category_id = resolve_workflow_category_id(api, blueprint.API_SOURCE_CATEGORY_TITLE)
    except ApiError as exc:
        raise ResumeError("cannot resolve API Suorce category") from exc
    before = _candidate_category_ids(api, workflow_id)
    if category_id in before:
        return
    values = {"categories": sorted(before | {category_id})}
    try:
        api.request("POST", f"/api/workflows:update?filterByTk={workflow_id}", values)
    except ApiError as exc:
        if category_id in _candidate_category_ids(api, workflow_id):
            checkpoint("candidate_category_reconciled_after_timeout", {
                "workflow_id": workflow_id, "category_id": category_id,
            })
            return
        raise ResumeError(
            f"category attachment outcome is unknown for candidate {workflow_id}"
        ) from exc
    if category_id not in _candidate_category_ids(api, workflow_id):
        raise ResumeError(f"candidate {workflow_id} category did not persist")
    checkpoint("candidate_categorized", {"workflow_id": workflow_id, "category_id": category_id})


def _create_or_find_disabled_candidate(
    api: RootNocoBaseApi,
    *,
    title: str,
    config: Mapping[str, Any],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Create a candidate once, or recover it after an uncertain POST.

    A timeout never triggers another POST.  We first re-read by exact title;
    only a single matching candidate proves that the original POST committed.
    """
    candidate = _find_candidate(api, title)
    if candidate is None:
        try:
            created_row = api.request("POST", "/api/workflows:create", {
                "title": title,
                "type": "collection",
                "sync": False,
                "enabled": False,
                "config": copy.deepcopy(dict(config)),
            })
        except ApiError as exc:
            candidate = _find_candidate(api, title)
            if candidate is None:
                raise ResumeError(
                    f"workflow create outcome is unknown for {title!r}; rerun resume after checking connectivity"
                ) from exc
        else:
            if not isinstance(created_row, Mapping) or not isinstance(created_row.get("id"), int):
                raise ResumeError(f"candidate create returned no ID: {title!r}")
            candidate = _workflow(api, int(created_row["id"]))
            checkpoint("candidate_created", {"workflow_id": candidate["id"], "title": title})
    _assert_candidate(candidate, title=title, config=config)
    # A prior timed-out run might have created the workflow before it attached
    # its category, so reconcile membership for both new and discovered rows.
    _ensure_api_source_category(api, int(candidate["id"]), checkpoint=checkpoint)
    return candidate


def _node_matches(workflow: Mapping[str, Any], title: str) -> list[dict[str, Any]]:
    return [dict(node) for node in (workflow.get("nodes") or [])
            if isinstance(node, Mapping) and node.get("title") == title]


def _strict_node(
    workflow: Mapping[str, Any], *, title: str, expected_type: str | None = None
) -> dict[str, Any] | None:
    matches = _node_matches(workflow, title)
    if len(matches) > 1:
        raise ResumeError(
            f"workflow {workflow.get('id')} has duplicate deterministic node title {title!r}"
        )
    if not matches:
        return None
    node = matches[0]
    if expected_type is not None and node.get("type") != expected_type:
        raise ResumeError(
            f"node {node.get('id')} {title!r} type drifted: {node.get('type')!r} != {expected_type!r}"
        )
    return node


def _ensure_node(
    api: RootNocoBaseApi,
    workflow_id: int,
    *,
    title: str,
    node_type: str,
    initial_config: Mapping[str, Any],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Find/create a node once; timeouts reconcile by exact title only."""
    current = _workflow(api, workflow_id)
    found = _strict_node(current, title=title, expected_type=node_type)
    if found is not None:
        return found
    try:
        created = api.create_node({
            "workflowId": workflow_id,
            "type": node_type,
            "title": title,
            "config": copy.deepcopy(dict(initial_config)),
        })
    except ApiError as exc:
        current = _workflow(api, workflow_id)
        found = _strict_node(current, title=title, expected_type=node_type)
        if found is None:
            raise ResumeError(
                f"node create outcome is unknown for {title!r}; do not retry POST, rerun resume"
            ) from exc
        checkpoint("node_create_reconciled_after_timeout", {
            "workflow_id": workflow_id, "node_id": found.get("id"), "title": title,
        })
        return found
    if not isinstance(created, Mapping) or not isinstance(created.get("id"), int):
        raise ResumeError(f"node create returned no ID: {title!r}")
    current = _workflow(api, workflow_id)
    found = _strict_node(current, title=title, expected_type=node_type)
    if found is None:
        raise ResumeError(f"created node {created.get('id')} is absent on readback")
    checkpoint("node_created", {
        "workflow_id": workflow_id, "node_id": found["id"], "node_key": found.get("key"), "title": title,
    })
    return found


def _patch_node(
    api: RootNocoBaseApi,
    workflow_id: int,
    node_id: int,
    values: Mapping[str, Any],
    *,
    checkpoint: Callable[[str, Mapping[str, Any]], None],
    reason: str,
) -> None:
    """Write only a mismatch; an uncertain write is reconciled by readback."""
    current = _workflow(api, workflow_id)
    node = next((n for n in current["nodes"] if n.get("id") == node_id), None)
    if not isinstance(node, Mapping):
        raise ResumeError(f"node {node_id} is no longer present")
    if all(node.get(key) == value for key, value in values.items()):
        return
    try:
        api.update_node(node_id, dict(values))
    except ApiError as exc:
        current = _workflow(api, workflow_id)
        node = next((n for n in current["nodes"] if n.get("id") == node_id), None)
        if isinstance(node, Mapping) and all(node.get(key) == value for key, value in values.items()):
            checkpoint("node_patch_reconciled_after_timeout", {
                "workflow_id": workflow_id, "node_id": node_id, "reason": reason,
            })
            return
        raise ResumeError(
            f"node {node_id} {reason} outcome is unknown and does not match readback"
        ) from exc
    checkpoint("node_patched", {"workflow_id": workflow_id, "node_id": node_id, "reason": reason})


def _expected_ingress() -> list[dict[str, Any]]:
    specs = blueprint.ingress_nodes()
    by_key = {str(spec["key"]): spec for spec in specs}
    result: list[dict[str, Any]] = []
    titles: set[str] = set()
    for spec in specs:
        title = str(spec["title"])
        if title in titles:
            raise ResumeError(f"ingress plan has duplicate title {title!r}")
        titles.add(title)
        upstream = spec.get("upstream")
        result.append({
            "identity": str(spec["key"]),
            "title": title,
            "type": str(spec["type"]),
            "config": copy.deepcopy(dict(spec["config"])),
            "upstream": (str(upstream) if upstream is not None else None),
            "branch": spec.get("branch"),
            "upstream_title": (str(by_key[str(upstream)]["title"]) if upstream is not None else None),
        })
    return result


def _ingress_node_map(workflow: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """Map blueprint ingress keys to actual nodes by deterministic title."""
    expected = _expected_ingress()
    expected_by_title = {spec["title"]: spec for spec in expected}
    unexpected = [node.get("title") for node in workflow.get("nodes") or []
                  if isinstance(node, Mapping) and node.get("title") not in expected_by_title]
    if unexpected:
        raise ResumeError(
            f"ingress candidate {workflow.get('id')} has unexpected node titles: {unexpected[:4]!r}"
        )
    actual: dict[str, dict[str, Any]] = {}
    for spec in expected:
        node = _strict_node(workflow, title=spec["title"], expected_type=spec["type"])
        if node is not None:
            actual[spec["identity"]] = node
    return actual


def _refs_resolve(workflow: Mapping[str, Any]) -> bool:
    keys = {str(node.get("key")) for node in workflow.get("nodes") or []}
    for node in workflow.get("nodes") or []:
        for text in blueprint._walk_strings((node or {}).get("config") or {}):
            for _scope, key in blueprint._REF_RE.findall(text):
                if key not in keys:
                    return False
    return True


def _validate_ingress(api: RootNocoBaseApi, candidate: Mapping[str, Any]) -> dict[str, Any]:
    row = _workflow(api, int(candidate["id"]))
    _assert_candidate(row, title=str(candidate["title"]), config=blueprint.ingress_config())
    expected = _expected_ingress()
    actual = _ingress_node_map(row)
    if len(actual) != len(expected) or len(row.get("nodes") or []) != len(expected):
        raise ResumeError(
            f"ingress candidate {row['id']} incomplete: {len(actual)}/{len(expected)} planned nodes"
        )
    for spec in expected:
        node = actual[spec["identity"]]
        if node.get("config") != spec["config"]:
            raise ResumeError(f"ingress node config drifted: {spec['title']!r}")
        upstream_identity = spec["upstream"]
        if upstream_identity is None:
            if node.get("upstreamId") not in (None, ""):
                raise ResumeError(f"ingress root unexpectedly has upstream: {spec['title']!r}")
            continue
        upstream = actual[upstream_identity]
        if node.get("upstreamId") != upstream["id"] or node.get("branchIndex") != spec["branch"]:
            raise ResumeError(f"ingress edge drifted: {spec['title']!r}")
        if spec["branch"] is None and upstream.get("downstreamId") != node["id"]:
            raise ResumeError(f"ingress continuation drifted: {spec['title']!r}")
    if not _refs_resolve(row):
        raise ResumeError(f"ingress candidate {row['id']} has unresolved references")
    return {
        "id": row["id"], "key": row.get("key"), "title": row.get("title"),
        "enabled": row.get("enabled"), "executed": row.get("executed"),
        "node_count": len(row.get("nodes") or []), "references_resolve": True,
        "node_map": {identity: {"id": node["id"], "key": node.get("key")}
                     for identity, node in actual.items()},
    }


def _reconcile_ingress(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Append missing ingress nodes/edges without touching an enabled workflow."""
    workflow_id = int(candidate["id"])
    _assert_candidate(_workflow(api, workflow_id), title=str(candidate["title"]),
                      config=blueprint.ingress_config())
    expected = _expected_ingress()
    # Pass 1: create only absent deterministic nodes.  The ingress has no
    # cross-node config references, so its initial config is final config.
    for spec in expected:
        _ensure_node(api, workflow_id, title=spec["title"], node_type=spec["type"],
                     initial_config=spec["config"], checkpoint=checkpoint)
    row = _workflow(api, workflow_id)
    actual = _ingress_node_map(row)
    # Pass 2: repair/configure only mismatches; usually this is zero writes.
    for spec in expected:
        node = actual[spec["identity"]]
        _patch_node(api, workflow_id, int(node["id"]), {"config": spec["config"]},
                    checkpoint=checkpoint, reason=f"config:{spec['identity']}")
    # Pass 3: establish the planned graph.  Nodes are disabled throughout.
    for spec in expected:
        if spec["upstream"] is None:
            continue
        parent = actual[spec["upstream"]]
        child = actual[spec["identity"]]
        _patch_node(api, workflow_id, int(child["id"]), {
            "upstreamId": parent["id"], "branchIndex": spec["branch"],
        }, checkpoint=checkpoint, reason=f"edge:{spec['identity']}")
        if spec["branch"] is None:
            _patch_node(api, workflow_id, int(parent["id"]), {"downstreamId": child["id"]},
                        checkpoint=checkpoint, reason=f"continuation:{spec['upstream']}->{spec['identity']}")
    return _validate_ingress(api, candidate)


def _source_graph_from_manifest(
    manifest: Mapping[str, Any], business: blueprint.Business, kind: str
) -> dict[str, Any]:
    """Read the frozen source graph captured before the first remote write.

    A resumed clone must not silently start using a later edited legacy graph.
    The original preparation manifest is therefore authoritative for CREATE;
    the approved local direct-UPDATE snapshot remains authoritative for UPDATE.
    """
    if kind == "CREATE":
        source = (manifest.get("source_snapshot", {}).get("create", {})
                  if isinstance(manifest.get("source_snapshot"), Mapping) else {}).get(business.name)
        if not isinstance(source, Mapping):
            raise ResumeError(f"manifest has no frozen CREATE source for {business.name}")
        graph = copy.deepcopy(dict(source))
        if graph.get("id") != business.create_source_id or graph.get("key") != business.create_source_key:
            raise ResumeError(f"frozen CREATE source identity drifted for {business.name}")
    elif kind == "UPDATE":
        graph = blueprint.prepared_update_graph(business)
    else:  # pragma: no cover - internal call site invariant
        raise AssertionError(kind)
    try:
        blueprint._node_index(graph)
    except blueprint.PlanError as exc:
        raise ResumeError(f"{business.name} {kind} source graph is unsafe to clone: {exc}") from exc
    return graph


def _clone_title(prefix: str, source: Mapping[str, Any]) -> str:
    return f"{prefix}/{source['key']} — {source.get('title') or source['type']}"


def _expected_worker(
    manifest: Mapping[str, Any], business: blueprint.Business
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    """Return deterministic candidate-node specs plus their frozen graphs.

    ``identity`` is local to a candidate and is intentionally independent of a
    NocoBase node key.  This makes it possible to reconstruct key maps after
    any process restart or timeout.
    """
    graphs = {
        "CREATE": _source_graph_from_manifest(manifest, business, "CREATE"),
        "UPDATE": _source_graph_from_manifest(manifest, business, "UPDATE"),
    }
    branch = blueprint.event_branch_node(business)
    specs: list[dict[str, Any]] = [{
        "identity": "EVENT",
        "title": str(branch["title"]),
        "type": str(branch["type"]),
        "initial_config": copy.deepcopy(dict(branch["config"])),
        "config_source": None,
        "prefix": None,
        "source_key": None,
        "upstream": None,
        "branch": None,
    }]
    for prefix, graph in graphs.items():
        indexed = blueprint._node_index(graph)
        roots = [node for node in indexed.values() if node.get("upstreamId") in (None, "")]
        if len(roots) != 1:  # _node_index already protects this, retain context here.
            raise ResumeError(f"{business.name} {prefix} source has no unique root")
        root_key = str(roots[0]["key"])
        for source in sorted(indexed.values(), key=lambda node: str(node["key"])):
            source_key = str(source["key"])
            identity = f"{prefix}:{source_key}"
            upstream_id = source.get("upstreamId")
            if upstream_id in (None, ""):
                upstream = "EVENT"
                edge_branch = 1 if prefix == "CREATE" else 0
            else:
                upstream = f"{prefix}:{indexed[int(upstream_id)]['key']}"
                edge_branch = source.get("branchIndex")
            specs.append({
                "identity": identity,
                "title": _clone_title(prefix, source),
                "type": str(source["type"]),
                # Old-key refs are valid only until every candidate node has
                # a key.  They are rewritten in the config pass below.
                "initial_config": copy.deepcopy(dict(source.get("config") or {})),
                "config_source": copy.deepcopy(dict(source.get("config") or {})),
                "prefix": prefix,
                "source_key": source_key,
                "upstream": upstream,
                "branch": edge_branch,
                "source_downstream": source.get("downstreamId"),
                "source_root_key": root_key,
            })
    titles = [str(spec["title"]) for spec in specs]
    if len(titles) != len(set(titles)):
        raise ResumeError(f"{business.name} deterministic worker titles are not unique")
    return specs, graphs


def _worker_node_map(
    workflow: Mapping[str, Any], specs: list[Mapping[str, Any]]
) -> dict[str, dict[str, Any]]:
    expected_by_title = {str(spec["title"]): spec for spec in specs}
    unexpected = [node.get("title") for node in workflow.get("nodes") or []
                  if isinstance(node, Mapping) and node.get("title") not in expected_by_title]
    if unexpected:
        raise ResumeError(
            f"worker candidate {workflow.get('id')} has unexpected node titles: {unexpected[:4]!r}"
        )
    actual: dict[str, dict[str, Any]] = {}
    for spec in specs:
        node = _strict_node(workflow, title=str(spec["title"]), expected_type=str(spec["type"]))
        if node is not None:
            actual[str(spec["identity"])] = node
    return actual


def _desired_worker_configs(
    specs: list[Mapping[str, Any]], actual: Mapping[str, Mapping[str, Any]]
) -> dict[str, dict[str, Any]]:
    """Rewrite per-clone references with the candidate's regenerated keys."""
    desired: dict[str, dict[str, Any]] = {}
    for spec in specs:
        identity = str(spec["identity"])
        source_config = spec.get("config_source")
        if source_config is None:
            desired[identity] = copy.deepcopy(dict(spec["initial_config"]))
            continue
        prefix = str(spec["prefix"])
        keymap = {
            str(other["source_key"]): str(actual[str(other["identity"])]["key"])
            for other in specs
            if other.get("prefix") == prefix and other.get("source_key") is not None
        }
        try:
            rewritten = blueprint._replace_refs(source_config, keymap)
        except blueprint.PlanError as exc:
            raise ResumeError(f"cannot rewrite {identity} cloned references: {exc}") from exc
        if not isinstance(rewritten, Mapping):  # source configs must be objects
            raise ResumeError(f"{identity} source config is not an object")
        desired[identity] = copy.deepcopy(dict(rewritten))
    return desired


def _validate_worker(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    business: blueprint.Business,
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    row = _workflow(api, int(candidate["id"]))
    _assert_candidate(row, title=str(candidate["title"]), config=blueprint.worker_config(business))
    specs, _graphs = _expected_worker(manifest, business)
    actual = _worker_node_map(row, specs)
    if len(actual) != len(specs) or len(row.get("nodes") or []) != len(specs):
        raise ResumeError(
            f"worker {business.name} incomplete: {len(actual)}/{len(specs)} planned nodes"
        )
    desired_configs = _desired_worker_configs(specs, actual)
    for spec in specs:
        identity = str(spec["identity"])
        node = actual[identity]
        if node.get("config") != desired_configs[identity]:
            raise ResumeError(f"worker {business.name} config drifted: {spec['title']!r}")
        upstream_identity = spec.get("upstream")
        if upstream_identity is None:
            if node.get("upstreamId") not in (None, ""):
                raise ResumeError(f"worker {business.name} root has unexpected upstream")
            continue
        parent = actual[str(upstream_identity)]
        if node.get("upstreamId") != parent["id"] or node.get("branchIndex") != spec.get("branch"):
            raise ResumeError(f"worker {business.name} edge drifted at {spec['title']!r}")
        if spec.get("branch") is None and parent.get("downstreamId") != node["id"]:
            raise ResumeError(f"worker {business.name} continuation drifted at {spec['title']!r}")
    if not _refs_resolve(row):
        raise ResumeError(f"worker {business.name} has unresolved cloned node refs")
    return {
        "id": row["id"], "key": row.get("key"), "title": row.get("title"),
        "business": business.name, "route": business.route,
        "enabled": row.get("enabled"), "executed": row.get("executed"),
        "node_count": len(row.get("nodes") or []), "references_resolve": True,
        "node_map": {identity: {"id": node["id"], "key": node.get("key")}
                     for identity, node in actual.items()},
    }


def _reconcile_worker(
    api: RootNocoBaseApi,
    candidate: Mapping[str, Any],
    *,
    business: blueprint.Business,
    manifest: Mapping[str, Any],
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    """Append/reconcile one disabled business worker in three idempotent passes."""
    workflow_id = int(candidate["id"])
    _assert_candidate(_workflow(api, workflow_id), title=str(candidate["title"]),
                      config=blueprint.worker_config(business))
    specs, _graphs = _expected_worker(manifest, business)
    # Pass 1: every clone node gets a key once.  No retry can duplicate a node:
    # _ensure_node always re-reads by its deterministic title after a timeout.
    for spec in specs:
        _ensure_node(api, workflow_id, title=str(spec["title"]), node_type=str(spec["type"]),
                     initial_config=dict(spec["initial_config"]), checkpoint=checkpoint)
    row = _workflow(api, workflow_id)
    actual = _worker_node_map(row, specs)
    if len(actual) != len(specs):
        raise ResumeError(f"worker {business.name} remained incomplete after node pass")
    # Pass 2: all keys now exist, so references can be rewritten exactly once.
    desired_configs = _desired_worker_configs(specs, actual)
    for spec in specs:
        identity = str(spec["identity"])
        _patch_node(api, workflow_id, int(actual[identity]["id"]), {
            "config": desired_configs[identity],
        }, checkpoint=checkpoint, reason=f"config:{business.name}:{identity}")
    # Pass 3: edges.  Branch edges live only on the child; ordinary linear
    # edges additionally keep the parent downstream pointer for NocoBase UI.
    for spec in specs:
        upstream_identity = spec.get("upstream")
        if upstream_identity is None:
            continue
        parent = actual[str(upstream_identity)]
        child = actual[str(spec["identity"])]
        _patch_node(api, workflow_id, int(child["id"]), {
            "upstreamId": parent["id"], "branchIndex": spec.get("branch"),
        }, checkpoint=checkpoint, reason=f"edge:{business.name}:{spec['identity']}")
        if spec.get("branch") is None:
            _patch_node(api, workflow_id, int(parent["id"]), {"downstreamId": child["id"]},
                        checkpoint=checkpoint,
                        reason=f"continuation:{business.name}:{upstream_identity}->{spec['identity']}")
    return _validate_worker(api, candidate, business=business, manifest=manifest)


def _manifest_path(migration_id: str) -> Path:
    return original._manifest_path(migration_id)


def _journal_path(migration_id: str) -> Path:
    return _manifest_path(migration_id).with_name("resume.json")


def _load_manifest(migration_id: str) -> tuple[Path, dict[str, Any]]:
    if not original._MIGRATION_RE.fullmatch(migration_id):
        raise ResumeError("migration ID must be lowercase letters/numbers/hyphens (6-64 chars)")
    path = _manifest_path(migration_id)
    if not path.is_file():
        raise ResumeError(
            f"preparation manifest is required for resume: {path}; use the original prepare tool for a new migration"
        )
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ResumeError(f"cannot read preparation manifest: {exc}") from exc
    if (manifest.get("format") != original.MANIFEST_FORMAT
            or manifest.get("environment") != "13001"
            or manifest.get("migration_id") != migration_id):
        raise ResumeError("manifest does not identify this 13001 migration")
    expected_digest = blueprint.digest(blueprint.static_plan())
    if manifest.get("plan_sha256") != expected_digest:
        raise ResumeError("local dispatch blueprint changed since preparation; refusing to append")
    return path, manifest


def _checkpoint_writer(migration_id: str) -> Callable[[str, Mapping[str, Any]], None]:
    """Make lightweight local checkpoints.  They never grant trust over GETs."""
    path = _journal_path(migration_id)
    state: dict[str, Any]
    if path.is_file():
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ResumeError(f"cannot read resume journal: {exc}") from exc
        if state.get("format") != RESUME_FORMAT or state.get("migration_id") != migration_id:
            raise ResumeError("resume journal belongs to another migration")
    else:
        state = {
            "format": RESUME_FORMAT,
            "migration_id": migration_id,
            "environment": "13001",
            "created_at_utc": _now(),
            "events": [],
        }

    def checkpoint(action: str, details: Mapping[str, Any]) -> None:
        state["updated_at_utc"] = _now()
        state["events"].append({"at_utc": state["updated_at_utc"], "action": action,
                                "details": dict(details)})
        # Keep the journal bounded even after many deliberately small patches.
        state["events"] = state["events"][-200:]
        _atomic_json(path, state)

    return checkpoint


def inspect(migration_id: str) -> dict[str, Any]:
    _manifest_path_value, manifest = _load_manifest(migration_id)
    api = _api()
    title = original._workflow_title("ingress", migration_id)
    candidate = _find_candidate(api, title)
    result: dict[str, Any] = {
        "writes_remote": False,
        "migration_id": migration_id,
        "manifest_phase": manifest.get("phase"),
        "ingress_title": title,
        "candidate": None,
    }
    if candidate is not None:
        _assert_candidate(candidate, title=title, config=blueprint.ingress_config())
        actual = _ingress_node_map(candidate)
        result["candidate"] = {
            "id": candidate["id"], "enabled": candidate.get("enabled"),
            "node_count": len(candidate.get("nodes") or []),
            "expected_node_count": len(_expected_ingress()),
            "missing_titles": [spec["title"] for spec in _expected_ingress()
                               if spec["identity"] not in actual],
        }
    worker_summary: dict[str, Any] = {}
    for business in blueprint.BUSINESSES:
        worker_title = original._workflow_title("worker", migration_id, business)
        worker = _find_candidate(api, worker_title)
        if worker is None:
            worker_summary[business.name] = {"present": False}
            continue
        _assert_candidate(worker, title=worker_title, config=blueprint.worker_config(business))
        specs, _graphs = _expected_worker(manifest, business)
        actual = _worker_node_map(worker, specs)
        worker_summary[business.name] = {
            "present": True,
            "id": worker["id"],
            "enabled": worker.get("enabled"),
            "node_count": len(worker.get("nodes") or []),
            "expected_node_count": len(specs),
            "missing_titles": [spec["title"] for spec in specs
                               if spec["identity"] not in actual],
        }
    result["workers"] = worker_summary
    return result


def resume_ingress(migration_id: str) -> dict[str, Any]:
    manifest_path, manifest = _load_manifest(migration_id)
    api = _api()
    checkpoint = _checkpoint_writer(migration_id)
    title = original._workflow_title("ingress", migration_id)
    candidate = _create_or_find_disabled_candidate(
        api, title=title, config=blueprint.ingress_config(), checkpoint=checkpoint
    )
    result = _reconcile_ingress(api, candidate, checkpoint)
    candidates = manifest.setdefault("candidates", {"ingress": None, "workers": {}})
    if not isinstance(candidates, dict):
        raise ResumeError("manifest candidates field is malformed")
    candidates["ingress"] = result
    manifest["phase"] = "partial_disabled_candidates"
    manifest["resumed_at_utc"] = _now()
    manifest["resume_note"] = "Ingress reconciled by deterministic title; workers remain disabled/unprepared."
    _atomic_json(manifest_path, manifest)
    checkpoint("ingress_reconciled", {"workflow_id": result["id"], "node_count": result["node_count"]})
    return {
        "writes_remote": True,
        "migration_id": migration_id,
        "phase": "ingress_reconciled_disabled",
        "manifest": str(manifest_path),
        "journal": str(_journal_path(migration_id)),
        "ingress": result,
        "all_candidates_enabled": False,
    }


def _resume_worker(
    api: RootNocoBaseApi,
    manifest: dict[str, Any],
    migration_id: str,
    business: blueprint.Business,
    checkpoint: Callable[[str, Mapping[str, Any]], None],
) -> dict[str, Any]:
    title = original._workflow_title("worker", migration_id, business)
    candidate = _create_or_find_disabled_candidate(
        api, title=title, config=blueprint.worker_config(business), checkpoint=checkpoint
    )
    return _reconcile_worker(api, candidate, business=business, manifest=manifest,
                             checkpoint=checkpoint)


def resume_workers(migration_id: str, *, only: str | None = None) -> dict[str, Any]:
    """Build/recover marker workers, never enabling any candidate.

    ``only`` is intentionally a business catalogue key, making recovery of a
    long graph possible without rerunning other finished workers.
    """
    manifest_path, manifest = _load_manifest(migration_id)
    api = _api()
    checkpoint = _checkpoint_writer(migration_id)
    selected = [business for business in blueprint.BUSINESSES
                if only is None or business.name == only]
    if not selected:
        valid = ", ".join(business.name for business in blueprint.BUSINESSES)
        raise ResumeError(f"unknown --business {only!r}; expected one of: {valid}")
    candidates = manifest.setdefault("candidates", {"ingress": None, "workers": {}})
    if not isinstance(candidates, dict):
        raise ResumeError("manifest candidates field is malformed")
    workers = candidates.setdefault("workers", {})
    if not isinstance(workers, dict):
        raise ResumeError("manifest candidates.workers field is malformed")
    results: dict[str, Any] = {}
    for business in selected:
        result = _resume_worker(api, manifest, migration_id, business, checkpoint)
        workers[business.name] = result
        manifest["phase"] = "partial_disabled_candidates"
        manifest["resumed_at_utc"] = _now()
        _atomic_json(manifest_path, manifest)
        checkpoint("worker_reconciled", {"business": business.name,
                                           "workflow_id": result["id"],
                                           "node_count": result["node_count"]})
        results[business.name] = result
    ingress = candidates.get("ingress")
    all_workers = set(workers) == {business.name for business in blueprint.BUSINESSES}
    if isinstance(ingress, Mapping) and all_workers:
        # Verify flags are still false before calling the candidate set ready.
        if ingress.get("enabled") is False and all(result.get("enabled") is False
                                                   for result in workers.values()
                                                   if isinstance(result, Mapping)):
            manifest["phase"] = "prepared_disabled"
            manifest["prepared_at_utc"] = _now()
            _atomic_json(manifest_path, manifest)
    return {
        "writes_remote": True,
        "migration_id": migration_id,
        "phase": manifest.get("phase"),
        "manifest": str(manifest_path),
        "journal": str(_journal_path(migration_id)),
        "workers": results,
        "all_candidates_enabled": False,
    }


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--inspect", action="store_true", help="Read partial ingress state only.")
    action.add_argument("--resume-ingress", action="store_true",
                        help="Append/reconcile only the disabled ingress candidate.")
    action.add_argument("--resume-workers", action="store_true",
                        help="Append/reconcile disabled business workers (or one --business).")
    parser.add_argument("--migration-id", required=True,
                        help="Existing original prepare migration ID, e.g. api-staging-20261019d.")
    parser.add_argument("--confirm", help="Required literal with --resume-ingress.")
    parser.add_argument("--business", help="One catalogue key with --resume-workers; omit for all 12.")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if args.inspect:
            if args.business:
                raise ResumeError("--business is only valid with --resume-workers")
            result = inspect(args.migration_id)
        elif args.resume_ingress:
            if args.business:
                raise ResumeError("--business is only valid with --resume-workers")
            if args.confirm != RESUME_CONFIRM:
                raise ResumeError("--resume-ingress requires --confirm " + RESUME_CONFIRM)
            result = resume_ingress(args.migration_id)
        else:
            if args.confirm != RESUME_CONFIRM:
                raise ResumeError("--resume-workers requires --confirm " + RESUME_CONFIRM)
            result = resume_workers(args.migration_id, only=args.business)
        print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except (ResumeError, ApiError, blueprint.PlanError) as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
