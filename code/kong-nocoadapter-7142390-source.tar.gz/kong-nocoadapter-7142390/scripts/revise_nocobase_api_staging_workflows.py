#!/usr/bin/env python3
"""Revise enabled API Request Staging Create/Update workflows.

Executed workflows cannot be edited in place. This script:
1. creates a same-key revision
2. writes f_source_system $ne CMTF
3. rebuilds Create/Update graphs so overlay fields land on application
4. enables the new revision (old version turns off)
"""

from __future__ import annotations

import argparse
import copy
import os
import sys
from collections.abc import Callable
from typing import Any, Optional

from create_nocobase_phase_c_chi_workflows import (
    CREATE_API_TYPE as CHI_CREATE_API_TYPE,
)
from create_nocobase_phase_c_chi_workflows import (
    CREATE_TITLE as CHI_CREATE_TITLE,
)
from create_nocobase_phase_c_chi_workflows import (
    UPDATE_API_TYPE as CHI_UPDATE_API_TYPE,
)
from create_nocobase_phase_c_chi_workflows import (
    UPDATE_TITLE as CHI_UPDATE_TITLE,
)
from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    disable_workflows_named,
    list_existing,
    set_enabled,
)
from create_nocobase_phase_c_chi_workflows import (
    build_create_graph as build_chi_create,
)
from create_nocobase_phase_c_chi_workflows import (
    build_update_graph as build_chi_update,
)
from create_nocobase_phase_d_closure_workflows import BPS as CLOSURE_BPS
from create_nocobase_phase_d_closure_workflows import (
    build_create_graph as build_closure_create,
)
from create_nocobase_phase_d_closure_workflows import (
    build_update_graph as build_closure_update,
)
from create_nocobase_phase_e_sh_rp_workflows import BPS as SH_RP_BPS
from create_nocobase_phase_e_sh_rp_workflows import (
    build_create_graph as build_sh_rp_create,
)
from create_nocobase_phase_e_sh_rp_workflows import (
    build_update_graph as build_sh_rp_update,
)
from create_nocobase_phase_f_change_workflows import BPS as CHANGE_BPS
from create_nocobase_phase_f_change_workflows import (
    build_create_graph as build_change_create,
)
from create_nocobase_phase_f_change_workflows import (
    build_update_graph as build_change_update,
)
from create_nocobase_phase_g_prosecution_workflows import (
    CREATE_API_TYPE as PROSECUTION_CREATE_API_TYPE,
)
from create_nocobase_phase_g_prosecution_workflows import (
    CREATE_TITLE as PROSECUTION_CREATE_TITLE,
)
from create_nocobase_phase_g_prosecution_workflows import (
    UPDATE_API_TYPE as PROSECUTION_UPDATE_API_TYPE,
)
from create_nocobase_phase_g_prosecution_workflows import (
    UPDATE_TITLE as PROSECUTION_UPDATE_TITLE,
)
from create_nocobase_phase_g_prosecution_workflows import (
    build_create_graph as build_prosecution_create,
)
from create_nocobase_phase_g_prosecution_workflows import (
    build_update_graph as build_prosecution_update,
)
from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from workflow_source_condition import (
    destroy_workflow_nodes,
    external_source_condition,
    replace_op_eq_with_external,
    revision_workflow,
)

Builder = Callable[[NocoBaseApi, int], None]

CHI_V2_BY_V1 = {
    CHI_CREATE_TITLE: "API Request Staging — Create Changing Home Information v2",
    CHI_UPDATE_TITLE: "API Request Staging — Update Changing Home Information v2",
}
ADDRESS_CODES_TITLE = (
    "API Request Staging — Dispatch by Source/Event/API Type — Address Codes v2"
)


def ensure_update_reservation_field(
    api: RootNocoBaseApi, *, create_if_missing: bool
) -> Optional[dict[str, Any]]:
    """Ensure the integration-only parent UPDATE reservation field exists."""

    path = "/api/collections/t_api_request_staging/fields:list?pageSize=400"
    rows = api.request("GET", path) or []
    matching = [row for row in rows if row.get("name") == "f_active_update_id"]
    if not matching and create_if_missing:
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:create",
            {
                "name": "f_active_update_id",
                "type": "string",
                "interface": "input",
                "uiSchema": {
                    "type": "string",
                    "title": "Active Update ID",
                    "x-component": "Input",
                },
            },
        )
        rows = api.request("GET", path) or []
        matching = [
            row for row in rows if row.get("name") == "f_active_update_id"
        ]
    if not matching:
        print("reservation_field=missing")
        return None
    if len(matching) != 1:
        raise ApiError("Staging f_active_update_id is ambiguous")
    field = matching[0]
    if field.get("type") != "string" or field.get("interface") != "input":
        raise ApiError("Staging f_active_update_id conflicts with reservation schema")
    print("reservation_field=ready")
    return field


def target_named(api: NocoBaseApi, title: str) -> dict[str, Any]:
    found = list_existing(api, title)
    if not found:
        raise ApiError(f"No workflow titled {title!r}")
    enabled = [row for row in found if row.get("enabled")]
    if len(enabled) > 1:
        raise ApiError(
            f"Expected one enabled workflow titled {title!r}, found {len(enabled)}"
        )
    if len(enabled) == 1:
        return enabled[0]
    current = [row for row in found if row.get("current")]
    if len(current) == 1:
        return current[0]
    found.sort(key=lambda row: int(row["id"]))
    return found[-1]


def patch_condition(
    api: NocoBaseApi, workflow: dict[str, Any], condition: dict[str, Any]
) -> None:
    config = copy.deepcopy(workflow.get("config") or {})
    config["condition"] = condition
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow['id']}",
        {"config": config},
    )


def _reenable_original(
    api: NocoBaseApi, original_id: int, revision_id: int | None
) -> None:
    if revision_id is not None:
        try:
            if api.get_workflow(revision_id).get("enabled"):
                return
        except Exception:
            pass
    set_enabled(api, original_id, True)
    print(f"reenabled_original_id={original_id}")


def revise_rebuild(
    api: NocoBaseApi,
    *,
    title: str,
    condition: dict[str, Any],
    build: Builder,
) -> dict[str, Any]:
    current = target_named(api, title)
    original_id = int(current["id"])
    was_enabled = bool(current.get("enabled"))
    revision_id: int | None = None
    print(f"revise_from_id={original_id} title={title} was_enabled={was_enabled}")
    try:
        revision = revision_workflow(api, original_id)
        revision_id = int(revision["id"])
        print(f"revision_id={revision_id}")
        patch_condition(api, revision, condition)
        fresh = api.get_workflow(revision_id)
        destroy_workflow_nodes(api, fresh)
        build(api, revision_id)
        set_enabled(api, revision_id, True)
        final = api.get_workflow(revision_id)
        print(f"revision_enabled={str(bool(final.get('enabled'))).lower()}")
        print(f"revision_node_count={len(final.get('nodes') or [])}")
        return final
    except Exception:
        if was_enabled:
            _reenable_original(api, original_id, revision_id)
        raise


def revise_condition_only(api: NocoBaseApi, title: str) -> dict[str, Any]:
    current = target_named(api, title)
    original_id = int(current["id"])
    was_enabled = bool(current.get("enabled"))
    revision_id: int | None = None
    print(
        f"revise_condition_from_id={original_id} title={title} "
        f"was_enabled={was_enabled}"
    )
    try:
        revision = revision_workflow(api, original_id)
        revision_id = int(revision["id"])
        print(f"revision_id={revision_id}")
        rewritten = replace_op_eq_with_external(
            (revision.get("config") or {}).get("condition")
        )
        if rewritten is None:
            raise ApiError(f"No condition to rewrite on {title!r}")
        patch_condition(api, revision, rewritten)
        set_enabled(api, revision_id, True)
        final = api.get_workflow(revision_id)
        print(f"revision_enabled={str(bool(final.get('enabled'))).lower()}")
        return final
    except Exception:
        if was_enabled:
            _reenable_original(api, original_id, revision_id)
        raise


def jobs(api: NocoBaseApi) -> list[tuple[str, Callable[[], dict[str, Any]]]]:
    items: list[tuple[str, Callable[[], dict[str, Any]]]] = [
        (
            CHI_CREATE_TITLE,
            lambda: revise_rebuild(
                api,
                title=CHI_CREATE_TITLE,
                condition=external_source_condition("CREATE", CHI_CREATE_API_TYPE),
                build=build_chi_create,
            ),
        ),
        (
            CHI_UPDATE_TITLE,
            lambda: revise_rebuild(
                api,
                title=CHI_UPDATE_TITLE,
                condition=external_source_condition("UPDATE", CHI_UPDATE_API_TYPE),
                build=build_chi_update,
            ),
        ),
    ]
    for bp in CLOSURE_BPS:
        items.append(
            (
                bp["create_title"],
                lambda bp=bp: revise_rebuild(
                    api,
                    title=bp["create_title"],
                    condition=external_source_condition(
                        "CREATE", bp["create_api_type"]
                    ),
                    build=lambda workflow_api, workflow_id, bp=bp: (
                        build_closure_create(workflow_api, workflow_id, bp)
                    ),
                ),
            )
        )
        items.append(
            (
                bp["update_title"],
                lambda bp=bp: revise_rebuild(
                    api,
                    title=bp["update_title"],
                    condition=external_source_condition(
                        "UPDATE", bp["update_api_type"]
                    ),
                    build=lambda workflow_api, workflow_id, bp=bp: (
                        build_closure_update(workflow_api, workflow_id, bp)
                    ),
                ),
            )
        )
    for bp in SH_RP_BPS:
        items.append(
            (
                bp["create_title"],
                lambda bp=bp: revise_rebuild(
                    api,
                    title=bp["create_title"],
                    condition=external_source_condition(
                        "CREATE", bp["create_api_type"]
                    ),
                    build=lambda workflow_api, workflow_id, bp=bp: (
                        build_sh_rp_create(workflow_api, workflow_id, bp)
                    ),
                ),
            )
        )
        items.append(
            (
                bp["update_title"],
                lambda bp=bp: revise_rebuild(
                    api,
                    title=bp["update_title"],
                    condition=external_source_condition(
                        "UPDATE", bp["update_api_type"]
                    ),
                    build=lambda workflow_api, workflow_id, bp=bp: (
                        build_sh_rp_update(workflow_api, workflow_id, bp)
                    ),
                ),
            )
        )
    for bp in CHANGE_BPS:
        items.append(
            (
                bp["create_title"],
                lambda bp=bp: revise_rebuild(
                    api,
                    title=bp["create_title"],
                    condition=external_source_condition(
                        "CREATE", bp["create_api_type"]
                    ),
                    build=lambda workflow_api, workflow_id, bp=bp: (
                        build_change_create(workflow_api, workflow_id, bp)
                    ),
                ),
            )
        )
        items.append(
            (
                bp["update_title"],
                lambda bp=bp: revise_rebuild(
                    api,
                    title=bp["update_title"],
                    condition=external_source_condition(
                        "UPDATE", bp["update_api_type"]
                    ),
                    build=lambda workflow_api, workflow_id, bp=bp: (
                        build_change_update(workflow_api, workflow_id, bp)
                    ),
                ),
            )
        )
    items.extend(
        [
            (
                PROSECUTION_CREATE_TITLE,
                lambda: revise_rebuild(
                    api,
                    title=PROSECUTION_CREATE_TITLE,
                    condition=external_source_condition(
                        "CREATE", PROSECUTION_CREATE_API_TYPE
                    ),
                    build=build_prosecution_create,
                ),
            ),
            (
                PROSECUTION_UPDATE_TITLE,
                lambda: revise_rebuild(
                    api,
                    title=PROSECUTION_UPDATE_TITLE,
                    condition=external_source_condition(
                        "UPDATE", PROSECUTION_UPDATE_API_TYPE
                    ),
                    build=build_prosecution_update,
                ),
            ),
            (
                ADDRESS_CODES_TITLE,
                lambda: revise_condition_only(
                    api,
                    ADDRESS_CODES_TITLE,
                ),
            ),
            (
                "API Request Staging — Update New Licence Data v5",
                lambda: revise_condition_only(
                    api, "API Request Staging — Update New Licence Data v5"
                ),
            ),
        ]
    )
    return items


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--only")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    ensure_update_reservation_field(api, create_if_missing=args.apply)
    selected = jobs(api)
    if args.only:
        selected = [item for item in selected if args.only in item[0]]
        if not selected:
            print(f"error=no job matched {args.only!r}", file=sys.stderr)
            return 2
    for title, _job in selected:
        print(f"job={title}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    # Resolve every target before creating the first revision. This avoids a
    # partially upgraded environment when a workflow was not migrated from
    # development or when duplicate enabled revisions exist.
    for title, _job in selected:
        current = target_named(api, title)
        print(
            f"preflight_workflow_id={current.get('id')} "
            f"enabled={str(bool(current.get('enabled'))).lower()} title={title}"
        )
    print("preflight=passed")

    for title, job in selected:
        print(f"start={title}")
        job()
        leftover_v2 = CHI_V2_BY_V1.get(title)
        if leftover_v2:
            disable_workflows_named(api, leftover_v2)
        print(f"done={title}")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
