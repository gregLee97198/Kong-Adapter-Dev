#!/usr/bin/env python3
"""Prepare a disabled CHI Created→Staging bridge revision with OP race guard.

Only the integration bridge is revised. The current enabled bridge is restored
immediately after NocoBase's revision API, and the new graph stays disabled.
Native Intake/CHI business workflows and Home Record tables are untouched.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    CREATE_BRIDGE_TITLE,
    RootNocoBaseApi,
    create_node,
    link,
    ref,
)
from extend_nocobase_staging_relations import ApiError
from revise_nocobase_chi_page_projection import (
    ensure_intake_create_marker_field,
    node_by_title,
)

BRIDGE_SOURCE_ID = 386582574202880
WAIT_TITLE = "Wait for OP CHI Intake backfill before CMTF staging"
RECHECK_TITLE = "Recheck OP CHI CREATE staging by Intake"
RECHECK_CONDITION_TITLE = "OP CHI CREATE staging linked after wait"
PROVENANCE_QUERY_TITLE = "Load CHI Intake API CREATE provenance"
PROVENANCE_CONDITION_TITLE = "CHI Intake came from OP CREATE Staging"
SOURCE_QUERY_TITLE = "Resolve existing CREATE staging"
SOURCE_CONDITION_TITLE = "Existing CREATE staging exists"
SOURCE_CREATE_TITLE = "Create CMTF CHI staging at Submitted"


def bridge_source(api: RootNocoBaseApi) -> dict[str, Any]:
    source = api.get_workflow(BRIDGE_SOURCE_ID)
    config = source.get("config") or {}
    if (
        source.get("title") != CREATE_BRIDGE_TITLE
        or not source.get("enabled")
        or config.get("collection") != "t_change_home_information_app"
        or config.get("mode") != 1
        or config.get("condition") != {}
    ):
        raise ApiError("Enabled CHI Created bridge differs from reviewed source")
    titles = {str(node.get("title")) for node in source.get("nodes") or []}
    expected = {
        SOURCE_QUERY_TITLE,
        SOURCE_CONDITION_TITLE,
        SOURCE_CREATE_TITLE,
    }
    if titles != expected or len(source.get("nodes") or []) != 3:
        raise ApiError("CHI Created bridge source node graph differs from v1")
    create = node_by_title(source, SOURCE_CREATE_TITLE)
    values = ((create.get("config") or {}).get("params") or {}).get("values") or {}
    if (
        values.get("f_source_system") != "CMTF"
        or values.get("f_status") != "succeeded"
        or values.get("f_application_status") != "Submitted"
    ):
        raise ApiError("CHI Created bridge CMTF record contract differs")
    return source


def validate_bridge_draft(draft: dict[str, Any], source: dict[str, Any]) -> None:
    if (
        draft.get("enabled")
        or draft.get("executed")
        or draft.get("key") != source.get("key")
        or draft.get("title") != source.get("title")
        or (draft.get("config") or {}) != (source.get("config") or {})
    ):
        raise ApiError("CHI bridge draft is not an unchanged disabled revision")
    nodes = draft.get("nodes") or []
    titles = {str(node.get("title")) for node in nodes}
    expected = {
        SOURCE_QUERY_TITLE,
        SOURCE_CONDITION_TITLE,
        SOURCE_CREATE_TITLE,
        PROVENANCE_QUERY_TITLE,
        PROVENANCE_CONDITION_TITLE,
        WAIT_TITLE,
        RECHECK_TITLE,
        RECHECK_CONDITION_TITLE,
    }
    if titles != expected or len(nodes) != 8:
        raise ApiError("CHI bridge delayed recheck graph is incomplete")
    provenance = node_by_title(draft, PROVENANCE_QUERY_TITLE)
    api_origin = node_by_title(draft, PROVENANCE_CONDITION_TITLE)
    original = node_by_title(draft, SOURCE_QUERY_TITLE)
    initial_condition = node_by_title(draft, SOURCE_CONDITION_TITLE)
    wait = node_by_title(draft, WAIT_TITLE)
    recheck = node_by_title(draft, RECHECK_TITLE)
    found = node_by_title(draft, RECHECK_CONDITION_TITLE)
    cmtf_create = node_by_title(draft, SOURCE_CREATE_TITLE)
    if (
        provenance.get("upstreamId") is not None
        or api_origin.get("upstreamId") != provenance["id"]
        or api_origin.get("downstreamId") is not None
        or original.get("upstreamId") != api_origin["id"]
        or original.get("branchIndex") != 0
        or (provenance.get("config") or {}).get("collection") != "t_intake_form"
        or wait.get("upstreamId") != initial_condition["id"]
        or wait.get("branchIndex") != 0
        or recheck.get("upstreamId") != wait["id"]
        or found.get("upstreamId") != recheck["id"]
        or cmtf_create.get("upstreamId") != found["id"]
        or cmtf_create.get("branchIndex") != 0
    ):
        raise ApiError("CHI bridge can create CMTF staging before OP recheck")
    marker_filter = ((provenance.get("config") or {}).get("params") or {}).get(
        "filter"
    )
    if marker_filter != {
        "$and": [{"id": {"$eq": "{{$context.data.fk_intake_form}}"}}]
    }:
        raise ApiError("CHI bridge provenance must inspect linked Intake only")
    marker_calculations = (
        ((api_origin.get("config") or {}).get("calculation") or {}).get("group")
        or {}
    ).get("calculations") or []
    if marker_calculations != [
        {"calculator": "gt", "operands": [ref(provenance, "id"), 0]},
        {"calculator": "notEqual", "operands": [
            ref(provenance, "f_api_create_staging_id"), None,
        ]},
        {"calculator": "notEqual", "operands": [
            ref(provenance, "f_api_create_staging_id"), "",
        ]},
    ]:
        raise ApiError("CHI bridge does not suppress Intake with OP CREATE marker")
    wait_config = wait.get("config") or {}
    if wait_config.get("duration") != 3 or wait_config.get("unit") != 1000:
        raise ApiError("CHI bridge wait is not a bounded three seconds")
    if (recheck.get("config") or {}) != (original.get("config") or {}):
        raise ApiError("CHI bridge recheck no longer uses Intake/application IDs")
    create_values = ((cmtf_create.get("config") or {}).get("params") or {}).get(
        "values"
    ) or {}
    if create_values.get("f_application_status") != "Accepted":
        raise ApiError("CMTF bridge application status is not Accepted")
    calculations = (
        ((found.get("config") or {}).get("calculation") or {}).get("group") or {}
    ).get("calculations") or []
    if calculations != [
        {"calculator": "gt", "operands": [ref(recheck, "id"), 0]}
    ]:
        raise ApiError("CHI bridge recheck does not suppress an existing OP ID")
    for node in nodes:
        if node.get("type") in ("update", "destroy"):
            raise ApiError("CHI Created bridge revision may not update business data")
        if node.get("type") == "create" and node["id"] != cmtf_create["id"]:
            raise ApiError("CHI Created bridge revision may not create other rows")


def existing_bridge_draft(
    api: RootNocoBaseApi, source: dict[str, Any]
) -> dict[str, Any] | None:
    query = urllib.parse.urlencode(
        {"filter[title]": str(source["title"]), "pageSize": 100}
    )
    rows = api.request("GET", "/api/workflows:list?" + query) or []
    drafts: list[dict[str, Any]] = []
    for row in rows:
        if (
            row.get("title") != source["title"]
            or row.get("key") != source["key"]
            or row.get("enabled")
            or int(row.get("id") or 0) == int(source["id"])
        ):
            continue
        candidate = api.get_workflow(int(row["id"]))
        if PROVENANCE_QUERY_TITLE in {
            str(node.get("title")) for node in candidate.get("nodes") or []
        }:
            drafts.append(candidate)
    if not drafts:
        return None
    if len(drafts) != 1:
        raise ApiError("Multiple guarded CHI bridge drafts require manual review")
    validate_bridge_draft(drafts[0], source)
    return drafts[0]


def draft_bridge(api: RootNocoBaseApi, source: dict[str, Any]) -> dict[str, Any]:
    """Use NocoBase's revision API but restore old enabled state in finally."""
    old_id = int(source["id"])
    created_id: int | None = None
    api.request(
        "POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": False}
    )
    try:
        query = urllib.parse.urlencode(
            {"filterByTk": old_id, "filter[key]": str(source["key"])}
        )
        created = api.request("POST", "/api/workflows:revision?" + query, {})
        if not isinstance(created, dict) or not created.get("id"):
            raise ApiError("CHI Created bridge revision returned no ID")
        created_id = int(created["id"])
    finally:
        api.request(
            "POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": True}
        )
    if not api.get_workflow(old_id).get("enabled") or created_id is None:
        raise ApiError("Original CHI Created bridge was not restored")
    draft = api.get_workflow(created_id)
    if draft.get("enabled") or draft.get("executed"):
        raise ApiError("CHI Created bridge new revision is not disabled/editable")
    return draft


def add_bridge_wait(api: RootNocoBaseApi, draft: dict[str, Any]) -> None:
    wid = int(draft["id"])
    initial_condition = node_by_title(draft, SOURCE_CONDITION_TITLE)
    original_query = node_by_title(draft, SOURCE_QUERY_TITLE)
    cmtf_create = node_by_title(draft, SOURCE_CREATE_TITLE)
    provenance = create_node(
        api,
        wid,
        "query",
        PROVENANCE_QUERY_TITLE,
        {
            "collection": "t_intake_form",
            "multiple": False,
            "params": {
                "filter": {
                    "$and": [
                        {"id": {"$eq": "{{$context.data.fk_intake_form}}"}}
                    ]
                },
                "sort": [],
                "page": 1,
                "pageSize": 1,
                "appends": [],
            },
        },
    )
    api_origin = create_node(
        api,
        wid,
        "condition",
        PROVENANCE_CONDITION_TITLE,
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [ref(provenance, "id"), 0],
                        },
                        {
                            "calculator": "notEqual",
                            "operands": [
                                ref(provenance, "f_api_create_staging_id"),
                                None,
                            ],
                        },
                        {
                            "calculator": "notEqual",
                            "operands": [
                                ref(provenance, "f_api_create_staging_id"),
                                "",
                            ],
                        },
                    ],
                }
            },
        },
    )
    wait = create_node(
        api,
        wid,
        "delay",
        WAIT_TITLE,
        {"unit": 1000, "duration": 3, "endStatus": 1},
    )
    recheck = create_node(
        api,
        wid,
        "query",
        RECHECK_TITLE,
        dict(original_query.get("config") or {}),
    )
    found = create_node(
        api,
        wid,
        "condition",
        RECHECK_CONDITION_TITLE,
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {"calculator": "gt", "operands": [ref(recheck, "id"), 0]}
                    ],
                }
            },
        },
    )
    create_config = dict(cmtf_create.get("config") or {})
    create_params = dict(create_config.get("params") or {})
    create_values = dict(create_params.get("values") or {})
    create_values["f_application_status"] = "Accepted"
    create_params["values"] = create_values
    create_config["params"] = create_params
    api.update_node(int(cmtf_create["id"]), {"config": create_config})
    link(api, provenance, api_origin)
    link(api, api_origin, original_query, branch_index=0)
    link(api, initial_condition, wait, branch_index=0)
    link(api, wait, recheck)
    link(api, recheck, found)
    link(api, found, cmtf_create, branch_index=0)


def prepare_disabled_bridge(api: RootNocoBaseApi) -> dict[str, Any]:
    ensure_intake_create_marker_field(api, create_if_missing=True)
    source = bridge_source(api)
    reusable = existing_bridge_draft(api, source)
    if reusable is not None:
        return reusable
    draft = draft_bridge(api, source)
    add_bridge_wait(api, draft)
    reread = api.get_workflow(int(draft["id"]))
    validate_bridge_draft(reread, source)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Original CHI Created bridge was disabled after draft build")
    return reread


def patch_disabled_marker_guard(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Harden one disabled Bridge draft when linked Intake query is missing."""
    source = bridge_source(api)
    draft = api.get_workflow(revision_id)
    if (
        draft.get("enabled")
        or draft.get("executed")
        or draft.get("key") != source.get("key")
        or draft.get("title") != source.get("title")
    ):
        raise ApiError("Only the disabled CHI Created bridge draft may be patched")
    ensure_intake_create_marker_field(api, create_if_missing=False)
    provenance = node_by_title(draft, PROVENANCE_QUERY_TITLE)
    condition = node_by_title(draft, PROVENANCE_CONDITION_TITLE)
    config = dict(condition.get("config") or {})
    calculation = dict(config.get("calculation") or {})
    group = dict(calculation.get("group") or {})
    calculations = list(group.get("calculations") or [])
    expected = {"calculator": "gt", "operands": [ref(provenance, "id"), 0]}
    if expected in calculations:
        validate_bridge_draft(draft, source)
        return draft
    old_expected = [
        {
            "calculator": "notEqual",
            "operands": [ref(provenance, "f_api_create_staging_id"), None],
        },
        {
            "calculator": "notEqual",
            "operands": [ref(provenance, "f_api_create_staging_id"), ""],
        },
    ]
    if calculations != old_expected:
        raise ApiError("Disabled CHI Bridge marker condition differs from reviewed v1")
    group["calculations"] = [expected, *old_expected]
    calculation["group"] = group
    config["calculation"] = calculation
    api.update_node(int(condition["id"]), {"config": config})
    reread = api.get_workflow(revision_id)
    validate_bridge_draft(reread, source)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Created Bridge changed during disabled patch")
    return reread


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--create-disabled-draft", action="store_true")
    parser.add_argument("--patch-disabled-marker-guard", type=int)
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = RootNocoBaseApi(args.base_url, token)
    source = bridge_source(api)
    print(
        "source_id=",
        source["id"],
        "enabled=",
        source.get("enabled"),
        "node_count=",
        len(source.get("nodes") or []),
    )
    if args.create_disabled_draft and args.patch_disabled_marker_guard:
        raise ApiError("Bridge draft preparation and patch cannot be combined")
    if not args.create_disabled_draft and not args.patch_disabled_marker_guard:
        print("mode=dry-run")
        return 0
    if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
        raise ApiError("CHI bridge disabled draft preparation is restricted to 13001")
    draft = (
        patch_disabled_marker_guard(api, args.patch_disabled_marker_guard)
        if args.patch_disabled_marker_guard
        else prepare_disabled_bridge(api)
    )
    print(
        "disabled_revision_id=",
        draft["id"],
        "enabled=",
        draft.get("enabled"),
        "node_count=",
        len(draft.get("nodes") or []),
    )
    print("mode=disabled-draft-only;activation=not-performed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
