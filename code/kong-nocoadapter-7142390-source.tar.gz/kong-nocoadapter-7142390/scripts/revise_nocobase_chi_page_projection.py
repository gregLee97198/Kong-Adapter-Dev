#!/usr/bin/env python3
"""Guarded CHI page-field projection for staging workflow revisions.

This file is intentionally dry-run by default. Only the two CHI API staging
workflow keys may be revised; native Intake/CHI workflows are never edited.
The projection refuses source Home Record addresses and contacts, as well as
UI fields for which no verified CHI-owned storage path exists yet.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    CREATE_API_TYPE,
    CREATE_TITLE,
    UPDATE_API_TYPE,
    UPDATE_TITLE,
    RootNocoBaseApi,
    create_node,
    link,
    overlay_values,
    query_config,
    ref,
    scope,
    update_config,
)
from create_nocobase_staging_update_workflow import field_references
from extend_nocobase_staging_relations import ADDRESS_FIELDS, CONTACT_FIELDS, ApiError


def node_by_title(workflow: Mapping[str, Any], title: str) -> dict[str, Any]:
    """Resolve exactly one workflow node without importing legacy CHI upgrades."""
    found = [
        dict(node)
        for node in workflow.get("nodes") or []
        if node.get("title") == title
    ]
    if len(found) != 1:
        raise ApiError(f"Expected one node {title!r}, found {len(found)}")
    return found[0]

CHANGE_FLAGS = (
    "is_change_name",
    "is_change_address",
    "is_change_operator_or_operating_company",
    "is_change_rch_type",
    "is_change_maximum_capacity",
)
CHI_PAGE_FIELDS = (
    *CHANGE_FLAGS,
    "f_rch_name_en",
    "f_rch_name_cn",
    "f_service_type",
    "f_business_ownership_type",
    "fk_type_of_rch",
    "f_licence_capacity",
)
# Exactly the fields already accepted by the deployed Staging CHI overlay.
# They remain writable, but missing request properties must preserve the
# current CHI values instead of projecting an absent parse variable as null.
LEGACY_CHI_FIELDS = tuple(overlay_values({"key": "preview"}))
ALL_CHI_FIELDS = tuple(dict.fromkeys((*LEGACY_CHI_FIELDS, *CHI_PAGE_FIELDS)))
LEGACY_PART2_MAP = {
    "telephone_no": "f_telephone_no",
    "fax_no": "f_fax_no",
    "email": "f_email",
    "gender": "f_rch_gender",
    "premises_type": "f_rch_premises",
    "monthly_fee_min": "f_monthly_fee_per_resident_min",
    "monthly_fee_max": "f_monthly_fee_per_resident_max",
    "floor_area_sqm": "f_net_floor_area_sqm",
    "licence_capacity": "f_licence_capacity",
    "nursing_home_places": "f_beds_nursing",
    "care_and_attention_home_places": "f_beds_care_and_attention",
    "aged_home_places": "f_beds_meal",
    "self_care_hostel_places": "f_beds_self_care",
}
LEGACY_PART5_MAP = {
    "application_level": "f_application_level",
    "comments": "f_comments",
    "other_information": "f_other_information",
    "remarks": "f_remarks",
    "attachment_ids": "f_attachments_of_rchs",
}
# The five Change popups do not display beds, fees, floor area, gender, etc.
CONTACT_PAGE_MAP = {
    key: CONTACT_FIELDS[key]
    for key in (
        "full_name_en",
        "full_name_cn",
        "company_name_en",
        "company_name_cn",
        "hkid_part_1",
        "hkid_part_2",
        "hkid_part_3",
        "business_registration_no",
        "certificate_of_incorporation_no",
        "application_type",
        "mobile_phone",
        "email",
    )
}
CONTACT_PAGE_FIELDS = (
    *CONTACT_PAGE_MAP.values(),
    "fk_licence_contact_person",
    "fk_licence_contact_company",
)
DECLARATION_SLOTS = tuple(range(1, 11))
CONTACT_NESTED_FIELDS = (
    "f_rpop_op_app",
    *(f"f_rpop_app_detail_{slot}" for slot in DECLARATION_SLOTS),
)
SAFE_PARENT_CREATE_ID_SCRIPT = (
    "return {ready: typeof parentId !== 'undefined' "
    "&& typeof originalId !== 'undefined' "
    "&& !!parentId && !!originalId "
    "&& String(parentId) === String(originalId)};"
)
LEGACY_PARENT_CREATE_ID_SCRIPT = (
    "return {ready: !!parentId && !!originalId "
    "&& String(parentId) === String(originalId)};"
)
CHECKLIST_PREFLIGHT_TITLE = "Plan CHI Checklist preflight IDs"
CHECKLIST_INPUT_VALIDATE_TITLE = "Validate CHI Checklist input limits"
CHECKLIST_INPUT_VALID_TITLE = "CHI Checklist input is safe"
CHECKLIST_INPUT_FAIL_TITLE = "Mark invalid CHI Checklist staging failed"
CHECKLIST_INPUT_GUARD_TITLES = frozenset(
    {
        CHECKLIST_INPUT_VALIDATE_TITLE,
        CHECKLIST_INPUT_VALID_TITLE,
        CHECKLIST_INPUT_FAIL_TITLE,
    }
)
CHECKLIST_INPUT_VALIDATION_SCRIPT = """
try {
  const rows = typeof checklist === 'undefined' ? [] : checklist;
  if (!Array.isArray(rows)) return {ready: false,
    block_reason: 'chi_checklist_must_be_an_array'};
  if (rows.length > 100) return {ready: false,
    block_reason: 'chi_checklist_limit_exceeded: maximum 100 items'};
  const seen = new Set();
  for (const row of rows) {
    const code = row && row.position_code;
    if (typeof code !== 'string' || code.length === 0) return {ready: false,
      block_reason: 'chi_checklist_position_code_missing'};
    if (seen.has(code)) return {ready: false,
      block_reason: 'chi_checklist_duplicate_position_code: ' + code};
    seen.add(code);
  }
  return {ready: true, block_reason: null};
} catch (error) {
  return {ready: false,
    block_reason: 'chi_checklist_validation_failed: '
      + String(error && error.message || error)};
}
"""
CHECKLIST_PREFLIGHT_SCRIPT = (
    "const rows = typeof checklist !== 'undefined' "
    "&& Array.isArray(checklist) ? checklist : []; "
    "return {position_codes: [...new Set(rows.map(row => row && "
    "row.position_code).filter(code => typeof code === 'string' "
    "&& code.length > 0))], attachment_ids: [...new Set(rows.map(row "
    "=> Number(row && row.attachment_id)).filter(id => "
    "Number.isSafeInteger(id) && id > 0))]};"
)
SNAPSHOT_PLAN_TITLE = "Plan CHI native snapshot wait"
SNAPSHOT_WAIT_TITLE = "Wait for native CHI snapshot completion"
SNAPSHOT_PAUSE_TITLE = "Pause between CHI native snapshot checks"
SNAPSHOT_RECHECK_TITLE = "Recheck CHI native snapshot version"
SNAPSHOT_PENDING_TITLE = "CHI native snapshot still pending"
SNAPSHOT_WAIT_TITLES = frozenset(
    {
        SNAPSHOT_PLAN_TITLE,
        SNAPSHOT_WAIT_TITLE,
        SNAPSHOT_PAUSE_TITLE,
        SNAPSHOT_RECHECK_TITLE,
        SNAPSHOT_PENDING_TITLE,
    }
)
SNAPSHOT_WAIT_PLAN_SCRIPT = (
    "const version = Number(application && "
    "application.f_source_home_snapshot_version || 0); "
    "return {iterations: version >= 1 ? 0 : 5};"
)
SNAPSHOT_STILL_PENDING_SCRIPT = (
    "const version = Number(application && "
    "application.f_source_home_snapshot_version || 0); "
    "return {pending: version < 1};"
)
CONTACT_CLONE_PLAN_TITLE = "Plan CHI contact clone wait"
CONTACT_CLONE_WAIT_TITLE = "Wait for native CHI contact clone"
CONTACT_CLONE_PAUSE_TITLE = "Pause between CHI contact clone checks"
CONTACT_CLONE_RECHECK_COMPANY_TITLE = "Recheck CHI company after clone wait"
CONTACT_CLONE_RECHECK_PERSONS_TITLE = "Recheck CHI persons after clone wait"
CONTACT_CLONE_STILL_MISSING_TITLE = "CHI contact clone still missing"
CONTACT_CLONE_RELOAD_COMPANY_TITLE = "Reload CHI company after clone wait"
CONTACT_CLONE_RELOAD_PERSONS_TITLE = "Reload CHI persons after clone wait"
CONTACT_CLONE_PENDING_TITLE = "CHI operator clone still pending"
CONTACT_CLONE_PENDING_FAIL_TITLE = "Mark CHI operator clone failed"
CONTACT_CLONE_WAIT_TITLES = frozenset(
    {
        CONTACT_CLONE_PLAN_TITLE,
        CONTACT_CLONE_WAIT_TITLE,
        CONTACT_CLONE_PAUSE_TITLE,
        CONTACT_CLONE_RECHECK_COMPANY_TITLE,
        CONTACT_CLONE_RECHECK_PERSONS_TITLE,
        CONTACT_CLONE_STILL_MISSING_TITLE,
        CONTACT_CLONE_RELOAD_COMPANY_TITLE,
        CONTACT_CLONE_RELOAD_PERSONS_TITLE,
    }
)
CONTACT_CLONE_PENDING_TITLES = frozenset(
    {CONTACT_CLONE_PENDING_TITLE, CONTACT_CLONE_PENDING_FAIL_TITLE}
)
# Bounded wait when Home has a source contact but native CHI has not cloned it.
CONTACT_CLONE_MISSING_JS = """
const f = formData || {};
const want = f.is_change_operator_or_operating_company === true;
const p3 = f.part_3 || {};
const company = companyContact && companyContact.id;
const persons = Array.isArray(operatorContact)
  ? operatorContact.filter(row => row && row.id) : [];
const homeCompany = (homeCompanyContact && homeCompanyContact.id)
  || (home && home.f_home_contact_company && home.f_home_contact_company.id);
const homePersons = Array.isArray(homePersonContacts) && homePersonContacts.length
  ? homePersonContacts.filter(row => row && row.id)
  : (Array.isArray(home && home.f_home_contact_person)
    ? home.f_home_contact_person.filter(row => row && row.id) : []);
let missing = false;
if (want && p3.company && homeCompany && !company) missing = true;
if (want && p3.operator && homePersons.length
    && persons.length < homePersons.length) missing = true;
"""
CONTACT_CLONE_WAIT_PLAN_SCRIPT = (
    CONTACT_CLONE_MISSING_JS + "return {iterations: missing ? 5 : 0};"
)
CONTACT_CLONE_STILL_MISSING_SCRIPT = (
    CONTACT_CLONE_MISSING_JS + "return {missing};"
)
CHECKLIST_TEMPLATE_SELECT_TITLE = "Select changed CHI Checklist template"
CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE = "Select native CHI Checklist template"
CHECKLIST_TEMPLATE_SELECT_SCRIPT = """
const rows = Array.isArray(templates) ? templates : [];
const hasUse = (row, name) => Array.isArray(row && row.f_use_for)
  && row.f_use_for.includes(name);
const chi = rows.filter(row => hasUse(row, 't_change_home_information_app'));
const nla = rows.filter(row => hasUse(row, 't_licence_app'));
const compareId = (left, right) => {
  const a = Number(left && left.id);
  const b = Number(right && right.id);
  if (Number.isSafeInteger(a) && Number.isSafeInteger(b)) return a - b;
  return String(left && left.id).localeCompare(String(right && right.id));
};
const pool = (chi.length ? chi : nla.length ? nla : rows).slice().sort(compareId);
return pool[0] || null;
"""
# Prepared for a later disabled-draft post-loop readback. Do not insert into a
# live graph until association-aware Latest UAT proves the attachment relation.
CHECKLIST_POST_LOOP_VERIFY_SCRIPT = """
const wanted = typeof checklist !== 'undefined' && Array.isArray(checklist)
  ? checklist : [];
const catalog = typeof templates !== 'undefined' && Array.isArray(templates)
  ? templates : [];
const saved = typeof items !== 'undefined' && Array.isArray(items)
  ? items : [];
const startMs = typeof requestCreatedAt !== 'undefined'
  ? Date.parse(requestCreatedAt) : NaN;
if (wanted.length && !Number.isFinite(startMs))
  return {ready: false, block_reason: 'chi_checklist_request_time_missing'};
const latestByCode = new Map();
const detailsByCode = new Map();
for (const assignment of wanted) {
  const code = assignment && assignment.position_code;
  const attachmentId = Number(assignment && assignment.attachment_id);
  if (typeof code !== 'string' || !code ||
      !Number.isSafeInteger(attachmentId) || attachmentId <= 0)
    return {ready: false, block_reason: 'chi_checklist_invalid_assignment'};
  latestByCode.set(code, attachmentId);
  if (!detailsByCode.has(code)) detailsByCode.set(code, new Set());
  detailsByCode.get(code).add(attachmentId);
}
for (const [code, attachmentId] of latestByCode.entries()) {
  const matches = catalog.filter(row => String(row.f_position_code) === code);
  const hasUse = (row, name) => Array.isArray(row.f_use_for)
    && row.f_use_for.includes(name);
  const chi = matches.filter(row => hasUse(row, 't_change_home_information_app'));
  const nla = matches.filter(row => hasUse(row, 't_licence_app'));
  const compareId = (left, right) => {
    const a = Number(left && left.id);
    const b = Number(right && right.id);
    if (Number.isSafeInteger(a) && Number.isSafeInteger(b)) return a - b;
    return String(left && left.id).localeCompare(String(right && right.id));
  };
  const pool = (chi.length ? chi : nla.length ? nla : matches)
    .slice().sort(compareId);
  if (!pool.length)
    return {ready: false, block_reason: 'chi_checklist_template_not_resolved',
      position_code: code};
  const rows = saved.filter(row =>
    String(row.fk_document_checklist) === String(pool[0].id));
  if (rows.length !== 1)
    return {ready: false, block_reason: 'chi_checklist_record_not_unique',
      position_code: code};
  const files = rows[0].f_lastest_files;
  if (!Array.isArray(files) || !files.some(file =>
      String(file && file.id) === String(attachmentId)))
    return {ready: false, block_reason: 'chi_checklist_latest_not_saved',
      position_code: code, attachment_id: attachmentId};
  const details = rows[0].f_details;
  if (!Array.isArray(details))
    return {ready: false, block_reason: 'chi_checklist_details_not_loaded',
      position_code: code};
  for (const requiredId of detailsByCode.get(code)) {
    if (!details.some(detail =>
        String(detail && detail.fk_documests_submitted_for_application_id)
          === String(rows[0].id) &&
        Number.isFinite(Date.parse(detail && detail.createdAt)) &&
        Date.parse(detail.createdAt) >= startMs &&
        Array.isArray(detail.f_files) && detail.f_files.some(file =>
          String(file && file.id) === String(requiredId))))
      return {ready: false, block_reason: 'chi_checklist_details_not_saved',
        position_code: code, attachment_id: requiredId};
  }
}
return {ready: true, verified_count: latestByCode.size};
"""
_SAFE_POST_LOOP_HEAD = (
    "const wanted = typeof checklist !== 'undefined' && "
    "Array.isArray(checklist)\n"
    "  ? checklist : [];\n"
    "const catalog = typeof templates !== 'undefined' && "
    "Array.isArray(templates)\n"
    "  ? templates : [];\n"
    "const saved = typeof items !== 'undefined' && Array.isArray(items)\n"
    "  ? items : [];\n"
    "const startMs = typeof requestCreatedAt !== 'undefined'\n"
    "  ? Date.parse(requestCreatedAt) : NaN;"
)
_LEGACY_POST_LOOP_HEAD = """const wanted = Array.isArray(checklist) ? checklist : [];
const catalog = Array.isArray(templates) ? templates : [];
const saved = Array.isArray(items) ? items : [];
const startMs = Date.parse(requestCreatedAt);"""
LEGACY_POST_LOOP_VERIFY_SCRIPT = CHECKLIST_POST_LOOP_VERIFY_SCRIPT.replace(
    _SAFE_POST_LOOP_HEAD, _LEGACY_POST_LOOP_HEAD, 1
)
ADDRESS_PAGE_FIELDS = (
    *ADDRESS_FIELDS.values(),
    "fk_region_en",
    "fk_region_cn",
    "fk_district_name_en",
    "fk_district_name_cn",
    "fk_sub_district_en",
    "fk_sub_district_cn",
)


def projection_script() -> str:
    """Pure JavaScript normalization; never reads or writes the database."""
    markers = {
        "__FLAGS__": json.dumps(CHANGE_FLAGS),
        "__CHI_FIELDS__": json.dumps(CHI_PAGE_FIELDS),
        "__ALL_CHI_FIELDS__": json.dumps(ALL_CHI_FIELDS),
        "__LEGACY_PART2_MAP__": json.dumps(LEGACY_PART2_MAP),
        "__LEGACY_PART5_MAP__": json.dumps(LEGACY_PART5_MAP),
        "__CONTACT_MAP__": json.dumps(CONTACT_PAGE_MAP),
        "__CONTACT_FIELDS__": json.dumps(CONTACT_PAGE_FIELDS),
        "__DECLARATION_SLOTS__": json.dumps(DECLARATION_SLOTS),
        "__CONTACT_NESTED_FIELDS__": json.dumps(CONTACT_NESTED_FIELDS),
        "__ADDRESS_MAP__": json.dumps(ADDRESS_FIELDS),
        "__ADDRESS_FIELDS__": json.dumps(ADDRESS_PAGE_FIELDS),
    }
    source = r"""try {
const f = formData || {};
const applicationRow = application || {};
const homeRow = home || {};
const chiAddressRow = chiAddress || {};
const homeAddressRow = homeAddress || {};
const companyRow = companyContact || {};
const personRows = Array.isArray(operatorContact) ? operatorContact : [];
const homeCompanyRow = homeCompanyContact || {};
const homePersonRows = Array.isArray(homePersonContacts) ? homePersonContacts : [];
const p2 = f.part_2 || {};
const p3 = f.part_3 || {};
const p1 = f.part_1 || {};
const p5 = f.part_5 || {};
const templates = Array.isArray(checklistTemplates) ? checklistTemplates : [];
const uploads = Array.isArray(checklistUploads) ? checklistUploads : [];
const own = (row, field) => row && Object.prototype.hasOwnProperty.call(row, field);
const rejectUnknown = (row, allowed, label) => {
  const extras = Object.keys(row || {}).filter(name => !allowed.includes(name));
  if (extras.length)
    throw new Error(label + ' has no verified CHI page mapping: '
      + extras.join(','));
};
const copy = (row, names) => Object.fromEntries(names.map(name =>
  [name, own(row, name) ? row[name] : null]));
const project = (target, input, mapping) => {
  for (const [external, internal] of Object.entries(mapping))
    if (own(input, external)) target[internal] = input[external];
};
const flags = __FLAGS__;
const pagePatch = copy(applicationRow, __CHI_FIELDS__);
const missing = __ALL_CHI_FIELDS__.filter(name => !own(applicationRow, name));
if (missing.length) return {ready: false,
  block_reason: 'chi_current_values_not_loaded', missing_fields: missing};
const pickChecklistTemplate = (code) => {
  const rows = templates.filter(row =>
    String(row.f_position_code) === String(code));
  const hasUse = (row, name) => Array.isArray(row.f_use_for)
    && row.f_use_for.includes(name);
  const chi = rows.filter(row => hasUse(row, 't_change_home_information_app'));
  const nla = rows.filter(row => hasUse(row, 't_licence_app'));
  const compareId = (left, right) => {
    const a = Number(left && left.id);
    const b = Number(right && right.id);
    if (Number.isSafeInteger(a) && Number.isSafeInteger(b)) return a - b;
    return String(left && left.id).localeCompare(String(right && right.id));
  };
  const pool = (chi.length ? chi : nla.length ? nla : rows)
    .slice().sort(compareId);
  return pool[0] || null;
};
for (const assignment of (Array.isArray(p5.checklist) ? p5.checklist : [])) {
  if (!pickChecklistTemplate(assignment.position_code)) return {ready: false,
    block_reason: 'chi_checklist_template_not_resolved',
    position_code: assignment.position_code};
  const file = uploads.find(row =>
    String(row.id) === String(assignment.attachment_id));
  if (!file) return {ready: false,
    block_reason: 'chi_checklist_attachment_not_resolved',
    attachment_id: assignment.attachment_id};
}
const legacyPatch = copy(applicationRow, __ALL_CHI_FIELDS__);
if (Array.isArray(applicationRow.f_attachments_of_rchs))
  legacyPatch.f_attachments_of_rchs = applicationRow.f_attachments_of_rchs.map(
    value => value && value.id ? value.id : value);
for (const flag of flags) {
  if (own(f, flag)) pagePatch[flag] = f[flag];
  else if (pagePatch[flag] === null) pagePatch[flag] = false;
}
if (f.is_change_name === true) {
  if (!own(p2, 'rch_name_en') && !own(p2, 'rch_name_cn'))
    throw new Error('is_change_name requires a proposed RCH name');
  if (own(p2, 'rch_name_en')) pagePatch.f_rch_name_en = p2.rch_name_en;
  if (own(p2, 'rch_name_cn')) pagePatch.f_rch_name_cn = p2.rch_name_cn;
}
if (f.is_change_rch_type === true) {
  if (!own(p2, 'rch_type_code'))
    throw new Error('is_change_rch_type requires rch_type_code');
  const office = (f.case_summary || {}).office_code || applicationRow.f_office_cd;
  const rows = Array.isArray(rchTypeOptions) ? rchTypeOptions : [];
  const match = rows.find(row => String(row.f_code) === String(p2.rch_type_code)
    && String(row.f_for_office) === String(office));
  if (!match) throw new Error('rch_type_code is not valid for office_code');
  pagePatch.fk_type_of_rch = match.id;
}
if (f.is_change_maximum_capacity === true) {
  const hasMaximum = own(p2, 'max_capacity');
  const hasLicence = own(p2, 'licence_capacity');
  if (!hasMaximum && !hasLicence)
    throw new Error('is_change_maximum_capacity requires proposed maximum capacity');
  if (hasMaximum && hasLicence
      && Number(p2.max_capacity) !== Number(p2.licence_capacity))
    throw new Error('max_capacity and licence_capacity disagree');
  const value = Number(hasMaximum ? p2.max_capacity : p2.licence_capacity);
  if (!Number.isSafeInteger(value) || value < 1)
    throw new Error('proposed maximum capacity must be a positive integer');
  pagePatch.f_licence_capacity = value;
}
if (f.is_change_operator_or_operating_company === true) {
  if (own(p3, 'rch_business_status')) {
    if (!['0', '1'].includes(String(p3.rch_business_status)))
      throw new Error('invalid rch_business_status');
    pagePatch.f_service_type = String(p3.rch_business_status);
  }
  if (own(p3, 'applicant_operator_type')) {
    if (!['0', '1', '2', '3'].includes(String(p3.applicant_operator_type)))
      throw new Error('invalid applicant_operator_type');
    pagePatch.f_business_ownership_type = String(p3.applicant_operator_type);
  }
}
// Preserve every current field accepted by the old Staging CHI workflow;
// only properties actually supplied by the client replace it.
project(legacyPatch, p2, __LEGACY_PART2_MAP__);
project(legacyPatch, p5, __LEGACY_PART5_MAP__);
if (own(p1, 'application_received_date'))
  legacyPatch.f_application_received_date = p1.application_received_date;
if (own(p1, 'tentative_commencement_date'))
  legacyPatch.f_tentative_service_commencement_date = p1.tentative_commencement_date;
if (own(f.case_summary || {}, 'office_code'))
  legacyPatch.f_office_cd = f.case_summary.office_code;
if (own(f, 'is_aip')) legacyPatch.is_aip = f.is_aip;
for (const [field, value] of Object.entries(pagePatch)) legacyPatch[field] = value;
const result = { ready: true, page_patch: pagePatch, legacy_patch: legacyPatch,
  address_requested: false, address_id: null,
  address_patch: {}, address_ops: [], contact_updates: [],
  contact_pending: false };
const snapshotVersion = Number(applicationRow.f_source_home_snapshot_version || 0);
if (snapshotVersion < 1) {
  result.ready = false;
  result.block_reason = 'native_chi_snapshot_incomplete';
  return result;
}
if (!applicationRow.id || String(applicationRow.fk_home_record) !== String(homeRow.id))
  throw new Error('CHI application is not linked to the resolved Home Record');
if (f.is_change_address === true) {
  if (!p2.address || !Object.keys(p2.address).length)
    throw new Error('is_change_address requires a proposed address');
  if (!applicationRow.fk_rch_address || !chiAddressRow.id
      || String(applicationRow.fk_rch_address) !== String(chiAddressRow.id)
      || String(chiAddressRow.id) === String(homeRow.fk_rch_address)
      || String(chiAddressRow.id) === String(homeAddressRow.id))
    throw new Error('Home Record address write refused');
  const missingAddress = __ADDRESS_FIELDS__.filter(name => !own(chiAddressRow, name));
  if (missingAddress.length) {
    result.ready = false;
    result.block_reason = 'chi_address_current_values_not_loaded';
    result.missing_fields = missingAddress;
    return result;
  }
  const addressPatch = copy(chiAddressRow, __ADDRESS_FIELDS__);
  rejectUnknown(p2.address,
    [...Object.keys(__ADDRESS_MAP__), 'region_code', 'district_code',
      'sub_district_code'], 'part_2.address');
  project(addressPatch, p2.address, __ADDRESS_MAP__);
  if (own(p2.address, 'region_code')) {
    const rows = Array.isArray(addressOptions) ? addressOptions : [];
    const region = rows.find(row =>
      String(row.f_code) === String(p2.address.region_code));
    const district = rows.find(row =>
      String(row.f_code) === String(p2.address.district_code)
      && region && String(row.parentId) === String(region.id));
    const sub = rows.find(row =>
      String(row.f_code) === String(p2.address.sub_district_code)
      && district && String(row.parentId) === String(district.id));
    if (!region || !district || !sub)
      throw new Error('invalid region/district/sub-district code hierarchy');
    Object.assign(addressPatch, {
      fk_region_en: region.f_name_en, fk_region_cn: region.f_name_cn,
      fk_district_name_en: district.f_name_en, fk_district_name_cn: district.f_name_cn,
      fk_sub_district_en: sub.f_name_en, fk_sub_district_cn: sub.f_name_cn,
    });
  }
  result.address_requested = true;
  result.address_id = chiAddressRow.id;
  result.address_patch = addressPatch;
  result.address_ops = [{id: chiAddressRow.id, patch: addressPatch}];
}
const contact = (incoming, current, source, sourceFull, foreignKey) => {
  if (!incoming) return;
  rejectUnknown(incoming,
    [...Object.keys(__CONTACT_MAP__), 'id', 'address', 'trust_no',
      'registration_identifier_types', 'legislation_chapter_no',
      'declaration_answers'], 'part_3 contact');
  if (incoming.address || own(incoming, 'trust_no'))
    throw new Error('unsupported CHI contact field; no verified storage projection');
  const linked = current && current.id ? current : null;
  const sourceIds = (Array.isArray(source) ? source : [source]).filter(Boolean)
    .map(row => String(row.id));
  const sourceRows = (Array.isArray(sourceFull) ? sourceFull : [sourceFull])
    .filter(row => row && row.id);
  const sourceLoaded = sourceIds.every(id =>
    sourceRows.some(row => String(row.id) === id));
  const hasNested = own(incoming, 'registration_identifier_types')
    || own(incoming, 'legislation_chapter_no')
    || own(incoming, 'declaration_answers');
  if (hasNested && sourceIds.length && !sourceLoaded) {
    result.ready = false;
    result.block_reason = 'home_contact_child_provenance_not_loaded';
    return;
  }
  if (linked && (String(linked[foreignKey]) !== String(applicationRow.id)
      || sourceIds.includes(String(linked.id))))
    throw new Error('Home Record contact write refused');
  if (!linked && sourceIds.length) {
    result.ready = false;
    result.contact_pending = true;
    result.block_reason = 'native_chi_contact_clone_incomplete';
    return;
  }
  if (own(incoming, 'id') && (!linked || String(incoming.id) !== String(linked.id)))
    throw new Error('contact id is not linked to this CHI');
  if (linked) {
    const missingContact = __CONTACT_FIELDS__.filter(name => !own(linked, name));
    if (missingContact.length) {
      result.ready = false;
      result.block_reason = 'chi_contact_current_values_not_loaded';
      result.missing_fields = missingContact;
      return;
    }
    if (hasNested && __CONTACT_NESTED_FIELDS__.some(name => !own(linked, name))) {
      result.ready = false;
      result.block_reason = 'chi_contact_child_provenance_not_loaded';
      return;
    }
  }
  const patch = copy(linked || {}, __CONTACT_FIELDS__);
  project(patch, incoming, __CONTACT_MAP__);
  patch[foreignKey] = applicationRow.id;
  const update = {id: linked ? linked.id : 0,
    kind: foreignKey === 'fk_licence_contact_company' ? 'company' : 'person',
    patch,
    registration_ops: [], declaration_ops: {}};
  for (const slot of __DECLARATION_SLOTS__)
    update.declaration_ops[String(slot)] = [];
  if (own(incoming, 'registration_identifier_types')
      || own(incoming, 'legislation_chapter_no')) {
    if (foreignKey !== 'fk_licence_contact_company')
      throw new Error('registration identifier is only supported on CHI company');
    const childRows = linked && Array.isArray(linked.f_rpop_op_app)
      ? linked.f_rpop_op_app.filter(Boolean) : [];
    const sourceChildIds = sourceRows.flatMap(row =>
      Array.isArray(row.f_rpop_op_app)
        ? row.f_rpop_op_app.map(child => String(child.id)) : []);
    if (childRows.length > 1)
      throw new Error('CHI company has multiple registration child rows');
    const child = childRows[0] || null;
    if (child && (String(child.fk_licence_contact) !== String(linked.id)
        || sourceChildIds.includes(String(child.id))))
      throw new Error('Home Record registration child write refused');
    if (!child && sourceChildIds.length) {
      result.ready = false;
      result.contact_pending = true;
      result.block_reason = 'native_chi_registration_child_clone_incomplete';
      return;
    }
    const registration = {
      f_company_registration_identifier_types: child
        ? (Array.isArray(child.f_company_registration_identifier_types)
          ? child.f_company_registration_identifier_types.map(String)
          : child.f_company_registration_identifier_types == null ? []
          : [String(child.f_company_registration_identifier_types)]) : [],
      f_legislation_chapter_no: child ? child.f_legislation_chapter_no : null,
    };
    if (own(incoming, 'registration_identifier_types'))
      {
        const selected = incoming.registration_identifier_types;
        if (!Array.isArray(selected) || selected.length !== 1
            || !['0', '1', '2'].includes(String(selected[0])))
          throw new Error('registration_identifier_types requires one radio value');
        registration.f_company_registration_identifier_types =
          selected.map(String);
      }
    if (own(incoming, 'legislation_chapter_no'))
      registration.f_legislation_chapter_no = incoming.legislation_chapter_no;
    if (linked) update.registration_ops.push({
      id: child ? child.id : 0, contact_id: linked.id, patch: registration,
    });
    else patch.f_rpop_op_app = [registration];
  }
  if (own(incoming, 'declaration_answers')) {
    const answers = incoming.declaration_answers || {};
    for (const [rawSlot, answer] of Object.entries(answers)) {
      const slot = Number(rawSlot);
      if (!__DECLARATION_SLOTS__.includes(slot) || !['Yes', 'No'].includes(answer))
        throw new Error('invalid CHI declaration slot or answer');
      const field = 'f_rpop_app_detail_' + slot;
      const existing = linked ? linked[field] : null;
      const sourceDetailIds = sourceRows.map(row => row[field])
        .filter(row => row && row.id).map(row => String(row.id));
      if (existing && sourceDetailIds.includes(String(existing.id)))
        throw new Error('Home Record declaration child write refused');
      if (!existing && sourceDetailIds.length) {
        result.ready = false;
        result.contact_pending = true;
        result.block_reason = 'native_chi_declaration_child_clone_incomplete';
        return;
      }
      if (linked) update.declaration_ops[rawSlot].push({
        id: existing ? existing.id : 0,
        contact_id: linked.id, answer,
      });
      else patch[field] = {f_declaration_answer: answer};
    }
  }
  if (!linked) {
    if (!own(patch, 'f_rpop_op_app')) patch.f_rpop_op_app = [];
    for (const slot of __DECLARATION_SLOTS__) {
      const field = 'f_rpop_app_detail_' + slot;
      if (!own(patch, field)) patch[field] = null;
    }
  }
  result.contact_updates.push(update);
};
if (f.is_change_operator_or_operating_company === true) {
  if (!p3.operator && !p3.company
      && !own(p3, 'rch_business_status')
      && !own(p3, 'applicant_operator_type'))
    throw new Error('operator/company change requires a proposed popup field');
  if (p3.operator && p3.company)
    throw new Error('personal operator and company branches cannot be combined');
  const selectedType = own(p3, 'applicant_operator_type')
    ? String(p3.applicant_operator_type)
    : String(applicationRow.f_business_ownership_type);
  if (p3.operator) {
    if (!['0', '1'].includes(selectedType))
      throw new Error('personal operator requires applicant_operator_type 0 or 1');
    const requestedId = own(p3.operator, 'id') ? String(p3.operator.id) : '';
    const sourcePersonCount = Array.isArray(homeRow.f_home_contact_person)
      ? homeRow.f_home_contact_person.filter(row => row && row.id).length : 0;
    if (sourcePersonCount && personRows.length < sourcePersonCount) {
      result.ready = false;
      result.contact_pending = true;
      result.block_reason = 'native_chi_person_contact_clone_incomplete';
      return result;
    }
    const current = requestedId
      ? personRows.find(row => String(row.id) === requestedId)
      : personRows.length === 1 ? personRows[0] : null;
    if (!requestedId && personRows.length > 1)
      throw new Error('operator.id is required when CHI has multiple persons');
    if (!current && (homeRow.f_home_contact_person || []).length) {
      result.ready = false;
      result.contact_pending = true;
      result.block_reason = 'native_chi_person_contact_clone_incomplete';
      return result;
    }
    contact(p3.operator, current, homeRow.f_home_contact_person || [],
      homePersonRows,
      'fk_licence_contact_person');
  }
  if (p3.company && !['2', '3'].includes(selectedType))
    throw new Error('company requires applicant_operator_type 2 or 3');
  contact(p3.company, companyRow, homeRow.f_home_contact_company,
    homeCompanyRow,
    'fk_licence_contact_company');
}
return result;
} catch (error) {
  return {ready: false, block_reason: String(error && error.message || error)};
}"""
    for marker, value in markers.items():
        source = source.replace(marker, value)
    return source


def source_summary(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for title, event, api_type in (
        (CREATE_TITLE, "CREATE", CREATE_API_TYPE),
        (UPDATE_TITLE, "UPDATE", UPDATE_API_TYPE),
    ):
        query = urllib.parse.urlencode({"filter[title]": title, "pageSize": 100})
        rows = api.request("GET", "/api/workflows:list?" + query) or []
        enabled = [
            row for row in rows if row.get("title") == title and row.get("enabled")
        ]
        if len(enabled) != 1:
            raise ApiError(
                f"Expected exactly one enabled CHI staging workflow: {title}"
            )
        workflow = api.get_workflow(int(enabled[0]["id"]))
        expected = expected_trigger_config(event=event, api_type=api_type)
        if (
            workflow.get("type") != "collection"
            or workflow.get("sync") is not False
            or (workflow.get("config") or {}) != expected
        ):
            raise ApiError("CHI source trigger differs from exact one-shot contract")
        result.append(workflow)
    return result


def expected_trigger_config(*, event: str, api_type: str) -> dict[str, Any]:
    """Return the only trigger shape safe for one-shot CHI Staging intake."""
    return {
        "mode": 1,
        "appends": [],
        "changed": [],
        "collection": "t_api_request_staging",
        "condition": {
            "$and": [
                {"f_status": {"$eq": "submitted"}},
                {"f_source_system": {"$ne": "CMTF"}},
                {"f_request_event": {"$eq": event}},
                {"f_api_type": {"$eq": api_type}},
            ]
        },
    }


def expected_chi_trigger_config(*, updating: bool) -> dict[str, Any]:
    return expected_trigger_config(
        event="UPDATE" if updating else "CREATE",
        api_type=UPDATE_API_TYPE if updating else CREATE_API_TYPE,
    )


def has_expected_chi_trigger(
    workflow: Mapping[str, Any], *, updating: bool
) -> bool:
    return (
        workflow.get("type") == "collection"
        and workflow.get("sync") is False
        and (workflow.get("config") or {})
        == expected_chi_trigger_config(updating=updating)
    )


def ensure_parent_staging_field(
    api: RootNocoBaseApi, *, create_if_missing: bool
) -> dict[str, Any]:
    """Verify the integration-only durable UPDATE queue parent key.

    This never edits a native Intake/CHI/Home collection. Existing fields with
    an incompatible schema fail closed rather than being overwritten.
    """
    path = "/api/collections/t_api_request_staging/fields:list?pageSize=400"
    rows = api.request("GET", path) or []
    matching = [row for row in rows if row.get("name") == "f_parent_create_id"]
    if not matching and create_if_missing:
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:create",
            {
                "name": "f_parent_create_id",
                "type": "string",
                "interface": "input",
                "uiSchema": {
                    "type": "string",
                    "title": "Original Create ID",
                    "x-component": "Input",
                },
            },
        )
        rows = api.request("GET", path) or []
        matching = [row for row in rows if row.get("name") == "f_parent_create_id"]
    if len(matching) != 1:
        raise ApiError("Staging f_parent_create_id is missing or ambiguous")
    field = matching[0]
    if field.get("type") != "string" or field.get("interface") != "input":
        raise ApiError("Staging f_parent_create_id conflicts with queue schema")
    return field


def ensure_staging_error_field(
    api: RootNocoBaseApi, *, create_if_missing: bool
) -> dict[str, Any]:
    """Persist the CHI Staging failure reason for operators and Query."""
    path = "/api/collections/t_api_request_staging/fields:list?pageSize=400"
    rows = api.request("GET", path) or []
    matching = [row for row in rows if row.get("name") == "f_error_message"]
    if not matching and create_if_missing:
        api.request(
            "POST",
            "/api/collections/t_api_request_staging/fields:create",
            {
                "name": "f_error_message",
                "type": "text",
                "interface": "textarea",
                "uiSchema": {
                    "type": "string",
                    "title": "API Staging Error",
                    "x-component": "Input.TextArea",
                },
            },
        )
        rows = api.request("GET", path) or []
        matching = [row for row in rows if row.get("name") == "f_error_message"]
    if len(matching) != 1:
        raise ApiError("Staging f_error_message is missing or ambiguous")
    field = matching[0]
    if field.get("type") not in {"text", "string"}:
        raise ApiError("Staging f_error_message conflicts with error schema")
    return field


def staging_failed_values(message: str, **extra: Any) -> dict[str, Any]:
    values = {"f_status": "failed", "f_error_message": message}
    values.update(extra)
    return values


def ensure_intake_create_marker_field(
    api: RootNocoBaseApi, *, create_if_missing: bool
) -> dict[str, Any]:
    """Add only a hidden integration provenance field to Intake metadata.

    The field is not placed on a business page and no native Intake workflow is
    edited. Writing the Staging ID in the Intake Create values is atomic with
    Intake creation, preventing the CHI Created bridge from misclassifying an
    OP application while its asynchronous Staging backfill is pending.
    """
    path = "/api/collections/t_intake_form/fields:list?pageSize=400"
    rows = api.request("GET", path) or []
    matching = [row for row in rows if row.get("name") == "f_api_create_staging_id"]
    if not matching and create_if_missing:
        api.request(
            "POST",
            "/api/collections/t_intake_form/fields:create",
            {
                "name": "f_api_create_staging_id",
                "type": "string",
                "interface": "input",
                "uiSchema": {
                    "type": "string",
                    "title": "API Create Staging ID",
                    "x-component": "Input",
                },
            },
        )
        rows = api.request("GET", path) or []
        matching = [row for row in rows if row.get("name") == "f_api_create_staging_id"]
    if len(matching) != 1:
        raise ApiError("Intake f_api_create_staging_id is missing or ambiguous")
    field = matching[0]
    if field.get("type") != "string" or field.get("interface") != "input":
        raise ApiError("Intake API Create marker conflicts with provenance schema")
    return field


def draft_revision(api: RootNocoBaseApi, source: dict[str, Any]) -> dict[str, Any]:
    """Create an editable disabled revision; restore the original immediately.

    NocoBase's revision API requires the old revision to be disabled first.
    The old revision is reenabled in ``finally`` before any graph changes are
    attempted, so the potentially lengthy build runs against an inactive copy.
    Never call this on a native CHI workflow or an arbitrary workflow key.
    """
    old_id = int(source["id"])
    if source.get("title") not in (CREATE_TITLE, UPDATE_TITLE) or not source.get("key"):
        raise ApiError("Only the two named CHI Staging workflows may be revised")
    updating = source.get("title") == UPDATE_TITLE
    if not source.get("enabled") or not has_expected_chi_trigger(
        source, updating=updating
    ):
        raise ApiError("CHI Staging source trigger is not the exact safe contract")
    revision_id: int | None = None
    api.request(
        "POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": False}
    )
    try:
        query = urllib.parse.urlencode(
            {"filterByTk": old_id, "filter[key]": str(source["key"])}
        )
        created = api.request("POST", f"/api/workflows:revision?{query}", {})
        if not isinstance(created, dict) or not created.get("id"):
            raise ApiError("CHI Staging revision returned no ID")
        revision_id = int(created["id"])
    finally:
        api.request(
            "POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": True}
        )
    restored = api.get_workflow(old_id)
    if not restored.get("enabled"):
        raise ApiError("Original CHI Staging workflow was not restored")
    if revision_id is None:
        raise ApiError("No CHI Staging revision was created")
    draft = api.get_workflow(revision_id)
    if (
        draft.get("enabled")
        or draft.get("executed")
        or draft.get("key") != source.get("key")
        or draft.get("title") != source.get("title")
        or not has_expected_chi_trigger(draft, updating=updating)
    ):
        raise ApiError("Disabled CHI Staging draft readback failed")
    return draft


def validate_revision_graph(workflow: dict[str, Any], *, updating: bool) -> None:
    """Fail closed on wrong ownership/write targets before any activation."""
    if workflow.get("enabled") or workflow.get("executed"):
        raise ApiError("CHI Staging revision must remain disabled and editable")
    if not has_expected_chi_trigger(workflow, updating=updating):
        raise ApiError("CHI revision trigger differs from exact one-shot contract")
    nodes = workflow.get("nodes") or []
    titles = [str(row.get("title")) for row in nodes]
    if len(titles) != len(set(titles)):
        raise ApiError("CHI Staging revision has duplicate node titles")
    required = {
        "Project guarded CHI page changes",
        "CHI snapshot and owner guards pass",
        "Mark guarded CHI staging failed",
        "Update CHI-owned address only",
        "Apply CHI-owned proposed contacts",
        "Create CHI Checklist upload Details",
        "Create new CHI Checklist upload Details",
        "Refresh existing CHI Latest",
        "Refresh new CHI Latest",
        "Apply existing CHI company registration child",
        "Update CHI company registration child",
        "Create CHI company registration child",
        "Apply CHI declaration answer 1",
        "Apply CHI declaration answer 10",
        "Preflight CHI Checklist templates",
        "Preflight CHI Checklist upload IDs",
        CHECKLIST_INPUT_VALIDATE_TITLE,
        CHECKLIST_INPUT_VALID_TITLE,
        CHECKLIST_INPUT_FAIL_TITLE,
        CHECKLIST_PREFLIGHT_TITLE,
        "Mark CHI Checklist code failed",
        "Mark CHI Checklist upload failed",
        "Reload CHI staging after Checklist",
        "CHI Checklist and projection succeeded",
        "Reload CHI Checklist associations after upload",
        "Verify CHI Checklist Latest and Details",
        "CHI Checklist associations saved",
        "Mark CHI Checklist association failed",
        CONTACT_CLONE_PLAN_TITLE,
        CONTACT_CLONE_WAIT_TITLE,
        CONTACT_CLONE_PAUSE_TITLE,
        CONTACT_CLONE_RECHECK_COMPANY_TITLE,
        CONTACT_CLONE_RECHECK_PERSONS_TITLE,
        CONTACT_CLONE_STILL_MISSING_TITLE,
        CONTACT_CLONE_RELOAD_COMPANY_TITLE,
        CONTACT_CLONE_RELOAD_PERSONS_TITLE,
        CONTACT_CLONE_PENDING_TITLE,
        CONTACT_CLONE_PENDING_FAIL_TITLE,
        SNAPSHOT_PLAN_TITLE,
        SNAPSHOT_WAIT_TITLE,
        SNAPSHOT_PAUSE_TITLE,
        SNAPSHOT_RECHECK_TITLE,
        SNAPSHOT_PENDING_TITLE,
    }
    if updating:
        required |= {
            "Apply staged CHI update overlay",
            "Apply changed CHI Checklist files",
            "Verify CHI Update parent create ID",
            "CHI Update parent key valid",
            "Mark CHI Update missing parent failed",
            "Find lower pending CHI Update",
            "Plan bounded CHI Update queue",
            "Wait for earlier CHI Update to finish",
            "Pause between CHI Update queue checks",
            "Recheck lower pending CHI Update",
            "Final lower pending CHI Update check",
            "CHI Update queue clear",
            "Mark CHI Update queue timeout failed",
            CHECKLIST_TEMPLATE_SELECT_TITLE,
        }
    else:
        required |= {
            "Apply staged flags and overlay to native CHI",
            "Apply Checklist files to native CHI records",
            "Wait briefly for native CHI creation",
            "Backfill OP CHI Intake ID before bridge",
            CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE,
        }
    if not required.issubset(titles):
        raise ApiError(
            "CHI Staging revision graph is incomplete: "
            + ",".join(sorted(required - set(titles)))
        )
    for row in nodes:
        if row.get("type") in ("create", "update", "destroy"):
            collection = (row.get("config") or {}).get("collection")
            if collection in ("t_home_record", "t_home_record_base", "t_home_contact"):
                raise ApiError("Home Record write node is forbidden in CHI Staging")
    overlay_title = (
        "Apply staged CHI update overlay"
        if updating
        else "Apply staged flags and overlay to native CHI"
    )
    overlay = node_by_title(workflow, overlay_title)
    values = ((overlay.get("config") or {}).get("params") or {}).get("values") or {}
    if set(values) != set(ALL_CHI_FIELDS) or not all(
        "legacy_patch." in str(value) for value in values.values()
    ):
        raise ApiError("CHI overlay does not preserve every previously accepted field")
    ready = node_by_title(workflow, "CHI snapshot and owner guards pass")
    normalize = node_by_title(workflow, "Project guarded CHI page changes")
    if (normalize.get("config") or {}).get("content") != projection_script():
        raise ApiError("CHI projection does not fail closed on incomplete clones")
    application = node_by_title(
        workflow, "Resolve linked CHI" if updating else "Find native-created CHI"
    )
    exists = node_by_title(
        workflow, "Linked CHI exists" if updating else "Native CHI exists"
    )
    snapshot_plan = node_by_title(workflow, SNAPSHOT_PLAN_TITLE)
    snapshot_wait = node_by_title(workflow, SNAPSHOT_WAIT_TITLE)
    snapshot_pause = node_by_title(workflow, SNAPSHOT_PAUSE_TITLE)
    snapshot_recheck = node_by_title(workflow, SNAPSHOT_RECHECK_TITLE)
    snapshot_pending = node_by_title(workflow, SNAPSHOT_PENDING_TITLE)
    snapshot = node_by_title(workflow, "Reload CHI after native snapshot")
    expected_snapshot_query = query_config(
        "t_change_home_information_app",
        [{"id": {"$eq": ref(application, "id")}}],
        appends=(
            "f_attachments_of_rchs",
            "f_licence_contact_company",
            "f_licence_contact_person",
        ),
    )
    if (
        snapshot_plan.get("upstreamId") != exists["id"]
        or snapshot_plan.get("branchIndex") != 1
        or (snapshot_plan.get("config") or {}).get("content")
        != SNAPSHOT_WAIT_PLAN_SCRIPT
        or (snapshot_plan.get("config") or {}).get("arguments")
        != [{"name": "application", "value": ref(application)}]
        or snapshot_wait.get("upstreamId") != snapshot_plan["id"]
        or (snapshot_wait.get("config") or {}).get("target")
        != ref(snapshot_plan, "iterations")
        or (snapshot_wait.get("config") or {}).get("condition", {}).get(
            "checkpoint"
        )
        != 1
        or snapshot_pause.get("upstreamId") != snapshot_wait["id"]
        or snapshot_pause.get("branchIndex") != 0
        or snapshot_recheck.get("upstreamId") != snapshot_pause["id"]
        or snapshot_recheck.get("config") != expected_snapshot_query
        or snapshot_pending.get("upstreamId") != snapshot_recheck["id"]
        or (snapshot_pending.get("config") or {}).get("content")
        != SNAPSHOT_STILL_PENDING_SCRIPT
        or (snapshot_pending.get("config") or {}).get("arguments")
        != [{"name": "application", "value": ref(snapshot_recheck)}]
        or snapshot.get("upstreamId") != snapshot_wait["id"]
        or snapshot.get("config") != expected_snapshot_query
    ):
        raise ApiError("CHI native snapshot completion gate is incomplete")
    uploads = node_by_title(workflow, "Preflight CHI Checklist upload IDs")
    if normalize.get("upstreamId") != uploads["id"]:
        raise ApiError("CHI Checklist preflight is not before scalar overlay")
    catalog = node_by_title(workflow, "Preflight CHI Checklist templates")
    plan = node_by_title(workflow, CHECKLIST_PREFLIGHT_TITLE)
    person_source = node_by_title(
        workflow, "Load Home person child IDs for provenance"
    )
    reload_persons = node_by_title(workflow, CONTACT_CLONE_RELOAD_PERSONS_TITLE)
    reload_company = node_by_title(workflow, CONTACT_CLONE_RELOAD_COMPANY_TITLE)
    wait_loop = node_by_title(workflow, CONTACT_CLONE_WAIT_TITLE)
    clone_plan = node_by_title(workflow, CONTACT_CLONE_PLAN_TITLE)
    if (
        clone_plan.get("upstreamId") != person_source["id"]
        or wait_loop.get("upstreamId") != clone_plan["id"]
        or reload_company.get("upstreamId") != wait_loop["id"]
        or reload_persons.get("upstreamId") != reload_company["id"]
        or plan.get("upstreamId") != reload_persons["id"]
        or catalog.get("upstreamId") != plan["id"]
        or uploads.get("upstreamId") != catalog["id"]
        or (plan.get("config") or {}).get("content")
        != CHECKLIST_PREFLIGHT_SCRIPT
        or (clone_plan.get("config") or {}).get("content")
        != CONTACT_CLONE_WAIT_PLAN_SCRIPT
        or (wait_loop.get("config") or {}).get("target")
        != ref(clone_plan, "iterations")
        or (wait_loop.get("config") or {}).get("condition", {}).get("checkpoint")
        != 1
    ):
        raise ApiError("CHI Checklist preflight ID plan is not before queries")
    plan_arguments = (plan.get("config") or {}).get("arguments") or []
    parse = node_by_title(
        workflow,
        "Parse staged CHI update body"
        if updating else "Parse staged CHI request body",
    )
    input_validate = node_by_title(workflow, CHECKLIST_INPUT_VALIDATE_TITLE)
    input_valid = node_by_title(workflow, CHECKLIST_INPUT_VALID_TITLE)
    input_failed = node_by_title(workflow, CHECKLIST_INPUT_FAIL_TITLE)
    first_business_path = node_by_title(
        workflow,
        "Resolve original CREATE staging record"
        if updating
        else (
            "Resolve business submitter and post"
            if "Resolve business submitter and post" in titles
            else "Create Intake (fixed CHI type + Home Record)"
        ),
    )
    expected_input_validate = {
        "arguments": [{"name": "checklist", "value": ref(parse, "checklist")}],
        "content": CHECKLIST_INPUT_VALIDATION_SCRIPT,
        "timeout": 3000,
        "continue": False,
    }
    if (
        parse.get("downstreamId") != input_validate["id"]
        or input_validate.get("upstreamId") != parse["id"]
        or input_validate.get("config") != expected_input_validate
        or input_validate.get("downstreamId") != input_valid["id"]
        or input_valid.get("upstreamId") != input_validate["id"]
        or input_valid.get("config")
        != truth_condition(ref(input_validate, "ready"))
        or input_failed.get("upstreamId") != input_valid["id"]
        or input_failed.get("branchIndex") != 0
        or input_failed.get("config")
        != update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values(ref(input_validate, "block_reason")),
        )
        or first_business_path.get("upstreamId") != input_valid["id"]
        or first_business_path.get("branchIndex") != 1
    ):
        raise ApiError("CHI Checklist input guard is not before business writes")
    if plan_arguments != [{"name": "checklist", "value": ref(parse, "checklist")}]:
        raise ApiError("CHI Checklist preflight plan cannot read parsed items")
    company_full = node_by_title(workflow, "Load CHI company child records")
    if (company_full.get("config") or {}) != chi_owned_company_query(snapshot):
        raise ApiError("CHI company clone is not queried by application id")
    projection_args = {
        item.get("name"): item.get("value")
        for item in (normalize.get("config") or {}).get("arguments") or []
    }
    if (
        projection_args.get("companyContact") != ref(reload_company)
        or projection_args.get("operatorContact") != ref(reload_persons)
    ):
        raise ApiError("CHI overlay does not use post-wait contact clones")
    catalog_filters = ((catalog.get("config") or {}).get("params") or {}).get(
        "filter", {}
    )
    if {"f_position_code": {"$in": ref(plan, "position_codes")}} not in (
        catalog_filters.get("$and") or []
    ):
        raise ApiError("CHI Checklist preflight uses an undefined position list")
    upload_filters = (
        ((uploads.get("config") or {}).get("params") or {}).get("filter") or {}
    ).get("$and") or []
    if {"id": {"$in": ref(plan, "attachment_ids")}} not in upload_filters:
        raise ApiError("CHI Checklist preflight uses an undefined attachment list")
    if {"f_office_code": {"$eq": ref(
        node_by_title(workflow, "Reload CHI after native snapshot"), "f_office_cd"
    )}} not in catalog_filters.get("$and", []):
        raise ApiError("CHI Checklist preflight is not office-scoped")
    if not updating:
        native_create = node_by_title(workflow, "Find native-created CHI")
        first_wait = node_by_title(workflow, "Wait briefly for native CHI creation")
        intake_create = node_by_title(
            workflow, "Create Intake (fixed CHI type + Home Record)"
        )
        intake_values = ((intake_create.get("config") or {}).get("params") or {}).get(
            "values"
        ) or {}
        if intake_values.get("f_api_create_staging_id") != "{{$context.data.id}}":
            raise ApiError("OP CHI Intake lacks atomic CREATE Staging provenance")
        early = node_by_title(workflow, "Backfill OP CHI Intake ID before bridge")
        submitter_post = node_by_title(workflow, "Apply submitter post to Intake")
        if (
            early.get("upstreamId") != intake_create["id"]
            or submitter_post.get("upstreamId") != early["id"]
            or (early.get("config", {}).get("params") or {}).get("values")
            != {"f_intake_id": ref(intake_create, "id")}
        ):
            raise ApiError("OP CHI Intake ID is not backfilled before native bridge")
        if native_create.get("upstreamId") != first_wait["id"]:
            raise ApiError("CHI lookup can race the native Intake create workflow")
        checklist_loop = node_by_title(
            workflow, "Apply Checklist files to native CHI records"
        )
        template_candidates = node_by_title(
            workflow, "Resolve checklist template by position_code"
        )
        template = node_by_title(workflow, CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE)
        item = node_by_title(workflow, "Find native CHI checklist item")
        create_item = node_by_title(workflow, "Create CHI checklist item + files")
        expected_item = query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(snapshot, "id")}},
                {"fk_document_checklist": {"$eq": ref(template, "id")}},
                {"f_business_type": {"$eq": "t_change_home_information_app"}},
            ],
        )
        create_values = ((create_item.get("config") or {}).get("params") or {}).get(
            "values"
        ) or {}
        if (
            template_candidates.get("upstreamId") != checklist_loop["id"]
            or template_candidates.get("branchIndex") != 0
            or template_candidates.get("config")
            != checklist_template_candidates_config(checklist_loop, snapshot)
            or template.get("upstreamId") != template_candidates["id"]
            or (template.get("config") or {}).get("arguments")
            != [{"name": "templates", "value": ref(template_candidates)}]
            or (template.get("config") or {}).get("content")
            != CHECKLIST_TEMPLATE_SELECT_SCRIPT
            or item.get("config") != expected_item
            or create_values.get("fk_document_checklist") != ref(template, "id")
        ):
            raise ApiError("CHI Create Checklist template choice is not deterministic")
    else:
        original = node_by_title(workflow, "Resolve original CREATE staging record")
        parent_check = node_by_title(workflow, "Verify CHI Update parent create ID")
        parent_filters = (
            (original.get("config") or {}).get("params") or {}
        ).get("filter") or {}
        if not any(
            item == {"f_application_status": {"$eq": "Accepted"}}
            for item in parent_filters.get("$and") or []
        ):
            raise ApiError("CHI Update parent Query does not accept Accepted CREATE")
        if (parent_check.get("config") or {}).get("content") != (
            SAFE_PARENT_CREATE_ID_SCRIPT
        ):
            raise ApiError("CHI Update parent Script can strand a missing CREATE")
        first_pending = node_by_title(workflow, "Find lower pending CHI Update")
        repeat_pending = node_by_title(workflow, "Recheck lower pending CHI Update")
        final_pending = node_by_title(workflow, "Final lower pending CHI Update check")
        queue = node_by_title(workflow, "Wait for earlier CHI Update to finish")
        queue_clear = node_by_title(workflow, "CHI Update queue clear")
        linked = node_by_title(workflow, "Resolve linked CHI")
        if parent_check.get("upstreamId") != original["id"]:
            raise ApiError("CHI Update parent key guard is not first")
        if linked.get("upstreamId") != queue_clear["id"] or linked.get(
            "branchIndex"
        ) != 1:
            raise ApiError("CHI Update may read a stale application before queue")
        if final_pending.get("upstreamId") != queue["id"]:
            raise ApiError("CHI Update queue final check missing")
        if queue.get("config", {}).get("target") != ref(
            node_by_title(workflow, "Plan bounded CHI Update queue"), "iterations"
        ):
            raise ApiError("CHI Update queue is not bounded")
        if (queue.get("config", {}).get("condition") or {}).get(
            "checkpoint"
        ) != 1:
            raise ApiError("CHI Update queue does not poll after each wait")
        expected_filter = {
            "$and": [
                {
                    "f_parent_create_id": {
                        "$eq": "{{$context.data.f_parent_create_id}}"
                    }
                },
                {"f_request_event": {"$eq": "UPDATE"}},
                {"id": {"$lt": "{{$context.data.id}}"}},
                {"f_status": {"$in": ["submitted", "processing"]}},
            ]
        }
        for row in (first_pending, repeat_pending, final_pending):
            if (row.get("config", {}).get("params") or {}).get(
                "filter"
            ) != expected_filter:
                raise ApiError("CHI Update queue must scope to lower active parent IDs")
        for title in (
            "Mark CHI Update missing parent failed",
            "Mark CHI Update queue timeout failed",
        ):
            failed_queue = node_by_title(workflow, title)
            if (failed_queue.get("config", {}).get("params") or {}).get(
                "values"
            ) != {"f_status": "failed"}:
                raise ApiError("CHI Update queue failure may not write business data")
        checklist_loop = node_by_title(workflow, "Apply changed CHI Checklist files")
        template_candidates = node_by_title(
            workflow, "Resolve changed CHI Checklist position_code"
        )
        template = node_by_title(workflow, CHECKLIST_TEMPLATE_SELECT_TITLE)
        expected_candidates = checklist_template_candidates_config(
            checklist_loop, snapshot
        )
        if (
            template_candidates.get("upstreamId") != checklist_loop["id"]
            or template_candidates.get("branchIndex") != 0
            or template_candidates.get("config") != expected_candidates
            or template.get("upstreamId") != template_candidates["id"]
            or (template.get("config") or {}).get("arguments")
            != [{"name": "templates", "value": ref(template_candidates)}]
            or (template.get("config") or {}).get("content")
            != CHECKLIST_TEMPLATE_SELECT_SCRIPT
        ):
            raise ApiError("CHI Update Checklist template choice is not deterministic")
    failed = node_by_title(workflow, "Mark guarded CHI staging failed")
    failed_values = ((failed.get("config") or {}).get("params") or {}).get(
        "values"
    ) or {}
    if (
        overlay.get("upstreamId") != ready["id"]
        or overlay.get("branchIndex") != 1
        or failed.get("upstreamId") != ready["id"]
        or failed.get("branchIndex") != 0
        or failed_values.get("f_status") != "failed"
        or failed_values.get("f_error_message") != ref(normalize, "block_reason")
    ):
        raise ApiError("CHI ownership guard can be bypassed")
    for detail_title, latest_title in (
        ("Create CHI Checklist upload Details", "Refresh existing CHI Latest"),
        ("Create new CHI Checklist upload Details", "Refresh new CHI Latest"),
    ):
        detail = node_by_title(workflow, detail_title)
        latest = node_by_title(workflow, latest_title)
        if latest.get("upstreamId") != detail["id"]:
            raise ApiError("CHI Checklist Latest precedes Details upload record")
        params = (latest.get("config") or {}).get("params") or {}
        if (
            (latest.get("config") or {}).get("collection")
            != "t_document_submitted_for_application"
            or params.get("individualHooks") is not True
            or set(params.get("values") or {})
            != {
                "f_lastest_files",
                "f_lastest_files_name",
                "f_lastest_file_date",
            }
        ):
            raise ApiError("CHI Checklist Latest must save attachment association")
    loop = node_by_title(
        workflow,
        "Apply changed CHI Checklist files"
        if updating else "Apply Checklist files to native CHI records",
    )
    association_query = node_by_title(
        workflow, "Reload CHI Checklist associations after upload"
    )
    association_script = node_by_title(
        workflow, "Verify CHI Checklist Latest and Details"
    )
    association_check = node_by_title(workflow, "CHI Checklist associations saved")
    association_failed = node_by_title(
        workflow, "Mark CHI Checklist association failed"
    )
    stage_reload = node_by_title(workflow, "Reload CHI staging after Checklist")
    app = node_by_title(
        workflow, "Resolve linked CHI" if updating else "Find native-created CHI"
    )
    expected_query = query_config(
        "t_document_submitted_for_application",
        [
            {"f_business_key": {"$eq": ref(app, "id")}},
            {"f_business_type": {"$eq": "t_change_home_information_app"}},
        ],
        multiple=True,
        appends=("f_lastest_files", "f_details", "f_details.f_files"),
    )
    if (
        association_query.get("type") != "query"
        or association_query.get("config") != expected_query
        or loop.get("downstreamId") != association_query["id"]
        or association_query.get("upstreamId") != loop["id"]
        or association_query.get("downstreamId") != association_script["id"]
        or association_script.get("upstreamId") != association_query["id"]
        or association_script.get("downstreamId") != association_check["id"]
        or (association_script.get("config") or {}).get("content")
        != CHECKLIST_POST_LOOP_VERIFY_SCRIPT
        or (association_script.get("config") or {}).get("arguments")
        != [
            {"name": "checklist", "value": ref(parse, "checklist")},
            {"name": "templates", "value": ref(catalog)},
            {"name": "items", "value": ref(association_query)},
            {
                "name": "requestCreatedAt",
                "value": "{{$context.data.createdAt}}",
            },
        ]
        or association_check.get("upstreamId") != association_script["id"]
        or association_check.get("config")
        != truth_condition(ref(association_script, "ready"))
        or association_failed.get("upstreamId") != association_check["id"]
        or association_failed.get("branchIndex") != 0
        or association_failed.get("config") != update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values(ref(association_script, "block_reason")),
        )
    ):
        raise ApiError("CHI Checklist post-loop association guard is incomplete")
    pending = node_by_title(workflow, CONTACT_CLONE_PENDING_TITLE)
    pending_failed = node_by_title(workflow, CONTACT_CLONE_PENDING_FAIL_TITLE)
    if (
        pending.get("upstreamId") != association_check["id"]
        or pending.get("branchIndex") != 1
        or pending.get("config") != truth_condition(ref(normalize, "contact_pending"))
        or pending_failed.get("upstreamId") != pending["id"]
        or pending_failed.get("branchIndex") != 1
        or pending_failed.get("config")
        != update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values(ref(normalize, "block_reason")),
        )
        or stage_reload.get("upstreamId") != pending["id"]
        or stage_reload.get("branchIndex") != 0
    ):
        raise ApiError("CHI operator clone pending is not failed separately")
    checked = node_by_title(workflow, "CHI Checklist and projection succeeded")
    continuation = node_by_title(
        workflow,
        "Mark update succeeded + backfill IDs"
        if updating
        else "Load Intake for native Submit",
    )
    if (
        continuation.get("upstreamId") != checked["id"]
        or continuation.get("branchIndex") != 1
    ):
        raise ApiError("Failed CHI Checklist can bypass Staging status guard")
    for condition_title, failed_title in (
        ("CHI Checklist code exists", "Mark CHI Checklist code failed"),
        ("CHI Checklist upload exists", "Mark CHI Checklist upload failed"),
    ):
        condition = node_by_title(workflow, condition_title)
        failed_node = node_by_title(workflow, failed_title)
        failed_values = ((failed_node.get("config") or {}).get("params") or {}).get(
            "values"
        ) or {}
        if (
            failed_node.get("upstreamId") != condition["id"]
            or failed_node.get("branchIndex") != 0
            or (condition.get("config") or {}).get("rejectOnFalse")
            or failed_values.get("f_status") != "failed"
            or not failed_values.get("f_error_message")
        ):
            raise ApiError("CHI Checklist failure can strand Staging processing")
    contact_update = node_by_title(workflow, "Update CHI-owned contact")
    contact_values = ((contact_update.get("config") or {}).get("params") or {}).get(
        "values"
    ) or {}
    if (
        "fk_licence_contact_company" in contact_values
        or "fk_licence_contact_person" in contact_values
    ):
        raise ApiError("Existing CHI contact update may not alter owner FK")
    for title, owned_fk, other_fk in (
        (
            "Create CHI-owned company",
            "fk_licence_contact_company",
            "fk_licence_contact_person",
        ),
        (
            "Create CHI-owned person",
            "fk_licence_contact_person",
            "fk_licence_contact_company",
        ),
    ):
        values = (
            (node_by_title(workflow, title).get("config") or {}).get("params") or {}
        ).get("values") or {}
        if owned_fk not in values or other_fk in values:
            raise ApiError("New CHI contact must have exactly its visible owner FK")


def existing_guarded_draft(
    api: RootNocoBaseApi, source: dict[str, Any], *, updating: bool
) -> dict[str, Any] | None:
    """Reuse one editable disabled revision; never silently create duplicates.

    Earlier CHI versions under the same workflow key are intentionally ignored
    unless they contain this version's unique projection node. A partially
    built matching draft is an operator recovery task, not a reason to create
    another revision.
    """
    query = urllib.parse.urlencode(
        {"filter[title]": str(source["title"]), "pageSize": 100}
    )
    rows = api.request("GET", "/api/workflows:list?" + query) or []
    candidates: list[dict[str, Any]] = []
    executed_candidates: list[int] = []
    for row in rows:
        if (
            row.get("title") != source.get("title")
            or row.get("key") != source.get("key")
            or int(row.get("id") or 0) == int(source["id"])
            or row.get("enabled")
        ):
            continue
        draft = api.get_workflow(int(row["id"]))
        titles = {str(node.get("title")) for node in draft.get("nodes") or []}
        if "Project guarded CHI page changes" in titles:
            execution_query = urllib.parse.urlencode(
                {"filter[workflowId]": str(draft["id"]), "pageSize": 1}
            )
            executions = api.request(
                "GET", "/api/executions:list?" + execution_query
            ) or []
            # workflows:get without versionStats can still report executed=0
            # for an already-run version. An explicit execution row is the
            # durable signal that NocoBase has frozen this revision.
            if draft.get("executed") or executions:
                executed_candidates.append(int(draft["id"]))
            else:
                candidates.append(draft)
    if not candidates:
        if executed_candidates:
            raise ApiError(
                "Guarded CHI revision has executed but no editable auto-copy; "
                "manual recovery required"
            )
        return None
    if len(candidates) != 1:
        raise ApiError("Multiple matching guarded CHI drafts require manual review")
    validate_revision_graph(candidates[0], updating=updating)
    return candidates[0]


def build_disabled_revisions(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    """Prepare, read back, and validate both drafts; never enable either.

    This is deliberately not exposed by ``main`` yet. Reviewers can audit
    graph topology and the one-row UAT rollback sequence before authorizing
    any mutating invocation. Native Intake/CHI workflows are never selected.
    """
    ensure_parent_staging_field(api, create_if_missing=True)
    sources = source_summary(api)
    drafts: list[dict[str, Any]] = []
    for source in sources:
        updating = source["title"] == UPDATE_TITLE
        reusable = existing_guarded_draft(api, source, updating=updating)
        if reusable is not None:
            drafts.append(reusable)
            continue
        draft = draft_revision(api, source)
        add_guarded_page_graph(api, draft, updating=updating)
        reread = api.get_workflow(int(draft["id"]))
        validate_revision_graph(reread, updating=updating)
        if not api.get_workflow(int(source["id"])).get("enabled"):
            raise ApiError(
                "Original CHI Staging source was disabled during draft build"
            )
        drafts.append(reread)
    return drafts


def patch_disabled_create_provenance(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """One-time guarded patch to an already disabled 13001 Create draft.

    This does not touch the enabled source or native CHI workflow. The Intake
    marker is atomic on Intake Create, and the early Staging backfill remains
    an integration compatibility guard for older unmarked records.
    """
    ensure_intake_create_marker_field(api, create_if_missing=True)
    sources = source_summary(api)
    source = next(row for row in sources if row["title"] == CREATE_TITLE)
    draft = api.get_workflow(revision_id)
    if (
        draft.get("enabled")
        or draft.get("executed")
        or draft.get("title") != CREATE_TITLE
        or draft.get("key") != source.get("key")
        or (draft.get("config") or {}).get("collection") != "t_api_request_staging"
    ):
        raise ApiError("Target is not the reviewed disabled CHI Create revision")
    ensure_intake_create_marker_field(api, create_if_missing=True)
    titles = {str(node.get("title")) for node in draft.get("nodes") or []}
    if (
        "Project guarded CHI page changes" not in titles
        or "Apply CHI declaration answer 10" not in titles
        or "CHI Checklist and projection succeeded" not in titles
    ):
        raise ApiError("Disabled CHI Create draft lacks reviewed guarded graph")
    intake = node_by_title(draft, "Create Intake (fixed CHI type + Home Record)")
    submitter_post = node_by_title(draft, "Apply submitter post to Intake")
    old_values = ((intake.get("config") or {}).get("params") or {}).get("values") or {}
    marker_present = old_values.get("f_api_create_staging_id") == "{{$context.data.id}}"
    early_present = "Backfill OP CHI Intake ID before bridge" in titles
    if marker_present != early_present:
        raise ApiError("Disabled CHI Create provenance patch is only partly present")
    if marker_present:
        validate_revision_graph(draft, updating=False)
        return draft
    if submitter_post.get("upstreamId") != intake["id"]:
        raise ApiError("CHI Create Intake→submitter path differs before patch")
    intake_config = dict(intake.get("config") or {})
    intake_params = dict(intake_config.get("params") or {})
    intake_values = dict(intake_params.get("values") or {})
    intake_values["f_api_create_staging_id"] = "{{$context.data.id}}"
    intake_params["values"] = intake_values
    intake_config["params"] = intake_params
    api.update_node(int(intake["id"]), {"config": intake_config})
    early = create_node(
        api,
        revision_id,
        "update",
        "Backfill OP CHI Intake ID before bridge",
        update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            {"f_intake_id": ref(intake, "id")},
        ),
    )
    link(api, intake, early)
    link(api, early, submitter_post)
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=False)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Create source changed during disabled patch")
    return reread


def patch_disabled_update_parent_lookup(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Repair Accepted parent lookup on one unexecuted CHI UPDATE draft only."""
    source = next(
        row for row in source_summary(api) if row.get("title") == UPDATE_TITLE
    )
    draft = api.get_workflow(revision_id)
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(revision_id), "pageSize": 1}
    )
    executions = api.request("GET", "/api/executions:list?" + query) or []
    if (
        draft.get("enabled")
        or draft.get("executed")
        or executions
        or draft.get("title") != UPDATE_TITLE
        or draft.get("key") != source.get("key")
        or (draft.get("config") or {}) != (source.get("config") or {})
    ):
        raise ApiError("Only an unexecuted disabled CHI UPDATE draft may be repaired")
    titles = {str(node.get("title")) for node in draft.get("nodes") or []}
    if not {
        "Project guarded CHI page changes",
        "CHI Update queue clear",
        "CHI Checklist and projection succeeded",
        "Mark CHI Update missing parent failed",
    }.issubset(titles):
        raise ApiError("CHI UPDATE draft lacks reviewed fail-closed graph")
    original = node_by_title(draft, "Resolve original CREATE staging record")
    parent = node_by_title(draft, "Verify CHI Update parent create ID")
    parent_config = dict(parent.get("config") or {})
    content = parent_config.get("content")
    if content not in (
        LEGACY_PARENT_CREATE_ID_SCRIPT,
        SAFE_PARENT_CREATE_ID_SCRIPT,
    ):
        raise ApiError("CHI UPDATE parent Script differs from reviewed version")
    set_update_parent_query_accepted(api, original)
    if content == LEGACY_PARENT_CREATE_ID_SCRIPT:
        parent_config["content"] = SAFE_PARENT_CREATE_ID_SCRIPT
        api.update_node(int(parent["id"]), {"config": parent_config})
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=True)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI UPDATE source changed during disabled patch")
    return reread


def patch_disabled_checklist_preflight(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Bind Checklist Query `$in` lists to a real parsed-item script result."""
    sources = source_summary(api)
    draft = api.get_workflow(revision_id)
    updating = draft.get("title") == UPDATE_TITLE
    source = next(
        (row for row in sources if row.get("title") == draft.get("title")),
        None,
    )
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(revision_id), "pageSize": 1}
    )
    executions = api.request("GET", "/api/executions:list?" + query) or []
    if (
        source is None
        or draft.get("enabled")
        or draft.get("executed")
        or executions
        or draft.get("key") != source.get("key")
        or (draft.get("config") or {}) != (source.get("config") or {})
    ):
        raise ApiError("Only an unexecuted disabled CHI Staging draft may be patched")
    titles = {str(node.get("title")) for node in draft.get("nodes") or []}
    if CHECKLIST_PREFLIGHT_TITLE in titles:
        validate_revision_graph(draft, updating=updating)
        return draft
    if not {
        "Project guarded CHI page changes",
        "Preflight CHI Checklist templates",
        "Preflight CHI Checklist upload IDs",
        "CHI snapshot and owner guards pass",
    }.issubset(titles):
        raise ApiError("CHI Staging draft lacks guarded Checklist preflight")
    parse = node_by_title(
        draft,
        "Parse staged CHI update body"
        if updating else "Parse staged CHI request body",
    )
    person_source = node_by_title(
        draft, "Load Home person child IDs for provenance"
    )
    reload_persons = node_by_title(draft, CONTACT_CLONE_RELOAD_PERSONS_TITLE)
    catalog = node_by_title(draft, "Preflight CHI Checklist templates")
    uploads = node_by_title(draft, "Preflight CHI Checklist upload IDs")
    normalize = node_by_title(draft, "Project guarded CHI page changes")
    preflight_upstream = (
        reload_persons
        if catalog.get("upstreamId") == reload_persons["id"]
        else person_source
    )
    if (
        catalog.get("upstreamId") != preflight_upstream["id"]
        or uploads.get("upstreamId") != catalog["id"]
        or normalize.get("upstreamId") != uploads["id"]
    ):
        raise ApiError("CHI Checklist preflight path differs before patch")
    catalog_config = dict(catalog.get("config") or {})
    catalog_params = dict(catalog_config.get("params") or {})
    catalog_filter = dict(catalog_params.get("filter") or {})
    catalog_conditions = list(catalog_filter.get("$and") or [])
    old_position = {"f_position_code": {"$in": ref(parse, "checklistPosition")}}
    if catalog_conditions.count(old_position) != 1:
        raise ApiError("CHI Checklist position Query is not reviewed legacy ref")
    uploads_config = dict(uploads.get("config") or {})
    uploads_params = dict(uploads_config.get("params") or {})
    uploads_filter = dict(uploads_params.get("filter") or {})
    uploads_conditions = list(uploads_filter.get("$and") or [])
    old_attachment = {"id": {"$in": ref(parse, "checklistAttachment")}}
    if uploads_conditions != [old_attachment]:
        raise ApiError("CHI Checklist attachment Query is not reviewed legacy ref")
    plan = create_node(
        api,
        revision_id,
        "script",
        CHECKLIST_PREFLIGHT_TITLE,
        {
            "arguments": [
                {"name": "checklist", "value": ref(parse, "checklist")}
            ],
            "content": CHECKLIST_PREFLIGHT_SCRIPT,
            "timeout": 3000,
            "continue": False,
        },
    )
    catalog_conditions[catalog_conditions.index(old_position)] = {
        "f_position_code": {"$in": ref(plan, "position_codes")}
    }
    catalog_filter["$and"] = catalog_conditions
    catalog_params["filter"] = catalog_filter
    catalog_config["params"] = catalog_params
    api.update_node(int(catalog["id"]), {"config": catalog_config})
    uploads_filter["$and"] = [
        {"id": {"$in": ref(plan, "attachment_ids")}}
    ]
    uploads_params["filter"] = uploads_filter
    uploads_config["params"] = uploads_params
    api.update_node(int(uploads["id"]), {"config": uploads_config})
    link(api, preflight_upstream, plan)
    link(api, plan, catalog)
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=updating)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Staging source changed during disabled patch")
    return reread


def patch_disabled_latest_relation(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Switch only two disabled Latest nodes to association-aware updates.

    NocoBase Repository.update() deliberately omits belongsToMany association
    fields in its individualHooks=false bulk branch. A resolved Update job can
    otherwise leave f_lastest_files empty while marking Staging succeeded.
    """
    sources = source_summary(api)
    draft = api.get_workflow(revision_id)
    source = next(
        (row for row in sources if row.get("title") == draft.get("title")), None
    )
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(revision_id), "pageSize": 1}
    )
    executions = api.request("GET", "/api/executions:list?" + query) or []
    if (
        source is None
        or draft.get("enabled")
        or draft.get("executed")
        or executions
        or draft.get("key") != source.get("key")
        or (draft.get("config") or {}) != (source.get("config") or {})
    ):
        raise ApiError("Only an unexecuted disabled CHI Staging draft may be patched")
    expected_values = {
        "f_lastest_files",
        "f_lastest_files_name",
        "f_lastest_file_date",
    }
    latest_nodes = []
    states = []
    for detail_title, latest_title in (
        ("Create CHI Checklist upload Details", "Refresh existing CHI Latest"),
        ("Create new CHI Checklist upload Details", "Refresh new CHI Latest"),
    ):
        detail = node_by_title(draft, detail_title)
        latest = node_by_title(draft, latest_title)
        config = latest.get("config") or {}
        params = config.get("params") or {}
        if (
            latest.get("type") != "update"
            or latest.get("upstreamId") != detail["id"]
            or config.get("collection")
            != "t_document_submitted_for_application"
            or set(params.get("values") or {}) != expected_values
            or params.get("individualHooks") not in (False, True)
        ):
            raise ApiError("CHI Latest update differs from reviewed disabled graph")
        latest_nodes.append(latest)
        states.append(params["individualHooks"])
    if states == [True, True]:
        validate_revision_graph(draft, updating=draft.get("title") == UPDATE_TITLE)
        return draft
    if states != [False, False]:
        raise ApiError("Partially patched CHI Latest requires manual review")
    for latest in latest_nodes:
        config = dict(latest["config"])
        params = dict(config["params"])
        params["individualHooks"] = True
        config["params"] = params
        api.update_node(int(latest["id"]), {"config": config})
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=draft.get("title") == UPDATE_TITLE)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Staging source changed during disabled patch")
    return reread


def patch_disabled_post_loop_guard(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Add association readback only to one unexecuted disabled CHI draft."""
    sources = source_summary(api)
    draft = api.get_workflow(revision_id)
    source = next(
        (row for row in sources if row.get("title") == draft.get("title")), None
    )
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(revision_id), "pageSize": 1}
    )
    executions = api.request("GET", "/api/executions:list?" + query) or []
    if (
        source is None
        or draft.get("enabled")
        or draft.get("executed")
        or executions
        or draft.get("key") != source.get("key")
        or (draft.get("config") or {}) != (source.get("config") or {})
    ):
        raise ApiError("Only an unexecuted disabled CHI Staging draft may be patched")
    updating = draft.get("title") == UPDATE_TITLE
    titles = {str(row.get("title")) for row in draft.get("nodes") or []}
    readback_titles = {
        "Reload CHI Checklist associations after upload",
        "Verify CHI Checklist Latest and Details",
        "CHI Checklist associations saved",
        "Mark CHI Checklist association failed",
    }
    if readback_titles.issubset(titles):
        validate_revision_graph(draft, updating=updating)
        return draft
    if titles & readback_titles:
        raise ApiError("Partially patched CHI association guard needs manual review")
    if not {
        "Project guarded CHI page changes",
        CHECKLIST_PREFLIGHT_TITLE,
        "Reload CHI staging after Checklist",
        "CHI Checklist and projection succeeded",
    }.issubset(titles):
        raise ApiError("CHI Staging draft lacks the guarded Checklist topology")
    for detail_title, latest_title in (
        ("Create CHI Checklist upload Details", "Refresh existing CHI Latest"),
        ("Create new CHI Checklist upload Details", "Refresh new CHI Latest"),
    ):
        detail = node_by_title(draft, detail_title)
        latest = node_by_title(draft, latest_title)
        params = (latest.get("config") or {}).get("params") or {}
        if (
            latest.get("upstreamId") != detail["id"]
            or params.get("individualHooks") is not True
            or "f_lastest_files" not in (params.get("values") or {})
        ):
            raise ApiError("CHI post-loop guard needs association-aware Latest")
    add_checklist_post_loop_guard(api, draft, updating=updating)
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=updating)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Staging source changed during disabled patch")
    return reread


def refresh_disabled_post_loop_script(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Fix missing optional Checklist arguments in one disabled CHI copy."""
    draft = api.get_workflow(revision_id)
    source = next(
        (
            row for row in source_summary(api)
            if row.get("title") == draft.get("title")
        ),
        None,
    )
    query = urllib.parse.urlencode(
        {"filter[workflowId]": str(revision_id), "pageSize": 1}
    )
    executions = api.request("GET", "/api/executions:list?" + query) or []
    if (
        draft.get("title") not in (CREATE_TITLE, UPDATE_TITLE)
        or source is None
        or draft.get("enabled")
        or draft.get("executed")
        or executions
        or draft.get("key") != source.get("key")
        or (draft.get("config") or {}) != (source.get("config") or {})
    ):
        raise ApiError("Only an unexecuted disabled CHI Staging copy may refresh")
    updating = draft.get("title") == UPDATE_TITLE
    verify = node_by_title(draft, "Verify CHI Checklist Latest and Details")
    content = (verify.get("config") or {}).get("content")
    if content == CHECKLIST_POST_LOOP_VERIFY_SCRIPT:
        validate_revision_graph(draft, updating=updating)
        return draft
    if content != LEGACY_POST_LOOP_VERIFY_SCRIPT:
        raise ApiError("CHI Checklist verifier differs from reviewed old script")
    reviewed = copy.deepcopy(draft)
    reviewed_verify = next(
        row for row in reviewed["nodes"]
        if row.get("title") == "Verify CHI Checklist Latest and Details"
    )
    reviewed_verify["config"]["content"] = CHECKLIST_POST_LOOP_VERIFY_SCRIPT
    validate_revision_graph(reviewed, updating=updating)
    config = dict(verify["config"])
    config["content"] = CHECKLIST_POST_LOOP_VERIFY_SCRIPT
    api.update_node(int(verify["id"]), {"config": config})
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=updating)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Staging source changed during JS refresh")
    return reread


def refresh_disabled_projection(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Sync pure JS validation on one disabled, fully validated revision."""
    sources = source_summary(api)
    draft = api.get_workflow(revision_id)
    updating = draft.get("title") == UPDATE_TITLE
    source = next(
        (row for row in sources if row.get("title") == draft.get("title")), None
    )
    if source is None or draft.get("key") != source.get("key"):
        raise ApiError("Only a reviewed CHI Staging draft may refresh projection")
    validate_revision_graph(draft, updating=updating)
    normalize = node_by_title(draft, "Project guarded CHI page changes")
    config = dict(normalize.get("config") or {})
    if config.get("content") != projection_script():
        config["content"] = projection_script()
        api.update_node(int(normalize["id"]), {"config": config})
    reread = api.get_workflow(revision_id)
    validate_revision_graph(reread, updating=updating)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Enabled CHI Staging source changed during JS refresh")
    return reread


def truth_condition(value: str) -> dict[str, Any]:
    return {
        "rejectOnFalse": False,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "equal", "operands": [value, True]},
                ],
            }
        },
    }


def ensure_checklist_input_guard(
    api: RootNocoBaseApi, workflow: dict[str, Any], *, updating: bool
) -> None:
    """Reject unsafe raw Checklist input before any CHI business write."""
    titles = {str(row.get("title")) for row in workflow.get("nodes") or []}
    present = titles & CHECKLIST_INPUT_GUARD_TITLES
    if present and present != CHECKLIST_INPUT_GUARD_TITLES:
        raise ApiError("Partially patched CHI Checklist input guard")
    parse = node_by_title(
        workflow,
        "Parse staged CHI update body"
        if updating
        else "Parse staged CHI request body",
    )
    first_title = (
        "Resolve original CREATE staging record"
        if updating
        else "Resolve business submitter and post"
    )
    try:
        successor = node_by_title(workflow, first_title)
    except ApiError:
        if updating:
            raise
        # Older offline fixtures and early Create revisions went directly from
        # parse to Intake. Keeping this fallback explicit avoids selecting an
        # arbitrary downstream node when repairing a reviewed disabled draft.
        successor = node_by_title(
            workflow, "Create Intake (fixed CHI type + Home Record)"
        )
    validate_config = {
        "arguments": [{"name": "checklist", "value": ref(parse, "checklist")}],
        "content": CHECKLIST_INPUT_VALIDATION_SCRIPT,
        "timeout": 3000,
        "continue": False,
    }
    if present:
        validate = node_by_title(workflow, CHECKLIST_INPUT_VALIDATE_TITLE)
        valid = node_by_title(workflow, CHECKLIST_INPUT_VALID_TITLE)
        failed = node_by_title(workflow, CHECKLIST_INPUT_FAIL_TITLE)
        api.update_node(int(validate["id"]), {"config": validate_config})
        validate["config"] = validate_config
        valid_config = truth_condition(ref(validate, "ready"))
        api.update_node(int(valid["id"]), {"config": valid_config})
        valid["config"] = valid_config
        failed_config = update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values(ref(validate, "block_reason")),
        )
        api.update_node(int(failed["id"]), {"config": failed_config})
        failed["config"] = failed_config
    else:
        validate = _adopt_node(
            workflow,
            create_node(
                api,
                int(workflow["id"]),
                "script",
                CHECKLIST_INPUT_VALIDATE_TITLE,
                validate_config,
            ),
        )
        valid = _adopt_node(
            workflow,
            create_node(
                api,
                int(workflow["id"]),
                "condition",
                CHECKLIST_INPUT_VALID_TITLE,
                truth_condition(ref(validate, "ready")),
            ),
        )
        failed = _adopt_node(
            workflow,
            create_node(
                api,
                int(workflow["id"]),
                "update",
                CHECKLIST_INPUT_FAIL_TITLE,
                update_config(
                    "t_api_request_staging",
                    "{{$context.data.id}}",
                    staging_failed_values(ref(validate, "block_reason")),
                ),
            ),
        )
    link(api, parse, validate)
    link(api, validate, valid)
    link(api, valid, failed, branch_index=0)
    link(api, valid, successor, branch_index=1)


def set_update_parent_query_accepted(
    api: RootNocoBaseApi, original: dict[str, Any]
) -> bool:
    """Change only the editable CHI UPDATE parent lookup from old to new status."""
    config = dict(original.get("config") or {})
    params = dict(config.get("params") or {})
    filter_value = dict(params.get("filter") or {})
    conditions = list(filter_value.get("$and") or [])
    positions = [
        index for index, item in enumerate(conditions)
        if "f_application_status" in item
    ]
    if len(positions) != 1:
        raise ApiError("CHI UPDATE parent Query has ambiguous status conditions")
    position = positions[0]
    old = conditions[position]
    if old == {"f_application_status": {"$eq": "Accepted"}}:
        return False
    if old != {"f_application_status": {"$eq": "Submitted"}}:
        raise ApiError("CHI UPDATE parent Query differs from reviewed legacy status")
    conditions[position] = {"f_application_status": {"$eq": "Accepted"}}
    filter_value["$and"] = conditions
    params["filter"] = filter_value
    config["params"] = params
    api.update_node(int(original["id"]), {"config": config})
    original["config"] = config
    return True


def add_update_serial_queue(
    api: RootNocoBaseApi,
    workflow_id: int,
    original: dict[str, Any],
    application: dict[str, Any],
) -> None:
    """Wait for lower-ID UPDATE requests for the same stable CREATE ID.

    The parent key is an integration-only Staging field. This queue runs before
    the CHI is read, so every accepted update projects the latest committed
    CHI state. A 20-second limit fails only the current Staging request; it
    never touches the application or any Home Record on timeout.
    """
    parent_check = create_node(
        api,
        workflow_id,
        "script",
        "Verify CHI Update parent create ID",
        {
            "arguments": [
                {"name": "parentId", "value": "{{$context.data.f_parent_create_id}}"},
                {"name": "originalId", "value": ref(original, "id")},
            ],
            "content": SAFE_PARENT_CREATE_ID_SCRIPT,
            "timeout": 3000,
            "continue": False,
        },
    )
    parent_valid = create_node(
        api,
        workflow_id,
        "condition",
        "CHI Update parent key valid",
        truth_condition(ref(parent_check, "ready")),
    )
    parent_failed = create_node(
        api,
        workflow_id,
        "update",
        "Mark CHI Update missing parent failed",
        update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            {"f_status": "failed"},
        ),
    )
    lower_filters = [
        {"f_parent_create_id": {"$eq": "{{$context.data.f_parent_create_id}}"}},
        {"f_request_event": {"$eq": "UPDATE"}},
        {"id": {"$lt": "{{$context.data.id}}"}},
        {"f_status": {"$in": ["submitted", "processing"]}},
    ]
    first_pending = create_node(
        api,
        workflow_id,
        "query",
        "Find lower pending CHI Update",
        query_config("t_api_request_staging", lower_filters),
    )
    queue_plan = create_node(
        api,
        workflow_id,
        "script",
        "Plan bounded CHI Update queue",
        {
            "arguments": [{"name": "pending", "value": ref(first_pending)}],
            "content": "return {iterations: pending && pending.id ? 10 : 0};",
            "timeout": 3000,
            "continue": False,
        },
    )
    queue = create_node(
        api,
        workflow_id,
        "loop",
        "Wait for earlier CHI Update to finish",
        {"target": ref(queue_plan, "iterations"), "condition": False, "exit": 1},
    )
    pause = create_node(
        api,
        workflow_id,
        "delay",
        "Pause between CHI Update queue checks",
        {"unit": 1000, "duration": 2, "endStatus": 1},
    )
    repeat_pending = create_node(
        api,
        workflow_id,
        "query",
        "Recheck lower pending CHI Update",
        query_config("t_api_request_staging", lower_filters),
    )
    # NocoBase 2.2.3 uses checkpoint=1 for post-condition. The first body
    # therefore runs once only when the initial query found a lower request;
    # subsequent iterations stop as soon as the most recent query is empty.
    queue_config = dict(queue.get("config") or {})
    queue_config["condition"] = {
        "checkpoint": 1,
        "continueOnFalse": False,
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "gt", "operands": [ref(repeat_pending, "id"), 0]}
                ],
            }
        },
    }
    api.update_node(int(queue["id"]), {"config": queue_config})
    final_pending = create_node(
        api,
        workflow_id,
        "query",
        "Final lower pending CHI Update check",
        query_config("t_api_request_staging", lower_filters),
    )
    queue_clear = create_node(
        api,
        workflow_id,
        "condition",
        "CHI Update queue clear",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [ref(final_pending), None],
                        }
                    ],
                }
            },
        },
    )
    timed_out = create_node(
        api,
        workflow_id,
        "update",
        "Mark CHI Update queue timeout failed",
        update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            {"f_status": "failed"},
        ),
    )
    link(api, original, parent_check)
    link(api, parent_check, parent_valid)
    link(api, parent_valid, parent_failed, branch_index=0)
    link(api, parent_valid, first_pending, branch_index=1)
    link(api, first_pending, queue_plan)
    link(api, queue_plan, queue)
    link(api, queue, pause, branch_index=0)
    link(api, pause, repeat_pending)
    link(api, queue, final_pending)
    link(api, final_pending, queue_clear)
    link(api, queue_clear, timed_out, branch_index=0)
    link(api, queue_clear, application, branch_index=1)


def add_existing_contact_children(
    api: RootNocoBaseApi,
    workflow_id: int,
    contact_loop: dict[str, Any],
    update_contact: dict[str, Any],
) -> None:
    """Update/create only child rows owned by an existing CHI contact.

    New contacts use NocoBase's existing nested Create association path, as
    verified in the native independent-contact node. Each declaration slot
    uses a separate loop so a newly created detail can link exactly one
    static FK back to its CHI-owned contact; there is no dynamic column name.
    """
    registration = create_node(
        api,
        workflow_id,
        "loop",
        "Apply existing CHI company registration child",
        {
            "target": scope(contact_loop, "registration_ops"),
            "condition": False,
            "exit": 2,
        },
    )
    exists = create_node(
        api,
        workflow_id,
        "condition",
        "CHI company registration child exists",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [scope(registration, "id"), 0],
                        },
                    ],
                }
            },
        },
    )
    fields = ("f_company_registration_identifier_types", "f_legislation_chapter_no")
    values = {field: scope(registration, "patch." + field) for field in fields}
    update = create_node(
        api,
        workflow_id,
        "update",
        "Update CHI company registration child",
        update_config("t_rpop_op_app", scope(registration, "id"), values),
    )
    new_values = dict(values)
    new_values["fk_licence_contact"] = scope(registration, "contact_id")
    create = create_node(
        api,
        workflow_id,
        "create",
        "Create CHI company registration child",
        {
            "collection": "t_rpop_op_app",
            "params": {"values": new_values, "appends": []},
        },
    )
    link(api, update_contact, registration)
    link(api, registration, exists, branch_index=0)
    link(api, exists, update, branch_index=1)
    link(api, exists, create, branch_index=0)

    previous = registration
    for slot in DECLARATION_SLOTS:
        detail_loop = create_node(
            api,
            workflow_id,
            "loop",
            f"Apply CHI declaration answer {slot}",
            {
                "target": scope(contact_loop, f"declaration_ops.{slot}"),
                "condition": False,
                "exit": 2,
            },
        )
        detail_exists = create_node(
            api,
            workflow_id,
            "condition",
            f"CHI declaration detail {slot} exists",
            {
                "rejectOnFalse": False,
                "engine": "basic",
                "calculation": {
                    "group": {
                        "type": "and",
                        "calculations": [
                            {
                                "calculator": "gt",
                                "operands": [scope(detail_loop, "id"), 0],
                            },
                        ],
                    }
                },
            },
        )
        update_detail = create_node(
            api,
            workflow_id,
            "update",
            f"Update CHI declaration detail {slot}",
            update_config(
                "t_rpop_app_detail",
                scope(detail_loop, "id"),
                {"f_declaration_answer": scope(detail_loop, "answer")},
            ),
        )
        new_detail = create_node(
            api,
            workflow_id,
            "create",
            f"Create CHI declaration detail {slot}",
            {
                "collection": "t_rpop_app_detail",
                "params": {
                    "values": {
                        "f_declaration_answer": scope(detail_loop, "answer"),
                    },
                    "appends": [],
                },
            },
        )
        # NocoBase's first FK is ``fk_rpop_app_detail1`` (without the second
        # underscore); slots 2..10 use ``fk_rpop_app_detail_N``.
        foreign_key = (
            "fk_rpop_app_detail1" if slot == 1 else f"fk_rpop_app_detail_{slot}"
        )
        link_detail = create_node(
            api,
            workflow_id,
            "update",
            f"Link CHI declaration detail {slot} to contact",
            update_config(
                "t_licence_contact",
                scope(detail_loop, "contact_id"),
                {foreign_key: ref(new_detail, "id")},
            ),
        )
        link(api, previous, detail_loop)
        link(api, detail_loop, detail_exists, branch_index=0)
        link(api, detail_exists, update_detail, branch_index=1)
        link(api, detail_exists, new_detail, branch_index=0)
        link(api, new_detail, link_detail)
        previous = detail_loop


def _adopt_node(workflow: dict[str, Any], node: Mapping[str, Any]) -> dict[str, Any]:
    """Keep locally cached graphs in sync with nodes created over HTTP."""
    nodes = workflow.setdefault("nodes", [])
    node_id = int(node["id"])
    for row in nodes:
        if int(row.get("id") or 0) == node_id:
            row.update(dict(node))
            return row
    adopted = dict(node)
    nodes.append(adopted)
    return adopted


def chi_owned_company_query(application: Mapping[str, Any]) -> dict[str, Any]:
    """Look up the CHI company clone by application id, not a stale relation id."""
    return query_config(
        "t_licence_contact",
        [
            {"fk_licence_contact_company": {"$eq": ref(application, "id")}},
        ],
        appends=CONTACT_NESTED_FIELDS,
    )


def chi_owned_persons_query(application: Mapping[str, Any]) -> dict[str, Any]:
    return query_config(
        "t_licence_contact",
        [
            {"fk_licence_contact_person": {"$eq": ref(application, "id")}},
        ],
        multiple=True,
        appends=CONTACT_NESTED_FIELDS,
    )


def contact_clone_script_arguments(
    parse: Mapping[str, Any],
    company: Mapping[str, Any],
    persons: Mapping[str, Any],
    home: Mapping[str, Any],
    home_company: Mapping[str, Any],
    home_persons: Mapping[str, Any],
) -> list[dict[str, Any]]:
    return [
        {"name": "formData", "value": ref(parse, "formData")},
        {"name": "companyContact", "value": ref(company)},
        {"name": "operatorContact", "value": ref(persons)},
        {"name": "home", "value": ref(home)},
        {"name": "homeCompanyContact", "value": ref(home_company)},
        {"name": "homePersonContacts", "value": ref(home_persons)},
    ]


def _set_projection_contact_sources(
    api: RootNocoBaseApi,
    normalize: Mapping[str, Any],
    company: Mapping[str, Any],
    persons: Mapping[str, Any],
) -> None:
    config = dict(normalize.get("config") or {})
    arguments = [dict(item) for item in config.get("arguments") or []]
    by_name = {item.get("name"): item for item in arguments}
    by_name["companyContact"] = {
        "name": "companyContact",
        "value": ref(company),
    }
    by_name["operatorContact"] = {
        "name": "operatorContact",
        "value": ref(persons),
    }
    order = [item.get("name") for item in arguments]
    for name in ("companyContact", "operatorContact"):
        if name not in order:
            order.append(name)
    config["arguments"] = [by_name[name] for name in order if name in by_name]
    api.update_node(int(normalize["id"]), {"config": config})


def add_contact_clone_wait(
    api: RootNocoBaseApi,
    workflow: dict[str, Any],
    *,
    parse: Mapping[str, Any],
    refresh: Mapping[str, Any],
    home: Mapping[str, Any],
    company_full: Mapping[str, Any],
    persons_full: Mapping[str, Any],
    home_company_full: Mapping[str, Any],
    home_persons_full: Mapping[str, Any],
    downstream: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Wait/recheck native CHI contact clones before overlay; then reload by CHI id."""
    wid = int(workflow["id"])
    plan = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "script",
            CONTACT_CLONE_PLAN_TITLE,
            {
                "arguments": contact_clone_script_arguments(
                    parse,
                    company_full,
                    persons_full,
                    home,
                    home_company_full,
                    home_persons_full,
                ),
                "content": CONTACT_CLONE_WAIT_PLAN_SCRIPT,
                "timeout": 3000,
                "continue": False,
            },
        ),
    )
    wait_loop = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "loop",
            CONTACT_CLONE_WAIT_TITLE,
            {"target": ref(plan, "iterations"), "condition": False, "exit": 1},
        ),
    )
    pause = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "delay",
            CONTACT_CLONE_PAUSE_TITLE,
            {"unit": 1000, "duration": 2, "endStatus": 1},
        ),
    )
    recheck_company = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "query",
            CONTACT_CLONE_RECHECK_COMPANY_TITLE,
            chi_owned_company_query(refresh),
        ),
    )
    recheck_persons = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "query",
            CONTACT_CLONE_RECHECK_PERSONS_TITLE,
            chi_owned_persons_query(refresh),
        ),
    )
    still_missing = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "script",
            CONTACT_CLONE_STILL_MISSING_TITLE,
            {
                "arguments": contact_clone_script_arguments(
                    parse,
                    recheck_company,
                    recheck_persons,
                    home,
                    home_company_full,
                    home_persons_full,
                ),
                "content": CONTACT_CLONE_STILL_MISSING_SCRIPT,
                "timeout": 3000,
                "continue": False,
            },
        ),
    )
    reload_company = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "query",
            CONTACT_CLONE_RELOAD_COMPANY_TITLE,
            chi_owned_company_query(refresh),
        ),
    )
    reload_persons = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "query",
            CONTACT_CLONE_RELOAD_PERSONS_TITLE,
            chi_owned_persons_query(refresh),
        ),
    )
    queue_config = dict(wait_loop.get("config") or {})
    queue_config["condition"] = {
        "checkpoint": 1,
        "continueOnFalse": False,
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {
                        "calculator": "equal",
                        "operands": [ref(still_missing, "missing"), True],
                    }
                ],
            }
        },
    }
    api.update_node(int(wait_loop["id"]), {"config": queue_config})
    wait_loop["config"] = queue_config
    link(api, home_persons_full, plan)
    link(api, plan, wait_loop)
    link(api, wait_loop, pause, branch_index=0)
    link(api, pause, recheck_company)
    link(api, recheck_company, recheck_persons)
    link(api, recheck_persons, still_missing)
    link(api, wait_loop, reload_company)
    link(api, reload_company, reload_persons)
    link(api, reload_persons, downstream)
    return reload_company, reload_persons


def add_snapshot_wait(
    api: RootNocoBaseApi,
    workflow: dict[str, Any],
    *,
    application: Mapping[str, Any],
    exists: Mapping[str, Any],
    refresh: Mapping[str, Any],
    pause: dict[str, Any] | None = None,
) -> None:
    """Bound the native snapshot race without writing application data."""
    wid = int(workflow["id"])
    plan = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "script",
            SNAPSHOT_PLAN_TITLE,
            {
                "arguments": [{"name": "application", "value": ref(application)}],
                "content": SNAPSHOT_WAIT_PLAN_SCRIPT,
                "timeout": 3000,
                "continue": False,
            },
        ),
    )
    wait_loop = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "loop",
            SNAPSHOT_WAIT_TITLE,
            {"target": ref(plan, "iterations"), "condition": False, "exit": 1},
        ),
    )
    if pause is None:
        pause = _adopt_node(
            workflow,
            create_node(
                api,
                wid,
                "delay",
                SNAPSHOT_PAUSE_TITLE,
                {"unit": 1000, "duration": 2, "endStatus": 1},
            ),
        )
    else:
        pause_config = {"unit": 1000, "duration": 2, "endStatus": 1}
        api.update_node(
            int(pause["id"]),
            {"title": SNAPSHOT_PAUSE_TITLE, "config": pause_config},
        )
        pause["title"] = SNAPSHOT_PAUSE_TITLE
        pause["config"] = pause_config
    recheck = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "query",
            SNAPSHOT_RECHECK_TITLE,
            copy.deepcopy(refresh.get("config") or {}),
        ),
    )
    pending = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "script",
            SNAPSHOT_PENDING_TITLE,
            {
                "arguments": [{"name": "application", "value": ref(recheck)}],
                "content": SNAPSHOT_STILL_PENDING_SCRIPT,
                "timeout": 3000,
                "continue": False,
            },
        ),
    )
    loop_config = dict(wait_loop.get("config") or {})
    loop_config["condition"] = {
        "checkpoint": 1,
        "continueOnFalse": False,
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {
                        "calculator": "equal",
                        "operands": [ref(pending, "pending"), True],
                    }
                ],
            }
        },
    }
    api.update_node(int(wait_loop["id"]), {"config": loop_config})
    wait_loop["config"] = loop_config
    link(api, exists, plan, branch_index=1)
    link(api, plan, wait_loop)
    link(api, wait_loop, pause, branch_index=0)
    link(api, pause, recheck)
    link(api, recheck, pending)
    link(api, wait_loop, refresh)


def ensure_snapshot_wait_graph(
    api: RootNocoBaseApi, workflow: dict[str, Any], *, updating: bool
) -> None:
    """Insert/refresh the bounded snapshot gate on an editable revision."""
    titles = {str(row.get("title")) for row in workflow.get("nodes") or []}
    present = titles & SNAPSHOT_WAIT_TITLES
    if present and present != SNAPSHOT_WAIT_TITLES:
        raise ApiError("Partially patched CHI snapshot wait needs manual review")
    application = node_by_title(
        workflow, "Resolve linked CHI" if updating else "Find native-created CHI"
    )
    exists = node_by_title(
        workflow, "Linked CHI exists" if updating else "Native CHI exists"
    )
    refresh = node_by_title(workflow, "Reload CHI after native snapshot")
    if present == SNAPSHOT_WAIT_TITLES:
        plan = node_by_title(workflow, SNAPSHOT_PLAN_TITLE)
        wait_loop = node_by_title(workflow, SNAPSHOT_WAIT_TITLE)
        pause = node_by_title(workflow, SNAPSHOT_PAUSE_TITLE)
        recheck = node_by_title(workflow, SNAPSHOT_RECHECK_TITLE)
        pending = node_by_title(workflow, SNAPSHOT_PENDING_TITLE)
        plan_config = {
            "arguments": [{"name": "application", "value": ref(application)}],
            "content": SNAPSHOT_WAIT_PLAN_SCRIPT,
            "timeout": 3000,
            "continue": False,
        }
        api.update_node(int(plan["id"]), {"config": plan_config})
        pause_config = {"unit": 1000, "duration": 2, "endStatus": 1}
        api.update_node(int(pause["id"]), {"config": pause_config})
        api.update_node(
            int(recheck["id"]),
            {"config": copy.deepcopy(refresh.get("config") or {})},
        )
        pending_config = {
            "arguments": [{"name": "application", "value": ref(recheck)}],
            "content": SNAPSHOT_STILL_PENDING_SCRIPT,
            "timeout": 3000,
            "continue": False,
        }
        api.update_node(int(pending["id"]), {"config": pending_config})
        loop_config = dict(wait_loop.get("config") or {})
        loop_config["target"] = ref(plan, "iterations")
        loop_config["condition"] = {
            "checkpoint": 1,
            "continueOnFalse": False,
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [ref(pending, "pending"), True],
                        }
                    ],
                }
            },
        }
        api.update_node(int(wait_loop["id"]), {"config": loop_config})
        link(api, exists, plan, branch_index=1)
        link(api, plan, wait_loop)
        link(api, wait_loop, pause, branch_index=0)
        link(api, pause, recheck)
        link(api, recheck, pending)
        link(api, wait_loop, refresh)
        return
    legacy_pause = node_by_title(workflow, "Wait briefly for native CHI snapshot")
    add_snapshot_wait(
        api,
        workflow,
        application=application,
        exists=exists,
        refresh=refresh,
        pause=legacy_pause,
    )


def ensure_operator_clone_pending_guard(
    api: RootNocoBaseApi, workflow: dict[str, Any]
) -> None:
    """Fail operator clone after independent overlay and Checklist have landed."""
    titles = {str(row.get("title")) for row in workflow.get("nodes") or []}
    present = titles & CONTACT_CLONE_PENDING_TITLES
    association_check = node_by_title(workflow, "CHI Checklist associations saved")
    stage_reload = node_by_title(workflow, "Reload CHI staging after Checklist")
    normalize = node_by_title(workflow, "Project guarded CHI page changes")
    if present and present != CONTACT_CLONE_PENDING_TITLES:
        raise ApiError("Partially patched CHI operator clone pending guard")
    if present == CONTACT_CLONE_PENDING_TITLES:
        pending = node_by_title(workflow, CONTACT_CLONE_PENDING_TITLE)
        failed = node_by_title(workflow, CONTACT_CLONE_PENDING_FAIL_TITLE)
    else:
        pending = _adopt_node(
            workflow,
            create_node(
                api,
                int(workflow["id"]),
                "condition",
                CONTACT_CLONE_PENDING_TITLE,
                truth_condition(ref(normalize, "contact_pending")),
            ),
        )
        failed = _adopt_node(
            workflow,
            create_node(
                api,
                int(workflow["id"]),
                "update",
                CONTACT_CLONE_PENDING_FAIL_TITLE,
                update_config(
                    "t_api_request_staging",
                    "{{$context.data.id}}",
                    staging_failed_values(ref(normalize, "block_reason")),
                ),
            ),
        )
    pending_config = dict(pending.get("config") or {})
    expected_pending = truth_condition(ref(normalize, "contact_pending"))
    if pending_config != expected_pending:
        api.update_node(int(pending["id"]), {"config": expected_pending})
        pending["config"] = expected_pending
    expected_failed = update_config(
        "t_api_request_staging",
        "{{$context.data.id}}",
        staging_failed_values(ref(normalize, "block_reason")),
    )
    if (failed.get("config") or {}) != expected_failed:
        api.update_node(int(failed["id"]), {"config": expected_failed})
        failed["config"] = expected_failed
    link(api, association_check, pending, branch_index=1)
    link(api, pending, failed, branch_index=1)
    link(api, pending, stage_reload, branch_index=0)


def ensure_contact_clone_wait_graph(
    api: RootNocoBaseApi, workflow: dict[str, Any], *, updating: bool
) -> None:
    """Insert or refresh bounded clone wait on an existing guarded CHI graph."""
    titles = {str(row.get("title")) for row in workflow.get("nodes") or []}
    present = titles & CONTACT_CLONE_WAIT_TITLES
    if present and present != CONTACT_CLONE_WAIT_TITLES:
        raise ApiError("Partially patched CHI contact clone wait needs manual review")
    parse = node_by_title(
        workflow,
        "Parse staged CHI update body" if updating else "Parse staged CHI request body",
    )
    refresh = node_by_title(workflow, "Reload CHI after native snapshot")
    home = node_by_title(workflow, "Load source Home for ownership guard")
    company_full = node_by_title(workflow, "Load CHI company child records")
    persons_full = node_by_title(workflow, "Load CHI person child records")
    home_company = node_by_title(
        workflow, "Load Home company child IDs for provenance"
    )
    home_persons = node_by_title(
        workflow, "Load Home person child IDs for provenance"
    )
    checklist_plan = node_by_title(workflow, CHECKLIST_PREFLIGHT_TITLE)
    normalize = node_by_title(workflow, "Project guarded CHI page changes")
    api.update_node(
        int(company_full["id"]),
        {"config": chi_owned_company_query(refresh)},
    )
    persons_config = chi_owned_persons_query(refresh)
    if (persons_full.get("config") or {}) != persons_config:
        api.update_node(int(persons_full["id"]), {"config": persons_config})
    if present == CONTACT_CLONE_WAIT_TITLES:
        reload_company = node_by_title(workflow, CONTACT_CLONE_RELOAD_COMPANY_TITLE)
        reload_persons = node_by_title(workflow, CONTACT_CLONE_RELOAD_PERSONS_TITLE)
        plan = node_by_title(workflow, CONTACT_CLONE_PLAN_TITLE)
        wait_loop = node_by_title(workflow, CONTACT_CLONE_WAIT_TITLE)
        still_missing = node_by_title(workflow, CONTACT_CLONE_STILL_MISSING_TITLE)
        recheck_company = node_by_title(
            workflow, CONTACT_CLONE_RECHECK_COMPANY_TITLE
        )
        recheck_persons = node_by_title(
            workflow, CONTACT_CLONE_RECHECK_PERSONS_TITLE
        )
        api.update_node(
            int(plan["id"]),
            {
                "config": {
                    "arguments": contact_clone_script_arguments(
                        parse,
                        company_full,
                        persons_full,
                        home,
                        home_company,
                        home_persons,
                    ),
                    "content": CONTACT_CLONE_WAIT_PLAN_SCRIPT,
                    "timeout": 3000,
                    "continue": False,
                }
            },
        )
        api.update_node(
            int(still_missing["id"]),
            {
                "config": {
                    "arguments": contact_clone_script_arguments(
                        parse,
                        recheck_company,
                        recheck_persons,
                        home,
                        home_company,
                        home_persons,
                    ),
                    "content": CONTACT_CLONE_STILL_MISSING_SCRIPT,
                    "timeout": 3000,
                    "continue": False,
                }
            },
        )
        api.update_node(
            int(reload_company["id"]), {"config": chi_owned_company_query(refresh)}
        )
        api.update_node(
            int(reload_persons["id"]), {"config": chi_owned_persons_query(refresh)}
        )
        api.update_node(
            int(recheck_company["id"]), {"config": chi_owned_company_query(refresh)}
        )
        api.update_node(
            int(recheck_persons["id"]), {"config": chi_owned_persons_query(refresh)}
        )
        queue_config = dict(wait_loop.get("config") or {})
        queue_config["target"] = ref(plan, "iterations")
        queue_config["condition"] = {
            "checkpoint": 1,
            "continueOnFalse": False,
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [ref(still_missing, "missing"), True],
                        }
                    ],
                }
            },
        }
        api.update_node(int(wait_loop["id"]), {"config": queue_config})
        link(api, home_persons, plan)
        link(api, plan, wait_loop)
        link(api, wait_loop, reload_company)
        link(api, reload_company, reload_persons)
        link(api, reload_persons, checklist_plan)
    else:
        reload_company, reload_persons = add_contact_clone_wait(
            api,
            workflow,
            parse=parse,
            refresh=refresh,
            home=home,
            company_full=company_full,
            persons_full=persons_full,
            home_company_full=home_company,
            home_persons_full=home_persons,
            downstream=checklist_plan,
        )
    _set_projection_contact_sources(api, normalize, reload_company, reload_persons)
    ensure_operator_clone_pending_guard(api, workflow)


def add_guarded_page_graph(
    api: RootNocoBaseApi, workflow: dict[str, Any], *, updating: bool
) -> None:
    """Extend only an editable Staging revision; native workflows are untouched.

    The old overlay node is retained and reconfigured with a preserve-on-absent
    projection of all previously accepted fields. A bounded snapshot-version
    poll prevents the API overlay from racing the native Home snapshot.
    """
    wid = int(workflow["id"])
    parse = node_by_title(
        workflow,
        "Parse staged CHI update body" if updating else "Parse staged CHI request body",
    )
    parse_config = dict(parse.get("config") or {})
    variables = list(parse_config.get("variables") or [])
    if not any(v.get("key") == "formData" for v in variables):
        variables.append(
            {
                "key": "formData",
                "path": "form_data",
                "name": "form_data",
                "paths": ["form_data"],
            }
        )
        parse_config["variables"] = variables
        api.update_node(int(parse["id"]), {"config": parse_config})
    ensure_checklist_input_guard(api, workflow, updating=updating)
    application = node_by_title(
        workflow, "Resolve linked CHI" if updating else "Find native-created CHI"
    )
    exists = node_by_title(
        workflow, "Linked CHI exists" if updating else "Native CHI exists"
    )
    apply = node_by_title(
        workflow,
        "Apply staged CHI update overlay"
        if updating
        else "Apply staged flags and overlay to native CHI",
    )
    successor = node_by_title(
        workflow,
        "Mark update succeeded + backfill IDs"
        if updating
        else "Apply Checklist files to native CHI records",
    )
    original = (
        node_by_title(workflow, "Resolve original CREATE staging record")
        if updating
        else None
    )
    if original is not None:
        set_update_parent_query_accepted(api, original)
    intake = (
        node_by_title(workflow, "Create Intake (fixed CHI type + Home Record)")
        if not updating
        else None
    )
    if intake is not None:
        intake_config = dict(intake.get("config") or {})
        intake_params = dict(intake_config.get("params") or {})
        intake_values = dict(intake_params.get("values") or {})
        intake_values["f_api_create_staging_id"] = "{{$context.data.id}}"
        intake_params["values"] = intake_values
        intake_config["params"] = intake_params
        api.update_node(int(intake["id"]), {"config": intake_config})
    pre_create_wait = None
    if not updating:
        submitter_post = node_by_title(workflow, "Apply submitter post to Intake")
        assert intake is not None
        early_backfill = create_node(
            api,
            wid,
            "update",
            "Backfill OP CHI Intake ID before bridge",
            update_config(
                "t_api_request_staging",
                "{{$context.data.id}}",
                {"f_intake_id": ref(intake, "id")},
            ),
        )
        pre_create_wait = create_node(
            api,
            wid,
            "delay",
            "Wait briefly for native CHI creation",
            {"unit": 1000, "duration": 2, "endStatus": 1},
        )
        link(api, intake, early_backfill)
        link(api, early_backfill, submitter_post)
        link(api, submitter_post, pre_create_wait)
        link(api, pre_create_wait, application)
    else:
        assert original is not None
        add_update_serial_queue(api, wid, original, application)
    refresh = create_node(
        api,
        wid,
        "query",
        "Reload CHI after native snapshot",
        query_config(
            "t_change_home_information_app",
            [
                {"id": {"$eq": ref(application, "id")}},
            ],
            appends=(
                "f_attachments_of_rchs",
                "f_licence_contact_company",
                "f_licence_contact_person",
            ),
        ),
    )
    add_snapshot_wait(
        api,
        workflow,
        application=application,
        exists=exists,
        refresh=refresh,
    )
    home = create_node(
        api,
        wid,
        "query",
        "Load source Home for ownership guard",
        query_config(
            "t_home_record",
            [
                {"id": {"$eq": ref(refresh, "fk_home_record")}},
            ],
            appends=(
                "f_home_contact_applicant",
                "f_home_contact_company",
                "f_home_contact_person",
            ),
        ),
    )
    chi_address = create_node(
        api,
        wid,
        "query",
        "Load CHI address clone",
        query_config(
            "t_address",
            [
                {"id": {"$eq": ref(refresh, "fk_rch_address")}},
            ],
        ),
    )
    home_address = create_node(
        api,
        wid,
        "query",
        "Load Home address ID only",
        query_config(
            "t_address",
            [
                {"id": {"$eq": ref(home, "fk_rch_address")}},
            ],
        ),
    )
    address_options = create_node(
        api,
        wid,
        "query",
        "Load address code map for CHI",
        query_config("f_tree_region_district", [], multiple=True),
    )
    type_options = create_node(
        api,
        wid,
        "query",
        "Load RCH type map for CHI",
        query_config("f_rch_type_options", [], multiple=True),
    )
    nested = CONTACT_NESTED_FIELDS
    company_full = create_node(
        api,
        wid,
        "query",
        "Load CHI company child records",
        chi_owned_company_query(refresh),
    )
    persons_full = create_node(
        api,
        wid,
        "query",
        "Load CHI person child records",
        chi_owned_persons_query(refresh),
    )
    home_company_full = create_node(
        api,
        wid,
        "query",
        "Load Home company child IDs for provenance",
        query_config(
            "t_home_contact",
            [
                {"id": {"$eq": ref(home, "f_home_contact_company.id")}},
            ],
            appends=nested,
        ),
    )
    home_persons_full = create_node(
        api,
        wid,
        "query",
        "Load Home person child IDs for provenance",
        query_config(
            "t_home_contact",
            [
                {"fk_home_contact_person": {"$eq": ref(home, "id")}},
            ],
            multiple=True,
            appends=nested,
        ),
    )
    checklist_plan = create_node(
        api,
        wid,
        "script",
        CHECKLIST_PREFLIGHT_TITLE,
        {
            "arguments": [
                {"name": "checklist", "value": ref(parse, "checklist")}
            ],
            "content": CHECKLIST_PREFLIGHT_SCRIPT,
            "timeout": 3000,
            "continue": False,
        },
    )
    reload_company, reload_persons = add_contact_clone_wait(
        api,
        workflow,
        parse=parse,
        refresh=refresh,
        home=home,
        company_full=company_full,
        persons_full=persons_full,
        home_company_full=home_company_full,
        home_persons_full=home_persons_full,
        downstream=checklist_plan,
    )
    checklist_templates = create_node(
        api,
        wid,
        "query",
        "Preflight CHI Checklist templates",
        query_config(
            "t_document_checklist",
            [
                {"f_position_code": {"$in": ref(checklist_plan, "position_codes")}},
                {"f_office_code": {"$eq": ref(refresh, "f_office_cd")}},
                {"f_active": {"$eq": True}},
                {"f_item_type": {"$eq": "2"}},
                {"f_use_for": {"$anyOf": ["t_change_home_information_app",
                                         "t_licence_app"]}},
            ],
            multiple=True,
        ),
    )
    checklist_uploads = create_node(
        api,
        wid,
        "query",
        "Preflight CHI Checklist upload IDs",
        query_config(
            "attachments",
            [{"id": {"$in": ref(checklist_plan, "attachment_ids")}}],
            multiple=True,
        ),
    )
    normalize = create_node(
        api,
        wid,
        "script",
        "Project guarded CHI page changes",
        {
            "arguments": [
                {"name": "formData", "value": ref(parse, "formData")},
                {"name": "application", "value": ref(refresh)},
                {"name": "home", "value": ref(home)},
                {"name": "chiAddress", "value": ref(chi_address)},
                {"name": "homeAddress", "value": ref(home_address)},
                {"name": "companyContact", "value": ref(reload_company)},
                {"name": "operatorContact", "value": ref(reload_persons)},
                {"name": "homeCompanyContact", "value": ref(home_company_full)},
                {"name": "homePersonContacts", "value": ref(home_persons_full)},
                {"name": "checklistTemplates", "value": ref(checklist_templates)},
                {"name": "checklistUploads", "value": ref(checklist_uploads)},
                {"name": "addressOptions", "value": ref(address_options)},
                {"name": "rchTypeOptions", "value": ref(type_options)},
            ],
            "content": projection_script(),
            "timeout": 3000,
            "continue": False,
        },
    )
    ready = create_node(
        api,
        wid,
        "condition",
        "CHI snapshot and owner guards pass",
        truth_condition(ref(normalize, "ready")),
    )
    failed = create_node(
        api,
        wid,
        "update",
        "Mark guarded CHI staging failed",
        update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values(
                ref(normalize, "block_reason"),
                f_application_id=ref(refresh, "id"),
                f_intake_id=(
                    ref(original, "f_intake_id")
                    if updating
                    else ref(intake, "id")
                ),
            ),
        ),
    )
    apply_config = dict(apply.get("config") or {})
    apply_params = dict(apply_config.get("params") or {})
    apply_params["values"] = field_references(normalize, "legacy_patch", ALL_CHI_FIELDS)
    apply_config["params"] = apply_params
    api.update_node(int(apply["id"]), {"config": apply_config})
    address_loop = create_node(
        api,
        wid,
        "loop",
        "Apply proposed CHI address",
        {"target": ref(normalize, "address_ops"), "condition": False, "exit": 2},
    )
    update_address = create_node(
        api,
        wid,
        "update",
        "Update CHI-owned address only",
        update_config(
            "t_address",
            scope(address_loop, "id"),
            {
                field: scope(address_loop, "patch." + field)
                for field in ADDRESS_PAGE_FIELDS
            },
        ),
    )
    contact_loop = create_node(
        api,
        wid,
        "loop",
        "Apply CHI-owned proposed contacts",
        {"target": ref(normalize, "contact_updates"), "condition": False, "exit": 0},
    )
    contact_exists = create_node(
        api,
        wid,
        "condition",
        "CHI proposed contact exists",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [scope(contact_loop, "id"), 0],
                        },
                    ],
                }
            },
        },
    )
    update_contact = create_node(
        api,
        wid,
        "update",
        "Update CHI-owned contact",
        update_config(
            "t_licence_contact",
            scope(contact_loop, "id"),
            {
                field: scope(contact_loop, "patch." + field)
                for field in CONTACT_PAGE_MAP.values()
            },
        ),
    )
    company_kind = create_node(
        api,
        wid,
        "condition",
        "New CHI contact is company",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [scope(contact_loop, "kind"), "company"],
                        },
                    ],
                }
            },
        },
    )

    def create_contact(kind: str, foreign_key: str) -> dict[str, Any]:
        values = {
            field: scope(contact_loop, "patch." + field)
            for field in CONTACT_PAGE_MAP.values()
        }
        values[foreign_key] = scope(contact_loop, "patch." + foreign_key)
        values.update(
            {
                field: scope(contact_loop, "patch." + field)
                for field in CONTACT_NESTED_FIELDS
            }
        )
        return create_node(
            api,
            wid,
            "create",
            "Create CHI-owned " + kind,
            {
                "collection": "t_licence_contact",
                "params": {"values": values, "appends": []},
            },
        )

    new_company = create_contact("company", "fk_licence_contact_company")
    new_person = create_contact("person", "fk_licence_contact_person")
    for upstream, downstream in (
        (refresh, home),
        (home, chi_address),
        (chi_address, home_address),
        (home_address, address_options),
        (address_options, type_options),
        (type_options, company_full),
        (company_full, persons_full),
        (persons_full, home_company_full),
        (home_company_full, home_persons_full),
        (checklist_plan, checklist_templates),
        (checklist_templates, checklist_uploads),
        (checklist_uploads, normalize),
        (normalize, ready),
        (apply, address_loop),
        (address_loop, contact_loop),
    ):
        link(api, upstream, downstream)
    link(api, ready, failed, branch_index=0)
    link(api, ready, apply, branch_index=1)
    link(api, address_loop, update_address, branch_index=0)
    link(api, contact_loop, contact_exists, branch_index=0)
    link(api, contact_exists, update_contact, branch_index=1)
    link(api, contact_exists, company_kind, branch_index=0)
    link(api, company_kind, new_company, branch_index=1)
    link(api, company_kind, new_person, branch_index=0)
    add_existing_contact_children(api, wid, contact_loop, update_contact)
    add_checklist_details(
        api,
        workflow,
        updating=updating,
        parse=parse,
        application=refresh,
        upstream=contact_loop,
        successor=successor,
    )
    ensure_operator_clone_pending_guard(api, workflow)


def row_exists_condition(
    node: dict[str, Any], *, reject: bool = False
) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "gt", "operands": [ref(node, "id"), 0]},
                ],
            }
        },
    }


def checklist_template_candidates_config(
    loop: Mapping[str, Any], application: Mapping[str, Any]
) -> dict[str, Any]:
    config = query_config(
        "t_document_checklist",
        [
            {"f_position_code": {"$eq": scope(loop, "position_code")}},
            {"f_office_code": {"$eq": ref(application, "f_office_cd")}},
            {"f_active": {"$eq": True}},
            {"f_item_type": {"$eq": "2"}},
            {
                "f_use_for": {
                    "$anyOf": [
                        "t_change_home_information_app",
                        "t_licence_app",
                    ]
                }
            },
        ],
        multiple=True,
    )
    config["params"]["sort"] = [{"field": "id", "direction": "asc"}]
    return config


def add_checklist_details(
    api: RootNocoBaseApi,
    workflow: dict[str, Any],
    *,
    updating: bool,
    parse: dict[str, Any],
    application: dict[str, Any],
    upstream: dict[str, Any],
    successor: dict[str, Any],
) -> None:
    """Every selected file gets Details before the parent Latest fields."""
    wid = int(workflow["id"])
    if updating:
        loop = create_node(
            api,
            wid,
            "loop",
            "Apply changed CHI Checklist files",
            {"target": ref(parse, "checklist"), "condition": False, "exit": 2},
        )
        template_candidates = create_node(
            api,
            wid,
            "query",
            "Resolve changed CHI Checklist position_code",
            checklist_template_candidates_config(loop, application),
        )
        template = create_node(
            api,
            wid,
            "script",
            CHECKLIST_TEMPLATE_SELECT_TITLE,
            {
                "arguments": [
                    {"name": "templates", "value": ref(template_candidates)}
                ],
                "content": CHECKLIST_TEMPLATE_SELECT_SCRIPT,
                "timeout": 3000,
                "continue": False,
            },
        )
        item = create_node(
            api,
            wid,
            "query",
            "Find changed CHI Checklist item",
            query_config(
                "t_document_submitted_for_application",
                [
                    {"f_business_key": {"$eq": ref(application, "id")}},
                    {"fk_document_checklist": {"$eq": ref(template, "id")}},
                    {"f_business_type": {"$eq": "t_change_home_information_app"}},
                ],
            ),
        )
        item_exists = create_node(
            api,
            wid,
            "condition",
            "Changed CHI Checklist item exists",
            row_exists_condition(item),
        )
        update_item = create_node(
            api,
            wid,
            "update",
            "Mark changed CHI item checked",
            update_config(
                "t_document_submitted_for_application",
                ref(item, "id"),
                {"f_is_checked": True},
            ),
        )
        create_item = create_node(
            api,
            wid,
            "create",
            "Create changed CHI item",
            {
                "collection": "t_document_submitted_for_application",
                "params": {
                    "values": {
                        "f_business_key": ref(application, "id"),
                        "f_business_type": "t_change_home_information_app",
                        "fk_document_checklist": ref(template, "id"),
                        "f_is_checked": True,
                    },
                    "appends": [],
                },
            },
        )
        link(api, upstream, loop)
        link(api, loop, template_candidates, branch_index=0)
        link(api, template_candidates, template)
    else:
        loop = successor
        template_candidates = node_by_title(
            workflow, "Resolve checklist template by position_code"
        )
        candidate_config = checklist_template_candidates_config(loop, application)
        api.update_node(
            int(template_candidates["id"]), {"config": candidate_config}
        )
        template_candidates["config"] = candidate_config
        template = _adopt_node(
            workflow,
            create_node(
                api,
                wid,
                "script",
                CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE,
                {
                    "arguments": [
                        {"name": "templates", "value": ref(template_candidates)}
                    ],
                    "content": CHECKLIST_TEMPLATE_SELECT_SCRIPT,
                    "timeout": 3000,
                    "continue": False,
                },
            ),
        )
        item = node_by_title(workflow, "Find native CHI checklist item")
        item_exists = node_by_title(workflow, "Native CHI checklist item exists")
        update_item = node_by_title(
            workflow, "Update native CHI checklist item + files"
        )
        create_item = node_by_title(workflow, "Create CHI checklist item + files")
        item_config = query_config(
            "t_document_submitted_for_application",
            [
                {"f_business_key": {"$eq": ref(application, "id")}},
                {"fk_document_checklist": {"$eq": ref(template, "id")}},
                {"f_business_type": {"$eq": "t_change_home_information_app"}},
            ],
        )
        api.update_node(int(item["id"]), {"config": item_config})
        item["config"] = item_config
        create_config = dict(create_item.get("config") or {})
        create_params = dict(create_config.get("params") or {})
        create_values = dict(create_params.get("values") or {})
        create_values["fk_document_checklist"] = ref(template, "id")
        create_params["values"] = create_values
        create_config["params"] = create_params
        api.update_node(int(create_item["id"]), {"config": create_config})
        create_item["config"] = create_config
        for node in (update_item, create_item):
            cfg = dict(node.get("config") or {})
            params = dict(cfg.get("params") or {})
            values = dict(params.get("values") or {})
            values.pop("f_lastest_files", None)
            values.pop("f_lastest_files_name", None)
            values.pop("f_lastest_file_date", None)
            params["values"] = values
            cfg["params"] = params
            api.update_node(int(node["id"]), {"config": cfg})
        link(api, upstream, loop)
        link(api, loop, template_candidates, branch_index=0)
        link(api, template_candidates, template)
    attachment = create_node(
        api,
        wid,
        "query",
        "Load CHI Checklist upload",
        query_config(
            "attachments",
            [
                {"id": {"$eq": scope(loop, "attachment_id")}},
            ],
        ),
    )
    attachment_exists = create_node(
        api,
        wid,
        "condition",
        "CHI Checklist upload exists",
        row_exists_condition(attachment),
    )
    template_exists = create_node(
        api,
        wid,
        "condition",
        "CHI Checklist code exists",
        row_exists_condition(template),
    )
    invalid_code = create_node(
        api,
        wid,
        "update",
        "Mark CHI Checklist code failed",
        update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values("chi_checklist_template_not_resolved"),
        ),
    )
    missing_upload = create_node(
        api,
        wid,
        "update",
        "Mark CHI Checklist upload failed",
        update_config(
            "t_api_request_staging",
            "{{$context.data.id}}",
            staging_failed_values("chi_checklist_attachment_not_resolved"),
        ),
    )

    # Branches must not set Latest before inserting the individual upload log.
    def detail(parent: dict[str, Any], label: str) -> dict[str, Any]:
        return create_node(
            api,
            wid,
            "create",
            label,
            {
                "collection": "t_document_submitted_for_application_details",
                "params": {
                    "values": {
                        "fk_documests_submitted_for_application_id": ref(parent, "id"),
                        "f_files": [scope(loop, "attachment_id")],
                        "f_file_name": ref(attachment, "filename"),
                        "f_file_date": ref(attachment, "createdAt"),
                    },
                    "appends": [],
                },
            },
        )

    existing_detail = detail(item, "Create CHI Checklist upload Details")
    new_detail = detail(create_item, "Create new CHI Checklist upload Details")
    latest = {
        "f_lastest_files": [scope(loop, "attachment_id")],
        "f_lastest_files_name": ref(attachment, "filename"),
        "f_lastest_file_date": ref(attachment, "createdAt"),
    }

    def latest_update_config(target_id: str) -> dict[str, Any]:
        config = update_config(
            "t_document_submitted_for_application", target_id, latest
        )
        config["params"]["individualHooks"] = True
        return config

    existing_latest = create_node(
        api,
        wid,
        "update",
        "Refresh existing CHI Latest",
        latest_update_config(ref(item, "id")),
    )
    new_latest = create_node(
        api,
        wid,
        "update",
        "Refresh new CHI Latest",
        latest_update_config(ref(create_item, "id")),
    )
    link(api, template, template_exists)
    link(api, template_exists, invalid_code, branch_index=0)
    link(api, template_exists, attachment, branch_index=1)
    link(api, attachment, attachment_exists)
    link(api, attachment_exists, missing_upload, branch_index=0)
    link(api, attachment_exists, item, branch_index=1)
    link(api, item, item_exists)
    link(api, item_exists, update_item, branch_index=1)
    link(api, item_exists, create_item, branch_index=0)
    link(api, update_item, existing_detail)
    link(api, existing_detail, existing_latest)
    link(api, create_item, new_detail)
    link(api, new_detail, new_latest)
    # A missing template/upload marks Staging failed inside the loop. The
    # final guard rereads Staging, preventing both native Submit and the
    # succeeded backfill if any loop iteration failed. No rejectOnFalse
    # exception can strand a row indefinitely in processing.
    continuation = (
        successor
        if updating
        else node_by_title(workflow, "Load Intake for native Submit")
    )
    status = create_node(
        api,
        wid,
        "query",
        "Reload CHI staging after Checklist",
        query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": "{{$context.data.id}}"}},
            ],
        ),
    )
    still_processing = create_node(
        api,
        wid,
        "condition",
        "CHI Checklist and projection succeeded",
        {
            "rejectOnFalse": False,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "equal",
                            "operands": [ref(status, "f_status"), "processing"],
                        },
                    ],
                }
            },
        },
    )
    link(api, loop, status)
    link(api, status, still_processing)
    link(api, still_processing, continuation, branch_index=1)
    add_checklist_post_loop_guard(api, workflow, updating=updating)


def add_checklist_post_loop_guard(
    api: RootNocoBaseApi, workflow: dict[str, Any], *, updating: bool
) -> None:
    """Fail Staging if requested Latest or upload Details were not persisted."""
    wid = int(workflow["id"])
    loop = node_by_title(
        workflow,
        "Apply changed CHI Checklist files"
        if updating else "Apply Checklist files to native CHI records",
    )
    stage_reload = node_by_title(workflow, "Reload CHI staging after Checklist")
    if (
        stage_reload.get("upstreamId") != loop["id"]
        or loop.get("downstreamId") != stage_reload["id"]
    ):
        raise ApiError("CHI Checklist loop completion differs before readback")
    app = node_by_title(
        workflow, "Resolve linked CHI" if updating else "Find native-created CHI"
    )
    parse = node_by_title(
        workflow,
        "Parse staged CHI update body"
        if updating else "Parse staged CHI request body",
    )
    catalog = node_by_title(workflow, "Preflight CHI Checklist templates")
    saved = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "query",
            "Reload CHI Checklist associations after upload",
            query_config(
                "t_document_submitted_for_application",
                [
                    {"f_business_key": {"$eq": ref(app, "id")}},
                    {"f_business_type": {"$eq": "t_change_home_information_app"}},
                ],
                multiple=True,
                appends=("f_lastest_files", "f_details", "f_details.f_files"),
            ),
        ),
    )
    verify = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "script",
            "Verify CHI Checklist Latest and Details",
            {
                "arguments": [
                    {"name": "checklist", "value": ref(parse, "checklist")},
                    {"name": "templates", "value": ref(catalog)},
                    {"name": "items", "value": ref(saved)},
                    {
                        "name": "requestCreatedAt",
                        "value": "{{$context.data.createdAt}}",
                    },
                ],
                "content": CHECKLIST_POST_LOOP_VERIFY_SCRIPT,
                "timeout": 3000,
                "continue": False,
            },
        ),
    )
    gate = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "condition",
            "CHI Checklist associations saved",
            truth_condition(ref(verify, "ready")),
        ),
    )
    failed = _adopt_node(
        workflow,
        create_node(
            api,
            wid,
            "update",
            "Mark CHI Checklist association failed",
            update_config(
                "t_api_request_staging",
                "{{$context.data.id}}",
                staging_failed_values(ref(verify, "block_reason")),
            ),
        ),
    )
    link(api, loop, saved)
    link(api, saved, verify)
    link(api, verify, gate)
    link(api, gate, failed, branch_index=0)
    link(api, gate, stage_reload, branch_index=1)
    ensure_operator_clone_pending_guard(api, workflow)


def _replace_update_values(
    api: RootNocoBaseApi, node: Mapping[str, Any], values: Mapping[str, Any]
) -> None:
    config = dict(node.get("config") or {})
    params = dict(config.get("params") or {})
    params["values"] = dict(values)
    config["params"] = params
    api.update_node(int(node["id"]), {"config": config})


def ensure_deterministic_checklist_selector(
    api: RootNocoBaseApi, workflow: dict[str, Any], *, updating: bool
) -> None:
    """Make Create/Update and post-loop readback choose the same template."""
    loop = node_by_title(
        workflow,
        "Apply changed CHI Checklist files"
        if updating
        else "Apply Checklist files to native CHI records",
    )
    # Both Create and Update must resolve Checklist rows against the final
    # post-snapshot reload.  The enabled legacy Update graph also contains an
    # earlier ``Resolve linked CHI`` node; using it here produces a different
    # office/business-key reference from the validator and post-loop verifier.
    application = node_by_title(workflow, "Reload CHI after native snapshot")
    candidate_title = (
        "Resolve changed CHI Checklist position_code"
        if updating
        else "Resolve checklist template by position_code"
    )
    selector_title = (
        CHECKLIST_TEMPLATE_SELECT_TITLE
        if updating
        else CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE
    )
    item_title = (
        "Find changed CHI Checklist item"
        if updating
        else "Find native CHI checklist item"
    )
    create_title = (
        "Create changed CHI item"
        if updating
        else "Create CHI checklist item + files"
    )
    candidates = node_by_title(workflow, candidate_title)
    candidate_config = checklist_template_candidates_config(loop, application)
    api.update_node(int(candidates["id"]), {"config": candidate_config})
    candidates["config"] = candidate_config
    found = [
        row for row in workflow.get("nodes") or [] if row.get("title") == selector_title
    ]
    if len(found) > 1:
        raise ApiError(f"Duplicate CHI Checklist selector {selector_title!r}")
    selector_config = {
        "arguments": [{"name": "templates", "value": ref(candidates)}],
        "content": CHECKLIST_TEMPLATE_SELECT_SCRIPT,
        "timeout": 3000,
        "continue": False,
    }
    if found:
        selector = found[0]
        api.update_node(int(selector["id"]), {"config": selector_config})
        selector["config"] = selector_config
    else:
        selector = _adopt_node(
            workflow,
            create_node(
                api,
                int(workflow["id"]),
                "script",
                selector_title,
                selector_config,
            ),
        )
    item = node_by_title(workflow, item_title)
    item_config = query_config(
        "t_document_submitted_for_application",
        [
            {"f_business_key": {"$eq": ref(application, "id")}},
            {"fk_document_checklist": {"$eq": ref(selector, "id")}},
            {"f_business_type": {"$eq": "t_change_home_information_app"}},
        ],
    )
    api.update_node(int(item["id"]), {"config": item_config})
    item["config"] = item_config
    create_item = node_by_title(workflow, create_title)
    create_config = dict(create_item.get("config") or {})
    create_params = dict(create_config.get("params") or {})
    create_values = dict(create_params.get("values") or {})
    create_values["fk_document_checklist"] = ref(selector, "id")
    create_params["values"] = create_values
    create_config["params"] = create_params
    api.update_node(int(create_item["id"]), {"config": create_config})
    create_item["config"] = create_config
    exists_title = (
        "Changed CHI Checklist item exists"
        if updating
        else "Native CHI checklist item exists"
    )
    template_exists = node_by_title(workflow, "CHI Checklist code exists")
    item_exists = node_by_title(workflow, exists_title)
    link(api, loop, candidates, branch_index=0)
    link(api, candidates, selector)
    link(api, selector, template_exists)
    attachment = node_by_title(workflow, "Load CHI Checklist upload")
    link(api, template_exists, attachment, branch_index=1)
    link(api, item, item_exists)


def patch_v07_adapt_revision(
    api: RootNocoBaseApi, draft: Mapping[str, Any], *, updating: bool
) -> dict[str, Any]:
    """Refresh CHI overlay JS, clone wait, and persist Staging failure reasons."""
    ensure_checklist_input_guard(api, dict(draft), updating=updating)
    draft = api.get_workflow(int(draft["id"]))
    ensure_snapshot_wait_graph(api, dict(draft), updating=updating)
    draft = api.get_workflow(int(draft["id"]))
    ensure_contact_clone_wait_graph(api, dict(draft), updating=updating)
    draft = api.get_workflow(int(draft["id"]))
    ensure_deterministic_checklist_selector(api, dict(draft), updating=updating)
    draft = api.get_workflow(int(draft["id"]))
    normalize = node_by_title(draft, "Project guarded CHI page changes")
    normalize_config = dict(normalize.get("config") or {})
    normalize_config["content"] = projection_script()
    api.update_node(int(normalize["id"]), {"config": normalize_config})

    verify = node_by_title(draft, "Verify CHI Checklist Latest and Details")
    verify_config = dict(verify.get("config") or {})
    verify_config["content"] = CHECKLIST_POST_LOOP_VERIFY_SCRIPT
    api.update_node(int(verify["id"]), {"config": verify_config})

    refresh = node_by_title(
        draft,
        "Resolve linked CHI" if updating else "Reload CHI after native snapshot",
    )
    intake_or_parent = node_by_title(
        draft,
        "Resolve original CREATE staging record"
        if updating
        else "Create Intake (fixed CHI type + Home Record)",
    )
    guarded = node_by_title(draft, "Mark guarded CHI staging failed")
    guarded_values = ((guarded.get("config") or {}).get("params") or {}).get(
        "values"
    ) or {}
    _replace_update_values(
        api,
        guarded,
        staging_failed_values(
            ref(normalize, "block_reason"),
            f_application_id=guarded_values.get("f_application_id")
            or ref(refresh, "id"),
            f_intake_id=guarded_values.get("f_intake_id")
            or (
                ref(intake_or_parent, "f_intake_id")
                if updating
                else ref(intake_or_parent, "id")
            ),
        ),
    )
    _replace_update_values(
        api,
        node_by_title(draft, "Mark CHI Checklist code failed"),
        staging_failed_values("chi_checklist_template_not_resolved"),
    )
    _replace_update_values(
        api,
        node_by_title(draft, "Mark CHI Checklist upload failed"),
        staging_failed_values("chi_checklist_attachment_not_resolved"),
    )
    _replace_update_values(
        api,
        node_by_title(draft, "Mark CHI Checklist association failed"),
        staging_failed_values(ref(verify, "block_reason")),
    )
    if not updating:
        native_fail = node_by_title(draft, "Mark failed + backfill Intake ID")
        native_values = ((native_fail.get("config") or {}).get("params") or {}).get(
            "values"
        ) or {}
        _replace_update_values(
            api,
            native_fail,
            staging_failed_values(
                "native_chi_not_created",
                f_intake_id=native_values.get("f_intake_id")
                or ref(intake_or_parent, "id"),
            ),
        )
    reread = api.get_workflow(int(draft["id"]))
    validate_revision_graph(reread, updating=updating)
    return reread


def apply_v07_adapt(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    """Revise the enabled CHI Staging pair on 13001 without touching native CHI."""
    ensure_staging_error_field(api, create_if_missing=True)
    sources = source_summary(api)
    drafts: list[tuple[dict[str, Any], dict[str, Any]]] = []
    enabled: list[dict[str, Any]] = []
    try:
        for source in sources:
            updating = source["title"] == UPDATE_TITLE
            draft = draft_revision(api, source)
            patched = patch_v07_adapt_revision(api, draft, updating=updating)
            drafts.append((source, patched))
        for source, draft in drafts:
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={source['id']}",
                {"enabled": False},
            )
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={draft['id']}",
                {"enabled": True},
            )
            checked = api.get_workflow(int(draft["id"]))
            if not checked.get("enabled") or api.get_workflow(
                int(source["id"])
            ).get("enabled"):
                raise ApiError("CHI v0.7 revision did not swap the enabled source")
            enabled.append(checked)
        return enabled
    except Exception:
        for source, draft in drafts:
            try:
                api.request(
                    "POST",
                    f"/api/workflows:update?filterByTk={draft['id']}",
                    {"enabled": False},
                )
            except Exception:
                pass
            try:
                api.request(
                    "POST",
                    f"/api/workflows:update?filterByTk={source['id']}",
                    {"enabled": True},
                )
            except Exception:
                pass
        raise


def workflow_execution_count(api: RootNocoBaseApi, workflow_id: int) -> int:
    """Count executions exactly without relying on possibly stale workflow stats."""
    total = 0
    page = 1
    while True:
        query = urllib.parse.urlencode(
            {
                "filter[workflowId]": str(workflow_id),
                "page": page,
                "pageSize": 100,
            }
        )
        rows = api.request("GET", "/api/executions:list?" + query) or []
        if not isinstance(rows, list):
            raise ApiError("Workflow execution list returned an unexpected payload")
        total += len(rows)
        if len(rows) < 100:
            return total
        page += 1
        if page > 1000:
            raise ApiError("Workflow execution count exceeded the safety page limit")


def validate_disabled_activation_candidate(
    api: RootNocoBaseApi,
    revision_id: int,
    *,
    sources: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Read-only validation for one explicit, disabled, execution-free revision."""
    active = source_summary(api) if sources is None else sources
    draft = api.get_workflow(revision_id)
    source = next(
        (
            row
            for row in active
            if row.get("title") == draft.get("title")
            and row.get("key") == draft.get("key")
        ),
        None,
    )
    if source is None or int(source["id"]) == int(revision_id):
        raise ApiError("CHI candidate key/title does not match an old active source")
    if draft.get("enabled") or draft.get("executed"):
        raise ApiError("CHI activation candidate must be disabled and unexecuted")
    executions = workflow_execution_count(api, revision_id)
    if executions:
        raise ApiError("CHI activation candidate has execution history")
    updating = draft.get("title") == UPDATE_TITLE
    validate_revision_graph(draft, updating=updating)
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Old CHI source changed during candidate validation")
    return {
        "workflow": draft,
        "source": source,
        "node_count": len(draft.get("nodes") or []),
        "execution_count": executions,
    }


def reusable_safe_candidate(
    api: RootNocoBaseApi, source: Mapping[str, Any], *, updating: bool
) -> dict[str, Any] | None:
    """Find exactly one execution-free candidate created by safe prepare."""
    source_id = int(source["id"])
    query = urllib.parse.urlencode(
        {"filter[title]": str(source["title"]), "pageSize": 100}
    )
    rows = api.request("GET", "/api/workflows:list?" + query) or []
    selector_title = (
        CHECKLIST_TEMPLATE_SELECT_TITLE
        if updating
        else CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE
    )
    required_markers = {
        "Project guarded CHI page changes",
        SNAPSHOT_PLAN_TITLE,
        SNAPSHOT_WAIT_TITLE,
        CONTACT_CLONE_PLAN_TITLE,
        selector_title,
    }
    candidates: list[dict[str, Any]] = []
    for row in rows:
        row_id = int(row.get("id") or 0)
        if (
            row.get("title") != source.get("title")
            or row.get("key") != source.get("key")
            # Revision IDs are monotonic. Older disabled same-key revisions
            # are retired history, not interrupted candidates from the safe
            # prepare that starts from the current active source.
            or row_id <= source_id
            or row.get("enabled")
        ):
            continue
        draft = api.get_workflow(row_id)
        titles = {str(node.get("title")) for node in draft.get("nodes") or []}
        marker_overlap = titles & required_markers
        if not marker_overlap:
            continue
        if marker_overlap != required_markers:
            raise ApiError("Partially prepared safe CHI candidate needs manual review")
        if not has_expected_chi_trigger(draft, updating=updating):
            raise ApiError("Prepared safe CHI candidate trigger was tampered")
        if draft.get("executed") or workflow_execution_count(api, int(draft["id"])):
            raise ApiError("Prepared safe CHI candidate has execution history")
        candidates.append(draft)
    if len(candidates) > 1:
        raise ApiError("Multiple reusable safe CHI candidates require manual review")
    return candidates[0] if candidates else None


def repair_disabled_safe_revision(
    api: RootNocoBaseApi, revision_id: int
) -> dict[str, Any]:
    """Explicitly repair one disabled execution-free candidate; never activate it."""
    sources = source_summary(api)
    draft = api.get_workflow(revision_id)
    source = next(
        (
            row
            for row in sources
            if row.get("title") == draft.get("title")
            and row.get("key") == draft.get("key")
        ),
        None,
    )
    if source is None or int(source["id"]) == int(revision_id):
        raise ApiError(
            "CHI repair candidate key/title does not match old active source"
        )
    updating = draft.get("title") == UPDATE_TITLE
    if draft.get("enabled") or draft.get("executed"):
        raise ApiError("CHI repair candidate must be disabled and unexecuted")
    if not has_expected_chi_trigger(draft, updating=updating):
        raise ApiError("CHI repair candidate trigger was tampered")
    if workflow_execution_count(api, revision_id):
        raise ApiError("CHI repair candidate has execution history")
    titles = {str(node.get("title")) for node in draft.get("nodes") or []}
    if "Project guarded CHI page changes" not in titles:
        raise ApiError("CHI repair candidate is not a controlled guarded revision")
    patched = patch_v07_adapt_revision(api, draft, updating=updating)
    checked = validate_disabled_activation_candidate(
        api, int(patched["id"]), sources=sources
    )
    if not api.get_workflow(int(source["id"])).get("enabled"):
        raise ApiError("Old CHI source changed during disabled repair")
    return checked


def prepare_disabled_safe_revisions(api: RootNocoBaseApi) -> list[dict[str, Any]]:
    """Create and fully validate two disabled revisions; never activate them."""
    ensure_staging_error_field(api, create_if_missing=True)
    sources = source_summary(api)
    prepared: list[dict[str, Any]] = []
    for source in sources:
        updating = source["title"] == UPDATE_TITLE
        draft = reusable_safe_candidate(api, source, updating=updating)
        if draft is None:
            draft = draft_revision(api, source)
        patched = patch_v07_adapt_revision(api, draft, updating=updating)
        checked = validate_disabled_activation_candidate(
            api, int(patched["id"]), sources=sources
        )
        prepared.append(checked)
    if any(not api.get_workflow(int(row["id"])).get("enabled") for row in sources):
        raise ApiError("Old CHI source was not preserved after disabled preparation")
    return prepared


def activate_validated_revision_pair(
    api: RootNocoBaseApi, revision_ids: list[int]
) -> list[dict[str, Any]]:
    """Explicitly swap a reviewed Create/Update pair, rolling back on any error."""
    if len(revision_ids) != 2 or len(set(revision_ids)) != 2:
        raise ApiError("Activation requires two distinct CHI revision IDs")
    sources = source_summary(api)
    candidates = [
        validate_disabled_activation_candidate(api, rid, sources=sources)
        for rid in revision_ids
    ]
    expected_titles = {CREATE_TITLE, UPDATE_TITLE}
    if {row["workflow"].get("title") for row in candidates} != expected_titles:
        raise ApiError("Activation requires one CHI Create and one CHI Update revision")
    by_title = {row["workflow"]["title"]: row for row in candidates}
    ordered = [by_title[CREATE_TITLE], by_title[UPDATE_TITLE]]
    source_counts = {
        int(row["source"]["id"]): workflow_execution_count(
            api, int(row["source"]["id"])
        )
        for row in ordered
    }
    try:
        for row in ordered:
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={row['source']['id']}",
                {"enabled": False},
            )
        for row in ordered:
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={row['workflow']['id']}",
                {"enabled": True},
            )
        result: list[dict[str, Any]] = []
        for row in ordered:
            source = api.get_workflow(int(row["source"]["id"]))
            active = api.get_workflow(int(row["workflow"]["id"]))
            active_executions = workflow_execution_count(api, int(active["id"]))
            if (
                source.get("enabled")
                or not active.get("enabled")
                or len(active.get("nodes") or []) != row["node_count"]
                or active_executions != row["execution_count"]
                or workflow_execution_count(api, int(source["id"]))
                != source_counts[int(source["id"])]
            ):
                raise ApiError("CHI revision activation readback validation failed")
            result.append(
                {
                    "title": active["title"],
                    "old_revision_id": int(source["id"]),
                    "new_revision_id": int(active["id"]),
                    "node_count": len(active.get("nodes") or []),
                    "execution_count": active_executions,
                }
            )
        return result
    except Exception as exc:
        rollback_errors: list[str] = []
        for row in ordered:
            try:
                api.request(
                    "POST",
                    f"/api/workflows:update?filterByTk={row['workflow']['id']}",
                    {"enabled": False},
                )
            except Exception as rollback_exc:  # pragma: no cover - transport guard
                rollback_errors.append(str(rollback_exc))
        for row in ordered:
            try:
                api.request(
                    "POST",
                    f"/api/workflows:update?filterByTk={row['source']['id']}",
                    {"enabled": True},
                )
            except Exception as rollback_exc:  # pragma: no cover - transport guard
                rollback_errors.append(str(rollback_exc))
        if rollback_errors:
            raise ApiError(
                f"CHI activation failed ({exc}); rollback errors: "
                + "; ".join(rollback_errors)
            ) from exc
        if any(
            not api.get_workflow(int(row["source"]["id"])).get("enabled")
            for row in ordered
        ):
            raise ApiError(
                f"CHI activation failed ({exc}); old active rollback not verified"
            ) from exc
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--create-disabled-drafts", action="store_true")
    parser.add_argument("--patch-disabled-create-provenance", type=int)
    parser.add_argument("--patch-disabled-update-parent-lookup", type=int)
    parser.add_argument("--patch-disabled-checklist-preflight", type=int)
    parser.add_argument("--patch-disabled-latest-relation", type=int)
    parser.add_argument("--patch-disabled-post-loop-guard", type=int)
    parser.add_argument("--refresh-disabled-post-loop-script", type=int)
    parser.add_argument("--refresh-disabled-projection", type=int)
    parser.add_argument("--apply-v07-adapt", action="store_true")
    parser.add_argument("--prepare-disabled-safe", action="store_true")
    parser.add_argument(
        "--repair-disabled-safe", type=int, action="append", default=[]
    )
    parser.add_argument(
        "--validate-disabled-revision", type=int, action="append", default=[]
    )
    parser.add_argument(
        "--activate-disabled-pair",
        type=int,
        nargs=2,
        metavar=("CREATE_ID", "UPDATE_ID"),
    )
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = RootNocoBaseApi(args.base_url, token)
    sources = source_summary(api)
    for workflow in sources:
        print(
            "source_id=",
            workflow["id"],
            "title=",
            workflow["title"],
            "node_count=",
            len(workflow.get("nodes") or []),
        )
    print("page_only_fields=", ",".join(CHI_PAGE_FIELDS))
    print("native_chi_workflows_untouched=yes")
    safe_modes = sum(
        bool(value)
        for value in (
            args.prepare_disabled_safe,
            args.repair_disabled_safe,
            args.validate_disabled_revision,
            args.activate_disabled_pair,
        )
    )
    legacy_mode = any(
        (
            args.apply,
            args.create_disabled_drafts,
            args.patch_disabled_create_provenance,
            args.patch_disabled_update_parent_lookup,
            args.patch_disabled_checklist_preflight,
            args.patch_disabled_latest_relation,
            args.patch_disabled_post_loop_guard,
            args.refresh_disabled_post_loop_script,
            args.refresh_disabled_projection,
            args.apply_v07_adapt,
        )
    )
    if safe_modes > 1 or (safe_modes and legacy_mode):
        raise ApiError("Safe prepare/validate/activate modes cannot be combined")
    target = args.base_url.rstrip("/")
    if (
        args.prepare_disabled_safe
        or args.repair_disabled_safe
        or args.activate_disabled_pair
    ) and target != "http://119.91.104.211:13001/cmtf2":
        raise ApiError("CHI safe mutation modes are restricted to 13001")
    if args.repair_disabled_safe:
        for revision_id in args.repair_disabled_safe:
            row = repair_disabled_safe_revision(api, revision_id)
            print(
                "repaired_disabled_revision_id=",
                row["workflow"]["id"],
                "title=",
                row["workflow"]["title"],
                "enabled=",
                row["workflow"].get("enabled"),
                "node_count=",
                row["node_count"],
                "execution_count=",
                row["execution_count"],
                "old_active_id=",
                row["source"]["id"],
            )
        print("mode=repaired-disabled-safe;activation=not-performed")
        return 0
    if args.prepare_disabled_safe:
        prepared = prepare_disabled_safe_revisions(api)
        for row in prepared:
            print(
                "disabled_revision_id=",
                row["workflow"]["id"],
                "title=",
                row["workflow"]["title"],
                "node_count=",
                row["node_count"],
                "execution_count=",
                row["execution_count"],
                "old_active_id=",
                row["source"]["id"],
            )
        print("mode=prepared-disabled-safe;activation=not-performed")
        return 0
    if args.validate_disabled_revision:
        sources = source_summary(api)
        for revision_id in args.validate_disabled_revision:
            row = validate_disabled_activation_candidate(
                api, revision_id, sources=sources
            )
            print(
                "validated_revision_id=",
                row["workflow"]["id"],
                "title=",
                row["workflow"]["title"],
                "enabled=",
                row["workflow"].get("enabled"),
                "node_count=",
                row["node_count"],
                "execution_count=",
                row["execution_count"],
                "old_active_id=",
                row["source"]["id"],
            )
        print("mode=validated-disabled-read-only;activation=not-performed")
        return 0
    if args.activate_disabled_pair:
        activated = activate_validated_revision_pair(
            api, list(args.activate_disabled_pair)
        )
        for row in activated:
            print(
                "activated_revision_id=",
                row["new_revision_id"],
                "title=",
                row["title"],
                "old_revision_id=",
                row["old_revision_id"],
                "old_enabled=False",
                "new_enabled=True",
                "node_count=",
                row["node_count"],
                "execution_count=",
                row["execution_count"],
            )
        print("mode=activated-validated-pair;rollback=armed")
        return 0
    if args.create_disabled_drafts and args.apply:
        raise ApiError("Draft preparation and activation cannot be combined")
    if args.patch_disabled_create_provenance:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.refresh_disabled_projection
            or args.patch_disabled_update_parent_lookup
            or args.patch_disabled_checklist_preflight
            or args.patch_disabled_latest_relation
            or args.patch_disabled_post_loop_guard
            or args.refresh_disabled_post_loop_script
        ):
            raise ApiError("Disabled provenance patch cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI disabled provenance patch is restricted to 13001")
        draft = patch_disabled_create_provenance(
            api, args.patch_disabled_create_provenance
        )
        print(
            "patched_disabled_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
            "node_count=",
            len(draft.get("nodes") or []),
        )
        print("mode=disabled-draft-provenance-only;activation=not-performed")
        return 0
    if args.patch_disabled_update_parent_lookup:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.refresh_disabled_projection
            or args.patch_disabled_checklist_preflight
            or args.patch_disabled_latest_relation
            or args.patch_disabled_post_loop_guard
            or args.refresh_disabled_post_loop_script
        ):
            raise ApiError("Disabled UPDATE parent patch cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI disabled UPDATE parent patch is restricted to 13001")
        draft = patch_disabled_update_parent_lookup(
            api, args.patch_disabled_update_parent_lookup
        )
        print(
            "patched_disabled_update_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
            "node_count=",
            len(draft.get("nodes") or []),
        )
        print("mode=disabled-draft-update-parent-only;activation=not-performed")
        return 0
    if args.patch_disabled_checklist_preflight:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.refresh_disabled_projection
            or args.patch_disabled_latest_relation
            or args.patch_disabled_post_loop_guard
            or args.refresh_disabled_post_loop_script
        ):
            raise ApiError("Disabled Checklist preflight patch cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI Checklist preflight patch is restricted to 13001")
        draft = patch_disabled_checklist_preflight(
            api, args.patch_disabled_checklist_preflight
        )
        print(
            "patched_disabled_checklist_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
            "node_count=",
            len(draft.get("nodes") or []),
        )
        print("mode=disabled-draft-checklist-only;activation=not-performed")
        return 0
    if args.patch_disabled_latest_relation:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.refresh_disabled_projection
            or args.patch_disabled_create_provenance
            or args.patch_disabled_update_parent_lookup
            or args.patch_disabled_checklist_preflight
            or args.patch_disabled_post_loop_guard
            or args.refresh_disabled_post_loop_script
        ):
            raise ApiError("Disabled Latest relation patch cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI Latest relation patch is restricted to 13001")
        draft = patch_disabled_latest_relation(
            api, args.patch_disabled_latest_relation
        )
        print(
            "patched_disabled_latest_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
            "node_count=",
            len(draft.get("nodes") or []),
        )
        print("mode=disabled-draft-latest-only;activation=not-performed")
        return 0
    if args.patch_disabled_post_loop_guard:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.refresh_disabled_projection
            or args.patch_disabled_create_provenance
            or args.patch_disabled_update_parent_lookup
            or args.patch_disabled_checklist_preflight
            or args.patch_disabled_latest_relation
            or args.refresh_disabled_post_loop_script
        ):
            raise ApiError("Disabled Checklist readback patch cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI Checklist readback patch is restricted to 13001")
        draft = patch_disabled_post_loop_guard(
            api, args.patch_disabled_post_loop_guard
        )
        print(
            "patched_disabled_readback_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
            "node_count=",
            len(draft.get("nodes") or []),
        )
        print("mode=disabled-draft-readback-only;activation=not-performed")
        return 0
    if args.refresh_disabled_post_loop_script:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.refresh_disabled_projection
            or args.patch_disabled_create_provenance
            or args.patch_disabled_update_parent_lookup
            or args.patch_disabled_checklist_preflight
            or args.patch_disabled_latest_relation
            or args.patch_disabled_post_loop_guard
        ):
            raise ApiError("Disabled verifier JS refresh cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI verifier JS refresh is restricted to 13001")
        draft = refresh_disabled_post_loop_script(
            api, args.refresh_disabled_post_loop_script
        )
        print(
            "refreshed_disabled_readback_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
            "node_count=",
            len(draft.get("nodes") or []),
        )
        print("mode=disabled-draft-verifier-js-only;activation=not-performed")
        return 0
    if args.refresh_disabled_projection:
        if (
            args.apply
            or args.create_disabled_drafts
            or args.patch_disabled_update_parent_lookup
            or args.patch_disabled_checklist_preflight
            or args.patch_disabled_latest_relation
            or args.patch_disabled_post_loop_guard
            or args.refresh_disabled_post_loop_script
        ):
            raise ApiError("Disabled JS refresh cannot be combined")
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI disabled JS refresh is restricted to 13001")
        draft = refresh_disabled_projection(api, args.refresh_disabled_projection)
        print(
            "refreshed_disabled_revision_id=",
            draft["id"],
            "enabled=",
            draft.get("enabled"),
        )
        print("mode=disabled-draft-js-only;activation=not-performed")
        return 0
    if args.create_disabled_drafts:
        if args.base_url.rstrip("/") != "http://119.91.104.211:13001/cmtf2":
            raise ApiError("CHI disabled draft preparation is restricted to 13001")
        drafts = build_disabled_revisions(api)
        for draft in drafts:
            print(
                "disabled_revision_id=",
                draft["id"],
                "title=",
                draft["title"],
                "node_count=",
                len(draft.get("nodes") or []),
                "enabled=",
                draft.get("enabled"),
            )
        print("mode=disabled-drafts-only;activation=not-performed")
        return 0
    if args.apply_v07_adapt:
        raise ApiError(
            "Direct CHI prepare-and-activate is disabled; use "
            "--prepare-disabled-safe, --validate-disabled-revision, then "
            "--activate-disabled-pair"
        )
    if not args.apply:
        print("mode=dry-run")
        return 0
    raise ApiError(
        "Apply is disabled until guarded node graph and Details-before-Latest "
        "regression tests are reviewed; this script never silently changes 13001"
    )


if __name__ == "__main__":
    raise SystemExit(main())
