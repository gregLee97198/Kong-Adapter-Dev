#!/usr/bin/env python3
"""Safely revise Home-bound application bridge workflows.

The two bridge graphs deliberately touch only ``t_api_request_staging``.
They never update an Intake, Home Record, or business application row.

The command is read-only by default.  ``--apply`` performs an all-target
preflight, creates disabled revisions under the exact reviewed workflow keys,
rebuilds and validates every graph, and only then enables the new revisions.
If any step fails, every new revision is disabled and the original enabled
revisions are restored.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    RootNocoBaseApi,
    create_node,
    link,
    ref,
    set_enabled,
)
from extend_nocobase_staging_relations import ApiError
from workflow_source_condition import destroy_workflow_nodes


def context(field: str) -> str:
    return "{{$context.data." + field + "}}"


@dataclass(frozen=True)
class BridgeTarget:
    key: str
    application_type: str
    create_api_type: str
    intake_type_id: int
    application_collection: str
    application_intake_fk: str
    created_title: str
    created_source_key: str
    received_title: str
    received_source_key: str
    application_condition: Mapping[str, Any]


TARGETS: tuple[BridgeTarget, ...] = (
    BridgeTarget(
        key="self_withdraw",
        application_type="self_withdraw",
        create_api_type="create_intake_for_self_withdraw",
        intake_type_id=379733733081088,
        application_collection="t_self_withdraw_licence_application",
        application_intake_fk="fk_intake_form",
        created_title=("API Bridge — Self-withdraw Application Created to Staging v1"),
        created_source_key="5c5gq6jo3h6",
        received_title=("API Bridge — Self-withdraw Intake Completed to Received v1"),
        received_source_key="l206xob0dbr",
        application_condition={"$and": [{"f_closure_workflow_type": {"$eq": "self"}}]},
    ),
    BridgeTarget(
        key="revoke_licence",
        application_type="revoke_licence",
        create_api_type="create_intake_for_revoke_licence",
        intake_type_id=379733764538368,
        application_collection="t_self_withdraw_licence_application",
        application_intake_fk="fk_intake_form",
        created_title=("API Bridge — Revoke Licence Application Created to Staging v1"),
        created_source_key="arvhul2cg5u",
        received_title=("API Bridge — Revoke Licence Intake Completed to Received v1"),
        received_source_key="15mecmtt7nw",
        application_condition={
            "$and": [{"f_closure_workflow_type": {"$eq": "revoke"}}]
        },
    ),
    BridgeTarget(
        key="specific_hour",
        application_type="specific_hour",
        create_api_type="create_intake_for_specific_hour",
        intake_type_id=378239147442176,
        application_collection="t_specific_hour_app",
        application_intake_fk="fk_intake_form",
        created_title=("API Bridge — Specific Hour Application Created to Staging v1"),
        created_source_key="xgd7hu04ocb",
        received_title=("API Bridge — Specific Hour Intake Completed to Received v1"),
        received_source_key="lsiypf4jl1a",
        application_condition={},
    ),
    BridgeTarget(
        key="responsible_person",
        application_type="responsible_person",
        create_api_type="create_intake_for_rp",
        intake_type_id=378414943305728,
        application_collection="t_rp_application",
        application_intake_fk="fk_intake_id",
        created_title="API Bridge — RP Application Created to Staging v1",
        created_source_key="g62jjm4yhjm",
        received_title=("API Bridge — RP Intake Completed to Received v1"),
        received_source_key="4g06ur8gpvm",
        application_condition={},
    ),
    BridgeTarget(
        key="change_home_manager",
        application_type="change_home_manager",
        create_api_type="create_intake_for_change_home_manager",
        intake_type_id=383004177793024,
        application_collection="t_change_monitoring_base",
        application_intake_fk="fk_intake_form",
        created_title=(
            "API Bridge — Change Home Manager Created to Staging v1"
        ),
        created_source_key="rf9w6a9ssno",
        received_title=(
            "API Bridge — Change Home Manager Intake Completed to Received v1"
        ),
        received_source_key="v30wzsx6kw2",
        application_condition={
            "$and": [{"fk_intake_type": {"$eq": 383004177793024}}]
        },
    ),
    BridgeTarget(
        key="change_beds",
        application_type="change_beds",
        create_api_type="create_intake_for_change_beds",
        intake_type_id=383004198764544,
        application_collection="t_change_monitoring_base",
        application_intake_fk="fk_intake_form",
        created_title="API Bridge — Change Beds Created to Staging v1",
        created_source_key="vqy9oir6n2v",
        received_title=(
            "API Bridge — Change Beds Intake Completed to Received v1"
        ),
        received_source_key="sxfsyh0uocy",
        application_condition={
            "$and": [{"fk_intake_type": {"$eq": 383004198764544}}]
        },
    ),
    BridgeTarget(
        key="change_operation_mode",
        application_type="change_operation_mode",
        create_api_type="create_intake_for_change_operation_mode",
        intake_type_id=383004215541760,
        application_collection="t_change_monitoring_base",
        application_intake_fk="fk_intake_form",
        created_title=(
            "API Bridge — Change Operation Mode Created to Staging v1"
        ),
        created_source_key="tzxd3e32ils",
        received_title=(
            "API Bridge — Change Operation Mode Intake Completed to Received v1"
        ),
        received_source_key="ay7xmr703qr",
        application_condition={
            "$and": [{"fk_intake_type": {"$eq": 383004215541760}}]
        },
    ),
    BridgeTarget(
        key="change_directors",
        application_type="change_directors",
        create_api_type="create_intake_for_change_directors",
        intake_type_id=383302631882752,
        application_collection="t_change_monitoring_base",
        application_intake_fk="fk_intake_form",
        created_title="API Bridge — Change Directors Created to Staging v1",
        created_source_key="lv58nwapn4t",
        received_title=(
            "API Bridge — Change Directors Intake Completed to Received v1"
        ),
        received_source_key="lwd0fiw5qta",
        application_condition={
            "$and": [{"fk_intake_type": {"$eq": 383302631882752}}]
        },
    ),
    BridgeTarget(
        key="change_nurse_in_charge",
        application_type="change_nurse_in_charge",
        create_api_type="create_intake_for_change_nurse_in_charge",
        intake_type_id=383004234416128,
        application_collection="t_change_monitoring_base",
        application_intake_fk="fk_intake_form",
        created_title=(
            "API Bridge — Change Nurse-in-Charge Created to Staging v1"
        ),
        created_source_key="1u4vc8irzoh",
        received_title=(
            "API Bridge — Change Nurse-in-Charge Intake Completed to Received v1"
        ),
        received_source_key="fgd6sjscz4x",
        application_condition={
            "$and": [{"fk_intake_type": {"$eq": 383004234416128}}]
        },
    ),
)


def created_workflow_config(target: BridgeTarget) -> dict[str, Any]:
    return {
        "mode": 1,
        "appends": [],
        "changed": [],
        "condition": dict(target.application_condition),
        "collection": target.application_collection,
    }


def received_workflow_config(target: BridgeTarget) -> dict[str, Any]:
    # mode=2 + changed is NocoBase's update-only, changed-field trigger.  The
    # Accepted filter and CAS below are still required for retry/concurrency.
    return {
        "mode": 2,
        "appends": [],
        "changed": ["f_approval_status"],
        "condition": {
            "$and": [
                {"fk_intake_type": {"$eq": target.intake_type_id}},
                {"f_approval_status": {"$eq": "4"}},
            ]
        },
        "collection": "t_intake_form",
    }


ConfigBuilder = Callable[[Mapping[str, Mapping[str, Any]]], dict[str, Any]]


@dataclass(frozen=True)
class NodePlan:
    name: str
    node_type: str
    title: str
    config: ConfigBuilder
    upstream: str | None = None
    branch_index: int | None = None


@dataclass(frozen=True)
class WorkflowPlan:
    title: str
    source_key: str
    config: Mapping[str, Any]
    nodes: tuple[NodePlan, ...]


def _query_config(
    collection: str,
    filters: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    return {
        "collection": collection,
        "multiple": False,
        "params": {
            "filter": {"$and": [dict(item) for item in filters]},
            "sort": [],
            "page": 1,
            "pageSize": 1,
            "appends": [],
        },
    }


def _exists_config(node: Mapping[str, Any], *, reject_on_false: bool) -> dict[str, Any]:
    return {
        "rejectOnFalse": reject_on_false,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {"calculator": "gt", "operands": [ref(node, "id"), 0]}
                ],
            }
        },
    }


def _marker_config(intake: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "rejectOnFalse": False,
        "engine": "basic",
        "calculation": {
            "group": {
                "type": "and",
                "calculations": [
                    {
                        "calculator": "notEqual",
                        "operands": [
                            ref(intake, "f_api_create_staging_id"),
                            None,
                        ],
                    },
                    {
                        "calculator": "notEqual",
                        "operands": [
                            ref(intake, "f_api_create_staging_id"),
                            "",
                        ],
                    },
                ],
            }
        },
    }


def _update_config(
    collection: str,
    filters: Sequence[Mapping[str, Any]],
    values: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "collection": collection,
        "params": {
            "filter": {"$and": [dict(item) for item in filters]},
            "values": dict(values),
            "individualHooks": False,
        },
    }


def build_created_plan(target: BridgeTarget) -> WorkflowPlan:
    def intake_query(_: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        return _query_config(
            "t_intake_form",
            [{"id": {"$eq": context(target.application_intake_fk)}}],
        )

    def intake_exists(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        return _exists_config(nodes["intake"], reject_on_false=True)

    def marker(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        return _marker_config(nodes["intake"])

    def marked_staging(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        intake = nodes["intake"]
        return _query_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(intake, "f_api_create_staging_id")}},
                {"f_source_system": {"$ne": "CMTF"}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": target.create_api_type}},
                {"f_application_type": {"$eq": target.application_type}},
            ],
        )

    def marked_exists(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        # A marker is authoritative.  If its Staging row is missing/mismatched,
        # reject this execution instead of misclassifying it as CMTF-originated.
        return _exists_config(nodes["marked_staging"], reject_on_false=True)

    def backfill_marked(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        intake = nodes["intake"]
        staging = nodes["marked_staging"]
        return _update_config(
            "t_api_request_staging",
            [
                {"id": {"$eq": ref(staging, "id")}},
                {"f_source_system": {"$ne": "CMTF"}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": target.create_api_type}},
                {"f_application_type": {"$eq": target.application_type}},
            ],
            {
                "f_intake_id": ref(intake, "id"),
                "f_application_id": context("id"),
                "f_rch_id": ref(intake, "fk_intake_source_rch"),
                "f_office_code": ref(intake, "f_office_cd"),
            },
        )

    def cmtf_staging(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        intake = nodes["intake"]
        return _query_config(
            "t_api_request_staging",
            [
                {"f_source_system": {"$eq": "CMTF"}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": target.create_api_type}},
                {"f_application_type": {"$eq": target.application_type}},
                {
                    "$or": [
                        {"f_application_id": {"$eq": context("id")}},
                        {"f_intake_id": {"$eq": ref(intake, "id")}},
                    ]
                },
            ],
        )

    def cmtf_exists(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        return _exists_config(nodes["cmtf_staging"], reject_on_false=False)

    def create_cmtf(nodes: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        intake = nodes["intake"]
        return {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_request_event": "CREATE",
                    "f_api_type": target.create_api_type,
                    "f_application_type": target.application_type,
                    "f_status": "succeeded",
                    "f_application_status": "Accepted",
                    "f_office_code": ref(intake, "f_office_cd"),
                    "f_intake_id": ref(intake, "id"),
                    "f_application_id": context("id"),
                    "f_rch_id": ref(intake, "fk_intake_source_rch"),
                    "f_request_body": {"source": "cmtf_backfill"},
                },
                "appends": [],
            },
        }

    return WorkflowPlan(
        title=target.created_title,
        source_key=target.created_source_key,
        config=created_workflow_config(target),
        nodes=(
            NodePlan(
                "intake",
                "query",
                "Load linked Intake API provenance",
                intake_query,
            ),
            NodePlan(
                "intake_exists",
                "condition",
                "Linked Intake exists",
                intake_exists,
                upstream="intake",
            ),
            NodePlan(
                "marker",
                "condition",
                "Intake has API CREATE marker",
                marker,
                upstream="intake_exists",
                branch_index=1,
            ),
            NodePlan(
                "marked_staging",
                "query",
                "Load marked external CREATE staging",
                marked_staging,
                upstream="marker",
                branch_index=1,
            ),
            NodePlan(
                "marked_exists",
                "condition",
                "Marked external CREATE staging exists",
                marked_exists,
                upstream="marked_staging",
            ),
            NodePlan(
                "backfill_marked",
                "update",
                "Backfill marked CREATE staging IDs",
                backfill_marked,
                upstream="marked_exists",
                branch_index=1,
            ),
            NodePlan(
                "cmtf_staging",
                "query",
                "Resolve existing CMTF CREATE staging",
                cmtf_staging,
                upstream="marker",
                branch_index=0,
            ),
            NodePlan(
                "cmtf_exists",
                "condition",
                "Existing CMTF CREATE staging exists",
                cmtf_exists,
                upstream="cmtf_staging",
            ),
            NodePlan(
                "create_cmtf",
                "create",
                "Create CMTF staging at Accepted",
                create_cmtf,
                upstream="cmtf_exists",
                branch_index=0,
            ),
        ),
    )


def build_received_plan(target: BridgeTarget) -> WorkflowPlan:
    def application(_: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
        filters: list[Mapping[str, Any]] = [
            {target.application_intake_fk: {"$eq": context("id")}}
        ]
        if target.application_condition:
            filters.append(dict(target.application_condition))
        return _query_config(target.application_collection, filters)

    def application_exists(
        nodes: Mapping[str, Mapping[str, Any]],
    ) -> dict[str, Any]:
        return _exists_config(nodes["application"], reject_on_false=True)

    def accepted_staging(
        nodes: Mapping[str, Mapping[str, Any]],
    ) -> dict[str, Any]:
        _ = nodes
        return _query_config(
            "t_api_request_staging",
            [
                {"f_intake_id": {"$eq": context("id")}},
                {"f_request_event": {"$eq": "CREATE"}},
                {"f_api_type": {"$eq": target.create_api_type}},
                {"f_application_type": {"$eq": target.application_type}},
                {"f_application_status": {"$eq": "Accepted"}},
            ],
        )

    def accepted_exists(
        nodes: Mapping[str, Mapping[str, Any]],
    ) -> dict[str, Any]:
        return _exists_config(nodes["accepted_staging"], reject_on_false=True)

    def publish_received(
        nodes: Mapping[str, Mapping[str, Any]],
    ) -> dict[str, Any]:
        staging = nodes["accepted_staging"]
        application_node = nodes["application"]
        # One SQL statement closes the check/update race with an admitted
        # Update.  If an Update is active, its terminal workflow node performs
        # the same deferred transition after that request has finished.
        return {
            "dataSource": "main",
            "sql": (
                'UPDATE "t_api_request_staging" AS create_row SET '
                '"f_application_status"=\'Received\', '
                '"f_intake_id"=:intakeId, '
                '"f_application_id"=:applicationId, '
                '"f_rch_id"=:rchId, '
                '"f_office_code"=:officeCode '
                'WHERE create_row."id"=:createId '
                'AND create_row."f_status"=\'succeeded\' '
                'AND create_row."f_request_event"=\'CREATE\' '
                'AND create_row."f_api_type"=:createApiType '
                'AND create_row."f_application_type"=:applicationType '
                'AND create_row."f_application_status"=\'Accepted\' '
                'AND (create_row."f_active_update_id" IS NULL '
                'OR create_row."f_active_update_id"=\'\') '
                'AND NOT EXISTS (SELECT 1 '
                'FROM "t_api_request_staging" AS active '
                'WHERE active."f_request_event"=\'UPDATE\' '
                'AND active."f_parent_create_id"=CAST(create_row."id" AS text) '
                'AND active."f_status" IN (\'submitted\',\'processing\')) '
                'RETURNING create_row."id";'
            ),
            "variables": [
                {"name": "createId", "value": ref(staging, "id")},
                {"name": "intakeId", "value": context("id")},
                {"name": "applicationId", "value": ref(application_node, "id")},
                {"name": "rchId", "value": context("fk_intake_source_rch")},
                {"name": "officeCode", "value": context("f_office_cd")},
                {"name": "createApiType", "value": target.create_api_type},
                {"name": "applicationType", "value": target.application_type},
            ],
            "withMeta": False,
            "unsafeInjection": False,
        }

    return WorkflowPlan(
        title=target.received_title,
        source_key=target.received_source_key,
        config=received_workflow_config(target),
        nodes=(
            NodePlan(
                "application",
                "query",
                "Resolve linked business application",
                application,
            ),
            NodePlan(
                "application_exists",
                "condition",
                "Linked business application exists",
                application_exists,
                upstream="application",
            ),
            NodePlan(
                "accepted_staging",
                "query",
                "Resolve unique Accepted CREATE staging",
                accepted_staging,
                upstream="application_exists",
                branch_index=1,
            ),
            NodePlan(
                "accepted_exists",
                "condition",
                "Accepted CREATE staging exists",
                accepted_exists,
                upstream="accepted_staging",
            ),
            NodePlan(
                "publish_received",
                "sql",
                "CAS publish Received + backfill IDs",
                publish_received,
                upstream="accepted_exists",
                branch_index=1,
            ),
        ),
    )


def install_plan(
    api: RootNocoBaseApi, workflow_id: int, plan: WorkflowPlan
) -> dict[str, dict[str, Any]]:
    nodes: dict[str, dict[str, Any]] = {}
    for item in plan.nodes:
        if item.upstream is not None and item.upstream not in nodes:
            raise ApiError(f"Node plan is not topological: {item.name}")
        node = create_node(
            api,
            workflow_id,
            item.node_type,
            item.title,
            item.config(nodes),
        )
        nodes[item.name] = node
        if item.upstream is not None:
            link(
                api,
                nodes[item.upstream],
                node,
                branch_index=item.branch_index,
            )
    return nodes


def _node_by_title(workflow: Mapping[str, Any], title: str) -> Mapping[str, Any]:
    rows = [row for row in workflow.get("nodes") or [] if row.get("title") == title]
    if len(rows) != 1:
        raise ApiError(f"Workflow node title is missing or ambiguous: {title}")
    return rows[0]


def validate_installed_plan(workflow: Mapping[str, Any], plan: WorkflowPlan) -> None:
    if (
        workflow.get("title") != plan.title
        or workflow.get("key") != plan.source_key
        or (workflow.get("config") or {}) != dict(plan.config)
    ):
        raise ApiError(f"Workflow metadata differs after rebuild: {plan.title}")
    actual_nodes = workflow.get("nodes") or []
    expected_titles = {item.title for item in plan.nodes}
    if (
        len(actual_nodes) != len(plan.nodes)
        or {str(row.get("title")) for row in actual_nodes} != expected_titles
    ):
        raise ApiError(f"Workflow graph differs after rebuild: {plan.title}")
    handles = {item.name: _node_by_title(workflow, item.title) for item in plan.nodes}
    for item in plan.nodes:
        node = handles[item.name]
        if node.get("type") != item.node_type:
            raise ApiError(f"Workflow node type differs: {item.title}")
        if (node.get("config") or {}) != item.config(handles):
            raise ApiError(f"Workflow node config differs: {item.title}")
        expected_upstream_id = (
            handles[item.upstream]["id"] if item.upstream is not None else None
        )
        if (
            node.get("upstreamId") != expected_upstream_id
            or node.get("branchIndex") != item.branch_index
        ):
            raise ApiError(f"Workflow node edge differs: {item.title}")
        if node.get("type") in {"create", "update"}:
            collection = (node.get("config") or {}).get("collection")
            if collection != "t_api_request_staging":
                raise ApiError(
                    f"Bridge attempted to mutate business collection: {collection}"
                )


def _workflow_rows(api: RootNocoBaseApi, title: str) -> list[dict[str, Any]]:
    path = "/api/workflows:list?" + urllib.parse.urlencode(
        {"filter[title]": title, "pageSize": 100}
    )
    return [
        dict(row)
        for row in (api.request("GET", path) or [])
        if row.get("title") == title
    ]


def _preflight_source(api: RootNocoBaseApi, plan: WorkflowPlan) -> dict[str, Any]:
    rows = [
        row
        for row in _workflow_rows(api, plan.title)
        if row.get("enabled") and row.get("key") == plan.source_key
    ]
    if len(rows) != 1:
        raise ApiError(
            "Expected exactly one enabled source for "
            f"{plan.title!r} with key {plan.source_key!r}"
        )
    source = api.get_workflow(int(rows[0]["id"]))
    if (
        source.get("title") != plan.title
        or source.get("key") != plan.source_key
        or not source.get("enabled")
        or (source.get("config") or {}) != dict(plan.config)
    ):
        raise ApiError(f"Source trigger differs from reviewed contract: {plan.title}")
    return source


def _preflight_marker_field(api: RootNocoBaseApi) -> None:
    rows = (
        api.request("GET", "/api/collections/t_intake_form/fields:list?pageSize=400")
        or []
    )
    matches = [row for row in rows if row.get("name") == "f_api_create_staging_id"]
    if len(matches) != 1 or matches[0].get("type") != "string":
        raise ApiError("Intake f_api_create_staging_id must exist as one string field")


def _preflight_reservation_field(api: RootNocoBaseApi) -> None:
    rows = (
        api.request(
            "GET",
            "/api/collections/t_api_request_staging/fields:list?pageSize=400",
        )
        or []
    )
    matches = [row for row in rows if row.get("name") == "f_active_update_id"]
    if (
        len(matches) != 1
        or matches[0].get("type") != "string"
        or matches[0].get("interface") != "input"
    ):
        raise ApiError(
            "Staging f_active_update_id must exist as one string input field"
        )


def selected_plans(keys: Sequence[str]) -> list[WorkflowPlan]:
    selected = [target for target in TARGETS if not keys or target.key in keys]
    unknown = sorted(set(keys) - {target.key for target in TARGETS})
    if unknown:
        raise ApiError("Unknown target(s): " + ", ".join(unknown))
    plans: list[WorkflowPlan] = []
    for target in selected:
        plans.extend((build_created_plan(target), build_received_plan(target)))
    return plans


def _create_revision(api: RootNocoBaseApi, source: Mapping[str, Any]) -> dict[str, Any]:
    source_id = int(source["id"])
    set_enabled(api, source_id, False)
    query = urllib.parse.urlencode(
        {"filterByTk": source_id, "filter[key]": str(source["key"])}
    )
    created = api.request("POST", "/api/workflows:revision?" + query, {})
    if not isinstance(created, dict) or created.get("id") is None:
        raise ApiError(f"Revision API returned no ID for {source.get('title')}")
    draft = api.get_workflow(int(created["id"]))
    if (
        draft.get("enabled")
        or draft.get("executed")
        or draft.get("key") != source.get("key")
        or draft.get("title") != source.get("title")
    ):
        raise ApiError(f"Revision is not a disabled editable copy: {source['title']}")
    return draft


def apply_revisions(
    api: RootNocoBaseApi,
    sources_and_plans: Sequence[tuple[dict[str, Any], WorkflowPlan]],
) -> list[dict[str, Any]]:
    drafts: list[dict[str, Any]] = []
    try:
        # Build every revision while all public sources are consistently off.
        # Activation happens only after every graph passes validation.
        for source, plan in sources_and_plans:
            draft = _create_revision(api, source)
            drafts.append(draft)
            destroy_workflow_nodes(api, draft)
            api.request(
                "POST",
                f"/api/workflows:update?filterByTk={int(draft['id'])}",
                {"config": dict(plan.config)},
            )
            install_plan(api, int(draft["id"]), plan)
            validate_installed_plan(api.get_workflow(int(draft["id"])), plan)

        # The NocoBase maintenance host still provides Python 3.9, where
        # ``zip(strict=True)`` is unavailable.  The two lists are guaranteed
        # to have equal length because each draft is appended in the build
        # loop above before activation begins.
        for draft, (_, plan) in zip(drafts, sources_and_plans):
            set_enabled(api, int(draft["id"]), True)
            enabled = api.get_workflow(int(draft["id"]))
            if not enabled.get("enabled"):
                raise ApiError(f"New bridge did not enable: {plan.title}")
        return [api.get_workflow(int(row["id"])) for row in drafts]
    except Exception:
        for draft in drafts:
            try:
                set_enabled(api, int(draft["id"]), False)
            except Exception:
                pass
        for source, _ in sources_and_plans:
            try:
                set_enabled(api, int(source["id"]), bool(source.get("enabled")))
            except Exception:
                pass
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True)
    parser.add_argument(
        "--target",
        action="append",
        choices=[target.key for target in TARGETS],
        default=[],
        help="Limit to one or more business targets; default is all targets.",
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = RootNocoBaseApi(args.base_url, token)
    plans = selected_plans(args.target)
    _preflight_marker_field(api)
    _preflight_reservation_field(api)
    sources_and_plans = [(_preflight_source(api, plan), plan) for plan in plans]
    print(f"preflight_count={len(sources_and_plans)}")
    for source, plan in sources_and_plans:
        print(
            f"source_id={source['id']} source_key={source['key']} "
            f"title={plan.title} new_node_count={len(plan.nodes)}"
        )
    print("mutated_business_collections=none")
    print("received_guard=changed(f_approval_status)+Accepted_CAS")
    if not args.apply:
        print("mode=dry-run")
        return 0

    revised = apply_revisions(api, sources_and_plans)
    for row in revised:
        print(
            f"enabled_revision_id={row['id']} source_key={row['key']} "
            f"title={row['title']} node_count={len(row.get('nodes') or [])}"
        )
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
