#!/usr/bin/env python3
# ruff: noqa: E501
"""Collect controlled runtime acceptance evidence for the 13001 dispatcher.

This is deliberately a *local-gateway* acceptance tool, not a deployment or
workflow writer.  It has two mutually exclusive modes:

``--run``
    Perform exactly one minimal Licence Renewal Create through the local
    Docker/Kong listener, then prove that it entered the new direct dispatcher
    once and only once.

``--collect-existing``
    Perform no create, authentication, workflow update, or delete.  It proves
    the same facts for one already-created controlled record.  This exists so
    an uncertain network response is never solved by re-sending a Create.

The write mode is intentionally difficult to invoke by accident: it requires
``--run``, an explicit confirmation phrase, an OP account/password supplied
only through the process environment, and a root NocoBase inspection token
supplied only through the process environment.  Neither password nor token is
printed, written to disk, or included in evidence.

All network destinations are fixed in this source:

* public Create is sent only to ``https://127.0.0.1:28443``; and
* inspection is sent only to the 13001 development NocoBase endpoint.

The script also checks the repository's local-test profile before a live run.
It therefore cannot be redirected to 13000/211 by an environment variable or
by a command-line URL.  Evidence is a new owner-only (0600), non-secret JSON
file compatible with
``plan_nocobase_unified_subflow_dispatch_13001.RUNTIME_EVIDENCE_FORMAT``.
It can subsequently be recorded by that plan tool without re-running the
Create.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from collections.abc import Callable, Iterable, Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

import plan_nocobase_unified_subflow_dispatch_13001 as topology

REPO_ROOT = Path(__file__).resolve().parents[1]
ARTIFACT_ROOT = REPO_ROOT.parent / "kong-nocoadapter-artifacts" / "workflow-evidence"

# These endpoint constants are intentionally not command-line options and do
# not consult environment variables.  A local test must never become a 13000
# or Internet-facing request merely because an operator has a stale shell.
LOCAL_GATEWAY_BASE_URL = "https://127.0.0.1:28443"
DEVELOPMENT_NOCOBASE_BASE_URL = topology.BASE_URL
MIGRATION_ID = "multibranch-20261019"
RUN_CONFIRM = "RUN_ONE_LRN_DISPATCHER_RUNTIME_ACCEPTANCE_13001"

OP_ACCOUNT_ENV = "OP_ACCOUNT"
OP_PASSWORD_ENV = "OP_PASSWORD"
ROOT_TOKEN_ENV = "NOCOBASE_TOKEN"

LRN_APPLICATION_TYPE = "licence_renewal"
LRN_CREATE_API_TYPE = "create_licence_renewal"
LRN_ENDPOINT = "/v1/create_licence_renewal"
LRN_OFFICE_CODE = "LORCHE"
LRN_RCH_NO = "L0043"
LRN_OLD_CREATE_WORKFLOW_ID = next(
    business.create_source_id
    for business in topology.BUSINESSES
    if business.name == "licence_renewal"
)

_REQUEST_ID_RE = re.compile(r"^DISPATCH-LRN-[A-Z0-9-]{12,128}$")
_PROFILE_BASE_URL_RE = re.compile(r'^\s*base_url:\s*["\']?([^"\'\s#]+)', re.MULTILINE)


class AcceptanceError(RuntimeError):
    """A runtime acceptance precondition or assertion failed safely."""


class JsonRequester(Protocol):
    """Narrow interface used by the real HTTP client and offline fakes."""

    def request_json(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        body: Mapping[str, Any] | None = None,
        timeout_seconds: int = 30,
    ) -> tuple[int, Any]:
        ...


class UrllibJsonRequester:
    """Minimal JSON transport with loopback-only TLS relaxation.

    Local Kong uses the development TLS certificate.  ``ssl`` verification is
    disabled only for the exact fixed 127.0.0.1 HTTPS listener; the 13001
    inspection endpoint is HTTP and has no TLS exception path.
    """

    def request_json(
        self,
        method: str,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        body: Mapping[str, Any] | None = None,
        timeout_seconds: int = 30,
    ) -> tuple[int, Any]:
        encoded: bytes | None = None
        request_headers = {"Accept": "application/json", **dict(headers or {})}
        if body is not None:
            encoded = json.dumps(body, separators=(",", ":")).encode("utf-8")
            request_headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            url,
            data=encoded,
            headers=request_headers,
            method=method,
        )
        context = None
        if url.startswith(LOCAL_GATEWAY_BASE_URL + "/"):
            context = ssl._create_unverified_context()  # noqa: SLF001 - fixed loopback only
        try:
            with urllib.request.urlopen(
                request, timeout=timeout_seconds, context=context
            ) as response:
                raw = response.read()
                status = int(response.status)
        except urllib.error.HTTPError as exc:
            # Deliberately do not surface a response body.  Authentication or
            # upstream error bodies may contain details that do not belong in
            # an operational acceptance log.
            raise AcceptanceError(f"HTTP {exc.code} from fixed acceptance endpoint") from exc
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            raise AcceptanceError(
                f"network failure contacting fixed acceptance endpoint: {type(exc).__name__}"
            ) from exc
        if not raw:
            return status, None
        try:
            return status, json.loads(raw)
        except json.JSONDecodeError as exc:
            raise AcceptanceError("fixed acceptance endpoint returned non-JSON data") from exc


class Gateway:
    """The strictly local public interface used in write mode."""

    def __init__(self, requester: JsonRequester) -> None:
        self._requester = requester

    def readiness(self) -> None:
        status, body = self._requester.request_json(
            "GET", LOCAL_GATEWAY_BASE_URL + "/health/ready", timeout_seconds=10
        )
        if status != 200 or not isinstance(body, Mapping) or body.get("status") != "ready":
            raise AcceptanceError("local gateway readiness check did not return status=ready")

    def authenticate(self, *, account: str, password: str, request_id: str) -> str:
        status, body = self._requester.request_json(
            "POST",
            LOCAL_GATEWAY_BASE_URL + "/v1/auth/token",
            headers={"X-Request-ID": request_id},
            body={"account": account, "password": password},
            timeout_seconds=30,
        )
        token = (
            body.get("data", {}).get("token")
            if isinstance(body, Mapping) and isinstance(body.get("data"), Mapping)
            else None
        )
        if status != 200 or not isinstance(token, str) or not token.strip():
            raise AcceptanceError("local OP authentication did not return a usable token")
        return token.strip()

    def create_lrn(self, *, token: str, payload: Mapping[str, Any]) -> dict[str, Any]:
        request_id = payload.get("request_id")
        if not isinstance(request_id, str):
            raise AcceptanceError("internal LRN payload lacks a request_id")
        status, body = self._requester.request_json(
            "POST",
            LOCAL_GATEWAY_BASE_URL + LRN_ENDPOINT,
            headers={
                "Authorization": f"Bearer {token}",
                "X-Request-ID": request_id,
            },
            body=payload,
            timeout_seconds=60,
        )
        return _validate_create_response(body, status=status, request_id=request_id)


class Inspector:
    """Root-token read-only inspector pinned to NocoBase development 13001."""

    def __init__(self, requester: JsonRequester, root_token: str) -> None:
        if not root_token.strip():
            raise AcceptanceError(f"{ROOT_TOKEN_ENV} must not be empty")
        self._requester = requester
        self._root_token = root_token

    def _get(self, path: str) -> Any:
        status, body = self._requester.request_json(
            "GET",
            DEVELOPMENT_NOCOBASE_BASE_URL + path,
            headers={
                "Authorization": f"Bearer {self._root_token}",
                "X-Role": "root",
            },
            timeout_seconds=60,
        )
        if status != 200:
            raise AcceptanceError("13001 read-only inspector received a non-200 response")
        # NocoBase data endpoints normally wrap records in ``data``.  This
        # keeps the low-level transport generic for offline fake tests.
        if isinstance(body, Mapping) and "data" in body:
            return body["data"]
        return body

    def staging(self, create_id: str) -> dict[str, Any]:
        query = urllib.parse.urlencode({"filterByTk": create_id})
        body = self._get("/api/t_api_request_staging:get?" + query)
        if not isinstance(body, Mapping):
            raise AcceptanceError("13001 staging record is missing or malformed")
        return dict(body)

    def workflow(self, workflow_id: int) -> dict[str, Any]:
        query = urllib.parse.urlencode({"filterByTk": str(workflow_id)})
        body = self._get("/api/workflows:get?" + query)
        if not isinstance(body, Mapping) or body.get("id") != workflow_id:
            raise AcceptanceError(f"13001 workflow {workflow_id} readback is malformed")
        return dict(body)

    def executions(self, workflow_id: int) -> dict[int, dict[str, Any]]:
        result: dict[int, dict[str, Any]] = {}
        page = 1
        while True:
            query = urllib.parse.urlencode(
                {
                    "filter[workflowId]": str(workflow_id),
                    "page": page,
                    "pageSize": 100,
                    "sort[]": "createdAt",
                }
            )
            rows = self._get("/api/executions:list?" + query)
            if not isinstance(rows, list) or not all(isinstance(row, Mapping) for row in rows):
                raise AcceptanceError(f"13001 executions for workflow {workflow_id} are malformed")
            for row in rows:
                execution_id = row.get("id")
                if not isinstance(execution_id, int) or execution_id in result:
                    raise AcceptanceError(
                        f"13001 execution list for workflow {workflow_id} has invalid IDs"
                    )
                result[execution_id] = dict(row)
            if len(rows) < 100:
                return result
            page += 1
            if page > 1000:
                raise AcceptanceError("13001 execution pagination exceeded the safety limit")


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _request_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"DISPATCH-LRN-{stamp}-{uuid.uuid4().hex[:12].upper()}"


def minimal_lrn_payload(request_id: str, *, received_date: str | None = None) -> dict[str, Any]:
    """The smallest known public LRN Create body for the LORCHE/L0043 fixture."""
    if not _REQUEST_ID_RE.fullmatch(request_id):
        raise AcceptanceError("runtime request_id has an unexpected controlled-test format")
    date_value = received_date or datetime.now(timezone.utc).date().isoformat()
    return {
        "request_id": request_id,
        "form_data": {
            "case_summary": {"office_code": LRN_OFFICE_CODE, "rch_no": LRN_RCH_NO},
            "part_1": {"application_received_date": date_value},
            # An explicit empty checklist is valid and avoids file upload or
            # checklist attachment work in this dispatcher-only test.
            "part_5": {"checklist": []},
        },
    }


def _as_positive_create_id(value: object) -> str:
    text = str(value).strip()
    if not text.isdigit() or int(text) <= 0:
        raise AcceptanceError("Create response does not contain a positive create_id")
    return text


def _validate_create_response(body: Any, *, status: int, request_id: str) -> dict[str, Any]:
    if status not in {200, 201, 202} or not isinstance(body, Mapping):
        raise AcceptanceError("LRN Create did not return a successful JSON response")
    create_id = _as_positive_create_id(body.get("create_id"))
    expected = {
        "accepted": True,
        "request_id": request_id,
        "status": "Accepted",
        "application_type": LRN_APPLICATION_TYPE,
    }
    if any(body.get(key) != value for key, value in expected.items()):
        raise AcceptanceError("LRN Create response does not match the public accepted contract")
    # Persist only the documented, non-secret response contract.  In
    # particular do not preserve arbitrary response extensions from a proxy.
    return {**expected, "create_id": create_id}


def _require_environment(names: Iterable[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    missing: list[str] = []
    for name in names:
        value = os.environ.get(name)
        if not isinstance(value, str) or not value:
            missing.append(name)
        else:
            result[name] = value
    if missing:
        raise AcceptanceError("required environment variable(s) are missing: " + ", ".join(missing))
    return result


def _read_env_file(path: Path) -> dict[str, str]:
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise AcceptanceError(f"cannot read required local-test profile file: {path}") from exc
    result: dict[str, str] = {}
    for line in raw.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def assert_local_development_profile(repo_root: Path = REPO_ROOT) -> None:
    """Refuse a live run if this checkout no longer names the local 13001 profile."""
    compose_env = _read_env_file(repo_root / "config" / "compose.local-test.env")
    required_env = {
        "DEPLOYMENT_ENV": "local_test",
        "KONG_HTTPS_BIND": "127.0.0.1",
        "KONG_HTTPS_PORT": "28443",
        "NOCOBASE_PROFILE_FILE": "./config/nocobase.local-test.yaml",
    }
    if any(compose_env.get(key) != value for key, value in required_env.items()):
        raise AcceptanceError("local compose profile is not the reviewed 127.0.0.1:28443 local_test profile")
    profile = repo_root / "config" / "nocobase.local-test.yaml"
    try:
        profile_text = profile.read_text(encoding="utf-8")
    except OSError as exc:
        raise AcceptanceError("cannot read local NocoBase profile") from exc
    match = _PROFILE_BASE_URL_RE.search(profile_text)
    if not match or match.group(1).rstrip("/") != DEVELOPMENT_NOCOBASE_BASE_URL:
        raise AcceptanceError("local NocoBase profile is not pinned to development 13001")


def _manifest() -> dict[str, Any]:
    _path, manifest = topology._existing_manifest(MIGRATION_ID, require_evidence=True)
    if manifest.get("environment") != "13001":
        raise AcceptanceError("runtime acceptance manifest is not a 13001 preparation")
    source_digest = manifest.get("source_snapshot_sha256")
    if not isinstance(source_digest, str) or len(source_digest) != 64:
        raise AcceptanceError("runtime acceptance manifest lacks a frozen source digest")
    return manifest


def _candidate_ids(manifest: Mapping[str, Any]) -> tuple[int, int]:
    candidates = manifest.get("candidates")
    if not isinstance(candidates, Mapping):
        raise AcceptanceError("runtime acceptance manifest candidates are malformed")
    parent = candidates.get("parent")
    children = candidates.get("children")
    child = children.get("licence_renewal") if isinstance(children, Mapping) else None
    if not isinstance(parent, Mapping) or not isinstance(child, Mapping):
        raise AcceptanceError("runtime acceptance manifest lacks the LRN direct path")
    parent_id = parent.get("id")
    child_id = child.get("id")
    if not isinstance(parent_id, int) or not isinstance(child_id, int):
        raise AcceptanceError("runtime acceptance candidate IDs are malformed")
    return parent_id, child_id


def _execution_context(row: Mapping[str, Any]) -> Mapping[str, Any] | None:
    context = row.get("context")
    return context if isinstance(context, Mapping) else None


def _matches_lrn_create_execution(row: Mapping[str, Any], create_id: str) -> bool:
    context = _execution_context(row)
    data = context.get("data") if isinstance(context, Mapping) else None
    if not isinstance(data, Mapping):
        return False
    return (
        str(data.get("id")) == create_id
        and data.get("f_source_system") == topology.SOURCE_SYSTEM
        and data.get("f_request_event") == "CREATE"
        and data.get("f_api_type") == LRN_CREATE_API_TYPE
        and data.get("f_application_type") == LRN_APPLICATION_TYPE
        and data.get("f_status") == topology.STATUS
    )


def _new_rows(
    before: Mapping[int, Mapping[str, Any]], after: Mapping[int, Mapping[str, Any]]
) -> list[dict[str, Any]]:
    return [dict(row) for row_id, row in after.items() if row_id not in before]


def _compact_execution(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "id": row.get("id"),
        "status": row.get("status"),
        "parent_execution_id": row.get("parentExecutionId"),
    }


def _assert_staging_row(staging: Mapping[str, Any], *, create_id: str, request_id: str) -> dict[str, Any]:
    if str(staging.get("id")) != create_id:
        raise AcceptanceError("staging row ID does not match public create_id")
    expected = {
        "f_source_system": topology.SOURCE_SYSTEM,
        "f_request_event": "CREATE",
        "f_api_type": LRN_CREATE_API_TYPE,
        "f_application_type": LRN_APPLICATION_TYPE,
        "f_office_code": LRN_OFFICE_CODE,
    }
    if any(staging.get(key) != value for key, value in expected.items()):
        raise AcceptanceError("staging row does not match the controlled LRN CREATE tuple")
    body = staging.get("f_request_body")
    if not isinstance(body, Mapping) or body.get("request_id") != request_id:
        raise AcceptanceError("staging row does not retain the controlled external request_id")
    created_by = staging.get("createdById")
    if created_by in {None, ""}:
        raise AcceptanceError("staging row has no createdById for the OP execution identity")
    if staging.get("f_dispatch_route") not in {None, ""}:
        raise AcceptanceError("staging row contains a forbidden legacy dispatch marker")
    if staging.get("f_status") != "succeeded":
        raise AcceptanceError("controlled LRN staging row has not completed successfully")
    if staging.get("f_application_id") in {None, ""}:
        raise AcceptanceError("controlled LRN staging row has no completed application ID")
    if staging.get("f_error_message") not in {None, ""}:
        raise AcceptanceError("controlled LRN staging row has an error marker")
    # The evidence deliberately exposes neither the full body nor the internal
    # person/home identifiers.  The public create ID and tuple are enough to
    # make the proof repeatable.
    return {
        "create_id": create_id,
        "request_id": request_id,
        "application_type": LRN_APPLICATION_TYPE,
        "office_code": LRN_OFFICE_CODE,
        "source_system": topology.SOURCE_SYSTEM,
        "request_event": "CREATE",
        "api_type": LRN_CREATE_API_TYPE,
        "status": "succeeded",
        "created_by_present": True,
        "application_created": True,
        "legacy_marker_absent": True,
    }


def _assert_execution_path(
    *,
    create_id: str,
    parent_rows: Iterable[Mapping[str, Any]],
    child_rows: Iterable[Mapping[str, Any]],
    old_rows: Iterable[Mapping[str, Any]],
) -> dict[str, Any]:
    matching_parent = [row for row in parent_rows if _matches_lrn_create_execution(row, create_id)]
    matching_child = [row for row in child_rows if _matches_lrn_create_execution(row, create_id)]
    matching_old = [row for row in old_rows if _matches_lrn_create_execution(row, create_id)]
    if len(matching_parent) != 1:
        raise AcceptanceError("expected exactly one new ingress parent execution for controlled LRN Create")
    if len(matching_child) != 1:
        raise AcceptanceError("expected exactly one new LRN child execution for controlled Create")
    if matching_old:
        raise AcceptanceError("legacy LRN Create workflow executed during direct dispatcher acceptance")
    parent = matching_parent[0]
    child = matching_child[0]
    parent_id = parent.get("id")
    if not isinstance(parent_id, int) or parent.get("status") != 1:
        raise AcceptanceError("controlled parent execution did not complete successfully")
    if child.get("status") != 1 or str(child.get("parentExecutionId")) != str(parent_id):
        raise AcceptanceError("controlled LRN child execution is not the successful child of ingress")
    return {
        "parent_execution": _compact_execution(parent),
        "child_execution": _compact_execution(child),
        "legacy_lrn_execution_count": 0,
    }


def _active_path_guard(inspector: Inspector, manifest: Mapping[str, Any]) -> tuple[int, int]:
    parent_id, child_id = _candidate_ids(manifest)
    parent = inspector.workflow(parent_id)
    child = inspector.workflow(child_id)
    old = inspector.workflow(LRN_OLD_CREATE_WORKFLOW_ID)
    if parent.get("enabled") is not True or child.get("enabled") is not True:
        raise AcceptanceError("new parent/LRN child are not both enabled; do not run acceptance")
    if old.get("enabled") is not False:
        raise AcceptanceError("legacy LRN Create listener is enabled; do not run acceptance")
    return parent_id, child_id


def _build_evidence(
    *,
    manifest: Mapping[str, Any],
    mode: str,
    request_id: str,
    create_id: str,
    staging: Mapping[str, Any],
    execution_proof: Mapping[str, Any],
    accepted_response: Mapping[str, Any] | None,
) -> dict[str, Any]:
    outcomes = {
        "created_by_id": {
            "passed": True,
            "observation": "The controlled OP-authenticated staging row retained a non-empty createdById.",
        },
        "op_role_mapping": {
            "passed": True,
            "observation": "The LRN custom-action child completed successfully using the staging execution identity.",
        },
        "direct_create_submitted_trigger": {
            "passed": True,
            "observation": "Exactly one successful direct ingress execution and one successful LRN child execution processed the submitted CREATE; no legacy LRN execution or dispatch marker was observed.",
        },
    }
    result: dict[str, Any] = {
        "format": topology.RUNTIME_EVIDENCE_FORMAT,
        "migration_id": manifest["migration_id"],
        "topology_sha256": manifest["topology_sha256"],
        "source_snapshot_sha256": manifest["source_snapshot_sha256"],
        "created_at_utc": _utc_now(),
        "mode": mode,
        "fixed_endpoints": {
            "local_gateway": LOCAL_GATEWAY_BASE_URL,
            "development_nocobase": DEVELOPMENT_NOCOBASE_BASE_URL,
        },
        "request": {
            "request_id": request_id,
            "endpoint": LRN_ENDPOINT,
            "office_code": LRN_OFFICE_CODE,
            "rch_no": LRN_RCH_NO,
        },
        "staging": dict(staging),
        "execution_proof": dict(execution_proof),
        "outcomes": outcomes,
    }
    if accepted_response is not None:
        result["accepted_response"] = dict(accepted_response)
    else:
        result["accepted_response"] = {"captured": False, "reason": "retrospective read-only collection"}
    return result


def _write_new_private_json(path: Path, value: Mapping[str, Any]) -> Path:
    destination = path.expanduser().resolve()
    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    try:
        descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise AcceptanceError(f"refusing to overwrite existing runtime evidence: {destination}") from exc
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except Exception:
        try:
            destination.unlink()
        except FileNotFoundError:
            pass
        raise
    return destination


def _evidence_destination(*, request_id: str, mode: str, requested: Path | None) -> Path:
    if requested is not None:
        return requested
    safe_id = re.sub(r"[^A-Za-z0-9_-]", "-", request_id)
    suffix = "run" if mode == "run" else "collect"
    return ARTIFACT_ROOT / f"runtime-lrn-{safe_id}-{suffix}.json"


def _validate_evidence_compatibility(path: Path, manifest: Mapping[str, Any]) -> None:
    """Use the production plan validator, then remove no data on success."""
    try:
        topology._valid_runtime_evidence(path, manifest)
    except Exception as exc:
        # This exact file was created seconds ago by this process. Removing it
        # is recoverable in source control/artifact history and prevents a bad
        # file from being mistaken for a valid cutover proof.
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        raise AcceptanceError("generated runtime evidence is not plan-compatible") from exc


def _wait_for_run_result(
    *,
    inspector: Inspector,
    create_id: str,
    request_id: str,
    parent_before: Mapping[int, Mapping[str, Any]],
    child_before: Mapping[int, Mapping[str, Any]],
    old_before: Mapping[int, Mapping[str, Any]],
    parent_id: int,
    child_id: int,
    timeout_seconds: int,
    sleep: Callable[[float], None] = time.sleep,
) -> tuple[dict[str, Any], dict[str, Any]]:
    deadline = time.monotonic() + timeout_seconds
    last_error: AcceptanceError | None = None
    while True:
        try:
            staging = _assert_staging_row(
                inspector.staging(create_id), create_id=create_id, request_id=request_id
            )
            parent_after = inspector.executions(parent_id)
            child_after = inspector.executions(child_id)
            old_after = inspector.executions(LRN_OLD_CREATE_WORKFLOW_ID)
            parent_new = _new_rows(parent_before, parent_after)
            child_new = _new_rows(child_before, child_after)
            old_new = _new_rows(old_before, old_after)
            execution = _assert_execution_path(
                create_id=create_id,
                parent_rows=parent_new,
                child_rows=child_new,
                old_rows=old_new,
            )
            # Strictly reject any old-LRN activity, even if it happened to be
            # for another row during the controlled quiet test window.
            if old_new:
                raise AcceptanceError("legacy LRN Create workflow has a new execution in the acceptance window")
            return staging, execution
        except AcceptanceError as exc:
            last_error = exc
            if time.monotonic() >= deadline:
                raise AcceptanceError(
                    "controlled LRN Create did not complete the required direct path before timeout: "
                    + str(last_error)
                ) from exc
            sleep(1.0)


def run_controlled_acceptance(
    *,
    gateway: Gateway,
    inspector: Inspector,
    manifest: Mapping[str, Any],
    account: str,
    password: str,
    request_id: str | None = None,
    timeout_seconds: int = 60,
    profile_validator: Callable[[], None] = assert_local_development_profile,
) -> dict[str, Any]:
    """Run one LRN Create and return unpersisted non-secret evidence."""
    profile_validator()
    parent_id, child_id = _active_path_guard(inspector, manifest)
    gateway.readiness()
    run_request_id = request_id or _request_id()
    payload = minimal_lrn_payload(run_request_id)
    parent_before = inspector.executions(parent_id)
    child_before = inspector.executions(child_id)
    old_before = inspector.executions(LRN_OLD_CREATE_WORKFLOW_ID)
    token = gateway.authenticate(account=account, password=password, request_id=run_request_id)
    try:
        accepted = gateway.create_lrn(token=token, payload=payload)
    finally:
        # The token is intentionally short-lived in this process only. Do not
        # serialize it, return it, or leave it in a module-global variable.
        token = ""
    create_id = str(accepted["create_id"])
    staging, execution = _wait_for_run_result(
        inspector=inspector,
        create_id=create_id,
        request_id=run_request_id,
        parent_before=parent_before,
        child_before=child_before,
        old_before=old_before,
        parent_id=parent_id,
        child_id=child_id,
        timeout_seconds=timeout_seconds,
    )
    return _build_evidence(
        manifest=manifest,
        mode="run",
        request_id=run_request_id,
        create_id=create_id,
        staging=staging,
        execution_proof=execution,
        accepted_response=accepted,
    )


def collect_existing_acceptance(
    *,
    inspector: Inspector,
    manifest: Mapping[str, Any],
    create_id: str,
    request_id: str,
) -> dict[str, Any]:
    """Read-only proof for an existing one-shot controlled LRN request."""
    public_id = _as_positive_create_id(create_id)
    if not _REQUEST_ID_RE.fullmatch(request_id):
        raise AcceptanceError("existing request_id has an unexpected controlled-test format")
    parent_id, child_id = _active_path_guard(inspector, manifest)
    staging = _assert_staging_row(
        inspector.staging(public_id), create_id=public_id, request_id=request_id
    )
    execution = _assert_execution_path(
        create_id=public_id,
        parent_rows=inspector.executions(parent_id).values(),
        child_rows=inspector.executions(child_id).values(),
        old_rows=inspector.executions(LRN_OLD_CREATE_WORKFLOW_ID).values(),
    )
    return _build_evidence(
        manifest=manifest,
        mode="collect_existing",
        request_id=request_id,
        create_id=public_id,
        staging=staging,
        execution_proof=execution,
        accepted_response=None,
    )


def static_plan() -> dict[str, Any]:
    """The no-write default output, suitable for review/CI."""
    return {
        "writes_remote": False,
        "writes_local": False,
        "environment": "13001 development through local Docker gateway only",
        "fixed_local_gateway": LOCAL_GATEWAY_BASE_URL,
        "fixed_development_nocobase": DEVELOPMENT_NOCOBASE_BASE_URL,
        "migration_id": MIGRATION_ID,
        "controlled_request": {
            "method": "POST",
            "path": LRN_ENDPOINT,
            "application_type": LRN_APPLICATION_TYPE,
            "office_code": LRN_OFFICE_CODE,
            "rch_no": LRN_RCH_NO,
        },
        "modes": {
            "run": "requires --run, explicit confirmation, OP_ACCOUNT, OP_PASSWORD, and NOCOBASE_TOKEN; creates exactly one new request",
            "collect_existing": "requires --collect-existing, create_id, request_id, and NOCOBASE_TOKEN; no Create/authentication/write",
        },
        "proof": [
            "staging row preserves createdById and has no legacy marker",
            "one successful ingress execution",
            "one successful Licence Renewal custom-action child execution with matching parentExecutionId",
            "zero legacy Licence Renewal Create executions for the controlled row",
        ],
        "evidence_format": topology.RUNTIME_EVIDENCE_FORMAT,
    }


def _parse_args(argv: Iterable[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true", help="Create one fresh controlled LRN request.")
    mode.add_argument(
        "--collect-existing",
        action="store_true",
        help="Read-only evidence collection for a known controlled LRN request.",
    )
    parser.add_argument("--create-id", help="Required with --collect-existing.")
    parser.add_argument("--request-id", help="Required with --collect-existing.")
    parser.add_argument("--confirm", help="Required literal with --run.")
    parser.add_argument("--evidence", type=Path, help="New 0600 evidence JSON path; never overwritten.")
    parser.add_argument("--timeout-seconds", type=int, default=60, help="Bounded post-Create wait (5-180 seconds).")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print result JSON.")
    return parser.parse_args(argv)


def main(argv: Iterable[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        if not args.run and not args.collect_existing:
            if any(value is not None for value in (args.create_id, args.request_id, args.confirm, args.evidence)):
                raise AcceptanceError("runtime options require --run or --collect-existing")
            result = static_plan()
        elif args.run:
            if args.create_id or args.request_id:
                raise AcceptanceError("--create-id/--request-id are not accepted with --run")
            if args.confirm != RUN_CONFIRM:
                raise AcceptanceError("--run requires --confirm " + RUN_CONFIRM)
            if not 5 <= args.timeout_seconds <= 180:
                raise AcceptanceError("--timeout-seconds must be between 5 and 180")
            environment = _require_environment((OP_ACCOUNT_ENV, OP_PASSWORD_ENV, ROOT_TOKEN_ENV))
            manifest = _manifest()
            evidence = run_controlled_acceptance(
                gateway=Gateway(UrllibJsonRequester()),
                inspector=Inspector(UrllibJsonRequester(), environment[ROOT_TOKEN_ENV]),
                manifest=manifest,
                account=environment[OP_ACCOUNT_ENV],
                password=environment[OP_PASSWORD_ENV],
                timeout_seconds=args.timeout_seconds,
            )
            destination = _write_new_private_json(
                _evidence_destination(
                    request_id=evidence["request"]["request_id"], mode="run", requested=args.evidence
                ),
                evidence,
            )
            _validate_evidence_compatibility(destination, manifest)
            result = {
                "writes_remote": True,
                "writes_local": True,
                "mode": "run",
                "evidence_path": str(destination),
                "create_id": evidence["staging"]["create_id"],
                "request_id": evidence["request"]["request_id"],
                "acceptance": "passed",
            }
        else:
            if args.confirm:
                raise AcceptanceError("--confirm is accepted only with --run")
            if not args.create_id or not args.request_id:
                raise AcceptanceError("--collect-existing requires --create-id and --request-id")
            environment = _require_environment((ROOT_TOKEN_ENV,))
            manifest = _manifest()
            evidence = collect_existing_acceptance(
                inspector=Inspector(UrllibJsonRequester(), environment[ROOT_TOKEN_ENV]),
                manifest=manifest,
                create_id=args.create_id,
                request_id=args.request_id,
            )
            destination = _write_new_private_json(
                _evidence_destination(
                    request_id=args.request_id, mode="collect", requested=args.evidence
                ),
                evidence,
            )
            _validate_evidence_compatibility(destination, manifest)
            result = {
                "writes_remote": False,
                "writes_local": True,
                "mode": "collect_existing",
                "evidence_path": str(destination),
                "create_id": evidence["staging"]["create_id"],
                "request_id": args.request_id,
                "acceptance": "passed",
            }
        print(json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None))
        return 0
    except AcceptanceError as exc:
        print(f"error={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
