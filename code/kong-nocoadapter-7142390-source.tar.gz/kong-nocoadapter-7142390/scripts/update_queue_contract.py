"""Local contract for a native NocoBase Staging UPDATE queue.

This module has no NocoBase client and performs no writes.  Its SQL is a
revision input, not an installed workflow.  SQL writes do *not* trigger
collection events.  Admission therefore leaves an admitted child pending;
an ORM transition to ``queued`` wakes the native collection workflow.  The
native FIFO dispatcher invokes the matching UPDATE workflow as a subflow.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, Literal

ADMISSION_PENDING = "admission_pending"
QUEUED = "queued"
DISPATCHED = "submitted"
PROCESSING = "processing"
NEEDS_REVIEW = "needs_review"
TERMINAL_STATUSES = frozenset({"succeeded", "failed"})
RECEIVED_BLOCKING_STATUSES = (
    QUEUED,
    DISPATCHED,
    PROCESSING,
    NEEDS_REVIEW,
)

# A NocoBase create first obtains its Snowflake ID and createdBy audit identity
# in admission_pending.  Synchronous SQL admission increments the parent
# count, assigns an admission sequence, and marks that child counted in one
# database statement, while leaving
# f_status unchanged.  The customer request then uses the NocoBase ORM to
# change f_status to queued and fire the native collection event.  If that ORM
# update is lost, a native scheduled reconciler may perform the same guarded
# transition.  The count orders admitted work, but does not block the native
# Intake workflow from crossing into Received.  A later reconciler cancels
# counted work that has not yet begun a business write.
PARENT_QUEUE_FIELDS = (
    "f_queue_pending_count",
    "f_queue_next_sequence",
    "f_active_update_id",
)
CHILD_QUEUE_FIELDS = (
    "f_queue_counted",
    "f_queue_sequence",
    "f_queue_phase",
    "f_queue_claimed_at",
    "f_attempt_count",
    "f_client_request_id",
    "f_queue_worker_token",
)

# LRN is the only currently supported API family whose CREATE deliberately
# backfills no Intake ID.  Every other listed family creates/links Intake.
# Unknown application types are not dispatched until explicitly mapped.
APPLICATION_ONLY_READY_TYPES = frozenset({"licence_renewal"})
INTAKE_AND_APPLICATION_READY_TYPES = frozenset(
    {
        "new_licence",
        "changing_home",
        "self_withdraw",
        "revoke_licence",
        "specific_hour",
        "responsible_person",
        "change_home_manager",
        "change_beds",
        "change_operation_mode",
        "change_directors",
        "change_nurse_in_charge",
        "prosecution",
        "expansion_aip",
    }
)
SUPPORTED_APPLICATION_TYPES = (
    APPLICATION_ONLY_READY_TYPES | INTAKE_AND_APPLICATION_READY_TYPES
)

# Bind all parameters from server-side validated constants / the exact pending
# row.  The child row lock prevents two invocations from counting one Update
# twice.  The parent UPDATE and child UPDATE are in one statement/transaction.
# The parent-row sequence is the admission linearization point.  Two UPDATE
# rows may obtain Snowflake IDs in one order but commit admission in another;
# both remain eligible and are dispatched in sequence order.  This avoids
# rejecting a valid earlier-created child just because a later child won the
# parent lock first. A native Received writer may still bypass this queue;
# see ATOMIC_CANCEL_COUNTED_AFTER_RECEIVED_SQL.
# The guarded division forces a rollback if the parent changed but the child
# transition unexpectedly did not happen.  A zero-row result is not accepted;
# the caller must re-read the exact child and classify it before responding.
ATOMIC_ADMIT_PENDING_SQL = """
WITH pending AS MATERIALIZED (
  SELECT child."id", child."f_application_type",
         child."f_parent_create_id"
  FROM "t_api_request_staging" AS child
  WHERE child."id" = :updateId
    AND child."f_parent_create_id" = :createId
    AND child."f_request_event" = 'UPDATE'
    AND child."f_source_system" = :sourceSystem
    AND child."f_api_type" = :updateApiType
    AND child."f_application_type" = :applicationType
    AND child."f_status" = 'admission_pending'
    AND child."f_queue_counted" IS NOT TRUE
    AND child."f_active_update_id" IS NOT NULL
    AND child."f_client_request_id" IS NOT NULL
  FOR UPDATE OF child SKIP LOCKED
), admitted_parent AS (
  UPDATE "t_api_request_staging" AS parent
  SET "f_queue_pending_count" =
      COALESCE(parent."f_queue_pending_count", 0) + 1,
      "f_queue_next_sequence" =
      COALESCE(parent."f_queue_next_sequence", 0) + 1
  FROM pending
  WHERE CAST(parent."id" AS text) = pending."f_parent_create_id"
    AND parent."f_request_event" = 'CREATE'
    AND parent."f_source_system" = :sourceSystem
    AND parent."f_api_type" = :createApiType
    AND parent."f_application_type" = :applicationType
    AND parent."f_status" IN ('submitted', 'processing', 'succeeded')
    AND parent."f_application_status" = 'Accepted'
    AND COALESCE(parent."f_queue_next_sequence", 0) >= 0
    AND COALESCE(parent."f_queue_next_sequence", 0) < 2147483647
  RETURNING parent."id", parent."f_queue_next_sequence"
), admitted_child AS (
  UPDATE "t_api_request_staging" AS child
  SET "f_queue_counted" = TRUE,
      "f_queue_sequence" = admitted_parent."f_queue_next_sequence"
  FROM pending, admitted_parent
  WHERE child."id" = pending."id"
    AND child."f_status" = 'admission_pending'
    AND CAST(admitted_parent."id" AS text) = pending."f_parent_create_id"
  RETURNING child."id"
), result AS (
  SELECT (SELECT COUNT(*) FROM admitted_parent) AS parent_rows,
         (SELECT COUNT(*) FROM admitted_child) AS child_rows,
         (SELECT "id" FROM admitted_child) AS update_id
)
SELECT parent_rows, child_rows, update_id,
       CASE WHEN parent_rows = 0 THEN 0 ELSE 1 / child_rows END
         AS consistency_guard
FROM result;
""".strip()

# Bind :createId to the CREATE Staging ID and :applicationType to a value from
# SUPPORTED_APPLICATION_TYPES (selected by the dispatcher, never the caller).
# Only counted children with a lower admission sequence can precede a queued
# child.  An uncounted admission_pending row is not accepted work and cannot
# stall this queue; if admitted later, it receives a later sequence.  Each
# invocation returns at most
# one child; an empty result means "not ready" or "another worker won" and
# must *not* mark any queued row failed.  SQL reserves the parent slot and
# marks the child claimed but leaves f_status=queued.  A subsequent NocoBase
# ORM conditional queued -> submitted update wakes the existing Collection
# Event; a SQL status update would not.
ATOMIC_FIFO_DISPATCH_SQL = """
WITH parent_guard AS MATERIALIZED (
  SELECT parent."id"
  FROM "t_api_request_staging" AS parent
  WHERE CAST(parent."id" AS text) = CAST(:createId AS text)
    AND parent."f_request_event" = 'CREATE'
    AND parent."f_source_system" = :sourceSystem
    AND parent."f_api_type" = :createApiType
    AND parent."f_status" = 'succeeded'
    AND parent."f_application_status" = 'Accepted'
    AND parent."f_application_type" = :applicationType
    AND parent."f_application_type" IN (
      'new_licence', 'changing_home', 'self_withdraw', 'revoke_licence',
      'specific_hour', 'responsible_person', 'change_home_manager',
      'change_beds', 'change_operation_mode', 'change_directors',
      'change_nurse_in_charge', 'prosecution', 'expansion_aip',
      'licence_renewal'
    )
    AND (parent."f_application_type" = 'licence_renewal'
         OR parent."f_intake_id" IS NOT NULL)
    AND parent."f_application_id" IS NOT NULL
    AND COALESCE(parent."f_queue_pending_count", 0) > 0
    AND parent."f_active_update_id" IS NULL
), candidate AS MATERIALIZED (
  SELECT staged."id", staged."f_parent_create_id",
         staged."f_active_update_id", staged."f_api_type",
         parent_guard."id" AS parent_id
  FROM "t_api_request_staging" AS staged
  JOIN parent_guard
    ON staged."f_parent_create_id" = CAST(parent_guard."id" AS text)
  WHERE staged."f_request_event" = 'UPDATE'
    AND staged."f_source_system" = :sourceSystem
    AND staged."f_api_type" = :updateApiType
    AND staged."f_application_type" = :applicationType
    AND staged."f_status" = 'queued'
    AND staged."f_active_update_id" IS NOT NULL
    AND staged."f_queue_counted" IS TRUE
    AND staged."f_queue_sequence" IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM "t_api_request_staging" AS older
      WHERE older."f_request_event" = 'UPDATE'
        AND older."f_parent_create_id" = staged."f_parent_create_id"
        AND older."f_queue_sequence" < staged."f_queue_sequence"
        AND older."f_queue_counted" IS TRUE
        AND older."f_status" IN
          ('admission_pending', 'queued', 'submitted', 'processing',
           'needs_review')
    )
  ORDER BY staged."f_queue_sequence"
  LIMIT 1
  -- Every queue mutation takes the child lock before the parent lock.
  -- Admission, cancellation and terminal release use the same order.
  FOR UPDATE OF staged SKIP LOCKED
), reserved AS (
  UPDATE "t_api_request_staging" AS parent
  SET "f_active_update_id" = candidate."f_active_update_id"
  FROM candidate
  WHERE parent."id" = candidate.parent_id
    AND parent."f_active_update_id" IS NULL
    AND COALESCE(parent."f_queue_pending_count", 0) > 0
    AND parent."f_application_status" = 'Accepted'
  RETURNING parent."id"
)
UPDATE "t_api_request_staging" AS staged
SET "f_queue_claimed_at" = NOW(),
    "f_attempt_count" = COALESCE(staged."f_attempt_count", 0) + 1
FROM candidate, reserved
WHERE staged."id" = candidate."id"
  AND reserved."id" = candidate.parent_id
  AND staged."f_status" = 'queued'
  AND staged."f_queue_counted" IS TRUE
  AND staged."f_queue_sequence" IS NOT NULL
  AND staged."f_active_update_id" = candidate."f_active_update_id"
RETURNING staged."id", staged."f_parent_create_id",
          staged."f_api_type", staged."f_active_update_id";
""".strip()


ReservedWakeDecision = Literal[
    "wake_required", "submitted", "claimed", "terminal", "isolate"
]


def classify_reserved_orm_wake(
    *,
    child: Mapping[str, Any],
    parent: Mapping[str, Any],
    expected_update_id: int,
    expected_reservation_id: str,
) -> ReservedWakeDecision:
    """Resolve an ambiguous ORM queued -> submitted wake by exact readback."""
    if (
        child.get("id") != expected_update_id
        or child.get("f_request_event") != "UPDATE"
        or child.get("f_active_update_id") != expected_reservation_id
        or str(child.get("f_parent_create_id")) != str(parent.get("id"))
    ):
        return "isolate"
    status = child.get("f_status")
    if status in TERMINAL_STATUSES and child.get("f_queue_counted") is not True:
        return "terminal" if parent.get("f_active_update_id") is None else "isolate"
    if (
        child.get("f_queue_counted") is not True
        or parent.get("f_active_update_id") != expected_reservation_id
    ):
        return "isolate"
    if status == QUEUED:
        return "wake_required"
    if status == DISPATCHED:
        return "submitted"
    if status in {PROCESSING, NEEDS_REVIEW, *TERMINAL_STATUSES}:
        return "claimed"
    return "isolate"

# The ORM queued -> submitted change starts the UPDATE Collection Event.
# This first SQL node reserves one execution without changing f_status, so
# the existing submitted -> processing ORM node can still run.  Its result
# contains the exact row ID and a database-generated worker token; a losing
# execution receives [] and must stop at the next condition node.  The SQL
# result is mapped with JSON Variable Mapping (parseArray=true, paths 0.id
# and 0.f_queue_worker_token) before any business write.
# PostgreSQL's gen_random_uuid() avoids depending on QuickJS crypto support.
# A workflow execution may be redelivered, but only one can claim the row.
# Native Intake Submit is not interlocked with this integration queue.  The
# business owner accepted that rare ordering race, but no worker may start
# after Intake is already Complete (status "4").  Licence Renewal has no
# Intake.  This is a preflight guard, not a guarantee that an in-flight
# native Submit cannot cross between this statement and a later business node.
NATIVE_INTAKE_OPEN_PREDICATE = """
(
  parent."f_application_type" = 'licence_renewal'
  OR EXISTS (
    SELECT 1 FROM "t_intake_form" AS intake
    WHERE CAST(intake."id" AS text) = parent."f_intake_id"
      AND intake."f_approval_status" IS DISTINCT FROM '4'
  )
)
""".strip()

ATOMIC_NATIVE_WORKER_RESERVE_SQL = f"""
UPDATE "t_api_request_staging" AS child
SET "f_queue_phase" = 'preflight',
    "f_queue_worker_token" = gen_random_uuid()::text,
    "f_queue_claimed_at" = NOW()
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_parent_create_id" = :createId
  AND child."f_request_event" = 'UPDATE'
  AND child."f_source_system" = :sourceSystem
  AND child."f_api_type" = :updateApiType
  AND child."f_application_type" = :applicationType
  AND child."f_status" = 'submitted'
  AND child."f_queue_phase" IS NULL
  AND child."f_queue_worker_token" IS NULL
  AND child."f_queue_counted" IS TRUE
  AND child."f_active_update_id" = :reservationId
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_request_event" = 'CREATE'
  AND parent."f_source_system" = :sourceSystem
  AND parent."f_api_type" = :createApiType
  AND parent."f_application_type" = :applicationType
  AND parent."f_status" = 'succeeded'
  AND parent."f_application_status" = 'Accepted'
  AND parent."f_active_update_id" = :reservationId
  AND {NATIVE_INTAKE_OPEN_PREDICATE}
RETURNING child."id", child."f_queue_worker_token";
""".strip()

# Legacy local SQL proof.  The disabled native NLA candidate uses
# ATOMIC_NATIVE_WORKER_RESERVE_SQL followed by its existing ORM processing
# node, not this processing-writing claim.
ATOMIC_WORKER_CLAIM_SQL = f"""
UPDATE "t_api_request_staging" AS child
SET "f_status" = 'processing',
    "f_queue_phase" = 'preflight',
    "f_queue_worker_token" = :workerToken
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_request_event" = 'UPDATE'
  AND child."f_source_system" = :sourceSystem
  AND child."f_api_type" = :updateApiType
  AND child."f_status" = 'submitted'
  AND child."f_queue_phase" IS NULL
  AND child."f_queue_worker_token" IS NULL
  AND child."f_queue_counted" IS TRUE
  AND child."f_active_update_id" = :reservationId
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_request_event" = 'CREATE'
  AND parent."f_source_system" = :sourceSystem
  AND parent."f_api_type" = :createApiType
  AND parent."f_application_type" = child."f_application_type"
  AND parent."f_application_status" = 'Accepted'
  AND parent."f_active_update_id" = :reservationId
  AND {NATIVE_INTAKE_OPEN_PREDICATE}
RETURNING child."id";
""".strip()

# Put this node immediately before the *first* mutation of business data.
# Any later uncertain failure must stay counted/isolated as needs_review;
# neither a worker nor a reconciler may silently retry an applying attempt.
ATOMIC_BEGIN_APPLY_SQL = f"""
UPDATE "t_api_request_staging" AS child
SET "f_queue_phase" = 'applying'
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_request_event" = 'UPDATE'
  AND child."f_status" = 'processing'
  AND child."f_queue_phase" = 'preflight'
  AND child."f_queue_worker_token" = :workerToken
  AND child."f_queue_counted" IS TRUE
  AND child."f_active_update_id" = :reservationId
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_application_status" = 'Accepted'
  AND parent."f_active_update_id" = :reservationId
  AND {NATIVE_INTAKE_OPEN_PREDICATE}
RETURNING child."id";
""".strip()

# Existing UPDATE workflows' error branches cannot mark every exception
# failed.  A preflight failure is known to have written no application data;
# after applying begins, an uncertain failure is isolated and remains counted.
# Both statements are idempotent and fenced to the winning worker token.
ATOMIC_FAIL_PREFLIGHT_SQL = """
UPDATE "t_api_request_staging" AS child
SET "f_status" = 'failed', "f_error_message" = :reason
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_status" = 'processing'
  AND child."f_queue_phase" = 'preflight'
  AND child."f_queue_worker_token" = :workerToken
  AND child."f_queue_counted" IS TRUE
  AND child."f_active_update_id" = :reservationId
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_active_update_id" = :reservationId
RETURNING child."id";
""".strip()

# A retry is permitted only after the caller has independently verified that
# the previous NocoBase execution FINISHED before any business write.  The
# SQL fences the exact old worker and reservation; it does not infer safety
# from elapsed time.  Keep the parent's active slot so younger Updates and
# Received remain blocked.  The dispatcher then invokes the same subflow
# again; its first node must claim a fresh worker token.
ATOMIC_RETRY_PREFLIGHT_SQL = """
UPDATE "t_api_request_staging" AS child
SET "f_status" = 'submitted',
    "f_queue_phase" = NULL,
    "f_queue_worker_token" = NULL,
    "f_queue_claimed_at" = NOW(),
    "f_attempt_count" = child."f_attempt_count" + 1
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_request_event" = 'UPDATE'
  AND child."f_status" = 'processing'
  AND child."f_queue_phase" = 'preflight'
  AND child."f_queue_worker_token" = :workerToken
  AND child."f_queue_counted" IS TRUE
  AND child."f_active_update_id" = :reservationId
  AND child."f_attempt_count" < :maxAttempts
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_request_event" = 'CREATE'
  AND parent."f_application_status" = 'Accepted'
  AND parent."f_active_update_id" = :reservationId
RETURNING child."id", child."f_attempt_count";
""".strip()

ATOMIC_ISOLATE_APPLYING_SQL = """
UPDATE "t_api_request_staging" AS child
SET "f_status" = 'needs_review', "f_error_message" = :reason
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_status" = 'processing'
  AND child."f_queue_phase" = 'applying'
  AND child."f_queue_worker_token" = :workerToken
  AND child."f_queue_counted" IS TRUE
  AND child."f_active_update_id" = :reservationId
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_active_update_id" = :reservationId
RETURNING child."id";
""".strip()

# Optional strict-order barrier for a future release.  The current owner has
# expressly ruled out changing native Intake/Received writers, so this is
# NOT an activation prerequisite for the development queue.  It remains an
# isolated reference contract and must not be installed in native workflows.
RECEIVED_BARRIER_PREDICATE = """
COALESCE(create_row."f_queue_pending_count", 0) = 0
AND create_row."f_active_update_id" IS NULL
AND NOT EXISTS (
  SELECT 1 FROM "t_api_request_staging" AS pending
  WHERE pending."f_request_event" = 'UPDATE'
    AND pending."f_parent_create_id" = CAST(create_row."id" AS text)
    AND pending."f_status" IN
      ('queued', 'submitted', 'processing', 'needs_review')
)
""".strip()

# Strict-order writer reference only; native Received may bypass it by design.
# An admitted child overtaken before business writes is cancelled through
# ATOMIC_CANCEL_COUNTED_AFTER_RECEIVED_SQL.  A still-unadmitted child loses
# later Admission and is rejected without being counted.
ATOMIC_ADVANCE_RECEIVED_SQL = f"""
UPDATE "t_api_request_staging" AS create_row
SET "f_application_status" = 'Received'
WHERE create_row."id" = :createId
  AND create_row."f_request_event" = 'CREATE'
  AND create_row."f_source_system" = :sourceSystem
  AND create_row."f_application_type" = :applicationType
  AND create_row."f_application_status" = 'Accepted'
  AND {RECEIVED_BARRIER_PREDICATE}
RETURNING create_row."id";
""".strip()

# When Received won, close only the exact never-counted child.  An ambiguous
# zero-row Admission
# must first be read back; do not run this merely because a Custom Action
# returned HTTP 200 {}.  The error is stable for same-request-id replay.
ATOMIC_REJECT_UNADMITTED_SQL = """
UPDATE "t_api_request_staging" AS child
SET "f_status" = 'failed',
    "f_error_message" = 'update_locked'
FROM "t_api_request_staging" AS parent
WHERE child."id" = :updateId
  AND child."f_parent_create_id" = :createId
  AND child."f_request_event" = 'UPDATE'
  AND child."f_source_system" = :sourceSystem
  AND child."f_api_type" = :updateApiType
  AND child."f_status" = 'admission_pending'
  AND child."f_queue_counted" IS NOT TRUE
  AND CAST(parent."id" AS text) = child."f_parent_create_id"
  AND parent."f_request_event" = 'CREATE'
  AND parent."f_application_type" = child."f_application_type"
  AND parent."f_application_status" <> 'Accepted'
RETURNING child."id";
""".strip()

# The native Intake workflow and its Received bridge are intentionally not
# interlocked with this queue.  A counted child overtaken before its first
# business write remains an audit row, but must not be applied.  The SQL node
# runs for one exact child, in a bounded reconciler or immediately after a
# zero-row worker claim/begin-apply.  It is safe for a queued sibling to be
# cancelled while a different child owns the active reservation: only this
# child's reservation may be cleared.  A child in applying/needs_review is
# never eligible, since its business write may already have happened.
# SQL changes do not emit Collection Events; the caller must explicitly run
# the bounded Pump after an exact 1|1 result, or let the scheduled reconciler
# do so.  A zero-row result is not proof of cancellation.
ATOMIC_CANCEL_COUNTED_AFTER_RECEIVED_SQL = """
WITH cancellable AS MATERIALIZED (
  SELECT child."id", child."f_parent_create_id",
         child."f_active_update_id"
  FROM "t_api_request_staging" AS child
  WHERE child."id" = :updateId
    AND child."f_parent_create_id" = :createId
    AND child."f_request_event" = 'UPDATE'
    AND child."f_source_system" = :sourceSystem
    AND child."f_api_type" = :updateApiType
    AND child."f_application_type" = :applicationType
    AND child."f_queue_counted" IS TRUE
    AND child."f_active_update_id" = :reservationId
    AND (
      child."f_status" IN ('admission_pending', 'queued', 'submitted')
      OR (child."f_status" = 'processing'
          AND child."f_queue_phase" = 'preflight')
    )
  FOR UPDATE OF child SKIP LOCKED
), cancelled_parent AS (
  UPDATE "t_api_request_staging" AS parent
  SET "f_queue_pending_count" = parent."f_queue_pending_count" - 1,
      "f_active_update_id" = CASE
        WHEN parent."f_active_update_id" = :reservationId THEN NULL
        ELSE parent."f_active_update_id" END
  FROM cancellable
  WHERE CAST(parent."id" AS text) = cancellable."f_parent_create_id"
    AND parent."f_request_event" = 'CREATE'
    AND parent."f_source_system" = :sourceSystem
    AND parent."f_api_type" = :createApiType
    AND parent."f_application_type" = :applicationType
    AND parent."f_queue_pending_count" > 0
    AND (
      parent."f_application_status" IS DISTINCT FROM 'Accepted'
      OR (parent."f_application_type" <> 'licence_renewal'
          AND EXISTS (
            SELECT 1 FROM "t_intake_form" AS intake
            WHERE CAST(intake."id" AS text) = parent."f_intake_id"
              AND intake."f_approval_status" = '4'
          ))
    )
  RETURNING parent."id"
), cancelled_child AS (
  UPDATE "t_api_request_staging" AS child
  SET "f_status" = 'failed',
      "f_error_message" = 'update_locked_after_admission',
      "f_queue_counted" = FALSE
  FROM cancellable, cancelled_parent
  WHERE child."id" = cancellable."id"
    AND CAST(cancelled_parent."id" AS text) =
        cancellable."f_parent_create_id"
  RETURNING child."id"
), result AS (
  SELECT (SELECT COUNT(*) FROM cancelled_parent) AS parent_rows,
         (SELECT COUNT(*) FROM cancelled_child) AS child_rows,
         (SELECT "id" FROM cancelled_child) AS update_id
)
SELECT parent_rows, child_rows, update_id,
       CASE WHEN parent_rows = 0 THEN 0 ELSE 1 / child_rows END
         AS consistency_guard
FROM result;
""".strip()

# A terminal child can release only its own reservation.  This preliminary
# predicate is also embedded in the atomic counted-release below.
RELEASE_TERMINAL_RESERVATION_SQL = """
WITH terminal_child AS MATERIALIZED (
  SELECT child."id", child."f_parent_create_id",
         child."f_active_update_id"
  FROM "t_api_request_staging" AS child
  WHERE child."id" = :updateId
    AND child."f_parent_create_id" = :createId
    AND child."f_request_event" = 'UPDATE'
    AND child."f_status" IN ('succeeded', 'failed')
    AND child."f_queue_counted" IS TRUE
    AND child."f_active_update_id" = :reservationId
  FOR UPDATE OF child SKIP LOCKED
), released_parent AS (
  UPDATE "t_api_request_staging" AS parent
  SET "f_queue_pending_count" = parent."f_queue_pending_count" - 1,
      "f_active_update_id" = NULL
  FROM terminal_child
  WHERE CAST(parent."id" AS text) = terminal_child."f_parent_create_id"
    AND parent."f_request_event" = 'CREATE'
    AND parent."f_active_update_id" = :reservationId
    AND parent."f_queue_pending_count" > 0
  RETURNING parent."id"
), released_child AS (
  UPDATE "t_api_request_staging" AS child
  SET "f_queue_counted" = FALSE
  FROM terminal_child, released_parent
  WHERE child."id" = terminal_child."id"
    AND CAST(released_parent."id" AS text) =
        terminal_child."f_parent_create_id"
  RETURNING child."id"
), result AS (
  SELECT (SELECT COUNT(*) FROM released_parent) AS parent_rows,
         (SELECT COUNT(*) FROM released_child) AS child_rows
)
SELECT parent_rows, child_rows,
       CASE WHEN parent_rows = 0 THEN 0 ELSE 1 / child_rows END
         AS consistency_guard
FROM result;
""".strip()

# The NLA worker success path uses this stronger terminal fence.  It releases
# only the execution that won the worker token and crossed begin_apply; a
# duplicate/substituted workflow execution cannot release another row's slot.
# A bounded reconciler may use RELEASE_TERMINAL_RESERVATION_SQL after exact
# terminal readback if this in-flow SQL node did not run.
ATOMIC_RELEASE_CLAIMED_SUCCESS_SQL = """
WITH terminal_child AS MATERIALIZED (
  SELECT child."id", child."f_parent_create_id",
         child."f_active_update_id"
  FROM "t_api_request_staging" AS child
  WHERE child."id" = :updateId
    AND child."f_parent_create_id" = :createId
    AND child."f_request_event" = 'UPDATE'
    AND child."f_source_system" = :sourceSystem
    AND child."f_api_type" = :updateApiType
    AND child."f_application_type" = :applicationType
    AND child."f_status" = 'succeeded'
    AND child."f_queue_phase" = 'applying'
    AND child."f_queue_worker_token" = :workerToken
    AND child."f_queue_counted" IS TRUE
    AND child."f_active_update_id" = :reservationId
  FOR UPDATE OF child SKIP LOCKED
), released_parent AS (
  UPDATE "t_api_request_staging" AS parent
  SET "f_queue_pending_count" = parent."f_queue_pending_count" - 1,
      "f_active_update_id" = NULL
  FROM terminal_child
  WHERE CAST(parent."id" AS text) = terminal_child."f_parent_create_id"
    AND parent."f_request_event" = 'CREATE'
    AND parent."f_source_system" = :sourceSystem
    AND parent."f_api_type" = :createApiType
    AND parent."f_application_type" = :applicationType
    AND parent."f_active_update_id" = :reservationId
    AND parent."f_queue_pending_count" > 0
  RETURNING parent."id"
), released_child AS (
  UPDATE "t_api_request_staging" AS child
  SET "f_queue_counted" = FALSE,
      "f_queue_phase" = 'finished'
  FROM terminal_child, released_parent
  WHERE child."id" = terminal_child."id"
    AND CAST(released_parent."id" AS text) =
        terminal_child."f_parent_create_id"
  RETURNING child."id"
), result AS (
  SELECT (SELECT COUNT(*) FROM released_parent) AS parent_rows,
         (SELECT COUNT(*) FROM released_child) AS child_rows,
         (SELECT "id" FROM released_parent) AS create_id,
         (SELECT "id" FROM released_child) AS update_id
)
SELECT parent_rows, child_rows, create_id, update_id,
       CASE WHEN parent_rows = 0 THEN 0 ELSE 1 / child_rows END
         AS consistency_guard
FROM result;
""".strip()

# The NLA worker has one deterministic *pre-write* failure branch: the
# referenced CREATE/business row cannot be resolved after the exact worker
# claim.  That branch must release its reservation before the next FIFO Pump.
# It uses the same child-first lock order and worker-token fence as success,
# but must never match a failure after application writes have begun.
ATOMIC_RELEASE_CLAIMED_PREFLIGHT_FAILURE_SQL = (
    ATOMIC_RELEASE_CLAIMED_SUCCESS_SQL
    .replace('child."f_status" = \'succeeded\'',
             'child."f_status" = \'failed\'')
    .replace('child."f_queue_phase" = \'applying\'',
             'child."f_queue_phase" = \'preflight\'')
)

# Migration PLAN only.  Before installing the index, audit and resolve old
# duplicates, and populate f_client_request_id for newly admitted requests.
# Validation-error audit rows are excluded because they are not accepted work.
IDEMPOTENCY_DUPLICATE_AUDIT_SQL = """
SELECT "f_source_system", "f_api_type", "f_parent_create_id",
       "f_client_request_id", COUNT(*) AS duplicate_count
FROM "t_api_request_staging"
WHERE "f_request_event" = 'UPDATE'
  AND "f_client_request_id" IS NOT NULL
  AND "f_status" NOT IN ('missing_required', 'invalid_request')
GROUP BY "f_source_system", "f_api_type", "f_parent_create_id",
         "f_client_request_id"
HAVING COUNT(*) > 1;
""".strip()

IDEMPOTENCY_UNIQUE_INDEX_SQL = """
CREATE UNIQUE INDEX uq_api_staging_accepted_update_request
ON "t_api_request_staging"
  ("f_source_system", "f_api_type", "f_parent_create_id",
   "f_client_request_id")
WHERE "f_request_event" = 'UPDATE'
  AND "f_client_request_id" IS NOT NULL
  AND "f_status" NOT IN ('missing_required', 'invalid_request');
""".strip()

# f_active_update_id on an UPDATE child is its server-generated reservation
# UUID (already present on the live staging collection), not the client
# request ID.  The same value is copied into the CREATE parent's active slot
# while that child is running.  This index catches a faulty token generator.
RESERVATION_TOKEN_UNIQUE_INDEX_SQL = """
CREATE UNIQUE INDEX uq_api_staging_update_reservation_token
ON "t_api_request_staging" ("f_active_update_id")
WHERE "f_request_event" = 'UPDATE'
  AND "f_active_update_id" IS NOT NULL;
""".strip()

# Admission sequence is unique only among counted UPDATE children of a
# CREATE parent.  A terminal child retains its sequence for audit, while the
# parent's counter never decreases; the partial index catches duplicate
# active slots without placing historical validation rows in scope.
COUNTED_SEQUENCE_DUPLICATE_AUDIT_SQL = """
SELECT "f_parent_create_id", "f_queue_sequence", COUNT(*) AS duplicate_count
FROM "t_api_request_staging"
WHERE "f_request_event" = 'UPDATE'
  AND "f_queue_counted" IS TRUE
  AND "f_queue_sequence" IS NOT NULL
GROUP BY "f_parent_create_id", "f_queue_sequence"
HAVING COUNT(*) > 1;
""".strip()

COUNTED_SEQUENCE_UNIQUE_INDEX_SQL = """
CREATE UNIQUE INDEX uq_api_staging_counted_update_sequence
ON "t_api_request_staging" ("f_parent_create_id", "f_queue_sequence")
WHERE "f_request_event" = 'UPDATE'
  AND "f_queue_counted" IS TRUE
  AND "f_queue_sequence" IS NOT NULL;
""".strip()

ExecutionState = Literal["running", "finished", "unknown"]
RecoveryAction = Literal[
    "retry_admission",
    "wait_ready",
    "invoke_subflow",
    "wait_execution",
    "retry_preflight",
    "isolate",
    "terminal",
]
BoundaryAction = Literal[
    "none", "cancel_counted", "release_terminal", "isolate"
]
AdmissionDecision = Literal[
    "accepted",
    "retry_admission",
    "wake_required",
    "reject_unadmitted",
    "update_locked",
    "idempotency_conflict",
    "isolate",
]


def classify_admission_readback(
    *,
    row: Mapping[str, Any],
    parent_application_status: str,
    parent_next_sequence: int | None = None,
    source_system: str,
    api_type: str,
    application_type: str,
    create_id: str,
    request_id: str,
    request_body: Mapping[str, Any],
    reservation_id: str | None = None,
) -> AdmissionDecision:
    """Decide whether synchronous Admission actually accepted an UPDATE.

    NocoBase Custom Action may return HTTP 200 and an empty object for both
    one and zero changed rows.  The caller must re-read the exact child (or
    find it by the unique client request key) with the *customer* token and
    pass that row here.  A duplicate request ID with a different body is a
    conflict, never a new UPDATE.  This helper performs no network or writes.
    """

    identity = {
        "f_request_event": "UPDATE",
        "f_source_system": source_system,
        "f_api_type": api_type,
        "f_application_type": application_type,
        "f_parent_create_id": str(create_id),
        "f_client_request_id": request_id,
    }
    if any(str(row.get(name)) != str(value) for name, value in identity.items()):
        return "isolate"
    if not isinstance(row.get("f_active_update_id"), str) or not row.get(
        "f_active_update_id"
    ):
        return "isolate"
    if reservation_id is not None and row.get("f_active_update_id") != reservation_id:
        return "isolate"
    actual_body = row.get("f_request_body")
    if not isinstance(actual_body, dict):
        return "isolate"
    if json.dumps(actual_body, sort_keys=True, separators=(",", ":")) != json.dumps(
        dict(request_body), sort_keys=True, separators=(",", ":")
    ):
        return "idempotency_conflict"

    row_id = row.get("id")
    if not isinstance(row_id, int) or isinstance(row_id, bool) or row_id < 1:
        return "isolate"
    sequence = row.get("f_queue_sequence")
    if sequence is not None and (
        not isinstance(sequence, int)
        or isinstance(sequence, bool)
        or sequence < 1
    ):
        return "isolate"
    if parent_next_sequence is None:
        parent_next_sequence = 0
    if (
        not isinstance(parent_next_sequence, int)
        or isinstance(parent_next_sequence, bool)
        or parent_next_sequence < 0
        or parent_next_sequence > 2147483647
    ):
        return "isolate"

    status = row.get("f_status")
    counted = row.get("f_queue_counted") is True
    attempts = row.get("f_attempt_count")
    phase = row.get("f_queue_phase")
    if status in {QUEUED, DISPATCHED, PROCESSING, NEEDS_REVIEW}:
        return (
            "accepted"
            if counted and sequence is not None and parent_next_sequence >= sequence
            else "isolate"
        )
    if status in TERMINAL_STATUSES:
        if (
            status == "failed"
            and row.get("f_error_message") == "update_locked_after_admission"
            and not counted
            and sequence is not None
            and parent_next_sequence >= sequence
        ):
            return "accepted"
        if sequence is not None and parent_next_sequence >= sequence and (
            counted or (
                isinstance(attempts, int)
                and not isinstance(attempts, bool)
                and attempts > 0
                and phase in {"preflight", "applying", "finished"}
            )
        ):
            return "accepted"
        if (
            status == "failed"
            and row.get("f_error_message") == "update_locked"
            and not counted
        ):
            return "update_locked"
        return "isolate"
    if status == ADMISSION_PENDING and not counted:
        if sequence is not None:
            return "isolate"
        if parent_application_status != "Accepted":
            return "reject_unadmitted"
        return "retry_admission"
    if status == ADMISSION_PENDING and counted:
        if sequence is None or parent_next_sequence < sequence:
            return "isolate"
        return (
            "wake_required" if parent_application_status == "Accepted" else "accepted"
        )
    return "isolate"


def classify_boundary_reconciliation(
    *,
    status: str,
    phase: str | None,
    counted: bool,
    parent_application_status: str,
    intake_complete: bool,
) -> BoundaryAction:
    """Select only safe post-Received actions for a *single exact* UPDATE.

    This is a scheduling hint, never proof that an SQL node changed a row.
    Every action must use its own fenced SQL and exact parent/child readback.
    Unknown or post-write states are isolated for human investigation.
    """

    if not counted:
        return "none"
    if status in TERMINAL_STATUSES:
        return "release_terminal"
    if status == NEEDS_REVIEW or (status == PROCESSING and phase != "preflight"):
        return "isolate"
    if parent_application_status == "Accepted" and not intake_complete:
        return "none"
    if status in {ADMISSION_PENDING, QUEUED, DISPATCHED} or (
        status == PROCESSING and phase == "preflight"
    ):
        return "cancel_counted"
    return "isolate"


def classify_recovery(
    *,
    status: str,
    phase: str | None,
    execution_state: ExecutionState,
    attempts: int,
    max_preflight_attempts: int = 3,
) -> RecoveryAction:
    """Classify a stranded UPDATE without guessing whether writes occurred.

    A workflow revision must atomically set ``processing + preflight`` in its
    first node, and set ``applying`` *before* its first business mutation.  An
    unrecognized phase, uncertain execution state, or exhausted retry budget
    is isolated; elapsed time alone never proves an execution has stopped.
    """

    if attempts < 0 or max_preflight_attempts < 1:
        raise ValueError("attempt counts must be non-negative; max must be positive")
    if execution_state not in {"running", "finished", "unknown"}:
        raise ValueError("unknown execution state")
    if status in TERMINAL_STATUSES:
        return "terminal"
    if status == ADMISSION_PENDING:
        return "retry_admission"
    if status == QUEUED:
        return "wait_ready"
    if status == DISPATCHED:
        return "invoke_subflow"
    if status == NEEDS_REVIEW:
        return "isolate"
    if status != PROCESSING:
        return "isolate"
    if execution_state == "running":
        return "wait_execution"
    if execution_state != "finished":
        return "isolate"
    if phase == "preflight" and attempts < max_preflight_attempts:
        return "retry_preflight"
    return "isolate"


def failure_status(*, phase: str | None) -> str:
    """Only a failure known to precede every business write may be skipped."""

    return "failed" if phase == "preflight" else NEEDS_REVIEW
