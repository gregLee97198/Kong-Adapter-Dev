#!/usr/bin/env python3
"""Revise enabled API staging workflows from Submitted to Accepted.

Only values underneath the exact f_application_status key are changed.
Internal f_status=submitted triggers are intentionally left untouched.
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.parse
from typing import Any

from extend_nocobase_staging_relations import ApiError, NocoBaseApi
from upgrade_nocobase_phase_a_status_contract import update_application_status_field


def replace_status(value: Any, *, under_application_status: bool = False) -> tuple[Any, int]:
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        count = 0
        for key, item in value.items():
            replaced, changed = replace_status(
                item,
                under_application_status=under_application_status or key == "f_application_status",
            )
            result[key] = replaced
            count += changed
        return result, count
    if isinstance(value, list):
        result = []
        count = 0
        for item in value:
            replaced, changed = replace_status(item, under_application_status=under_application_status)
            result.append(replaced)
            count += changed
        return result, count
    if under_application_status and value == "Submitted":
        return "Accepted", 1
    return value, 0


def workflow_candidates(api: NocoBaseApi) -> list[dict[str, Any]]:
    rows = api.request(
        "GET",
        "/api/workflows:list?" + urllib.parse.urlencode({"pageSize": 500, "appends[]": "nodes"}),
    )
    result = []
    for row in rows or []:
        if not row.get("enabled"):
            continue
        _, workflow_changes = replace_status(row.get("config") or {})
        node_changes = sum(replace_status(node.get("config") or {})[1] for node in row.get("nodes") or [])
        if workflow_changes + node_changes:
            result.append(row)
    return result


def revise(api: NocoBaseApi, row: dict[str, Any]) -> dict[str, Any]:
    old_id = int(row["id"])
    api.request("POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": False})
    query = urllib.parse.urlencode({"filterByTk": old_id, "filter[key]": row["key"]})
    created = api.request("POST", f"/api/workflows:revision?{query}", {})
    if not isinstance(created, dict) or created.get("id") is None:
        raise ApiError(f"Could not revise workflow {old_id}")
    return api.get_workflow(int(created["id"]))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://119.91.104.211:13001/cmtf2")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = NocoBaseApi(args.base_url, token)
    candidates = workflow_candidates(api)
    print(f"candidate_count={len(candidates)}")
    for row in candidates:
        print(f"candidate={row['id']} title={row.get('title')}")
    print("internal_f_status=submitted unchanged")
    if not args.apply:
        print("mode=dry-run")
        return 0

    update_application_status_field(api)
    completed: list[tuple[int, int]] = []
    try:
        for old in candidates:
            revised = revise(api, old)
            workflow_config, _ = replace_status(revised.get("config") or {})
            api.request("POST", f"/api/workflows:update?filterByTk={revised['id']}", {"config": workflow_config})
            for node in revised.get("nodes") or []:
                node_config, count = replace_status(node.get("config") or {})
                if count:
                    api.update_node(int(node["id"]), {"config": node_config})
            api.request("POST", f"/api/workflows:update?filterByTk={revised['id']}", {"enabled": True})
            completed.append((int(old["id"]), int(revised["id"])))
            print(f"revised={old['id']}->{revised['id']}")
        print("mode=applied")
        return 0
    except Exception:
        for old_id, new_id in completed:
            try:
                api.request("POST", f"/api/workflows:update?filterByTk={new_id}", {"enabled": False})
                api.request("POST", f"/api/workflows:update?filterByTk={old_id}", {"enabled": True})
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
