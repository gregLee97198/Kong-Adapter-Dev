#!/usr/bin/env python3
"""Revise 13001 CHI staging workflows to persist selected Part 2/3 changes.

This upgrades editable workflow revisions, not the native CHI/Intake submit
flows. The CREATE and UPDATE triggers remain restricted to one submitted OP
staging row; no node writes the CREATE staging row back to submitted.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from create_nocobase_phase_c_chi_workflows import (
    APPLICATION_COLLECTION,
    CREATE_TITLE,
    UPDATE_TITLE,
    RootNocoBaseApi,
    create_node,
    link,
    query_config,
    ref,
    scope,
    update_config,
)
from extend_nocobase_staging_relations import CONTACT_FIELDS, ApiError
from create_nocobase_staging_update_workflow import field_references


OPERATOR_RELATION = "f_api_chi_change_operator"
OPERATOR_FOREIGN_KEY = "fk_api_chi_change_operator"
APP_FIELDS = [
    "is_change_name", "is_change_address",
    "is_change_operator_or_operating_company", "is_change_rch_type",
    "is_change_maximum_capacity", "is_aip", "f_application_received_date",
    "f_rch_name_en", "f_rch_name_cn", "f_telephone_no", "f_fax_no",
    "f_email", "f_rch_gender", "f_rch_premises",
    "f_monthly_fee_per_resident_min", "f_monthly_fee_per_resident_max",
    "f_net_floor_area_sqm", "f_licence_capacity", "f_beds_nursing",
    "f_beds_care_and_attention", "f_beds_meal", "f_beds_self_care",
    "f_tentative_service_commencement_date", "f_application_level",
    "f_comments", "f_other_information", "f_remarks", "f_attachments_of_rchs",
    "f_office_cd", "fk_type_of_rch", "fk_home_record",
]
CONTACT_KEYS = [*CONTACT_FIELDS.values(), OPERATOR_FOREIGN_KEY,
                "fk_licence_contact_company"]


def node_by_title(workflow: Mapping[str, Any], title: str) -> dict[str, Any]:
    found = [dict(node) for node in workflow.get("nodes") or []
             if node.get("title") == title]
    if len(found) != 1:
        raise ApiError(f"Expected one node {title!r}, found {len(found)}")
    return found[0]


def patch_script() -> str:
    app_part_2 = {
        "rch_name_en": "f_rch_name_en", "rch_name_cn": "f_rch_name_cn",
        "telephone_no": "f_telephone_no", "fax_no": "f_fax_no",
        "email": "f_email", "gender": "f_rch_gender",
        "premises_type": "f_rch_premises",
        "monthly_fee_min": "f_monthly_fee_per_resident_min",
        "monthly_fee_max": "f_monthly_fee_per_resident_max",
        "floor_area_sqm": "f_net_floor_area_sqm",
        "licence_capacity": "f_licence_capacity",
        "nursing_home_places": "f_beds_nursing",
        "care_and_attention_home_places": "f_beds_care_and_attention",
        "aged_home_places": "f_beds_meal",
        "self_care_hostel_places": "f_beds_self_care",
    }
    app_part_5 = {
        "application_level": "f_application_level", "comments": "f_comments",
        "other_information": "f_other_information", "remarks": "f_remarks",
        "attachment_ids": "f_attachments_of_rchs",
    }
    replacements = {
        "__APP_FIELDS__": json.dumps(APP_FIELDS),
        "__CONTACT_KEYS__": json.dumps(CONTACT_KEYS),
        "__PART2_MAP__": json.dumps(app_part_2),
        "__PART5_MAP__": json.dumps(app_part_5),
        "__CONTACT_MAP__": json.dumps(CONTACT_FIELDS),
        "__OPERATOR_FK__": json.dumps(OPERATOR_FOREIGN_KEY),
    }
    content = r"""const f = formData || {};
const app = application || {};
const p1 = f.part_1 || {};
const p2 = f.part_2 || {};
const p3 = f.part_3 || {};
const p5 = f.part_5 || {};
const summary = f.case_summary || {};
const own = (o, k) => o && Object.prototype.hasOwnProperty.call(o, k);
const initial = (row, names) => Object.fromEntries(names.map(k =>
  [k, own(row, k) ? row[k] : null]));
const assign = (target, source, map) => {
  for (const [external, internal] of Object.entries(map)) {
    if (own(source, external)) target[internal] = source[external];
  }
};
const appPatch = initial(app, __APP_FIELDS__);
if (Array.isArray(app.f_attachments_of_rchs))
  appPatch.f_attachments_of_rchs = app.f_attachments_of_rchs.map(value =>
    value && value.id ? value.id : value);
for (const flag of ['is_change_name', 'is_change_address',
  'is_change_operator_or_operating_company', 'is_change_rch_type',
  'is_change_maximum_capacity', 'is_aip']) {
  if (own(f, flag)) appPatch[flag] = f[flag];
}
if (own(p1, 'application_received_date'))
  appPatch.f_application_received_date = p1.application_received_date;
if (own(p1, 'tentative_commencement_date'))
  appPatch.f_tentative_service_commencement_date = p1.tentative_commencement_date;
assign(appPatch, p2, __PART2_MAP__);
assign(appPatch, p5, __PART5_MAP__);
if (own(summary, 'office_code')) appPatch.f_office_cd = summary.office_code;
if (f.is_change_maximum_capacity === true) {
  const capacity = own(p2, 'max_capacity') ? p2.max_capacity : p2.licence_capacity;
  if (own(p2, 'max_capacity') && own(p2, 'licence_capacity')
      && Number(p2.max_capacity) !== Number(p2.licence_capacity))
    throw new Error('max_capacity and licence_capacity conflict');
  appPatch.f_licence_capacity = capacity;
}
if (f.is_change_rch_type === true) {
  const office = summary.office_code || app.f_office_cd;
  const rows = Array.isArray(rchTypeOptions) ? rchTypeOptions : [];
  const match = rows.find(row => String(row.f_code) === String(p2.rch_type_code)
    && String(row.f_for_office) === String(office));
  if (!match) throw new Error('Unknown rch_type_code for office_code');
  appPatch.fk_type_of_rch = match.id;
}
const contacts = [];
const contact = (payload, current, foreignKey) => {
  if (!payload) return;
  const row = current || {};
  if (own(payload, 'id') && String(payload.id) !== String(row.id || ''))
    throw new Error('Contact ID is not linked to this CHI');
  const patch = initial(row, __CONTACT_KEYS__);
  assign(patch, payload, __CONTACT_MAP__);
  patch[foreignKey] = app.id;
  contacts.push({ id: row.id || 0, patch });
};
if (f.is_change_operator_or_operating_company === true) {
  contact(p3.operator, operatorContact, __OPERATOR_FK__);
  contact(p3.company, companyContact, 'fk_licence_contact_company');
}
return { app_patch: appPatch, contact_updates: contacts };
"""
    for marker, value in replacements.items():
        content = content.replace(marker, value)
    return content


def ensure_operator_relation(api: RootNocoBaseApi) -> None:
    path = (f"/api/collections/{APPLICATION_COLLECTION}/fields:get?"
            + urllib.parse.urlencode({"filterByTk": OPERATOR_RELATION}))
    fields = api.request(
        "GET", f"/api/collections/{APPLICATION_COLLECTION}/fields:list?pageSize=500"
    ) or []
    named = [field for field in fields if field.get("name") == OPERATOR_RELATION]
    if len(named) > 1:
        raise ApiError("Multiple CHI operator relation fields exist")
    if named:
        existing = api.request("GET", path)
        if (existing.get("target"), existing.get("foreignKey")) != (
            "t_licence_contact", OPERATOR_FOREIGN_KEY
        ):
            raise ApiError("Existing CHI operator relation has incompatible target/FK")
        return
    api.request(
        "POST", f"/api/collections/{APPLICATION_COLLECTION}/fields:create",
        {
            "name": OPERATOR_RELATION,
            "type": "hasOne", "interface": "oho",
            "collectionName": APPLICATION_COLLECTION,
            "target": "t_licence_contact", "foreignKey": OPERATOR_FOREIGN_KEY,
            "sourceKey": "id", "targetKey": "id", "onDelete": "SET NULL",
            "uiSchema": {
                "type": "object", "title": "CHI Operator Change Values",
                "x-component": "AssociationField",
                "x-component-props": {"multiple": False},
            },
        },
    )
    created = api.request("GET", path)
    if not isinstance(created, dict) or created.get("name") != OPERATOR_RELATION:
        raise ApiError("CHI operator relation was not created")


def revise(api: RootNocoBaseApi, workflow: Mapping[str, Any]) -> dict[str, Any]:
    old_id = int(workflow["id"])
    api.request("POST", f"/api/workflows:update?filterByTk={old_id}",
                {"enabled": False})
    query = urllib.parse.urlencode({"filterByTk": old_id,
                                    "filter[key]": str(workflow["key"])})
    created = api.request("POST", f"/api/workflows:revision?{query}", {})
    if not isinstance(created, dict) or not created.get("id"):
        raise ApiError("CHI workflow revision returned no ID")
    revision = api.get_workflow(int(created["id"]))
    if revision.get("enabled") or revision.get("executed"):
        raise ApiError("CHI workflow revision is not editable")
    return revision


def add_category_nodes(api: RootNocoBaseApi, workflow: dict[str, Any], *,
                       updating: bool) -> None:
    wid = int(workflow["id"])
    parse = node_by_title(workflow, "Parse staged CHI update body" if updating
                          else "Parse staged CHI request body")
    config = dict(parse.get("config") or {})
    variables = list(config.get("variables") or [])
    if not any(v.get("key") == "formData" for v in variables):
        variables.append({"key": "formData", "path": "form_data",
                          "name": "form_data", "paths": ["form_data"]})
        config["variables"] = variables
        api.update_node(int(parse["id"]), {"config": config})
    application = node_by_title(workflow, "Resolve linked CHI" if updating
                                else "Find native-created CHI")
    application_config = dict(application.get("config") or {})
    application_params = dict(application_config.get("params") or {})
    current_appends = list(application_params.get("appends") or [])
    if "f_attachments_of_rchs" not in current_appends:
        current_appends.append("f_attachments_of_rchs")
        application_params["appends"] = current_appends
        application_config["params"] = application_params
        api.update_node(int(application["id"]), {"config": application_config})
    exists = node_by_title(workflow, "Linked CHI exists" if updating
                           else "Native CHI exists")
    apply = node_by_title(workflow, "Apply staged CHI update overlay" if updating
                          else "Apply staged flags and overlay to native CHI")
    successor = node_by_title(workflow, "Mark update succeeded + backfill IDs"
                              if updating else
                              "Apply Checklist files to native CHI records")
    types = create_node(api, wid, "query", "Load CHI type code dictionary",
        query_config("f_rch_type_options", [], multiple=True))
    operator = create_node(api, wid, "query", "Load CHI operator change contact",
        query_config("t_licence_contact", [
            {OPERATOR_FOREIGN_KEY: {"$eq": ref(application, "id")}}]))
    company = create_node(api, wid, "query", "Load CHI company contact",
        query_config("t_licence_contact", [
            {"fk_licence_contact_company": {"$eq": ref(application, "id")}}]))
    normalize = create_node(api, wid, "script", "Build guarded CHI category patches",
        {"arguments": [
            {"name": "formData", "value": ref(parse, "formData")},
            {"name": "application", "value": ref(application)},
            {"name": "rchTypeOptions", "value": ref(types)},
            {"name": "operatorContact", "value": ref(operator)},
            {"name": "companyContact", "value": ref(company)},
        ], "content": patch_script(), "timeout": 0, "continue": False})
    patched = dict(apply.get("config") or {})
    patched["params"]["values"] = field_references(
        normalize, "app_patch", APP_FIELDS)
    api.update_node(int(apply["id"]), {"config": patched})
    contact_loop = create_node(api, wid, "loop", "Apply changed CHI contacts",
        {"target": ref(normalize, "contact_updates"), "condition": False,
         "exit": 0})
    contact_exists = create_node(api, wid, "condition", "Changed CHI contact exists",
        {"rejectOnFalse": False, "engine": "basic", "calculation": {
            "group": {"type": "and", "calculations": [{"calculator": "gt",
                "operands": [scope(contact_loop, "id"), 0]}]}}})
    update_contact = create_node(api, wid, "update", "Update changed CHI contact",
        update_config("t_licence_contact", scope(contact_loop, "id"),
                      {name: scope(contact_loop, "patch." + name)
                       for name in CONTACT_KEYS}))
    create_contact = create_node(api, wid, "create", "Create changed CHI contact",
        {"collection": "t_licence_contact", "params": {"values":
            {name: scope(contact_loop, "patch." + name)
             for name in CONTACT_KEYS}, "appends": []}})
    link(api, exists, types, branch_index=1)
    link(api, types, operator)
    link(api, operator, company)
    link(api, company, normalize)
    link(api, normalize, apply)
    link(api, apply, contact_loop)
    link(api, contact_loop, contact_exists, branch_index=0)
    link(api, contact_exists, update_contact, branch_index=1)
    link(api, contact_exists, create_contact, branch_index=0)
    if updating:
        add_update_checklist(api, workflow, parse, application, contact_loop, successor)
    else:
        link(api, contact_loop, successor)


def add_update_checklist(api: RootNocoBaseApi, workflow: Mapping[str, Any],
                         parse: Mapping[str, Any], application: Mapping[str, Any],
                         upstream: Mapping[str, Any], successor: Mapping[str, Any]) -> None:
    wid = int(workflow["id"])
    loop = create_node(api, wid, "loop", "Apply changed CHI Checklist files",
        {"target": ref(parse, "checklist"), "condition": False, "exit": 2})
    template = create_node(api, wid, "query", "Resolve changed CHI Checklist code",
        query_config("t_document_checklist", [
            {"f_position_code": {"$eq": scope(loop, "position_code")}},
            {"f_active": {"$eq": True}},
            {"f_item_type": {"$eq": "2"}},
            {"f_use_for": {"$anyOf": [APPLICATION_COLLECTION, "t_licence_app"]}},
        ]))
    item = create_node(api, wid, "query", "Find changed CHI Checklist item",
        query_config("t_document_submitted_for_application", [
            {"f_business_key": {"$eq": ref(application, "id")}},
            {"fk_document_checklist": {"$eq": ref(template, "id")}},
            {"f_business_type": {"$eq": APPLICATION_COLLECTION}},
        ]))
    exists = create_node(api, wid, "condition", "Changed CHI Checklist item exists",
        {"rejectOnFalse": False, "engine": "basic", "calculation": {
            "group": {"type": "and", "calculations": [{"calculator": "gt",
                "operands": [ref(item, "id"), 0]}]}}})
    values = {"f_is_checked": True,
              "f_lastest_files": [scope(loop, "attachment_id")]}
    update = create_node(api, wid, "update", "Replace CHI Checklist file",
        update_config("t_document_submitted_for_application", ref(item, "id"), values))
    create = create_node(api, wid, "create", "Create changed CHI Checklist item",
        {"collection": "t_document_submitted_for_application", "params": {
            "values": {"f_business_key": ref(application, "id"),
                       "f_business_type": APPLICATION_COLLECTION,
                       "fk_document_checklist": ref(template, "id"), **values},
            "appends": []}})
    link(api, upstream, loop)
    link(api, loop, template, branch_index=0)
    link(api, template, item)
    link(api, item, exists)
    link(api, exists, update, branch_index=1)
    link(api, exists, create, branch_index=0)
    link(api, loop, successor)


def enabled_workflow(api: RootNocoBaseApi, title: str) -> dict[str, Any]:
    query = urllib.parse.urlencode({"filter[title]": title, "pageSize": 100})
    rows = api.request("GET", f"/api/workflows:list?{query}") or []
    enabled = [r for r in rows if r.get("title") == title and r.get("enabled")]
    if len(enabled) != 1:
        raise ApiError(f"Expected one enabled {title!r}, found {len(enabled)}")
    return api.get_workflow(int(enabled[0]["id"]))


def validate_revision(original: Mapping[str, Any], revision: Mapping[str, Any],
                      *, updating: bool) -> None:
    if revision.get("key") != original.get("key"):
        raise ApiError("CHI revision key differs from its enabled predecessor")
    if revision.get("enabled") or revision.get("executed"):
        raise ApiError("CHI revision must be disabled and editable")
    expected = len(original.get("nodes") or []) + 8 + (6 if updating else 0)
    if len(revision.get("nodes") or []) < expected:
        raise ApiError(
            f"CHI revision has {len(revision.get('nodes') or [])} nodes; "
            f"expected at least {expected}"
        )
    node_by_title(revision, "Build guarded CHI category patches")
    if any(node.get("title") == "Apply independent CHI address patch"
           for node in revision.get("nodes") or []):
        raise ApiError("Unsafe inline CHI address node must not be enabled")
    node_by_title(revision, "Apply changed CHI contacts")
    if updating:
        node_by_title(revision, "Apply changed CHI Checklist files")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--resume-create-id", type=int)
    parser.add_argument("--resume-update-id", type=int)
    args = parser.parse_args()
    if bool(args.resume_create_id) != bool(args.resume_update_id):
        parser.error("both --resume-create-id and --resume-update-id are required")
    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2
    api = RootNocoBaseApi(args.base_url, token)
    originals = [enabled_workflow(api, CREATE_TITLE),
                 enabled_workflow(api, UPDATE_TITLE)]
    for workflow in originals:
        print("source_workflow_id=", workflow["id"], "title=", workflow["title"],
              "node_count=", len(workflow.get("nodes") or []))
    print("operator_relation=", OPERATOR_RELATION)
    print("new_workflow_versions=yes; native_submit_unchanged=yes")
    if not args.apply:
        print("mode=dry-run")
        return 0
    ensure_operator_relation(api)
    revisions = []
    try:
        for original, updating in zip(originals, (False, True)):
            resume_id = (args.resume_update_id if updating else
                         args.resume_create_id)
            revision = (api.get_workflow(resume_id) if resume_id else
                        revise(api, original))
            revisions.append(revision)
            if not resume_id:
                add_category_nodes(api, revision, updating=updating)
            checked = api.get_workflow(int(revision["id"]))
            validate_revision(original, checked, updating=updating)
            if resume_id:
                api.request("POST", f"/api/workflows:update?filterByTk={original['id']}",
                            {"enabled": False})
            api.request("POST", f"/api/workflows:update?filterByTk={revision['id']}",
                        {"enabled": True})
            print("enabled_revision_id=", revision["id"],
                  "node_count=", len(checked.get("nodes") or []))
        print("mode=applied")
        return 0
    except Exception:
        for revision in revisions:
            try:
                api.request("POST", f"/api/workflows:update?filterByTk={revision['id']}",
                            {"enabled": False})
            except Exception:
                pass
        for original in originals:
            try:
                api.request("POST", f"/api/workflows:update?filterByTk={original['id']}",
                            {"enabled": True})
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
