#!/usr/bin/env python3
"""Upgrade 13001 NLA staging workflows to the Phase-A status contract."""

from __future__ import annotations

import argparse
import copy
import os
import sys
import urllib.parse
from typing import Any

from extend_nocobase_staging_relations import ApiError, NocoBaseApi, node_by_title

DEFAULT_CREATE_WORKFLOW_ID = 385905217175552
DEFAULT_UPDATE_WORKFLOW_ID = 384765704011776
STAGING_COLLECTION = "t_api_request_staging"


def revision(api: NocoBaseApi, workflow_id: int) -> dict[str, Any]:
    workflow = api.get_workflow(workflow_id)
    if workflow.get("enabled"):
        api.request(
            "POST",
            f"/api/workflows:update?filterByTk={workflow_id}",
            {"enabled": False},
        )
        workflow = api.get_workflow(workflow_id)
    query = urllib.parse.urlencode(
        {"filterByTk": workflow_id, "filter[key]": workflow["key"]}
    )
    created = api.request("POST", f"/api/workflows:revision?{query}", {})
    if not isinstance(created, dict) or created.get("id") is None:
        raise ApiError("Workflow revision API did not return an ID")
    result = api.get_workflow(int(created["id"]))
    if result.get("enabled") or result.get("executed"):
        raise ApiError("New revision is not editable")
    return result


def add_status_filter(config: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(config)
    filters = result["params"]["filter"].setdefault("$and", [])
    if not any("f_status" in item for item in filters):
        filters.append({"f_status": {"$eq": "submitted"}})
    else:
        for item in filters:
            if "f_status" in item:
                item["f_status"] = {"$eq": "submitted"}
    return result


def patch_create(api: NocoBaseApi, workflow: dict[str, Any]) -> None:
    legacy_nodes = [
        node
        for node in workflow.get("nodes") or []
        if node.get("title") == "Disabled legacy custom Checklist row creation"
    ]
    for legacy in legacy_nodes:
        api.request(
            "POST",
            "/api/flow_nodes:destroy?"
            + urllib.parse.urlencode({"filterByTk": str(legacy["id"])}),
            {},
        )
    workflow_config = copy.deepcopy(workflow.get("config") or {})
    workflow_config["condition"] = {
        "$and": [
            {"f_status": {"$eq": "submitted"}},
            {"f_source_system": {"$ne": "CMTF"}},
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_api_type": {"$eq": "create_intake_for_new_licence"}},
        ]
    }
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow['id']}",
        {"config": workflow_config},
    )
    dispatch = node_by_title(workflow, "Dispatch by source/event/API")
    dispatch_config = copy.deepcopy(dispatch.get("config") or {})
    for condition in dispatch_config.get("conditions") or []:
        calculations = (
            ((condition.get("calculation") or {}).get("group") or {}).get(
                "calculations"
            )
            or []
        )
        for calculation in calculations:
            operands = calculation.get("operands") or []
            if operands and operands[0] == "{{$context.data.f_status}}":
                calculation["operands"] = [operands[0], "submitted"]
    api.update_node(int(dispatch["id"]), {"config": dispatch_config})
    processing = node_by_title(workflow, "Mark processing")
    api.update_node(
        int(processing["id"]),
        {"config": add_status_filter(processing["config"])},
    )


def patch_update(api: NocoBaseApi, workflow: dict[str, Any]) -> None:
    workflow_config = copy.deepcopy(workflow.get("config") or {})
    workflow_config["condition"] = {
        "$and": [
            {"f_status": {"$eq": "submitted"}},
            {"f_source_system": {"$ne": "CMTF"}},
            {"f_request_event": {"$eq": "UPDATE"}},
            {"f_api_type": {"$eq": "update_new_licence_data"}},
        ]
    }
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow['id']}",
        {"config": workflow_config},
    )
    processing = node_by_title(workflow, "Mark update processing")
    api.update_node(
        int(processing["id"]),
        {"config": add_status_filter(processing["config"])},
    )
    original = node_by_title(workflow, "Resolve original CREATE staging record")
    original_config = copy.deepcopy(original.get("config") or {})
    filters = original_config["params"]["filter"]["$and"]
    filters[:] = [item for item in filters if "f_application_status" not in item]
    filters.append({"f_application_status": {"$eq": "Accepted"}})
    api.update_node(int(original["id"]), {"config": original_config})


def update_application_status_field(api: NocoBaseApi) -> None:
    field = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        + urllib.parse.urlencode({"filterByTk": "f_application_status"}),
    )
    if not isinstance(field, dict):
        raise ApiError("Application status field was not found")
    ui_schema = copy.deepcopy(field.get("uiSchema") or {})
    options = list(ui_schema.get("enum") or [])
    options = [item for item in options if item.get("value") != "Submitted"]
    if not any(item.get("value") == "Accepted" for item in options):
        options.insert(0, {"value": "Accepted", "label": "Accepted"})
    ui_schema["enum"] = options
    api.request(
        "POST",
        "/api/collections/t_api_request_staging/fields:update?"
        + urllib.parse.urlencode({"filterByTk": field["name"]}),
        {"uiSchema": ui_schema},
    )
    updated = api.request(
        "GET",
        "/api/collections/t_api_request_staging/fields:get?"
        + urllib.parse.urlencode({"filterByTk": field["name"]}),
    )
    updated_options = ((updated or {}).get("uiSchema") or {}).get("enum") or []
    if not any(item.get("value") == "Accepted" for item in updated_options):
        raise ApiError("Accepted application status did not persist")


def set_enabled(api: NocoBaseApi, workflow_id: int, enabled: bool) -> None:
    api.request(
        "POST",
        f"/api/workflows:update?filterByTk={workflow_id}",
        {"enabled": enabled},
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument(
        "--create-workflow-id", type=int, default=DEFAULT_CREATE_WORKFLOW_ID
    )
    parser.add_argument(
        "--update-workflow-id", type=int, default=DEFAULT_UPDATE_WORKFLOW_ID
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    print("phase=A")
    print("internal_status=submitted->processing->succeeded|failed")
    print("application_status=Accepted->Received")
    print(f"create_source_workflow_id={args.create_workflow_id}")
    print(f"update_source_workflow_id={args.update_workflow_id}")
    if not args.apply:
        print("mode=dry-run")
        return 0

    api = NocoBaseApi(args.base_url, token)
    old_ids = [args.create_workflow_id, args.update_workflow_id]
    new_ids: list[int] = []
    try:
        update_application_status_field(api)
        create_revision = revision(api, args.create_workflow_id)
        new_ids.append(int(create_revision["id"]))
        patch_create(api, create_revision)

        update_revision = revision(api, args.update_workflow_id)
        new_ids.append(int(update_revision["id"]))
        patch_update(api, update_revision)

        set_enabled(api, int(create_revision["id"]), True)
        set_enabled(api, int(update_revision["id"]), True)

        create_final = api.get_workflow(int(create_revision["id"]))
        update_final = api.get_workflow(int(update_revision["id"]))
        print(f"create_revision_id={create_final['id']}")
        print(f"create_revision_enabled={str(bool(create_final.get('enabled'))).lower()}")
        print(f"update_revision_id={update_final['id']}")
        print(f"update_revision_enabled={str(bool(update_final.get('enabled'))).lower()}")
        print("mode=applied")
        return 0
    except Exception:
        for workflow_id in new_ids:
            try:
                set_enabled(api, workflow_id, False)
            except Exception:
                pass
        for workflow_id in old_ids:
            try:
                set_enabled(api, workflow_id, True)
            except Exception:
                pass
        raise


if __name__ == "__main__":
    raise SystemExit(main())
