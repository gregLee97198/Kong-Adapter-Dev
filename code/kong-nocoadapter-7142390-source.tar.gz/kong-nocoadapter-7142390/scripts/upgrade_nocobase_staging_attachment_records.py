#!/usr/bin/env python3
"""Add attachment-backed Intake Activity and Checklist Details records.

The public API supplies only NocoBase attachment IDs.  This upgrade makes the
staging workflow load each attachment, create the native Checklist Details
history row first, and then update the parent Checklist summary.  It also logs
the main application attachment IDs on an Intake Activity record.  The workflow
runs the native Intake Submit action exactly once as the business submitter,
then backfills the staging result and ends.  It never auto-closes or impersonates
an approval assignee.
"""

from __future__ import annotations

import argparse
import copy
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from extend_nocobase_staging_relations import (
    ApiError,
    NocoBaseApi,
    node_by_title,
    normalize_script,
)

DEFAULT_WORKFLOW_ID = 384761304186880

ATTACHMENT_LOOKUP_TITLE = "Load Checklist attachment record"
ATTACHMENT_EXISTS_TITLE = "Checklist attachment exists?"
DETAIL_CREATE_TITLE = "Create Checklist upload Details record"
ACTIVITY_CREATE_TITLE = "Create Intake API receipt Activity + attachments"
NATIVE_SUBMIT_TITLE = "Run native Intake Form Submit as business submitter"
UNSAFE_CLOSE_TITLES = {
    "Reload Intake for native Close",
    "Run native Intake Close as approval assignee",
    "Close Intake after API submit without recursive hooks",
}


def reference(node_key: str, suffix: str | None = None) -> str:
    path = node_key if suffix is None else f"{node_key}.{suffix}"
    return "{{$jobsMapByNodeKey." + path + "}}"


def variable_ref(parse: Mapping[str, Any], path: str) -> str:
    keys = [
        variable.get("key")
        for variable in (parse.get("config") or {}).get("variables") or []
        if variable.get("path") == path
    ]
    if len(keys) != 1:
        raise ApiError(f"Expected exactly one Checklist variable for {path!r}")
    return reference(str(parse["key"]), str(keys[0]))


def upsert_node(
    api: NocoBaseApi,
    workflow: Mapping[str, Any],
    *,
    workflow_id: int,
    title: str,
    node_type: str,
    config: Mapping[str, Any],
) -> dict[str, Any]:
    matches = [
        node for node in workflow.get("nodes") or [] if node.get("title") == title
    ]
    if len(matches) > 1:
        raise ApiError(f"More than one workflow node is titled {title!r}")
    values = {"type": node_type, "title": title, "config": dict(config)}
    if matches:
        node = matches[0]
        api.update_node(int(node["id"]), values)
        return dict(node)
    return dict(
        api.create_node(
            {"workflowId": workflow_id, **values}
        )
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument(
        "--revision",
        action="store_true",
        help="Create an editable workflow revision before applying the upgrade",
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    if workflow.get("enabled"):
        raise ApiError("Source workflow must be Off before revision or editing")

    if args.revision:
        print(f"source_workflow_id={args.workflow_id}")
        if not args.apply:
            print("create_revision=yes")
            print("mode=dry-run")
            return 0
        query = urllib.parse.urlencode(
            {
                "filterByTk": str(args.workflow_id),
                "filter[key]": str(workflow["key"]),
            }
        )
        revision = api.request("POST", f"/api/workflows:revision?{query}", {})
        if not isinstance(revision, dict) or revision.get("id") is None:
            raise ApiError("Workflow revision API did not return a workflow")
        workflow = api.get_workflow(int(revision["id"]))

    workflow_id = int(workflow["id"])
    if workflow.get("enabled") or workflow.get("executed"):
        raise ApiError("Target workflow must be editable, unexecuted, and Off")

    source_titles = {
        node.get("title") for node in workflow.get("nodes") or []
    }
    unsafe_titles = sorted(UNSAFE_CLOSE_TITLES & source_titles)
    if unsafe_titles:
        raise ApiError(
            "Refusing to modify a workflow that contains unsafe auto-close "
            f"nodes: {unsafe_titles}"
        )

    normalize = node_by_title(workflow, "Normalize complete NLA relation data")
    checklist_loop = node_by_title(
        workflow, "Apply Checklist files to native records"
    )
    parse_item = node_by_title(workflow, "Parse current Checklist item")
    find_native = node_by_title(workflow, "Find native Checklist item")
    native_exists = node_by_title(workflow, "Native Checklist item exists?")
    update_native = node_by_title(workflow, "Update native Checklist item + files")
    create_intake = node_by_title(workflow, "Create Intake (fixed NLA type)")
    submitter = node_by_title(workflow, "Resolve business submitter and post")
    load_intake = node_by_title(workflow, "Load Intake for native Submit")
    native_submit = node_by_title(workflow, NATIVE_SUBMIT_TITLE)
    succeeded = node_by_title(workflow, "Mark succeeded + backfill IDs")

    print(f"workflow_id={workflow_id}")
    print("public_checklist_attachment_shape=attachment_id")
    print("checklist_details_before_parent_update=yes")
    print("intake_activity_main_attachments=yes")
    print("native_submit_count=1")
    print("auto_close=no")
    print("workflow_enabled=no")
    if not args.apply:
        print("mode=dry-run")
        return 0

    normalize_config = copy.deepcopy(normalize.get("config") or {})
    normalize_config["content"] = normalize_script()
    api.update_node(int(normalize["id"]), {"config": normalize_config})

    parse_config = copy.deepcopy(parse_item.get("config") or {})
    parse_config["variables"] = [
        {
            "key": "position001",
            "path": "position_code",
            "name": "position_code",
            "paths": ["position_code"],
        },
        {
            "key": "template001",
            "path": "template_id",
            "name": "template_id",
            "paths": ["template_id"],
        },
        {
            "key": "checked0001",
            "path": "checked",
            "name": "checked",
            "paths": ["checked"],
        },
        {
            "key": "status00001",
            "path": "status",
            "name": "status",
            "paths": ["status"],
        },
        {
            "key": "remarks0001",
            "path": "remarks",
            "name": "remarks",
            "paths": ["remarks"],
        },
        {
            "key": "attachid001",
            "path": "attachment_id",
            "name": "attachment_id",
            "paths": ["attachment_id"],
        },
        {
            "key": "attachids01",
            "path": "attachment_ids",
            "name": "attachment_ids",
            "paths": ["attachment_ids"],
        },
    ]
    parse_config["example"] = {
        "position_code": "LORCHE_STAGE2:ROW:35",
        "template_id": 369569483653120,
        "checked": True,
        "status": "1",
        "remarks": "OP supplied",
        "attachment_id": 502,
        "attachment_ids": [502],
    }
    parse_for_refs = {**parse_item, "config": parse_config}
    api.update_node(int(parse_item["id"]), {"config": parse_config})

    attachment_lookup_config = {
        "collection": "attachments",
        "multiple": False,
        "params": {
            "filter": {
                "$and": [
                    {
                        "id": {
                            "$eq": variable_ref(parse_for_refs, "attachment_id")
                        }
                    }
                ]
            },
            "sort": [],
            "page": 1,
            "pageSize": 1,
            "appends": [],
        },
    }
    attachment_lookup = upsert_node(
        api,
        workflow,
        workflow_id=workflow_id,
        title=ATTACHMENT_LOOKUP_TITLE,
        node_type="query",
        config=attachment_lookup_config,
    )
    attachment_exists = upsert_node(
        api,
        workflow,
        workflow_id=workflow_id,
        title=ATTACHMENT_EXISTS_TITLE,
        node_type="condition",
        config={
            "rejectOnFalse": True,
            "engine": "basic",
            "calculation": {
                "group": {
                    "type": "and",
                    "calculations": [
                        {
                            "calculator": "gt",
                            "operands": [
                                reference(attachment_lookup["key"], "id"),
                                0,
                            ],
                        }
                    ],
                }
            },
        },
    )
    detail_create = upsert_node(
        api,
        workflow,
        workflow_id=workflow_id,
        title=DETAIL_CREATE_TITLE,
        node_type="create",
        config={
            "collection": "t_document_submitted_for_application_details",
            "params": {
                "values": {
                    "fk_documests_submitted_for_application_id": reference(
                        find_native["key"], "id"
                    ),
                    "f_files": variable_ref(parse_for_refs, "attachment_ids"),
                    "f_file_name": reference(attachment_lookup["key"], "filename"),
                    "f_file_date": reference(attachment_lookup["key"], "createdAt"),
                    "f_remarks": variable_ref(parse_for_refs, "remarks"),
                    "createdBy": reference(submitter["key"], "id"),
                },
                "appends": [],
            },
        },
    )

    update_config = copy.deepcopy(update_native.get("config") or {})
    update_params = update_config.setdefault("params", {})
    update_params["individualHooks"] = True
    update_params["filter"] = {
        "$and": [{"id": {"$eq": reference(find_native["key"], "id")}}]
    }
    update_params["values"] = {
        "f_is_checked": variable_ref(parse_for_refs, "checked"),
        "f_status": variable_ref(parse_for_refs, "status"),
        "f_remarks": variable_ref(parse_for_refs, "remarks"),
        "f_lastest_files": variable_ref(parse_for_refs, "attachment_ids"),
        "f_lastest_files_name": reference(
            attachment_lookup["key"], "filename"
        ),
        "f_lastest_file_date": reference(
            attachment_lookup["key"], "createdAt"
        ),
    }

    activity_create = upsert_node(
        api,
        workflow,
        workflow_id=workflow_id,
        title=ACTIVITY_CREATE_TITLE,
        node_type="create",
        config={
            "collection": "t_intake_activity",
            "params": {
                "values": {
                    "fk_activity": reference(create_intake["key"], "id"),
                    "f_date": reference(normalize["key"], "activity_date"),
                    "f_activity": "Online Platform",
                    "f_activity_status": "completed",
                    "f_remarks": (
                        "<p>New Licence Application received through the OP "
                        "gateway.</p>"
                    ),
                    "f_attachments": reference(
                        normalize["key"], "main_attachment_ids"
                    ),
                    "createdBy": reference(submitter["key"], "id"),
                    "fk_received_by": reference(create_intake["key"], "fk_task_owner"),
                    "fk_staff_post": reference(
                        create_intake["key"], "fk_task_owner_post"
                    ),
                    "f_temp_office_code": reference(
                        create_intake["key"], "f_office_cd"
                    ),
                },
                "appends": [],
            },
        },
    )

    api.update_node(
        int(native_exists["id"]),
        {"downstreamId": None},
    )
    api.update_node(
        int(attachment_lookup["id"]),
        {
            "upstreamId": native_exists["id"],
            "downstreamId": attachment_exists["id"],
            "branchIndex": 1,
        },
    )
    api.update_node(
        int(attachment_exists["id"]),
        {
            "upstreamId": attachment_lookup["id"],
            "downstreamId": None,
            "branchIndex": None,
        },
    )
    api.update_node(
        int(detail_create["id"]),
        {
            "upstreamId": attachment_exists["id"],
            "downstreamId": update_native["id"],
            "branchIndex": 1,
        },
    )
    api.update_node(
        int(update_native["id"]),
        {
            "config": update_config,
            "upstreamId": detail_create["id"],
            "downstreamId": None,
            "branchIndex": None,
        },
    )
    api.update_node(
        int(checklist_loop["id"]), {"downstreamId": activity_create["id"]}
    )
    api.update_node(
        int(activity_create["id"]),
        {
            "upstreamId": checklist_loop["id"],
            "downstreamId": load_intake["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(load_intake["id"]),
        {"upstreamId": activity_create["id"], "branchIndex": None},
    )
    api.update_node(
        int(native_submit["id"]),
        {"downstreamId": succeeded["id"]},
    )
    api.update_node(
        int(succeeded["id"]),
        {"upstreamId": native_submit["id"], "branchIndex": None},
    )

    verified = api.get_workflow(workflow_id)
    verified_parse = node_by_title(verified, "Parse current Checklist item")
    verified_lookup = node_by_title(verified, ATTACHMENT_LOOKUP_TITLE)
    verified_exists = node_by_title(verified, ATTACHMENT_EXISTS_TITLE)
    verified_detail = node_by_title(verified, DETAIL_CREATE_TITLE)
    verified_update = node_by_title(
        verified, "Update native Checklist item + files"
    )
    verified_loop = node_by_title(
        verified, "Apply Checklist files to native records"
    )
    verified_activity = node_by_title(verified, ACTIVITY_CREATE_TITLE)
    verified_load = node_by_title(verified, "Load Intake for native Submit")
    verified_native_submit = node_by_title(verified, NATIVE_SUBMIT_TITLE)
    verified_succeeded = node_by_title(verified, "Mark succeeded + backfill IDs")
    installed_titles = {node.get("title") for node in verified.get("nodes") or []}
    parse_paths = {
        variable.get("path")
        for variable in (verified_parse.get("config") or {}).get("variables") or []
    }
    checks = {
        "workflow_off": not verified.get("enabled"),
        "public_metadata_removed": not (
            {"file_ids", "latest_file_name", "latest_file_date"} & parse_paths
        ),
        "attachment_id_parsed": "attachment_id" in parse_paths,
        "lookup_after_native_check": verified_lookup.get("upstreamId")
        == node_by_title(verified, "Native Checklist item exists?").get("id"),
        "details_after_attachment_check": verified_detail.get("upstreamId")
        == verified_exists.get("id"),
        "parent_update_after_details": verified_update.get("upstreamId")
        == verified_detail.get("id"),
        "activity_after_checklist": verified_loop.get("downstreamId")
        == verified_activity.get("id"),
        "submit_after_activity": verified_activity.get("downstreamId")
        == verified_load.get("id"),
        "success_after_single_submit": verified_native_submit.get("downstreamId")
        == verified_succeeded.get("id"),
        "no_unsafe_auto_close_nodes": not (UNSAFE_CLOSE_TITLES & installed_titles),
        "details_collection": (verified_detail.get("config") or {}).get(
            "collection"
        )
        == "t_document_submitted_for_application_details",
        "activity_collection": (verified_activity.get("config") or {}).get(
            "collection"
        )
        == "t_intake_activity",
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ApiError(f"Attachment-record upgrade verification failed: {failed}")

    print(f"attachment_lookup_node_id={verified_lookup['id']}")
    print(f"details_create_node_id={verified_detail['id']}")
    print(f"intake_activity_node_id={verified_activity['id']}")
    print("upgrade_verified=yes")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
