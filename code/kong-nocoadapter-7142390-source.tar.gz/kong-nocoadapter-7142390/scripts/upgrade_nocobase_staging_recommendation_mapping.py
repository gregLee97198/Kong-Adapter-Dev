#!/usr/bin/env python3
"""Map public recommendation values to NocoBase native enum values.

The public API does not accept a Recommendation field.  The native Intake
Submit workflow tests ``f_intake_accept_reject`` against ``0`` or ``1``.  This
upgrade writes the native ``accept`` value ``0`` immediately after the staged
body is parsed, before Intake is created.  It never changes a status directly.
"""

from __future__ import annotations

import argparse
import copy
import os
import sys
import urllib.parse
from collections.abc import Mapping
from typing import Any

from extend_nocobase_staging_relations import (
    ApiError,
    NocoBaseApi,
    node_by_title,
)

DEFAULT_WORKFLOW_ID = 384761304186880
PARSE_TITLE = "Parse staged request body"
EARLY_MAPPING_TITLE = "Map Recommendation before Intake creation"
RESOLVE_SUBMITTER_TITLE = "Resolve business submitter and post"
CREATE_INTAKE_TITLE = "Create Intake (fixed NLA type)"
PUBLIC_RECOMMENDATION_PATH = "form_data.part_5.recommendation"
SUBMIT_TITLE = "Run native Intake Form Submit as business submitter"
SUCCESS_TITLE = "Mark succeeded + backfill IDs"
UNSAFE_CLOSE_TITLES = {
    "Reload Intake for native Close",
    "Run native Intake Close as approval assignee",
    "Close Intake after API submit without recursive hooks",
}


def job_reference(node_key: str, field: str) -> str:
    return "{{$jobsMapByNodeKey." + node_key + "." + field + "}}"


def mapping_script_config() -> dict[str, Any]:
    return {
        "arguments": [],
        "content": "return {recommendation_value: '0'};",
        "timeout": 0,
        "continue": False,
    }


def remove_public_recommendation(parse_node: Mapping[str, Any]) -> dict[str, Any]:
    config = copy.deepcopy(parse_node.get("config") or {})
    config["variables"] = [
        variable
        for variable in config.get("variables") or []
        if variable.get("path") != PUBLIC_RECOMMENDATION_PATH
    ]
    example = config.get("example")
    if isinstance(example, dict):
        form_data = example.get("form_data")
        part_5 = form_data.get("part_5") if isinstance(form_data, dict) else None
        if isinstance(part_5, dict):
            part_5.pop("recommendation", None)
    return config


def require_safe_topology(workflow: Mapping[str, Any]) -> None:
    if workflow.get("enabled"):
        raise ApiError("Workflow must be Off before revision or modification")
    titles = {node.get("title") for node in workflow.get("nodes") or []}
    unsafe = sorted(UNSAFE_CLOSE_TITLES & titles)
    if unsafe:
        raise ApiError(f"Unsafe auto-close nodes are present: {unsafe}")
    submit = node_by_title(workflow, SUBMIT_TITLE)
    success = node_by_title(workflow, SUCCESS_TITLE)
    if submit.get("downstreamId") != success.get("id"):
        raise ApiError("Native Submit must directly precede staging success")
    if success.get("upstreamId") != submit.get("id"):
        raise ApiError("Staging success must directly follow native Submit")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--workflow-id", type=int, default=DEFAULT_WORKFLOW_ID)
    parser.add_argument(
        "--revision",
        action="store_true",
        help="Create an editable revision before installing the mapping",
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    token = os.environ.get("NOCOBASE_TOKEN")
    if not token:
        print("error=NOCOBASE_TOKEN is required", file=sys.stderr)
        return 2

    api = NocoBaseApi(args.base_url, token)
    workflow = api.get_workflow(args.workflow_id)
    require_safe_topology(workflow)
    print(f"source_workflow_id={workflow['id']}")
    print("public_recommendation_field=forbidden")
    print("native_recommendation_default=0")
    print("direct_status_write=no")

    if args.revision:
        if not args.apply:
            print("create_revision=yes")
            print("mode=dry-run")
            return 0
        query = urllib.parse.urlencode(
            {
                "filterByTk": str(workflow["id"]),
                "filter[key]": str(workflow["key"]),
            }
        )
        revision = api.request("POST", f"/api/workflows:revision?{query}", {})
        if not isinstance(revision, dict) or revision.get("id") is None:
            raise ApiError("Workflow revision API did not return a workflow")
        workflow = api.get_workflow(int(revision["id"]))
        require_safe_topology(workflow)

    parse = node_by_title(workflow, PARSE_TITLE)
    resolve_submitter = node_by_title(workflow, RESOLVE_SUBMITTER_TITLE)
    create_intake = node_by_title(workflow, CREATE_INTAKE_TITLE)
    existing_mapping = [
        node
        for node in workflow.get("nodes") or []
        if node.get("title") == EARLY_MAPPING_TITLE
    ]
    if len(existing_mapping) > 1:
        raise ApiError(f"More than one node is titled {EARLY_MAPPING_TITLE!r}")
    print(f"workflow_id={workflow['id']}")
    print("workflow_enabled=no")
    if not args.apply:
        print("mode=dry-run")
        return 0

    if existing_mapping:
        mapping = existing_mapping[0]
        api.update_node(
            int(mapping["id"]),
            {"config": mapping_script_config()},
        )
    else:
        mapping = api.create_node(
            {
                "workflowId": int(workflow["id"]),
                "type": "script",
                "title": EARLY_MAPPING_TITLE,
                "config": mapping_script_config(),
            }
        )

    expected_reference = job_reference(
        str(mapping["key"]), "recommendation_value"
    )

    intake_config = copy.deepcopy(create_intake.get("config") or {})
    intake_values = intake_config.setdefault("params", {}).setdefault("values", {})
    intake_values["f_intake_accept_reject"] = expected_reference
    api.update_node(int(create_intake["id"]), {"config": intake_config})

    api.update_node(
        int(parse["id"]),
        {
            "config": remove_public_recommendation(parse),
            "downstreamId": mapping["id"],
        },
    )
    api.update_node(
        int(mapping["id"]),
        {
            "upstreamId": parse["id"],
            "downstreamId": resolve_submitter["id"],
            "branchIndex": None,
        },
    )
    api.update_node(
        int(resolve_submitter["id"]), {"upstreamId": mapping["id"]}
    )

    verified = api.get_workflow(int(workflow["id"]))
    require_safe_topology(verified)
    verified_parse = node_by_title(verified, PARSE_TITLE)
    verified_mapping = node_by_title(verified, EARLY_MAPPING_TITLE)
    verified_resolve = node_by_title(verified, RESOLVE_SUBMITTER_TITLE)
    verified_create = node_by_title(verified, CREATE_INTAKE_TITLE)
    content = str((verified_mapping.get("config") or {}).get("content") or "")
    values = (
        ((verified_create.get("config") or {}).get("params") or {})
        .get("values", {})
    )
    checks = {
        "default_accept_to_zero": "recommendation_value: '0'" in content,
        "intake_uses_early_mapped_value": values.get("f_intake_accept_reject")
        == expected_reference,
        "mapping_precedes_intake": (
            verified_parse.get("downstreamId") == verified_mapping.get("id")
            and verified_mapping.get("upstreamId") == verified_parse.get("id")
            and verified_mapping.get("downstreamId") == verified_resolve.get("id")
            and verified_resolve.get("upstreamId") == verified_mapping.get("id")
        ),
        "public_recommendation_not_parsed": PUBLIC_RECOMMENDATION_PATH
        not in {
            variable.get("path")
            for variable in (verified_parse.get("config") or {}).get("variables")
            or []
        },
        "workflow_off": not verified.get("enabled"),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ApiError(f"Recommendation mapping verification failed: {failed}")

    print("recommendation_mapping_verified=yes")
    print("workflow_enabled=no")
    print("mode=applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
