"""Shared Create/Update trigger: any external source, never CMTF."""

from __future__ import annotations

import urllib.parse
from collections.abc import Mapping
from typing import Any

from extend_nocobase_staging_relations import ApiError, NocoBaseApi

INTERNAL_SOURCE_SYSTEM = "CMTF"


def external_source_condition(request_event: str, api_type: str) -> dict[str, Any]:
    """Trigger on submitted Staging that did not originate inside CMTF."""
    return {
        "$and": [
            {"f_status": {"$eq": "submitted"}},
            {"f_source_system": {"$ne": INTERNAL_SOURCE_SYSTEM}},
            {"f_request_event": {"$eq": request_event}},
            {"f_api_type": {"$eq": api_type}},
        ]
    }


def replace_op_eq_with_external(condition: Mapping[str, Any] | None) -> dict[str, Any] | None:
    """Rewrite f_source_system $eq OP (or any literal) to $ne CMTF."""
    if not isinstance(condition, dict):
        return None
    rewritten = _rewrite(condition)
    return rewritten if isinstance(rewritten, dict) else None


def _rewrite(value: Any) -> Any:
    if isinstance(value, list):
        return [_rewrite(item) for item in value]
    if not isinstance(value, dict):
        return value
    source_filter = value.get("f_source_system")
    if (
        isinstance(source_filter, dict)
        and "$eq" in source_filter
        and str(source_filter.get("$eq") or "").upper() != INTERNAL_SOURCE_SYSTEM
        and set(source_filter) == {"$eq"}
    ):
        cloned = dict(value)
        cloned["f_source_system"] = {"$ne": INTERNAL_SOURCE_SYSTEM}
        return {key: _rewrite(item) for key, item in cloned.items()}
    return {key: _rewrite(item) for key, item in value.items()}


def revision_workflow(api: NocoBaseApi, workflow_id: int) -> dict[str, Any]:
    """Create an editable revision of an executed workflow (same key)."""
    workflow = api.get_workflow(workflow_id)
    if workflow.get("enabled"):
        api.request(
            "POST",
            f"/api/workflows:update?filterByTk={workflow_id}",
            {"enabled": False},
        )
        workflow = api.get_workflow(workflow_id)
    key = workflow.get("key")
    if not key:
        raise ApiError(f"Workflow {workflow_id} has no key for revision")
    query = urllib.parse.urlencode({"filterByTk": workflow_id, "filter[key]": key})
    created = api.request("POST", f"/api/workflows:revision?{query}", {})
    if not isinstance(created, dict) or created.get("id") is None:
        raise ApiError("Workflow revision API did not return an ID")
    result = api.get_workflow(int(created["id"]))
    if result.get("enabled") or result.get("executed"):
        raise ApiError("New revision is not editable")
    return result


def destroy_workflow_nodes(api: NocoBaseApi, workflow: Mapping[str, Any]) -> None:
    workflow_id = int(workflow["id"])
    while True:
        fresh = api.get_workflow(workflow_id)
        remaining = {
            int(node["id"]): dict(node)
            for node in (fresh.get("nodes") or [])
            if node.get("id") is not None
        }
        if not remaining:
            return
        referenced = {
            int(node["downstreamId"])
            for node in remaining.values()
            if node.get("downstreamId") not in (None, "")
        }
        leaves = [
            node
            for node_id, node in remaining.items()
            if node_id not in referenced
        ] or list(remaining.values())
        node_id = int(leaves[0]["id"])
        try:
            api.request(
                "POST",
                "/api/flow_nodes:destroy?"
                + urllib.parse.urlencode({"filterByTk": str(node_id)}),
                {},
            )
        except ApiError as exc:
            if "404" not in str(exc) and "not found" not in str(exc).lower():
                raise
            still = api.get_workflow(workflow_id)
            still_ids = {
                int(node["id"])
                for node in (still.get("nodes") or [])
                if node.get("id") is not None
            }
            if node_id in still_ids:
                raise
