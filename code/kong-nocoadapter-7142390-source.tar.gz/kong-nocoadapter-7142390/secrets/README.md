# Runtime secrets

在服务器上创建以下纯文本文件，只保存一行实际值：

- `nocobase_config_token`：具有读取 File Manager 存储配置权限的全局/Root Token。
- `nocobase_config_token.local_test`：仅供本机连接隔离测试环境 `13001` 使用的 Root Token。

全局 Token 只调用存储配置、字段枚举等系统元数据接口。预签名、Local 上传、
附件记录和暂存业务写入均使用客户请求中的 NocoBase 原生 Token。NLA 的后续处理
由 NocoBase 集合事件异步工作流执行，不需要 Webhook Basic 凭据。

建议权限：

```bash
chown root:10001 nocobase_config_token
chmod 640 nocobase_config_token
```

这些文件已被 `.gitignore` 排除，不要提交、截图或放入接口文档。
