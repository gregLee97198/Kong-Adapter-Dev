"""Offline, fail-closed contract for the 13001 NLA Closed mapping repair."""

from __future__ import annotations

import copy
import sys
import urllib.parse
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import align_nocobase_nla_closed_mapping as target  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402


class FakeApi:
    def __init__(self, *, closed_exists: bool = True) -> None:
        self.maps = [
            {"id": 40, "f_code": target.NLA_MAP_CODE},
            {"id": 41, "f_code": "t_other_app"},
        ]
        self.statuses = [
            {"id": 8, "f_status": "Rejected", "f_update_allowed": False},
            {"id": 4, "f_status": "Acknowledged", "f_update_allowed": False},
        ]
        if closed_exists:
            self.statuses.append(
                {
                    "id": 9,
                    "f_status": "Closed",
                    "f_update_allowed": False,
                    "f_recommended_query_data": "application_data, notices",
                    "f_sort": 9,
                }
            )
        self.details = [
            {
                "id": target.CLOSED_DETAIL_ID,
                "fk_map_id": 40,
                "f_code": "2",
                "f_name": "Closed",
                "f_notice_board_persist": True,
                "fk_notice_board_status": 8,
            },
            {
                "id": target.PENDING_CLOSURE_DETAIL_ID,
                "fk_map_id": 40,
                "f_code": "16",
                "f_name": "Approve for closing the case?",
                "f_notice_board_persist": True,
                "fk_notice_board_status": 8,
            },
            {
                "id": 500,
                "fk_map_id": 41,
                "f_code": "2",
                "f_name": "Other business closing",
                "fk_notice_board_status": 8,
                "f_notice_board_persist": True,
            },
        ]
        self.writes: list[tuple[int, dict[str, Any]]] = []
        self.timeout_after_first_write = False

    def request(
        self, method: str, path: str, body: dict[str, Any] | None = None
    ) -> Any:
        route, _, raw_query = path.partition("?")
        query = urllib.parse.parse_qs(raw_query)
        if method == "GET" and route.endswith(":list"):
            if route.startswith(f"/api/{target.MAP_COLLECTION}:"):
                return copy.deepcopy(self.maps)
            if route.startswith(f"/api/{target.STATUS_COLLECTION}:"):
                return copy.deepcopy(self.statuses)
            if route.startswith(f"/api/{target.DETAIL_COLLECTION}:"):
                return copy.deepcopy(self.details)
        if method == "GET" and route == f"/api/{target.DETAIL_COLLECTION}:get":
            record_id = int(query["filterByTk"][0])
            return copy.deepcopy(
                next(row for row in self.details if row["id"] == record_id)
            )
        if method == "POST" and route == f"/api/{target.DETAIL_COLLECTION}:update":
            assert body is not None and len(body) == 1
            record_id = int(query["filterByTk"][0])
            row = next(row for row in self.details if row["id"] == record_id)
            row.update(copy.deepcopy(body))
            self.writes.append((record_id, copy.deepcopy(body)))
            if self.timeout_after_first_write:
                self.timeout_after_first_write = False
                raise ApiError("simulated timeout after committed update")
            return {}
        raise AssertionError((method, path, body))


@pytest.fixture
def api() -> FakeApi:
    return FakeApi()


def test_audit_is_get_only_and_retains_other_rejected_references(api: FakeApi) -> None:
    snapshot = target.audit(api)  # type: ignore[arg-type]
    assert target.state(snapshot) == "old"
    assert snapshot.closed_status_id == 9
    assert snapshot.other_rejected_reference_ids == (
        500,
        target.PENDING_CLOSURE_DETAIL_ID,
    )
    assert api.writes == []


def test_apply_changes_only_two_nla_fields_and_is_idempotent(api: FakeApi) -> None:
    other_before = copy.deepcopy(api.details[2])
    statuses_before = copy.deepcopy(api.statuses)
    final = target.apply(api)  # type: ignore[arg-type]
    assert target.state(final) == "new"
    assert api.writes == [
        (target.PENDING_CLOSURE_DETAIL_ID, {"f_notice_board_persist": False}),
        (target.CLOSED_DETAIL_ID, {"fk_notice_board_status": 9}),
    ]
    assert api.details[2] == other_before
    assert api.statuses == statuses_before
    target.apply(api)  # type: ignore[arg-type]
    assert len(api.writes) == 2


def test_missing_closed_dictionary_fails_before_any_write() -> None:
    api = FakeApi(closed_exists=False)
    snapshot = target.audit(api)  # type: ignore[arg-type]
    assert snapshot.closed_status_id is None
    with pytest.raises(ApiError, match="prepare Send Letter v4 first"):
        target.apply(api)  # type: ignore[arg-type]
    assert api.writes == []


def test_partial_retry_and_timeout_after_committed_write(api: FakeApi) -> None:
    api.details[1]["f_notice_board_persist"] = False
    api.timeout_after_first_write = True
    final = target.apply(api)  # type: ignore[arg-type]
    assert target.state(final) == "new"
    assert api.writes == [(target.CLOSED_DETAIL_ID, {"fk_notice_board_status": 9})]


def test_rollback_restores_only_target_fields(api: FakeApi) -> None:
    target.apply(api)  # type: ignore[arg-type]
    api.writes.clear()
    final = target.apply(api, rollback=True)  # type: ignore[arg-type]
    assert target.state(final) == "old"
    assert api.writes == [
        (target.CLOSED_DETAIL_ID, {"fk_notice_board_status": 8}),
        (target.PENDING_CLOSURE_DETAIL_ID, {"f_notice_board_persist": True}),
    ]
    assert api.statuses[-1]["f_status"] == "Closed"


@pytest.mark.parametrize(
    "mutation, error",
    [
        (lambda api: api.details[0].update(fk_map_id=41), "NLA node 2"),
        (
            lambda api: api.details[1].update(f_name="Case closure"),
            "pending-closure node identity",
        ),
        (
            lambda api: api.details[0].update(fk_notice_board_status=4),
            "neither reviewed old nor new",
        ),
        (
            lambda api: api.details[0].update(fk_notice_board_status=None),
            "neither reviewed old nor new",
        ),
        (
            lambda api: api.statuses[-1].update(f_update_allowed=True),
            "Closed dictionary row",
        ),
        (
            lambda api: api.statuses.append(copy.deepcopy(api.statuses[-1])),
            "duplicate IDs",
        ),
    ],
)
def test_identity_or_value_drift_fails_closed_before_writes(
    api: FakeApi, mutation: Any, error: str
) -> None:
    mutation(api)
    with pytest.raises(ApiError, match=error):
        target.apply(api)  # type: ignore[arg-type]
    assert api.writes == []


def test_cli_default_dry_run_and_target_guard(
    api: FakeApi, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("NOCOBASE_TOKEN", "dummy")
    monkeypatch.setattr(target, "RootNocoBaseApi", lambda *_: api)
    assert target.main([]) == 0
    assert '"writes": "none"' in capsys.readouterr().out
    assert api.writes == []
    with pytest.raises(SystemExit):
        target.main(["--base-url", "http://119.91.104.211:13000/cmtf2"])
    assert api.writes == []


def test_cli_rollback_requires_explicit_ack(
    api: FakeApi, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("NOCOBASE_TOKEN", "dummy")
    monkeypatch.setattr(target, "RootNocoBaseApi", lambda *_: api)
    with pytest.raises(SystemExit):
        target.main(["--rollback", "--apply"])
    assert api.writes == []
