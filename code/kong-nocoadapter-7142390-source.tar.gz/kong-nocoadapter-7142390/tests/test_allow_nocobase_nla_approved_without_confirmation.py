"""Offline safety contract for the isolated Send Letter v5 revision."""

from __future__ import annotations

import copy
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import allow_nocobase_nla_approved_without_confirmation as target  # noqa: E402
import complete_nocobase_nla_sent_letter_notice as v4  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402


def run_js(content: str, arguments: dict[str, Any]) -> dict[str, Any]:
    if shutil.which("node") is None:
        pytest.skip("Node.js is required to execute the NocoBase JS contract")
    names = list(arguments)
    code = (
        "const fn=new Function(..." + json.dumps(names) + ","
        + json.dumps(content) + ");"
        "process.stdout.write(JSON.stringify(fn(..."
        + json.dumps([arguments[name] for name in names]) + ")));"
    )
    result = subprocess.run(
        ["node", "-e", code], capture_output=True, text=True,
        check=True, timeout=10,
    )
    return json.loads(result.stdout)


def minimal_source() -> dict[str, Any]:
    source = {
        "id": target.SOURCE_ID,
        "key": target.SOURCE_KEY,
        "title": target.SOURCE_TITLE,
        "enabled": True,
        "type": "collection",
        "sync": False,
        "config": {"collection": "t_letter_attachment", "changed": ["f_sendtime"]},
        "nodes": [],
    }
    used = {target.PLAN_ID, target.ADVANCE_PLAN_ID}
    dummy_ids = (
        ident for ident in range(target.SOURCE_ID + 1, target.SOURCE_ID + 100)
        if ident not in used
    )
    titles = [target.PLAN, target.ADVANCE_PLAN] + [
        f"Other v4 node {index}" for index in range(24)
    ]
    for index, title in enumerate(titles):
        ident = (target.PLAN_ID if title == target.PLAN
                 else target.ADVANCE_PLAN_ID if title == target.ADVANCE_PLAN
                 else next(dummy_ids))
        content = (v4.plan_script() if title == target.PLAN
                   else v4.advance_script() if title == target.ADVANCE_PLAN
                   else None)
        source["nodes"].append({
            "id": ident,
            "key": f"test_v4_{index}",
            "title": title,
            "type": "script" if content is not None else "query",
            "workflowId": target.SOURCE_ID,
            "upstreamId": None,
            "downstreamId": None,
            "branchIndex": None,
            "config": ({"content": content, "timeout": 5000}
                       if content is not None else {"collection": "example"}),
        })
    return source


def clone(source: dict[str, Any]) -> dict[str, Any]:
    candidate = copy.deepcopy(source)
    candidate["id"] = target.SOURCE_ID + 1000
    candidate["enabled"] = False
    old_to_new = {}
    for row in candidate["nodes"]:
        old_to_new[row["id"]] = row["id"] + 1000
    for row in candidate["nodes"]:
        row["id"] = old_to_new[row["id"]]
        row["workflowId"] = candidate["id"]
        for edge in ("upstreamId", "downstreamId"):
            if row[edge] is not None:
                row[edge] = old_to_new[row[edge]]
    return candidate


def prepared_pair() -> tuple[dict[str, Any], dict[str, Any]]:
    source = minimal_source()
    candidate = clone(source)
    for title in target.CHANGES:
        target.by_title(candidate)[title]["config"]["content"] = (
            target.target_content(source, title)
        )
    return source, candidate


def letter(kind: str, ident: int) -> dict[str, Any]:
    return {
        "id": ident, "f_letter_type": kind,
        "f_business_key": 900, "f_is_send": True,
        "f_sendtime": "2026-10-08T03:00:00Z", "f_attachment": [],
    }


def plan_args(*, with_cover: bool, with_licence: bool) -> dict[str, Any]:
    return {
        "letter": letter("f" if with_licence else "c", 202),
        "application": {"id": 900, "f_approval_status": 9},
        "canonicalRows": [{
            "id": 800, "f_application_id": 900,
            "f_source_system": "OP", "f_request_event": "CREATE",
            "f_api_type": "create_intake_for_new_licence",
            "f_application_type": "new_licence",
            "f_application_status": "Acknowledged",
        }],
        "coverLetters": [letter("c", 201)] if with_cover else [],
        "licenceLetters": [letter("f", 202)] if with_licence else [],
        "accountLetters": [],
    }


def test_only_approved_prior_status_literals_change() -> None:
    source = minimal_source()
    assert target.target_content(source, target.PLAN) == v4.plan_script().replace(
        "  Approved: ['Confirmed', 'Reminding', 'Approved'],",
        "  Approved: ['Acknowledged', 'Confirmed', 'Reminding', 'Approved'],",
        1,
    )
    assert target.target_content(source, target.ADVANCE_PLAN) == (
        v4.advance_script().replace(
            "  Approved: ['Confirmed', 'Reminding'],",
            "  Approved: ['Acknowledged', 'Confirmed', 'Reminding'],",
            1,
        )
    )


def test_acknowledged_can_approve_only_after_both_real_letters() -> None:
    source = minimal_source()
    v5_content = target.target_content(source, target.PLAN)
    complete = plan_args(with_cover=True, with_licence=True)
    assert run_js(v4.plan_script(), complete)["ready"] is False
    revised = run_js(v5_content, complete)
    assert revised["ready"] is True
    assert revised["statusName"] == "Approved"
    assert set(revised["requiredLetterIds"]) == {"201", "202"}
    for cover, licence in ((True, False), (False, True)):
        partial = plan_args(with_cover=cover, with_licence=licence)
        assert run_js(v5_content, partial)["ready"] is False


def test_advance_still_requires_both_persisted_notices() -> None:
    source = minimal_source()
    plan = run_js(
        target.target_content(source, target.PLAN),
        plan_args(with_cover=True, with_licence=True),
    )
    notices = []
    for item in plan["notices"]:
        notices.append({
            "fk_api_request": 800,
            "f_business_record_id": 900,
            "f_third_party_name": "OP",
            "f_source_collection": "t_letter_attachment",
            "fk_status": 7,
            "fk_letter_attachment": item["letterId"],
            "f_notice_type": item["letterType"],
            "f_dedupe_key": item["dedupeKey"],
            "f_source_event_id": item["dedupeKey"],
            "f_source_record_id": item["letterId"],
            "f_source_workflow_key": target.SOURCE_KEY,
            "f_source_workflow_node": "Send Letter",
        })
    args = {
        "planned": plan,
        "canonicalRows": plan_args(
            with_cover=True, with_licence=True
        )["canonicalRows"],
        "notices": notices,
        "mappedStatus": {"id": 7},
    }
    v5_guard = target.target_content(source, target.ADVANCE_PLAN)
    assert run_js(v4.advance_script(), args)["advance"] is False
    assert run_js(v5_guard, args)["advance"] is True
    args["notices"] = notices[:1]
    assert run_js(v5_guard, args)["advance"] is False


def test_candidate_graph_diff_is_limited_to_two_script_contents() -> None:
    source, candidate = prepared_pair()
    target.validate_candidate(source, candidate, enabled=False, phase="prepared")
    drifted = copy.deepcopy(candidate)
    target.by_title(drifted)["Other v4 node 1"]["config"]["collection"] = "wrong"
    with pytest.raises(ApiError, match="differs beyond"):
        target.validate_candidate(source, drifted, enabled=False, phase="prepared")
    drifted = copy.deepcopy(candidate)
    target.by_title(drifted)[target.PLAN]["config"]["timeout"] = 0
    with pytest.raises(ApiError, match="differs beyond"):
        target.validate_candidate(source, drifted, enabled=False, phase="prepared")


class FakeApi:
    def __init__(self, source: dict[str, Any]) -> None:
        self.workflows = {target.SOURCE_ID: copy.deepcopy(source)}
        self.revision_id = target.SOURCE_ID + 1000
        self.writes: list[tuple[str, Any]] = []
        self.fail_enable_sequence: list[tuple[int, bool]] = []

    def get_workflow(self, workflow_id: int) -> dict[str, Any]:
        return copy.deepcopy(self.workflows[workflow_id])

    def request(self, method: str, path: str, body: Any = None) -> Any:
        if method == "GET" and path.startswith("/api/workflows:list?"):
            return [
                {"id": ident, "key": row["key"], "enabled": row["enabled"]}
                for ident, row in self.workflows.items()
            ]
        if method == "GET" and path.startswith("/api/executions:list?"):
            return []
        if method == "POST" and path.startswith("/api/workflows:revision?"):
            source = self.workflows[target.SOURCE_ID]
            self.workflows[self.revision_id] = clone(source)
            self.writes.append(("revision", self.revision_id))
            return {"id": self.revision_id}
        if method == "POST" and path.startswith("/api/workflows:update?"):
            ident = int(path.split("filterByTk=")[1])
            if body["enabled"] and self.fail_enable_sequence:
                failure_id, after_commit = self.fail_enable_sequence[0]
                if ident == failure_id:
                    self.fail_enable_sequence.pop(0)
                    if not after_commit:
                        raise ApiError("simulated enable failure before commit")
                    self.workflows[ident]["enabled"] = True
                    self.writes.append(("enabled", (ident, True)))
                    raise ApiError("simulated response loss after enable")
            self.workflows[ident]["enabled"] = body["enabled"]
            self.writes.append(("enabled", (ident, body["enabled"])))
            return self.workflows[ident]
        raise AssertionError((method, path, body))

    def update_node(self, node_id: int, values: dict[str, Any]) -> None:
        self.writes.append(("node", node_id))
        for workflow in self.workflows.values():
            for row in workflow["nodes"]:
                if row["id"] == node_id:
                    row.update(copy.deepcopy(values))
                    return
        raise AssertionError(node_id)


def test_prepare_copies_executed_source_then_patches_only_disabled_candidate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = minimal_source()
    monkeypatch.setattr(
        target, "SOURCE_FINGERPRINT", target.source_fingerprint(source)
    )
    api = FakeApi(source)
    prepared_id = target.prepare(api)
    assert prepared_id == api.revision_id
    assert api.get_workflow(target.SOURCE_ID) == source
    candidate = api.get_workflow(prepared_id)
    target.validate_candidate(source, candidate, enabled=False, phase="prepared")
    node_writes = [value for kind, value in api.writes if kind == "node"]
    assert len(node_writes) == 2
    assert all(value not in {target.PLAN_ID, target.ADVANCE_PLAN_ID}
               for value in node_writes)
    assert target.prepare(api) == prepared_id
    assert len([value for kind, value in api.writes if kind == "node"]) == 2


def test_cutover_and_rollback_never_enable_both(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = minimal_source()
    monkeypatch.setattr(
        target, "SOURCE_FINGERPRINT", target.source_fingerprint(source)
    )
    api = FakeApi(source)
    candidate_id = target.prepare(api)
    assert target.cutover(api) == candidate_id
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is False
    assert api.get_workflow(candidate_id)["enabled"] is True
    target.rollback(api)
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is True
    assert api.get_workflow(candidate_id)["enabled"] is False
    flags = {target.SOURCE_ID: True}
    for kind, value in api.writes:
        if kind == "revision":
            flags[candidate_id] = False
        elif kind == "enabled":
            ident, enabled = value
            flags[ident] = enabled
            assert not (flags[target.SOURCE_ID] and flags.get(candidate_id, False))


def prepared_api(monkeypatch: pytest.MonkeyPatch) -> tuple[FakeApi, int]:
    source = minimal_source()
    monkeypatch.setattr(
        target, "SOURCE_FINGERPRINT", target.source_fingerprint(source)
    )
    api = FakeApi(source)
    return api, target.prepare(api)


@pytest.mark.parametrize("after_commit", [False, True])
def test_failed_cutover_restores_v4(
    monkeypatch: pytest.MonkeyPatch, after_commit: bool,
) -> None:
    api, candidate_id = prepared_api(monkeypatch)
    api.fail_enable_sequence = [(candidate_id, after_commit)]
    with pytest.raises(ApiError, match="v4 restored"):
        target.cutover(api)
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is True
    assert api.get_workflow(candidate_id)["enabled"] is False


def test_cutover_restores_v5_when_v4_recovery_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    api, candidate_id = prepared_api(monkeypatch)
    api.fail_enable_sequence = [(candidate_id, False), (target.SOURCE_ID, True)]
    with pytest.raises(ApiError, match="reviewed v5 is active"):
        target.cutover(api)
    assert api.fail_enable_sequence == []
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is False
    assert api.get_workflow(candidate_id)["enabled"] is True


@pytest.mark.parametrize("after_commit", [False, True])
def test_failed_rollback_restores_v5(
    monkeypatch: pytest.MonkeyPatch, after_commit: bool,
) -> None:
    api, candidate_id = prepared_api(monkeypatch)
    target.cutover(api)
    api.fail_enable_sequence = [(target.SOURCE_ID, after_commit)]
    with pytest.raises(ApiError, match="v5 restored"):
        target.rollback(api)
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is False
    assert api.get_workflow(candidate_id)["enabled"] is True


def test_audit_fails_closed_when_both_versions_are_disabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    api, candidate_id = prepared_api(monkeypatch)
    api.workflows[target.SOURCE_ID]["enabled"] = False
    assert api.get_workflow(candidate_id)["enabled"] is False
    with pytest.raises(ApiError, match="Notice capture is offline"):
        target.audit(api)
