"""Offline guards for the exact-UID 13001 API workflow category change."""

from __future__ import annotations

import copy
import json
import sys
import urllib.parse
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from attach_api_source_category_guarded_13001 import (  # noqa: E402
    CategoryGuardError,
    Target,
    apply,
    inspect,
    load_targets,
)


class FakeApi:
    def __init__(self, *, commit_then_error: bool = False) -> None:
        self.calls: list[tuple[str, str, object]] = []
        self.commit_then_error = commit_then_error
        self.rows = {
            101: {
                "id": 101, "title": "API Staging — LRN bounded FIFO drain",
                "key": "lrn-key", "type": "schedule", "enabled": False,
                "sync": True, "config": {"startsOn": "2099-01-01"},
                "nodes": [{"id": 501, "key": "step", "type": "sql",
                           "title": "Drain", "config": {"sql": "SELECT 1"}}],
                "categories": [{"id": 8, "title": "Other"}],
            },
        }

    def request(self, method: str, path: str, body: object = None) -> object:
        self.calls.append((method, path, body))
        if path.startswith("/api/workflowCategories:list"):
            return [{"id": 9, "title": "API Suorce"}]
        if path.startswith("/api/workflows:get"):
            uid = int(urllib.parse.parse_qs(
                urllib.parse.urlsplit(path).query
            )["filterByTk"][0])
            return copy.deepcopy(self.rows[uid])
        if method == "POST" and path.startswith("/api/workflows:update"):
            uid = int(urllib.parse.parse_qs(
                urllib.parse.urlsplit(path).query
            )["filterByTk"][0])
            assert isinstance(body, dict)
            assert list(body) == ["categories"]
            self.rows[uid]["categories"] = [
                {"id": category_id} for category_id in body["categories"]
            ]
            if self.commit_then_error:
                raise ConnectionError("Connection reset after commit")
            return self.rows[uid]
        raise AssertionError((method, path, body))


TARGET = Target(101, "schedule", None, "lrn-key", "reviewed-manifest")


def test_manifest_targets_do_not_include_source_uid(tmp_path: Path) -> None:
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps({
        "family": "licence_renewal", "source_uid": 999,
        "worker_uid": 102, "formal_uid": 101, "schedule_key": "lrn-key",
        "smoke_uid": 103, "retired_formal_uid": 104,
    }))
    targets = load_targets([path], None)
    assert [target.uid for target in targets] == [101, 102]
    assert targets[0].expected_key == "lrn-key"


def test_plan_get_only_and_preserves_other_category() -> None:
    api = FakeApi()
    plan = inspect(api, [TARGET])
    assert plan["rows"][0]["category_ids_before"] == [8]
    assert plan["rows"][0]["category_ids_after"] == [8, 9]
    assert all(method == "GET" for method, _, _ in api.calls)


def test_apply_backups_before_category_only_post(tmp_path: Path) -> None:
    api = FakeApi()
    result = apply(api, [TARGET], tmp_path)
    assert result["updated_uids"] == [101]
    backup = Path(result["backup_dir"])
    before = json.loads((backup / "workflow-101-before.json").read_text())
    assert before["categories"] == [{"id": 8, "title": "Other"}]
    assert api.rows[101]["categories"] == [{"id": 8}, {"id": 9}]
    posts = [call for call in api.calls if call[0] == "POST"]
    assert len(posts) == 1
    assert posts[0][2] == {"categories": [8, 9]}


def test_commit_then_connection_reset_reconciles_without_retry(tmp_path: Path) -> None:
    api = FakeApi(commit_then_error=True)
    result = apply(api, [TARGET], tmp_path)
    assert result["updated_uids"] == [101]
    assert sum(method == "POST" for method, _, _ in api.calls) == 1


def test_native_or_unknown_workflow_title_refused() -> None:
    api = FakeApi()
    api.rows[101]["title"] = "Native Intake Submit"
    with pytest.raises(CategoryGuardError, match="not an API workflow"):
        inspect(api, [TARGET])


def test_exact_key_mismatch_refused() -> None:
    api = FakeApi()
    with pytest.raises(CategoryGuardError, match="key drift"):
        inspect(api, [Target(101, "schedule", None, "wrong", "reviewed")])


def test_exact_reviewed_q3_action_allowed_but_diagnostic_refused() -> None:
    api = FakeApi()
    api.rows[101]["title"] = "Q3 UPDATE Admission — guarded pending to queued"
    api.rows[101]["type"] = "custom-action"
    target = Target(
        101, "custom-action", api.rows[101]["title"], "lrn-key", "reviewed"
    )
    assert inspect(api, [target])["rows"][0]["uid"] == 101
    api.rows[101]["title"] = "Q3 Native Wake Diagnostic xyz"
    with pytest.raises(CategoryGuardError, match="not an API workflow"):
        inspect(api, [Target(101, "custom-action",
                             api.rows[101]["title"], "lrn-key", "reviewed")])
