"""Offline reliability tests for the GET-only 13001 workflow exporter."""

from __future__ import annotations

import http.client
import pathlib
import sys
import urllib.request
from typing import Any

SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import backup_nocobase_api_source_workflows_13001 as target  # noqa: E402


class _Response:
    def __enter__(self) -> _Response:
        return self

    def __exit__(self, *_args: Any) -> None:
        return None

    def read(self) -> bytes:
        return b'{"data":{"ok":true}}'


def test_exporter_retries_a_remote_disconnect_for_a_get(monkeypatch: Any) -> None:
    calls = 0

    def fake_urlopen(request: Any, timeout: int) -> _Response:
        nonlocal calls
        calls += 1
        assert request.get_method() == "GET"
        assert timeout == 90
        if calls == 1:
            raise http.client.RemoteDisconnected("upstream reset")
        return _Response()

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(target.time, "sleep", lambda _seconds: None)

    value, meta = target.ReadOnlyNocoBaseApi(
        "http://nocobase.test/cmtf2", "token"
    ).get("/api/workflows:list")

    assert value == {"ok": True}
    assert meta == {}
    assert calls == 2


def test_exporter_sends_root_role_by_default_and_can_disable_it(
    monkeypatch: Any,
) -> None:
    headers: list[dict[str, str]] = []

    def fake_urlopen(request: Any, timeout: int) -> _Response:
        assert timeout == 90
        headers.append({key.lower(): value for key, value in request.header_items()})
        return _Response()

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)

    target.ReadOnlyNocoBaseApi("http://nocobase.test/cmtf2", "token").get(
        "/api/workflows:list"
    )
    target.ReadOnlyNocoBaseApi(
        "http://nocobase.test/cmtf2", "token", root_role=False
    ).get("/api/workflows:list")

    assert headers[0]["x-role"] == "root"
    assert "x-role" not in headers[1]
    assert all(item["authorization"] == "Bearer token" for item in headers)


def test_exporter_rejects_an_invalid_retry_bound() -> None:
    try:
        target.ReadOnlyNocoBaseApi(
            "http://nocobase.test/cmtf2", "token", get_retry_attempts=0
        )
    except ValueError as exc:
        assert "at least one" in str(exc)
    else:  # pragma: no cover - defensive assertion
        raise AssertionError("invalid retry bound must fail")
