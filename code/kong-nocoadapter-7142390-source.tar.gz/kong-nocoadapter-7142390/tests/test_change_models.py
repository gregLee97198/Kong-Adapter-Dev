from __future__ import annotations

import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import pytest
from pydantic import BaseModel, ValidationError

from app.models import (
    CreateIntakeForChangeBedsRequest,
    CreateIntakeForChangeDirectorsRequest,
    CreateIntakeForChangeHomeManagerRequest,
    CreateIntakeForChangeNurseInChargeRequest,
    CreateIntakeForChangeOperationModeRequest,
    UpdateChangeBedsDataRequest,
    UpdateChangeDirectorsDataRequest,
    UpdateChangeHomeManagerDataRequest,
    UpdateChangeNurseInChargeDataRequest,
    UpdateChangeOperationModeDataRequest,
)

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from create_nocobase_phase_f_change_workflows import BPS, parse_config  # noqa: E402

CREATE_MODELS: dict[str, type[BaseModel]] = {
    "mgr": CreateIntakeForChangeHomeManagerRequest,
    "beds": CreateIntakeForChangeBedsRequest,
    "mode": CreateIntakeForChangeOperationModeRequest,
    "dir": CreateIntakeForChangeDirectorsRequest,
    "nurse": CreateIntakeForChangeNurseInChargeRequest,
}

UPDATE_MODELS: dict[str, type[BaseModel]] = {
    "mgr": UpdateChangeHomeManagerDataRequest,
    "beds": UpdateChangeBedsDataRequest,
    "mode": UpdateChangeOperationModeDataRequest,
    "dir": UpdateChangeDirectorsDataRequest,
    "nurse": UpdateChangeNurseInChargeDataRequest,
}


def bp(key: str) -> dict[str, Any]:
    return next(deepcopy(row) for row in BPS if row["key"] == key)


def public_example(key: str) -> dict[str, Any]:
    example = parse_config(bp(key))["example"]
    summary = example["form_data"]["case_summary"]
    for name in (
        "submitter_user_id", "task_owner_user_id", "task_owner_post_code",
        "source_id", "source_other",
    ):
        summary.pop(name, None)
    for name in ("comments", "remarks", "attachment_ids"):
        example["form_data"].pop(name, None)
    return example


@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
def test_phase_f_create_example_matches_public_model(key: str) -> None:
    example = public_example(key)
    request = CREATE_MODELS[key].model_validate(example)

    assert request.request_id
    assert request.form_data.case_summary.office_code == "LORCHE"
    if key == "dir":
        assert "attachment_ids" not in example["form_data"]


@pytest.mark.parametrize("models", [CREATE_MODELS, UPDATE_MODELS])
@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
def test_change_contracts_have_no_checklist_item_fields(
    models: dict[str, type[BaseModel]], key: str
) -> None:
    form_model = models[key].model_fields["form_data"].annotation
    assert isinstance(form_model, type) and issubclass(form_model, BaseModel)
    schema = form_model.model_json_schema()
    property_names = {
        name
        for value in schema.get("$defs", {}).values()
        if isinstance(value, dict)
        for name in (value.get("properties") or {})
    }
    property_names.update(schema.get("properties") or {})

    assert {"checklist", "position_code", "attachment_id"}.isdisjoint(
        property_names
    )


@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
def test_change_create_rejects_checklist(key: str) -> None:
    payload = public_example(key)
    payload["form_data"]["checklist"] = [
        {"position_code": "UNSUPPORTED", "attachment_id": 12345}
    ]

    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        CREATE_MODELS[key].model_validate(payload)


@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
def test_change_update_rejects_checklist(key: str) -> None:
    payload = {
        "request_id": "CHANGE-NO-CHECKLIST-001",
        "create_id": "384761337741312",
        "form_data": {
            "proposed_effective_date": "2026-09-24",
            "checklist": [
                {"position_code": "UNSUPPORTED", "attachment_id": 12345}
            ],
        },
    }

    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        UPDATE_MODELS[key].model_validate(payload)


@pytest.mark.parametrize(
    ("model", "form_data"),
    [
        (
            CreateIntakeForChangeHomeManagerRequest,
            {
                "case_summary": {
                    "office_code": "LORCHE",
                    "submitter_user_id": 12,
                    "task_owner_user_id": 45,
                    "task_owner_post_code": "S(LR)1",
                },
                "proposed_name": "Replacement Manager",
                "attachment_ids": None,
            },
        ),
        (
            UpdateChangeHomeManagerDataRequest,
            {"attachment_ids": None},
        ),
        (
            UpdateChangeBedsDataRequest,
            {"attachment_ids": None},
        ),
        (
            UpdateChangeOperationModeDataRequest,
            {"attachment_ids": None},
        ),
        (
            UpdateChangeNurseInChargeDataRequest,
            {"attachment_ids": None},
        ),
        (
            CreateIntakeForChangeDirectorsRequest,
            {
                "case_summary": {
                    "office_code": "LORCHE",
                    "submitter_user_id": 12,
                    "task_owner_user_id": 45,
                    "task_owner_post_code": "S(LR)1",
                },
                "title": "0",
                "name_en": "Director",
                "name_cn": "董事",
                "date_of_directors_change": "2026-09-23",
                "authorised_to_apply": False,
                "other_phone_number": "21234567",
                "documents": None,
            },
        ),
        (
            UpdateChangeDirectorsDataRequest,
            {"documents": None},
        ),
    ],
)
def test_change_attachment_arrays_reject_null(
    model: type[BaseModel], form_data: dict[str, Any]
) -> None:
    payload = {
        "request_id": "CHANGE-ARRAY-NULL-001",
        "form_data": form_data,
    }
    if model.__name__.startswith("Update"):
        payload["create_id"] = "384761337741312"
    if "case_summary" in form_data:
        for name in (
            "submitter_user_id", "task_owner_user_id", "task_owner_post_code",
        ):
            form_data["case_summary"].pop(name, None)

    expected = (
        "Extra inputs are not permitted"
        if "attachment_ids" in form_data else "must be an array"
    )
    with pytest.raises(ValidationError, match=expected):
        model.model_validate(payload)


@pytest.mark.parametrize(
    "model",
    [
        UpdateChangeHomeManagerDataRequest,
        UpdateChangeBedsDataRequest,
        UpdateChangeOperationModeDataRequest,
        UpdateChangeDirectorsDataRequest,
        UpdateChangeNurseInChargeDataRequest,
    ],
)
def test_change_update_rejects_noop_form_data(model: type[BaseModel]) -> None:
    payload = {
        "request_id": "CHANGE-NOOP-001",
        "create_id": "384761337741312",
        "form_data": {},
    }

    with pytest.raises(ValidationError, match="must contain"):
        model.model_validate(payload)


def test_director_written_authorisation_requires_typed_letter() -> None:
    form_data = {
        "case_summary": {
            "office_code": "LORCHE",
        },
        "title": "0",
        "name_en": "Director",
        "name_cn": "董事",
        "date_of_directors_change": "2026-09-23",
        "authorised_to_apply": True,
        "means_of_authorisation": "1",
        "other_phone_number": "21234567",
        "documents": [],
    }
    payload = {
        "request_id": "DIRECTOR-WRITTEN-001",
        "form_data": form_data,
    }

    with pytest.raises(ValidationError, match="AUTHORISATION_LETTER"):
        CreateIntakeForChangeDirectorsRequest.model_validate(payload)

    form_data["documents"] = [
        {
            "document_type": "AUTHORISATION_LETTER",
            "attachment_ids": [12345],
        }
    ]
    request = CreateIntakeForChangeDirectorsRequest.model_validate(payload)
    assert request.form_data.documents[0].document_type == "AUTHORISATION_LETTER"


def test_home_type_code_must_match_office() -> None:
    example = public_example("mode")
    example["form_data"]["case_summary"]["office_code"] = "LORCHD"
    example["form_data"]["proposed_rch_nature_code"] = "PN"

    with pytest.raises(ValidationError, match="not valid for office_code"):
        CreateIntakeForChangeOperationModeRequest.model_validate(example)


def test_nurse_create_and_update_do_not_restrict_office_code() -> None:
    create = public_example("nurse")
    create["form_data"]["case_summary"]["office_code"] = "LORCHD"
    assert (
        CreateIntakeForChangeNurseInChargeRequest.model_validate(create)
        .form_data.case_summary.office_code
        == "LORCHD"
    )

    update = {
        "request_id": "NURSE-LORCHD-UPDATE-001",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {"office_code": "LORCHD", "rch_no": "D0043"},
            "name": "Chan Mei Ling",
        },
    }
    assert (
        UpdateChangeNurseInChargeDataRequest.model_validate(update)
        .form_data.case_summary.office_code
        == "LORCHD"
    )


def test_beds_counts_are_nonnegative_without_unconfirmed_total_equations() -> None:
    negative = public_example("beds")
    negative["form_data"]["proposed_beds_self_care"] = -1
    with pytest.raises(ValidationError):
        CreateIntakeForChangeBedsRequest.model_validate(negative)

    # Existing 13001 records legitimately keep resident totals independent
    # from the formula-derived proposed bed total (for example 100 beds and
    # zero resident totals).  The API must not invent equality constraints.
    independent_totals = public_example("beds")
    independent_totals["form_data"].update(
        {
            "proposed_beds_self_care": 30,
            "proposed_beds_meal": 20,
            "proposed_beds_nursing": 40,
            "proposed_beds_care_and_attention": 10,
            "proposed_residents_total_ab": 0,
            "proposed_residents_total_a": 0,
            "proposed_residents_total_b": 0,
        }
    )
    request = CreateIntakeForChangeBedsRequest.model_validate(independent_totals)
    assert request.form_data.proposed_residents_total_ab == 0

    missing_others_description = public_example("beds")
    missing_others_description["form_data"].update(
        {
            "proposed_residents_nonelderly_others": 1,
            "proposed_residents_nonelderly_others_specify": None,
        }
    )
    with pytest.raises(ValidationError, match="Others count"):
        CreateIntakeForChangeBedsRequest.model_validate(
            missing_others_description
        )
