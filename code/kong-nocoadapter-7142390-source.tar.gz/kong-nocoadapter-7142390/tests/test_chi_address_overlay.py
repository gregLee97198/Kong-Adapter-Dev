"""The CHI address overlay must never target the Home Record address."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from create_nocobase_chi_address_overlay import overlay_script  # noqa: E402


def evaluate(target_address_id: int) -> subprocess.CompletedProcess[str]:
    node = shutil.which("node")
    if node is None:
        pytest.skip("Node.js is not available")
    arguments = {
        "staging": {
            "f_chi_address_requested": True,
            "f_application_id": "100",
            "f_rch_id": "200",
            "f_request_body": {"form_data": {"part_2": {
                "address": {"full_name_en": "CHI-only address"}}}},
        },
        "application": {
            "id": 100, "fk_home_record": 200,
            "fk_rch_address": target_address_id,
        },
        "home": {"id": 200, "fk_rch_address": 300},
        "independentAddress": {
            "id": target_address_id, "f_fullname_en": "Previous address"
        },
        "addressOptions": [],
    }
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const names = Object.keys(input.arguments);
const result = new Function(...names, input.script)(
  ...names.map(name => input.arguments[name]));
process.stdout.write(JSON.stringify(result));
"""
    return subprocess.run(
        [node, "-e", runner],
        input=json.dumps({"script": overlay_script(), "arguments": arguments}),
        text=True, capture_output=True, check=False,
    )


def test_home_record_address_id_is_refused() -> None:
    result = evaluate(300)
    assert result.returncode != 0
    assert "Home Record write refused" in result.stderr


def test_only_independent_address_can_be_updated() -> None:
    result = evaluate(301)
    assert result.returncode == 0, result.stderr
    output = json.loads(result.stdout)
    assert output["address_id"] == 301
    assert output["address_patch"]["f_fullname_en"] == "CHI-only address"
