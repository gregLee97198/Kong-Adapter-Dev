"""Offline tests for integration-only CHI Created bridge race guard."""

from __future__ import annotations

import copy
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from create_nocobase_phase_c_chi_workflows import CREATE_BRIDGE_TITLE  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402
from revise_nocobase_chi_created_bridge import (  # noqa: E402
    PROVENANCE_CONDITION_TITLE,
    PROVENANCE_QUERY_TITLE,
    RECHECK_TITLE,
    SOURCE_CONDITION_TITLE,
    SOURCE_CREATE_TITLE,
    SOURCE_QUERY_TITLE,
    WAIT_TITLE,
    add_bridge_wait,
    existing_bridge_draft,
    validate_bridge_draft,
)


class FakeApi:
    def __init__(self, workflow: dict) -> None:
        self.workflow = workflow
        self.next_id = 5000

    def create_node(self, body: dict) -> dict:
        self.next_id += 1
        node = {
            "id": self.next_id,
            "key": f"mock{self.next_id}",
            "type": body["type"],
            "title": body["title"],
            "config": body["config"],
        }
        self.workflow["nodes"].append(node)
        return node

    def update_node(self, node_id: int, values: dict) -> dict:
        node = next(row for row in self.workflow["nodes"] if row["id"] == node_id)
        node.update(values)
        return node


def source() -> dict:
    initial = {
        "id": 100,
        "key": "original-query",
        "title": SOURCE_QUERY_TITLE,
        "type": "query",
        "config": {
            "collection": "t_api_request_staging",
            "multiple": False,
            "params": {
                "filter": {
                    "$and": [
                        {"f_request_event": {"$eq": "CREATE"}},
                        {"f_api_type": {"$eq": "create_intake_for_changing_home"}},
                        {
                            "$or": [
                                {
                                    "f_intake_id": {
                                        "$eq": "{{$context.data.fk_intake_form}}"
                                    }
                                },
                                {"f_application_id": {"$eq": "{{$context.data.id}}"}},
                            ]
                        },
                    ]
                }
            },
        },
    }
    condition = {
        "id": 101,
        "key": "old-condition",
        "title": SOURCE_CONDITION_TITLE,
        "type": "condition",
        "config": {},
        "upstreamId": 100,
    }
    create = {
        "id": 102,
        "key": "old-create",
        "title": SOURCE_CREATE_TITLE,
        "type": "create",
        "config": {
            "collection": "t_api_request_staging",
            "params": {
                "values": {
                    "f_source_system": "CMTF",
                    "f_status": "succeeded",
                    "f_application_status": "Submitted",
                }
            },
        },
        "upstreamId": 101,
        "branchIndex": 0,
    }
    return {
        "id": 386582574202880,
        "key": "bridge-key",
        "title": CREATE_BRIDGE_TITLE,
        "enabled": True,
        "executed": 0,
        "config": {
            "mode": 1,
            "condition": {},
            "collection": "t_change_home_information_app",
        },
        "nodes": [initial, condition, create],
    }


def test_disabled_bridge_waits_and_rechecks_before_cmtf_staging_create() -> None:
    old = source()
    draft = copy.deepcopy(old)
    draft["id"] = 4999
    draft["enabled"] = False
    add_bridge_wait(FakeApi(draft), draft)
    validate_bridge_draft(draft, old)
    nodes = {row["title"]: row for row in draft["nodes"]}
    assert nodes[PROVENANCE_QUERY_TITLE].get("upstreamId") is None
    provenance_calculations = nodes[PROVENANCE_CONDITION_TITLE]["config"][
        "calculation"
    ]["group"]["calculations"]
    assert provenance_calculations[0]["calculator"] == "gt"
    assert provenance_calculations[0]["operands"][1] == 0
    assert nodes[SOURCE_QUERY_TITLE]["upstreamId"] == nodes[
        PROVENANCE_CONDITION_TITLE]["id"]
    assert nodes[PROVENANCE_CONDITION_TITLE].get("downstreamId") is None
    assert nodes[SOURCE_QUERY_TITLE]["branchIndex"] == 0
    assert nodes[WAIT_TITLE]["upstreamId"] == nodes[SOURCE_CONDITION_TITLE]["id"]
    assert nodes[WAIT_TITLE]["branchIndex"] == 0
    assert nodes[WAIT_TITLE]["config"]["duration"] == 3
    assert nodes[RECHECK_TITLE]["config"] == nodes[SOURCE_QUERY_TITLE]["config"]
    assert nodes[SOURCE_CREATE_TITLE]["upstreamId"] == nodes[
        "OP CHI CREATE staging linked after wait"]["id"]
    assert nodes[SOURCE_CREATE_TITLE]["config"]["params"]["values"][
        "f_application_status"
    ] == "Accepted"


def test_partial_bridge_draft_does_not_create_another_revision() -> None:
    old = source()
    draft = copy.deepcopy(old)
    draft["id"] = 4999
    draft["enabled"] = False
    add_bridge_wait(FakeApi(draft), draft)
    draft["nodes"] = [
        row for row in draft["nodes"] if row["title"] != WAIT_TITLE
    ]

    class ListApi:
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET" and "workflows:list" in path
            return [old, draft]

        def get_workflow(self, workflow_id: int) -> dict:
            assert workflow_id == draft["id"]
            return draft

    try:
        existing_bridge_draft(ListApi(), old)
    except ApiError as exc:
        assert "incomplete" in str(exc)
    else:
        raise AssertionError("Partial CHI bridge draft must fail closed")


def test_bridge_guard_refuses_missing_linked_intake_query_result() -> None:
    old = source()
    draft = copy.deepcopy(old)
    draft["id"] = 4999
    draft["enabled"] = False
    add_bridge_wait(FakeApi(draft), draft)
    condition = next(
        row for row in draft["nodes"] if row["title"] == PROVENANCE_CONDITION_TITLE
    )
    condition["config"]["calculation"]["group"]["calculations"].pop(0)
    try:
        validate_bridge_draft(draft, old)
    except ApiError as exc:
        assert "does not suppress Intake" in str(exc)
    else:
        raise AssertionError("Bridge must not classify missing Intake as OP")
