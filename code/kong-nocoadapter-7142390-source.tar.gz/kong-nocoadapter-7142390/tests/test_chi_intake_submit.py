import sys
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from create_nocobase_phase_c_chi_workflows import (  # noqa: E402
    INTAKE_NATIVE_ACCEPT,
    INTAKE_SUBMIT_WORKFLOW_KEY,
    SUBMIT_TITLE,
    chi_intake_create_values,
)


def test_chi_intake_create_uses_business_submitter_and_native_accept() -> None:
    parse = {"key": "parseKey"}
    values = chi_intake_create_values(parse)

    assert values["createdBy"] == "{{$jobsMapByNodeKey.parseKey.submitterId}}"
    assert values["f_intake_accept_reject"] == INTAKE_NATIVE_ACCEPT == "0"
    assert "f_approval_status" not in values
    assert INTAKE_SUBMIT_WORKFLOW_KEY == "qdkj25b0793"
    assert SUBMIT_TITLE == "Run native Intake Form Submit as business submitter"
