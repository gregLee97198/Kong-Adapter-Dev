"""Pure local checks for CHI page-only workflow projection and ownership guards."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from revise_nocobase_chi_page_projection import (  # noqa: E402
    ADDRESS_PAGE_FIELDS,
    ALL_CHI_FIELDS,
    CHECKLIST_INPUT_VALIDATION_SCRIPT,
    CHECKLIST_POST_LOOP_VERIFY_SCRIPT,
    CHECKLIST_PREFLIGHT_SCRIPT,
    CHECKLIST_TEMPLATE_SELECT_SCRIPT,
    CHI_PAGE_FIELDS,
    CONTACT_NESTED_FIELDS,
    CONTACT_PAGE_FIELDS,
    projection_script,
)


def run_checklist_input_guard(rows: object) -> dict:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const result = new Function('checklist', input.script)(input.rows);
process.stdout.write(JSON.stringify(result));
"""
    result = subprocess.run(
        [node, "-e", runner],
        input=json.dumps(
            {"script": CHECKLIST_INPUT_VALIDATION_SCRIPT, "rows": rows}
        ),
        text=True,
        capture_output=True,
        check=True,
    )
    return json.loads(result.stdout)


def test_raw_checklist_input_guard_rejects_storm_shapes() -> None:
    too_many = [
        {"position_code": f"CHI:{index}", "attachment_id": index + 1}
        for index in range(101)
    ]
    assert run_checklist_input_guard(too_many) == {
        "ready": False,
        "block_reason": "chi_checklist_limit_exceeded: maximum 100 items",
    }
    duplicate = [
        {"position_code": "CHI:DUPLICATE", "attachment_id": 1},
        {"position_code": "CHI:DUPLICATE", "attachment_id": 2},
    ]
    assert run_checklist_input_guard(duplicate) == {
        "ready": False,
        "block_reason": (
            "chi_checklist_duplicate_position_code: CHI:DUPLICATE"
        ),
    }
    accepted = [
        {"position_code": f"CHI:{index}", "attachment_id": index + 1}
        for index in range(100)
    ]
    assert run_checklist_input_guard(accepted) == {
        "ready": True,
        "block_reason": None,
    }


def run(
    form_data: dict,
    *,
    app: dict | None = None,
    chi_address: int = 301,
    home_address: int = 300,
    company: dict | None = None,
    person_rows: list[dict] | None = None,
    home_people: list[dict] | None = None,
    home_company_id: int | None = 600,
    home_company_data: dict | None = None,
    checklist_templates: list[dict] | None = None,
    checklist_uploads: list[dict] | None = None,
    missing_fields: tuple[str, ...] = (),
) -> subprocess.CompletedProcess[str]:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    default_app = {name: None for name in ALL_CHI_FIELDS}
    default_app.update(
        {
            "id": 100,
            "fk_home_record": 200,
            "fk_rch_address": chi_address,
            "f_source_home_snapshot_version": 1,
            "f_office_cd": "LORCHE",
            "f_rch_name_en": "Existing Name",
            "f_rch_name_cn": "舊名",
        "fk_type_of_rch": 10,
        "f_business_ownership_type": "2",
            "f_licence_capacity": 20,
            "f_attachments_of_rchs": [{"id": 500}],
            "is_change_name": False,
            "is_change_address": False,
            "is_change_operator_or_operating_company": False,
            "is_change_rch_type": False,
            "is_change_maximum_capacity": False,
        }
    )


    default_app.update(app or {})
    for field in missing_fields:
        default_app.pop(field, None)
    arguments = {
        "formData": form_data,
        "application": default_app,
        "home": {
            "id": 200,
            "fk_rch_address": home_address,
            "f_home_contact_company": (
                {"id": home_company_id} if home_company_id else None
            ),
            "f_home_contact_person": home_people or [],
        },
        "chiAddress": {
            **{name: None for name in ADDRESS_PAGE_FIELDS},
            "id": chi_address,
            "f_fullname_en": "Old address",
        },
        "homeAddress": {"id": home_address},
        "companyContact": (
            {
                **{
                    name: None
                    for name in (*CONTACT_PAGE_FIELDS, *CONTACT_NESTED_FIELDS)
                },
                **company,
            }
            if company
            else {}
        ),
        "operatorContact": [
            {
                **{
                    name: None
                    for name in (*CONTACT_PAGE_FIELDS, *CONTACT_NESTED_FIELDS)
                },
                **row,
            }
            for row in (person_rows or [])
        ],
        "homeCompanyContact": (
            {
                "id": home_company_id,
                "f_rpop_op_app": [],
                **{
                    name: None
                    for name in CONTACT_NESTED_FIELDS
                    if name != "f_rpop_op_app"
                },
                **(home_company_data or {}),
            }
            if home_company_id
            else {}
        ),
        "homePersonContacts": [],
        "checklistTemplates": checklist_templates or [],
        "checklistUploads": checklist_uploads or [],
        "rchTypeOptions": [
            {"id": 11, "f_code": "a1", "f_for_office": "LORCHE"},
        ],
        "addressOptions": [],
    }
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const names = Object.keys(input.arguments);
try {
  const result = new Function(...names, input.script)(
    ...names.map(name => input.arguments[name]));
  process.stdout.write(JSON.stringify(result));
} catch (error) {
  process.stderr.write(error.message);
  process.exitCode = 1;
}
"""
    return subprocess.run(
        [node, "-e", runner],
        input=json.dumps({"script": projection_script(), "arguments": arguments}),
        text=True,
        capture_output=True,
        check=False,
    )


def test_checklist_preflight_script_exposes_real_unique_query_arrays() -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const args = input.bind ? ['checklist'] : [];
const result = new Function(...args, input.script)(
  ...(input.bind ? [input.rows] : []));
process.stdout.write(JSON.stringify(result));
"""
    rows = [
        {"position_code": "LORCHE_STAGE2:PROOF_OF_ADDRESS", "attachment_id": 1220},
        {"position_code": "LORCHE_STAGE2:PROOF_OF_ADDRESS", "attachment_id": "1220"},
        {"position_code": "LORCHE_STAGE2:APPLICATION", "attachment_id": 1221},
    ]
    result = subprocess.run(
        [node, "-e", runner],
        input=json.dumps(
            {"script": CHECKLIST_PREFLIGHT_SCRIPT, "rows": rows, "bind": True}
        ),
        text=True,
        capture_output=True,
        check=True,
    )
    assert json.loads(result.stdout) == {
        "position_codes": [
            "LORCHE_STAGE2:PROOF_OF_ADDRESS",
            "LORCHE_STAGE2:APPLICATION",
        ],
        "attachment_ids": [1220, 1221],
    }
    absent = subprocess.run(
        [node, "-e", runner],
        input=json.dumps({"script": CHECKLIST_PREFLIGHT_SCRIPT, "bind": False}),
        text=True,
        capture_output=True,
        check=True,
    )
    assert json.loads(absent.stdout) == {
        "position_codes": [], "attachment_ids": []
    }


def test_post_loop_checklist_script_checks_latest_and_new_details() -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const result = new Function('checklist', 'templates', 'items',
  'requestCreatedAt', input.script)(input.checklist, input.templates,
  input.items, input.requestCreatedAt);
process.stdout.write(JSON.stringify(result));
"""
    code = "LORCHE_STAGE2:PROOF_OF_ADDRESS"
    request_time = "2026-09-15T15:20:38.633Z"
    template = {"id": 373714108481536, "f_position_code": code}
    item = {
        "id": 386842883194881,
        "fk_document_checklist": template["id"],
        "f_lastest_files": [{"id": 1220}],
        "f_details": [{
            "id": 386844145680386,
            "fk_documests_submitted_for_application_id": 386842883194881,
            "createdAt": "2026-09-15T15:21:03.164Z",
            "f_files": [{"id": 1220}],
        }],
    }

    def verify(
        row: dict,
        *,
        request_created_at: str = request_time,
        assignments: list[dict] | None = None,
    ) -> dict:
        result = subprocess.run(
            [node, "-e", runner],
            input=json.dumps({
                "script": CHECKLIST_POST_LOOP_VERIFY_SCRIPT,
                "checklist": (
                    [{"position_code": code, "attachment_id": 1220}]
                    if assignments is None else assignments
                ),
                "templates": [template],
                "items": [row],
                "requestCreatedAt": request_created_at,
            }),
            text=True,
            capture_output=True,
            check=False,
        )
        assert result.returncode == 0, result.stderr
        return json.loads(result.stdout)

    assert verify(item) == {"ready": True, "verified_count": 1}
    assert verify({**item, "f_lastest_files": [], "f_details": []},
                  assignments=[]) == {"ready": True, "verified_count": 0}
    # NocoBase leaves a missing Script argument unbound, rather than [] or null.
    missing_checklist_runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const result = new Function('templates', 'items', input.script)([], []);
process.stdout.write(JSON.stringify(result));
"""
    absent = subprocess.run(
        [node, "-e", missing_checklist_runner],
        input=json.dumps({"script": CHECKLIST_POST_LOOP_VERIFY_SCRIPT}),
        text=True,
        capture_output=True,
        check=False,
    )
    assert absent.returncode == 0, absent.stderr
    assert json.loads(absent.stdout) == {"ready": True, "verified_count": 0}
    assert verify({**item, "f_lastest_files": []})["block_reason"] == (
        "chi_checklist_latest_not_saved"
    )
    assert verify({**item, "f_details": []})["block_reason"] == (
        "chi_checklist_details_not_saved"
    )
    old_detail = {
        **item,
        "f_details": [{
            **item["f_details"][0],
            "createdAt": "2026-09-15T15:11:01.619Z",
        }],
    }
    assert verify(old_detail)["block_reason"] == (
        "chi_checklist_details_not_saved"
    )


def test_post_loop_verifier_uses_same_chi_first_template_choice() -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const result = new Function('checklist', 'templates', 'items',
  'requestCreatedAt', input.script)(input.checklist, input.templates,
  input.items, input.requestCreatedAt);
process.stdout.write(JSON.stringify(result));
"""
    code = "DUPLICATE-CODE"
    templates = [
        {"id": 9, "f_position_code": code, "f_use_for": ["t_licence_app"]},
        {
            "id": 7,
            "f_position_code": code,
            "f_use_for": ["t_change_home_information_app"],
        },
        {
            "id": 5,
            "f_position_code": code,
            "f_use_for": ["t_change_home_information_app"],
        },
    ]
    item = {
        "id": 50,
        "fk_document_checklist": 5,
        "f_lastest_files": [{"id": 501}],
        "f_details": [
            {
                "fk_documests_submitted_for_application_id": 50,
                "createdAt": "2026-09-15T15:21:03.164Z",
                "f_files": [{"id": 501}],
            }
        ],
    }
    result = subprocess.run(
        [node, "-e", runner],
        input=json.dumps(
            {
                "script": CHECKLIST_POST_LOOP_VERIFY_SCRIPT,
                "checklist": [{"position_code": code, "attachment_id": 501}],
                "templates": templates,
                "items": [item],
                "requestCreatedAt": "2026-09-15T15:20:38.633Z",
            }
        ),
        text=True,
        capture_output=True,
        check=True,
    )
    assert json.loads(result.stdout) == {"ready": True, "verified_count": 1}


def test_only_five_popup_main_fields_are_projected() -> None:
    response = run(
        {
            "case_summary": {"office_code": "LORCHE"},
            "is_change_name": True,
            "is_change_rch_type": True,
            "is_change_maximum_capacity": True,
            "part_2": {
                "rch_name_en": "Proposed Name",
                "rch_type_code": "a1",
                "max_capacity": 35,
                "monthly_fee_min": 999,
            },
        }
    )
    assert response.returncode == 0, response.stderr
    result = json.loads(response.stdout)
    assert set(result["page_patch"]) == set(CHI_PAGE_FIELDS)
    assert result["page_patch"]["f_rch_name_en"] == "Proposed Name"
    assert result["page_patch"]["fk_type_of_rch"] == 11
    assert result["page_patch"]["f_licence_capacity"] == 35
    assert "f_service_type" in result["page_patch"]
    assert "f_business_ownership_type" in result["page_patch"]
    assert "f_monthly_fee_per_resident_min" not in result["page_patch"]
    assert result["address_requested"] is False
    assert result["legacy_patch"]["f_monthly_fee_per_resident_min"] == 999


def test_absent_legacy_fields_preserve_current_values_and_file_ids() -> None:
    response = run(
        {"is_change_name": True, "part_2": {"rch_name_cn": "新名"}},
        app={"f_telephone_no": "21234567", "f_beds_nursing": 8},
    )
    assert response.returncode == 0, response.stderr
    patch = json.loads(response.stdout)["legacy_patch"]
    assert patch["f_telephone_no"] == "21234567"
    assert patch["f_beds_nursing"] == 8
    assert patch["f_attachments_of_rchs"] == [500]
    assert patch["f_rch_name_en"] == "Existing Name"
    assert patch["f_rch_name_cn"] == "新名"


def test_unloaded_existing_chi_field_blocks_before_update() -> None:
    response = run(
        {"is_change_name": True, "part_2": {"rch_name_en": "New"}},
        missing_fields=("f_telephone_no",),
    )
    assert response.returncode == 0
    result = json.loads(response.stdout)
    assert result["ready"] is False
    assert result["block_reason"] == "chi_current_values_not_loaded"


def test_every_chi_checklist_code_and_upload_is_preflighted_before_overlay() -> None:
    form = {"is_change_name": True,
            "part_2": {"rch_name_en": "Proposed"},
            "part_5": {"checklist": [
                {"position_code": "CHI-DOC-001", "attachment_id": 501},
            ]}}
    missing = run(form)
    assert json.loads(missing.stdout)["block_reason"] == (
        "chi_checklist_template_not_resolved"
    )
    code = [{"id": 800, "f_position_code": "CHI-DOC-001"}]
    no_file = run(form, checklist_templates=code)
    assert json.loads(no_file.stdout)["block_reason"] == (
        "chi_checklist_attachment_not_resolved"
    )
    good = run(form, checklist_templates=code,
               checklist_uploads=[{"id": 501}])
    projected = json.loads(good.stdout)
    assert projected["ready"] is True
    assert projected["page_patch"]["f_rch_name_en"] == "Proposed"


def test_name_and_capacity_overlay_fails_closed_without_snapshot_version() -> None:
    app = {
        "id": 100,
        "fk_home_record": 200,
        "fk_rch_address": 301,
        "f_source_home_snapshot_version": None,
    }
    response = run(
        {
            "is_change_name": True,
            "is_change_maximum_capacity": True,
            "part_2": {"rch_name_en": "Example RCH New Name", "max_capacity": 90},
        },
        app=app,
    )
    assert response.returncode == 0, response.stderr
    projected = json.loads(response.stdout)
    assert projected["ready"] is False
    assert projected["block_reason"] == "native_chi_snapshot_incomplete"
    assert projected["address_ops"] == []
    assert projected["contact_updates"] == []


def test_nla_position_code_resolves_when_chi_and_nla_catalogs_share_code() -> None:
    form = {
        "is_change_name": True,
        "part_2": {"rch_name_en": "Proposed"},
        "part_5": {"checklist": [
            {"position_code": "LORCHE_STAGE2:ELDERLY_HOME_LICENCE_APPLICATION_FORM",
             "attachment_id": 501},
        ]},
    }
    templates = [
        {
            "id": 900,
            "f_position_code": "LORCHE_STAGE2:ELDERLY_HOME_LICENCE_APPLICATION_FORM",
            "f_use_for": ["t_licence_app"],
        },
        {
            "id": 901,
            "f_position_code": "LORCHE_STAGE2:ELDERLY_HOME_LICENCE_APPLICATION_FORM",
            "f_use_for": ["t_change_home_information_app", "t_licence_app"],
        },
    ]
    response = run(
        form,
        checklist_templates=templates,
        checklist_uploads=[{"id": 501}],
    )
    assert response.returncode == 0, response.stderr
    assert json.loads(response.stdout)["ready"] is True


def test_cloned_address_overlay_fails_before_address_write_without_snapshot() -> None:
    app = {
        "id": 100,
        "fk_home_record": 200,
        "fk_rch_address": 301,
        "f_source_home_snapshot_version": None,
    }
    response = run(
        {"is_change_address": True, "part_2": {"address": {"full_name_en": "New"}}},
        app=app,
    )
    assert response.returncode == 0, response.stderr
    result = json.loads(response.stdout)
    assert result["ready"] is False
    assert result["block_reason"] == "native_chi_snapshot_incomplete"
    assert result["address_requested"] is False
    assert result["address_ops"] == []


def test_home_record_address_id_is_never_a_write_target() -> None:
    response = run(
        {"is_change_address": True, "part_2": {"address": {"full_name_en": "New"}}},
        chi_address=300,
        home_address=300,
    )
    assert response.returncode == 0
    assert json.loads(response.stdout)["block_reason"] == (
        "Home Record address write refused"
    )


def test_independent_chi_address_is_selected() -> None:
    response = run(
        {"is_change_address": True, "part_2": {"address": {"full_name_en": "New"}}}
    )
    assert response.returncode == 0, response.stderr
    result = json.loads(response.stdout)
    assert result["address_id"] == 301
    assert result["address_patch"]["f_fullname_en"] == "New"


def test_company_requires_chi_owned_clone_and_rejects_unmapped_fields() -> None:
    form = {
        "is_change_operator_or_operating_company": True,
        "part_3": {"company": {"company_name_en": "New Company"}},
    }
    missing = run(form)
    projected = json.loads(missing.stdout)
    assert projected["ready"] is False
    assert projected["contact_pending"] is True
    assert projected["block_reason"] == "native_chi_contact_clone_incomplete"
    assert projected["contact_updates"] == []
    existing = run(form, company={"id": 601, "fk_licence_contact_company": 100})
    assert existing.returncode == 0, existing.stderr
    updates = json.loads(existing.stdout)["contact_updates"]
    assert updates[0]["id"] == 601
    assert updates[0]["patch"]["f_compnay_name_en"] == "New Company"
    trust = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"company": {"trust_no": "TRUST-1"}},
        },
        company={"id": 601, "fk_licence_contact_company": 100},
    )
    assert trust.returncode == 0
    assert "unsupported CHI contact field" in json.loads(trust.stdout)["block_reason"]


def test_operator_popup_status_and_mobile_are_mapped_on_chi_owner() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "rch_business_status": "1",
                "applicant_operator_type": "2",
                "company": {
                    "company_name_en": "Proposed Ltd",
                    "mobile_phone": "90000000",
                },
            },
        },
        company={"id": 601, "fk_licence_contact_company": 100},
    )
    assert response.returncode == 0, response.stderr
    projected = json.loads(response.stdout)
    assert projected["ready"] is True
    assert projected["page_patch"]["f_service_type"] == "1"
    assert projected["page_patch"]["f_business_ownership_type"] == "2"
    assert projected["contact_updates"][0]["patch"]["f_mobile_phone"] == "90000000"


def test_popup_status_only_is_not_mistaken_for_missing_contact() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"rch_business_status": "0", "applicant_operator_type": "3"},
        }
    )
    assert response.returncode == 0, response.stderr
    projected = json.loads(response.stdout)
    assert projected["ready"] is True
    assert projected["page_patch"]["f_service_type"] == "0"
    assert projected["page_patch"]["f_business_ownership_type"] == "3"
    assert projected["contact_updates"] == []


def test_accepted_but_unmapped_contact_field_is_rejected() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"company": {"contact_relationship": "Other"}},
        },
        company={"id": 601, "fk_licence_contact_company": 100},
    )
    assert response.returncode == 0
    assert "no verified CHI page mapping" in json.loads(response.stdout)["block_reason"]
    extra_phone = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"company": {"office_phone": "28000000"}},
        },
        company={"id": 601, "fk_licence_contact_company": 100},
    )
    assert extra_phone.returncode == 0
    assert "no verified CHI page mapping" in json.loads(extra_phone.stdout)[
        "block_reason"
    ]


def test_new_chi_owned_company_nests_registration_and_declaration_children() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "company": {
                    "company_name_en": "New Co",
                    "registration_identifier_types": ["1"],
                    "legislation_chapter_no": "123",
                    "declaration_answers": {"1": "Yes"},
                }
            },
        },
        home_company_id=None,
    )
    assert response.returncode == 0, response.stderr
    result = json.loads(response.stdout)
    assert result["ready"] is True
    created = result["contact_updates"][0]
    assert created["kind"] == "company" and created["id"] == 0
    assert created["patch"]["fk_licence_contact_company"] == 100
    assert created["patch"]["f_rpop_op_app"] == [
        {
            "f_company_registration_identifier_types": ["1"],
            "f_legislation_chapter_no": "123",
        }
    ]
    assert created["patch"]["f_rpop_app_detail_1"] == {
        "f_declaration_answer": "Yes",
    }


def test_existing_company_child_ids_must_be_distinct_from_home_ids() -> None:
    request = {
        "is_change_operator_or_operating_company": True,
        "part_3": {
            "company": {
                "registration_identifier_types": ["0"],
                "declaration_answers": {"1": "No"},
            }
        },
    }
    current = {
        "id": 601,
        "fk_licence_contact_company": 100,
        "f_rpop_op_app": [
            {
                "id": 800,
                "fk_licence_contact": 601,
                "f_company_registration_identifier_types": 0,
                "f_legislation_chapter_no": "12",
            }
        ],
        "f_rpop_app_detail_1": {"id": 900, "f_declaration_answer": "Yes"},
    }
    source = {"f_rpop_op_app": [{"id": 700}], "f_rpop_app_detail_1": {"id": 901}}
    response = run(request, company=current, home_company_data=source)
    assert response.returncode == 0, response.stderr
    projected = json.loads(response.stdout)
    assert projected["ready"] is True
    update = projected["contact_updates"][0]
    assert update["registration_ops"][0]["id"] == 800
    assert update["registration_ops"][0]["patch"][
        "f_company_registration_identifier_types"
    ] == ["0"]
    assert update["declaration_ops"]["1"][0]["id"] == 900
    current["f_rpop_app_detail_1"] = {"id": 901}
    unsafe = run(request, company=current, home_company_data=source)
    assert json.loads(unsafe.stdout)["block_reason"] == (
        "Home Record declaration child write refused"
    )


def test_direct_staging_company_registration_rejects_multiple_radio_values() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "company": {"registration_identifier_types": ["0", "1"]}
            },
        },
        home_company_id=None,
    )
    assert response.returncode == 0
    result = json.loads(response.stdout)
    assert result["ready"] is False
    assert "one radio value" in result["block_reason"]


def test_person_operator_creates_only_when_home_has_no_person_source() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"applicant_operator_type": "0",
                       "operator": {"full_name_en": "Operator"}},
        }
    )
    first = json.loads(response.stdout)
    assert first["ready"] is True
    assert first["contact_updates"][0]["id"] == 0
    assert first["contact_updates"][0]["patch"]["fk_licence_contact_person"] == 100
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"applicant_operator_type": "0",
                       "operator": {"full_name_en": "Operator"}},
        },
        person_rows=[{"id": 602, "fk_licence_contact_person": 100}],
    )
    assert response.returncode == 0, response.stderr
    update = json.loads(response.stdout)["contact_updates"][0]
    assert update["id"] == 602
    assert update["patch"]["fk_licence_contact_person"] == 100
    assert "fk_api_chi_change_operator" not in update["patch"]
    cloned = run(
        {"is_change_operator_or_operating_company": True,
         "part_3": {"applicant_operator_type": "1",
                    "operator": {"full_name_en": "Operator"}}},
        person_rows=[{"id": 602, "fk_licence_contact_person": 100}],
        home_people=[{"id": 700}],
    )
    assert json.loads(cloned.stdout)["contact_updates"][0]["id"] == 602
    unsafe = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"applicant_operator_type": "0",
                       "operator": {"full_name_en": "Operator"}},
        },
        home_people=[{"id": 700}],
    )
    person_pending = json.loads(unsafe.stdout)
    assert person_pending["ready"] is False
    assert person_pending["contact_pending"] is True
    assert person_pending["block_reason"] == (
        "native_chi_person_contact_clone_incomplete"
    )
    assert person_pending["contact_updates"] == []
    wrong_owner = run(
        {"is_change_operator_or_operating_company": True,
         "part_3": {"applicant_operator_type": "0",
                    "operator": {"full_name_en": "Operator"}}},
        person_rows=[{"id": 602, "fk_licence_contact_person": 200}],
    )
    assert json.loads(wrong_owner.stdout)["block_reason"] == (
        "Home Record contact write refused"
    )


def test_independent_name_overlays_when_company_clone_is_pending() -> None:
    response = run(
        {
            "is_change_name": True,
            "is_change_operator_or_operating_company": True,
            "is_change_maximum_capacity": True,
            "part_2": {
                "rch_name_en": "Proposed Name",
                "max_capacity": 90,
            },
            "part_3": {
                "rch_business_status": "1",
                "applicant_operator_type": "2",
                "company": {"company_name_en": "New Company"},
            },
        }
    )
    assert response.returncode == 0, response.stderr
    projected = json.loads(response.stdout)
    assert projected["ready"] is False
    assert projected["contact_pending"] is True
    assert projected["block_reason"] == "native_chi_contact_clone_incomplete"
    assert projected["page_patch"]["f_rch_name_en"] == "Proposed Name"
    assert projected["page_patch"]["f_licence_capacity"] == 90
    assert projected["page_patch"]["f_service_type"] == "1"
    assert projected["page_patch"]["f_business_ownership_type"] == "2"
    assert projected["contact_updates"] == []


def test_contact_clone_wait_plan_only_retries_missing_home_backed_clone() -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    from revise_nocobase_chi_page_projection import (  # noqa: WPS433
        CONTACT_CLONE_STILL_MISSING_SCRIPT,
        CONTACT_CLONE_WAIT_PLAN_SCRIPT,
    )

    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const names = ['formData', 'companyContact', 'operatorContact', 'home',
  'homeCompanyContact', 'homePersonContacts'];
const result = new Function(...names, input.script)(...input.values);
process.stdout.write(JSON.stringify(result));
"""

    def evaluate(script: str, values: list[object]) -> dict:
        result = subprocess.run(
            [node, "-e", runner],
            input=json.dumps({"script": script, "values": values}),
            text=True,
            capture_output=True,
            check=True,
        )
        return json.loads(result.stdout)

    missing = [
        {"is_change_operator_or_operating_company": True,
         "part_3": {"company": {"company_name_en": "New"}}},
        {},
        [],
        {"f_home_contact_company": {"id": 600}},
        {"id": 600},
        [],
    ]
    assert evaluate(CONTACT_CLONE_WAIT_PLAN_SCRIPT, missing) == {"iterations": 5}
    assert evaluate(CONTACT_CLONE_STILL_MISSING_SCRIPT, missing) == {"missing": True}
    ready = list(missing)
    ready[1] = {"id": 601}
    assert evaluate(CONTACT_CLONE_WAIT_PLAN_SCRIPT, ready) == {"iterations": 0}
    assert evaluate(CONTACT_CLONE_STILL_MISSING_SCRIPT, ready) == {"missing": False}
    partial_persons = [
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {"operator": {"full_name_en": "Changed"}},
        },
        {},
        [{"id": 701}],
        {"f_home_contact_person": [{"id": 700}, {"id": 702}]},
        {},
        [{"id": 700}, {"id": 702}],
    ]
    assert evaluate(CONTACT_CLONE_WAIT_PLAN_SCRIPT, partial_persons) == {
        "iterations": 5
    }
    assert evaluate(CONTACT_CLONE_STILL_MISSING_SCRIPT, partial_persons) == {
        "missing": True
    }
    status_only = [
        {"is_change_operator_or_operating_company": True,
         "part_3": {"rch_business_status": "0"}},
        {},
        [],
        {"f_home_contact_company": {"id": 600}},
        {"id": 600},
        [],
    ]
    assert evaluate(CONTACT_CLONE_WAIT_PLAN_SCRIPT, status_only) == {"iterations": 0}


def test_partial_person_clone_fails_closed_before_selecting_wrong_contact() -> None:
    response = run(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "applicant_operator_type": "0",
                "operator": {"full_name_en": "Changed"},
            },
        },
        person_rows=[{"id": 701, "fk_licence_contact_person": 100}],
        home_people=[{"id": 700}, {"id": 702}],
    )
    assert response.returncode == 0, response.stderr
    result = json.loads(response.stdout)
    assert result["ready"] is False
    assert result["contact_pending"] is True
    assert result["block_reason"] == "native_chi_person_contact_clone_incomplete"
    assert result["contact_updates"] == []


def test_snapshot_wait_is_bounded_and_version_driven() -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    from revise_nocobase_chi_page_projection import (  # noqa: WPS433
        SNAPSHOT_STILL_PENDING_SCRIPT,
        SNAPSHOT_WAIT_PLAN_SCRIPT,
    )

    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const result = new Function('application', input.script)(input.application);
process.stdout.write(JSON.stringify(result));
"""

    def evaluate(script: str, application: object) -> dict:
        result = subprocess.run(
            [node, "-e", runner],
            input=json.dumps({"script": script, "application": application}),
            text=True,
            capture_output=True,
            check=True,
        )
        return json.loads(result.stdout)

    assert evaluate(SNAPSHOT_WAIT_PLAN_SCRIPT, None) == {"iterations": 5}
    assert evaluate(SNAPSHOT_STILL_PENDING_SCRIPT, {}) == {"pending": True}
    ready = {"f_source_home_snapshot_version": 1}
    assert evaluate(SNAPSHOT_WAIT_PLAN_SCRIPT, ready) == {"iterations": 0}
    assert evaluate(SNAPSHOT_STILL_PENDING_SCRIPT, ready) == {"pending": False}


def test_checklist_template_selection_prefers_chi_then_lowest_id() -> None:
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable")
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const result = new Function('templates', input.script)(input.templates);
process.stdout.write(JSON.stringify(result));
"""
    rows = [
        {"id": 40, "f_use_for": ["t_licence_app"]},
        {"id": 30, "f_use_for": ["t_change_home_information_app"]},
        {"id": 20, "f_use_for": ["t_change_home_information_app"]},
    ]
    result = subprocess.run(
        [node, "-e", runner],
        input=json.dumps(
            {"script": CHECKLIST_TEMPLATE_SELECT_SCRIPT, "templates": rows}
        ),
        text=True,
        capture_output=True,
        check=True,
    )
    assert json.loads(result.stdout)["id"] == 20

    nla_only = [
        {"id": 9, "f_use_for": ["t_licence_app"]},
        {"id": 4, "f_use_for": ["t_licence_app"]},
    ]
    result = subprocess.run(
        [node, "-e", runner],
        input=json.dumps(
            {"script": CHECKLIST_TEMPLATE_SELECT_SCRIPT, "templates": nla_only}
        ),
        text=True,
        capture_output=True,
        check=True,
    )
    assert json.loads(result.stdout)["id"] == 4
