"""Offline topology checks for the proposed CHI Staging revisions only."""

from __future__ import annotations

import copy
import sys
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from create_nocobase_phase_c_chi_workflows import (  # noqa: E402
    CREATE_TITLE,
    UPDATE_TITLE,
    query_config,
    ref,
    scope,
)
from revise_nocobase_chi_page_projection import (  # noqa: E402
    ALL_CHI_FIELDS,
    CHECKLIST_INPUT_FAIL_TITLE,
    CHECKLIST_INPUT_VALID_TITLE,
    CHECKLIST_INPUT_VALIDATE_TITLE,
    CHECKLIST_INPUT_VALIDATION_SCRIPT,
    CHECKLIST_PREFLIGHT_TITLE,
    CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE,
    CHECKLIST_TEMPLATE_SELECT_SCRIPT,
    CHECKLIST_TEMPLATE_SELECT_TITLE,
    CONTACT_CLONE_PENDING_TITLE,
    CONTACT_CLONE_RELOAD_PERSONS_TITLE,
    CONTACT_CLONE_WAIT_TITLE,
    LEGACY_PARENT_CREATE_ID_SCRIPT,
    LEGACY_POST_LOOP_VERIFY_SCRIPT,
    SAFE_PARENT_CREATE_ID_SCRIPT,
    SNAPSHOT_PAUSE_TITLE,
    SNAPSHOT_PENDING_TITLE,
    SNAPSHOT_PLAN_TITLE,
    SNAPSHOT_RECHECK_TITLE,
    SNAPSHOT_WAIT_TITLE,
    activate_validated_revision_pair,
    add_guarded_page_graph,
    chi_owned_company_query,
    draft_revision,
    ensure_deterministic_checklist_selector,
    ensure_intake_create_marker_field,
    ensure_parent_staging_field,
    ensure_snapshot_wait_graph,
    existing_guarded_draft,
    expected_chi_trigger_config,
    patch_disabled_checklist_preflight,
    patch_disabled_latest_relation,
    patch_disabled_post_loop_guard,
    patch_disabled_update_parent_lookup,
    prepare_disabled_safe_revisions,
    refresh_disabled_post_loop_script,
    repair_disabled_safe_revision,
    reusable_safe_candidate,
    validate_disabled_activation_candidate,
    validate_revision_graph,
)


class FakeApi:
    def __init__(self, workflow: dict) -> None:
        self.workflow = workflow
        self.next_id = max(
            (row.get("id", 0) for row in workflow.get("nodes") or []),
            default=5000,
        )
        self.next_id = max(self.next_id, 5000)

    def create_node(self, body: dict) -> dict:
        self.next_id += 1
        node = {
            "id": self.next_id,
            "key": f"mock{self.next_id}",
            "workflowId": body["workflowId"],
            "type": body["type"],
            "title": body["title"],
            "config": body["config"],
        }
        self.workflow["nodes"].append(node)
        return node

    def update_node(self, node_id: int, values: dict) -> dict:
        node = next(row for row in self.workflow["nodes"] if row["id"] == node_id)
        node.update(values)
        return node


def activation_fixture() -> tuple[dict[int, dict], list[int], list[int]]:
    rows: dict[int, dict] = {}
    old_ids: list[int] = []
    candidate_ids: list[int] = []
    for updating, old_id, candidate_id, key in (
        (False, 101, 201, "chi-create-key"),
        (True, 102, 202, "chi-update-key"),
    ):
        candidate = source(updating)
        add_guarded_page_graph(FakeApi(candidate), candidate, updating=updating)
        title = UPDATE_TITLE if updating else CREATE_TITLE
        trigger = expected_chi_trigger_config(updating=updating)
        candidate.update(
            {
                "id": candidate_id,
                "key": key,
                "title": title,
                "enabled": False,
                "executed": 0,
                "config": trigger,
            }
        )
        old = {
            "id": old_id,
            "key": key,
            "title": title,
            "type": "collection",
            "sync": False,
            "enabled": True,
            "executed": 7,
            "config": copy.deepcopy(trigger),
            "nodes": [],
        }
        rows[old_id] = old
        rows[candidate_id] = candidate
        old_ids.append(old_id)
        candidate_ids.append(candidate_id)
    return rows, old_ids, candidate_ids


class ActivationApi:
    def __init__(self, *, fail_enable_id: int | None = None) -> None:
        self.rows, self.old_ids, self.candidate_ids = activation_fixture()
        self.executions = {workflow_id: [] for workflow_id in self.rows}
        self.fail_enable_id = fail_enable_id

    def get_workflow(self, workflow_id: int) -> dict:
        return self.rows[workflow_id]

    def request(
        self, method: str, path: str, body: dict | None = None
    ) -> list[dict] | dict:
        if method == "GET" and path.startswith("/api/workflows:list?"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
            title = query.get("filter[title]", [""])[0]
            return [row for row in self.rows.values() if row["title"] == title]
        if method == "GET" and path.startswith("/api/executions:list?"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
            workflow_id = int(query["filter[workflowId]"][0])
            page = int(query.get("page", ["1"])[0])
            size = int(query.get("pageSize", ["100"])[0])
            start = (page - 1) * size
            return self.executions[workflow_id][start : start + size]
        if method == "POST" and path.startswith("/api/workflows:update?"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
            workflow_id = int(query["filterByTk"][0])
            assert body is not None and set(body) == {"enabled"}
            if body["enabled"] and workflow_id == self.fail_enable_id:
                raise RuntimeError("injected activation failure")
            self.rows[workflow_id]["enabled"] = body["enabled"]
            return self.rows[workflow_id]
        raise AssertionError((method, path, body))


class RepairApi(ActivationApi):
    def __init__(self, target_id: int) -> None:
        super().__init__()
        self.target_id = target_id
        self.next_id = max(
            int(row.get("id") or 0)
            for row in self.rows[target_id].get("nodes") or []
        )

    def create_node(self, body: dict) -> dict:
        assert int(body["workflowId"]) == self.target_id
        self.next_id += 1
        node = {
            "id": self.next_id,
            "key": f"repair{self.next_id}",
            "workflowId": self.target_id,
            "type": body["type"],
            "title": body["title"],
            "config": body["config"],
        }
        self.rows[self.target_id]["nodes"].append(node)
        return node

    def update_node(self, node_id: int, values: dict) -> dict:
        node = next(
            row
            for row in self.rows[self.target_id]["nodes"]
            if int(row["id"]) == int(node_id)
        )
        node.update(values)
        return node


def source(updating: bool) -> dict:
    common = [
        "Parse staged CHI update body" if updating else "Parse staged CHI request body",
        "Resolve linked CHI" if updating else "Find native-created CHI",
        "Linked CHI exists" if updating else "Native CHI exists",
        "Apply staged CHI update overlay"
        if updating
        else "Apply staged flags and overlay to native CHI",
        "Mark update succeeded + backfill IDs"
        if updating
        else "Apply Checklist files to native CHI records",
    ]
    if updating:
        common.append("Resolve original CREATE staging record")
    else:
        common.extend(
            [
                "Create Intake (fixed CHI type + Home Record)",
                "Apply submitter post to Intake",
                "Resolve checklist template by position_code",
                "Find native CHI checklist item",
                "Native CHI checklist item exists",
                "Update native CHI checklist item + files",
                "Create CHI checklist item + files",
                "Load Intake for native Submit",
            ]
        )
    nodes = []
    for number, title in enumerate(common, start=100):
        config = (
            {"variables": [{"key": "checklist"}]} if title.startswith("Parse") else {}
        )
        if title in (
            "Update native CHI checklist item + files",
            "Create CHI checklist item + files",
        ):
            config = {
                "params": {
                    "values": {
                        "f_lastest_files": [123],
                        "f_is_checked": True,
                    }
                }
            }
        if title.startswith("Apply staged"):
            config = {"params": {"values": {"f_rch_name_en": "old-ref"}}}
        if title == "Resolve original CREATE staging record":
            config = {
                "params": {
                    "filter": {
                        "$and": [
                            {"id": {"$eq": "original-ref"}},
                            {"f_application_status": {"$eq": "Submitted"}},
                        ]
                    }
                }
            }
        nodes.append(
            {
                "id": number,
                "key": f"mock{number}",
                "title": title,
                "type": "update",
                "config": config,
            }
        )
    return {
        "id": 4999,
        "type": "collection",
        "sync": False,
        "enabled": False,
        "executed": 0,
        "config": expected_chi_trigger_config(updating=updating),
        "nodes": nodes,
    }


def test_create_revision_targets_chi_owned_rows_and_logs_details_first() -> None:
    workflow = source(False)
    add_guarded_page_graph(FakeApi(workflow), workflow, updating=False)
    validate_revision_graph(workflow, updating=False)
    nodes = {row["title"]: row for row in workflow["nodes"]}
    assert set(
        nodes["Apply staged flags and overlay to native CHI"]["config"]["params"][
            "values"
        ]
    ) == set(ALL_CHI_FIELDS)
    assert (
        nodes["Apply staged flags and overlay to native CHI"]["upstreamId"]
        == (nodes["CHI snapshot and owner guards pass"]["id"])
    )
    early = nodes["Backfill OP CHI Intake ID before bridge"]
    assert early["upstreamId"] == nodes[
        "Create Intake (fixed CHI type + Home Record)"]["id"]
    assert nodes["Apply submitter post to Intake"]["upstreamId"] == early["id"]
    assert early["config"]["collection"] == "t_api_request_staging"
    assert set(early["config"]["params"]["values"]) == {"f_intake_id"}
    assert early["config"]["params"]["individualHooks"] is False
    assert nodes["Create Intake (fixed CHI type + Home Record)"]["config"][
        "params"
    ]["values"]["f_api_create_staging_id"] == "{{$context.data.id}}"
    assert nodes["Update CHI-owned address only"]["config"]["collection"] == "t_address"
    assert (
        nodes["Update CHI-owned address only"]["upstreamId"]
        == (nodes["Apply proposed CHI address"]["id"])
    )
    address_filter = nodes["Update CHI-owned address only"]["config"]["params"][
        "filter"
    ]
    assert "$scopes." in address_filter["$and"][0]["id"]["$eq"]
    assert "0" not in address_filter["$and"][0]["id"]["$eq"].split("item.")[-1]
    assert (
        nodes["Create CHI Checklist upload Details"]["upstreamId"]
        == (nodes["Update native CHI checklist item + files"]["id"])
    )
    assert (
        nodes["Refresh existing CHI Latest"]["upstreamId"]
        == (nodes["Create CHI Checklist upload Details"]["id"])
    )
    for title in ("Refresh existing CHI Latest", "Refresh new CHI Latest"):
        assert nodes[title]["config"]["params"]["individualHooks"] is True
    assert nodes["Load Intake for native Submit"]["upstreamId"] == (
        nodes["CHI Checklist and projection succeeded"]["id"]
    )
    assert nodes["Reload CHI staging after Checklist"]["upstreamId"] == (
        nodes[CONTACT_CLONE_PENDING_TITLE]["id"]
    )
    assert nodes["Reload CHI staging after Checklist"]["branchIndex"] == 0
    assert nodes[CONTACT_CLONE_PENDING_TITLE]["branchIndex"] == 1
    assert nodes["Mark CHI operator clone failed"]["branchIndex"] == 1
    assert nodes[CONTACT_CLONE_WAIT_TITLE]["config"]["condition"]["checkpoint"] == 1
    assert nodes[CONTACT_CLONE_WAIT_TITLE]["config"]["target"].endswith(
        ".iterations}}"
    )
    snapshot_plan = nodes[SNAPSHOT_PLAN_TITLE]
    snapshot_wait = nodes[SNAPSHOT_WAIT_TITLE]
    snapshot_pause = nodes[SNAPSHOT_PAUSE_TITLE]
    snapshot_recheck = nodes[SNAPSHOT_RECHECK_TITLE]
    snapshot_pending = nodes[SNAPSHOT_PENDING_TITLE]
    native_exists = nodes["Native CHI exists"]
    refresh = nodes["Reload CHI after native snapshot"]
    assert snapshot_plan["upstreamId"] == native_exists["id"]
    assert snapshot_plan["branchIndex"] == 1
    assert snapshot_wait["upstreamId"] == snapshot_plan["id"]
    assert snapshot_pause["upstreamId"] == snapshot_wait["id"]
    assert snapshot_pause["branchIndex"] == 0
    assert snapshot_recheck["upstreamId"] == snapshot_pause["id"]
    assert snapshot_pending["upstreamId"] == snapshot_recheck["id"]
    assert refresh["upstreamId"] == snapshot_wait["id"]
    assert snapshot_wait["config"]["condition"]["checkpoint"] == 1
    assert nodes["Load CHI company child records"]["config"] == chi_owned_company_query(
        refresh
    )
    projection_args = {
        item["name"]: item["value"]
        for item in nodes["Project guarded CHI page changes"]["config"]["arguments"]
    }
    assert projection_args["companyContact"] == ref(
        nodes["Reload CHI company after clone wait"]
    )
    assert projection_args["operatorContact"] == ref(
        nodes["Reload CHI persons after clone wait"]
    )
    assert nodes["Plan CHI Checklist preflight IDs"]["upstreamId"] == (
        nodes[CONTACT_CLONE_RELOAD_PERSONS_TITLE]["id"]
    )
    template_candidates = nodes["Resolve checklist template by position_code"]
    selected_template = nodes[CHECKLIST_TEMPLATE_SELECT_CREATE_TITLE]
    assert template_candidates["config"]["multiple"] is True
    assert template_candidates["config"]["params"]["sort"] == [
        {"field": "id", "direction": "asc"}
    ]
    assert {
        "f_office_code": {
            "$eq": ref(nodes["Reload CHI after native snapshot"], "f_office_cd")
        }
    } in template_candidates["config"]["params"]["filter"]["$and"]
    assert selected_template["upstreamId"] == template_candidates["id"]
    assert nodes["Find native CHI checklist item"]["config"]["params"]["filter"][
        "$and"
    ][1] == {"fk_document_checklist": {"$eq": ref(selected_template, "id")}}
    assert nodes["Create CHI checklist item + files"]["config"]["params"][
        "values"
    ]["fk_document_checklist"] == ref(selected_template, "id")
    assert nodes["Mark CHI Checklist code failed"]["branchIndex"] == 0
    assert nodes["Mark CHI Checklist upload failed"]["branchIndex"] == 0
    company_values = nodes["Create CHI-owned company"]["config"]["params"][
        "values"]
    assert "fk_licence_contact_company" in company_values
    assert "fk_licence_contact_person" not in company_values
    assert "f_rpop_op_app" in company_values
    assert nodes["Update CHI company registration child"]["config"][
        "collection"] == "t_rpop_op_app"
    assert nodes["Update CHI declaration detail 1"]["config"][
        "collection"] == "t_rpop_app_detail"
    assert "fk_rpop_app_detail1" in nodes[
        "Link CHI declaration detail 1 to contact"]["config"]["params"]["values"]
    assert "fk_rpop_app_detail_10" in nodes[
        "Link CHI declaration detail 10 to contact"]["config"]["params"]["values"]
    for row in workflow["nodes"]:
        if row["type"] == "update":
            assert row["config"].get("collection") != "t_home_record"
    original_checklist_values = nodes["Update native CHI checklist item + files"][
        "config"
    ]["params"]["values"]
    assert "f_lastest_files" not in original_checklist_values


def test_update_revision_preserves_partial_fields_and_creates_details() -> None:
    workflow = source(True)
    add_guarded_page_graph(FakeApi(workflow), workflow, updating=True)
    validate_revision_graph(workflow, updating=True)
    nodes = {row["title"]: row for row in workflow["nodes"]}
    patch = nodes["Apply staged CHI update overlay"]["config"]["params"]["values"]
    assert set(patch) == set(ALL_CHI_FIELDS)
    assert all("legacy_patch." in value for value in patch.values())
    assert (
        nodes["Create CHI Checklist upload Details"]["upstreamId"]
        == (nodes["Mark changed CHI item checked"]["id"])
    )
    assert (
        nodes["Refresh existing CHI Latest"]["upstreamId"]
        == (nodes["Create CHI Checklist upload Details"]["id"])
    )
    for title in ("Refresh existing CHI Latest", "Refresh new CHI Latest"):
        assert nodes[title]["config"]["params"]["individualHooks"] is True
    assert nodes["Mark update succeeded + backfill IDs"]["upstreamId"] == (
        nodes["CHI Checklist and projection succeeded"]["id"]
    )
    assert nodes["Resolve linked CHI"]["upstreamId"] == (
        nodes["CHI Update queue clear"]["id"]
    )
    assert nodes["Resolve linked CHI"]["branchIndex"] == 1
    assert nodes["Verify CHI Update parent create ID"]["upstreamId"] == (
        nodes["Resolve original CREATE staging record"]["id"]
    )
    assert nodes["Wait for earlier CHI Update to finish"]["config"][
        "target"
    ].endswith(".iterations}}")
    assert nodes["Wait for earlier CHI Update to finish"]["config"][
        "condition"
    ]["checkpoint"] == 1
    assert nodes["Pause between CHI Update queue checks"]["config"][
        "duration"
    ] == 2
    for title in (
        "Find lower pending CHI Update",
        "Recheck lower pending CHI Update",
        "Final lower pending CHI Update check",
    ):
        filters = nodes[title]["config"]["params"]["filter"]["$and"]
        assert {
            "f_parent_create_id": {"$eq": "{{$context.data.f_parent_create_id}}"}
        } in filters
        assert {"id": {"$lt": "{{$context.data.id}}"}} in filters
        assert {"f_status": {"$in": ["submitted", "processing"]}} in filters
    assert nodes["Mark CHI Update queue timeout failed"]["branchIndex"] == 0
    assert nodes["Mark CHI Update queue timeout failed"]["config"]["params"][
        "values"
    ] == {"f_status": "failed"}
    template_candidates = nodes["Resolve changed CHI Checklist position_code"]
    selected_template = nodes[CHECKLIST_TEMPLATE_SELECT_TITLE]
    assert template_candidates["config"]["multiple"] is True
    assert template_candidates["config"]["params"]["sort"] == [
        {"field": "id", "direction": "asc"}
    ]
    assert selected_template["upstreamId"] == template_candidates["id"]
    assert selected_template["config"]["content"] == CHECKLIST_TEMPLATE_SELECT_SCRIPT
    assert nodes["Changed CHI Checklist item exists"]["upstreamId"] == nodes[
        "Find changed CHI Checklist item"
    ]["id"]
    guarded_fail = nodes["Mark guarded CHI staging failed"]
    assert guarded_fail["config"]["collection"] == "t_api_request_staging"
    assert guarded_fail["branchIndex"] == 0
    assert nodes["Apply staged CHI update overlay"]["branchIndex"] == 1


def test_raw_checklist_guard_precedes_create_and_update_business_writes() -> None:
    for updating in (False, True):
        workflow = source(updating)
        add_guarded_page_graph(FakeApi(workflow), workflow, updating=updating)
        validate_revision_graph(workflow, updating=updating)
        nodes = {row["title"]: row for row in workflow["nodes"]}
        parse = nodes[
            "Parse staged CHI update body"
            if updating
            else "Parse staged CHI request body"
        ]
        validate = nodes[CHECKLIST_INPUT_VALIDATE_TITLE]
        valid = nodes[CHECKLIST_INPUT_VALID_TITLE]
        failed = nodes[CHECKLIST_INPUT_FAIL_TITLE]
        first_business_path = nodes[
            "Resolve original CREATE staging record"
            if updating
            else "Create Intake (fixed CHI type + Home Record)"
        ]

        assert parse["downstreamId"] == validate["id"]
        assert validate["upstreamId"] == parse["id"]
        assert validate["config"]["content"] == CHECKLIST_INPUT_VALIDATION_SCRIPT
        assert valid["upstreamId"] == validate["id"]
        assert failed["upstreamId"] == valid["id"]
        assert failed["branchIndex"] == 0
        assert failed["config"]["collection"] == "t_api_request_staging"
        assert failed["config"]["params"]["values"] == {
            "f_status": "failed",
            "f_error_message": ref(validate, "block_reason"),
        }
        assert first_business_path["upstreamId"] == valid["id"]
        assert first_business_path["branchIndex"] == 1


def test_revision_validation_rejects_tampered_top_level_trigger() -> None:
    from extend_nocobase_staging_relations import ApiError

    for updating in (False, True):
        baseline = source(updating)
        add_guarded_page_graph(FakeApi(baseline), baseline, updating=updating)
        mutations = []
        wrong_collection = copy.deepcopy(baseline)
        wrong_collection["config"]["collection"] = "t_change_home_information_app"
        mutations.append(wrong_collection)
        wrong_mode = copy.deepcopy(baseline)
        wrong_mode["config"]["mode"] = 2
        mutations.append(wrong_mode)
        wrong_type = copy.deepcopy(baseline)
        wrong_type["type"] = "schedule"
        mutations.append(wrong_type)
        wrong_sync = copy.deepcopy(baseline)
        wrong_sync["sync"] = True
        mutations.append(wrong_sync)
        wrong_api_type = copy.deepcopy(baseline)
        wrong_api_type["config"]["condition"]["$and"][3] = {
            "f_api_type": {"$eq": "tampered"}
        }
        mutations.append(wrong_api_type)
        missing_source_guard = copy.deepcopy(baseline)
        del missing_source_guard["config"]["condition"]["$and"][1]
        mutations.append(missing_source_guard)
        extra_trigger_key = copy.deepcopy(baseline)
        extra_trigger_key["config"]["unexpected"] = True
        mutations.append(extra_trigger_key)

        for workflow in mutations:
            try:
                validate_revision_graph(workflow, updating=updating)
            except ApiError as exc:
                assert "exact one-shot contract" in str(exc)
            else:
                raise AssertionError("Tampered CHI trigger must fail closed")


def test_legacy_update_selector_upgrade_uses_post_snapshot_application() -> None:
    workflow = source(True)
    api = FakeApi(workflow)
    add_guarded_page_graph(api, workflow, updating=True)
    nodes = {row["title"]: row for row in workflow["nodes"]}
    selector = nodes[CHECKLIST_TEMPLATE_SELECT_TITLE]
    loop = nodes["Apply changed CHI Checklist files"]
    candidates = nodes["Resolve changed CHI Checklist position_code"]
    linked = nodes["Resolve linked CHI"]
    snapshot = nodes["Reload CHI after native snapshot"]
    item = nodes["Find changed CHI Checklist item"]
    create_item = nodes["Create changed CHI item"]
    template_exists = nodes["CHI Checklist code exists"]

    # Reproduce the deployed legacy shape: one unsorted candidate query,
    # downstream nodes referring directly to it, and no selector Script.
    workflow["nodes"] = [row for row in workflow["nodes"] if row is not selector]
    candidates["config"] = query_config(
        "t_document_checklist",
        [
            {"f_position_code": {"$eq": scope(loop, "position_code")}},
            {"f_active": {"$eq": True}},
            {"f_item_type": {"$eq": "2"}},
            {
                "f_use_for": {
                    "$anyOf": [
                        "t_change_home_information_app",
                        "t_licence_app",
                    ]
                }
            },
        ],
    )
    candidates["downstreamId"] = template_exists["id"]
    template_exists["upstreamId"] = candidates["id"]
    item["config"] = query_config(
        "t_document_submitted_for_application",
        [
            {"f_business_key": {"$eq": ref(linked, "id")}},
            {"fk_document_checklist": {"$eq": ref(candidates, "id")}},
            {"f_business_type": {"$eq": "t_change_home_information_app"}},
        ],
    )
    create_item["config"]["params"]["values"]["fk_document_checklist"] = ref(
        candidates, "id"
    )

    ensure_deterministic_checklist_selector(api, workflow, updating=True)
    validate_revision_graph(workflow, updating=True)
    upgraded = {row["title"]: row for row in workflow["nodes"]}
    chosen = upgraded[CHECKLIST_TEMPLATE_SELECT_TITLE]
    filters = candidates["config"]["params"]["filter"]["$and"]
    assert {"f_office_code": {"$eq": ref(snapshot, "f_office_cd")}} in filters
    assert item["config"]["params"]["filter"]["$and"][0] == {
        "f_business_key": {"$eq": ref(snapshot, "id")}
    }
    assert create_item["config"]["params"]["values"][
        "fk_document_checklist"
    ] == ref(chosen, "id")


def test_update_queue_guard_cannot_be_removed_without_validation_failure() -> None:
    from extend_nocobase_staging_relations import ApiError

    workflow = source(True)
    add_guarded_page_graph(FakeApi(workflow), workflow, updating=True)
    linked = next(
        row for row in workflow["nodes"] if row["title"] == "Resolve linked CHI"
    )
    linked["upstreamId"] = 777
    try:
        validate_revision_graph(workflow, updating=True)
    except ApiError as exc:
        assert "stale application" in str(exc)
    else:
        raise AssertionError("Update graph must reject a CHI read before queue")


def test_update_snapshot_or_clone_failure_cannot_reach_business_writes() -> None:
    workflow = source(True)
    add_guarded_page_graph(FakeApi(workflow), workflow, updating=True)
    validate_revision_graph(workflow, updating=True)
    nodes = {row["title"]: row for row in workflow["nodes"]}

    ready = nodes["CHI snapshot and owner guards pass"]
    failed = nodes["Mark guarded CHI staging failed"]
    overlay = nodes["Apply staged CHI update overlay"]
    assert failed["upstreamId"] == ready["id"] and failed["branchIndex"] == 0
    assert failed["config"]["collection"] == "t_api_request_staging"
    assert set(failed["config"]["params"]["values"]) == {
        "f_status",
        "f_error_message",
        "f_application_id",
        "f_intake_id",
    }
    assert overlay["upstreamId"] == ready["id"] and overlay["branchIndex"] == 1
    assert nodes["Apply proposed CHI address"]["upstreamId"] == overlay["id"]
    assert nodes["Apply CHI-owned proposed contacts"]["upstreamId"] == nodes[
        "Apply proposed CHI address"
    ]["id"]
    assert nodes["Apply changed CHI Checklist files"]["upstreamId"] == nodes[
        "Apply CHI-owned proposed contacts"
    ]["id"]


def test_snapshot_wait_upgrade_reuses_legacy_delay_safely() -> None:
    workflow = source(True)
    api = FakeApi(workflow)
    add_guarded_page_graph(api, workflow, updating=True)
    nodes = {row["title"]: row for row in workflow["nodes"]}
    pause = nodes[SNAPSHOT_PAUSE_TITLE]
    exists = nodes["Linked CHI exists"]
    refresh = nodes["Reload CHI after native snapshot"]
    new_titles = {
        SNAPSHOT_PLAN_TITLE,
        SNAPSHOT_WAIT_TITLE,
        SNAPSHOT_PAUSE_TITLE,
        SNAPSHOT_RECHECK_TITLE,
        SNAPSHOT_PENDING_TITLE,
    }
    workflow["nodes"] = [
        row for row in workflow["nodes"] if row["title"] not in new_titles
    ]
    pause.update(
        {
            "title": "Wait briefly for native CHI snapshot",
            "upstreamId": exists["id"],
            "branchIndex": 1,
            "downstreamId": refresh["id"],
        }
    )
    workflow["nodes"].append(pause)
    refresh["upstreamId"] = pause["id"]

    ensure_snapshot_wait_graph(api, workflow, updating=True)
    validate_revision_graph(workflow, updating=True)
    upgraded = {row["title"]: row for row in workflow["nodes"]}
    assert upgraded[SNAPSHOT_PAUSE_TITLE]["id"] == pause["id"]
    assert "Wait briefly for native CHI snapshot" not in upgraded


def test_disabled_candidate_validation_is_read_only_and_execution_free() -> None:
    api = ActivationApi()
    candidate_id = api.candidate_ids[0]
    before = copy.deepcopy(api.rows)
    result = validate_disabled_activation_candidate(api, candidate_id)
    assert result["workflow"]["id"] == candidate_id
    assert result["execution_count"] == 0
    assert result["node_count"] > 0
    assert api.rows == before

    api.executions[candidate_id] = [{"id": 1}]
    try:
        validate_disabled_activation_candidate(api, candidate_id)
    except Exception as exc:
        assert "execution history" in str(exc)
    else:
        raise AssertionError("Executed CHI revision must not validate")


def test_disabled_candidate_validation_rejects_tampered_trigger_read_only() -> None:
    from extend_nocobase_staging_relations import ApiError

    api = ActivationApi()
    candidate_id = api.candidate_ids[0]
    api.rows[candidate_id]["config"]["condition"]["$and"][0] = {
        "f_status": {"$eq": "processing"}
    }
    before = copy.deepcopy(api.rows)
    try:
        validate_disabled_activation_candidate(api, candidate_id)
    except ApiError as exc:
        assert "exact one-shot contract" in str(exc)
    else:
        raise AssertionError("Tampered activation candidate must fail closed")
    assert api.rows == before
    assert all(api.rows[workflow_id]["enabled"] for workflow_id in api.old_ids)


def test_explicit_pair_activation_preserves_old_revisions_and_reads_back() -> None:
    api = ActivationApi()
    result = activate_validated_revision_pair(api, api.candidate_ids)
    assert {row["new_revision_id"] for row in result} == set(api.candidate_ids)
    assert all(not api.rows[workflow_id]["enabled"] for workflow_id in api.old_ids)
    assert all(
        api.rows[workflow_id]["enabled"] for workflow_id in api.candidate_ids
    )
    assert all(row["execution_count"] == 0 for row in result)
    assert all(row["node_count"] > 0 for row in result)


def test_pair_activation_failure_restores_both_old_active_revisions() -> None:
    api = ActivationApi(fail_enable_id=202)
    try:
        activate_validated_revision_pair(api, api.candidate_ids)
    except RuntimeError as exc:
        assert "injected activation failure" in str(exc)
    else:
        raise AssertionError("Injected activation failure must propagate")
    assert all(api.rows[workflow_id]["enabled"] for workflow_id in api.old_ids)
    assert all(
        not api.rows[workflow_id]["enabled"] for workflow_id in api.candidate_ids
    )


def test_safe_prepare_keeps_old_sources_active_and_returns_disabled_pair(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module

    api = ActivationApi()
    sources = [api.rows[workflow_id] for workflow_id in api.old_ids]
    drafts = [api.rows[workflow_id] for workflow_id in api.candidate_ids]
    monkeypatch.setattr(module, "source_summary", lambda _api: sources)
    monkeypatch.setattr(
        module, "ensure_staging_error_field", lambda _api, create_if_missing: {}
    )
    monkeypatch.setattr(
        module,
        "draft_revision",
        lambda _api, source_row: drafts[sources.index(source_row)],
    )
    monkeypatch.setattr(
        module,
        "patch_v07_adapt_revision",
        lambda _api, draft, updating: draft,
    )
    prepared = prepare_disabled_safe_revisions(api)
    assert [row["workflow"]["id"] for row in prepared] == api.candidate_ids
    assert all(api.rows[workflow_id]["enabled"] for workflow_id in api.old_ids)
    assert all(
        not api.rows[workflow_id]["enabled"] for workflow_id in api.candidate_ids
    )


def test_safe_prepare_candidate_reuse_is_unique_and_execution_free() -> None:
    from extend_nocobase_staging_relations import ApiError

    api = ActivationApi()
    create_source = api.rows[api.old_ids[0]]
    reused = reusable_safe_candidate(api, create_source, updating=False)
    assert reused is not None and reused["id"] == api.candidate_ids[0]

    duplicate = copy.deepcopy(reused)
    duplicate["id"] = 203
    api.rows[203] = duplicate
    api.executions[203] = []
    try:
        reusable_safe_candidate(api, create_source, updating=False)
    except ApiError as exc:
        assert "Multiple reusable" in str(exc)
    else:
        raise AssertionError("Multiple safe candidates must fail closed")

    del api.rows[203]
    del api.executions[203]
    api.executions[api.candidate_ids[0]] = [{"id": 1}]
    try:
        reusable_safe_candidate(api, create_source, updating=False)
    except ApiError as exc:
        assert "execution history" in str(exc)
    else:
        raise AssertionError("Executed safe candidate must not be reused")


def test_safe_candidate_ignores_older_partial_revision_history() -> None:
    api = ActivationApi()
    create_source = api.rows[api.old_ids[0]]
    expected = api.rows[api.candidate_ids[0]]
    historical = copy.deepcopy(expected)
    historical["id"] = int(create_source["id"]) - 1
    historical["nodes"] = [
        node
        for node in historical["nodes"]
        if node["title"] != SNAPSHOT_PLAN_TITLE
    ]
    api.rows[historical["id"]] = historical
    api.executions[historical["id"]] = []

    reused = reusable_safe_candidate(api, create_source, updating=False)
    assert reused is expected


def test_safe_candidate_rejects_newer_partial_or_tampered_revision() -> None:
    from extend_nocobase_staging_relations import ApiError

    partial_api = ActivationApi()
    create_source = partial_api.rows[partial_api.old_ids[0]]
    partial = copy.deepcopy(partial_api.rows[partial_api.candidate_ids[0]])
    partial["id"] = max(partial_api.rows) + 1
    partial["nodes"] = [
        node for node in partial["nodes"]
        if node["title"] != SNAPSHOT_PLAN_TITLE
    ]
    partial_api.rows[partial["id"]] = partial
    partial_api.executions[partial["id"]] = []
    try:
        reusable_safe_candidate(partial_api, create_source, updating=False)
    except ApiError as exc:
        assert "Partially prepared" in str(exc)
    else:
        raise AssertionError("Newer partial safe candidate must fail closed")

    tampered_api = ActivationApi()
    create_source = tampered_api.rows[tampered_api.old_ids[0]]
    tampered = copy.deepcopy(tampered_api.rows[tampered_api.candidate_ids[0]])
    tampered["id"] = max(tampered_api.rows) + 1
    tampered["config"]["condition"]["$and"][3] = {
        "f_api_type": {"$eq": "tampered"}
    }
    tampered_api.rows[tampered["id"]] = tampered
    tampered_api.executions[tampered["id"]] = []
    try:
        reusable_safe_candidate(tampered_api, create_source, updating=False)
    except ApiError as exc:
        assert "trigger was tampered" in str(exc)
    else:
        raise AssertionError("Newer tampered safe candidate must fail closed")


def test_explicit_disabled_repair_reuses_id_and_never_activates() -> None:
    target_id = 202
    api = RepairApi(target_id)
    candidate = api.rows[target_id]
    candidate["nodes"] = [
        row
        for row in candidate["nodes"]
        if row["title"] != CHECKLIST_TEMPLATE_SELECT_TITLE
    ]
    before_old = {
        workflow_id: api.rows[workflow_id]["enabled"]
        for workflow_id in api.old_ids
    }

    result = repair_disabled_safe_revision(api, target_id)
    node_ids_after_first_repair = {
        row["id"] for row in result["workflow"]["nodes"]
    }
    repeated = repair_disabled_safe_revision(api, target_id)
    assert result["workflow"]["id"] == target_id
    assert result["workflow"]["enabled"] is False
    assert result["execution_count"] == 0
    assert repeated["workflow"]["id"] == target_id
    assert repeated["workflow"]["enabled"] is False
    assert {
        row["id"] for row in repeated["workflow"]["nodes"]
    } == node_ids_after_first_repair
    assert {row["title"] for row in result["workflow"]["nodes"]} >= {
        CHECKLIST_TEMPLATE_SELECT_TITLE,
        SNAPSHOT_PLAN_TITLE,
        CONTACT_CLONE_WAIT_TITLE,
    }
    assert {
        workflow_id: api.rows[workflow_id]["enabled"]
        for workflow_id in api.old_ids
    } == before_old


def test_explicit_disabled_repair_rejects_executed_candidate() -> None:
    target_id = 202
    api = RepairApi(target_id)
    api.executions[target_id] = [{"id": 1}]
    try:
        repair_disabled_safe_revision(api, target_id)
    except Exception as exc:
        assert "execution history" in str(exc)
    else:
        raise AssertionError("Executed candidate must not be repaired")


def test_revision_draft_restores_enabled_source_before_its_graph_is_edited() -> None:
    class RevisionApi:
        def __init__(self) -> None:
            self.rows = {
                100: {
                    "id": 100,
                    "key": "chi-staging",
                    "title": CREATE_TITLE,
                    "type": "collection",
                    "sync": False,
                    "config": expected_chi_trigger_config(updating=False),
                    "enabled": True,
                    "nodes": [],
                }
            }
            self.calls = []

        def request(self, method: str, path: str, body: dict) -> dict:
            self.calls.append((method, path, body))
            if "workflows:update" in path:
                self.rows[100]["enabled"] = body["enabled"]
                return self.rows[100]
            if "workflows:revision" in path:
                assert self.rows[100]["enabled"] is False
                self.rows[200] = copy.deepcopy(self.rows[100])
                self.rows[200]["id"] = 200
                self.rows[200]["enabled"] = False
                return self.rows[200]
            raise AssertionError(path)

        def get_workflow(self, workflow_id: int) -> dict:
            return self.rows[workflow_id]

    api = RevisionApi()
    draft = draft_revision(api, api.rows[100])
    assert draft["id"] == 200 and draft["enabled"] is False
    assert api.rows[100]["enabled"] is True
    assert [
        call[2].get("enabled") for call in api.calls if "workflows:update" in call[1]
    ] == [False, True]


def test_parent_staging_field_is_idempotent_and_rejects_conflicting_schema() -> None:
    from extend_nocobase_staging_relations import ApiError

    class FieldApi:
        def __init__(self, existing: dict | None = None) -> None:
            self.rows = [] if existing is None else [existing]
            self.creates = 0

        def request(self, method: str, path: str, body: dict | None = None) -> list:
            if method == "GET" and path.endswith("fields:list?pageSize=400"):
                return self.rows
            if method == "POST" and path.endswith("fields:create"):
                self.creates += 1
                assert body is not None
                self.rows.append(body)
                return self.rows
            raise AssertionError((method, path))

    api = FieldApi()
    field = ensure_parent_staging_field(api, create_if_missing=True)
    assert field["name"] == "f_parent_create_id"
    ensure_parent_staging_field(api, create_if_missing=True)
    assert api.creates == 1
    conflict = FieldApi({"name": "f_parent_create_id", "type": "integer"})
    try:
        ensure_parent_staging_field(conflict, create_if_missing=True)
    except ApiError as exc:
        assert "conflicts" in str(exc)
    else:
        raise AssertionError("Conflicting staging parent key must be rejected")
    assert conflict.creates == 0


def test_intake_provenance_field_is_additive_and_idempotent() -> None:
    class FieldApi:
        def __init__(self) -> None:
            self.rows = []
            self.creates = 0

        def request(self, method: str, path: str, body: dict | None = None) -> list:
            if method == "GET" and path.endswith("fields:list?pageSize=400"):
                assert "t_intake_form" in path
                return self.rows
            if method == "POST" and path.endswith("fields:create"):
                assert "t_intake_form" in path
                self.creates += 1
                assert body is not None
                self.rows.append(body)
                return self.rows
            raise AssertionError((method, path))

    api = FieldApi()
    ensure_intake_create_marker_field(api, create_if_missing=True)
    ensure_intake_create_marker_field(api, create_if_missing=True)
    assert api.creates == 1
    assert api.rows[0]["name"] == "f_api_create_staging_id"


def test_completed_guarded_draft_is_reused_and_partial_draft_fails_closed() -> None:
    from extend_nocobase_staging_relations import ApiError

    draft = source(True)
    add_guarded_page_graph(FakeApi(draft), draft, updating=True)
    draft.update(
        {
            "key": "chi-update-key",
            "title": UPDATE_TITLE,
            "enabled": False,
            "executed": 0,
        }
    )
    old = {
        "id": 100,
        "key": "chi-update-key",
        "title": UPDATE_TITLE,
        "enabled": True,
    }

    class DraftApi:
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET"
            if "workflows:list" in path:
                return [old, draft]
            assert "executions:list" in path
            return []

        def get_workflow(self, workflow_id: int) -> dict:
            assert workflow_id == draft["id"]
            return draft

    assert existing_guarded_draft(DraftApi(), old, updating=True) is draft
    draft["nodes"] = [
        node
        for node in draft["nodes"]
        if node["title"] != "CHI Update queue clear"
    ]
    try:
        existing_guarded_draft(DraftApi(), old, updating=True)
    except ApiError as exc:
        assert "incomplete" in str(exc)
    else:
        raise AssertionError("Partial guarded draft must block a new revision")


def test_executed_guarded_origin_reuses_only_editable_auto_revision() -> None:
    from extend_nocobase_staging_relations import ApiError

    draft = source(True)
    add_guarded_page_graph(FakeApi(draft), draft, updating=True)
    draft.update(
        {
            "key": "chi-update-key",
            "title": UPDATE_TITLE,
            "enabled": False,
            "executed": 0,
        }
    )
    origin = copy.deepcopy(draft)
    origin["id"] = 6001
    editable = copy.deepcopy(draft)
    editable["id"] = 6002
    old = {
        "id": 100,
        "key": "chi-update-key",
        "title": UPDATE_TITLE,
        "enabled": True,
    }

    class AutoRevisionApi:
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET"
            if "workflows:list" in path:
                return [old, origin, editable]
            assert "executions:list" in path
            return [{"id": 9001}] if str(origin["id"]) in path else []

        def get_workflow(self, workflow_id: int) -> dict:
            return origin if workflow_id == origin["id"] else editable

    api = AutoRevisionApi()
    assert existing_guarded_draft(api, old, updating=True) is editable
    editable["nodes"] = [
        node
        for node in editable["nodes"]
        if node["title"] != "CHI Update queue clear"
    ]
    try:
        existing_guarded_draft(api, old, updating=True)
    except ApiError as exc:
        assert "incomplete" in str(exc)
    else:
        raise AssertionError("Executed origin must not mask partial editable copy")


def test_update_parent_lookup_patch_repairs_only_disabled_editable_graph(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module

    draft = source(True)
    add_guarded_page_graph(FakeApi(draft), draft, updating=True)
    draft.update(
        {
            "key": "chi-update-key",
            "title": UPDATE_TITLE,
            "enabled": False,
            "executed": 0,
            "config": expected_chi_trigger_config(updating=True),
        }
    )
    old = {
        "id": 100,
        "key": "chi-update-key",
        "title": UPDATE_TITLE,
        "enabled": True,
        "config": expected_chi_trigger_config(updating=True),
    }
    monkeypatch.setattr(module, "source_summary", lambda api: [old])
    original = next(
        row for row in draft["nodes"]
        if row["title"] == "Resolve original CREATE staging record"
    )
    parent = next(
        row for row in draft["nodes"]
        if row["title"] == "Verify CHI Update parent create ID"
    )
    original["config"]["params"]["filter"]["$and"][1] = {
        "f_application_status": {"$eq": "Submitted"}
    }
    parent["config"]["content"] = LEGACY_PARENT_CREATE_ID_SCRIPT

    class PatchApi(FakeApi):
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET" and "executions:list" in path
            return []

        def get_workflow(self, workflow_id: int) -> dict:
            return old if workflow_id == old["id"] else draft

    api = PatchApi(draft)
    assert patch_disabled_update_parent_lookup(api, draft["id"]) is draft
    assert original["config"]["params"]["filter"]["$and"][1] == {
        "f_application_status": {"$eq": "Accepted"}
    }
    assert parent["config"]["content"] == SAFE_PARENT_CREATE_ID_SCRIPT
    assert old["enabled"] is True
    validate_revision_graph(draft, updating=True)

    class ExecutedApi(PatchApi):
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET" and "executions:list" in path
            return [{"id": 9001}]

    from extend_nocobase_staging_relations import ApiError

    try:
        patch_disabled_update_parent_lookup(ExecutedApi(draft), draft["id"])
    except ApiError as exc:
        assert "unexecuted disabled" in str(exc)
    else:
        raise AssertionError("Already executed UPDATE revision cannot be patched")


def test_checklist_preflight_patch_rebinds_both_missing_parse_variables(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module

    draft = source(True)
    add_guarded_page_graph(FakeApi(draft), draft, updating=True)
    draft.update(
        {
            "key": "chi-update-key",
            "title": UPDATE_TITLE,
            "enabled": False,
            "executed": 0,
            "config": expected_chi_trigger_config(updating=True),
        }
    )
    old = {
        "id": 100,
        "key": "chi-update-key",
        "title": UPDATE_TITLE,
        "enabled": True,
        "config": expected_chi_trigger_config(updating=True),
    }
    monkeypatch.setattr(module, "source_summary", lambda api: [old])
    by_title = {row["title"]: row for row in draft["nodes"]}
    plan = by_title[CHECKLIST_PREFLIGHT_TITLE]
    reload_persons = by_title[CONTACT_CLONE_RELOAD_PERSONS_TITLE]
    parse = by_title["Parse staged CHI update body"]
    catalog = by_title["Preflight CHI Checklist templates"]
    uploads = by_title["Preflight CHI Checklist upload IDs"]
    draft["nodes"] = [row for row in draft["nodes"] if row["id"] != plan["id"]]
    reload_persons["downstreamId"] = catalog["id"]
    catalog["upstreamId"] = reload_persons["id"]
    catalog["config"]["params"]["filter"]["$and"][0] = {
        "f_position_code": {"$in": ref(parse, "checklistPosition")}
    }
    uploads["config"]["params"]["filter"]["$and"] = [
        {"id": {"$in": ref(parse, "checklistAttachment")}}
    ]

    class PatchApi(FakeApi):
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET" and "executions:list" in path
            return []

        def get_workflow(self, workflow_id: int) -> dict:
            return old if workflow_id == old["id"] else draft

    api = PatchApi(draft)
    assert patch_disabled_checklist_preflight(api, draft["id"]) is draft
    validate_revision_graph(draft, updating=True)
    by_title = {row["title"]: row for row in draft["nodes"]}
    fixed_plan = by_title[CHECKLIST_PREFLIGHT_TITLE]
    assert catalog["upstreamId"] == fixed_plan["id"]
    assert {"f_position_code": {"$in": ref(fixed_plan, "position_codes")}} in (
        catalog["config"]["params"]["filter"]["$and"]
    )
    assert uploads["config"]["params"]["filter"]["$and"] == [
        {"id": {"$in": ref(fixed_plan, "attachment_ids")}}
    ]
    assert old["enabled"] is True


def test_latest_relation_patch_only_changes_disabled_unexecuted_updates(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module
    from extend_nocobase_staging_relations import ApiError

    for updating in (False, True):
        draft = source(updating)
        add_guarded_page_graph(FakeApi(draft), draft, updating=updating)
        draft.update(
            {
                "key": "chi-staging-key",
                "title": UPDATE_TITLE if updating else CREATE_TITLE,
                "enabled": False,
                "executed": 0,
                "config": expected_chi_trigger_config(updating=updating),
            }
        )
        old = {
            "id": 100,
            "key": "chi-staging-key",
            "title": draft["title"],
            "enabled": True,
            "config": expected_chi_trigger_config(updating=updating),
        }
        monkeypatch.setattr(module, "source_summary", lambda api: [old])
        latest_nodes = [
            row for row in draft["nodes"]
            if row["title"] in (
                "Refresh existing CHI Latest", "Refresh new CHI Latest"
            )
        ]
        for row in latest_nodes:
            row["config"]["params"]["individualHooks"] = False
        try:
            validate_revision_graph(draft, updating=updating)
        except ApiError as exc:
            assert "attachment association" in str(exc)
        else:
            raise AssertionError("Bulk Latest cannot pass graph validation")

        class PatchApi(FakeApi):
            def request(self, method: str, path: str) -> list[dict]:
                assert method == "GET" and "executions:list" in path
                return []

            def get_workflow(self, workflow_id: int) -> dict:
                return old if workflow_id == old["id"] else draft

        api = PatchApi(draft)
        assert patch_disabled_latest_relation(api, draft["id"]) is draft
        assert all(
            row["config"]["params"]["individualHooks"] is True
            for row in latest_nodes
        )
        assert patch_disabled_latest_relation(api, draft["id"]) is draft
        validate_revision_graph(draft, updating=updating)
        assert old["enabled"] is True

        class ExecutedApi(PatchApi):
            def request(self, method: str, path: str) -> list[dict]:
                return [{"id": 9001}]

        try:
            patch_disabled_latest_relation(ExecutedApi(draft), draft["id"])
        except ApiError as exc:
            assert "unexecuted disabled" in str(exc)
        else:
            raise AssertionError("Executed Latest revision must not be patched")


def test_post_loop_guard_patch_requires_disabled_complete_latest_graph(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module
    from extend_nocobase_staging_relations import ApiError

    guard_titles = {
        "Reload CHI Checklist associations after upload",
        "Verify CHI Checklist Latest and Details",
        "CHI Checklist associations saved",
        "Mark CHI Checklist association failed",
    }
    for updating in (False, True):
        draft = source(updating)
        add_guarded_page_graph(FakeApi(draft), draft, updating=updating)
        draft.update({
            "key": "chi-guard-key",
            "title": UPDATE_TITLE if updating else CREATE_TITLE,
            "enabled": False,
            "executed": 0,
            "config": expected_chi_trigger_config(updating=updating),
        })
        old = {
            "id": 100, "key": "chi-guard-key", "title": draft["title"],
            "enabled": True,
            "config": expected_chi_trigger_config(updating=updating),
        }
        monkeypatch.setattr(module, "source_summary", lambda api: [old])
        nodes = {row["title"]: row for row in draft["nodes"]}
        loop = nodes[
            "Apply changed CHI Checklist files" if updating
            else "Apply Checklist files to native CHI records"
        ]
        reload_stage = nodes["Reload CHI staging after Checklist"]
        draft["nodes"] = [
            row for row in draft["nodes"] if row["title"] not in guard_titles
        ]
        original_count = len(draft["nodes"])
        loop["downstreamId"] = reload_stage["id"]
        reload_stage["upstreamId"] = loop["id"]
        reload_stage["branchIndex"] = None

        class PatchApi(FakeApi):
            def request(self, method: str, path: str) -> list[dict]:
                assert method == "GET" and "executions:list" in path
                return []

            def get_workflow(self, workflow_id: int) -> dict:
                return old if workflow_id == old["id"] else draft

        api = PatchApi(draft)
        assert patch_disabled_post_loop_guard(api, draft["id"]) is draft
        assert len(draft["nodes"]) == original_count + 4
        validate_revision_graph(draft, updating=updating)
        nodes = {row["title"]: row for row in draft["nodes"]}
        assert nodes["Reload CHI staging after Checklist"]["upstreamId"] == (
            nodes[CONTACT_CLONE_PENDING_TITLE]["id"]
        )
        assert nodes["Reload CHI staging after Checklist"]["branchIndex"] == 0
        assert nodes["Mark CHI Checklist association failed"]["branchIndex"] == 0
        assert nodes[CONTACT_CLONE_PENDING_TITLE]["upstreamId"] == (
            nodes["CHI Checklist associations saved"]["id"]
        )
        assert nodes[CONTACT_CLONE_PENDING_TITLE]["branchIndex"] == 1
        assert nodes["Reload CHI Checklist associations after upload"]["config"][
            "params"
        ]["appends"] == ["f_lastest_files", "f_details", "f_details.f_files"]
        assert patch_disabled_post_loop_guard(api, draft["id"]) is draft
        assert old["enabled"] is True

        # A partial draft must not silently continue or create duplicate nodes.
        draft["nodes"] = [
            row for row in draft["nodes"]
            if row["title"] != "Verify CHI Checklist Latest and Details"
        ]
        try:
            patch_disabled_post_loop_guard(api, draft["id"])
        except ApiError as exc:
            assert "Partially patched" in str(exc)
        else:
            raise AssertionError("Partial readback graph must fail closed")


def test_disabled_update_verifier_js_refresh_fixes_unbound_optional_checklist(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module
    from extend_nocobase_staging_relations import ApiError

    draft = source(True)
    add_guarded_page_graph(FakeApi(draft), draft, updating=True)
    draft.update({
        "key": "chi-verifier-key", "title": UPDATE_TITLE,
        "enabled": False,
        "executed": 0,
        "config": expected_chi_trigger_config(updating=True),
    })
    old = {
        "id": 100, "key": "chi-verifier-key", "title": UPDATE_TITLE,
        "enabled": True,
        "config": expected_chi_trigger_config(updating=True),
    }
    monkeypatch.setattr(module, "source_summary", lambda api: [old])
    verify = next(
        node for node in draft["nodes"]
        if node["title"] == "Verify CHI Checklist Latest and Details"
    )
    verify["config"]["content"] = LEGACY_POST_LOOP_VERIFY_SCRIPT

    class PatchApi(FakeApi):
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET" and "executions:list" in path
            return []

        def get_workflow(self, workflow_id: int) -> dict:
            return old if workflow_id == old["id"] else draft

    api = PatchApi(draft)
    assert refresh_disabled_post_loop_script(api, draft["id"]) is draft
    assert verify["config"]["content"] == module.CHECKLIST_POST_LOOP_VERIFY_SCRIPT
    validate_revision_graph(draft, updating=True)
    assert refresh_disabled_post_loop_script(api, draft["id"]) is draft
    assert old["enabled"] is True
    verify["config"]["content"] = "unknown unreviewed JS"
    try:
        refresh_disabled_post_loop_script(api, draft["id"])
    except ApiError as exc:
        assert "differs" in str(exc)
    else:
        raise AssertionError("Unreviewed verifier JS must not be patched")


def test_disabled_create_verifier_js_refresh_keeps_original_source_enabled(
    monkeypatch,
) -> None:
    import revise_nocobase_chi_page_projection as module

    draft = source(False)
    add_guarded_page_graph(FakeApi(draft), draft, updating=False)
    draft.update({
        "key": "chi-create-verifier", "title": CREATE_TITLE,
        "enabled": False,
        "executed": 0,
        "config": expected_chi_trigger_config(updating=False),
    })
    old = {
        "id": 100, "key": "chi-create-verifier", "title": CREATE_TITLE,
        "enabled": True,
        "config": expected_chi_trigger_config(updating=False),
    }
    monkeypatch.setattr(module, "source_summary", lambda api: [old])
    verify = next(
        node for node in draft["nodes"]
        if node["title"] == "Verify CHI Checklist Latest and Details"
    )
    verify["config"]["content"] = LEGACY_POST_LOOP_VERIFY_SCRIPT

    class PatchApi(FakeApi):
        def request(self, method: str, path: str) -> list[dict]:
            assert method == "GET" and "executions:list" in path
            return []

        def get_workflow(self, workflow_id: int) -> dict:
            return old if workflow_id == old["id"] else draft

    api = PatchApi(draft)
    assert refresh_disabled_post_loop_script(api, draft["id"]) is draft
    assert verify["config"]["content"] == module.CHECKLIST_POST_LOOP_VERIFY_SCRIPT
    validate_revision_graph(draft, updating=False)
    assert old["enabled"] is True
