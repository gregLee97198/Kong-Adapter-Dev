"""Pure local checks for the CHI workflow's guarded JavaScript patches."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from upgrade_nocobase_chi_category_payloads import patch_script  # noqa: E402


def run_patch(form_data: dict, *, app: dict | None = None) -> dict:
    node = shutil.which("node")
    if node is None:
        pytest.skip("Node.js is not available")
    arguments = {
        "formData": form_data,
        "application": app or {
            "id": 100, "fk_rch_address": 200, "f_office_cd": "LORCHE",
            "f_rch_name_en": "Original", "f_licence_capacity": 30,
            "f_attachments_of_rchs": [{"id": 501}],
        },
        "mainAddress": {"id": 200, "f_fullname_en": "Old Address"},
        "addressOptions": [],
        "rchTypeOptions": [
            {"id": 10, "f_code": "a1", "f_for_office": "LORCHE"}
        ],
        "operatorContact": None,
        "companyContact": None,
    }
    runner = """
const input = JSON.parse(require('fs').readFileSync(0, 'utf8'));
const names = Object.keys(input.arguments);
const result = new Function(...names, input.script)(
  ...names.map(name => input.arguments[name]));
process.stdout.write(JSON.stringify(result));
"""
    result = subprocess.run(
        [node, "-e", runner],
        input=json.dumps({"script": patch_script(), "arguments": arguments}),
        text=True, capture_output=True, check=False,
    )
    if result.returncode:
        raise RuntimeError(result.stderr)
    return json.loads(result.stdout)


def test_all_chi_change_categories_patch_business_fields_but_not_address() -> None:
    result = run_patch(
        {
            "case_summary": {"office_code": "LORCHE"},
            "is_change_name": True,
            "is_change_address": True,
            "is_change_operator_or_operating_company": True,
            "is_change_rch_type": True,
            "is_change_maximum_capacity": True,
            "part_2": {
                "rch_name_en": "Changed", "rch_type_code": "a1",
                "max_capacity": 54,
                "address": {"full_name_en": "Changed Address"},
            },
            "part_3": {
                "operator": {"full_name_en": "Operator"},
                "company": {"company_name_en": "Care Limited"},
            },
        }
    )
    assert result["app_patch"]["f_rch_name_en"] == "Changed"
    assert result["app_patch"]["fk_type_of_rch"] == 10
    assert result["app_patch"]["f_licence_capacity"] == 54
    assert result["app_patch"]["is_change_address"] is True
    assert "address_updates" not in result
    assert len(result["contact_updates"]) == 2
    assert result["contact_updates"][0]["patch"]["fk_api_chi_change_operator"] == 100
    assert result["contact_updates"][1]["patch"]["fk_licence_contact_company"] == 100


def test_chi_common_patch_keeps_omitted_categories_and_files() -> None:
    result = run_patch({"part_5": {"comments": "Updated"}})
    assert result["app_patch"]["f_rch_name_en"] == "Original"
    assert result["app_patch"]["f_attachments_of_rchs"] == [501]
    assert "address_updates" not in result
    assert result["contact_updates"] == []
