"""Offline contract for the DEV NLA Send Letter v4 sidecar."""

from __future__ import annotations

import copy
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import complete_nocobase_nla_sent_letter_notice as target  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402


def node_eval(
    content: str, arguments: dict[str, Any], argument_names: list[str],
) -> dict[str, Any]:
    if shutil.which("node") is None:
        pytest.skip("Node.js is required for NocoBase JS workflow contract tests")
    js = (
        "const input=JSON.parse(require('fs').readFileSync(0,'utf8'));"
        "const fn=new Function(..." + json.dumps(argument_names) + ","
        + json.dumps(content) + ");"
        "process.stdout.write(JSON.stringify(fn(..."
        + json.dumps([arguments[name] for name in argument_names]) + ")));"
    )
    result = subprocess.run(
        ["node", "-e", js], capture_output=True, text=True, check=True,
        input="{}", timeout=10,
    )
    return json.loads(result.stdout)


def fixture(
    letter_type: str, *, native: int = 7, current: str = "Acknowledged",
    letter_id: int = 100, covers: list[dict[str, Any]] | None = None,
    licences: list[dict[str, Any]] | None = None,
    accounts: list[dict[str, Any]] | None = None,
    canonical: bool = True,
) -> dict[str, Any]:
    return {
        "letter": {
            "id": letter_id, "f_letter_type": letter_type,
            "f_business_key": 900, "f_is_send": True,
            "f_sendtime": "2026-10-08T01:00:00Z",
            "f_attachment": [{"id": 1415}],
        },
        "application": {
            "id": 900, "f_approval_status": native, "f_p_no": "PE0213",
            "f_intake_form": {"fk_intake_type": 111,
                              "f_intake_source_rch": {
                                  "f_rch_no": "E123", "f_rch_name_en": "Home"
                              }},
        },
        "canonicalRows": ([{
            "id": 800, "f_application_id": 900,
            "f_source_system": "OP", "f_request_event": "CREATE",
            "f_api_type": "create_intake_for_new_licence",
            "f_application_type": "new_licence",
            "f_application_status": current,
        }] if canonical else []),
        "coverLetters": covers or [],
        "licenceLetters": licences or [],
        "accountLetters": accounts or [],
    }


def plan(**kwargs: Any) -> dict[str, Any]:
    data = fixture(**kwargs)
    return node_eval(target.plan_script(), data, list(data))


def letter(letter_type: str, ident: int) -> dict[str, Any]:
    return fixture(letter_type, letter_id=ident)["letter"]


def test_a_remains_owned_by_approval_log_sync() -> None:
    assert plan(letter_type="a")["notices"] == []


def test_b_confirmation_notice_is_tied_to_canonical_create() -> None:
    response = plan(letter_type="b")
    assert response["ready"] is True
    assert response["statusName"] == "Confirmed"
    assert response["canonicalId"] == 800
    assert response["requiredLetterIds"] == ["100"]
    assert response["notices"][0]["attachmentIds"] == [1415]
    assert plan(letter_type="b", canonical=False)["ready"] is False


def test_d_reminder_requires_pending_initial_inspection() -> None:
    assert plan(letter_type="d", native=7, current="Acknowledged")["statusName"] \
        == "Reminding"
    assert plan(letter_type="d", native=7, current="Acknowledged")["ready"]
    assert plan(letter_type="d", native=7, current="Confirmed")["ready"]
    assert not plan(letter_type="d", native=8, current="Confirmed")["ready"]
    assert not plan(letter_type="d", native=7, current="Approved")["ready"]


def test_b_can_follow_reminding_without_reverting_to_acknowledged() -> None:
    response = plan(letter_type="b", current="Reminding")
    assert response["ready"]
    assert response["statusName"] == "Confirmed"


@pytest.mark.parametrize("last_type", ["c", "f"])
def test_approved_waits_for_both_real_sent_letters(last_type: str) -> None:
    first = letter("f" if last_type == "c" else "c", 201)
    second = letter(last_type, 202)
    first_data = fixture(
        first["f_letter_type"], current="Confirmed", letter_id=201,
        covers=[first] if first["f_letter_type"] == "c" else [],
        licences=[first] if first["f_letter_type"] == "f" else [],
    )
    first_response = node_eval(target.plan_script(), first_data, list(first_data))
    assert first_response["notices"] == []
    assert first_response["ready"] is False

    second_data = fixture(
        last_type, current="Confirmed", letter_id=202,
        covers=[first if first["f_letter_type"] == "c" else second],
        licences=[first if first["f_letter_type"] == "f" else second],
    )
    second_response = node_eval(target.plan_script(), second_data, list(second_data))
    assert second_response["ready"] is True
    assert second_response["statusName"] == "Approved"
    assert set(second_response["requiredLetterIds"]) == {"201", "202"}
    assert {item["letterType"] for item in second_response["notices"]} == {
        "c", "f"
    }


def test_e_is_deferred_until_cover_and_licence_pair() -> None:
    early = plan(letter_type="e", current="Confirmed")
    assert not early["ready"]
    data = fixture(
        "e", current="Approved", covers=[letter("c", 201)],
        licences=[letter("f", 202)], accounts=[letter("e", 203)],
        letter_id=203,
    )
    published = node_eval(target.plan_script(), data, list(data))
    assert published["ready"]
    assert {item["letterId"] for item in published["notices"]} == {
        201, 202, 203
    }


def test_approved_pair_can_follow_a_valid_reminder() -> None:
    data = fixture(
        "f", current="Reminding", letter_id=202,
        covers=[letter("c", 201)], licences=[letter("f", 202)],
    )
    planned = node_eval(target.plan_script(), data, list(data))
    assert planned["ready"]
    assert planned["statusName"] == "Approved"
    assert set(planned["requiredLetterIds"]) == {"201", "202"}


@pytest.mark.parametrize("native, expected", [(17, True), (2, True), (16, False)])
def test_closed_is_only_valid_after_native_closure_letter_stage(
    native: int, expected: bool,
) -> None:
    response = plan(
        letter_type=target.CANCELLATION_TYPE,
        native=native, current="Approved",
    )
    assert response["ready"] is expected
    assert response["statusName"] == ("Closed" if expected else "")


def test_unrecognized_nla_letter_cannot_default_to_received() -> None:
    response = plan(letter_type="unrecognized")
    assert not response["ready"]
    assert response["statusName"] == ""


def test_prevent_status_regression() -> None:
    assert not plan(letter_type="b", current="Approved")["ready"]
    assert not plan(letter_type="d", native=7, current="Approved")["ready"]


def test_canonical_identity_must_be_unique_and_exact() -> None:
    data = fixture("b")
    data["canonicalRows"].append(copy.deepcopy(data["canonicalRows"][0]))
    assert not node_eval(target.plan_script(), data, list(data))["ready"]
    data["canonicalRows"] = data["canonicalRows"][:1]
    data["canonicalRows"][0]["f_source_system"] = "CMTF"
    assert not node_eval(target.plan_script(), data, list(data))["ready"]


def test_a_timestamp_without_native_send_flag_is_not_a_sent_letter() -> None:
    data = fixture("b")
    data["letter"]["f_is_send"] = False
    assert not node_eval(target.plan_script(), data, list(data))["ready"]
    data["letter"]["f_is_send"] = True
    data["letter"]["f_sendtime"] = None
    assert not node_eval(target.plan_script(), data, list(data))["ready"]


def test_advance_only_after_all_notices_are_persisted() -> None:
    data = fixture("f", current="Confirmed")
    data["canonicalRows"][0]["f_application_status"] = "Confirmed"
    plan_row = {
        "canonicalId": 800, "businessId": 900, "statusName": "Approved",
        "requiredLetterIds": ["201", "202"],
        "notices": [
            {"letterId": 201, "letterType": "c", "dedupeKey": "nla:letter:201"},
            {"letterId": 202, "letterType": "f", "dedupeKey": "nla:letter:202"},
        ],
    }
    first = {
        "fk_api_request": 800, "f_business_record_id": 900,
        "f_third_party_name": "OP",
        "f_source_collection": "t_letter_attachment",
        "f_notice_type": "c", "fk_letter_attachment": 201,
        "fk_status": 7, "f_dedupe_key": "nla:letter:201",
        "f_source_event_id": "nla:letter:201",
        "f_source_workflow_key": target.SOURCE_KEY,
        "f_source_workflow_node": "Send Letter",
        "f_source_record_id": 201,
    }
    second = {**first, "f_notice_type": "f", "fk_letter_attachment": 202,
              "f_dedupe_key": "nla:letter:202",
              "f_source_event_id": "nla:letter:202",
              "f_source_record_id": 202}
    names = ["planned", "canonicalRows", "notices", "mappedStatus"]
    args = {"planned": plan_row, "canonicalRows": data["canonicalRows"],
            "notices": [first], "mappedStatus": {"id": 7}}
    assert not node_eval(target.advance_script(), args, names)["advance"]
    args["notices"].append(second)
    result = node_eval(target.advance_script(), args, names)
    assert result["advance"]
    assert result["priorStatus"] == "Confirmed"
    args["canonicalRows"][0]["f_application_status"] = "Reminding"
    assert node_eval(target.advance_script(), args, names)["advance"]
    args["notices"][1]["fk_api_request"] = 999
    assert not node_eval(target.advance_script(), args, names)["advance"]


def test_status_advance_matches_reminder_then_confirmation_sequence() -> None:
    row = {
        "fk_api_request": 800, "f_business_record_id": 900,
        "f_third_party_name": "OP",
        "f_source_collection": "t_letter_attachment",
        "f_notice_type": "d", "fk_letter_attachment": 201,
        "fk_status": 6, "f_dedupe_key": "nla:letter:201",
        "f_source_event_id": "nla:letter:201",
        "f_source_workflow_key": target.SOURCE_KEY,
        "f_source_workflow_node": "Send Letter",
        "f_source_record_id": 201,
    }
    args = {
        "planned": {
            "canonicalId": 800, "businessId": 900,
            "statusName": "Reminding", "requiredLetterIds": ["201"],
            "notices": [{"letterId": 201, "letterType": "d",
                         "dedupeKey": "nla:letter:201"}],
        },
        "canonicalRows": fixture(
            "d", current="Acknowledged"
        )["canonicalRows"],
        "notices": [row], "mappedStatus": {"id": 6},
    }
    names = ["planned", "canonicalRows", "notices", "mappedStatus"]
    assert node_eval(target.advance_script(), args, names)["advance"]
    args["canonicalRows"][0]["f_application_status"] = "Reminding"
    assert not node_eval(target.advance_script(), args, names)["advance"]
    args["planned"]["statusName"] = "Confirmed"
    args["planned"]["notices"][0]["letterType"] = "b"
    args["notices"][0]["f_notice_type"] = "b"
    args["notices"][0]["fk_status"] = 5
    args["mappedStatus"]["id"] = 5
    assert node_eval(target.advance_script(), args, names)["advance"]


def synthetic_candidate() -> tuple[dict[str, Any], dict[str, Any]]:
    original_titles = [
        target.ORIGINAL_START,
        "02 Record Each Sent Letter Once",
        "03 Resolve API Request Staging When Available",
        "04 Resolve NLA When Letter Belongs to NLA",
        "05 Resolve Home Record from Letter, Staging or NLA",
        "06 Build Staging-Optional Letter Notice",
        "06A Resolve Letter Notice status by name",
        "06B Letter Notice status exists",
        "07 Create Notice Board Letter Record",
    ]
    source = {
        "id": target.SOURCE_ID,
        "key": target.SOURCE_KEY,
        "title": target.SOURCE_TITLE,
        "type": "collection",
        "sync": False,
        "enabled": True,
        "config": {
            "mode": 2, "collection": "t_letter_attachment",
            "appends": ["f_attachment", "f_home_record", "f_senduser"],
            "changed": ["f_sendtime"],
            "condition": {"$and": [{"f_sendtime": {"$notEmpty": True}}]},
        },
        "nodes": [
            {
                "id": target.SOURCE_ID + index + 1,
                "key": f"v3_test_{index}",
                "title": title,
                "type": "query" if index != 1 else "condition",
                "workflowId": target.SOURCE_ID,
                "upstreamId": None,
                "downstreamId": None,
                "branchIndex": None,
                "config": {"params": {"pageSize": 1}} if index == 0 else {},
            }
            for index, title in enumerate(original_titles)
        ],
    }
    candidate = copy.deepcopy(source)
    candidate["id"] = source["id"] + 100000
    candidate["enabled"] = False
    candidate["config"] = target.required_candidate_config(source)
    for item in candidate["nodes"]:
        item["workflowId"] = candidate["id"]
    next_id = max(item["id"] for item in candidate["nodes"]) + 1
    for index, title in enumerate(target.ADDED_TITLES):
        candidate["nodes"].append({
            "id": next_id + index,
            "key": f"v4_test_{index}",
            "title": title,
            "type": target._node_kinds()[title],
            "workflowId": candidate["id"],
            "upstreamId": None,
            "downstreamId": None,
            "branchIndex": None,
            "config": {},
        })
    nodes = target.nodes_by_title(candidate)
    specs = target.node_specs(nodes)
    edges = target.expected_edges(source)
    for title, node in nodes.items():
        if title in specs:
            node["config"] = specs[title][1]
        upstream, downstream, branch = edges[title]
        node["upstreamId"] = nodes[upstream]["id"] if upstream else None
        node["downstreamId"] = nodes[downstream]["id"] if downstream else None
        node["branchIndex"] = branch
    candidate["nodes"] = list(nodes.values())
    return source, candidate


def test_exact_graph_preserves_all_non_nla_nodes_and_edges() -> None:
    source, candidate = synthetic_candidate()
    target.validate_candidate(source, candidate, complete=True)
    nodes = target.nodes_by_title(candidate)
    assert nodes[target.ORIGINAL_START]["branchIndex"] == 0
    gate = nodes[target.NLA_GATE]["config"]["calculation"]["group"]
    assert gate == {
        "type": "and",
        "calculations": [
            {
                "calculator": "gt",
                "operands": [target.ref(nodes[target.NLA_APP], "id"), 0],
            }
        ],
    }
    assert candidate["config"]["condition"]["$and"] == [
        {"f_sendtime": {"$notEmpty": True}},
        {"f_is_send": {"$eq": True}},
    ]
    assert candidate["config"]["changed"] == ["f_sendtime", "f_is_send"]
    changed = copy.deepcopy(candidate)
    target.nodes_by_title(changed)[target.ORIGINAL_START]["config"]["params"][
        "pageSize"
    ] = 5
    with pytest.raises(ApiError, match="Original v3 node modified"):
        target.validate_candidate(source, changed, complete=True)


def test_cas_is_scoped_to_canonical_create_and_disables_hooks() -> None:
    _, candidate = synthetic_candidate()
    config = target.node_specs(target.nodes_by_title(candidate))[target.ADVANCE][1]
    assert config["params"]["individualHooks"] is False
    conditions = config["params"]["filter"]["$and"]
    assert {"f_source_system": {"$eq": "OP"}} in conditions
    assert {"f_request_event": {"$eq": "CREATE"}} in conditions
    assert {"f_api_type": {"$eq": "create_intake_for_new_licence"}} in conditions
    assert {"f_application_type": {"$eq": "new_licence"}} in conditions
    assert any("f_application_status" in item for item in conditions)


def test_loop_child_uses_installed_nocobase_scope_syntax() -> None:
    _, candidate = synthetic_candidate()
    nodes = target.nodes_by_title(candidate)
    config = target.node_specs(nodes)[target.CREATE][1]
    expression = config["params"]["values"]["f_letter_attachment"]
    assert expression == (
        "{{$scopes." + nodes[target.LOOP]["key"] + ".item.letterId}}"
    )
    assert "scopesMapByNodeKey" not in expression


def test_existing_notice_lookup_is_global_per_letter_attachment() -> None:
    _, candidate = synthetic_candidate()
    nodes = target.nodes_by_title(candidate)
    config = target.node_specs(nodes)[target.EXISTING][1]
    filters = config["params"]["filter"]["$and"]
    assert filters == [{
        "fk_letter_attachment": {
            "$eq": target.scope(nodes[target.LOOP], "letterId")
        }
    }]


def test_v3_cover_plus_v4_licence_can_complete_approved_without_duplicate() -> None:
    sent_at = "2026-10-08T01:00:00Z"
    planned = {
        "canonicalId": 800, "businessId": 900, "statusName": "Approved",
        "requiredLetterIds": ["201", "202"],
        "notices": [
            {
                "letterId": 201, "letterType": "c",
                "dedupeKey": "nla:letter:201",
                "legacyDedupeKey": f"letter:sent:201:{sent_at}",
                "legacyEventId": f"201:{sent_at}",
            },
            {
                "letterId": 202, "letterType": "f",
                "dedupeKey": "nla:letter:202",
                "legacyDedupeKey": f"letter:sent:202:{sent_at}",
                "legacyEventId": f"202:{sent_at}",
            },
        ],
    }
    old_cover = {
        "fk_api_request": 800, "f_business_record_id": 900,
        "f_third_party_name": "OP", "f_notice_type": "c",
        "fk_letter_attachment": 201, "fk_status": 7,
        "f_source_collection": "t_letter_attachment",
        "f_source_record_id": 201,
        "f_source_workflow_key": "i1qob8kae1n",
        "f_source_workflow_node": "Send Letter",
        "f_source_event_id": f"201:{sent_at}",
        "f_dedupe_key": f"letter:sent:201:{sent_at}",
    }
    new_licence = {
        **old_cover,
        "f_notice_type": "f", "fk_letter_attachment": 202,
        "f_source_record_id": 202,
        "f_source_workflow_key": target.SOURCE_KEY,
        "f_source_event_id": "nla:letter:202",
        "f_dedupe_key": "nla:letter:202",
    }
    args = {
        "planned": planned,
        "canonicalRows": fixture("f", current="Confirmed")["canonicalRows"],
        "notices": [old_cover, new_licence],
        "mappedStatus": {"id": 7},
    }
    names = ["planned", "canonicalRows", "notices", "mappedStatus"]
    assert node_eval(target.advance_script(), args, names)["advance"]
    for changed_field, bad_value in (
        ("fk_api_request", 999),
        ("f_notice_type", "e"),
        ("fk_status", 5),
        ("f_source_event_id", "201:wrong-time"),
        ("f_source_workflow_key", "unknown"),
    ):
        bad = copy.deepcopy(args)
        bad["notices"][0][changed_field] = bad_value
        assert not node_eval(target.advance_script(), bad, names)["advance"]


class ToggleApi:
    """Model only the workflow enable/disable operations used in cutover."""

    def __init__(self, source: dict[str, Any], candidate: dict[str, Any]) -> None:
        self.workflows = {
            source["id"]: copy.deepcopy(source),
            candidate["id"]: copy.deepcopy(candidate),
        }
        self.fail_on_enable: int | None = None
        self.fail_enable_sequence: list[int] = []
        self.fail_after_commit = False
        self.writes: list[tuple[int, bool]] = []

    def get_workflow(self, workflow_id: int) -> dict[str, Any]:
        return copy.deepcopy(self.workflows[workflow_id])

    def request(
        self, method: str, path: str, body: dict[str, Any] | None = None,
    ) -> Any:
        if method == "GET" and path.startswith("/api/workflows:list?"):
            return [
                {"id": row["id"], "key": row["key"],
                 "enabled": row["enabled"]}
                for row in self.workflows.values()
            ]
        assert method == "POST" and path.startswith(
            "/api/workflows:update?filterByTk="
        )
        workflow_id = int(path.split("filterByTk=", 1)[1])
        assert body is not None and set(body) == {"enabled"}
        enabled = body["enabled"]
        self.writes.append((workflow_id, enabled))
        failed = enabled and (
            self.fail_on_enable == workflow_id
            or bool(self.fail_enable_sequence)
            and self.fail_enable_sequence[0] == workflow_id
        )
        if failed and self.fail_enable_sequence:
            assert self.fail_enable_sequence.pop(0) == workflow_id
        if failed and not self.fail_after_commit:
            self.fail_on_enable = None
            raise ApiError("simulated write failure")
        self.workflows[workflow_id]["enabled"] = enabled
        if failed:
            self.fail_on_enable = None
            raise ApiError("simulated response loss after commit")
        return {}


@pytest.fixture
def toggle_api(monkeypatch: pytest.MonkeyPatch) -> ToggleApi:
    source, candidate = synthetic_candidate()
    monkeypatch.setattr(target, "SOURCE_FINGERPRINT", target.source_fingerprint(source))
    return ToggleApi(source, candidate)


@pytest.mark.parametrize("after_commit", [False, True])
def test_failed_rollback_restores_reviewed_v4_without_double_enable(
    toggle_api: ToggleApi, after_commit: bool,
) -> None:
    candidate_id = next(
        workflow_id for workflow_id in toggle_api.workflows
        if workflow_id != target.SOURCE_ID
    )
    toggle_api.workflows[target.SOURCE_ID]["enabled"] = False
    toggle_api.workflows[candidate_id]["enabled"] = True
    toggle_api.fail_on_enable = target.SOURCE_ID
    toggle_api.fail_after_commit = after_commit
    with pytest.raises(ApiError, match="v4 restored"):
        target.rollback(toggle_api)  # type: ignore[arg-type]
    assert toggle_api.workflows[target.SOURCE_ID]["enabled"] is False
    assert toggle_api.workflows[candidate_id]["enabled"] is True


@pytest.mark.parametrize("after_commit", [False, True])
def test_failed_cutover_restores_v3_after_candidate_enable_failure(
    toggle_api: ToggleApi, monkeypatch: pytest.MonkeyPatch,
    after_commit: bool,
) -> None:
    candidate_id = next(
        workflow_id for workflow_id in toggle_api.workflows
        if workflow_id != target.SOURCE_ID
    )
    monkeypatch.setattr(target, "validate_schema", lambda *_args, **_kwargs: None)
    toggle_api.fail_on_enable = candidate_id
    toggle_api.fail_after_commit = after_commit
    with pytest.raises(ApiError, match="v3 restored"):
        target.cutover(toggle_api)  # type: ignore[arg-type]
    assert toggle_api.workflows[target.SOURCE_ID]["enabled"] is True
    assert toggle_api.workflows[candidate_id]["enabled"] is False


def test_failed_cutover_restores_v4_if_v3_recovery_also_fails(
    toggle_api: ToggleApi, monkeypatch: pytest.MonkeyPatch,
) -> None:
    candidate_id = next(
        workflow_id for workflow_id in toggle_api.workflows
        if workflow_id != target.SOURCE_ID
    )
    monkeypatch.setattr(target, "validate_schema", lambda *_args, **_kwargs: None)
    toggle_api.fail_enable_sequence = [candidate_id, target.SOURCE_ID]
    with pytest.raises(ApiError, match="reviewed v4 is active"):
        target.cutover(toggle_api)  # type: ignore[arg-type]
    assert toggle_api.fail_enable_sequence == []
    assert toggle_api.workflows[target.SOURCE_ID]["enabled"] is False
    assert toggle_api.workflows[candidate_id]["enabled"] is True
