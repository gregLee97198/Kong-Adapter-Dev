"""Accepted CREATE request_id semantics with an index-enforcing fake DB."""

from __future__ import annotations

import asyncio
from copy import deepcopy
from typing import Any

import pytest
from fastapi.testclient import TestClient

from app.create_idempotency import CreateIdempotencyService, _same_public_body
from app.errors import AdapterError
from app.main import _normalized_create_body, create_app
from app.models import (
    CreateIntakeForChangeHomeManagerRequest,
    CreateIntakeForNewLicenceRequest,
)
from tests.test_change_models import public_example
from tests.test_main import FakeAuthClient, settings, valid_new_licence_payload


class IndexedStaging:
    def __init__(self) -> None:
        self.rows: dict[tuple[str, str], dict[str, Any]] = {}
        self.legacy_rows: list[dict[str, Any]] = []
        self.attempts = 0
        self.ambiguous_first = False
        self._lock = asyncio.Lock()

    async def list_records(self, *, filters: dict[str, Any], **_kwargs: Any):
        conditions = filters["$and"]
        values = {
            key: condition["$eq"]
            for condition in conditions
            for key, condition in condition.items()
        }
        if "f_client_request_id" in values:
            key = (values["f_source_system"], values["f_client_request_id"])
            row = self.rows.get(key)
            return {"data": [deepcopy(row)] if row is not None else []}
        request_id = values["f_request_body.request_id"]
        matches = [
            row
            for row in [*self.rows.values(), *self.legacy_rows]
            if row.get("f_source_system") == values["f_source_system"]
            and row.get("f_request_event") == values["f_request_event"]
            and (row.get("f_request_body") or {}).get("request_id") == request_id
        ]
        return {"data": deepcopy(matches)}

    async def create_request_staging(self, *, values: dict[str, Any], **_kwargs: Any):
        async with self._lock:
            self.attempts += 1
            key = (values["f_source_system"], values["f_client_request_id"])
            if key in self.rows:
                raise AdapterError(409, "nocobase_request_rejected", "unique index")
            row = {"id": 100, **deepcopy(values)}
            self.rows[key] = row
            if self.ambiguous_first:
                self.ambiguous_first = False
                raise AdapterError(504, "upstream_timeout", "ambiguous commit")
            return {"id": row["id"]}


class NocoBaseNumericNormalizingStaging(IndexedStaging):
    async def create_request_staging(
        self, *, values: dict[str, Any], **kwargs: Any
    ) -> dict[str, Any]:
        result = await super().create_request_staging(values=values, **kwargs)
        body = self.rows[(values["f_source_system"], values["f_client_request_id"])][
            "f_request_body"
        ]
        part_2 = body["form_data"]["part_2"]
        for field in ("floor_area_sqm", "monthly_fee_min", "monthly_fee_max"):
            part_2[field] = int(part_2[field])
        return result


def _values(body: dict[str, Any]) -> dict[str, Any]:
    return {
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_application_type": "new_licence",
        "f_status": "submitted",
        "f_request_body": body,
    }


async def _create(
    service: CreateIdempotencyService,
    body: dict[str, Any],
    *,
    api_type: str = "create_intake_for_new_licence",
) -> dict[str, Any]:
    return await service.create_or_replay(
        token="client-token",
        transport_request_id="trace",
        client_request_id="NLA-1",
        create_api_type=api_type,
        application_type="new_licence",
        client_body=body,
        staging_values=_values(body),
    )


@pytest.mark.asyncio
async def test_concurrent_same_id_same_body_returns_one_original_create_id() -> None:
    backend = IndexedStaging()
    service = CreateIdempotencyService(backend, "OP")
    body = {"request_id": "NLA-1", "form_data": {"part_1": {"kind": "x"}}}
    first, second = await asyncio.gather(_create(service, body), _create(service, body))
    assert first["id"] == second["id"] == 100
    assert backend.attempts in {1, 2}
    assert len(backend.rows) == 1
    assert backend.rows[("OP", "NLA-1")]["f_client_request_id"] == "NLA-1"


@pytest.mark.asyncio
async def test_same_id_different_body_is_409_duplicate_request_id() -> None:
    backend = IndexedStaging()
    service = CreateIdempotencyService(backend, "OP")
    await _create(service, {"request_id": "NLA-1", "form_data": {"name": "A"}})
    with pytest.raises(AdapterError) as caught:
        await _create(service, {"request_id": "NLA-1", "form_data": {"name": "B"}})
    assert (caught.value.status_code, caught.value.code) == (
        409,
        "duplicate_request_id",
    )
    assert len(backend.rows) == 1


@pytest.mark.asyncio
async def test_exact_nla_body_replays_after_json_number_normalization() -> None:
    backend = NocoBaseNumericNormalizingStaging()
    service = CreateIdempotencyService(backend, "OP")
    sample = valid_new_licence_payload()
    sample["request_id"] = "NLA-1"
    sample["form_data"]["part_2"]["floor_area_sqm"] = 520
    body = _normalized_create_body(
        CreateIntakeForNewLicenceRequest.model_validate(sample), "new_licence"
    )
    first = await _create(service, body)
    replay = await _create(service, deepcopy(body))
    assert first == replay == {"id": 100}
    assert backend.attempts == 1
    persisted = backend.rows[("OP", "NLA-1")]["f_request_body"]
    assert _same_public_body(persisted, body)
    for field in ("floor_area_sqm", "monthly_fee_min", "monthly_fee_max"):
        assert isinstance(persisted["form_data"]["part_2"][field], int)
        assert isinstance(body["form_data"]["part_2"][field], float)

    changed = deepcopy(body)
    changed["form_data"]["part_2"]["monthly_fee_min"] += 1.0
    with pytest.raises(AdapterError) as caught:
        await _create(service, changed)
    assert (caught.value.status_code, caught.value.code) == (
        409, "duplicate_request_id"
    )
    assert backend.attempts == 1


def test_json_semantic_equality_keeps_non_numeric_types_strict() -> None:
    assert _same_public_body({"a": 12000.0}, {"a": 12000})
    assert _same_public_body({"a": [1.0, 2]}, {"a": [1, 2.0]})
    assert not _same_public_body({"a": True}, {"a": 1})
    assert not _same_public_body({"a": False}, {"a": 0.0})
    assert not _same_public_body({"a": None}, {"a": 0})
    assert not _same_public_body({"a": "1"}, {"a": 1})
    assert not _same_public_body({"a": [1, 2]}, {"a": [2, 1]})
    assert not _same_public_body({"a": 1}, {"a": 1, "b": None})
    assert not _same_public_body({"a": float("nan")}, {"a": float("nan")})
    assert not _same_public_body({"a": float("inf")}, {"a": float("inf")})


@pytest.mark.asyncio
async def test_concurrent_different_bodies_get_one_200_and_one_409() -> None:
    backend = IndexedStaging()
    service = CreateIdempotencyService(backend, "OP")
    results = await asyncio.gather(
        _create(service, {"request_id": "NLA-1", "form_data": {"name": "A"}}),
        _create(service, {"request_id": "NLA-1", "form_data": {"name": "B"}}),
        return_exceptions=True,
    )
    accepted = [result for result in results if isinstance(result, dict)]
    rejected = [result for result in results if isinstance(result, AdapterError)]
    assert len(accepted) == len(rejected) == 1
    assert accepted[0]["id"] == 100
    assert (rejected[0].status_code, rejected[0].code) == (
        409,
        "duplicate_request_id",
    )
    assert len(backend.rows) == 1


@pytest.mark.asyncio
async def test_same_id_different_create_api_is_409_even_with_same_body() -> None:
    backend = IndexedStaging()
    service = CreateIdempotencyService(backend, "OP")
    body = {"request_id": "NLA-1", "form_data": {"name": "A"}}
    await _create(service, body)
    with pytest.raises(AdapterError) as caught:
        await _create(service, body, api_type="create_licence_renewal")
    assert (caught.value.status_code, caught.value.code) == (
        409,
        "duplicate_request_id",
    )


@pytest.mark.asyncio
async def test_ambiguous_insert_commit_is_resolved_by_unique_key_readback() -> None:
    backend = IndexedStaging()
    backend.ambiguous_first = True
    service = CreateIdempotencyService(backend, "OP")
    body = {"request_id": "NLA-1", "form_data": {"name": "A"}}
    result = await _create(service, body)
    assert result["id"] == 100
    assert backend.attempts == 1


@pytest.mark.asyncio
async def test_ambiguous_insert_without_row_never_blindly_retries() -> None:
    backend = IndexedStaging()
    service = CreateIdempotencyService(backend, "OP")

    async def no_commit(**_kwargs: Any):
        raise AdapterError(504, "upstream_timeout", "ambiguous")

    backend.create_request_staging = no_commit  # type: ignore[method-assign]
    with pytest.raises(AdapterError) as caught:
        await _create(service, {"request_id": "NLA-1", "form_data": {}})
    assert (caught.value.status_code, caught.value.code) == (
        503,
        "create_idempotency_unconfirmed",
    )


def _legacy_row(
    row_id: int, body: dict[str, Any], *, status: str = "succeeded"
) -> dict[str, Any]:
    return {
        "id": row_id,
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_client_request_id": None,
        "f_api_type": "create_intake_for_new_licence",
        "f_application_type": "new_licence",
        "f_status": status,
        "f_request_body": body,
    }


@pytest.mark.asyncio
async def test_unique_legacy_create_replays_without_mutating_old_row() -> None:
    backend = IndexedStaging()
    body = {"request_id": "NLA-1", "form_data": {"name": "A"}}
    backend.legacy_rows.append(_legacy_row(71, body))
    service = CreateIdempotencyService(backend, "OP")
    existing = await service.find(
        token="client-token", transport_request_id="trace", client_request_id="NLA-1"
    )
    assert existing is not None and existing["id"] == 71
    assert (await _create(service, body))["id"] == 71
    assert backend.attempts == 0
    assert backend.legacy_rows[0]["f_client_request_id"] is None


@pytest.mark.asyncio
async def test_unique_legacy_create_with_changed_body_is_409() -> None:
    backend = IndexedStaging()
    backend.legacy_rows.append(
        _legacy_row(71, {"request_id": "NLA-1", "form_data": {"name": "A"}})
    )
    service = CreateIdempotencyService(backend, "OP")
    with pytest.raises(AdapterError) as caught:
        await _create(service, {"request_id": "NLA-1", "form_data": {"name": "B"}})
    assert (caught.value.status_code, caught.value.code) == (
        409,
        "duplicate_request_id",
    )
    assert backend.attempts == 0


@pytest.mark.asyncio
async def test_two_successful_legacy_creates_are_409_never_third_insert() -> None:
    backend = IndexedStaging()
    body = {"request_id": "NLA-1", "form_data": {"name": "A"}}
    backend.legacy_rows.extend((_legacy_row(71, body), _legacy_row(72, body)))
    service = CreateIdempotencyService(backend, "OP")
    with pytest.raises(AdapterError) as caught:
        await _create(service, body)
    assert (caught.value.status_code, caught.value.code) == (
        409,
        "duplicate_request_id",
    )
    assert backend.attempts == 0
    assert all(row["f_client_request_id"] is None for row in backend.legacy_rows)


@pytest.mark.asyncio
async def test_invalid_legacy_row_does_not_reserve_request_id() -> None:
    backend = IndexedStaging()
    body = {"request_id": "NLA-1", "form_data": {"name": "A"}}
    backend.legacy_rows.append(_legacy_row(71, body, status="invalid_request"))
    service = CreateIdempotencyService(backend, "OP")
    assert (await _create(service, body))["id"] == 100
    assert backend.attempts == 1


def test_server_derived_sh_snapshot_does_not_change_public_body_identity() -> None:
    backend = IndexedStaging()
    service = CreateIdempotencyService(backend, "OP")
    row = {
        "id": 100,
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_client_request_id": "SH-1",
        "f_api_type": "create_intake_for_specific_hour",
        "f_application_type": "specific_hour",
        "f_status": "succeeded",
        "f_request_body": {
            "request_id": "SH-1",
            "form_data": {
                "staffings": [{"code": "N", "_rule_snapshot": {"version": 1}}]
            },
        },
    }
    assert (
        service.replay_id(
            row,
            client_request_id="SH-1",
            create_api_type="create_intake_for_specific_hour",
            application_type="specific_hour",
            client_body={
                "request_id": "SH-1",
                "form_data": {"staffings": [{"code": "N"}]},
            },
        )
        == 100
    )


def test_nla_default_application_type_matches_persisted_body() -> None:
    original = valid_new_licence_payload()
    assert "application_type" not in original["form_data"]["part_1"]
    normalized = _normalized_create_body(
        CreateIntakeForNewLicenceRequest.model_validate(original), "new_licence"
    )
    assert normalized["form_data"]["part_1"]["application_type"] == "0"
    assert original["form_data"]["part_1"].get("application_type") is None


def test_change_create_replay_normalization_preserves_omitted_fields() -> None:
    original = public_example("mgr")
    model = CreateIntakeForChangeHomeManagerRequest.model_validate(original)
    normalized = _normalized_create_body(model, "change_home_manager")
    assert normalized == model.model_dump(mode="json", exclude_unset=True)
    assert set(normalized["form_data"]) == set(original["form_data"])


class RouteClient(FakeAuthClient):
    def __init__(self) -> None:
        super().__init__()
        self.indexed = IndexedStaging()

    async def list_records(self, **kwargs: Any) -> dict[str, Any]:
        if kwargs.get("collection") == "t_api_request_staging":
            return await self.indexed.list_records(**kwargs)
        return await super().list_records(**kwargs)

    async def create_request_staging(self, **kwargs: Any) -> dict[str, Any]:
        return await self.indexed.create_request_staging(**kwargs)


@pytest.mark.parametrize("family", ["nla", "lrn"])
def test_public_create_replay_and_conflict_use_original_id(
    monkeypatch: pytest.MonkeyPatch, family: str
) -> None:
    monkeypatch.setenv("CREATE_IDEMPOTENCY_INDEX_READY", "1")
    application = create_app(settings())
    fake = RouteClient()
    if family == "nla":
        path = "/v1/create_intake_for_new_licence"
        payload = valid_new_licence_payload()
        changed = deepcopy(payload)
        changed["form_data"]["part_2"]["rch_name_en"] = "Different name"
    else:
        path = "/v1/create_licence_renewal"
        payload = {
            "request_id": "LRN-REPLAY-1",
            "form_data": {
                "case_summary": {"office_code": "LORCHE", "rch_no": "L0043"},
                "part_1": {"application_received_date": "2026-10-15"},
            },
        }
        changed = deepcopy(payload)
        changed["form_data"]["part_1"]["application_received_date"] = "2026-10-16"

    with TestClient(application) as client:
        application.state.client = fake
        application.state.create_idempotency_service = CreateIdempotencyService(
            fake, "OP"
        )
        headers = {"Authorization": "Bearer valid-client-token"}
        first = client.post(path, headers=headers, json=payload)
        replay = client.post(path, headers=headers, json=payload)
        conflict = client.post(path, headers=headers, json=changed)

    assert first.status_code == replay.status_code == 200
    assert first.json() == replay.json()
    assert first.json()["create_id"] == "100"
    assert conflict.status_code == 409
    assert conflict.json()["error"]["code"] == "duplicate_request_id"
    assert fake.indexed.attempts == 1
    assert len(fake.indexed.rows) == 1
