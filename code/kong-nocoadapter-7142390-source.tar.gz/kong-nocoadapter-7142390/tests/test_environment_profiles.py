from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import yaml

from scripts import manage_environment

ROOT = Path(__file__).parents[1]
ENVIRONMENTS = ROOT / "config" / "environments.yaml"


def _yaml(path: Path) -> dict[str, object]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def _env_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line and not line.startswith("#"):
            key, value = line.split("=", 1)
            values[key] = value
    return values


def test_environment_manifest_keeps_local_online_and_uat_separate() -> None:
    document = _yaml(ENVIRONMENTS)
    environments = document["environments"]

    local_test = environments["local_test"]
    assert local_test["runtime"] == "docker-compose"
    assert local_test["upstream"]["base_url"] == (
        "http://119.91.104.211:13001/cmtf2"
    )
    assert local_test["kong_config"] == "config/kong.local-test-dbless.yml"
    assert local_test["nocobase_config"] == "config/nocobase.local-test.yaml"

    online_test = environments["online_test"]
    assert online_test["runtime"] == "docker-compose"
    assert online_test["upstream"]["base_url"] == (
        "http://host.docker.internal:13000/cmtf2"
    )
    assert online_test["compose_expectations"] == {
        "project_name": "kong-dbless",
        "kong_image": "kong-3.93:20260924-r3",
        "adapter_image": "kong-3.93-adapter:20261008-r1",
        "https_bind": "0.0.0.0",
        "https_port": 443,
    }

    development = environments["development"]
    assert development["runtime"] == "docker-compose"
    assert development["upstream"]["base_url"] == (
        "http://119.91.104.211:13001/cmtf2"
    )
    assert development["kong_config"] == "config/kong.local-test-dbless.yml"
    assert development["nocobase_config"] == "config/nocobase.local-test.yaml"

    uat = environments["uat"]
    assert uat["runtime"] == "docker-compose"
    assert uat["upstream_env_file"] == ".env"
    assert uat["compose_env_file"] == ".env"
    assert uat["upstream"] == {"mode": "docker-direct"}
    assert uat["kong_config"] == "config/kong.uat-dbless.yml"
    example = (ROOT / "uat.env.example").read_text(encoding="utf-8")
    assert (
        "UAT_NOCOBASE_BASE_URL=http://change-me.invalid/cmtf2"
        in example
    )
    assert "NOCOBASE_CONFIG_TOKEN=" in example


def test_uat_docker_profiles_target_internal_upstreams() -> None:
    manifest = _yaml(ENVIRONMENTS)["environments"]["uat"]
    kong_path = ROOT / manifest["kong_config"]
    nocobase_path = ROOT / manifest["nocobase_config"]
    kong_text = kong_path.read_text(encoding="utf-8")
    nocobase_text = nocobase_path.read_text(encoding="utf-8")
    combined = f"{kong_text}\n{nocobase_text}"

    assert "cmtf2sit.swd.hksarg" not in combined
    assert "/cmtf2/v/api" not in combined
    assert "change-me.invalid" in combined

    kong = _yaml(kong_path)
    services = {service["name"]: service for service in kong["services"]}
    for name in manifest["kong_nocobase_services"]:
        service = services[name]
        assert service["protocol"] == "http"
        assert service["host"] == "change-me.invalid"
        assert service["port"] == 80
    assert services["nocobase-file-adapter-service"]["host"] == "kong-nocoadapter"


def test_uat_upstream_changes_from_one_env_file(tmp_path: Path, monkeypatch) -> None:
    (tmp_path / "config").mkdir()
    shutil.copy2(ENVIRONMENTS, tmp_path / "config/environments.yaml")
    (tmp_path / ".env").write_text(
        "UAT_NOCOBASE_BASE_URL=http://10.24.0.17:8081/cmtf2\n"
        "NOCOBASE_CONFIG_TOKEN=example-only\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(manage_environment, "ROOT", tmp_path)
    monkeypatch.setattr(
        manage_environment, "MANIFEST_PATH", tmp_path / "config/environments.yaml"
    )
    upstream = manage_environment._profile("uat")["upstream"]
    assert upstream["host"] == "10.24.0.17"
    assert upstream["port"] == 8081
    assert "namespace" not in upstream
    assert "service" not in upstream


def test_compose_defaults_use_current_development_profile() -> None:
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    assert (
        'CREATE_IDEMPOTENCY_INDEX_READY: "${CREATE_IDEMPOTENCY_INDEX_READY:-0}"'
        in compose
    )
    assert "${NOCOBASE_PROFILE_FILE:-./config/nocobase.local-test.yaml}" in compose
    assert (
        "${KONG_DECLARATIVE_CONFIG_FILE:-./config/kong.local-test-dbless.yml}"
        in compose
    )
    assert 'NOCOBASE_UPSTREAM_URL: "${NOCOBASE_UPSTREAM_URL:-}"' in compose
    assert (
        "${NOCOBASE_CONFIG_TOKEN_SOURCE_FILE:-./secrets/"
        "nocobase_config_token.local_test}" in compose
    )
    assert "${KONG_HTTP_PORT:-28000}:8000" in compose
    assert "${KONG_HTTPS_PORT:-28443}:8443" in compose
    assert "${KONG_ADMIN_PORT:-28001}:8001" in compose
    assert "${ADAPTER_CONTAINER_NAME:-kong-dbless-nocoadapter}" in compose
    assert "${KONG_CONTAINER_NAME:-kong-dbless-gateway}" in compose
    assert "${KONG_NETWORK_NAME:-kong-dbless-net}" in compose


def test_local_compose_ports_are_isolated_from_online_and_uat() -> None:
    expected_local_ports = {
        "KONG_HTTP_PORT": "28000",
        "KONG_HTTPS_PORT": "28443",
        "KONG_ADMIN_PORT": "28001",
    }
    for filename in ("compose.local-test.env", "compose.development.env"):
        values = _env_values(ROOT / "config" / filename)
        assert {
            key: values[key] for key in expected_local_ports
        } == expected_local_ports
        assert values["ADAPTER_CONTAINER_NAME"].startswith(
            values["COMPOSE_PROJECT_NAME"]
        )
        assert values["KONG_CONTAINER_NAME"].startswith(
            values["COMPOSE_PROJECT_NAME"]
        )
        assert values["KONG_NETWORK_NAME"].startswith(
            values["COMPOSE_PROJECT_NAME"]
        )

    online = _env_values(ROOT / "config" / "compose.online-test.env")
    assert online["KONG_HTTP_PORT"] == "18000"
    assert online["KONG_HTTPS_PORT"] == "443"
    assert online["KONG_ADMIN_PORT"] == "18001"

    uat_compose = (ROOT / "docker-compose.uat.yml").read_text(encoding="utf-8")
    assert '"0.0.0.0:18000:8000"' in uat_compose
    assert '"127.0.0.1:18001:8001"' in uat_compose


def test_environment_validator_accepts_deployable_profiles() -> None:
    for environment in ("local_test", "online_test", "development", "uat"):
        env = os.environ.copy()
        if environment == "uat":
            env["UAT_ENV_FILE"] = "uat.env.example"
        result = subprocess.run(
            [
                sys.executable,
                str(ROOT / "scripts" / "manage_environment.py"),
                "validate",
                environment,
            ],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
            env=env,
        )
        assert result.returncode == 0, result.stderr
        assert "validation=passed" in result.stdout


def test_production_profile_cannot_inherit_a_test_target() -> None:
    result = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts" / "manage_environment.py"),
            "validate",
            "production",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 2
    assert "environment is not deployable" in result.stderr


def test_local_test_kong_and_adapter_target_port_13001() -> None:
    document = _yaml(ENVIRONMENTS)
    profile = document["environments"]["local_test"]
    kong = _yaml(ROOT / profile["kong_config"])
    adapter = _yaml(ROOT / profile["nocobase_config"])
    services = {service["name"]: service for service in kong["services"]}
    auth = services["nocobase-adapter-auth-service"]

    assert auth["host"] == "kong-nocoadapter"
    assert auth["port"] == 8080
    assert "path" not in auth
    assert adapter["nocobase"]["api"]["auth_sign_in"] == "/api/auth:signIn"
    assert adapter["nocobase"]["base_url"] == (
        "http://119.91.104.211:13001/cmtf2"
    )


def test_development_and_local_test_share_the_same_code_and_target() -> None:
    environments = _yaml(ENVIRONMENTS)["environments"]
    development = environments["development"]
    local_test = environments["local_test"]

    for key in ("kong_config", "nocobase_config", "secret_file"):
        assert development[key] == local_test[key]
    assert development["upstream"] == local_test["upstream"]


def test_online_test_compose_exposes_current_adapter_on_public_https_443() -> None:
    values = _env_values(ROOT / "config/compose.online-test.env")

    assert values["COMPOSE_PROJECT_NAME"] == "kong-dbless"
    assert values["KONG_IMAGE"] == "kong-3.93:20260924-r3"
    assert values["ADAPTER_IMAGE"] == "kong-3.93-adapter:20261008-r1"
    assert values["NOCOBASE_UPSTREAM_URL"] == (
        "http://host.docker.internal:13000/cmtf2"
    )
    assert values["KONG_HTTPS_BIND"] == "0.0.0.0"
    assert values["KONG_HTTPS_PORT"] == "443"
    assert values["KONG_HTTP_BIND"] == "127.0.0.1"
    assert values["KONG_ADMIN_BIND"] == "127.0.0.1"


def test_local_test_kong_only_changes_the_native_upstream_target() -> None:
    online = _yaml(ROOT / "config/kong.211-dbless.yml")
    local = _yaml(ROOT / "config/kong.local-test-dbless.yml")
    online_auth = online["services"][0]
    local_auth = local["services"][0]

    normalized_local_auth = dict(local_auth)
    normalized_local_auth["host"] = online_auth["host"]
    normalized_local_auth["port"] = online_auth["port"]

    normalized_local = dict(local)
    normalized_local["services"] = [normalized_local_auth, *local["services"][1:]]
    assert normalized_local == online
