"""Offline safety tests for the narrow 13001 workflow cleanup executor."""

# ruff: noqa: E501

from __future__ import annotations

import copy
import json
import pathlib
import sys
import urllib.parse

import pytest

SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import execute_nocobase_unified_subflow_cleanup_13001 as target  # noqa: E402
import plan_nocobase_unified_subflow_cutover_cleanup_13001 as cleanup  # noqa: E402
import plan_nocobase_unified_subflow_dispatch_13001 as topology  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402

CATEGORY_ID = 380631923228672


def _manifest() -> dict:
    """Minimal local candidate evidence; graph proof is isolated below."""
    return {
        "environment": "13001",
        "migration_id": target.MIGRATION_ID,
        "architecture": topology.ARCHITECTURE,
        "candidates": {
            "parent": {
                "id": 900000,
                "key": "test-cleanup-parent",
                "title": "API Staging — unified multi-branch ingress [prepared multibranch-20261019]",
            },
            "children": {
                business.name: {
                    "id": 910000 + index,
                    "key": f"test-cleanup-child-{index}",
                    "title": f"API Staging — {business.title} unified CREATE/UPDATE child [prepared multibranch-20261019]",
                }
                for index, business in enumerate(topology.BUSINESSES, 1)
            },
        },
    }


class _FakeApi:
    """A root-client-shaped in-memory API; it never opens a network socket."""

    base_url = target.BASE_URL

    def __init__(self, manifest: dict) -> None:
        self.workflows: dict[int, dict] = {}
        self.executions: dict[int, list[dict]] = {}
        self.actions: list[tuple[str, int, dict]] = []
        self.fail_title_update: int | None = None
        self.fail_destroy: int | None = None
        self.null_workflows: set[int] = set()

        parent, children = target._active_target_specs(manifest)
        self._put_active(parent)
        for child in children:
            self._put_active(child)
        for candidate in target.DELETE_TARGETS:
            self.workflows[candidate.id] = {
                "id": candidate.id,
                "key": candidate.key,
                "title": candidate.title,
                "type": "collection",
                "enabled": False,
                "sync": False,
                "nodes": [],
                "categories": [{"id": CATEGORY_ID}],
            }
            self.executions[candidate.id] = []

        notice = cleanup.PRESERVE[0]
        self.workflows[notice.id] = {
            "id": notice.id,
            "key": notice.key,
            "title": notice.title,
            "type": "collection",
            "enabled": True,
            "sync": False,
            "nodes": [],
            "categories": [{"id": CATEGORY_ID}],
        }
        self.executions[notice.id] = []

        # These must survive even though they are API Suorce staging entries.
        for optional in cleanup.OPTIONAL_UNPUBLISHED:
            self.workflows[optional.id] = {
                "id": optional.id,
                "key": optional.key,
                "title": optional.title,
                "type": "collection",
                "enabled": True,
                "sync": False,
                "nodes": [],
                "categories": [{"id": CATEGORY_ID}],
            }
            self.executions[optional.id] = []

    def _put_active(self, item: dict) -> None:
        self.workflows[int(item["id"])] = {
            "id": int(item["id"]),
            "key": item["key"],
            "title": item["title"],
            "type": item["expected_type"],
            "enabled": True,
            "sync": item["expected_sync"],
            "nodes": [],
            "categories": [{"id": CATEGORY_ID}],
        }
        self.executions[int(item["id"])] = []

    def get_workflow(self, workflow_id: int) -> dict:
        try:
            return copy.deepcopy(self.workflows[workflow_id])
        except KeyError as exc:
            raise ApiError(f"HTTP 404 for workflow {workflow_id}") from exc

    def request(self, method: str, path: str, body=None):
        query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
        if method == "GET" and path.startswith("/api/workflowCategories:list?"):
            return [{"id": CATEGORY_ID, "title": topology.API_SOURCE_CATEGORY_TITLE}]
        if method == "GET" and path.startswith("/api/workflows:get?"):
            workflow_id = int(query["filterByTk"][0])
            if workflow_id in self.null_workflows:
                return None
            return self.get_workflow(workflow_id)
        if method == "GET" and path.startswith("/api/executions:list?"):
            return copy.deepcopy(self.executions[int(query["filter[workflowId]"][0])])
        if method == "POST" and path.startswith("/api/workflows:update?"):
            workflow_id = int(query["filterByTk"][0])
            values = dict(body or {})
            if workflow_id == self.fail_title_update:
                raise ApiError("simulated title update failure")
            self.workflows[workflow_id].update(copy.deepcopy(values))
            self.actions.append(("update", workflow_id, values))
            return copy.deepcopy(self.workflows[workflow_id])
        if method == "POST" and path.startswith("/api/workflows:destroy?"):
            workflow_id = int(query["filterByTk"][0])
            if workflow_id == self.fail_destroy:
                raise ApiError("simulated destroy failure")
            if workflow_id not in self.workflows:
                raise ApiError("HTTP 404 for destroy")
            del self.workflows[workflow_id]
            self.actions.append(("destroy", workflow_id, {}))
            return None
        raise AssertionError(f"unexpected API operation: {method} {path}")


def _topology_result(api: _FakeApi, manifest: dict) -> dict:
    parent_target, child_targets = target._active_target_specs(manifest)
    parent = target._read_workflow(api, int(parent_target["id"]))
    children = {
        child["business"]: target._read_workflow(api, int(child["id"]))
        for child in child_targets
    }
    return {
        "category_id": CATEGORY_ID,
        "parent": parent,
        "children": children,
        "target_parent": parent_target,
        "target_children": child_targets,
    }


@pytest.fixture
def isolated_topology(monkeypatch):
    """Keep executor tests focused on cleanup, not full graph construction."""
    manifest = _manifest()
    monkeypatch.setattr(target, "verify_active_topology", _topology_result)
    return manifest


def test_static_plan_is_hardlocked_to_exact_40_targets():
    plan = target.static_plan()

    assert plan["writes_remote"] is False
    assert plan["environment"] == "13001 only"
    assert plan["delete_count"] == 27
    assert len(plan["delete_ids"]) == 27
    assert not set(plan["delete_ids"]) & set(plan["preserved_notice_ids"])
    assert not set(plan["delete_ids"]) & set(plan["excluded_optional_ids"])
    assert target._clean_parent_title().endswith("Dispatcher")
    assert all("[" not in target._clean_child_title(item) for item in topology.BUSINESSES)


def test_preflight_refuses_a_running_or_queued_target_without_writes(isolated_topology):
    api = _FakeApi(isolated_topology)
    api.executions[target.DELETE_TARGETS[0].id] = [{"id": 77, "status": 0}]

    with pytest.raises(target.CleanupError, match="running or queued"):
        target.preflight(api, isolated_topology)
    assert api.actions == []


def test_exact_root_snapshot_has_only_40_targets_and_owner_only_files(tmp_path, isolated_topology):
    api = _FakeApi(isolated_topology)
    active_parent, active_children = target._active_target_specs(isolated_topology)
    backup_dir = target._export_fresh_backup(
        api,
        tmp_path / "exact",
        active_targets=[active_parent, *active_children],
    )

    value = target._validate_fresh_backup(
        backup_dir,
        active_targets=[active_parent, *active_children],
    )
    manifest = json.loads((backup_dir / "manifest.json").read_text(encoding="utf-8"))
    details = json.loads((backup_dir / "workflows.redacted.json").read_text(encoding="utf-8"))
    captured_ids = {int(item["id"]) for item in manifest["workflows"]}

    assert value["directory"] == str(backup_dir)
    assert manifest["workflow_count"] == 40
    assert len(captured_ids) == 40
    assert cleanup.PRESERVE[0].id not in captured_ids
    assert set(map(int, details["workflows"])) == captured_ids
    assert (backup_dir / "manifest.json").stat().st_mode & 0o777 == 0o600
    assert (backup_dir / "workflows.redacted.json").stat().st_mode & 0o777 == 0o600
    assert backup_dir.stat().st_mode & 0o777 == 0o700


def test_apply_renames_13_and_deletes_only_exact_27(tmp_path, isolated_topology):
    api = _FakeApi(isolated_topology)
    optional_before = {workflow_id: copy.deepcopy(api.workflows[workflow_id]) for workflow_id in target.OPTIONAL_IDS}
    notice_before = copy.deepcopy(api.workflows[cleanup.PRESERVE[0].id])

    result = target.apply_cleanup(
        api,
        output_root=tmp_path / "evidence",
        confirmation=target.CLEANUP_CONFIRM,
        admission_paused=target.ADMISSION_PAUSED_CONFIRM,
        manifest=isolated_topology,
    )

    parent, children = target._active_target_specs(isolated_topology)
    assert result["cleanup_complete"] is True
    assert result["renamed_count"] == 13
    assert result["deleted_count"] == 27
    assert {workflow_id for action, workflow_id, _ in api.actions if action == "destroy"} == {
        item.id for item in target.DELETE_TARGETS
    }
    assert [workflow_id for action, workflow_id, _ in api.actions if action == "update"] == [
        int(parent["id"]),
        *[int(child["id"]) for child in children],
    ]
    assert api.workflows[int(parent["id"])]["title"] == parent["clean_title"]
    assert all(api.workflows[int(item["id"])]["title"] == item["clean_title"] for item in children)
    assert api.workflows[cleanup.PRESERVE[0].id] == notice_before
    assert {workflow_id: api.workflows[workflow_id] for workflow_id in target.OPTIONAL_IDS} == optional_before
    checkpoint = pathlib.Path(result["checkpoint"])
    assert checkpoint.stat().st_mode & 0o777 == 0o600
    saved = json.loads(checkpoint.read_text(encoding="utf-8"))
    assert saved["phase"] == "cleanup_complete"
    assert "not implemented" in saved["rollback_guidance"]["automatic_rollback"]


def test_failed_rename_stops_before_deletion_and_never_auto_restores(tmp_path, isolated_topology):
    api = _FakeApi(isolated_topology)
    parent, _children = target._active_target_specs(isolated_topology)
    api.fail_title_update = int(parent["id"])

    with pytest.raises(target.CleanupError, match="title update failed"):
        target.apply_cleanup(
            api,
            output_root=tmp_path / "evidence",
            confirmation=target.CLEANUP_CONFIRM,
            admission_paused=target.ADMISSION_PAUSED_CONFIRM,
            manifest=isolated_topology,
        )

    assert not [action for action in api.actions if action[0] == "destroy"]
    assert api.workflows[int(parent["id"])]["title"] == parent["title"]


def test_apply_records_null_workflow_as_already_absent_after_preflight(
    tmp_path, isolated_topology, monkeypatch
):
    """13001 returns data:null rather than 404 for a concurrently removed row."""
    api = _FakeApi(isolated_topology)
    missing_id = target.DELETE_TARGETS[0].id
    original_preflight = target.preflight

    def preflight_then_remove(*args, **kwargs):
        result = original_preflight(*args, **kwargs)
        api.null_workflows.add(missing_id)
        return result

    monkeypatch.setattr(target, "preflight", preflight_then_remove)
    result = target.apply_cleanup(
        api,
        output_root=tmp_path / "evidence",
        confirmation=target.CLEANUP_CONFIRM,
        admission_paused=target.ADMISSION_PAUSED_CONFIRM,
        manifest=isolated_topology,
    )

    assert result["cleanup_complete"] is True
    assert result["retired_count"] == 27
    assert result["deleted_count"] == 26
    assert result["already_absent_ids"] == [missing_id]
    destroyed_ids = {workflow_id for action, workflow_id, _ in api.actions if action == "destroy"}
    assert missing_id not in destroyed_ids
    checkpoint = json.loads(pathlib.Path(result["checkpoint"]).read_text(encoding="utf-8"))
    assert any(
        event["action"] == "workflow_already_absent_after_preflight"
        and event["details"]["id"] == missing_id
        for event in checkpoint["events"]
    )


def test_resume_completes_a_reviewed_interrupted_run(
    tmp_path, isolated_topology, monkeypatch
):
    api = _FakeApi(isolated_topology)
    blocked_id = target.DELETE_TARGETS[0].id
    api.fail_destroy = blocked_id
    output_root = tmp_path / "evidence"
    monkeypatch.setattr(target, "CLEANUP_ROOT", output_root)

    with pytest.raises(target.CleanupError, match="deletion failed before commit"):
        target.apply_cleanup(
            api,
            output_root=output_root,
            confirmation=target.CLEANUP_CONFIRM,
            admission_paused=target.ADMISSION_PAUSED_CONFIRM,
            manifest=isolated_topology,
        )

    checkpoint = next(output_root.glob("*/checkpoint.json"))
    api.fail_destroy = None
    result = target.resume_cleanup(
        api,
        checkpoint_path=checkpoint,
        confirmation=target.CLEANUP_CONFIRM,
        admission_paused=target.ADMISSION_PAUSED_CONFIRM,
        manifest=isolated_topology,
    )

    assert result["cleanup_complete"] is True
    assert result["retired_count"] == 27
    assert result["deleted_count"] == 27
    saved = json.loads(pathlib.Path(result["checkpoint"]).read_text(encoding="utf-8"))
    assert saved["phase"] == "cleanup_complete"
    assert any(event["action"] == "resume_preflight_complete" for event in saved["events"])
