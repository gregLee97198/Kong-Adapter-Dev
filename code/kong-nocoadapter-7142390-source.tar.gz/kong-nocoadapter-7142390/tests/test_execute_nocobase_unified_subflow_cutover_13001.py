"""Offline contract tests for the reversible 13001 multibranch cutover."""

# ruff: noqa: E501

from __future__ import annotations

import copy
import json
import pathlib
import sys
import urllib.parse

import pytest

SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import execute_nocobase_unified_subflow_cutover_13001 as target  # noqa: E402
import plan_nocobase_unified_subflow_cutover_cleanup_13001 as cleanup  # noqa: E402
import plan_nocobase_unified_subflow_dispatch_13001 as topology  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402

CATEGORY_ID = 11


def _validation() -> dict:
    return {
        "writes_remote": False,
        "environment": "13001",
        "migration_id": target.MIGRATION_ID,
        "manifest": str(topology._manifest_path(target.MIGRATION_ID).resolve()),
        "topology_sha256": topology._topology_digest(),
        "source_snapshot_sha256": "a" * 64,
        "validated_disabled": True,
        "cutover_not_implemented": True,
        "sentinel": {
            "state": "passed",
            "evidence_sha256": "b" * 64,
            "parent_execution_delta": 1,
            "child_execution_delta": 1,
            "child_enable_state_at_cutover": "enabled",
        },
        "runtime_acceptance_prerequisites": {
            "created_by_id": "not_yet_tested",
            "op_role_mapping": "not_yet_tested",
            "direct_create_submitted_trigger": "not_yet_tested",
        },
        "runtime_acceptance_passed": False,
        "parent": {
            "id": 9001,
            "key": "parent-key",
            "title": "API Suorce — Unified API Staging ingress [multibranch-20261019]",
            "type": "collection",
            "enabled": False,
            "executed": 0,
            "router_type": "multi-conditions",
            "business_branch_count": 12,
            "collection_event_workflow_count": 1,
            "serial_condition_chain": False,
            "marker_write": False,
            "category": topology.API_SOURCE_CATEGORY_TITLE,
        },
        "children": {
            business.name: {
                "id": 9100 + index,
                "key": f"child-key-{index}",
                "title": f"API Suorce — {business.title} child [multibranch-20261019]",
                "business": business.name,
                "type": "custom-action",
                "enabled": False,
                "executed": 0,
                "router_type": "multi-conditions",
                "event_branches": ["CREATE", "UPDATE"],
                "marker_write": False,
                "category": topology.API_SOURCE_CATEGORY_TITLE,
            }
            for index, business in enumerate(topology.BUSINESSES)
        },
    }


def _write_validation(tmp_path: pathlib.Path, value: dict | None = None) -> pathlib.Path:
    path = tmp_path / "validated-disabled.json"
    path.write_text(json.dumps(value or _validation()), encoding="utf-8")
    return path


class _FakeApi:
    base_url = target.BASE_URL

    def __init__(self, validation: dict) -> None:
        self.workflows: dict[int, dict] = {}
        self.executions: dict[int, list[dict]] = {}
        self.transitions: list[tuple[int, bool]] = []
        self.fail_before: set[int] = set()
        self.fail_after: set[int] = set()

        for item in (*cleanup.PUBLIC_LEGACY, *cleanup.PRESERVE):
            # One historic update listener is expected to be dormant before
            # cutover; precise restore must retain that false state.
            enabled = item.id != 392475375632384
            self.workflows[item.id] = {
                "id": item.id,
                "key": item.key,
                "title": item.title,
                "type": "collection",
                "enabled": enabled,
                "nodes": [],
                "categories": [{"id": CATEGORY_ID}],
            }
            self.executions[item.id] = []

        self.workflows[validation["parent"]["id"]] = {
            "id": validation["parent"]["id"],
            "key": validation["parent"]["key"],
            "title": validation["parent"]["title"],
            "type": "collection",
            "enabled": False,
            "nodes": [],
            "categories": [{"id": CATEGORY_ID}],
        }
        self.executions[validation["parent"]["id"]] = []
        for child in validation["children"].values():
            self.workflows[child["id"]] = {
                "id": child["id"],
                "key": child["key"],
                "title": child["title"],
                "type": "custom-action",
                "enabled": False,
                "nodes": [],
                "categories": [{"id": CATEGORY_ID}],
            }
            self.executions[child["id"]] = []

    def get_workflow(self, workflow_id: int) -> dict:
        return copy.deepcopy(self.workflows[workflow_id])

    def request(self, method: str, path: str, body=None):
        if method == "GET" and path.startswith("/api/workflowCategories:list?"):
            return [{"id": CATEGORY_ID, "title": topology.API_SOURCE_CATEGORY_TITLE}]
        if method == "GET" and path.startswith("/api/workflows:get?"):
            query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
            workflow_id = int(query["filterByTk"][0])
            return copy.deepcopy(self.workflows[workflow_id])
        if method == "GET" and path.startswith("/api/executions:list?"):
            query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
            return copy.deepcopy(self.executions[int(query["filter[workflowId]"][0])])
        if method == "POST" and path.startswith("/api/workflows:update?"):
            query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
            workflow_id = int(query["filterByTk"][0])
            if workflow_id in self.fail_before:
                raise ApiError(f"simulated pre-commit failure {workflow_id}")
            self.workflows[workflow_id].update(copy.deepcopy(dict(body or {})))
            self.transitions.append((workflow_id, bool((body or {})["enabled"])))
            if workflow_id in self.fail_after:
                raise ApiError(f"simulated post-commit response loss {workflow_id}")
            return copy.deepcopy(self.workflows[workflow_id])
        raise AssertionError(f"unexpected API operation: {method} {path}")


@pytest.fixture
def validated(monkeypatch, tmp_path):
    value = _validation()
    monkeypatch.setattr(target.topology, "validate_preparation", lambda *_args, **_kwargs: copy.deepcopy(value))
    return value, _write_validation(tmp_path, value)


def test_static_plan_is_13001_only_multibranch_and_has_no_delete_path():
    plan = target.static_plan()

    assert plan["writes_remote"] is False
    assert plan["environment"] == "13001 only"
    assert "twelve direct business subflow branches" in plan["topology"]["parent"]
    assert "CREATE/UPDATE multi-conditions" in plan["topology"]["children"]
    assert plan["deletions"] == "not implemented"
    assert len(plan["preserve_ids"]) == 1
    assert {386591126388736, 386593907212288}.issubset(set(plan["excluded_ids"]))


def test_preflight_requires_saved_and_fresh_static_validation_to_agree(validated):
    value, evidence_path = validated
    api = _FakeApi(value)

    result = target.preflight(api, evidence_path)

    assert result["ready_for_explicit_cutover"] is True
    assert result["legacy_target_count"] == 25
    assert result["snapshot"]["executions"]["392438115532800"]["running"] == 0
    assert api.transitions == []


def test_preflight_rejects_serial_parent_even_if_a_saved_file_claims_it_is_valid(tmp_path):
    value = _validation()
    value["parent"]["serial_condition_chain"] = True
    path = _write_validation(tmp_path, value)

    with pytest.raises(target.CutoverError, match="parent evidence mismatch"):
        target._read_validation_file(path)


def test_preflight_blocks_an_active_legacy_execution_without_writes(validated):
    value, evidence_path = validated
    api = _FakeApi(value)
    api.executions[cleanup.PUBLIC_LEGACY[0].id] = [{"id": 7001, "status": 0}]

    with pytest.raises(target.CutoverError, match="running/queued"):
        target.preflight(api, evidence_path)
    assert api.transitions == []


def test_apply_uses_children_then_exact_legacy_then_single_parent(validated, tmp_path):
    value, evidence_path = validated
    api = _FakeApi(value)

    result = target.apply_cutover(
        api,
        evidence_path,
        output_root=tmp_path / "cutovers",
        confirmation=target.CUTOVER_CONFIRM,
        admission_paused=target.ADMISSION_PAUSED_CONFIRM,
    )

    assert result["cutover_complete"] is True
    assert result["deletions"] == 0
    children = [child["id"] for child in value["children"].values()]
    legacy = [row.id for row in cleanup.PUBLIC_LEGACY]
    parent = value["parent"]["id"]
    # The historical LRN Update listener was already disabled. It is still
    # identity-checked and checkpointed as one of the exact 25 targets, but a
    # safe executor does not send a redundant remote mutation for it.
    expected_legacy_mutations = [
        identifier for identifier in legacy if identifier != 392475375632384
    ]
    assert api.transitions == ([(identifier, True) for identifier in children]
                               + [(identifier, False) for identifier in expected_legacy_mutations]
                               + [(parent, True)])
    assert all(api.workflows[identifier]["enabled"] is True for identifier in children)
    assert all(api.workflows[identifier]["enabled"] is False for identifier in legacy)
    assert api.workflows[parent]["enabled"] is True
    assert api.workflows[cleanup.PRESERVE[0].id]["enabled"] is True
    assert pathlib.Path(result["backup"]).is_file()
    checkpoint = json.loads(pathlib.Path(result["checkpoint"]).read_text(encoding="utf-8"))
    assert checkpoint["phase"] == "cutover_complete_pending_functional_acceptance"
    assert checkpoint["rollback_plan"]["deletions"] == "forbidden"


def test_direct_apply_also_requires_both_explicit_confirmations(validated, tmp_path):
    value, evidence_path = validated
    api = _FakeApi(value)

    with pytest.raises(target.CutoverError, match="cutover confirmation"):
        target.apply_cutover(
            api,
            evidence_path,
            output_root=tmp_path / "cutovers",
            confirmation="wrong",
            admission_paused=target.ADMISSION_PAUSED_CONFIRM,
        )
    assert api.transitions == []


def test_parent_failure_restores_prior_enable_states_and_never_touches_notice(validated, tmp_path):
    value, evidence_path = validated
    api = _FakeApi(value)
    api.fail_before.add(value["parent"]["id"])

    with pytest.raises(target.CutoverError, match="prior enable states were restored"):
        target.apply_cutover(
            api,
            evidence_path,
            output_root=tmp_path / "cutovers",
            confirmation=target.CUTOVER_CONFIRM,
            admission_paused=target.ADMISSION_PAUSED_CONFIRM,
        )

    # Parent stayed off; all custom-action children returned to inactive.
    assert api.workflows[value["parent"]["id"]]["enabled"] is False
    assert all(api.workflows[child["id"]]["enabled"] is False for child in value["children"].values())
    # Exact legacy source state, including the historical dormant LRN Update,
    # was restored. The preserved Notice listener was never toggled.
    assert api.workflows[392475375632384]["enabled"] is False
    assert all(
        api.workflows[row.id]["enabled"] is True
        for row in cleanup.PUBLIC_LEGACY
        if row.id != 392475375632384
    )
    assert all(identifier != cleanup.PRESERVE[0].id for identifier, _ in api.transitions)
    assert all(identifier not in {item.id for item in cleanup.OPTIONAL_UNPUBLISHED}
               for identifier, _ in api.transitions)


def test_exact_identity_drift_blocks_before_first_mutation(validated):
    value, evidence_path = validated
    api = _FakeApi(value)
    api.workflows[cleanup.PUBLIC_LEGACY[2].id]["key"] = "unexpected-replacement"

    with pytest.raises(target.CutoverError, match="identity drifted"):
        target.preflight(api, evidence_path)
    assert api.transitions == []


def test_lost_response_after_child_commit_is_reconciled_by_exact_readback(validated, tmp_path):
    value, evidence_path = validated
    api = _FakeApi(value)
    first_child = next(iter(value["children"].values()))["id"]
    api.fail_after.add(first_child)

    result = target.apply_cutover(
        api,
        evidence_path,
        output_root=tmp_path / "cutovers",
        confirmation=target.CUTOVER_CONFIRM,
        admission_paused=target.ADMISSION_PAUSED_CONFIRM,
    )

    assert result["cutover_complete"] is True
    assert api.workflows[first_child]["enabled"] is True
    assert api.transitions.count((first_child, True)) == 1


def test_cli_refuses_apply_without_both_explicit_confirmations(tmp_path, capsys):
    evidence_path = _write_validation(tmp_path)

    assert target.main(["--apply", "--validation", str(evidence_path)]) == 1
    assert "--confirm" in capsys.readouterr().err
    assert target.main([]) == 0
    plan = json.loads(capsys.readouterr().out)
    assert plan["deletions"] == "not implemented"
