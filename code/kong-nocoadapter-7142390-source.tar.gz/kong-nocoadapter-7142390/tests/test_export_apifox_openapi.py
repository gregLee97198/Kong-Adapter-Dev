from app.models import (
    CreateIntakeForExpansionAipRequest,
    UpdateExpansionAipDataRequest,
)
from scripts.export_apifox_openapi import AIP_EXAMPLE, PATH_META, build_spec


def test_expansion_aip_examples_match_request_models() -> None:
    CreateIntakeForExpansionAipRequest.model_validate(AIP_EXAMPLE)
    UpdateExpansionAipDataRequest.model_validate(
        PATH_META["/v1/update_expansion_aip_data"]["example"]
    )


def test_expansion_aip_paths_are_grouped_and_use_named_models() -> None:
    spec = build_spec()

    checklist = spec["paths"]["/v1/expansion-aip-checklist"]["get"]
    assert checklist["tags"] == ["19-Expansion AIP"]
    assert checklist["x-apifox-folder"] == "19-Expansion AIP"

    expected_models = {
        "/v1/create_intake_for_expansion_aip": (
            "CreateIntakeForExpansionAipRequest",
            "AIP-20260924-0001",
        ),
        "/v1/update_expansion_aip_data": (
            "UpdateExpansionAipDataRequest",
            "AIP-UPDATE-0001",
        ),
    }
    for path, (model_name, request_id) in expected_models.items():
        operation = spec["paths"][path]["post"]
        media = operation["requestBody"]["content"]["application/json"]
        assert operation["tags"] == ["19-Expansion AIP"]
        assert operation["x-apifox-folder"] == "19-Expansion AIP"
        assert media["schema"] == {
            "$ref": f"#/components/schemas/{model_name}"
        }
        assert media["example"]["request_id"] == request_id


def test_expansion_aip_schemas_have_apifox_metadata() -> None:
    schemas = build_spec()["components"]["schemas"]

    expected_titles = {
        "CreateIntakeForExpansionAipRequest": "Expansion AIP Create 请求",
        "UpdateExpansionAipDataRequest": "Expansion AIP Update 请求",
        "ExpansionAipFormData": "Expansion AIP form_data",
        "UpdateExpansionAipFormData": "Expansion AIP Update form_data",
    }
    for name, title in expected_titles.items():
        assert schemas[name]["title"] == title
        assert schemas[name]["x-apifox-folder"] == "数据模型/Expansion AIP"

    assert schemas["UpdateHomeBoundCaseSummaryPayload"]["x-apifox-folder"] == (
        "数据模型/公共"
    )
