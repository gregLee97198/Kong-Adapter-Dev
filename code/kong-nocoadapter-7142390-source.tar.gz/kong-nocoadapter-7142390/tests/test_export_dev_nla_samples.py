from __future__ import annotations

import copy
import io
import json
import re
from types import SimpleNamespace
from typing import Any

import pytest

from scripts import export_dev_nla_samples as exporter

CREATE_ID = "390790723928064"


def create_request() -> dict[str, Any]:
    address = {
        "region_code": "0",
        "district_code": "C",
        "sub_district_code": "Admiralty",
        "full_name_en": "18 Harbourview Lane, Hong Kong",
    }
    return {
        "request_id": "OP-NLA-20261007-001",
        "form_data": {
            "case_summary": {"office_code": "LORCHE", "received_date": "2026-10-07"},
            "part_1": {
                "application_received_date": "2026-10-07",
                "tentative_commencement_date": "2027-04-05",
            },
            "part_2": {
                "rch_name_en": "Harbourview Residential Care Home",
                "rch_name_cn": "海景安老院",
                "operation_mode_id": "PN",
                "premises_type": "1",
                "monthly_fee_min": 12000,
                "monthly_fee_max": 18000,
                "gender": "0",
                "floor_area_sqm": 520,
                "licence_capacity": 40,
                "address": address,
                "rch_type_code": "a2",
                "nursing_home_places": 0,
                "care_and_attention_home_places": 40,
                "aged_home_places": 0,
                "self_care_hostel_places": 0,
                "premises": {
                    "self_owned": [],
                    "rented": [
                        {
                            "premise_type": "1",
                            "tenancy_from": "2026-07-09",
                            "tenancy_to": "2031-10-06",
                            "sort_order": 1,
                            "address": address,
                        }
                    ],
                },
            },
            "part_3": {
                "rch_business_status": "0",
                "applicant_operator_type": "0",
                "operator": {"full_name_en": "LEUNG HO YAT", "active": True},
            },
            "part_5": {
                "application_level": "normal",
                "checklist": [
                    {
                        "position_code": "LORCHE_NLA_FORM",
                        "attachment_id": 1408,
                    }
                ],
            },
        },
    }


def query_response(request: dict[str, Any]) -> dict[str, Any]:
    form = request["form_data"]
    return {
        "request_id": request["request_id"],
        "create_id": CREATE_ID,
        "office_code": "LORCHE",
        "application_type": {
            "value": "new_licence",
            "label": "New Licence Applications",
        },
        "status": "Acknowledged",
        "application_data": {
            "form_data": {
                "case_summary": {"office_code": "LORCHE"},
                "part_1": copy.deepcopy(form["part_1"]),
                "part_2": {
                    "rch_name_en": form["part_2"]["rch_name_en"],
                    "rch_name_cn": form["part_2"]["rch_name_cn"],
                    "floor_area_sqm": 520,
                    "premises": {
                        "rented": [
                            {
                                "premise_type": "1",
                                "tenancy_from": "2026-07-09",
                                "tenancy_to": "2031-10-06",
                            }
                        ]
                    },
                },
                "part_3": {"applicant_operator_type": "0"},
                "part_5": {
                    "application_level": "normal",
                    "checklist": copy.deepcopy(form["part_5"]["checklist"]),
                },
            }
        },
        "notices": [
            {
                "notice_id": "114",
                "third_party_name": "OP",
                "intake_type": "New Licence Application",
                "notice_type": "a",
                "status": "Acknowledged",
                "content": "Acknowledgement letter sent.",
                "rch_no": None,
                "rch_name": form["part_2"]["rch_name_en"],
                "created_time": "2026-10-07T11:54:00.828Z",
                "attachments": [
                    {
                        "data_id": 1413,
                        "filename": "acknowledgement.docx",
                        "size": 65162,
                        "download_url": "/v1/files/1413",
                    }
                ],
            }
        ],
    }


def test_valid_public_create_and_query_are_accepted_without_mutation() -> None:
    request = create_request()
    response = query_response(request)
    original_request = copy.deepcopy(request)
    original_response = copy.deepcopy(response)

    assert exporter._validate_create_request(request) is request
    assert exporter._validate_query_response(response, CREATE_ID, request) is response
    assert request == original_request
    assert response == original_response


@pytest.mark.parametrize(
    ("mutate", "path"),
    [
        (
            lambda body: body["form_data"]["case_summary"].update(submitter_user_id=12),
            "Create.form_data.case_summary.submitter_user_id",
        ),
        (
            lambda body: body["form_data"]["case_summary"].update(
                task_owner_user_id=45
            ),
            "Create.form_data.case_summary.task_owner_user_id",
        ),
        (
            lambda body: body["form_data"]["case_summary"].update(
                task_owner_post_code="S(LR)1"
            ),
            "Create.form_data.case_summary.task_owner_post_code",
        ),
        (
            lambda body: body["form_data"]["part_5"].update(attachment_ids=[]),
            "Create.form_data.part_5.attachment_ids",
        ),
        (
            lambda body: body["form_data"]["part_3"]["operator"].update(id=10),
            "Create.form_data.part_3.operator.id",
        ),
        (
            lambda body: body["form_data"]["part_5"]["checklist"][0].update(
                checklist_id=99
            ),
            "Create.form_data.part_5.checklist[0].checklist_id",
        ),
        (
            lambda body: body["form_data"]["part_2"].update(floor_area_sqm="520.00"),
            "Create.form_data.part_2.floor_area_sqm",
        ),
        (
            lambda body: body["form_data"]["part_3"]["operator"].update(active="true"),
            "Create.form_data.part_3.operator.active",
        ),
    ],
)
def test_create_rejects_internal_fields_instead_of_stripping_them(
    mutate: Any, path: str
) -> None:
    request = create_request()
    mutate(request)
    original = copy.deepcopy(request)

    with pytest.raises(ValueError, match=re.escape(path)):
        exporter._validate_create_request(request)

    assert request == original


@pytest.mark.parametrize(
    ("mutate", "path"),
    [
        (lambda body: body.update(request_id="DIFFERENT"), "Query.request_id"),
        (
            lambda body: body["application_data"].update(intake_id=123),
            "Query.application_data.intake_id",
        ),
        (
            lambda body: body["application_data"]["form_data"]["part_5"]["checklist"][
                0
            ].update(checklist_id=123),
            "Query.application_data.form_data.part_5.checklist[0].checklist_id",
        ),
        (
            lambda body: body["application_data"]["form_data"]["part_5"]["checklist"][
                0
            ].update(attachment_id=0),
            "Query.application_data.form_data.part_5.checklist[0].attachment_id",
        ),
        (
            lambda body: body["application_data"]["form_data"]["part_2"].update(
                floor_area_sqm="520.00"
            ),
            "Query.application_data.form_data.part_2.floor_area_sqm",
        ),
        (
            lambda body: body["application_data"]["form_data"]["part_2"].update(
                rch_name_en="Other Home"
            ),
            "Query.application_data.form_data.part_2.rch_name_en",
        ),
        (
            lambda body: body["notices"][0].update(letter_attachment_id=99),
            "Query.notices[0].letter_attachment_id",
        ),
        (
            lambda body: body["notices"][0]["attachments"][0].update(
                download_url="/v1/files/other"
            ),
            "Query.notices[0].attachments[0].download_url",
        ),
    ],
)
def test_query_rejects_contract_drift(mutate: Any, path: str) -> None:
    request = create_request()
    response = query_response(request)
    mutate(response)

    with pytest.raises(ValueError, match=re.escape(path)):
        exporter._validate_query_response(response, CREATE_ID, request)


def _patch_export_io(
    monkeypatch: pytest.MonkeyPatch, source: dict[str, Any], response: dict[str, Any]
) -> None:
    monkeypatch.setattr(
        exporter.Settings,
        "from_env",
        lambda: SimpleNamespace(nocobase_base_url=exporter.DEV_BASE_URL),
    )
    monkeypatch.setattr(exporter.getpass, "getpass", lambda _: "password")
    monkeypatch.setattr(exporter, "sign_in", lambda _: "token")
    monkeypatch.setattr(exporter, "create_app", lambda _: object())
    monkeypatch.setattr(
        exporter.urllib.request,
        "urlopen",
        lambda request, timeout: io.StringIO(json.dumps({"data": source})),
    )

    class FakeClient:
        def __init__(self, app: Any) -> None:
            pass

        def __enter__(self) -> FakeClient:
            return self

        def __exit__(self, *_args: Any) -> None:
            return None

        def get(self, path: str, headers: dict[str, str]) -> Any:
            assert path == f"/v1/request/{CREATE_ID}"
            return SimpleNamespace(status_code=200, json=lambda: response)

    monkeypatch.setattr(exporter, "TestClient", FakeClient)


def test_export_writes_unmodified_valid_pair(
    tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    request = create_request()
    response = query_response(request)
    source = {
        "id": int(CREATE_ID),
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_application_type": "new_licence",
        "f_office_code": "LORCHE",
        "f_request_body": request,
    }
    _patch_export_io(monkeypatch, source, response)
    output_dir = tmp_path / "samples"

    exporter.export([CREATE_ID], output_dir)

    assert (
        json.loads((output_dir / f"nla-create-{CREATE_ID}.json").read_text()) == request
    )
    assert (
        json.loads((output_dir / f"nla-request-{CREATE_ID}.json").read_text())
        == response
    )


def test_export_rejects_before_writing_any_file(
    tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    request = create_request()
    request["form_data"]["part_5"]["attachment_ids"] = []
    response = query_response(request)
    source = {
        "id": int(CREATE_ID),
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_application_type": "new_licence",
        "f_request_body": request,
    }
    _patch_export_io(monkeypatch, source, response)
    output_dir = tmp_path / "samples"

    with pytest.raises(RuntimeError, match="Create.form_data.part_5.attachment_ids"):
        exporter.export([CREATE_ID], output_dir)

    assert not output_dir.exists()
