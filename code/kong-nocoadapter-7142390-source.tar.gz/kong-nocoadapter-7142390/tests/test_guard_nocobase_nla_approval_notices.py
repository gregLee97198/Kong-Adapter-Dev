"""Offline safety contract for the NLA-only Approval Log Sync Data guard."""

from __future__ import annotations

import copy
import sys
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import guard_nocobase_nla_approval_notices as target  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402


def source_graph() -> dict[str, Any]:
    titles = [
        target.NLA_TITLE,
        target.STAGING_TITLE,
        target.DETAILS_TITLE,
        target.TARGET_TITLE,
    ]
    kinds = ["query", "query", "query", "condition"]
    ids = [target.SOURCE_ID + index for index in range(1, 4)] + [target.TARGET_ID]
    nodes = [
        {
            "id": node_id,
            "key": f"testkey{index}",
            "title": title,
            "type": kind,
            "workflowId": target.SOURCE_ID,
            "upstreamId": None,
            "downstreamId": None,
            "branchIndex": None,
            "config": {},
        }
        for index, (node_id, title, kind) in enumerate(zip(ids, titles, kinds))
    ]
    nodes[-1]["upstreamId"] = nodes[1]["id"]
    nodes[-1]["branchIndex"] = 1
    nodes[-1]["key"] = target.TARGET_KEY
    workflow = {
        "id": target.SOURCE_ID,
        "key": target.SOURCE_KEY,
        "title": target.SOURCE_TITLE,
        "type": "collection",
        "sync": False,
        "enabled": True,
        "config": copy.deepcopy(target.EXPECTED_TRIGGER),
        "nodes": nodes,
    }
    nodes[-1]["config"] = target.original_target_config(workflow)
    return workflow


class FakeApi:
    def __init__(self, source: dict[str, Any]) -> None:
        self.workflows = {target.SOURCE_ID: copy.deepcopy(source)}
        self.revision_id = target.SOURCE_ID + 100000
        self.writes: list[tuple[str, int | None, Any]] = []
        self.bad_mapping = False
        self.fail_enable_candidate = False
        self.fail_enable_source = False
        self.timeout_after_node_update = False

    def get_workflow(self, workflow_id: int) -> dict[str, Any]:
        return copy.deepcopy(self.workflows[workflow_id])

    def update_node(self, node_id: int, values: dict[str, Any]) -> None:
        self.writes.append(("node", node_id, copy.deepcopy(values)))
        for workflow in self.workflows.values():
            for node in workflow["nodes"]:
                if node["id"] == node_id:
                    node.update(copy.deepcopy(values))
                    if self.timeout_after_node_update:
                        self.timeout_after_node_update = False
                        raise ApiError("simulated timeout after node update")
                    return
        raise AssertionError("Missing node")

    def request(
        self, method: str, path: str, body: dict[str, Any] | None = None
    ) -> Any:
        if method == "GET":
            if path.startswith("/api/workflows:list?"):
                return [
                    {"id": w["id"], "key": w["key"], "enabled": w["enabled"]}
                    for w in self.workflows.values()
                ]
            if path.startswith("/api/executions:list?"):
                return []
            if path.startswith("/api/t_status_name_map_details:get?"):
                return {
                    "id": target.ACK_MAPPING_ID,
                    "f_code": "15",
                    "f_notice_board_persist": True,
                    "f_notice_type": "b" if self.bad_mapping else "a",
                    "fk_notice_board_status": 4,
                    "f_notice_log_status": "5",
                }
            if path.startswith("/api/t_notice_board_status:get?"):
                return {"id": 4, "f_status": "Acknowledged"}
            raise AssertionError(path)
        assert method == "POST"
        if path.startswith("/api/workflows:revision?"):
            assert self.revision_id not in self.workflows
            source = self.workflows[target.SOURCE_ID]
            candidate = copy.deepcopy(source)
            candidate["id"] = self.revision_id
            candidate["enabled"] = False
            node_ids = {
                node["id"]: self.revision_id + index
                for index, node in enumerate(candidate["nodes"], start=1)
            }
            for node in candidate["nodes"]:
                node["id"] = node_ids[node["id"]]
                node["workflowId"] = self.revision_id
                for edge in ("upstreamId", "downstreamId"):
                    if node[edge] is not None:
                        node[edge] = node_ids[node[edge]]
            self.workflows[self.revision_id] = candidate
            self.writes.append(("revision", self.revision_id, {}))
            return {"id": self.revision_id}
        assert path.startswith("/api/workflows:update?filterByTk=")
        workflow_id = int(path.split("filterByTk=", 1)[1])
        assert body is not None and set(body) == {"enabled"}
        self.writes.append(("enable", workflow_id, body["enabled"]))
        if (
            self.fail_enable_candidate
            and workflow_id == self.revision_id
            and body["enabled"]
        ):
            raise ApiError("simulated candidate enable failure")
        if (
            self.fail_enable_source
            and workflow_id == target.SOURCE_ID
            and body["enabled"]
        ):
            raise ApiError("simulated source enable failure")
        self.workflows[workflow_id]["enabled"] = body["enabled"]
        return {}


@pytest.fixture
def api(monkeypatch: pytest.MonkeyPatch) -> FakeApi:
    source = source_graph()
    monkeypatch.setattr(target, "SOURCE_NODE_COUNT", len(source["nodes"]))
    monkeypatch.setattr(target, "SOURCE_FINGERPRINT", target.fingerprint(source))
    return FakeApi(source)


def test_guard_preserves_original_conditions_and_adds_only_ack_evidence() -> None:
    source = source_graph()
    old = target.original_target_config(source)
    guarded = target.guarded_target_config(source)
    calculations = guarded["calculation"]["group"]["calculations"]
    assert calculations[:2] == old["calculation"]["group"]["calculations"]
    assert calculations[2:] == [
        {
            "calculator": "equal",
            "operands": ["{{$context.data.f_collection_name}}", "t_licence_app"],
        },
        {"calculator": "equal", "operands": ["{{$context.data.f_node_val}}", "15"]},
        {"calculator": "equal", "operands": ["{{$context.data.f_status}}", "5"]},
        {
            "calculator": "notEqual",
            "operands": ["{{$context.data.f_completed_date}}", None],
        },
        {
            "calculator": "equal",
            "operands": ["{{$jobsMapByNodeKey.testkey2.f_notice_type}}", "a"],
        },
        {
            "calculator": "equal",
            "operands": ["{{$jobsMapByNodeKey.testkey2.fk_notice_board_status}}", 4],
        },
    ]
    assert old == target.original_target_config(source)


def test_audit_and_default_prepare_are_read_only(
    api: FakeApi, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    target.audit(api)  # type: ignore[arg-type]
    assert not api.writes
    assert "candidate_id=None" in capsys.readouterr().out
    monkeypatch.setenv("NOCOBASE_TOKEN", "fake")
    monkeypatch.setattr(target, "RootNocoBaseApi", lambda *_: api)
    assert target.main(["prepare"]) == 0
    assert not api.writes
    assert "mode=read-only" in capsys.readouterr().out


def test_prepare_patches_only_disabled_revision_and_is_idempotent(api: FakeApi) -> None:
    revision_id = target.prepare(api)  # type: ignore[arg-type]
    assert revision_id == api.revision_id
    source = api.get_workflow(target.SOURCE_ID)
    candidate = api.get_workflow(revision_id)
    target.validate_source(source, enabled=True)
    target.validate_candidate(source, candidate, patched=True, enabled=False)
    assert [write[0] for write in api.writes].count("node") == 1
    before = copy.deepcopy(api.writes)
    assert target.prepare(api) == revision_id  # type: ignore[arg-type]
    assert api.writes == before


def test_prepare_accepts_only_exact_readback_after_node_timeout(api: FakeApi) -> None:
    api.timeout_after_node_update = True
    revision_id = target.prepare(api)  # type: ignore[arg-type]
    target.validate_candidate(
        api.get_workflow(target.SOURCE_ID),
        api.get_workflow(revision_id),
        patched=True,
        enabled=False,
    )


def test_mapping_or_source_drift_fails_before_writes(api: FakeApi) -> None:
    api.bad_mapping = True
    with pytest.raises(ApiError, match="Acknowledgement mapping drifted"):
        target.prepare(api)  # type: ignore[arg-type]
    assert not api.writes
    api.bad_mapping = False
    api.workflows[target.SOURCE_ID]["nodes"][0]["config"] = {"rogue": True}
    with pytest.raises(ApiError, match="audited DEV graph"):
        target.prepare(api)  # type: ignore[arg-type]
    assert not api.writes


def test_candidate_other_branch_drift_blocks_cutover(api: FakeApi) -> None:
    target.prepare(api)  # type: ignore[arg-type]
    api.workflows[api.revision_id]["nodes"][0]["config"] = {"rogue": True}
    before = copy.deepcopy(api.writes)
    with pytest.raises(ApiError, match="exact graph copy"):
        target.cutover(api)  # type: ignore[arg-type]
    assert api.writes == before


def test_cutover_failure_restores_source(api: FakeApi) -> None:
    target.prepare(api)  # type: ignore[arg-type]
    api.fail_enable_candidate = True
    with pytest.raises(ApiError, match="audited source restored"):
        target.cutover(api)  # type: ignore[arg-type]
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is True
    assert api.get_workflow(api.revision_id)["enabled"] is False


def test_cutover_verify_and_rollback_never_enable_both(api: FakeApi) -> None:
    target.prepare(api)  # type: ignore[arg-type]
    assert target.cutover(api) == api.revision_id  # type: ignore[arg-type]
    assert target.verify(api) == api.revision_id  # type: ignore[arg-type]
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is False
    assert api.get_workflow(api.revision_id)["enabled"] is True
    target.rollback(api)  # type: ignore[arg-type]
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is True
    assert api.get_workflow(api.revision_id)["enabled"] is False
    enabled_writes = [write for write in api.writes if write[0] == "enable"]
    assert enabled_writes == [
        ("enable", target.SOURCE_ID, False),
        ("enable", target.SOURCE_ID, True),
        ("enable", target.SOURCE_ID, False),
        ("enable", api.revision_id, True),
        ("enable", api.revision_id, False),
        ("enable", target.SOURCE_ID, True),
    ]


def test_failed_rollback_restores_guarded_candidate(api: FakeApi) -> None:
    target.prepare(api)  # type: ignore[arg-type]
    target.cutover(api)  # type: ignore[arg-type]
    api.fail_enable_source = True
    with pytest.raises(ApiError, match="guarded candidate restored"):
        target.rollback(api)  # type: ignore[arg-type]
    assert api.get_workflow(target.SOURCE_ID)["enabled"] is False
    assert api.get_workflow(api.revision_id)["enabled"] is True
