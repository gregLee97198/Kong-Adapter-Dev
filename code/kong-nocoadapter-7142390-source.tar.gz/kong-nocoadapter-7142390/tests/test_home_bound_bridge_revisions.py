from __future__ import annotations

import copy
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import revise_nocobase_home_bound_bridges as bridge_module  # noqa: E402
from revise_nocobase_home_bound_bridges import (  # noqa: E402
    TARGETS,
    apply_revisions,
    build_created_plan,
    build_received_plan,
    install_plan,
    validate_installed_plan,
)


class FakeApi:
    def __init__(self, workflow: dict[str, Any]) -> None:
        self.workflow = workflow
        self.next_id = 1000

    def create_node(self, body: dict[str, Any]) -> dict[str, Any]:
        self.next_id += 1
        node = {
            **copy.deepcopy(body),
            "id": self.next_id,
            "key": f"node-{self.next_id}",
        }
        self.workflow["nodes"].append(node)
        return copy.deepcopy(node)

    def update_node(self, node_id: int, body: dict[str, Any]) -> dict[str, Any]:
        node = next(row for row in self.workflow["nodes"] if row["id"] == node_id)
        node.update(copy.deepcopy(body))
        return copy.deepcopy(node)


def materialize(plan: Any) -> dict[str, Any]:
    workflow = {
        "id": 900,
        "key": plan.source_key,
        "title": plan.title,
        "config": copy.deepcopy(dict(plan.config)),
        "nodes": [],
    }
    install_plan(FakeApi(workflow), 900, plan)
    validate_installed_plan(workflow, plan)
    return workflow


def by_title(workflow: dict[str, Any], title: str) -> dict[str, Any]:
    return next(row for row in workflow["nodes"] if row["title"] == title)


@pytest.mark.parametrize("target", TARGETS, ids=lambda row: row.key)
def test_created_bridge_uses_intake_marker_and_never_application_office(
    target: Any,
) -> None:
    workflow = materialize(build_created_plan(target))
    nodes = {row["title"]: row for row in workflow["nodes"]}

    intake = nodes["Load linked Intake API provenance"]
    assert intake["config"]["collection"] == "t_intake_form"
    assert intake["config"]["params"]["filter"] == {
        "$and": [
            {"id": {"$eq": "{{$context.data." + target.application_intake_fk + "}}"}}
        ]
    }

    marker = nodes["Intake has API CREATE marker"]
    marked = nodes["Load marked external CREATE staging"]
    cmtf = nodes["Resolve existing CMTF CREATE staging"]
    assert marked["upstreamId"] == marker["id"]
    assert marked["branchIndex"] == 1
    assert cmtf["upstreamId"] == marker["id"]
    assert cmtf["branchIndex"] == 0

    marked_filters = marked["config"]["params"]["filter"]["$and"]
    assert {
        "id": {
            "$eq": "{{$jobsMapByNodeKey." + intake["key"] + ".f_api_create_staging_id}}"
        }
    } in marked_filters
    assert {"f_source_system": {"$ne": "CMTF"}} in marked_filters

    backfill = nodes["Backfill marked CREATE staging IDs"]
    values = backfill["config"]["params"]["values"]
    assert values == {
        "f_intake_id": "{{$jobsMapByNodeKey." + intake["key"] + ".id}}",
        "f_application_id": "{{$context.data.id}}",
        "f_rch_id": (
            "{{$jobsMapByNodeKey." + intake["key"] + ".fk_intake_source_rch}}"
        ),
        "f_office_code": ("{{$jobsMapByNodeKey." + intake["key"] + ".f_office_cd}}"),
    }
    assert "{{$context.data.f_office_cd}}" not in str(values)
    assert "{{$context.data.f_office_code}}" not in str(values)

    creates = [row for row in workflow["nodes"] if row["type"] == "create"]
    assert len(creates) == 1
    create_values = creates[0]["config"]["params"]["values"]
    assert create_values["f_source_system"] == "CMTF"
    assert create_values["f_status"] == "succeeded"
    assert create_values["f_application_status"] == "Accepted"
    assert create_values["f_office_code"] == (
        "{{$jobsMapByNodeKey." + intake["key"] + ".f_office_cd}}"
    )
    assert (
        creates[0]["upstreamId"] == nodes["Existing CMTF CREATE staging exists"]["id"]
    )
    assert creates[0]["branchIndex"] == 0


@pytest.mark.parametrize("target", TARGETS, ids=lambda row: row.key)
def test_created_bridge_mutates_only_staging(target: Any) -> None:
    workflow = materialize(build_created_plan(target))
    mutations = [
        row for row in workflow["nodes"] if row["type"] in {"create", "update"}
    ]
    assert mutations
    assert {row["config"]["collection"] for row in mutations} == {
        "t_api_request_staging"
    }


@pytest.mark.parametrize(
    "target",
    [
        row
        for row in TARGETS
        if row.application_collection == "t_change_monitoring_base"
    ],
    ids=lambda row: row.key,
)
def test_change_created_bridge_is_scoped_to_exact_intake_type(target: Any) -> None:
    workflow = materialize(build_created_plan(target))
    assert workflow["config"]["collection"] == "t_change_monitoring_base"
    assert workflow["config"]["condition"] == {
        "$and": [{"fk_intake_type": {"$eq": target.intake_type_id}}]
    }

    application = by_title(workflow, "Load linked Intake API provenance")
    assert application["config"]["params"]["filter"] == {
        "$and": [
            {
                "id": {
                    "$eq": (
                        "{{$context.data." + target.application_intake_fk + "}}"
                    )
                }
            }
        ]
    }


@pytest.mark.parametrize("target", TARGETS, ids=lambda row: row.key)
def test_received_bridge_is_changed_field_trigger_with_accepted_cas(
    target: Any,
) -> None:
    workflow = materialize(build_received_plan(target))
    assert workflow["config"] == {
        "mode": 2,
        "appends": [],
        "changed": ["f_approval_status"],
        "condition": {
            "$and": [
                {"fk_intake_type": {"$eq": target.intake_type_id}},
                {"f_approval_status": {"$eq": "4"}},
            ]
        },
        "collection": "t_intake_form",
    }

    application = by_title(workflow, "Resolve linked business application")
    assert application["config"]["collection"] == target.application_collection
    accepted = by_title(workflow, "Resolve unique Accepted CREATE staging")
    accepted_filters = accepted["config"]["params"]["filter"]["$and"]
    assert {"f_intake_id": {"$eq": "{{$context.data.id}}"}} in accepted_filters
    assert {"f_request_event": {"$eq": "CREATE"}} in accepted_filters
    assert {"f_api_type": {"$eq": target.create_api_type}} in accepted_filters
    assert {"f_application_type": {"$eq": target.application_type}} in accepted_filters
    assert {"f_application_status": {"$eq": "Accepted"}} in accepted_filters

    publish = by_title(workflow, "CAS publish Received + backfill IDs")
    assert publish["type"] == "sql"
    config = publish["config"]
    assert config["dataSource"] == "main"
    assert config["unsafeInjection"] is False
    sql = config["sql"]
    assert '"f_application_status"=\'Received\'' in sql
    assert 'create_row."f_status"=\'succeeded\'' in sql
    assert 'create_row."f_application_status"=\'Accepted\'' in sql
    assert 'create_row."f_active_update_id" IS NULL' in sql
    assert 'create_row."f_active_update_id"=\'\'' in sql
    assert "NOT EXISTS" in sql
    assert 'active."f_request_event"=\'UPDATE\'' in sql
    assert "('submitted','processing')" in sql

    variables = {item["name"]: item["value"] for item in config["variables"]}
    assert variables == {
        "createId": f"{{{{$jobsMapByNodeKey.{accepted['key']}.id}}}}",
        "intakeId": "{{$context.data.id}}",
        "applicationId": f"{{{{$jobsMapByNodeKey.{application['key']}.id}}}}",
        "rchId": "{{$context.data.fk_intake_source_rch}}",
        "officeCode": "{{$context.data.f_office_cd}}",
        "createApiType": target.create_api_type,
        "applicationType": target.application_type,
    }


def test_reviewed_titles_and_source_keys_are_exact() -> None:
    assert [(row.created_title, row.created_source_key) for row in TARGETS] == [
        (
            "API Bridge — Self-withdraw Application Created to Staging v1",
            "5c5gq6jo3h6",
        ),
        (
            "API Bridge — Revoke Licence Application Created to Staging v1",
            "arvhul2cg5u",
        ),
        (
            "API Bridge — Specific Hour Application Created to Staging v1",
            "xgd7hu04ocb",
        ),
        ("API Bridge — RP Application Created to Staging v1", "g62jjm4yhjm"),
        (
            "API Bridge — Change Home Manager Created to Staging v1",
            "rf9w6a9ssno",
        ),
        ("API Bridge — Change Beds Created to Staging v1", "vqy9oir6n2v"),
        (
            "API Bridge — Change Operation Mode Created to Staging v1",
            "tzxd3e32ils",
        ),
        (
            "API Bridge — Change Directors Created to Staging v1",
            "lv58nwapn4t",
        ),
        (
            "API Bridge — Change Nurse-in-Charge Created to Staging v1",
            "1u4vc8irzoh",
        ),
    ]
    assert [(row.received_title, row.received_source_key) for row in TARGETS] == [
        (
            "API Bridge — Self-withdraw Intake Completed to Received v1",
            "l206xob0dbr",
        ),
        (
            "API Bridge — Revoke Licence Intake Completed to Received v1",
            "15mecmtt7nw",
        ),
        (
            "API Bridge — Specific Hour Intake Completed to Received v1",
            "lsiypf4jl1a",
        ),
        (
            "API Bridge — RP Intake Completed to Received v1",
            "4g06ur8gpvm",
        ),
        (
            "API Bridge — Change Home Manager Intake Completed to Received v1",
            "v30wzsx6kw2",
        ),
        (
            "API Bridge — Change Beds Intake Completed to Received v1",
            "sxfsyh0uocy",
        ),
        (
            "API Bridge — Change Operation Mode Intake Completed to Received v1",
            "ay7xmr703qr",
        ),
        (
            "API Bridge — Change Directors Intake Completed to Received v1",
            "lwd0fiw5qta",
        ),
        (
            "API Bridge — Change Nurse-in-Charge Intake Completed to Received v1",
            "fgd6sjscz4x",
        ),
    ]


def test_apply_revisions_runs_on_python_39_without_zip_strict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Exercise the activation loop used by the 13001 maintenance runtime."""

    draft = {"id": 2, "enabled": False, "nodes": []}

    class ApplyApi:
        def request(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
            return {}

        def get_workflow(self, workflow_id: int) -> dict[str, Any]:
            assert workflow_id == 2
            return copy.deepcopy(draft)

    monkeypatch.setattr(
        bridge_module,
        "_create_revision",
        lambda _api, _source: copy.deepcopy(draft),
    )
    monkeypatch.setattr(bridge_module, "destroy_workflow_nodes", lambda *_args: None)
    monkeypatch.setattr(bridge_module, "install_plan", lambda *_args: None)
    monkeypatch.setattr(bridge_module, "validate_installed_plan", lambda *_args: None)

    def fake_set_enabled(_api: Any, _workflow_id: int, enabled: bool) -> None:
        draft["enabled"] = enabled

    monkeypatch.setattr(bridge_module, "set_enabled", fake_set_enabled)
    plan = SimpleNamespace(config={}, title="Compatibility plan")

    result = apply_revisions(
        ApplyApi(),
        [({"id": 1, "enabled": True}, plan)],
    )

    assert result == [{"id": 2, "enabled": True, "nodes": []}]
