from __future__ import annotations

from pathlib import Path

import yaml

ROOT = Path(__file__).parents[1]
KONG_CONFIG = ROOT / "config" / "kong.211-dbless.yml"
COMPOSE_CONFIG = ROOT / "docker-compose.yml"
KONG_DOCKERFILE = ROOT / "Dockerfile.kong"
KONG_STARTER = ROOT / "deploy" / "kong-release" / "use-declarative-config-and-start.sh"


def _load_yaml(path: Path) -> dict[str, object]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def test_kong_publishes_only_expected_native_token_routes() -> None:
    config = _load_yaml(KONG_CONFIG)
    services = config["services"]
    assert isinstance(services, list)

    route_pairs = {
        (method, path)
        for service in services
        for route in service.get("routes", [])
        for method in route.get("methods", [])
        for path in route.get("paths", [])
    }
    assert route_pairs == {
        ("POST", "~/v1/auth/token$"),
        ("GET", "~/health/ready$"),
        ("POST", "~/simple-test$"),
        ("POST", "~/homerecord-query$"),
        ("POST", "~/v1/create_intake_for_new_licence$"),
        ("POST", "~/v1/update_new_licence_data$"),
        ("POST", "~/v1/create_intake_for_changing_home$"),
        ("POST", "~/v1/update_changing_home_data$"),
        ("GET", "~/v1/changing-home-checklist$"),
        ("POST", "~/v1/create_intake_for_self_withdraw$"),
        ("POST", "~/v1/update_self_withdraw_data$"),
        ("POST", "~/v1/create_intake_for_revoke_licence$"),
        ("POST", "~/v1/update_revoke_licence_data$"),
        ("GET", "~/v1/self-withdraw-checklist$"),
        ("GET", "~/v1/revoke-licence-checklist$"),
        ("POST", "~/v1/create_intake_for_specific_hour$"),
        ("POST", "~/v1/update_specific_hour_data$"),
        ("POST", "~/v1/create_intake_for_rp$"),
        ("POST", "~/v1/update_rp_data$"),
        ("GET", "~/v1/specific-hour-checklist$"),
        ("GET", "~/v1/rp-checklist$"),
        ("POST", "~/v1/create_intake_for_change_home_manager$"),
        ("POST", "~/v1/update_change_home_manager_data$"),
        ("POST", "~/v1/create_intake_for_change_beds$"),
        ("POST", "~/v1/update_change_beds_data$"),
        ("POST", "~/v1/create_intake_for_change_operation_mode$"),
        ("POST", "~/v1/update_change_operation_mode_data$"),
        ("POST", "~/v1/create_intake_for_change_directors$"),
        ("POST", "~/v1/update_change_directors_data$"),
        ("POST", "~/v1/create_intake_for_change_nurse_in_charge$"),
        ("POST", "~/v1/update_change_nurse_in_charge_data$"),
        ("POST", "~/v1/create_intake_for_prosecution$"),
        ("POST", "~/v1/update_prosecution_data$"),
        ("POST", "~/v1/create_licence_renewal$"),
        ("POST", "~/v1/update_licence_renewal_data$"),
        ("GET", "~/v1/licence-renewal-checklist$"),
        ("GET", "~/v1/expansion-aip-checklist$"),
        ("POST", "~/v1/create_intake_for_expansion_aip$"),
        ("POST", "~/v1/update_expansion_aip_data$"),
        ("POST", "/v1/files"),
        ("GET", "~/v1/files/[^/]+$"),
        ("GET", "~/v1/request/[^/]+$"),
        ("GET", "~/v1/intakes$"),
        ("GET", "~/v1/new-licence-applications$"),
        ("GET", "~/v1/new-licence-checklist$"),
    }


def test_kong_config_contains_no_oauth2_plugin_or_credentials() -> None:
    text = KONG_CONFIG.read_text(encoding="utf-8").lower()
    assert "oauth2" not in text
    assert "client_secret" not in text
    assert "x-api-key:" not in text


def test_auth_route_targets_adapter_without_exposing_native_upstream() -> None:
    config = _load_yaml(KONG_CONFIG)
    services = {service["name"]: service for service in config["services"]}
    assert "nocobase-native-auth-service" not in services
    auth = services["nocobase-adapter-auth-service"]
    assert auth["host"] == "kong-nocoadapter"
    assert auth["port"] == 8080
    assert "path" not in auth
    route = auth["routes"][0]
    assert route["methods"] == ["POST"]
    assert route["paths"] == ["~/v1/auth/token$"]
    assert route["protocols"] == ["https"]
    assert route["strip_path"] is False
    transformer = next(
        plugin for plugin in route["plugins"]
        if plugin["name"] == "request-transformer"
    )
    assert "Authorization" in transformer["config"]["remove"]["headers"]
    assert "add" not in transformer["config"]


def test_auth_route_is_exact_and_adapter_backed_in_every_gateway_profile() -> None:
    for filename in (
        "kong.211-dbless.yml",
        "kong.local-test-dbless.yml",
        "kong.uat-dbless.yml",
        "kong.portable-template.yml",
    ):
        services = _load_yaml(ROOT / "config" / filename)["services"]
        auth = next(
            service for service in services
            if service["name"] == "nocobase-adapter-auth-service"
        )
        route = auth["routes"][0]
        assert route["methods"] == ["POST"]
        assert route["paths"] == ["~/v1/auth/token$"]
        assert route["strip_path"] is False
        assert route["path_handling"] == "v0"
        if "url" in auth:
            assert auth["url"] == "http://cmtf-adapter:8080"
        else:
            assert (auth["host"], auth["port"]) == (
                "kong-nocoadapter", 8080
            )


def test_create_nla_route_targets_internal_adapter_and_is_https_only() -> None:
    config = _load_yaml(KONG_CONFIG)
    services = config["services"]
    adapter = next(
        service
        for service in services
        if service["name"] == "nocobase-file-adapter-service"
    )
    assert adapter["host"] == "kong-nocoadapter"
    assert adapter["port"] == 8080

    route = next(
        route
        for route in adapter["routes"]
        if route["name"] == "nocobase-create-intake-for-new-licence-v1-route"
    )
    assert route["protocols"] == ["https"]
    assert route["methods"] == ["POST"]
    assert route["paths"] == ["~/v1/create_intake_for_new_licence$"]
    assert route["strip_path"] is False


def test_public_health_route_is_https_get_only_and_strips_credentials() -> None:
    config = _load_yaml(KONG_CONFIG)
    adapter = next(
        service
        for service in config["services"]
        if service["name"] == "nocobase-file-adapter-service"
    )
    route = next(
        route
        for route in adapter["routes"]
        if route["name"] == "nocobase-adapter-health-v1-route"
    )

    assert route["protocols"] == ["https"]
    assert route["methods"] == ["GET"]
    assert route["paths"] == ["~/health/ready$"]
    transformer = next(
        plugin
        for plugin in route["plugins"]
        if plugin["name"] == "request-transformer"
    )
    removed_headers = transformer["config"]["remove"]["headers"]
    assert "Authorization" in removed_headers
    assert "X-NocoBase-Authorization" in removed_headers


def test_liveness_is_internal_only_across_all_gateway_profiles() -> None:
    for filename in (
        "kong.211-dbless.yml",
        "kong.local-test-dbless.yml",
        "kong.uat-dbless.yml",
        "kong.portable-template.yml",
    ):
        routes = [
            route
            for service in _load_yaml(ROOT / "config" / filename)["services"]
            for route in service.get("routes", [])
        ]
        paths = [path for route in routes for path in route.get("paths", [])]
        assert "~/health/ready$" in paths
        assert "~/health/live$" not in paths


def test_compose_is_dbless_and_adapter_has_no_host_port() -> None:
    config = _load_yaml(COMPOSE_CONFIG)
    services = config["services"]
    assert set(services) == {"kong-nocoadapter", "kong-gateway"}
    assert "ports" not in services["kong-nocoadapter"]
    assert services["kong-nocoadapter"]["expose"] == ["8080"]
    assert services["kong-gateway"]["environment"]["KONG_DATABASE"] == "off"
    assert "volumes" not in config


def test_compose_runtime_values_are_controlled_by_dotenv() -> None:
    compose = COMPOSE_CONFIG.read_text(encoding="utf-8")
    expected_variables = {
        "STORAGE_CACHE_SECONDS",
        "MAX_FILE_BYTES",
        "ALLOWED_MIME_TYPES",
        "NOCOBASE_VERIFY_TLS",
        "CONNECT_TIMEOUT_SECONDS",
        "REQUEST_TIMEOUT_SECONDS",
        "UPLOAD_TIMEOUT_SECONDS",
        "MAX_CONNECTIONS",
        "LOG_LEVEL",
        "SOURCE_SYSTEM",
    }
    for variable in expected_variables:
        assert f"${{{variable}:-" in compose


def test_release_kong_image_uses_mounted_contract_before_embedded_fallback() -> None:
    dockerfile = KONG_DOCKERFILE.read_text(encoding="utf-8")
    starter = KONG_STARTER.read_text(encoding="utf-8")

    assert "ARG KONG_BASE_IMAGE=kong:3.9.3" in dockerfile
    assert "COPY config/kong.211-dbless.yml /opt/kong-release/kong.yml" in dockerfile
    assert (
        'ENTRYPOINT ["/usr/local/bin/use-declarative-config-and-start"]'
        in dockerfile
    )
    assert "mounted_config=/kong/declarative/kong.yml" in starter
    assert "embedded_config=/opt/kong-release/kong.yml" in starter
    assert "if [ -r \"$mounted_config\" ]" in starter
    assert 'export KONG_DECLARATIVE_CONFIG="$runtime_config"' in starter
    assert 'exec /docker-entrypoint.sh "$@"' in starter
