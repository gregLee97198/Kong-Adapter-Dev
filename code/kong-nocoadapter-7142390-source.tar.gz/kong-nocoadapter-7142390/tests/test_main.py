from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Optional
from unittest.mock import ANY, AsyncMock

import pytest
from fastapi.testclient import TestClient

from app.errors import AdapterError
from app.main import _update_queue_service_from_env, create_app
from app.models import (
    CreateIntakeForChangingHomeRequest,
    FileDownload,
    FileUploadResult,
    UpdateChangingHomeDataRequest,
)
from app.nocobase_client import NocoBaseClient
from app.nocobase_config import NocoBaseProfile
from app.settings import Settings

PROFILE_PATH = Path(__file__).parents[1] / "config/nocobase.yaml"


def settings(
    *,
    lrn_update_enabled: bool = True,
    prosecution_update_enabled: bool = True,
    chi_operator_enabled: bool = False,
) -> Settings:
    profile = replace(
        NocoBaseProfile.load(PROFILE_PATH),
        base_url="http://example.test/cmtf2",
        storage_selection="default",
        storage_name=None,
        licence_renewal_update_enabled=lrn_update_enabled,
        prosecution_update_enabled=prosecution_update_enabled,
        changing_home_operator_replacement_enabled=chi_operator_enabled,
    )
    return Settings(
        nocobase=profile,
        nocobase_config_token="root-config-token",
        verify_tls=True,
        storage_cache_seconds=0,
        max_file_bytes=1024,
        allowed_mime_types=frozenset({"application/pdf"}),
        connect_timeout_seconds=1,
        request_timeout_seconds=1,
        upload_timeout_seconds=1,
        max_connections=5,
        log_level="INFO",
    )


def assert_validation_field_response(
    response: Any,
    *,
    path: str,
    code: str = "invalid_field",
    error_code: str = "validation_failed",
    message: Optional[str] = None,
) -> None:
    assert response.status_code == 422
    error = response.json()["error"]
    assert error["code"] == error_code
    assert "reason" not in error.get("details", {})
    field = error["details"]["fields"][0]
    assert field["path"] == path
    assert field["code"] == code
    assert "reason" not in field
    if message is not None:
        assert error["message"] == message
        assert field["message"] == message


def assert_update_locked_response(response: Any) -> None:
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "update_locked"
    assert response.json()["error"]["message"] == (
        "Update is allowed only while status is Accepted."
    )


def assert_accepted_business_response(
    response: Any, *, request_id: str, create_id: str, application_type: str
) -> None:
    assert response.status_code == 200
    assert response.json() == {
        "accepted": True,
        "request_id": request_id,
        "create_id": create_id,
        "status": "Accepted",
        "application_type": application_type,
    }


def test_expected_native_token_business_endpoints_are_published() -> None:
    application = create_app(settings())
    paths = application.openapi()["paths"]

    assert "/v1/auth/token" in paths
    assert "/v1/files" in paths
    assert "/v1/files/{attachment_id}" in paths
    assert "/v1/create_intake_for_new_licence" in paths
    assert "/v1/update_new_licence_data" in paths
    assert "/v1/request/{create_id}" in paths
    assert "/v1/requests/{record_id}" in paths
    assert "/v1/intakes" in paths
    assert "/v1/new-licence-applications" in paths
    assert "/v1/new-licence-checklist" in paths
    assert "/v1/create_intake_for_changing_home" in paths
    assert "/v1/update_changing_home_data" in paths
    assert "/v1/changing-home-checklist" in paths
    assert "/v1/create_intake_for_self_withdraw" in paths
    assert "/v1/update_self_withdraw_data" in paths
    assert "/v1/create_intake_for_revoke_licence" in paths
    assert "/v1/update_revoke_licence_data" in paths
    assert "/v1/self-withdraw-checklist" in paths
    assert "/v1/revoke-licence-checklist" in paths
    assert "/v1/create_intake_for_specific_hour" in paths
    assert "/v1/update_specific_hour_data" in paths
    assert "/v1/create_intake_for_rp" in paths
    assert "/v1/update_rp_data" in paths
    assert "/v1/specific-hour-checklist" in paths
    assert "/v1/rp-checklist" in paths
    assert "/v1/create_intake_for_change_home_manager" in paths
    assert "/v1/update_change_home_manager_data" in paths
    assert "/v1/create_intake_for_change_beds" in paths
    assert "/v1/update_change_beds_data" in paths
    assert "/v1/create_intake_for_change_operation_mode" in paths
    assert "/v1/update_change_operation_mode_data" in paths
    assert "/v1/create_intake_for_change_directors" in paths
    assert "/v1/update_change_directors_data" in paths
    assert "/v1/create_intake_for_change_nurse_in_charge" in paths
    assert "/v1/update_change_nurse_in_charge_data" in paths
    assert "/v1/create_intake_for_prosecution" in paths
    assert "/v1/update_prosecution_data" in paths
    assert "/v1/create_licence_renewal" in paths
    assert "/v1/update_licence_renewal_data" in paths
    assert "/v1/licence-renewal-checklist" in paths
    assert "/v1/expansion-aip-checklist" in paths
    assert "/v1/create_intake_for_expansion_aip" in paths
    assert "/v1/update_expansion_aip_data" in paths
    assert "/simple-test" in paths
    assert "/homerecord-query" in paths
    assert "/v1/storage/current" not in paths
    assert (
        "/v1/applications/{application_type}/{application_id}/attachments" not in paths
    )


def test_auth_token_preserves_native_success_without_bearer() -> None:
    application = create_app(settings())
    with TestClient(application) as client:
        application.state.client.sign_in = AsyncMock(
            return_value={"data": {"token": "native-token"}}
        )
        response = client.post(
            "/v1/auth/token",
            headers={"X-Request-ID": "auth-trace-1"},
            json={"account": "assigned-client", "password": "secret-value"},
        )
        sign_in = application.state.client.sign_in

    assert response.status_code == 200
    assert response.json() == {"data": {"token": "native-token"}}
    assert response.headers["X-Request-ID"] == "auth-trace-1"
    sign_in.assert_awaited_once_with(
        account="assigned-client",
        password="secret-value",
        request_id="auth-trace-1",
    )


def test_auth_token_does_not_expose_extra_upstream_metadata() -> None:
    application = create_app(settings())
    with TestClient(application) as client:
        application.state.client.sign_in = AsyncMock(
            return_value={
                "data": {"token": "native-token", "user": {"id": 7}},
                "meta": {"session": "internal"},
            }
        )
        response = client.post(
            "/v1/auth/token",
            json={"account": "assigned-client", "password": "secret-value"},
        )

    assert response.status_code == 200
    assert response.json() == {"data": {"token": "native-token"}}


@pytest.mark.parametrize(
    "body",
    [
        {"account": "assigned-client"},
        {"account": "assigned-client", "password": ""},
        {"account": 123, "password": "secret-value"},
        ["assigned-client", "secret-value"],
    ],
)
def test_auth_token_rejects_malformed_credentials(body: object) -> None:
    application = create_app(settings())
    with TestClient(application) as client:
        application.state.client.sign_in = AsyncMock()
        response = client.post(
            "/v1/auth/token",
            headers={"X-Request-ID": "auth-trace-2"},
            json=body,
        )
        sign_in = application.state.client.sign_in

    assert response.status_code == 400
    assert response.json() == {
        "ok": False,
        "error": {
            "code": "invalid_request",
            "message": "A JSON object with account and password is required",
            "request_id": "auth-trace-2",
        },
    }
    sign_in.assert_not_awaited()


@pytest.mark.parametrize(
    ("status", "code"),
    [(401, "authentication_failed"), (503, "service_unavailable")],
)
def test_auth_token_uses_public_error_envelope(status: int, code: str) -> None:
    application = create_app(settings())
    with TestClient(application) as client:
        application.state.client.sign_in = AsyncMock(
            side_effect=AdapterError(
                status,
                "invalid_credentials" if status == 401 else code,
                "Authentication failed",
            )
        )
        response = client.post(
            "/v1/auth/token",
            headers={"X-Request-ID": "auth-trace-3"},
            json={"account": "assigned-client", "password": "secret-value"},
        )

    assert response.status_code == status
    assert response.json() == {
        "ok": False,
        "error": {
            "code": code,
            "message": "Authentication failed",
            "request_id": "auth-trace-3",
        },
    }
    assert "secret-value" not in response.text


def test_checklist_catalog_requires_an_explicit_office_code() -> None:
    application = create_app(settings())
    operation = application.openapi()["paths"]["/v1/new-licence-checklist"]["get"]
    office_parameter = next(
        item for item in operation["parameters"] if item["name"] == "office_code"
    )

    assert office_parameter["required"] is True
    assert office_parameter["schema"]["pattern"] == r"^(LORCHE|LORCHD)$"


class FakeUploadService:
    def __init__(self) -> None:
        self.received: dict[str, Any] = {}

    async def upload_file(self, **kwargs: Any) -> FileUploadResult:
        self.received = kwargs
        content = await kwargs["upload"].read()
        return FileUploadResult(
            data_id=99,
            filename=kwargs["upload"].filename,
            size=len(content),
            download_url="/v1/files/99",
        )


class FakeAuthClient:
    def __init__(self) -> None:
        self.received_token: str | None = None
        self.webhook_calls: list[dict[str, Any]] = []
        self.staging_calls: list[dict[str, Any]] = []
        self.update_calls: list[dict[str, Any]] = []
        self.staging_response: object | None = None
        self.parent_status_after_staging_create: str | None = None
        self.parent_status_on_reservation_attempt: str | None = None
        self.update_status_after_staging_create: str | None = None
        self.created_staging_records: dict[str, dict[str, Any]] = {}
        self.original_request: dict[str, Any] = {
            "id": "384761337741312",
            "f_source_system": "OP",
            "f_request_event": "CREATE",
            "f_api_type": "create_intake_for_new_licence",
            "f_application_type": "new_licence",
            "f_office_code": "LORCHE",
            "f_status": "succeeded",
            "f_application_status": "Accepted",
            "f_intake_id": "384761337741313",
            "f_application_id": "384761337741314",
        }
        self.list_calls: list[dict[str, Any]] = []
        self.attachment_get_calls: list[dict[str, Any]] = []
        self.attachment_records: dict[int, dict[str, Any]] = {}
        self.denied_attachment_ids: set[int] = set()
        self.events: list[str] = []
        self.home_record_by_id: dict[str, dict[str, Any]] = {}
        self.home_records: list[dict[str, Any]] = [
            {
                "id": 376863288262672,
                "f_rch_no": "L0043",
                "f_final_o_no": "PE0177",
                "f_office_cd": "LORCHE",
                "fk_type_of_rch": 101,
                "fk_rch_nature": "S",
            }
        ]
        self.rch_type_options: list[dict[str, Any]] = [
            {
                "id": 101,
                "f_code": "a1",
                "f_for_office": "LORCHE",
            }
        ]
        self.rch_nature_options: list[dict[str, Any]] = [
            {
                "id": 201,
                "f_code": "PN",
                "f_enabled": True,
                "f_for_office": ["LORCHE"],
            },
            {
                "id": 202,
                "f_code": "PE",
                "f_enabled": True,
                "f_for_office": ["LORCHE"],
            },
        ]
        self.pending_update_records: list[dict[str, Any]] = []
        self.staffing_rules: list[dict[str, Any]] = [
            {
                "id": index,
                "f_office_cd": "LORCHE",
                "fk_rch_care_level": 101,
                "f_is_active": True,
                "f_minimum_required_hours": 1,
                "f_staff_ratio_requirement": f"1:{index * 10}",
                "f_sort_order": index,
                "f_staff_types_id": [{"id": index, "f_staff_code": code}],
            }
            for index, code in enumerate(("AW", "CW", "HCP"), start=1)
        ]

    async def list_records(self, **kwargs: Any) -> dict[str, Any]:
        self.list_calls.append(kwargs)
        if kwargs.get("collection") == "t_api_request_staging":
            return {
                "data": list(self.pending_update_records),
                "meta": {
                    "count": len(self.pending_update_records),
                    "page": 1,
                    "pageSize": 1,
                },
            }
        return {
            "data": list(self.home_records),
            "meta": {"count": len(self.home_records), "page": 1, "pageSize": 2},
        }

    async def list_configuration_records(self, **kwargs: Any) -> dict[str, Any]:
        if kwargs.get("collection") == "f_rch_type_options":
            rows = list(self.rch_type_options)
            return {"data": rows, "meta": {"count": len(rows)}}
        if kwargs.get("collection") == "f_rch_nature":
            code = (
                kwargs.get("filters", {})
                .get("$and", [{}])[0]
                .get("f_code", {})
                .get("$eq")
            )
            rows = [row for row in self.rch_nature_options if row.get("f_code") == code]
            return {"data": rows, "meta": {"count": len(rows)}}
        return {
            "data": list(self.staffing_rules),
            "meta": {"count": len(self.staffing_rules)},
        }

    async def check_access_token(
        self, token: str, request_id: str
    ) -> dict[str, object]:
        self.received_token = token
        return {
            "id": 42,
            "username": "op-test",
            "roleName": "external_operator",
        }

    async def trigger_business_webhook(self, **kwargs: Any) -> object:
        self.webhook_calls.append(kwargs)
        if kwargs["path"].endswith("/nyljpyltaxc"):
            return {"data": [{"f_rch_no": "L0043"}]}
        return {"ok": True, "message": "connected", "endpoint": "simple-test"}

    async def create_request_staging(self, **kwargs: Any) -> object:
        self.events.append("staging_create")
        self.staging_calls.append(kwargs)
        if self.parent_status_after_staging_create is not None:
            self.original_request["f_application_status"] = (
                self.parent_status_after_staging_create
            )
        if self.staging_response is not None:
            return self.staging_response
        record = {"id": 9001, **kwargs["values"]}
        if self.update_status_after_staging_create is not None:
            record["f_status"] = self.update_status_after_staging_create
        self.created_staging_records[str(record["id"])] = record
        return record

    async def get_record(self, **kwargs: Any) -> dict[str, Any]:
        if kwargs.get("collection") == "attachments":
            self.events.append("attachment_get")
            self.attachment_get_calls.append(kwargs)
            attachment_id = int(kwargs["record_id"])
            if attachment_id in self.denied_attachment_ids:
                raise AdapterError(403, "forbidden", "No access to attachment")
            if attachment_id not in self.attachment_records:
                raise AdapterError(404, "record_not_found", "Attachment not found")
            return self.attachment_records[attachment_id]
        if kwargs.get("collection") == "t_home_record":
            record_id = kwargs.get("record_id")
            if str(record_id) in self.home_record_by_id:
                return self.home_record_by_id[str(record_id)]
            return {
                "id": record_id,
                "f_rch_no": "L0043",
                "f_final_o_no": "PE0177",
                "f_office_cd": "LORCHE",
                "fk_type_of_rch": 101,
                "fk_rch_nature": "S",
            }
        if kwargs.get("collection") == "t_api_request_staging":
            staging = self.created_staging_records.get(str(kwargs.get("record_id")))
            if staging is not None:
                return dict(staging)
        return self.original_request

    async def update_record(self, **kwargs: Any) -> dict[str, Any]:
        self.update_calls.append(kwargs)
        return {"id": kwargs["record_id"], **kwargs["values"]}

    async def update_record_if(self, **kwargs: Any) -> dict[str, Any]:
        self.update_calls.append(kwargs)
        record_id = str(kwargs["record_id"])
        record = self.created_staging_records.get(record_id)
        if record is None and record_id == str(self.original_request["id"]):
            record = self.original_request
            if self.parent_status_on_reservation_attempt is not None:
                record["f_application_status"] = (
                    self.parent_status_on_reservation_attempt
                )
        if record is None:
            raise AssertionError(f"Unknown fake record {record_id}")
        matches = all(
            record.get(field) == value for field, value in kwargs["expected"].items()
        )
        if matches:
            record.update(kwargs["values"])
        return dict(record)

    async def open_attachment_download(self, **kwargs: Any) -> FileDownload:
        self.download_kwargs = kwargs

        async def content():
            yield b"downloaded-file"

        return FileDownload(
            content=content(),
            status_code=200,
            headers={
                "content-type": "application/pdf",
                "content-disposition": 'attachment; filename="file.pdf"',
            },
        )


class FakeChecklistCatalogQueryService:
    def __init__(self, *position_codes: str) -> None:
        self.position_codes = position_codes
        self.calls: list[dict[str, Any]] = []

    async def list_checklist_catalog(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(kwargs)
        return {
            "data": [
                {"position_code": code, "checklist_id": index + 1}
                for index, code in enumerate(self.position_codes)
            ]
        }


@pytest.mark.parametrize(
    "path",
    [
        "/v1/new-licence-checklist",
        "/v1/changing-home-checklist",
        "/v1/licence-renewal-checklist",
        "/v1/expansion-aip-checklist",
    ],
)
@pytest.mark.parametrize("office_code", ["LORCHE", "LORCHD"])
def test_licence_application_checklist_routes_share_catalogue(
    path: str, office_code: str
) -> None:
    application = create_app(settings())
    fake_catalog = FakeChecklistCatalogQueryService(f"{office_code}_APP_FILE_001")

    with TestClient(application) as client:
        application.state.client = FakeAuthClient()
        application.state.query_service = fake_catalog
        response = client.get(
            path,
            params={"office_code": office_code},
            headers={"Authorization": "Bearer valid-client-token"},
        )

    assert response.status_code == 200
    assert response.json()["data"] == [
        {"position_code": f"{office_code}_APP_FILE_001", "checklist_id": 1}
    ]
    assert len(fake_catalog.calls) == 1
    assert fake_catalog.calls[0]["office_code"] == office_code
    assert fake_catalog.calls[0].get("application_collection", "t_licence_app") == (
        "t_licence_app"
    )


@pytest.mark.parametrize(
    ("path", "error_code"),
    [
        ("/v1/new-licence-checklist", "invalid_office_code"),
        ("/v1/changing-home-checklist", "invalid_request"),
        ("/v1/licence-renewal-checklist", "invalid_office_code"),
        ("/v1/expansion-aip-checklist", "invalid_office_code"),
        ("/v1/self-withdraw-checklist", "invalid_office_code"),
        ("/v1/specific-hour-checklist", "invalid_office_code"),
        ("/v1/rp-checklist", "invalid_office_code"),
    ],
)
@pytest.mark.parametrize("office_code", [None, "INVALID"])
def test_checklist_office_code_error_matches_public_contract(
    path: str, error_code: str, office_code: Optional[str]
) -> None:
    application = create_app(settings())
    params = {} if office_code is None else {"office_code": office_code}

    with TestClient(application) as client:
        response = client.get(
            path,
            params=params,
            headers={"X-Request-ID": "checklist-office-code-1"},
        )

    assert response.status_code == 422
    assert response.json()["error"]["code"] == error_code
    assert response.json()["error"]["request_id"] == "checklist-office-code-1"
    assert response.json()["error"]["details"]["fields"][0]["path"] == (
        "office_code"
    )


def test_revoke_checklist_reuses_shared_closure_catalog() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_SELF_WITHDRAW_001")

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.get(
            "/v1/revoke-licence-checklist?office_code=LORCHE",
            headers={"Authorization": "Bearer valid-client-token"},
        )

    assert response.status_code == 200
    assert response.json()["data"][0]["position_code"] == ("LORCHE_SELF_WITHDRAW_001")
    assert len(fake_catalog.calls) == 1
    assert fake_catalog.calls[0]["office_code"] == "LORCHE"
    assert fake_catalog.calls[0]["application_collection"] == (
        "t_self_withdraw_licence_application"
    )


class FakeQueryService:
    def __init__(self) -> None:
        self.received: dict[str, Any] = {}

    async def get_new_licence_request(self, **kwargs: Any) -> dict[str, Any]:
        self.received = kwargs
        return {
            "office_code": "LORCHE",
            "application_type": {
                "value": "new_licence",
                "label": "New Licence Applications",
            },
            "status": "Acknowledged",
            "application_data": {"application_id": 7001},
            "letter_attachments": [],
        }

    async def list_notices(self, **kwargs: Any) -> list[dict[str, Any]]:
        self.notice_query = kwargs
        return [{"status": "Received"}]


def test_new_licence_request_route_uses_create_id_and_native_token() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_query_service = FakeQueryService()

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_query_service
        response = client.get(
            "/v1/request/9001",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-query-1",
            },
        )

    assert response.status_code == 200
    assert response.json()["status"] == "Acknowledged"
    assert response.json()["notices"] == [{"status": "Received"}]
    assert "letter_attachments" not in response.json()
    assert fake_client.received_token == "valid-client-token"
    assert fake_query_service.received == {
        "create_id": "9001",
        "request_id": "request-query-1",
        "authorization_token": "valid-client-token",
    }


def test_new_licence_request_route_requires_native_token() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        response = client.get("/v1/request/9001")

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "authentication_failed"


@pytest.mark.parametrize("status", [403, 404])
def test_request_query_maps_public_route_errors(status: int) -> None:
    application = create_app(settings())
    fake_query_service = FakeQueryService()
    fake_query_service.get_new_licence_request = AsyncMock(
        side_effect=AdapterError(status, "internal_error", "Sensitive upstream detail")
    )
    with TestClient(application) as client:
        application.state.client = FakeAuthClient()
        application.state.query_service = fake_query_service
        response = client.get(
            "/v1/request/9001",
            headers={"Authorization": "Bearer valid-client-token"},
        )

    assert response.status_code == status
    assert response.json()["error"]["code"] == {
        403: "request_forbidden",
        404: "create_id_not_found",
    }[status]
    assert "Sensitive upstream detail" not in response.text


def test_request_query_maps_invalid_bearer_to_generic_authentication_failure() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.check_access_token = AsyncMock(
        side_effect=AdapterError(401, "invalid_client_token", "Expired token")
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.get(
            "/v1/request/9001",
            headers={"Authorization": "Bearer expired-token"},
        )

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "authentication_failed"
    assert response.json()["error"]["message"] == "Authentication failed"


def test_file_endpoint_uses_native_token_and_verified_identity() -> None:
    application = create_app(settings())
    fake_service = FakeUploadService()
    fake_auth_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.upload_service = fake_service
        application.state.client = fake_auth_client
        response = client.post(
            "/v1/files",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-route-1",
            },
            data={"externalRequestId": "external-route-1"},
            files={
                "file": (
                    "application.pdf",
                    b"%PDF-route-test",
                    "application/pdf",
                )
            },
        )

    assert response.status_code == 200
    assert response.headers["X-Request-ID"] == "request-route-1"
    assert response.json() == {
        "data_id": 99,
        "filename": "application.pdf",
        "size": len(b"%PDF-route-test"),
        "download_url": "/v1/files/99",
    }
    assert fake_auth_client.received_token == "valid-client-token"
    assert fake_service.received["consumer_id"] == "nocobase-user:42"
    assert fake_service.received["authorization_token"] == ("valid-client-token")


def test_missing_file_uses_stable_error_envelope() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        response = client.post(
            "/v1/files",
            headers={"X-Request-ID": "request-route-2"},
        )

    assert response.status_code == 422
    assert response.json()["error"] == {
        "code": "validation_failed",
        "message": "The request contains invalid fields.",
        "request_id": "request-route-2",
        "details": {
            "fields": [
                {
                    "path": "file",
                    "code": "required",
                    "message": "Field required",
                }
            ]
        },
    }


def test_upload_requires_client_bearer_token() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        response = client.post(
            "/v1/files",
            files={
                "file": (
                    "application.pdf",
                    b"%PDF-route-test",
                    "application/pdf",
                )
            },
        )

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "authentication_failed"


def test_download_uses_returned_attachment_id_and_client_token() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.get(
            "/v1/files/99",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-download-1",
            },
        )

    assert response.status_code == 200
    assert response.content == b"downloaded-file"
    assert response.headers["content-type"] == "application/pdf"
    assert response.headers["content-disposition"] == (
        'attachment; filename="file.pdf"'
    )
    assert fake_client.download_kwargs == {
        "attachment_id": "99",
        "request_id": "request-download-1",
        "authorization_token": "valid-client-token",
        "byte_range": None,
    }


def test_download_forwards_single_byte_range_and_preserves_partial_headers() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    async def partial_download(**kwargs: Any) -> FileDownload:
        fake_client.download_kwargs = kwargs

        async def content():
            yield b"PDF"

        return FileDownload(
            content=content(),
            status_code=206,
            headers={
                "content-type": "application/pdf",
                "content-range": "bytes 0-2/99",
                "content-length": "3",
                "accept-ranges": "bytes",
            },
        )

    with TestClient(application) as client:
        fake_client.open_attachment_download = partial_download
        application.state.client = fake_client
        response = client.get(
            "/v1/files/99",
            headers={
                "Authorization": "Bearer valid-client-token",
                "Range": "bytes=0-2",
            },
        )

    assert response.status_code == 206
    assert response.content == b"PDF"
    assert response.headers["content-range"] == "bytes 0-2/99"
    assert response.headers["content-length"] == "3"
    assert fake_client.download_kwargs["byte_range"] == "bytes=0-2"


@pytest.mark.parametrize(
    "range_value", ["bytes=10-9", "bytes=-0", "bytes=0-1,3-4", "items=0-1"]
)
def test_download_rejects_invalid_byte_range(range_value: str) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.get(
            "/v1/files/99",
            headers={
                "Authorization": "Bearer valid-client-token",
                "Range": range_value,
            },
        )

    assert response.status_code == 400
    assert response.json()["error"]["code"] == "invalid_range"
    assert not hasattr(fake_client, "download_kwargs")


def test_download_maps_forbidden_to_attachment_forbidden() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.open_attachment_download = AsyncMock(
        side_effect=AdapterError(
            403, "nocobase_permission_denied", "Internal collection"
        )
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.get(
            "/v1/files/99",
            headers={"Authorization": "Bearer valid-client-token"},
        )

    assert response.status_code == 403
    assert response.json()["error"]["code"] == "attachment_forbidden"
    assert "Internal collection" not in response.text


def test_download_requires_client_bearer_token() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        response = client.get("/v1/files/99")

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "authentication_failed"


def test_download_rejects_invalid_attachment_id() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        response = client.get(
            "/v1/files/not%20valid",
            headers={"Authorization": "Bearer valid-client-token"},
        )

    assert response.status_code == 422
    assert response.json()["error"]["code"] == "validation_failed"
    assert response.json()["error"]["details"]["fields"][0]["code"] == ("invalid_field")


def test_simple_test_validates_and_forwards_client_identity() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/simple-test",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-simple-1",
            },
        )

    assert response.status_code == 200
    assert response.json() == {
        "ok": True,
        "message": "connected",
        "endpoint": "simple-test",
    }
    assert fake_client.received_token == "valid-client-token"
    assert fake_client.webhook_calls == [
        {
            "path": settings().nocobase.api.simple_test,
            "request_id": "request-simple-1",
            "authorization_token": "valid-client-token",
        }
    ]


def test_homerecord_query_forwards_allowed_filters_and_client_token() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/homerecord-query",
            params={
                "officeCode": "LORCHE",
                "rchStatus": "ACTIVE",
                "rchNo": "L0043",
            },
            headers={"Authorization": "Bearer valid-client-token"},
        )

    assert response.status_code == 200
    assert response.json() == {"data": [{"f_rch_no": "L0043"}]}
    assert fake_client.webhook_calls[0]["params"] == [
        ("officeCode", "LORCHE"),
        ("rchStatus", "ACTIVE"),
        ("rchNo", "L0043"),
    ]
    assert fake_client.webhook_calls[0]["authorization_token"] == ("valid-client-token")


def test_business_routes_reject_missing_client_token() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        simple_response = client.post("/simple-test")
        home_response = client.post("/homerecord-query")

    assert simple_response.status_code == 401
    assert home_response.status_code == 401
    assert simple_response.json()["error"]["code"] == "authentication_failed"
    assert home_response.json()["error"]["code"] == "authentication_failed"


def valid_new_licence_payload() -> dict[str, Any]:
    address = {
        "region_code": "0",
        "district_code": "C",
        "sub_district_code": "Admiralty",
        "full_name_en": "1 Test Road, Admiralty, Hong Kong",
        "full_name_cn": "香港金鐘測試道一號",
    }
    return {
        "request_id": "NLA-20260903-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
            },
            "part_1": {
                "application_received_date": "2026-09-03",
                "tentative_commencement_date": "2026-12-01",
            },
            "part_2": {
                "rch_name_en": "Acceptance Test RCH",
                "rch_name_cn": "驗收測試院舍",
                "operation_mode_id": 1,
                "premises_type": "0",
                "monthly_fee_min": 8000,
                "monthly_fee_max": 12000,
                "gender": "1",
                "floor_area_sqm": 380.5,
                "licence_capacity": 48,
                "address": address,
                "rch_type_code": "a1",
                "nursing_home_places": 12,
                "care_and_attention_home_places": 12,
                "aged_home_places": 12,
                "self_care_hostel_places": 12,
                "premises": {
                    "self_owned": [
                        {
                            "premise_type": "0",
                            "location": "Hong Kong",
                            "tenancy_from": "2026-01-01",
                            "tenancy_to": "2036-12-31",
                            "address": address.copy(),
                        }
                    ],
                    "rented": [],
                },
            },
            "part_3": {
                "rch_business_status": "0",
                "applicant_operator_type": "0",
                "operator": {"full_name_en": "Test Operator"},
                "personnel": [],
            },
            "part_4": {
                "authorised_representative": {"full_name_en": "Test Representative"}
            },
            "part_5": {
                "application_level": "normal",
                "checklist": [],
            },
        },
    }


def test_create_new_licence_stores_request_and_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-nla-route-1",
            },
            json=valid_new_licence_payload(),
        )

    assert_accepted_business_response(
        response,
        request_id="NLA-20260903-0001",
        create_id="9001",
        application_type="new_licence",
    )
    assert fake_client.received_token == "valid-client-token"
    expected_body = valid_new_licence_payload()
    expected_body["form_data"]["part_1"]["application_type"] = "0"
    expected_staging_values = {
        "f_request_body": expected_body,
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_user_role": "external_operator",
        "f_status": "submitted",
        "f_application_type": "new_licence",
        "f_office_code": "LORCHE",
        "f_application_status": "Accepted",
    }
    assert fake_client.staging_calls == [
        {
            "request_id": "request-nla-route-1",
            "authorization_token": "valid-client-token",
            "values": expected_staging_values,
        }
    ]


def test_create_new_licence_preflights_checklist_before_runnable_staging() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.attachment_records[502] = {"id": 502}
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_NLA_001")
    payload = valid_new_licence_payload()
    payload["form_data"]["part_5"]["checklist"] = [
        {"position_code": "LORCHE_NLA_001", "attachment_id": 502}
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 200
    assert fake_catalog.calls[0]["office_code"] == "LORCHE"
    assert fake_catalog.calls[0]["application_collection"] == "t_licence_app"
    assert fake_client.attachment_get_calls[0]["record_id"] == 502
    assert fake_client.attachment_get_calls[0]["authorization_token"] == (
        "valid-client-token"
    )
    assert fake_client.events == ["attachment_get", "staging_create"]
    assert fake_client.staging_calls[0]["values"]["f_status"] == "submitted"


@pytest.mark.parametrize(
    ("catalogue_code", "expected_field", "expected_error", "expected_code"),
    [
        (
            "OTHER_OFFICE_NLA_001",
            "form_data.part_5.checklist.0.position_code",
            "The position_code is not in the office-specific checklist",
            "invalid_checklist_item",
        ),
        (
            "LORCHE_NLA_001",
            "form_data.part_5.checklist.0.attachment_id",
            "The uploaded attachment was not found or is not accessible",
            "missing_document",
        ),
    ],
)
def test_create_new_licence_checklist_preflight_rejects_without_business_flow(
    catalogue_code: str,
    expected_field: str,
    expected_error: str,
    expected_code: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService(catalogue_code)
    payload = valid_new_licence_payload()
    payload["form_data"]["part_5"]["checklist"] = [
        {"position_code": "LORCHE_NLA_001", "attachment_id": 502}
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert_validation_field_response(
        response,
        path=expected_field,
        message=expected_error,
        error_code=expected_code,
    )
    assert len(fake_client.staging_calls) == 1
    staged = fake_client.staging_calls[0]["values"]
    assert staged["f_status"] == "invalid_request"
    assert staged["f_error_message"] in {
        "invalid_checklist_item",
        "missing_document",
    }
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_create_new_licence_checklist_preflight_respects_caller_permissions() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.denied_attachment_ids.add(502)
    payload = valid_new_licence_payload()
    payload["form_data"]["part_5"]["checklist"] = [
        {"position_code": "LORCHE_NLA_001", "attachment_id": 502}
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = FakeChecklistCatalogQueryService(
            "LORCHE_NLA_001"
        )
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_validation_field_response(
        response,
        path="form_data.part_5.checklist.0.attachment_id",
        message="The uploaded attachment was not found or is not accessible",
        error_code="missing_document",
    )
    assert fake_client.attachment_get_calls[0]["authorization_token"] == (
        "valid-client-token"
    )
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_new_licence_does_not_require_client_personnel_ids() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    for field in (
        "submitter_user_id",
        "task_owner_user_id",
        "task_owner_post_code",
    ):
        payload["form_data"]["case_summary"].pop(field, None)
    payload["form_data"]["part_5"].pop("attachment_ids", None)

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="NLA-20260903-0001",
        create_id="9001",
        application_type="new_licence",
    )
    staged_summary = fake_client.staging_calls[0]["values"]["f_request_body"][
        "form_data"
    ]["case_summary"]
    assert staged_summary == {"office_code": "LORCHE"}
    staged_part_5 = fake_client.staging_calls[0]["values"]["f_request_body"][
        "form_data"
    ]["part_5"]
    assert "attachment_ids" not in staged_part_5


def test_update_new_licence_stages_full_form_using_create_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260904-0001",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {"received_date": "2026-09-04"},
            "part_2": {"rch_name_en": "Updated RCH Name"},
        },
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-nla-update-1",
            },
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="NLA-UPDATE-20260904-0001",
        create_id="384761337741312",
        application_type="new_licence",
    )
    assert fake_client.staging_calls == [
        {
            "request_id": "request-nla-update-1",
            "authorization_token": "valid-client-token",
            "values": {
                "f_request_body": payload,
                "f_source_system": "OP",
                "f_request_event": "UPDATE",
                "f_api_type": "update_new_licence_data",
                "f_user_role": "external_operator",
                "f_status": "submitted",
                "f_application_type": "new_licence",
                "f_office_code": "LORCHE",
                "f_application_status": None,
                "f_parent_create_id": "384761337741312",
            },
        }
    ]


def test_portable_release_does_not_fall_back_to_legacy_update() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-PORTABLE-QUEUE-OFF-0001",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"rch_name_en": "Updated RCH Name"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.portable_release = True
        application.state.update_queue_application_types = frozenset()
        application.state.update_queue_service = None
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 503
    assert response.json()["error"]["code"] == "update_queue_not_ready"
    assert fake_client.staging_calls == []


def test_fifo_only_target_does_not_acknowledge_direct_update(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("UPDATE_QUEUE_REQUIRED", "1")
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-FIFO-REQUIRED-0001",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"rch_name_en": "Updated RCH Name"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 503
    assert response.json()["error"]["code"] == "update_queue_not_ready"
    assert fake_client.staging_calls == []


@pytest.mark.parametrize(
    "form_data",
    [
        {"part_3": {"personnel": []}},
        {"part_3": {"personnel": [{"full_name_en": "Person One"}]}},
        {"part_2": {"premises": {"self_owned": []}}},
        {"part_2": {"premises": {"rented": []}}},
    ],
)
def test_update_new_licence_stages_complete_child_replacement_for_async_worker(
    form_data: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-REPLACE-1",
        "create_id": "384761337741312",
        "form_data": form_data,
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="NLA-UPDATE-REPLACE-1",
        create_id="384761337741312",
        application_type="new_licence",
    )
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_request_event"] == "UPDATE"
    assert fake_client.staging_calls[0]["values"]["f_request_body"] == payload


@pytest.mark.parametrize(
    "form_data",
    [
        {"part_3": {"personnel": []}},
        {"part_2": {"premises": {"self_owned": []}}},
        {"part_2": {"premises": {"rented": []}}},
        {"part_2": {"premises": {"self_owned": [{
            "premise_type": "0",
            "tenancy_from": "2026-01-01",
            "tenancy_to": "2027-01-01",
            "address": {
                "region_code": "R", "district_code": "D",
                "sub_district_code": "S",
            },
        }]}}},
    ],
)
def test_nla_queue_opt_in_accepts_id_free_child_replacement(
    form_data: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    queued = AsyncMock()
    payload = {
        "request_id": "NLA-UPDATE-REPLACE-QUEUED-1",
        "create_id": "384761337741312",
        "form_data": form_data,
    }
    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.update_queue_application_types = frozenset({"new_licence"})
        application.state.update_queue_service = SimpleNamespace(admit_update=queued)
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert_accepted_business_response(
        response,
        request_id="NLA-UPDATE-REPLACE-QUEUED-1",
        create_id="384761337741312",
        application_type="new_licence",
    )
    assert queued.await_count == 1
    assert queued.await_args.kwargs["request_body"] == payload
    assert fake_client.staging_calls == []


@pytest.mark.parametrize(
    ("create_status", "intake_id", "application_id"),
    [
        ("submitted", None, None),
        ("processing", "384761337741313", "384761337741314"),
        ("succeeded", None, "384761337741314"),
        ("succeeded", "384761337741313", None),
    ],
)
def test_update_new_licence_rejects_before_create_is_ready(
    create_status: str,
    intake_id: Optional[str],
    application_id: Optional[str],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_status": create_status,
            "f_intake_id": intake_id,
            "f_application_id": application_id,
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "NLA-UPDATE-CREATE-NOT-READY",
                "create_id": "384761337741312",
                "form_data": {"part_2": {"rch_name_en": "Updated Home"}},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "create_not_ready"
    assert response.json()["error"]["details"] == {
        "field": "create_id",
        "status": create_status,
    }
    assert fake_client.staging_calls == []


def test_opt_in_queue_accepts_update_while_create_is_pending() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {"f_status": "submitted", "f_intake_id": None, "f_application_id": None}
    )
    queued = AsyncMock()
    payload = {
        "request_id": "NLA-UPDATE-QUEUED-1",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"rch_name_en": "Updated Home"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.update_queue_application_types = frozenset({"new_licence"})
        application.state.update_queue_service = SimpleNamespace(admit_update=queued)
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="NLA-UPDATE-QUEUED-1",
        create_id="384761337741312",
        application_type="new_licence",
    )
    assert fake_client.staging_calls == []
    assert queued.await_count == 1
    assert queued.await_args.kwargs["authorization_token"] == "valid-client-token"
    assert queued.await_args.kwargs["family"].update_api_type == (
        "update_new_licence_data"
    )


def test_queue_service_cannot_affect_family_outside_exact_allowlist() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {"f_status": "submitted", "f_intake_id": None, "f_application_id": None}
    )
    queued = AsyncMock()

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.update_queue_service = SimpleNamespace(admit_update=queued)
        assert application.state.update_queue_application_types == frozenset()
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "NLA-UPDATE-QUEUE-NOT-ALLOWLISTED",
                "create_id": "384761337741312",
                "form_data": {"part_2": {"rch_name_en": "Updated Home"}},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "create_not_ready"
    queued.assert_not_awaited()


def test_queue_family_allowlist_is_parsed_but_does_not_enable_runtime(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("UPDATE_QUEUE_APPLICATION_TYPES", "new_licence")
    application = create_app(settings())
    with TestClient(application):
        assert application.state.update_queue_application_types == frozenset(
            {"new_licence"}
        )
        assert application.state.update_queue_service is None


def test_opt_in_queue_routes_received_update_to_audit_before_same_409() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request["f_application_status"] = "Received"
    queued = AsyncMock(
        side_effect=AdapterError(
            409,
            "update_locked",
            "Update is allowed only while status is Accepted.",
            details={"field": "create_id", "status": "Received"},
        )
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.update_queue_application_types = frozenset({"new_licence"})
        application.state.update_queue_service = SimpleNamespace(admit_update=queued)
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "NLA-UPDATE-LOCKED-QUEUE-1",
                "create_id": "384761337741312",
                "form_data": {"part_2": {"rch_name_en": "Must not be applied"}},
            },
        )

    assert_update_locked_response(response)
    assert response.json()["error"]["details"] == {
        "field": "create_id",
        "status": "Received",
    }
    assert queued.await_count == 1
    assert fake_client.staging_calls == []


def test_opt_in_queue_fails_startup_while_native_boundary_is_blocked(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("UPDATE_QUEUE_ENABLED", "1")
    application = create_app(settings())
    with pytest.raises(RuntimeError, match="UPDATE queue release is blocked"):
        with TestClient(application):
            pass


def test_nla_queue_pilot_requires_exact_local_28443_13001_binding(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    pilot_settings = settings()
    pilot_settings = replace(
        pilot_settings,
        nocobase=replace(
            pilot_settings.nocobase,
            base_url="http://119.91.104.211:13001/cmtf2",
        ),
    )
    client = NocoBaseClient(pilot_settings)
    monkeypatch.setenv("UPDATE_QUEUE_ENABLED", "1")
    monkeypatch.setenv("DEPLOYMENT_ENV", "local_test")
    monkeypatch.setenv("KONG_HTTPS_BIND", "127.0.0.1")
    monkeypatch.setenv("KONG_HTTPS_PORT", "28443")
    monkeypatch.setenv(
        "UPDATE_QUEUE_NLA_PILOT_CONFIRM",
        "LOCAL_13001_NLA_FIFO_PILOT_20261016_"
        "c988c590038a73dec9d963140328a327",
    )
    exact_family = frozenset({"new_licence"})
    candidate = _update_queue_service_from_env(client, pilot_settings, exact_family)
    assert candidate is not None
    assert candidate._pilot_nla_test_mode is True

    for changed_env, value in (
        ("DEPLOYMENT_ENV", "online_test"),
        ("KONG_HTTPS_BIND", "0.0.0.0"),
        ("KONG_HTTPS_PORT", "443"),
        ("UPDATE_QUEUE_NLA_PILOT_CONFIRM", "wrong"),
    ):
        with monkeypatch.context() as isolated:
            isolated.setenv(changed_env, value)
            with pytest.raises(RuntimeError, match="only exact local 13001 NLA pilot"):
                _update_queue_service_from_env(client, pilot_settings, exact_family)

    with pytest.raises(RuntimeError, match="only exact local 13001 NLA pilot"):
        _update_queue_service_from_env(
            client,
            pilot_settings,
            frozenset({"new_licence", "licence_renewal"}),
        )
    wrong_upstream = replace(
        pilot_settings,
        nocobase=replace(pilot_settings.nocobase, base_url="http://host.docker.internal:13000/cmtf2"),
    )
    with pytest.raises(RuntimeError, match="only exact local 13001 NLA pilot"):
        _update_queue_service_from_env(client, wrong_upstream, exact_family)


def test_lrn_queue_pilot_requires_exact_local_profile_and_single_family(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    pilot_settings = replace(
        settings(lrn_update_enabled=True),
        nocobase=replace(
            settings(lrn_update_enabled=True).nocobase,
            base_url="http://119.91.104.211:13001/cmtf2",
        ),
    )
    client = NocoBaseClient(pilot_settings)
    monkeypatch.setenv("UPDATE_QUEUE_ENABLED", "1")
    monkeypatch.setenv("DEPLOYMENT_ENV", "local_test")
    monkeypatch.setenv("KONG_HTTPS_BIND", "127.0.0.1")
    monkeypatch.setenv("KONG_HTTPS_PORT", "28443")
    monkeypatch.setenv(
        "UPDATE_QUEUE_LRN_PILOT_CONFIRM",
        "LOCAL_13001_LRN_FIFO_PILOT_20261017_"
        "b69f4d21a8e75c0d6e4b8f39962a31c5",
    )
    exact_family = frozenset({"licence_renewal"})
    candidate = _update_queue_service_from_env(client, pilot_settings, exact_family)
    assert candidate is not None
    assert candidate._pilot_lrn_test_mode is True
    assert candidate._pilot_nla_test_mode is False

    for changed_env, value in (
        ("DEPLOYMENT_ENV", "online_test"),
        ("KONG_HTTPS_BIND", "0.0.0.0"),
        ("KONG_HTTPS_PORT", "443"),
        ("UPDATE_QUEUE_LRN_PILOT_CONFIRM", "wrong"),
        ("UPDATE_QUEUE_NLA_PILOT_CONFIRM", "conflicting"),
    ):
        with monkeypatch.context() as isolated:
            isolated.setenv(changed_env, value)
            with pytest.raises(RuntimeError, match="only exact local 13001"):
                _update_queue_service_from_env(client, pilot_settings, exact_family)
    for families in (
        frozenset({"new_licence"}),
        frozenset({"new_licence", "licence_renewal"}),
    ):
        with pytest.raises(RuntimeError, match="only exact local 13001"):
            _update_queue_service_from_env(client, pilot_settings, families)
    closed_feature = replace(
        pilot_settings,
        nocobase=replace(
            pilot_settings.nocobase, licence_renewal_update_enabled=False
        ),
    )
    with pytest.raises(RuntimeError, match="only exact local 13001"):
        _update_queue_service_from_env(client, closed_feature, exact_family)
    wrong_upstream = replace(
        pilot_settings,
        nocobase=replace(
            pilot_settings.nocobase,
            base_url="http://host.docker.internal:13000/cmtf2",
        ),
    )
    with pytest.raises(RuntimeError, match="only exact local 13001"):
        _update_queue_service_from_env(client, wrong_upstream, exact_family)


def test_update_new_licence_is_locked_after_submitted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request["f_application_status"] = "Received"
    payload = {
        "request_id": "NLA-UPDATE-LOCKED-1",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"rch_name_en": "Must not be applied"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "update_locked"
    assert response.json()["error"]["message"] == (
        "Update is allowed only while status is Accepted."
    )
    assert fake_client.staging_calls == []


def test_update_new_licence_lock_precedes_child_replacement_guard() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request["f_application_status"] = "Received"
    payload = {
        "request_id": "NLA-UPDATE-LOCKED-REPLACE-1",
        "create_id": "384761337741312",
        "form_data": {"part_3": {"personnel": []}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "update_locked"
    assert fake_client.staging_calls == []


def test_update_new_licence_rejects_non_op_create_request() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request["f_source_system"] = "CMTF"
    payload = {
        "request_id": "NLA-UPDATE-CMTF-1",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"rch_name_en": "Must not be applied"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 404
    assert response.json()["error"]["code"] == "request_not_found"
    assert response.json()["error"]["message"] == "The create request was not found"
    assert fake_client.staging_calls == []


def test_update_new_licence_requires_create_id_and_stages_rejection() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260904-0002",
        "form_data": {"part_2": {"rch_name_en": "Updated RCH Name"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["accepted"] is False
    assert result["status"] == "missing_required"
    assert result["create_id"] is None
    assert "update_id" not in result
    assert "staging_record_id" not in result
    assert result["missing_required_fields"] == ["create_id"]
    assert fake_client.staging_calls[0]["values"]["f_status"] == ("missing_required")
    assert fake_client.staging_calls[0]["values"]["f_request_event"] == ("UPDATE")
    assert fake_client.staging_calls[0]["values"]["f_application_type"] == (
        "new_licence"
    )
    assert fake_client.staging_calls[0]["values"]["f_office_code"] is None
    assert fake_client.staging_calls[0]["values"]["f_application_status"] is None


def test_update_new_licence_preserves_explicit_null_as_a_change() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260904-CLEAR-1",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"telephone_no": None}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 200
    staged_body = fake_client.staging_calls[0]["values"]["f_request_body"]
    assert "telephone_no" in staged_body["form_data"]["part_2"]
    assert staged_body["form_data"]["part_2"]["telephone_no"] is None


def test_update_new_licence_rejects_changed_office_code_without_staging() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260908-OFFICE-1",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {"office_code": "LORCHD"},
            "part_2": {"telephone_no": "21239999"},
        },
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["error"]["code"] == "validation_failed"
    assert response.json()["error"]["details"]["fields"][0]["path"] == (
        "form_data.case_summary.office_code"
    )
    assert fake_client.staging_calls == []


def test_update_new_licence_accepts_unchanged_office_code() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260908-OFFICE-2",
        "create_id": "384761337741312",
        "form_data": {
            "case_summary": {"office_code": "LORCHE"},
            "part_2": {"telephone_no": "21239999"},
        },
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 200
    assert fake_client.staging_calls[0]["values"]["f_office_code"] == "LORCHE"


def test_update_new_licence_rejects_unchanged_office_only() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260908-OFFICE-3",
        "create_id": "384761337741312",
        "form_data": {"case_summary": {"office_code": "LORCHE"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["accepted"] is False
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"
    assert fake_client.staging_calls[0]["values"]["f_request_event"] == "UPDATE"


def test_update_new_licence_rejects_rch_type_for_different_office() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260908-TYPE-1",
        "create_id": "384761337741312",
        "form_data": {"part_2": {"rch_type_code": "b1"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["error"]["code"] == "validation_failed"
    assert response.json()["error"]["details"]["fields"][0]["path"] == (
        "form_data.part_2.rch_type_code"
    )
    assert fake_client.staging_calls == []


def test_update_new_licence_rejects_empty_nested_form_data() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "NLA-UPDATE-20260904-EMPTY-1",
        "create_id": "384761337741312",
        "form_data": {"part_2": {}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "invalid_request"
    assert result["validation_errors"][0]["path"] == "form_data"
    assert result["validation_errors"][0]["code"] == "invalid_field"
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"
    assert fake_client.staging_calls[0]["values"]["f_application_type"] == (
        "new_licence"
    )
    assert fake_client.staging_calls[0]["values"]["f_office_code"] is None
    assert fake_client.staging_calls[0]["values"]["f_application_status"] is None


def test_create_new_licence_rejects_missing_required_business_field() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    del payload["form_data"]["part_2"]["rch_name_en"]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-nla-missing-1",
            },
            json=payload,
        )

    assert response.status_code == 422
    assert response.json() == {
        "ok": False,
        "accepted": False,
        "request_id": "NLA-20260903-0001",
        "status": "missing_required",
        "missing_required_fields": ["form_data.part_2.rch_name_en"],
        "validation_errors": [
            {
                "path": "form_data.part_2.rch_name_en",
                "code": "required",
                "message": "Field required",
            }
        ],
        "error": {
            "code": "validation_failed",
            "message": "The request contains invalid fields.",
            "request_id": "request-nla-missing-1",
            "details": {
                "fields": [
                    {
                        "path": "form_data.part_2.rch_name_en",
                        "code": "required",
                        "message": "Field required",
                    }
                ]
            },
        },
    }
    assert fake_client.staging_calls == [
        {
            "request_id": "request-nla-missing-1",
            "authorization_token": "valid-client-token",
            "values": {
                "f_request_body": payload,
                "f_source_system": "OP",
                "f_request_event": "CREATE",
                "f_api_type": "create_intake_for_new_licence",
                "f_user_role": "external_operator",
                "f_status": "missing_required",
                "f_application_type": "new_licence",
                "f_office_code": "LORCHE",
                "f_application_status": None,
            },
        }
    ]


def test_create_new_licence_reports_every_missing_required_field() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    del payload["request_id"]
    required_nested_fields = {
        "case_summary": [
            "office_code",
        ],
        "part_1": ["application_received_date", "tentative_commencement_date"],
        "part_2": [
            "rch_name_en",
            "rch_name_cn",
            "operation_mode_id",
            "premises_type",
            "monthly_fee_min",
            "monthly_fee_max",
            "gender",
            "floor_area_sqm",
            "licence_capacity",
            "address",
            "rch_type_code",
            "nursing_home_places",
            "care_and_attention_home_places",
            "aged_home_places",
            "self_care_hostel_places",
            "premises",
        ],
        "part_3": ["rch_business_status", "applicant_operator_type"],
        "part_5": ["application_level"],
    }
    for section, fields in required_nested_fields.items():
        for field in fields:
            del payload["form_data"][section][field]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "missing_required"
    assert set(result["missing_required_fields"]) == {
        "request_id",
        "form_data.case_summary.office_code",
        "form_data.part_1.application_received_date",
        "form_data.part_1.tentative_commencement_date",
        "form_data.part_2.rch_name_en",
        "form_data.part_2.rch_name_cn",
        "form_data.part_2.operation_mode_id",
        "form_data.part_2.premises_type",
        "form_data.part_2.monthly_fee_min",
        "form_data.part_2.monthly_fee_max",
        "form_data.part_2.gender",
        "form_data.part_2.floor_area_sqm",
        "form_data.part_2.licence_capacity",
        "form_data.part_2.address",
        "form_data.part_2.rch_type_code",
        "form_data.part_2.nursing_home_places",
        "form_data.part_2.care_and_attention_home_places",
        "form_data.part_2.aged_home_places",
        "form_data.part_2.self_care_hostel_places",
        "form_data.part_2.premises",
        "form_data.part_3.rch_business_status",
        "form_data.part_3.applicant_operator_type",
        "form_data.part_5.application_level",
    }
    assert fake_client.staging_calls[0]["values"]["f_status"] == ("missing_required")
    assert fake_client.staging_calls[0]["values"]["f_application_type"] == (
        "new_licence"
    )
    assert fake_client.staging_calls[0]["values"]["f_office_code"] is None
    assert fake_client.staging_calls[0]["values"]["f_application_status"] is None


def test_create_new_licence_rejects_client_supplied_intake_type() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    payload["form_data"]["case_summary"]["intake_type_id"] = 364490020880384

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert response.json()["missing_required_fields"] == []
    assert response.json()["validation_errors"] == [
        {
            "path": "form_data.case_summary.intake_type_id",
            "code": "invalid_field",
            "message": "Extra inputs are not permitted",
        }
    ]
    assert fake_client.staging_calls[0]["values"]["f_status"] == ("invalid_request")
    assert fake_client.staging_calls[0]["values"]["f_request_body"] == (payload)


def test_create_new_licence_rejects_unknown_office_code_without_staging_it() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    payload["form_data"]["case_summary"]["office_code"] = "OTHER"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "invalid_request"
    assert result["validation_errors"][0]["path"] == (
        "form_data.case_summary.office_code"
    )
    staged_values = fake_client.staging_calls[0]["values"]
    assert staged_values["f_application_type"] == "new_licence"
    assert staged_values["f_office_code"] is None
    assert staged_values["f_application_status"] is None


def test_create_new_licence_rejects_external_application_reference_fields() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    payload["form_data"]["part_1"]["application_ref"] = "APP-REF-001"
    payload["form_data"]["part_1"]["d_no"] = "D-001"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "invalid_request"
    assert {error["path"] for error in result["validation_errors"]} == {
        "form_data.part_1.application_ref",
        "form_data.part_1.d_no",
    }
    assert {error["code"] for error in result["validation_errors"]} == {"invalid_field"}


def test_create_new_licence_rejects_client_supplied_recommendation() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    payload["form_data"]["part_5"]["recommendation"] = "accept"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "invalid_request"
    assert result["validation_errors"][0]["path"] == ("form_data.part_5.recommendation")


def test_create_new_licence_checklist_accepts_only_uploaded_attachment_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    payload["form_data"]["part_5"]["checklist"] = [
        {"position_code": "LORCHE_NLA_001", "attachment_id": 502}
    ]
    checklist_item = payload["form_data"]["part_5"]["checklist"][0]
    checklist_item["file_ids"] = [502]
    checklist_item["latest_file_name"] = "client-supplied-name.pdf"
    checklist_item["latest_file_date"] = "2026-09-04"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "invalid_request"
    assert {error["path"] for error in result["validation_errors"]} == {
        "form_data.part_5.checklist.0.file_ids",
        "form_data.part_5.checklist.0.latest_file_name",
        "form_data.part_5.checklist.0.latest_file_date",
    }


def test_create_new_licence_requires_checklist_attachment_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    payload["form_data"]["part_5"]["checklist"] = [
        {"position_code": "LORCHE_NLA_001", "attachment_id": 502}
    ]
    del payload["form_data"]["part_5"]["checklist"][0]["attachment_id"]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "missing_required"
    assert result["missing_required_fields"] == [
        "form_data.part_5.checklist.0.attachment_id"
    ]


def test_create_new_licence_rejects_address_select_or_address_record_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_new_licence_payload()
    address = payload["form_data"]["part_2"]["address"]
    address["address_select"] = 384610600419332
    address["id"] = 384610600419333

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    result = response.json()
    assert result["status"] == "invalid_request"
    assert result["missing_required_fields"] == []
    assert result["validation_errors"] == [
        {
            "path": "form_data.part_2.address.address_select",
            "code": "invalid_field",
            "message": "Extra inputs are not permitted",
        },
        {
            "path": "form_data.part_2.address.id",
            "code": "invalid_field",
            "message": "Extra inputs are not permitted",
        },
    ]
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_new_licence_requires_client_token() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        response = client.post(
            "/v1/create_intake_for_new_licence",
            json=valid_new_licence_payload(),
        )

    assert response.status_code == 401
    assert response.json()["error"]["code"] == "authentication_failed"


def test_create_new_licence_rejects_staging_response_without_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.staging_response = {}

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_new_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_new_licence_payload(),
        )

    assert response.status_code == 502
    assert response.json()["error"]["code"] == "invalid_staging_create_response"


def valid_changing_home_payload() -> dict[str, Any]:
    return {
        "request_id": "CHI-20260914-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "rch_no": "l0043",
            },
            "is_change_name": True,
            "part_2": {"rch_name_en": "Updated RCH name"},
        },
    }


def chi_name_update(name: str) -> dict[str, Any]:
    return {
        "is_change_name": True,
        "part_2": {"rch_name_en": name},
    }


def test_create_changing_home_resolves_home_record_and_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-chi-create-1",
            },
            json=valid_changing_home_payload(),
        )

    assert_accepted_business_response(
        response,
        request_id="CHI-20260914-0001",
        create_id="9001",
        application_type="changing_home",
    )
    assert fake_client.list_calls[0]["collection"] == "t_home_record"
    assert fake_client.list_calls[0]["filters"] == {
        "$and": [
            {"f_rch_no": {"$eq": "L0043"}},
            {"f_office_cd": {"$eq": "LORCHE"}},
        ]
    }
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.staging_calls[0]["values"]["f_application_status"] == "Accepted"
    assert fake_client.staging_calls[0]["values"]["f_status"] == "submitted"
    assert "f_chi_address_requested" not in fake_client.staging_calls[0]["values"]


def test_create_changing_home_does_not_require_personnel_ids() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    summary = payload["form_data"]["case_summary"]
    for key in ("submitter_user_id", "task_owner_user_id", "task_owner_post_code"):
        summary.pop(key, None)

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 200
    staged_form = fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]
    staged_summary = staged_form["case_summary"]
    assert staged_summary["rch_no"] == "l0043"
    personnel_keys = {
        "submitter_user_id",
        "task_owner_user_id",
        "task_owner_post_code",
    }
    assert personnel_keys.isdisjoint(staged_summary)


def test_create_changing_home_rejects_prior_create_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["create_id"] = "prior-create-id"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert any(
        item["path"] == "create_id" for item in response.json()["validation_errors"]
    )
    assert fake_client.list_calls == []
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize("alternative", ["lorche_d_no", "p_no"])
def test_create_changing_home_requires_rch_no_even_with_other_reference(
    alternative: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    summary = payload["form_data"]["case_summary"]
    del summary["rch_no"]
    summary[alternative] = "PE0177" if alternative == "p_no" else "L0043"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "missing_required"
    assert "form_data.case_summary.rch_no" in response.json()["missing_required_fields"]
    assert fake_client.list_calls == []


def test_chi_create_does_not_fall_back_to_p_no_when_rch_no_is_unresolved() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.home_records = []
    payload = valid_changing_home_payload()
    payload["form_data"]["case_summary"].update({"rch_no": "UNKNOWN", "p_no": "PE0177"})
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert len(fake_client.list_calls) == 1
    assert fake_client.list_calls[0]["filters"] == {
        "$and": [
            {"f_rch_no": {"$eq": "UNKNOWN"}},
            {"f_office_cd": {"$eq": "LORCHE"}},
        ]
    }


def test_create_changing_home_rejects_unknown_home_record() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.home_records = []

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_changing_home_payload(),
        )

    assert response.status_code == 422
    body = response.json()
    assert body["status"] == "invalid_request"
    assert_validation_field_response(
        response,
        path="form_data.case_summary",
        message="No matching Home Record was found",
    )
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_changing_home_requires_a_change_category() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"]["is_change_name"] = False

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"


@pytest.mark.parametrize(
    ("flag", "section"),
    [
        ("is_change_name", {"part_2": {"rch_name_en": "New RCH"}}),
        ("is_change_address", {"part_2": {"address": {"street_name_en": "Street"}}}),
        (
            "is_change_operator_or_operating_company",
            {
                "part_3": {
                    "applicant_operator_type": "2",
                    "company": {"company_name_en": "Company"},
                }
            },
        ),
        ("is_change_rch_type", {"part_2": {"rch_type_code": "a1"}}),
        ("is_change_maximum_capacity", {"part_2": {"max_capacity": 80}}),
    ],
)
def test_chi_change_flag_requires_matching_section(
    flag: str, section: dict[str, Any]
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"] = {
        "case_summary": payload["form_data"]["case_summary"],
        flag: True,
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        missing = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
        payload["form_data"].update(section)
        valid = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert missing.status_code == 422
    assert valid.status_code == 200
    submitted = [
        call["values"]
        for call in fake_client.staging_calls
        if call["values"]["f_status"] == "submitted"
    ]
    assert len(submitted) == 1
    assert submitted[0]["f_request_body"]["form_data"][flag] is True


def test_chi_update_flag_requires_matching_section() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-MISSING-BODY",
                "create_id": "384761337741312",
                "form_data": {"is_change_address": True},
            },
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    "form_data",
    [
        {"part_5": {}},
        {"part_2": {}},
        {"part_5": {"checklist": []}},
        {
            "part_5": {
                "checklist": [
                    {"position_code": "LORCHE_CHI_001", "attachment_id": 501},
                    {"position_code": "LORCHE_CHI_001", "attachment_id": 502},
                ]
            }
        },
    ],
)
def test_chi_update_rejects_empty_or_ambiguous_changes(
    form_data: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-NO-OP",
                "create_id": "384761337741312",
                "form_data": form_data,
            },
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_chi_update_accepts_one_checklist_file_per_position() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_CHI_001", "LORCHE_CHI_002")
    fake_client.attachment_records = {
        501: {"id": 501, "filename": "one.pdf"},
        502: {"id": 502, "filename": "two.pdf"},
    }
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
        }
    )
    checklist = [
        {"position_code": "LORCHE_CHI_001", "attachment_id": 501},
        {"position_code": "LORCHE_CHI_002", "attachment_id": 502},
    ]
    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-CHECKLIST",
                "create_id": "384761337741312",
                "form_data": {"part_5": {"checklist": checklist}},
            },
        )
    assert response.status_code == 200
    assert (
        fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]["part_5"][
            "checklist"
        ]
        == checklist
    )
    assert len(fake_catalog.calls) == 1
    assert fake_catalog.calls[0]["application_collection"] == "t_licence_app"
    assert {call["record_id"] for call in fake_client.attachment_get_calls} == {
        501,
        502,
    }
    assert all(
        call["authorization_token"] == "valid-client-token"
        for call in fake_client.attachment_get_calls
    )
    assert fake_client.events[-3:] == [
        "attachment_get",
        "attachment_get",
        "staging_create",
    ]


@pytest.mark.parametrize(
    ("endpoint", "request_event"),
    [
        ("/v1/create_intake_for_changing_home", "CREATE"),
        ("/v1/update_changing_home_data", "UPDATE"),
    ],
)
@pytest.mark.parametrize(
    ("position_code", "expected_path", "expected_message", "expected_code"),
    [
        (
            "NOT_AN_OFFICE_CHI_POSITION",
            "form_data.part_5.checklist.0.position_code",
            "The position_code is not in the office-specific checklist",
            "invalid_checklist_item",
        ),
        (
            "LORCHE_CHI_001",
            "form_data.part_5.checklist.0.attachment_id",
            "The uploaded attachment was not found or is not accessible",
            "missing_document",
        ),
    ],
)
def test_chi_checklist_preflight_rejects_unknown_code_or_missing_upload(
    endpoint: str,
    request_event: str,
    position_code: str,
    expected_path: str,
    expected_message: str,
    expected_code: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_CHI_001")
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
        }
    )
    checklist = [{"position_code": position_code, "attachment_id": 501}]
    if request_event == "CREATE":
        payload = valid_changing_home_payload()
        payload["form_data"]["part_5"] = {"checklist": checklist}
    else:
        payload = {
            "request_id": "CHI-UPDATE-PREFLIGHT",
            "create_id": "384761337741312",
            "form_data": {"part_5": {"checklist": checklist}},
        }
    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert_validation_field_response(
        response,
        path=expected_path,
        message=expected_message,
        error_code=expected_code,
    )
    assert len(fake_catalog.calls) == 1
    assert fake_catalog.calls[0]["office_code"] == "LORCHE"
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )
    assert len(fake_client.attachment_get_calls) == (
        0 if position_code == "NOT_AN_OFFICE_CHI_POSITION" else 1
    )
    if position_code == "LORCHE_CHI_001":
        assert fake_client.attachment_get_calls[0]["collection"] == "attachments"
        assert (
            fake_client.attachment_get_calls[0]["authorization_token"]
            == "valid-client-token"
        )


@pytest.mark.parametrize(
    "endpoint",
    ["/v1/create_intake_for_changing_home", "/v1/update_changing_home_data"],
)
def test_chi_checklist_preflight_respects_caller_attachment_permissions(
    endpoint: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_CHI_001")
    fake_client.denied_attachment_ids.add(501)
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
        }
    )
    item = {"position_code": "LORCHE_CHI_001", "attachment_id": 501}
    if endpoint.endswith("changing_home"):
        payload = valid_changing_home_payload()
        payload["form_data"]["part_5"] = {"checklist": [item]}
    else:
        payload = {
            "request_id": "CHI-UPDATE-DENIED-ATTACHMENT",
            "create_id": "384761337741312",
            "form_data": {"part_5": {"checklist": [item]}},
        }
    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert_validation_field_response(
        response,
        path="form_data.part_5.checklist.0.attachment_id",
        message="The uploaded attachment was not found or is not accessible",
        error_code="missing_document",
    )
    assert len(fake_client.attachment_get_calls) == 1
    assert (
        fake_client.attachment_get_calls[0]["authorization_token"]
        == "valid-client-token"
    )
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_chi_create_preflight_deduplicates_same_upload_and_precedes_staging() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_CHI_001", "LORCHE_CHI_002")
    fake_client.attachment_records[501] = {"id": 501, "filename": "one.pdf"}
    payload = valid_changing_home_payload()
    payload["form_data"]["part_5"] = {
        "checklist": [
            {"position_code": "LORCHE_CHI_001", "attachment_id": 501},
            {"position_code": "LORCHE_CHI_002", "attachment_id": 501},
        ]
    }
    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 200
    assert len(fake_catalog.calls) == 1
    assert len(fake_client.attachment_get_calls) == 1
    assert fake_client.events[-2:] == ["attachment_get", "staging_create"]


def test_chi_checklist_preflight_caps_assignment_request_count() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService()
    payload = valid_changing_home_payload()
    payload["form_data"]["part_5"] = {
        "checklist": [
            {"position_code": f"LORCHE_CHI_{index:03d}", "attachment_id": index}
            for index in range(1, 102)
        ]
    }
    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert not fake_catalog.calls
    assert not fake_client.attachment_get_calls
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    ("operator_type", "branch", "contact"),
    [
        (
            "1",
            "operator",
            {
                "full_name_en": "Change Operator",
                "declaration_answers": {"2": "No", "9": "Yes"},
            },
        ),
        (
            "2",
            "company",
            {
                "company_name_en": "Change Company",
                "business_registration_no": "BR-123",
                "certificate_of_incorporation_no": "CI-123",
                "application_type": "1",
                "registration_identifier_types": ["2"],
                "legislation_chapter_no": "Cap. 622",
                "declaration_answers": {"1": "Yes", "10": "No"},
            },
        ),
    ],
)
def test_chi_create_accepts_one_page_operator_branch(
    operator_type: str, branch: str, contact: dict[str, Any]
) -> None:
    application = create_app(settings(chi_operator_enabled=branch == "operator"))
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "rch_business_status": "0",
                "applicant_operator_type": operator_type,
                branch: contact,
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 200
    staged = fake_client.staging_calls[0]["values"]["f_request_body"]
    assert staged["form_data"]["part_3"] == payload["form_data"]["part_3"]


def test_chi_operator_list_is_an_explicit_complete_replacement() -> None:
    create_body = valid_changing_home_payload()
    create_body["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "applicant_operator_type": "0",
                "operators": [
                    {"full_name_en": "First Owner"},
                    {"full_name_en": "Second Owner"},
                ],
            },
        }
    )
    parsed_create = CreateIntakeForChangingHomeRequest.model_validate(create_body)
    assert len(parsed_create.form_data.part_3.operators) == 2
    assert (
        "id"
        not in parsed_create.model_dump(mode="json")["form_data"]["part_3"][
            "operators"
        ][0]
    )

    base_update = {
        "request_id": "CHI-UPDATE-OPERATORS-1",
        "create_id": "384761337741312",
        "form_data": {
            "is_change_operator_or_operating_company": True,
            "part_3": {"applicant_operator_type": "0"},
        },
    }
    omitted = UpdateChangingHomeDataRequest.model_validate(base_update)
    assert (
        "operators" not in omitted.model_dump(exclude_unset=True)["form_data"]["part_3"]
    )
    clearing = UpdateChangingHomeDataRequest.model_validate(
        {
            **base_update,
            "form_data": {
                "is_change_operator_or_operating_company": True,
                "part_3": {"applicant_operator_type": "0", "operators": []},
            },
        }
    )
    assert (
        clearing.model_dump(exclude_unset=True)["form_data"]["part_3"]["operators"]
        == []
    )


@pytest.mark.parametrize(
    ("part_3", "expected"),
    [
        (
            {"applicant_operator_type": "0", "operators": None},
            "cannot be null",
        ),
        (
            {"applicant_operator_type": "0", "operators": [{}]},
            "requires full_name_en or full_name_cn",
        ),
        (
            {
                "applicant_operator_type": "0",
                "operators": [{"full_name_en": "Person", "id": 5}],
            },
            "Extra inputs are not permitted",
        ),
        (
            {
                "applicant_operator_type": "2",
                "operators": [{"full_name_en": "Person"}],
            },
            "requires applicant_operator_type 0 or 1",
        ),
        (
            {
                "applicant_operator_type": "0",
                "operator": {"full_name_en": "One"},
                "operators": [{"full_name_en": "Two"}],
            },
            "cannot be combined",
        ),
        (
            {
                "applicant_operator_type": "0",
                "operators": [{"full_name_en": "Person"}],
                "company": {"company_name_en": "Company"},
            },
            "cannot be combined",
        ),
    ],
)
def test_chi_operator_list_invalid_requests_never_become_runnable(
    part_3: dict[str, Any], expected: str
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {"is_change_operator_or_operating_company": True, "part_3": part_3}
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert expected in str(response.json())
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize("endpoint", [
    "/v1/create_intake_for_changing_home", "/v1/update_changing_home_data",
])
@pytest.mark.parametrize("branch,value", [
    ("operator", {"full_name_en": "Owner"}),
    ("operators", [{"full_name_en": "Owner"}]),
    ("operators", []),
])
def test_chi_operator_replacement_fail_closed_until_workflow_cutover(
    endpoint: str, branch: str, value: object
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
            "f_intake_id": "8001",
            "f_application_id": "7001",
        }
    )
    form_data = {
        "is_change_operator_or_operating_company": True,
        "part_3": {"applicant_operator_type": "0", branch: value},
    }
    if endpoint.endswith("changing_home"):
        payload = valid_changing_home_payload()
        payload["form_data"].update(form_data)
    else:
        payload = {
            "request_id": "CHI-UPDATE-OPERATORS-2",
            "create_id": "384761337741312",
            "form_data": form_data,
        }
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 503
    assert response.json()["error"]["code"] == (
        "operator_replacement_temporarily_unavailable"
    )
    assert response.json()["error"]["details"]["field"] == (
        f"form_data.part_3.{branch}"
    )
    assert fake_client.staging_calls == []


@pytest.mark.parametrize("endpoint", [
    "/v1/create_intake_for_changing_home", "/v1/update_changing_home_data",
])
@pytest.mark.parametrize("branch,value", [
    ("operator", {"full_name_en": "Owner"}),
    ("operators", [{"full_name_en": "Owner"}]),
    ("operators", []),
])
def test_chi_operator_replacement_admits_only_with_explicit_feature_gate(
    endpoint: str, branch: str, value: object
) -> None:
    application = create_app(settings(chi_operator_enabled=True))
    fake_client = FakeAuthClient()
    fake_client.original_request.update({
        "f_api_type": "create_intake_for_changing_home",
        "f_application_type": "changing_home",
        "f_rch_id": "376863288262672",
        "f_intake_id": "8001",
        "f_application_id": "7001",
    })
    form_data = {
        "is_change_operator_or_operating_company": True,
        "part_3": {"applicant_operator_type": "0", branch: value},
    }
    if endpoint.endswith("changing_home"):
        payload = valid_changing_home_payload()
        payload["form_data"].update(form_data)
    else:
        payload = {
            "request_id": "CHI-UPDATE-OPERATORS-FEATURE-ON",
            "create_id": "384761337741312",
            "form_data": form_data,
        }
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 200
    assert len(fake_client.staging_calls) == 1
    staged_part_3 = fake_client.staging_calls[0]["values"]["f_request_body"][
        "form_data"
    ]["part_3"]
    assert staged_part_3[branch] == value


@pytest.mark.parametrize(
    ("part_3", "error_fragment"),
    [
        (
            {
                "applicant_operator_type": "1",
                "operator": {"full_name_en": "Person"},
                "company": {"company_name_en": "Company"},
            },
            "cannot be combined",
        ),
        (
            {"applicant_operator_type": "2", "operator": {"full_name_en": "Person"}},
            "requires applicant_operator_type 0 or 1",
        ),
        (
            {"applicant_operator_type": "0", "company": {"company_name_en": "Company"}},
            "requires applicant_operator_type 2 or 3",
        ),
        (
            {"operator": {"full_name_en": "Person"}},
            "requires part_3.applicant_operator_type",
        ),
        (
            {"company": {"company_name_en": "Company"}},
            "requires part_3.applicant_operator_type",
        ),
    ],
)
def test_chi_create_rejects_contradictory_operator_branch_synchronously(
    part_3: dict[str, Any], error_fragment: str
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": part_3,
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert error_fragment in str(response.json()["validation_errors"])
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    "part_3",
    [
        {"applicant_operator_type": "3", "operator": {"full_name_en": "Person"}},
        {"applicant_operator_type": "1", "company": {"company_name_en": "Company"}},
        {"operator": {"full_name_en": "Person"}},
        {"company": {"company_name_en": "Company"}},
    ],
)
def test_chi_update_rejects_ambiguous_operator_branch_synchronously(
    part_3: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-INVALID-BRANCH",
                "create_id": "384761337741312",
                "form_data": {
                    "is_change_operator_or_operating_company": True,
                    "part_3": part_3,
                },
            },
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    "company_change",
    [
        {"trust_no": "TR-123"},
        {"registration_identifier_types": ["3"]},
        {"registration_identifier_types": ["0", "2"]},
        {"registration_identifier_types": ["0", "0"]},
        {"registration_identifier_types": None},
        {"legislation_chapter_no": ""},
        {"legislation_chapter_no": None},
        {"declaration_answers": None},
        {"declaration_answers": {}},
        {"declaration_answers": {"11": "Yes"}},
        {"declaration_answers": {"1": "Maybe"}},
        {"office_phone": "21230000"},
        {"address": {"street_name_en": "Unsafe shared address"}},
    ],
)
def test_chi_rejects_unsupported_or_invalid_company_contract(
    company_change: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "applicant_operator_type": "2",
                "company": {"company_name_en": "Company", **company_change},
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_chi_part_3_business_status_requires_operator_change_flag() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"]["part_3"] = {"rch_business_status": "0"}
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    ("rch_business_status", "applicant_operator_type"),
    [("0", "0"), ("1", "3")],
)
def test_chi_business_status_enum_values_are_staged(
    rch_business_status: str, applicant_operator_type: str
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "rch_business_status": rch_business_status,
                "applicant_operator_type": applicant_operator_type,
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 200
    staged = fake_client.staging_calls[0]["values"]["f_request_body"]
    assert staged["form_data"]["part_3"] == payload["form_data"]["part_3"]


@pytest.mark.parametrize(
    "part_3",
    [
        {"rch_business_status": "2"},
        {"applicant_operator_type": "4"},
        {"rch_business_status": 0},
    ],
)
def test_chi_business_status_enum_rejects_unsupported_values(
    part_3: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": part_3,
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    "answers",
    [{"11": "Yes"}, {"1": "Maybe"}, None, {}],
)
def test_chi_operator_declaration_answers_are_constrained(answers: object) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(
        {
            "is_change_operator_or_operating_company": True,
            "part_3": {
                "applicant_operator_type": "0",
                "operator": {
                    "full_name_en": "Operator",
                    "declaration_answers": answers,
                },
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    ("changes", "error_fragment"),
    [
        ({"is_change_name": "true"}, "is_change_name"),
        ({"is_change_name": 1}, "is_change_name"),
        ({"is_change_name": None}, "is_change_name"),
        ({"part_2": {"rch_name_en": None}}, "rch_name_en"),
        ({"part_2": {"rch_name_en": "   "}}, "rch_name_en"),
        ({"part_2": {"monthly_fee_min": 100.0}}, "monthly_fee_min"),
        ({"part_1": {"tentative_commencement_date": "2026-12-01"}}, "part_1"),
        (
            {"part_2": {"max_capacity": 0}, "is_change_maximum_capacity": True},
            "max_capacity",
        ),
        (
            {"part_2": {"max_capacity": "80"}, "is_change_maximum_capacity": True},
            "max_capacity",
        ),
        (
            {
                "part_2": {"rch_name_en": "Revised", "rch_type_code": "b1"},
                "is_change_rch_type": True,
            },
            "rch_type_code",
        ),
        (
            {
                "part_3": {
                    "applicant_operator_type": "2",
                    "company": {"application_type": "2"},
                },
                "is_change_operator_or_operating_company": True,
            },
            "application_type",
        ),
        (
            {
                "part_3": {
                    "applicant_operator_type": "0",
                    "operator": {"representative_position": "CEO"},
                },
                "is_change_operator_or_operating_company": True,
            },
            "representative_position",
        ),
        (
            {
                "part_3": {
                    "applicant_operator_type": "2",
                    "company": {"address_for_licence": True},
                },
                "is_change_operator_or_operating_company": True,
            },
            "address_for_licence",
        ),
        ({"part_4": None}, "part_4"),
        ({"part_3": None}, "part_3"),
    ],
)
def test_chi_create_rejects_non_page_or_empty_proposed_fields(
    changes: dict[str, Any], error_fragment: str
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"].update(changes)
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert error_fragment in str(response.json()["validation_errors"])
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_chi_create_accepts_office_valid_rch_type_and_positive_capacity() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.home_records = [
        {
            "id": 376863288262673,
            "f_rch_no": "D0043",
            "f_final_o_no": "PD0177",
            "f_office_cd": "LORCHD",
        }
    ]
    payload = valid_changing_home_payload()
    payload["form_data"]["case_summary"].update(
        {"office_code": "LORCHD", "lorche_d_no": "D0043"}
    )
    payload["form_data"].update(
        {
            "is_change_rch_type": True,
            "is_change_maximum_capacity": True,
            "part_2": {
                "rch_name_en": "Revised RCH",
                "rch_type_code": "b3",
                "max_capacity": 70,
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 200
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262673"
    assert (
        fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]["part_2"][
            "rch_type_code"
        ]
        == "b3"
    )


@pytest.mark.parametrize(
    "form_data",
    [
        {"is_change_name": False},
        {"is_change_name": None},
        {"is_change_name": "true"},
        {"is_aip": None},
        {"case_summary": None, **chi_name_update("New Name")},
        {"case_summary": {"office_code": "LORCHE", "rch_no": "L0043"}},
        {"part_2": {"max_capacity": 0}, "is_change_maximum_capacity": True},
        {"part_2": {"max_capacity": "90"}, "is_change_maximum_capacity": True},
        {"part_2": {"licence_capacity": 90}, "is_change_maximum_capacity": True},
        {"part_2": {"rch_type_code": None}, "is_change_rch_type": True},
    ],
)
def test_chi_update_rejects_flag_noop_or_non_page_capacity(
    form_data: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-STRICT",
                "create_id": "384761337741312",
                "form_data": form_data,
            },
        )
    assert response.status_code == 422
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_chi_update_rejects_rch_type_from_other_office() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-WRONG-TYPE",
                "create_id": "384761337741312",
                "form_data": {
                    "is_change_rch_type": True,
                    "part_2": {"rch_type_code": "b1"},
                },
            },
        )
    assert response.status_code == 422
    assert response.json()["error"] == {
        "code": "validation_failed",
        "message": "The RCH Type is not valid for the original office_code",
        "request_id": response.headers["X-Request-ID"],
        "details": {
            "fields": [
                {
                    "path": "form_data.part_2.rch_type_code",
                    "code": "invalid_field",
                    "message": (
                        "The RCH Type is not valid for the original office_code"
                    ),
                }
            ]
        },
    }
    assert not fake_client.staging_calls


@pytest.mark.parametrize(
    "unsupported",
    [
        {"received_date": "2026-09-15"},
        {"received_date": None},
        {"severity": "0"},
        {"source_id": 701},
        {"source_other": "OP"},
        {"task_owner_user_id": 45},
        {"task_owner_post_code": "S(LR)1"},
    ],
)
def test_chi_update_rejects_unprojected_intake_metadata(
    unsupported: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-INTAKE-METADATA",
                "create_id": "384761337741312",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "rch_no": "L0043",
                        **unsupported,
                    },
                    **chi_name_update("Projected Name Change"),
                },
            },
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert next(iter(unsupported)) in str(response.json()["validation_errors"])
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    "nested_patch",
    [
        {"operator": {"declaration_answers": None}},
        {"operator": {"declaration_answers": {}}},
        {"company": {"registration_identifier_types": None}},
        {"company": {"legislation_chapter_no": None}},
        {"company": {"declaration_answers": None}},
    ],
)
def test_chi_update_rejects_null_or_empty_child_relation_patch(
    nested_patch: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-CHILD-NULL",
                "create_id": "384761337741312",
                "form_data": {
                    "is_change_operator_or_operating_company": True,
                    "part_3": nested_patch,
                },
            },
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_chi_create_keeps_visible_intake_metadata_mapped_by_workflow() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"]["case_summary"].update(
        {
            "received_date": "2026-09-15",
            "severity": "0",
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 200
    staged_summary = fake_client.staging_calls[0]["values"]["f_request_body"][
        "form_data"
    ]["case_summary"]
    assert staged_summary["received_date"] == "2026-09-15"
    assert staged_summary["severity"] == "0"
    assert "source_id" not in staged_summary


@pytest.mark.parametrize("source_other", ["OP", None])
def test_chi_create_rejects_unrepresented_intake_source_other(
    source_other: object,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_changing_home_payload()
    payload["form_data"]["case_summary"]["source_other"] = source_other
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_changing_home",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert "source_other" in str(response.json()["validation_errors"])
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


@pytest.mark.parametrize(
    ("endpoint", "extra"),
    [
        ("/v1/create_intake_for_changing_home", {"is_aip": True}),
        ("/v1/create_intake_for_changing_home", {"is_aip": False}),
        ("/v1/update_changing_home_data", {"is_aip": True}),
        ("/v1/update_changing_home_data", {"is_aip": False}),
        (
            "/v1/create_intake_for_changing_home",
            {"part_5": {"comments": "Not a CHI page field"}},
        ),
        ("/v1/create_intake_for_changing_home", {"part_5": {"attachment_ids": [501]}}),
        ("/v1/create_intake_for_changing_home", {"part_5": {"checklist": None}}),
        (
            "/v1/update_changing_home_data",
            {"part_5": {"comments": "Not a CHI page field"}},
        ),
        (
            "/v1/update_changing_home_data",
            {"part_5": {"remarks": "Not a CHI page field"}},
        ),
        ("/v1/update_changing_home_data", {"part_5": {"checklist": None}}),
    ],
)
def test_chi_rejects_non_page_aip_and_part5_fields_synchronously(
    endpoint: str, extra: dict[str, Any]
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    if endpoint.endswith("changing_home"):
        payload = valid_changing_home_payload()
        payload["form_data"].update(extra)
    else:
        payload = {
            "request_id": "CHI-UPDATE-NON-PAGE",
            "create_id": "384761337741312",
            "form_data": {**chi_name_update("Actual proposed name"), **extra},
        }
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert all(
        call["values"]["f_status"] != "submitted" for call in fake_client.staging_calls
    )


def test_update_changing_home_is_locked_after_submitted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_application_status": "Received",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-LOCKED-1",
                "create_id": "384761337741312",
                "form_data": chi_name_update("Must not be applied"),
            },
        )

    assert_update_locked_response(response)
    assert fake_client.staging_calls == []


def test_update_changing_home_stages_using_create_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
            "f_intake_id": "8001",
            "f_application_id": "7001",
        }
    )
    payload = {
        "request_id": "CHI-UPDATE-20260914-0001",
        "create_id": "384761337741312",
        "form_data": chi_name_update("Updated through API"),
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="CHI-UPDATE-20260914-0001",
        create_id="384761337741312",
        application_type="changing_home",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "update_changing_home_data"
    )
    assert (
        fake_client.staging_calls[0]["values"]["f_parent_create_id"]
        == (payload["create_id"])
    )
    assert (
        fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]
        == payload["form_data"]
    )
    assert "f_chi_address_requested" not in fake_client.staging_calls[0]["values"]


@pytest.mark.parametrize(
    ("create_status", "intake_id", "application_id"),
    [
        ("processing", "8001", "7001"),
        ("succeeded", None, "7001"),
        ("succeeded", "8001", None),
    ],
)
def test_update_changing_home_rejects_before_create_is_ready(
    create_status: str,
    intake_id: Optional[str],
    application_id: Optional[str],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
            "f_status": create_status,
            "f_intake_id": intake_id,
            "f_application_id": application_id,
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-CREATE-NOT-READY",
                "create_id": "384761337741312",
                "form_data": chi_name_update("Updated Home"),
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "create_not_ready"
    assert fake_client.staging_calls == []


@pytest.mark.parametrize(
    ("summary", "original_rch_id", "field"),
    [
        (
            {"office_code": "LORCHD", "rch_no": "L0043"},
            "376863288262672",
            "form_data.case_summary.office_code",
        ),
        (
            {"submitter_user_id": 999},
            "376863288262672",
            "form_data.case_summary.submitter_user_id",
        ),
        (
            {"office_code": "LORCHE", "rch_no": "L0043"},
            "other-home-record-id",
            "form_data.case_summary",
        ),
    ],
)
def test_chi_update_rejects_identity_or_home_changes(
    summary: dict[str, Any], original_rch_id: str, field: str
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": original_rch_id,
            "f_request_body": {
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                    }
                }
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-IDENTITY-MISMATCH",
                "create_id": "384761337741312",
                "form_data": {
                    "case_summary": summary,
                    **chi_name_update("Must be rejected"),
                },
            },
        )
    assert_validation_field_response(response, path=field)
    if field == "form_data.case_summary.submitter_user_id":
        assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"
    else:
        assert fake_client.staging_calls == []


def test_chi_update_accepts_same_original_identity_and_home() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_rch_id": "376863288262672",
            "f_request_body": {
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                    }
                }
            },
        }
    )
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_changing_home_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHI-UPDATE-SAME-IDENTITY",
                "create_id": "384761337741312",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "rch_no": "L0043",
                    },
                    **chi_name_update("Same original identity"),
                },
            },
        )
    assert response.status_code == 200
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.staging_calls[0]["values"]["f_status"] == "submitted"
    assert "f_chi_address_requested" not in fake_client.staging_calls[0]["values"]


def valid_self_withdraw_payload() -> dict[str, Any]:
    return {
        "request_id": "SW-20260914-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "lorche_d_no": "l0043",
                "received_date": "2026-09-22",
            },
            "applicant_title": "0",
            "applicant_name_en": "Example Applicant",
            "means_of_authorisation": "0",
            "tentative_date_of_closure": "2026-12-31",
            "reason_for_closure": "0",
        },
    }


def valid_specific_hour_payload(*, home_field: str = "lorche_d_no") -> dict[str, Any]:
    return {
        "request_id": "SH-20260914-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                home_field: "PE0177" if home_field == "p_no" else "L0043",
                "received_date": "2026-09-22",
            },
            "application_detail": "approval",
            "applicant_title": "Mr",
            "applicant_name_en": "Example Applicant",
            "authorisation_method": "digital",
            "authorised_to_apply": True,
            "certificate_name_en": "Example RCH",
            "tentative_commencement_date": "2026-12-01",
            "specific_hour_set_count": "0",
            "specific_hour_options": [
                {
                    "set_no": "0",
                    "section": "workday_and_holiday",
                    "staffings": [
                        {
                            "staff_type_code": code,
                            "time_rows": [
                                {
                                    "work_hour_from": "09:00:00",
                                    "work_hour_to": "18:00:00",
                                }
                            ],
                        }
                        for code in ("AW", "CW", "HCP")
                    ],
                }
            ],
            "declaration_acknowledged": True,
            "warning_acknowledged": True,
            "declared_at": "2026-09-22",
        },
    }


def valid_rp_payload(*, home_field: str = "p_no") -> dict[str, Any]:
    return {
        "request_id": "RP-20260914-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                home_field: "PE0177" if home_field == "p_no" else "L0043",
                "received_date": "2026-09-22",
            },
            "rp_title": "mr",
            "rp_name_en": "Example RP",
            "rp_tel": "21234567",
            "rp_email": "rp@example.com",
            "rp_address_en": "1 Example Road",
            "rp_address_cn": "示例道1号",
            "rp_position_type": "sole_proprietorship",
            "rp_other_home": "no",
            "rp_application_type": "section_9",
            "change_reason": "DSW_change",
            "ceased_status": "will_cease",
            "cease_position_date": "2026-10-01",
            "new_rp_assume_office_date": "2026-10-02",
            "notice_expected_issued_date": "2026-09-30",
            "authorised_rep_position": "Authorised Representative",
            "other_particulars": {
                "q1": {"answer": "no"},
                "q2": {"answer": "no"},
                "q3": {"answer": "no"},
                "q4": {"answer": "no"},
                "q5": {"answer": "no"},
                "q6": {"answer": "no"},
                "q7": {"answer": "no"},
                "q8": {"answer": "no"},
            },
            "declaration": {
                "acknowledged": True,
                "signature_date_of_rp": "2026-09-22",
                "signature_date_of_applicant_representative_partner": "2026-09-22",
            },
        },
    }


def test_create_self_withdraw_resolves_home_record_and_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_self_withdraw",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "request-sw-create-1",
            },
            json=valid_self_withdraw_payload(),
        )

    assert_accepted_business_response(
        response,
        request_id="SW-20260914-0001",
        create_id="9001",
        application_type="self_withdraw",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_intake_for_self_withdraw"
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.staging_calls[0]["values"]["f_application_status"] == (
        "Accepted"
    )


def test_create_self_withdraw_rejects_unknown_home_record() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.home_records = []

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_self_withdraw",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_self_withdraw_payload(),
        )

    assert_validation_field_response(
        response,
        path="form_data.case_summary",
        message="No matching Home Record was found",
    )


def test_self_withdraw_checklist_is_validated_before_staging() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_SELF_WITHDRAW_001")
    fake_client.attachment_records[501] = {"id": 501}
    payload = valid_self_withdraw_payload()
    payload["form_data"]["checklist"] = [
        {
            "position_code": "LORCHE_SELF_WITHDRAW_001",
            "attachment_id": 501,
        }
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/create_intake_for_self_withdraw",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 200
    assert fake_catalog.calls[0]["application_collection"] == (
        "t_self_withdraw_licence_application"
    )
    assert fake_client.attachment_get_calls[0]["record_id"] == 501
    assert fake_client.events.index("attachment_get") < fake_client.events.index(
        "staging_create"
    )


def test_update_self_withdraw_is_locked_after_submitted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_application_status": "Received",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-LOCKED-1",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert_update_locked_response(response)


def test_update_self_withdraw_stages_against_original_create_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={
                "Authorization": "Bearer valid-client-token",
                "X-Request-ID": "client-reused-transport-id",
            },
            json={
                "request_id": "SW-UPDATE-ACCEPTED-1",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert response.status_code == 200
    values = fake_client.staging_calls[0]["values"]
    assert values["f_parent_create_id"] == "384761337741312"
    assert values["f_rch_id"] == "376863288262672"
    assert values["f_status"] == "submitted"
    assert values["f_active_update_id"]
    assert values["f_active_update_id"] != "client-reused-transport-id"
    assert (
        fake_client.original_request["f_active_update_id"]
        == values["f_active_update_id"]
    )
    assert fake_client.update_calls[0]["expected"] == {
        "f_application_status": "Accepted",
        "f_active_update_id": None,
    }


def test_update_self_withdraw_cancels_when_received_wins_admission_race() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_rch_id": "376863288262672",
        }
    )
    fake_client.parent_status_on_reservation_attempt = "Received"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-RACE-1",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert_update_locked_response(response)
    assert fake_client.staging_calls == []
    assert fake_client.update_calls == [
        {
            "collection": "t_api_request_staging",
            "record_id": "384761337741312",
            "expected": {
                "f_application_status": "Accepted",
                "f_active_update_id": None,
            },
            "request_id": ANY,
            "authorization_token": "valid-client-token",
            "values": {"f_active_update_id": ANY},
        }
    ]


def test_update_self_withdraw_passes_same_reservation_to_workflow() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_rch_id": "376863288262672",
        }
    )
    fake_client.update_status_after_staging_create = "processing"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-RACE-WORKFLOW-WINS",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert response.status_code == 200
    assert response.json()["status"] == "Accepted"
    staged = fake_client.created_staging_records["9001"]
    assert staged["f_status"] == "processing"
    assert staged["f_active_update_id"]
    assert (
        fake_client.original_request["f_active_update_id"]
        == staged["f_active_update_id"]
    )


@pytest.mark.parametrize("active_status", ["submitted", "processing"])
def test_update_self_withdraw_rejects_a_second_active_update(
    active_status: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_rch_id": "376863288262672",
        }
    )
    fake_client.pending_update_records = [
        {
            "id": 9000,
            "f_parent_create_id": "384761337741312",
            "f_status": active_status,
        }
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-IN-PROGRESS",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "update_in_progress"


def test_update_self_withdraw_reports_reserved_parent_as_in_progress() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_rch_id": "376863288262672",
            "f_active_update_id": "another-server-reservation",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-RESERVED",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "update_in_progress"
    assert fake_client.staging_calls == []
    assert fake_client.staging_calls == []
    staging_query = next(
        call
        for call in fake_client.list_calls
        if call.get("collection") == "t_api_request_staging"
    )
    assert staging_query["filters"] == {
        "$and": [
            {"f_request_event": {"$eq": "UPDATE"}},
            {"f_parent_create_id": {"$eq": "384761337741312"}},
            {"f_status": {"$in": ["submitted", "processing"]}},
        ]
    }


@pytest.mark.parametrize(
    ("create_status", "intake_id", "application_id"),
    [
        ("processing", "384761337741313", "384761337741314"),
        ("succeeded", None, "384761337741314"),
        ("succeeded", "384761337741313", None),
    ],
)
def test_update_specific_hour_rejects_until_create_is_ready(
    create_status: str,
    intake_id: Optional[str],
    application_id: Optional[str],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_specific_hour",
            "f_application_type": "specific_hour",
            "f_rch_id": "376863288262672",
            "f_status": create_status,
            "f_intake_id": intake_id,
            "f_application_id": application_id,
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_specific_hour_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SH-UPDATE-CREATE-NOT-READY",
                "create_id": "384761337741312",
                "form_data": {"certificate_name_en": "Revised name"},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "create_not_ready"
    assert response.json()["error"]["details"] == {
        "field": "create_id",
        "status": create_status,
    }
    assert fake_client.staging_calls == []


def test_update_specific_hour_rejects_false_authorisation() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_specific_hour_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SH-UPDATE-FALSE-AUTHORISATION",
                "create_id": "384761337741312",
                "form_data": {"authorised_to_apply": False},
            },
        )

    assert response.status_code == 422
    assert response.json()["error"]["code"] == "validation_failed"
    fields = response.json()["error"]["details"]["fields"]
    assert any(
        field["path"] == "form_data"
        and "authorised_to_apply cannot be false" in field["message"]
        for field in fields
    )


def test_update_rp_submits_when_create_is_ready_and_no_update_is_active() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_rp",
            "f_application_type": "responsible_person",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_rp_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RP-UPDATE-READY",
                "create_id": "384761337741312",
                "form_data": {"rp_tel": "21234568"},
            },
        )

    assert response.status_code == 200
    assert response.json()["status"] == "Accepted"
    assert response.json()["create_id"] == "384761337741312"
    assert fake_client.staging_calls[0]["values"]["f_status"] == "submitted"


def test_update_revoke_rejects_until_create_is_ready() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_revoke_licence",
            "f_application_type": "revoke_licence",
            "f_rch_id": "376863288262672",
            "f_status": "processing",
            "f_intake_id": None,
            "f_application_id": None,
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_revoke_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "REVOKE-UPDATE-NOT-READY",
                "create_id": "384761337741312",
                "form_data": {"tentative_date_of_closure": "2027-01-01"},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "create_not_ready"
    assert fake_client.staging_calls == []


def test_update_self_withdraw_rejects_home_record_rebinding() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_rch_id": "376863288262672",
        }
    )
    fake_client.home_records = [
        {
            "id": 999,
            "f_rch_no": "L9999",
            "f_final_o_no": "PE9999",
            "f_office_cd": "LORCHE",
            "fk_type_of_rch": 101,
        }
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-HOME-MISMATCH",
                "create_id": "384761337741312",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "rch_no": "L9999",
                    },
                    "tentative_date_of_closure": "2027-01-01",
                },
            },
        )

    assert_validation_field_response(
        response,
        path="form_data.case_summary",
        message="The Home Record must match the original Create request",
    )
    assert fake_client.staging_calls == []


def test_create_revoke_licence_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_revoke_licence",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RV-20260914-0001",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "lorche_d_no": "L0043",
                        "received_date": "2026-09-14",
                    },
                    "applicant_title": "0",
                    "applicant_name_en": "Example Applicant",
                    "means_of_authorisation": "1",
                    "tentative_date_of_closure": "2026-12-31",
                    "reason_for_closure": "0",
                },
            },
        )

    assert_accepted_business_response(
        response,
        request_id="RV-20260914-0001",
        create_id="9001",
        application_type="revoke_licence",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_intake_for_revoke_licence"
    )


@pytest.mark.parametrize(
    ("endpoint", "payload"),
    [
        (
            "/v1/create_intake_for_revoke_licence",
            {
                "request_id": "RV-UNSUPPORTED-ATTACHMENT-CREATE",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "lorche_d_no": "L0043",
                        "received_date": "2026-09-14",
                        "submitter_user_id": 12,
                        "task_owner_user_id": 45,
                        "task_owner_post_code": "S(LR)1",
                    },
                    "applicant_title": "0",
                    "applicant_name_en": "Example Applicant",
                    "means_of_authorisation": "1",
                    "tentative_date_of_closure": "2026-12-31",
                    "reason_for_closure": "0",
                    "attachment_ids": [501],
                },
            },
        ),
        (
            "/v1/update_revoke_licence_data",
            {
                "request_id": "RV-UNSUPPORTED-ATTACHMENT-UPDATE",
                "create_id": "388000000000001",
                "form_data": {"attachment_ids": [501]},
            },
        ),
    ],
)
def test_revoke_rejects_unimplemented_attachment_ids_instead_of_losing_them(
    endpoint: str,
    payload: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert "attachment_ids" in str(response.json()["validation_errors"])
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_specific_hour_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_specific_hour",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_specific_hour_payload(),
        )

    assert_accepted_business_response(
        response,
        request_id="SH-20260914-0001",
        create_id="9001",
        application_type="specific_hour",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_intake_for_specific_hour"
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.list_calls[0]["filters"] == {
        "$and": [
            {"f_rch_no": {"$eq": "L0043"}},
            {"f_office_cd": {"$eq": "LORCHE"}},
        ]
    }
    staffing = fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"][
        "specific_hour_options"
    ][0]["staffings"][0]
    assert staffing["_rule_snapshot"] == {
        "rule_id": 1,
        "staff_ratio_requirement": "1:10",
        "minimum_required_hours": 1,
        "sort_order": 1,
    }
    assert staffing["time_rows"][0]["_duration_hours"] == 9.0
    assert staffing["time_rows"][0]["_sort_order"] == 1


def test_create_specific_hour_resolves_home_record_by_p_no() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_specific_hour",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_specific_hour_payload(home_field="p_no"),
        )

    assert_accepted_business_response(
        response,
        request_id="SH-20260914-0001",
        create_id="9001",
        application_type="specific_hour",
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.list_calls[0]["filters"] == {
        "$and": [
            {"f_final_o_no": {"$eq": "PE0177"}},
            {"f_office_cd": {"$eq": "LORCHE"}},
        ]
    }


def test_create_specific_hour_rejects_staff_type_not_in_home_rules() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_specific_hour_payload()
    payload["form_data"]["specific_hour_options"][0]["staffings"][2][
        "staff_type_code"
    ] = "UNKNOWN"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_specific_hour",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_validation_field_response(
        response,
        path="form_data.specific_hour_options.0.staffings",
        message=(
            "Each Specific Hour staffing rule requires exactly one allowed staff type"
        ),
    )
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"
    assert fake_client.staging_calls[0]["values"]["f_error_message"] == (
        "invalid_staffing_selection"
    )


def test_create_specific_hour_rejects_hours_below_configured_minimum() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_specific_hour_payload()
    first_row = payload["form_data"]["specific_hour_options"][0]["staffings"][0][
        "time_rows"
    ][0]
    first_row["work_hour_to"] = "09:30:00"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_specific_hour",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_validation_field_response(
        response,
        path="form_data.specific_hour_options.0.staffings",
        message="The submitted working hours are below the configured minimum",
    )
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"
    assert fake_client.staging_calls[0]["values"]["f_error_message"] == (
        "minimum_staffing_hours_not_met"
    )


def test_create_specific_hour_caps_total_time_rows_before_workflow_submission() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_specific_hour_payload()
    time_row = {
        "work_hour_from": "09:00:00",
        "work_hour_to": "10:00:00",
    }
    payload["form_data"]["specific_hour_options"][0]["staffings"] = [
        {
            "staff_type_code": f"S{index}",
            "time_rows": [dict(time_row) for _ in range(17)],
        }
        for index in range(16)
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_specific_hour",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert "at most 256 time rows" in str(response.json()["validation_errors"])
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_rp_resolves_home_record_by_p_no() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_rp",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_rp_payload(home_field="p_no"),
        )

    assert_accepted_business_response(
        response,
        request_id="RP-20260914-0001",
        create_id="9001",
        application_type="responsible_person",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_intake_for_rp"
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.list_calls[0]["filters"] == {
        "$and": [
            {"f_final_o_no": {"$eq": "PE0177"}},
            {"f_office_cd": {"$eq": "LORCHE"}},
        ]
    }


def test_create_rp_rejects_non_routable_email_before_staging_workflow() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_rp_payload()
    payload["form_data"]["rp_email"] = "rp@example.test"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_rp",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    body = response.json()
    assert body["accepted"] is False
    assert body["validation_errors"][0]["path"] == "form_data.rp_email"
    assert body["status"] == "invalid_request"
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"
    assert fake_client.list_calls == []


@pytest.mark.parametrize(
    ("question", "field"),
    [("q2", "place_of_proceeding"), ("q4", "place_of_court")],
)
def test_create_rp_rejects_non_page_q2_q4_place_fields(
    question: str,
    field: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_rp_payload()
    payload["form_data"]["other_particulars"][question][field] = "Unsupported"

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_rp",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert f"{question} does not support" in str(response.json()["validation_errors"])
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_update_rp_rejects_non_page_q2_place_field() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_rp_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RP-UPDATE-UNSUPPORTED-PLACE",
                "create_id": "384761337741312",
                "form_data": {
                    "other_particulars": {"q2": {"place_of_proceeding": "Unsupported"}}
                },
            },
        )

    assert response.status_code == 422
    assert "q2 does not support" in str(response.json()["validation_errors"])
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_rp_resolves_home_record_by_rch_no() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_rp",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_rp_payload(home_field="lorche_d_no"),
        )

    assert_accepted_business_response(
        response,
        request_id="RP-20260914-0001",
        create_id="9001",
        application_type="responsible_person",
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    assert fake_client.list_calls[0]["filters"] == {
        "$and": [
            {"f_rch_no": {"$eq": "L0043"}},
            {"f_office_cd": {"$eq": "LORCHE"}},
        ]
    }


@pytest.mark.parametrize(
    ("rp_other_home", "currently_appointed_homes", "expected_message"),
    [
        (
            "yes",
            [],
            "currently_appointed_homes is required when rp_other_home is yes",
        ),
        (
            "no",
            [{"rch_no": "L0099", "rch_name": "Another Home"}],
            "currently_appointed_homes must be empty when rp_other_home is no",
        ),
    ],
)
def test_create_rp_requires_other_home_flag_and_rows_to_agree(
    rp_other_home: str,
    currently_appointed_homes: list[dict[str, str]],
    expected_message: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = valid_rp_payload()
    payload["form_data"]["rp_other_home"] = rp_other_home
    payload["form_data"]["currently_appointed_homes"] = currently_appointed_homes

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_rp",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_validation_field_response(response, path="form_data")
    assert (
        expected_message in response.json()["error"]["details"]["fields"][0]["message"]
    )
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


def test_create_specific_hour_requires_rch_no_or_p_no() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_specific_hour",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SH-MISSING-REF-1",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "submitter_user_id": 12,
                        "task_owner_user_id": 45,
                        "task_owner_post_code": "S(LR)1",
                    },
                    "application_detail": "approval",
                },
            },
        )

    assert response.status_code == 422
    assert response.json()["status"] in {"invalid_request", "missing_required"}


def test_update_rp_is_locked_after_submitted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_rp",
            "f_application_type": "responsible_person",
            "f_application_status": "Received",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_rp_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RP-UPDATE-LOCKED-1",
                "create_id": "384761337741312",
                "form_data": {"rp_tel": "21234568"},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "update_locked"


def test_update_rp_accepts_one_partial_nested_question() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_rp",
            "f_application_type": "responsible_person",
            "f_application_status": "Accepted",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_rp_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RP-UPDATE-Q5-1",
                "create_id": "384761337741312",
                "form_data": {
                    "other_particulars": {
                        "q5": {
                            "date": "2026-09-21",
                            "reasons": "Correct the previously supplied reason",
                        }
                    }
                },
            },
        )

    assert response.status_code == 200
    staged = fake_client.staging_calls[0]["values"]
    assert staged["f_parent_create_id"] == "384761337741312"
    assert staged["f_request_body"]["form_data"] == {
        "other_particulars": {
            "q5": {
                "date": "2026-09-21",
                "reasons": "Correct the previously supplied reason",
            }
        }
    }


@pytest.mark.parametrize(
    ("form_data", "expected_message"),
    [
        (
            {"rp_other_home": "yes"},
            "rp_other_home and currently_appointed_homes must be supplied together",
        ),
        (
            {"currently_appointed_homes": []},
            "rp_other_home and currently_appointed_homes must be supplied together",
        ),
        (
            {"rp_other_home": "yes", "currently_appointed_homes": []},
            "currently_appointed_homes is required when rp_other_home is yes",
        ),
        (
            {
                "rp_other_home": "no",
                "currently_appointed_homes": [
                    {"rch_no": "L0099", "rch_name": "Another Home"}
                ],
            },
            "currently_appointed_homes must be an empty array when rp_other_home is no",
        ),
    ],
)
def test_update_rp_requires_other_home_flag_and_rows_as_one_replacement(
    form_data: dict[str, Any],
    expected_message: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_rp",
            "f_application_type": "responsible_person",
            "f_application_status": "Accepted",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_rp_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RP-UPDATE-OTHER-HOME-INVALID",
                "create_id": "384761337741312",
                "form_data": form_data,
            },
        )

    assert_validation_field_response(response, path="form_data")
    assert (
        expected_message in response.json()["error"]["details"]["fields"][0]["message"]
    )
    assert fake_client.staging_calls[0]["values"]["f_status"] == "invalid_request"


@pytest.mark.parametrize(
    ("rp_other_home", "currently_appointed_homes"),
    [
        ("no", []),
        (
            "yes",
            [{"rch_no": "L0099", "rch_name": "Another Home"}],
        ),
    ],
)
def test_update_rp_accepts_consistent_other_home_replacement(
    rp_other_home: str,
    currently_appointed_homes: list[dict[str, str]],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_rp",
            "f_application_type": "responsible_person",
            "f_application_status": "Accepted",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_rp_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "RP-UPDATE-OTHER-HOME-VALID",
                "create_id": "384761337741312",
                "form_data": {
                    "rp_other_home": rp_other_home,
                    "currently_appointed_homes": currently_appointed_homes,
                },
            },
        )

    assert response.status_code == 200
    staged_form = fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]
    assert staged_form == {
        "rp_other_home": rp_other_home,
        "currently_appointed_homes": currently_appointed_homes,
    }


def test_home_bound_update_accepts_partial_intake_metadata() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_application_status": "Accepted",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_self_withdraw_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "SW-UPDATE-INTAKE-1",
                "create_id": "384761337741312",
                "form_data": {
                    "case_summary": {
                        "received_date": "2026-09-23",
                        "severity": "1",
                    }
                },
            },
        )

    assert response.status_code == 200
    staged_summary = fake_client.staging_calls[0]["values"]["f_request_body"][
        "form_data"
    ]["case_summary"]
    assert staged_summary == {"received_date": "2026-09-23", "severity": "1"}


def test_create_change_home_manager_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_change_home_manager",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHG-MGR-20260914-0001",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "lorche_d_no": "L0043",
                    },
                    "proposed_name": "Example Manager",
                },
            },
        )

    assert_accepted_business_response(
        response,
        request_id="CHG-MGR-20260914-0001",
        create_id="9001",
        application_type="change_home_manager",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_intake_for_change_home_manager"
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    staged_form = fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]
    assert staged_form == {
        "case_summary": {
            "office_code": "LORCHE",
            "lorche_d_no": "L0043",
        },
        "proposed_name": "Example Manager",
    }


@pytest.mark.parametrize(
    ("endpoint", "application_type", "specific_form"),
    [
        (
            "/v1/create_intake_for_change_beds",
            "change_beds",
            {
                "proposed_beds_self_care": 1,
                "proposed_beds_meal": 1,
                "proposed_beds_nursing": 1,
                "proposed_beds_care_and_attention": 1,
                "proposed_residents_total_ab": 4,
                "proposed_residents_total_a": 2,
                "proposed_residents_total_b": 2,
                "proposed_residents_self_care": 1,
                "proposed_residents_meal": 1,
                "proposed_residents_nursing": 1,
                "proposed_residents_care_and_attention": 1,
                "proposed_residents_nursing_beyond": 0,
                "proposed_residents_nonelderly_mental": 0,
                "proposed_residents_nonelderly_intellectual": 0,
                "proposed_residents_nonelderly_physical": 0,
                "proposed_residents_nonelderly_others": 0,
                "proposed_residents_nonelderly_other_details_num": 0,
            },
        ),
        (
            "/v1/create_intake_for_change_operation_mode",
            "change_operation_mode",
            {"proposed_rch_nature_code": "PN"},
        ),
        (
            "/v1/create_intake_for_change_directors",
            "change_directors",
            {
                "title": "0",
                "name_en": "Example Director",
                "name_cn": "示例董事",
                "date_of_directors_change": "2026-09-23",
                "authorised_to_apply": True,
                "means_of_authorisation": "0",
                "digital_organisation_certificate_name_en": "Example Limited",
                "other_phone_number": "21234567",
            },
        ),
        (
            "/v1/create_intake_for_change_nurse_in_charge",
            "change_nurse_in_charge",
            {"person_title": "3", "name": "Example Nurse"},
        ),
    ],
)
def test_create_change_monitoring_types_return_accepted(
    endpoint: str,
    application_type: str,
    specific_form: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    form_data = {
        "case_summary": {
            "office_code": "LORCHE",
            "lorche_d_no": "L0043",
        },
        **specific_form,
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": f"{application_type}-20260923-0001",
                "form_data": form_data,
            },
        )

    assert_accepted_business_response(
        response,
        request_id=f"{application_type}-20260923-0001",
        create_id="9001",
        application_type=application_type,
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"
    staged_form = fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]
    assert "attachment_ids" not in staged_form
    if application_type == "change_directors":
        assert "documents" not in staged_form


def test_create_change_nurse_in_charge_allows_lorchd_home() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.home_records = [
        {
            "id": 376863288262673,
            "f_rch_no": "D0043",
            "f_office_cd": "LORCHD",
            "fk_type_of_rch": 202,
        }
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_change_nurse_in_charge",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "NURSE-D-20261016-0001",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHD",
                        "rch_no": "D0043",
                    },
                    "person_title": "3",
                    "name": "Example Nurse",
                },
            },
        )

    assert_accepted_business_response(
        response,
        request_id="NURSE-D-20261016-0001",
        create_id="9001",
        application_type="change_nurse_in_charge",
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == ("376863288262673")


@pytest.mark.parametrize(
    ("endpoint", "create_api_type", "application_type"),
    [
        (
            "/v1/update_change_home_manager_data",
            "create_intake_for_change_home_manager",
            "change_home_manager",
        ),
        (
            "/v1/update_change_beds_data",
            "create_intake_for_change_beds",
            "change_beds",
        ),
        (
            "/v1/update_change_operation_mode_data",
            "create_intake_for_change_operation_mode",
            "change_operation_mode",
        ),
        (
            "/v1/update_change_directors_data",
            "create_intake_for_change_directors",
            "change_directors",
        ),
        (
            "/v1/update_change_nurse_in_charge_data",
            "create_intake_for_change_nurse_in_charge",
            "change_nurse_in_charge",
        ),
    ],
)
def test_update_change_monitoring_types_return_accepted(
    endpoint: str,
    create_api_type: str,
    application_type: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": create_api_type,
            "f_application_type": application_type,
            "f_rch_id": "376863288262672",
            "f_request_body": {
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                    }
                }
            },
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            endpoint,
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": f"{application_type}-update-1",
                "create_id": "384761337741312",
                "form_data": {"proposed_effective_date": "2026-10-16"},
            },
        )

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["application_type"] == application_type
    assert body["status"] == "Accepted"


def test_update_change_beds_is_locked_after_submitted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_change_beds",
            "f_application_type": "change_beds",
            "f_application_status": "Received",
            "f_rch_id": "376863288262672",
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_change_beds_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "CHG-BEDS-LOCKED-1",
                "create_id": "384761337741312",
                "form_data": {"proposed_effective_date": "2026-10-16"},
            },
        )

    assert_update_locked_response(response)


def test_create_prosecution_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_prosecution",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "PRO-20260914-0001",
                "form_data": {
                    "case_summary": {
                        "office_code": "LORCHE",
                        "lorche_d_no": "L0043",
                    },
                    "legal_advice_result": "Go for Prosecution",
                    "unlicenced_rch": False,
                    "comments": "Phase G prosecution",
                },
            },
        )

    assert_accepted_business_response(
        response,
        request_id="PRO-20260914-0001",
        create_id="9001",
        application_type="prosecution",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_intake_for_prosecution"
    )
    assert fake_client.staging_calls[0]["values"]["f_rch_id"] == "376863288262672"


def test_create_licence_renewal_resolves_home_record_and_returns_accepted() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "LRN-20260914-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "rch_no": "l0043",
            },
            "part_1": {"application_received_date": "2026-10-15"},
        },
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_licence_renewal",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="LRN-20260914-0001",
        create_id="9001",
        application_type="licence_renewal",
    )
    assert fake_client.staging_calls[0]["values"]["f_api_type"] == (
        "create_licence_renewal"
    )
    staged_form = fake_client.staging_calls[0]["values"]["f_request_body"]["form_data"]
    staged_summary = staged_form["case_summary"]
    personnel_keys = {
        "submitter_user_id",
        "task_owner_user_id",
        "task_owner_post_code",
    }
    assert personnel_keys.isdisjoint(staged_summary)


@pytest.mark.parametrize("alternative", ["lorche_d_no", "p_no"])
def test_create_licence_renewal_requires_rch_no(
    alternative: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "LRN-REQUIRES-RCH-NO",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                alternative: "PE0177" if alternative == "p_no" else "L0043",
            },
            "part_1": {"application_received_date": "2026-10-15"},
        },
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_licence_renewal",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "missing_required"
    assert "form_data.case_summary.rch_no" in response.json()["missing_required_fields"]
    assert fake_client.list_calls == []


def test_create_licence_renewal_rejects_prior_create_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "LRN-NO-PRIOR-CREATE-ID",
        "create_id": "prior-create-id",
        "form_data": {
            "case_summary": {"office_code": "LORCHE", "rch_no": "L0043"},
            "part_1": {"application_received_date": "2026-10-15"},
        },
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_licence_renewal",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert any(
        item["path"] == "create_id" for item in response.json()["validation_errors"]
    )
    assert fake_client.list_calls == []


def test_update_licence_renewal_allows_cmtf_create_request() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request = {
        "id": "386000000000001",
        "f_source_system": "CMTF",
        "f_request_event": "CREATE",
        "f_api_type": "create_licence_renewal",
        "f_application_type": "licence_renewal",
        "f_office_code": "LORCHE",
        "f_status": "succeeded",
        "f_intake_id": None,
        "f_application_id": "386000000000003",
        "f_application_status": "Accepted",
        "f_rch_id": "376863288262672",
    }
    payload = {
        "request_id": "LRN-UPDATE-CMTF-1",
        "create_id": "386000000000001",
        "form_data": {"part_1": {"application_received_date": "2026-10-16"}},
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert_accepted_business_response(
        response,
        request_id="LRN-UPDATE-CMTF-1",
        create_id="386000000000001",
        application_type="licence_renewal",
    )
    assert fake_client.staging_calls[0]["values"]["f_request_event"] == "UPDATE"


def test_update_licence_renewal_is_disabled_before_safe_workflow_cutover() -> None:
    application = create_app(settings(lrn_update_enabled=False))
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "LRN-UPDATE-BLOCKED-1",
                "create_id": "386000000000001",
                "form_data": {"part_1": {"application_received_date": "2026-10-16"}},
            },
        )

    assert response.status_code == 503
    assert response.json()["error"]["code"] == "update_temporarily_unavailable"
    assert fake_client.staging_calls == []
    assert fake_client.list_calls == []


def test_update_prosecution_is_disabled_before_safe_workflow_cutover() -> None:
    application = create_app(settings(prosecution_update_enabled=False))
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_prosecution_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "PROSECUTION-UPDATE-BLOCKED-1",
                "create_id": "386000000000001",
                "form_data": {},
            },
        )

    assert response.status_code == 503
    assert response.json()["error"]["code"] == "update_temporarily_unavailable"
    assert fake_client.staging_calls == []
    assert fake_client.list_calls == []


@pytest.mark.parametrize(
    ("create_status", "intake_id", "application_id"),
    [
        ("processing", "386000000000002", "386000000000003"),
        ("succeeded", "386000000000002", None),
    ],
)
def test_update_licence_renewal_rejects_before_create_is_ready(
    create_status: str,
    intake_id: Optional[str],
    application_id: Optional[str],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_licence_renewal",
            "f_application_type": "licence_renewal",
            "f_rch_id": "376863288262672",
            "f_status": create_status,
            "f_intake_id": intake_id,
            "f_application_id": application_id,
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "LRN-UPDATE-CREATE-NOT-READY",
                "create_id": "384761337741312",
                "form_data": {"part_1": {"application_received_date": "2026-10-16"}},
            },
        )

    assert response.status_code == 409
    assert response.json()["error"]["code"] == "create_not_ready"
    assert fake_client.staging_calls == []


def test_update_licence_renewal_accepts_checklist_file_replacement() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_NLA_001")
    fake_client.attachment_records[98771] = {"id": 98771}
    fake_client.original_request = {
        "id": "386000000000001",
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_licence_renewal",
        "f_application_type": "licence_renewal",
        "f_office_code": "LORCHE",
        "f_status": "succeeded",
        "f_intake_id": "386000000000002",
        "f_application_id": "386000000000003",
        "f_application_status": "Accepted",
        "f_rch_id": "376863288262672",
    }
    checklist = [{"position_code": "LORCHE_NLA_001", "attachment_id": 98771}]

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "LRN-UPDATE-CHECKLIST-1",
                "create_id": "386000000000001",
                "form_data": {"part_5": {"checklist": checklist}},
            },
        )

    assert response.status_code == 200
    staged_body = fake_client.staging_calls[0]["values"]["f_request_body"]
    assert staged_body["form_data"]["part_5"]["checklist"] == checklist
    assert fake_catalog.calls[0]["application_collection"] == "t_licence_app"


@pytest.mark.parametrize(
    ("position_code", "expected_code"),
    [
        ("NOT_IN_CATALOG", "invalid_checklist_item"),
        ("LORCHE_NLA_001", "missing_document"),
    ],
)
def test_update_licence_renewal_checks_catalog_and_file_before_staging(
    position_code: str,
    expected_code: str,
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_licence_renewal",
            "f_application_type": "licence_renewal",
            "f_rch_id": "376863288262672",
        }
    )
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_NLA_001")

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "LRN-UPDATE-CHECKLIST-PREFLIGHT",
                "create_id": "384761337741312",
                "form_data": {
                    "part_5": {
                        "checklist": [
                            {"position_code": position_code, "attachment_id": 98771}
                        ]
                    }
                },
            },
        )

    assert response.status_code == 422
    assert response.json()["error"]["code"] == expected_code
    assert len(fake_client.staging_calls) == 1
    assert fake_client.staging_calls[0]["values"]["f_status"] == ("invalid_request")


def test_update_licence_renewal_requires_checklist_attachment_id() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request = {
        "id": "386000000000001",
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_licence_renewal",
        "f_application_type": "licence_renewal",
        "f_office_code": "LORCHE",
        "f_status": "succeeded",
        "f_intake_id": "386000000000002",
        "f_application_id": "386000000000003",
        "f_application_status": "Accepted",
        "f_rch_id": "376863288262672",
    }

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "LRN-UPDATE-CHECKLIST-2",
                "create_id": "386000000000001",
                "form_data": {
                    "part_5": {"checklist": [{"position_code": "LORCHE_NLA_001"}]}
                },
            },
        )

    assert response.status_code == 422
    assert response.json()["missing_required_fields"] == [
        "form_data.part_5.checklist.0.attachment_id"
    ]


@pytest.mark.parametrize(
    "part",
    [
        {"part_1": {"application_type": "0"}},
        {"part_2": {"rch_name_en": "Not supported"}},
        {"part_5": {"application_level": "high"}},
    ],
)
def test_licence_renewal_rejects_fields_not_written_by_workflow(
    part: dict[str, Any],
) -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    payload = {
        "request_id": "LRN-UNSUPPORTED-FIELD",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "rch_no": "L0043",
                "submitter_user_id": 12,
                "task_owner_user_id": 45,
                "task_owner_post_code": "S(LR)1",
            },
            **part,
        },
    }
    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_licence_renewal",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )
    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"


def test_health_responses_follow_public_api_contract() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        application.state.client.check_readiness = AsyncMock(return_value=True)
        live_response = client.get("/health/live")
        ready_response = client.get("/health/ready")

    assert live_response.status_code == 200
    assert live_response.json() == {"status": "ok"}
    assert ready_response.status_code == 200
    assert ready_response.json() == {"status": "ready"}


def test_health_ready_returns_public_503_when_dependency_is_unavailable() -> None:
    application = create_app(settings())

    with TestClient(application) as client:
        application.state.client.check_readiness = AsyncMock(return_value=False)
        response = client.get("/health/ready")

    assert response.status_code == 503
    assert response.json()["ok"] is False
    assert response.json()["error"]["code"] == "service_not_ready"
    assert "root-config-token" not in response.text


def test_health_ready_requires_configured_upstream_token() -> None:
    application = create_app(replace(settings(), nocobase_config_token=None))

    with TestClient(application) as client:
        response = client.get("/health/ready")

    assert response.status_code == 503
    assert response.json()["error"]["code"] == "service_not_ready"


def valid_expansion_aip_payload() -> dict[str, Any]:
    return {
        "request_id": "AIP-20260924-0001",
        "form_data": {
            "case_summary": {
                "office_code": "LORCHE",
                "rch_no": "L0043",
            },
            "part_1": {
                "title": "0",
                "name_eng": "Example Applicant",
                "authorised_to_apply_by_operator": True,
                "means_of_authorisation": "0",
                "hkic_number1": "A123456",
                "hkic_number2": "7",
            },
            "part_2": {
                "address_chi_expansion": "香港示例地址",
                "address_eng_expansion": "Example Address, Hong Kong",
                "tentative_licencing_capacity_expansion": 120,
                "tentative_area_of_floor_space_expansion": "580.5",
                "number_of_beds_expansion": 100,
            },
            "part_3": {"checklist": []},
        },
    }


def test_create_expansion_aip_resolves_home_and_stages_accepted_request() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/create_intake_for_expansion_aip",
            headers={"Authorization": "Bearer valid-client-token"},
            json=valid_expansion_aip_payload(),
        )

    assert_accepted_business_response(
        response,
        request_id="AIP-20260924-0001",
        create_id="9001",
        application_type="expansion_aip",
    )
    staged = fake_client.staging_calls[0]["values"]
    assert staged["f_api_type"] == "create_intake_for_expansion_aip"
    assert staged["f_application_type"] == "expansion_aip"
    assert staged["f_application_status"] == "Accepted"
    assert staged["f_rch_id"] == "376863288262672"
    assert (
        staged["f_request_body"]["form_data"]["part_2"][
            "tentative_area_of_floor_space_expansion"
        ]
        == 580.5
    )


def test_create_expansion_aip_preflights_shared_licence_checklist() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.attachment_records[502] = {"id": 502, "filename": "file.pdf"}
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_APP_FILE_001")
    payload = valid_expansion_aip_payload()
    payload["form_data"]["part_3"]["checklist"] = [
        {"position_code": "LORCHE_APP_FILE_001", "attachment_id": 502}
    ]

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/create_intake_for_expansion_aip",
            headers={"Authorization": "Bearer valid-client-token"},
            json=payload,
        )

    assert response.status_code == 200, response.text
    assert fake_catalog.calls[0]["application_collection"] == "t_licence_app"
    assert fake_client.attachment_get_calls[0]["record_id"] == 502


def test_update_expansion_aip_preflights_shared_licence_checklist() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.attachment_records[502] = {"id": 502, "filename": "file.pdf"}
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_expansion_aip",
            "f_application_type": "expansion_aip",
            "f_rch_id": "376863288262672",
            "f_request_body": valid_expansion_aip_payload(),
        }
    )
    fake_catalog = FakeChecklistCatalogQueryService("LORCHE_APP_FILE_001")

    with TestClient(application) as client:
        application.state.client = fake_client
        application.state.query_service = fake_catalog
        response = client.post(
            "/v1/update_expansion_aip_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "AIP-UPDATE-CHECKLIST-1",
                "create_id": "384761337741312",
                "form_data": {
                    "part_3": {
                        "checklist": [
                            {
                                "position_code": "LORCHE_APP_FILE_001",
                                "attachment_id": 502,
                            }
                        ]
                    }
                },
            },
        )

    assert response.status_code == 200, response.text
    assert fake_catalog.calls[0]["application_collection"] == "t_licence_app"
    assert fake_client.attachment_get_calls[0]["record_id"] == 502


def test_update_expansion_aip_supports_empty_checklist_replacement() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_expansion_aip",
            "f_application_type": "expansion_aip",
            "f_rch_id": "376863288262672",
            "f_request_body": valid_expansion_aip_payload(),
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_expansion_aip_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "AIP-UPDATE-1",
                "create_id": "384761337741312",
                "form_data": {"part_3": {"checklist": []}},
            },
        )

    assert_accepted_business_response(
        response,
        request_id="AIP-UPDATE-1",
        create_id="384761337741312",
        application_type="expansion_aip",
    )
    staged = fake_client.staging_calls[0]["values"]
    assert staged["f_api_type"] == "update_expansion_aip_data"
    assert staged["f_parent_create_id"] == "384761337741312"
    assert staged["f_request_body"]["form_data"]["part_3"]["checklist"] == []
    assert staged["f_active_update_id"]


def test_update_expansion_aip_accepts_partial_intake_metadata() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()
    fake_client.original_request.update(
        {
            "f_api_type": "create_intake_for_expansion_aip",
            "f_application_type": "expansion_aip",
            "f_rch_id": "376863288262672",
            "f_request_body": valid_expansion_aip_payload(),
        }
    )

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_expansion_aip_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "AIP-UPDATE-INTAKE-1",
                "create_id": "384761337741312",
                "form_data": {
                    "case_summary": {
                        "received_date": "2026-09-25",
                        "severity": "1",
                    }
                },
            },
        )

    assert response.status_code == 200, response.text
    staged_summary = fake_client.staging_calls[0]["values"]["f_request_body"][
        "form_data"
    ]["case_summary"]
    assert staged_summary == {
        "received_date": "2026-09-25",
        "severity": "1",
    }


def test_update_expansion_aip_rejects_null_checklist() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_expansion_aip_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "AIP-UPDATE-NULL",
                "create_id": "384761337741312",
                "form_data": {"part_3": {"checklist": None}},
            },
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert "cannot be null" in str(response.json()["validation_errors"])


def test_update_expansion_aip_rejects_empty_section_as_noop() -> None:
    application = create_app(settings())
    fake_client = FakeAuthClient()

    with TestClient(application) as client:
        application.state.client = fake_client
        response = client.post(
            "/v1/update_expansion_aip_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "AIP-UPDATE-NOOP",
                "create_id": "384761337741312",
                "form_data": {"part_1": {}},
            },
        )

    assert response.status_code == 422
    assert response.json()["status"] == "invalid_request"
    assert "at least one changed field" in str(response.json()["validation_errors"])
