from pathlib import Path

import pytest

from app.errors import AdapterError
from app.mappings import ApplicationMappings

MAPPING_PATH = Path(__file__).parents[1] / "config/application-mappings.yaml"


def test_resolves_enabled_attachment_mapping() -> None:
    mappings = ApplicationMappings.load(MAPPING_PATH)

    application, field = mappings.resolve(
        "nla", "applicationForm", "application_form"
    )

    assert application.collection == "t_licence_app"
    assert field.internal_field == "f_attachments_of_rchs"
    assert field.multiple is True


def test_rejects_unknown_application_type() -> None:
    mappings = ApplicationMappings.load(MAPPING_PATH)

    with pytest.raises(AdapterError) as caught:
        mappings.resolve("unknown", "applicationForm", "APPLICATION_FORM")

    assert caught.value.code == "unsupported_application_type"


def test_rejects_unknown_document_type() -> None:
    mappings = ApplicationMappings.load(MAPPING_PATH)

    with pytest.raises(AdapterError) as caught:
        mappings.resolve("NLA", "applicationForm", "UNKNOWN")

    assert caught.value.code == "unsupported_document_type"
