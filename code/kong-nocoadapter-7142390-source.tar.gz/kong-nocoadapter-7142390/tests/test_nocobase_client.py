from __future__ import annotations

import asyncio
import json
from dataclasses import replace
from io import BytesIO
from pathlib import Path

import httpx
import pytest

from app.errors import AdapterError
from app.nocobase_client import NocoBaseClient
from app.nocobase_config import NocoBaseProfile
from app.settings import Settings

PROFILE_PATH = Path(__file__).parents[1] / "config/nocobase.yaml"
CONFIG_TOKEN = "root-config-token"
CLIENT_TOKEN = "client-native-token"


class MockAsyncStream(httpx.AsyncByteStream):
    def __init__(self, content: bytes) -> None:
        self.content = content

    async def __aiter__(self):
        yield self.content


def settings(*, default_storage: bool = True) -> Settings:
    profile = replace(
        NocoBaseProfile.load(PROFILE_PATH),
        base_url="http://example.test/cmtf2",
        storage_selection="default" if default_storage else "named",
        storage_name=None if default_storage else "named-storage",
    )
    return Settings(
        nocobase=profile,
        nocobase_config_token=CONFIG_TOKEN,
        verify_tls=True,
        storage_cache_seconds=0,
        max_file_bytes=1024,
        allowed_mime_types=frozenset({"application/pdf"}),
        connect_timeout_seconds=1,
        request_timeout_seconds=1,
        upload_timeout_seconds=1,
        max_connections=5,
        log_level="INFO",
    )


async def mock_client(
    handler,
    *,
    default_storage: bool = True,
    object_handler=None,
):
    client = NocoBaseClient(settings(default_storage=default_storage))
    await client.start()
    assert client._client is not None
    await client._client.aclose()
    client._client = httpx.AsyncClient(
        base_url="http://example.test/cmtf2",
        transport=httpx.MockTransport(handler),
    )
    if object_handler is not None:
        assert client._object_client is not None
        await client._object_client.aclose()
        client._object_client = httpx.AsyncClient(
            transport=httpx.MockTransport(object_handler),
        )
    return client


@pytest.mark.asyncio
async def test_native_sign_in_preserves_token_without_bearer_or_config_token() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["headers"] = dict(request.headers)
        captured["body"] = json.loads(request.content)
        return httpx.Response(200, json={"data": {"token": "native-token"}})

    client = await mock_client(handler)
    try:
        result = await client.sign_in(
            account="assigned-client", password="not-logged", request_id="trace-1"
        )
    finally:
        await client.close()

    assert result == {"data": {"token": "native-token"}}
    assert captured["path"] == "/cmtf2/api/auth:signIn"
    assert captured["body"] == {
        "account": "assigned-client",
        "password": "not-logged",
    }
    headers = captured["headers"]
    assert isinstance(headers, dict)
    assert "authorization" not in headers
    assert headers["x-authenticator"] == "basic"
    assert headers["x-request-id"] == "trace-1"


@pytest.mark.asyncio
async def test_native_sign_in_projects_only_documented_token() -> None:
    client = await mock_client(
        lambda _request: httpx.Response(
            200,
            json={
                "data": {"token": "native-token", "user": {"id": 42}},
                "meta": {"session": "internal"},
            },
        )
    )
    try:
        result = await client.sign_in(
            account="assigned-client", password="secret", request_id="trace-projection"
        )
    finally:
        await client.close()

    assert result == {"data": {"token": "native-token"}}


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("upstream_status", "body", "expected_status", "expected_code"),
    [
        (401, {"message": "secret password"}, 401, "invalid_credentials"),
        (200, {"errors": [{"message": "secret password"}]}, 401, "invalid_credentials"),
        (429, {"message": "rate limit"}, 429, "rate_limit_exceeded"),
        (503, {"message": "internal details"}, 503, "service_unavailable"),
        (200, {"data": {}}, 502, "upstream_error"),
    ],
)
async def test_native_sign_in_normalizes_failures_without_upstream_detail(
    upstream_status: int,
    body: dict[str, object],
    expected_status: int,
    expected_code: str,
) -> None:
    client = await mock_client(
        lambda _request: httpx.Response(upstream_status, json=body)
    )
    try:
        with pytest.raises(AdapterError) as caught:
            await client.sign_in(
                account="assigned-client",
                password="secret password",
                request_id="trace-2",
            )
    finally:
        await client.close()

    assert caught.value.status_code == expected_status
    assert caught.value.code == expected_code
    assert "secret password" not in caught.value.message
    assert "internal details" not in caught.value.message


@pytest.mark.asyncio
async def test_native_sign_in_connection_failure_is_service_unavailable() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("upstream unavailable", request=request)

    client = await mock_client(handler)
    try:
        with pytest.raises(AdapterError) as caught:
            await client.sign_in(
                account="assigned-client",
                password="secret password",
                request_id="trace-3",
            )
    finally:
        await client.close()

    assert caught.value.status_code == 503
    assert caught.value.code == "service_unavailable"


@pytest.mark.asyncio
async def test_storage_discovery_uses_only_global_config_token() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["authorization"] = request.headers["authorization"]
        captured["authenticator"] = request.headers["x-authenticator"]
        return httpx.Response(
            200,
            json={
                "data": {
                    "id": 2,
                    "title": "Default S3 Pro",
                    "name": "default-s3-pro",
                    "type": "s3-compatible",
                    "rules": {"size": 20971520},
                }
            },
        )

    client = await mock_client(handler)
    try:
        storage = await client.get_storage("request-1")
    finally:
        await client.close()

    assert captured["path"] == "/cmtf2/api/storages:getBasicInfo"
    assert captured["authorization"] == f"Bearer {CONFIG_TOKEN}"
    assert captured["authenticator"] == "basic"
    assert storage.type == "s3-compatible"


@pytest.mark.asyncio
async def test_reads_named_storage_using_configured_path() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        return httpx.Response(
            200,
            json={
                "data": {
                    "id": 3,
                    "title": "Named S3 Pro",
                    "name": "named-storage",
                    "type": "s3-compatible",
                }
            },
        )

    client = await mock_client(handler, default_storage=False)
    try:
        storage = await client.get_storage("request-named")
    finally:
        await client.close()

    assert captured["path"] == (
        "/cmtf2/api/storages:getBasicInfo/named-storage"
    )
    assert storage.name == "named-storage"


@pytest.mark.asyncio
async def test_s3_record_creation_uses_client_token() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["query"] = request.url.query.decode()
        captured["authorization"] = request.headers["authorization"]
        captured["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={"data": {"id": 99, "filename": "api/generated.pdf"}},
        )

    client = await mock_client(handler)
    try:
        attachment = await client.create_attachment(
            file_info={
                "title": "application.pdf",
                "key": "api/generated.pdf",
                "extname": ".pdf",
                "size": 9,
                "mimetype": "application/pdf",
                "meta": {},
            },
            storage_id=2,
            request_id="request-create-attachment",
            authorization_token=CLIENT_TOKEN,
            attachment_field_context=(
                "t_licence_app.f_attachments_of_rchs"
            ),
        )
    finally:
        await client.close()

    assert captured["path"] == "/cmtf2/api/attachments:create"
    assert captured["query"] == (
        "attachmentField=t_licence_app.f_attachments_of_rchs"
    )
    assert captured["authorization"] == f"Bearer {CLIENT_TOKEN}"
    assert captured["body"] == {
        "title": "application.pdf",
        "filename": "api/generated.pdf",
        "extname": ".pdf",
        "path": "",
        "size": 9,
        "url": "",
        "mimetype": "application/pdf",
        "meta": {},
        "storageId": 2,
    }
    assert attachment["id"] == 99


@pytest.mark.asyncio
async def test_server_side_upload_uses_client_token_and_multipart() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["authorization"] = request.headers["authorization"]
        content_type = request.headers["content-type"]
        captured["content_type"] = content_type
        captured["body"] = request.content
        return httpx.Response(
            200,
            json={"data": {"id": 100, "filename": "uploads/local.pdf"}},
        )

    client = await mock_client(handler)
    try:
        attachment = await client.upload_attachment_file(
            filename="local.pdf",
            mime_type="application/pdf",
            file_object=BytesIO(b"%PDF-local"),
            request_id="request-local",
            authorization_token=CLIENT_TOKEN,
        )
    finally:
        await client.close()

    assert captured["path"] == "/cmtf2/api/attachments:create"
    assert captured["authorization"] == f"Bearer {CLIENT_TOKEN}"
    assert str(captured["content_type"]).startswith("multipart/form-data;")
    assert b'%PDF-local' in captured["body"]
    assert attachment["id"] == 100


@pytest.mark.asyncio
async def test_checks_client_token_with_basic_authenticator() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["authorization"] = request.headers["authorization"]
        captured["authenticator"] = request.headers["x-authenticator"]
        return httpx.Response(
            200,
            json={"data": {"id": 42, "username": "op-test"}},
        )

    client = await mock_client(handler)
    try:
        identity = await client.check_access_token(
            CLIENT_TOKEN,
            "request-auth-check",
        )
    finally:
        await client.close()

    assert captured["path"] == "/cmtf2/api/auth:check"
    assert captured["authorization"] == f"Bearer {CLIENT_TOKEN}"
    assert captured["authenticator"] == "basic"
    assert identity["id"] == 42


@pytest.mark.asyncio
async def test_readiness_checks_nocobase_auth_with_global_token() -> None:
    captured: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["authorization"] = request.headers["authorization"]
        return httpx.Response(200, json={"data": {"id": 1}})

    client = await mock_client(handler)
    try:
        assert await client.check_readiness() is True
    finally:
        await client.close()

    assert captured == {
        "path": "/cmtf2/api/auth:check",
        "authorization": f"Bearer {CONFIG_TOKEN}",
    }


@pytest.mark.asyncio
async def test_readiness_rejects_unavailable_or_unconfigured_dependency() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"errors": [{"message": "Denied"}]})

    client = await mock_client(handler)
    try:
        assert await client.check_readiness() is False
        client._settings = replace(settings(), nocobase_config_token=None)
        assert await client.check_readiness() is False
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_readiness_probe_has_bounded_total_timeout(monkeypatch) -> None:
    monkeypatch.setattr("app.nocobase_client.READINESS_TIMEOUT_SECONDS", 0.01)
    client = NocoBaseClient(settings())

    async def stalled_auth(_token: str, _request_id: str) -> dict[str, object]:
        await asyncio.sleep(1)
        return {"id": 1}

    monkeypatch.setattr(client, "check_access_token", stalled_auth)
    assert await client.check_readiness() is False


@pytest.mark.asyncio
async def test_conditional_record_update_sends_one_atomic_filter() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["filter"] = json.loads(request.url.params["filter"])
        captured["authorization"] = request.headers["authorization"]
        captured["body"] = json.loads(request.content)
        return httpx.Response(200, json={"data": []})

    client = await mock_client(handler)
    try:
        await client.update_record_if(
            collection="t_api_request_staging",
            record_id=9001,
            expected={"f_status": "submitted", "f_active_update_id": None},
            request_id="request-conditional-update",
            authorization_token=CLIENT_TOKEN,
            values={
                "f_status": "failed",
                "f_error_message": "update_locked_after_admission",
            },
        )
    finally:
        await client.close()

    assert captured == {
        "path": "/cmtf2/api/t_api_request_staging:update",
        "filter": {
            "$and": [
                {"id": {"$eq": 9001}},
                {"f_status": {"$eq": "submitted"}},
                {"f_active_update_id": {"$empty": True}},
            ]
        },
        "authorization": f"Bearer {CLIENT_TOKEN}",
        "body": {
            "f_status": "failed",
            "f_error_message": "update_locked_after_admission",
        },
    }


@pytest.mark.asyncio
async def test_business_webhook_preserves_response_and_client_identity() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["query"] = request.url.query.decode()
        captured["authorization"] = request.headers["authorization"]
        captured["authenticator"] = request.headers["x-authenticator"]
        return httpx.Response(
            200,
            json={"data": [{"f_rch_no": "L0043"}]},
        )

    client = await mock_client(handler)
    try:
        result = await client.trigger_business_webhook(
            path="/api/webhook:trigger/home",
            request_id="request-home",
            authorization_token=CLIENT_TOKEN,
            params=[("rchNo", "L0043")],
        )
    finally:
        await client.close()

    assert captured["path"] == "/cmtf2/api/webhook:trigger/home"
    assert captured["query"] == "rchNo=L0043"
    assert captured["authorization"] == f"Bearer {CLIENT_TOKEN}"
    assert captured["authenticator"] == "basic"
    assert result == {"data": [{"f_rch_no": "L0043"}]}


@pytest.mark.asyncio
async def test_request_staging_create_uses_client_identity() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["path"] = request.url.path
        captured["authorization"] = request.headers["authorization"]
        captured["authenticator"] = request.headers["x-authenticator"]
        captured["request_id"] = request.headers["x-request-id"]
        captured["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={"data": {"id": 9001, "f_status": "received"}},
        )

    client = await mock_client(handler)
    try:
        result = await client.create_request_staging(
            request_id="request-nla",
            authorization_token=CLIENT_TOKEN,
            values={
                "f_request_body": {"request_id": "NLA-1"},
                "f_source_system": "OP",
                "f_request_event": "CREATE",
                "f_api_type": "create_intake_for_new_licence",
                "f_user_role": "external_operator",
                "f_status": "received",
            },
        )
    finally:
        await client.close()

    assert captured["path"] == "/cmtf2/api/t_api_request_staging:create"
    assert captured["authorization"] == f"Bearer {CLIENT_TOKEN}"
    assert captured["authenticator"] == "basic"
    assert captured["request_id"] == "request-nla"
    assert captured["body"] == {
        "f_request_body": {"request_id": "NLA-1"},
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_user_role": "external_operator",
        "f_status": "received",
    }
    assert result["id"] == 9001


@pytest.mark.asyncio
async def test_request_staging_create_requires_created_record_id() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"data": {"f_status": "received"}})

    client = await mock_client(handler)
    try:
        with pytest.raises(AdapterError) as caught:
            await client.create_request_staging(
                request_id="request-nla-no-id",
                authorization_token=CLIENT_TOKEN,
                values={"f_status": "received"},
            )
    finally:
        await client.close()

    assert caught.value.status_code == 502
    assert caught.value.code == "invalid_staging_create_response"


@pytest.mark.asyncio
async def test_rejects_invalid_client_token_as_unauthorized() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"errors": [{"message": "No"}]})

    client = await mock_client(handler)
    try:
        with pytest.raises(AdapterError) as caught:
            await client.check_access_token(
                "invalid-client-token",
                "request-auth-invalid",
            )
    finally:
        await client.close()

    assert caught.value.status_code == 401
    assert caught.value.code == "invalid_client_token"


@pytest.mark.asyncio
async def test_reports_missing_global_config_token() -> None:
    no_token_settings = replace(settings(), nocobase_config_token=None)
    client = NocoBaseClient(no_token_settings)

    with pytest.raises(AdapterError) as caught:
        await client.get_storage("request-no-config-token")

    assert caught.value.status_code == 503
    assert caught.value.code == "storage_config_token_missing"


@pytest.mark.asyncio
async def test_reports_invalid_global_config_token_as_service_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"errors": [{"message": "No"}]})

    client = await mock_client(handler)
    try:
        with pytest.raises(AdapterError) as caught:
            await client.get_storage("request-invalid-config-token")
    finally:
        await client.close()

    assert caught.value.status_code == 503
    assert caught.value.code == "storage_config_access_denied"


@pytest.mark.asyncio
async def test_local_download_streams_through_nocobase_with_client_token() -> None:
    captured: list[dict[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(
            {
                "path": request.url.path,
                "query": request.url.query.decode(),
                "authorization": request.headers.get("authorization", ""),
            }
        )
        if request.url.path.endswith("/files/main/main/attachments/99"):
            return httpx.Response(
                302,
                headers={
                    "Location": "/cmtf2/storage/uploads/generated.pdf?download=1"
                },
            )
        return httpx.Response(
            200,
            stream=MockAsyncStream(b"%PDF-downloaded"),
            headers={
                "Content-Type": "application/pdf",
                "Content-Length": "15",
                "Content-Disposition": 'attachment; filename="generated.pdf"',
            },
        )

    client = await mock_client(handler)
    try:
        download = await client.open_attachment_download(
            attachment_id=99,
            request_id="request-download-local",
            authorization_token=CLIENT_TOKEN,
        )
        body = b"".join([chunk async for chunk in download.content])
    finally:
        await client.close()

    assert body == b"%PDF-downloaded"
    assert download.headers["content-type"] == "application/pdf"
    assert download.headers["content-disposition"] == (
        'attachment; filename="generated.pdf"'
    )
    assert captured == [
        {
            "path": "/cmtf2/files/main/main/attachments/99",
            "query": "download=1",
            "authorization": f"Bearer {CLIENT_TOKEN}",
        },
        {
            "path": "/cmtf2/storage/uploads/generated.pdf",
            "query": "download=1",
            "authorization": f"Bearer {CLIENT_TOKEN}",
        },
    ]


@pytest.mark.asyncio
async def test_local_download_range_redirect_preserves_206() -> None:
    captured: list[dict[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(
            {
                "path": request.url.path,
                "range": request.headers.get("range", ""),
                "authorization": request.headers.get("authorization", ""),
            }
        )
        if request.url.path.endswith("/attachments/99"):
            return httpx.Response(
                302, headers={"Location": "/cmtf2/storage/uploads/generated.pdf"}
            )
        return httpx.Response(
            206,
            stream=MockAsyncStream(b"PDF"),
            headers={
                "Content-Type": "application/pdf",
                "Content-Range": "bytes 0-2/15",
                "Content-Length": "3",
                "Accept-Ranges": "bytes",
            },
        )

    client = await mock_client(handler)
    try:
        download = await client.open_attachment_download(
            attachment_id=99,
            request_id="request-download-local-range",
            authorization_token=CLIENT_TOKEN,
            byte_range="bytes=0-2",
        )
        body = b"".join([chunk async for chunk in download.content])
    finally:
        await client.close()

    assert body == b"PDF"
    assert download.status_code == 206
    assert download.headers["content-range"] == "bytes 0-2/15"
    assert captured == [
        {
            "path": "/cmtf2/files/main/main/attachments/99",
            "range": "bytes=0-2",
            "authorization": f"Bearer {CLIENT_TOKEN}",
        },
        {
            "path": "/cmtf2/storage/uploads/generated.pdf",
            "range": "bytes=0-2",
            "authorization": f"Bearer {CLIENT_TOKEN}",
        },
    ]


@pytest.mark.asyncio
async def test_s3_download_does_not_forward_client_token_to_object_host() -> None:
    object_headers: dict[str, str] = {}

    def nocobase_handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == f"Bearer {CLIENT_TOKEN}"
        return httpx.Response(
            302,
            headers={"Location": "https://objects.example.test/signed-file"},
        )

    def object_handler(request: httpx.Request) -> httpx.Response:
        object_headers.update(request.headers)
        return httpx.Response(
            200,
            stream=MockAsyncStream(b"object-body"),
            headers={"Content-Type": "application/octet-stream"},
        )

    client = await mock_client(
        nocobase_handler,
        object_handler=object_handler,
    )
    try:
        download = await client.open_attachment_download(
            attachment_id="s3-object-id",
            request_id="request-download-s3",
            authorization_token=CLIENT_TOKEN,
            byte_range="bytes=-5",
        )
        body = b"".join([chunk async for chunk in download.content])
    finally:
        await client.close()

    assert body == b"object-body"
    assert "authorization" not in object_headers
    assert "x-authenticator" not in object_headers
    assert "x-request-id" not in object_headers
    assert object_headers["range"] == "bytes=-5"


@pytest.mark.asyncio
@pytest.mark.parametrize("byte_range", ["bytes=4-3", "bytes=-0", "bytes=0-1,3-4"])
async def test_download_rejects_bad_range_before_upstream(byte_range: str) -> None:
    calls = 0

    def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(200, content=b"ignored")

    client = await mock_client(handler)
    try:
        with pytest.raises(AdapterError) as caught:
            await client.open_attachment_download(
                attachment_id=99,
                request_id="request-bad-range",
                authorization_token=CLIENT_TOKEN,
                byte_range=byte_range,
            )
    finally:
        await client.close()

    assert caught.value.status_code == 400
    assert caught.value.code == "invalid_range"
    assert calls == 0


@pytest.mark.asyncio
async def test_download_maps_unsatisfiable_range_to_invalid_range() -> None:
    client = await mock_client(
        lambda _request: httpx.Response(
            416, headers={"Content-Range": "bytes */15"}
        )
    )
    try:
        with pytest.raises(AdapterError) as caught:
            await client.open_attachment_download(
                attachment_id=99,
                request_id="request-unsatisfiable-range",
                authorization_token=CLIENT_TOKEN,
                byte_range="bytes=99-100",
            )
    finally:
        await client.close()

    assert caught.value.status_code == 400
    assert caught.value.code == "invalid_range"


@pytest.mark.asyncio
async def test_download_rejects_partial_body_without_content_range() -> None:
    client = await mock_client(
        lambda _request: httpx.Response(206, content=b"PDF")
    )
    try:
        with pytest.raises(AdapterError) as caught:
            await client.open_attachment_download(
                attachment_id=99,
                request_id="request-invalid-partial",
                authorization_token=CLIENT_TOKEN,
                byte_range="bytes=0-2",
            )
    finally:
        await client.close()

    assert caught.value.status_code == 502
    assert caught.value.code == "invalid_download_response"


@pytest.mark.asyncio
async def test_download_preserves_content_encoding_for_raw_stream() -> None:
    compressed = b"\x1f\x8bcompressed-body"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            stream=MockAsyncStream(compressed),
            headers={
                "Content-Type": "text/plain",
                "Content-Encoding": "gzip",
                "Content-Length": str(len(compressed)),
            },
        )

    client = await mock_client(handler)
    try:
        download = await client.open_attachment_download(
            attachment_id=1196,
            request_id="request-download-encoded",
            authorization_token=CLIENT_TOKEN,
        )
        body = b"".join([chunk async for chunk in download.content])
    finally:
        await client.close()

    assert body == compressed
    assert download.headers["content-encoding"] == "gzip"
    assert download.headers["content-length"] == str(len(compressed))


@pytest.mark.asyncio
async def test_download_maps_missing_attachment_to_stable_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"errors": [{"message": "Not found"}]})

    client = await mock_client(handler)
    try:
        with pytest.raises(AdapterError) as caught:
            await client.open_attachment_download(
                attachment_id=404,
                request_id="request-download-missing",
                authorization_token=CLIENT_TOKEN,
            )
    finally:
        await client.close()

    assert caught.value.status_code == 404
    assert caught.value.code == "attachment_not_found"
