from __future__ import annotations

from pathlib import Path

import pytest

from app.errors import ConfigurationError
from app.nocobase_config import NocoBaseProfile


def write_profile(
    path: Path,
    *,
    selection: str = "default",
    config_token: str | None = None,
) -> None:
    name = "" if selection == "default" else "test-storage"
    token_line = (
        "  config_token: null"
        if config_token is None
        else f'  config_token: "{config_token}"'
    )
    path.write_text(
        f"""
nocobase:
  version: "2.2.3"
  base_url: "http://example.test/app"
  authenticator: "basic"
{token_line}
  storage:
    selection: {selection}
    name: "{name}"
  api:
    auth_check: "/api/auth:check"
    simple_test: "/api/webhook:trigger/simple"
    homerecord_query: "/api/webhook:trigger/home"
    request_staging_create: "/api/t_api_request_staging:create"
    storage_basic_info: "/api/storage:default"
    storage_basic_info_by_name: "/api/storage:by-name/{{storage_name}}"
    create_presigned_url: "/api/files:presign"
    attachment_create: "/api/files:create"
    attachment_download: "/files/main/main/attachments/{{attachment_id}}"
  response:
    data_key: "result"
""".strip(),
        encoding="utf-8",
    )


def test_loads_replaceable_223_profile(tmp_path: Path) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path, selection="named")

    profile = NocoBaseProfile.load(path)

    assert profile.version == "2.2.3"
    assert profile.base_url == "http://example.test/app"
    assert profile.storage_name == "test-storage"
    assert profile.api.create_presigned_url == "/api/files:presign"
    assert profile.api.request_staging_create == (
        "/api/t_api_request_staging:create"
    )
    assert profile.api.attachment_download == (
        "/files/main/main/attachments/{attachment_id}"
    )
    assert profile.response_data_key == "result"
    assert profile.config_token is None
    assert profile.licence_renewal_update_enabled is False
    assert profile.prosecution_update_enabled is False
    assert profile.changing_home_operator_replacement_enabled is False


def test_licence_renewal_update_requires_boolean_feature_flag(tmp_path: Path) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path)
    original = path.read_text(encoding="utf-8")
    path.write_text(
        original.replace(
            '  authenticator: "basic"',
            '  authenticator: "basic"\n'
            '  features:\n'
            '    licence_renewal_update: true\n'
            '    prosecution_update: true',
        ),
        encoding="utf-8",
    )
    assert NocoBaseProfile.load(path).licence_renewal_update_enabled is True
    assert NocoBaseProfile.load(path).prosecution_update_enabled is True

    path.write_text(
        path.read_text(encoding="utf-8").replace(
            "licence_renewal_update: true", "licence_renewal_update: yes-please"
        ),
        encoding="utf-8",
    )
    with pytest.raises(ConfigurationError, match="licence_renewal_update"):
        NocoBaseProfile.load(path)

    path.write_text(
        path.read_text(encoding="utf-8")
        .replace("licence_renewal_update: yes-please", "licence_renewal_update: true")
        .replace("prosecution_update: true", "prosecution_update: yes-please"),
        encoding="utf-8",
    )
    with pytest.raises(ConfigurationError, match="prosecution_update"):
        NocoBaseProfile.load(path)


def test_chi_operator_replacement_requires_explicit_boolean_flag(
    tmp_path: Path,
) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path)
    original = path.read_text(encoding="utf-8")
    path.write_text(
        original.replace(
            '  authenticator: "basic"',
            '  authenticator: "basic"\n'
            '  features:\n'
            '    changing_home_operator_replacement: true',
        ),
        encoding="utf-8",
    )
    assert NocoBaseProfile.load(path).changing_home_operator_replacement_enabled

    path.write_text(
        path.read_text(encoding="utf-8").replace(
            "changing_home_operator_replacement: true",
            "changing_home_operator_replacement: ready",
        ),
        encoding="utf-8",
    )
    with pytest.raises(ConfigurationError, match="changing_home_operator_replacement"):
        NocoBaseProfile.load(path)


def test_loads_config_token_without_exposing_it_in_repr(tmp_path: Path) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path, config_token="  yaml-root-token  ")

    profile = NocoBaseProfile.load(path)

    assert profile.config_token == "yaml-root-token"
    assert "yaml-root-token" not in repr(profile)


def test_rejects_non_string_config_token(tmp_path: Path) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path)
    path.write_text(
        path.read_text(encoding="utf-8").replace(
            "config_token: null", "config_token: 12345"
        ),
        encoding="utf-8",
    )

    with pytest.raises(ConfigurationError, match="config_token"):
        NocoBaseProfile.load(path)


def test_environment_can_override_target_without_editing_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path, selection="named")
    monkeypatch.setenv("NOCOBASE_BASE_URL", "https://replacement.example/new")
    monkeypatch.setenv("NOCOBASE_STORAGE_SELECTION", "default")

    profile = NocoBaseProfile.load(path)

    assert profile.base_url == "https://replacement.example/new"
    assert profile.storage_selection == "default"
    assert profile.storage_name is None


def test_rejects_missing_storage_name_placeholder(tmp_path: Path) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path)
    text = path.read_text(encoding="utf-8").replace(
        "/api/storage:by-name/{storage_name}", "/api/storage:by-name"
    )
    path.write_text(text, encoding="utf-8")

    with pytest.raises(ConfigurationError, match="storage_basic_info_by_name"):
        NocoBaseProfile.load(path)


def test_rejects_missing_attachment_download_placeholder(
    tmp_path: Path,
) -> None:
    path = tmp_path / "nocobase.yaml"
    write_profile(path)
    text = path.read_text(encoding="utf-8").replace(
        "/files/main/main/attachments/{attachment_id}",
        "/files/main/main/attachments/fixed",
    )
    path.write_text(text, encoding="utf-8")

    with pytest.raises(ConfigurationError, match="attachment_download"):
        NocoBaseProfile.load(path)
