"""Offline safety tests for the versioned Notice status workflow patch."""

from __future__ import annotations

import copy
import json
import sys
import urllib.parse
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
import patch_nocobase_notice_status_workflows as patch  # noqa: E402


class FakeApi:
    def __init__(self, *, unique: bool = True, notices: list[dict] | None = None):
        self.calls: list[tuple[str, str, Any]] = []
        self.unique = unique
        self.dedupe_description = patch.DEDUPE_DESCRIPTION
        self.dedupe_ui_description = patch.DEDUPE_DESCRIPTION
        self.notices = notices or []
        self.notice_types = [
            {"value": patch.PN_NOTICE_TYPE, "label": patch.PN_NOTICE_LABEL}
        ]
        self.next_workflow_id = 500
        self.next_node_id = 1000
        self.workflows: dict[int, dict[str, Any]] = {
            patch.PN_SOURCE_WORKFLOW_ID: {
                "id": patch.PN_SOURCE_WORKFLOW_ID,
                "key": patch.PN_SOURCE_WORKFLOW_KEY,
                "title": "native P Number",
                "enabled": True,
                "nodes": [
                    {
                        "id": 1,
                        "key": "native-update",
                        "type": "update",
                        "title": "更新数据",
                        "config": {"params": {"values": {"f_p_no": "P-1"}}},
                    }
                ],
            }
        }

    def get_workflow(self, workflow_id: int) -> dict[str, Any]:
        return copy.deepcopy(self.workflows[workflow_id])

    def create_node(self, values: dict[str, Any]) -> dict[str, Any]:
        self.calls.append(("POST", "/api/flow_nodes:create", copy.deepcopy(values)))
        self.next_node_id += 1
        node = {
            "id": self.next_node_id,
            "key": f"node-{self.next_node_id}",
            **copy.deepcopy(values),
            "upstreamId": None,
            "downstreamId": None,
            "branchIndex": None,
        }
        self.workflows[int(values["workflowId"])]["nodes"].append(node)
        return copy.deepcopy(node)

    def update_node(self, node_id: int, values: dict[str, Any]) -> dict[str, Any]:
        self.calls.append(
            ("POST", f"/api/flow_nodes:update/{node_id}", copy.deepcopy(values))
        )
        for workflow in self.workflows.values():
            for node in workflow.get("nodes") or []:
                if node.get("id") == node_id:
                    node.update(copy.deepcopy(values))
                    return copy.deepcopy(node)
        raise AssertionError(f"unknown node {node_id}")

    def request(self, method: str, path: str, body: Any = None) -> Any:
        self.calls.append((method, path, copy.deepcopy(body)))
        if path.startswith("/api/executions:list?"):
            return []
        if path.startswith(f"/api/{patch.STATUS_COLLECTION}:list?"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
            wanted = json.loads(query["filter"][0])["f_status"]
            return [{"id": hash(wanted) % 1000 + 1, "f_status": wanted}]
        if path.startswith(f"/api/{patch.NOTICE_COLLECTION}:list?"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
            page = int(query.get("page", ["1"])[0])
            return copy.deepcopy(self.notices if page == 1 else [])
        if path.startswith(f"/api/collections/{patch.NOTICE_COLLECTION}/fields:get?"):
            field = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)[
                "filterByTk"
            ][0]
            if field == patch.DEDUPE_FIELD:
                return {
                    "name": field,
                    "unique": self.unique,
                    "description": self.dedupe_description,
                    "uiSchema": {"description": self.dedupe_ui_description},
                }
            if field == patch.NOTICE_TYPE_FIELD:
                return {
                    "name": field,
                    "unique": False,
                    "uiSchema": {"enum": copy.deepcopy(self.notice_types)},
                }
            raise AssertionError(field)
        if path.startswith(
            f"/api/collections/{patch.NOTICE_COLLECTION}/fields:update?"
        ):
            field = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)[
                "filterByTk"
            ][0]
            if field == patch.DEDUPE_FIELD:
                self.unique = bool(body["unique"])
                self.dedupe_description = body["description"]
                self.dedupe_ui_description = body["uiSchema"]["description"]
            elif field == patch.NOTICE_TYPE_FIELD:
                self.notice_types = copy.deepcopy(body["uiSchema"]["enum"])
            else:
                raise AssertionError(field)
            return {"name": field}
        if path.startswith("/api/workflows:list?"):
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)
            field = "title" if "filter[title]" in query else "key"
            wanted = query[f"filter[{field}]"][0]
            return [
                copy.deepcopy(workflow)
                for workflow in self.workflows.values()
                if workflow.get(field) == wanted
            ]
        if path.startswith("/api/workflows:update?filterByTk="):
            workflow_id = int(
                urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)["filterByTk"][
                    0
                ]
            )
            self.workflows[workflow_id].update(copy.deepcopy(body))
            return copy.deepcopy(self.workflows[workflow_id])
        if path == "/api/workflows:create":
            self.next_workflow_id += 1
            workflow = {
                "id": self.next_workflow_id,
                "key": f"workflow-{self.next_workflow_id}",
                "nodes": [],
                "executed": 0,
                **copy.deepcopy(body),
            }
            self.workflows[workflow["id"]] = workflow
            return copy.deepcopy(workflow)
        raise AssertionError(f"unexpected request: {method} {path} {body}")


def build_p_number_candidate(api: FakeApi) -> dict[str, Any]:
    api.next_workflow_id += 1
    workflow_id = api.next_workflow_id
    api.workflows[workflow_id] = {
        "id": workflow_id,
        "key": f"workflow-{workflow_id}",
        "title": patch.PN_TITLE,
        "type": "collection",
        "sync": False,
        "enabled": False,
        "executed": 0,
        "nodes": [],
        "config": {
            "mode": 2,
            "appends": [],
            "changed": ["f_p_no"],
            "collection": "t_licence_app",
            "condition": {"$and": [{"f_p_no": {"$notEmpty": True}}]},
        },
    }
    return patch.reconcile_p_number(api, workflow_id)


def build_received_p_number_candidate(api: FakeApi) -> dict[str, Any]:
    api.next_workflow_id += 1
    workflow_id = api.next_workflow_id
    api.workflows[workflow_id] = {
        "id": workflow_id,
        "key": f"workflow-{workflow_id}",
        "title": patch.PN_RECEIVED_TITLE,
        "type": "collection",
        "sync": False,
        "enabled": False,
        "executed": 0,
        "nodes": [],
        "config": {
            "mode": 2,
            "appends": [],
            "changed": ["f_application_status"],
            "collection": "t_api_request_staging",
            "condition": {
                "$and": [
                    {"f_application_status": {"$eq": "Received"}},
                    {"f_request_event": {"$eq": "CREATE"}},
                    {"f_application_type": {"$eq": "new_licence"}},
                    {"f_application_id": {"$notEmpty": True}},
                ]
            },
        },
    }
    return patch.reconcile_received_p_number(api, workflow_id)


def test_p_number_requires_received_and_publishes_with_individual_hooks() -> None:
    api = FakeApi()
    workflow = build_p_number_candidate(api)

    staging = patch.node_by_title(workflow, "01 Resolve Received NLA CREATE staging")
    staging_exists = patch.node_by_title(
        workflow, "02 Received NLA CREATE staging exists"
    )
    publish = patch.node_by_title(
        workflow, "11 Publish P_Number_Generated from Received"
    )
    staging_filter = staging["config"]["params"]["filter"]["$and"]
    publish_params = publish["config"]["params"]

    assert {"f_application_status": {"$eq": "Received"}} in staging_filter
    assert {"f_application_status": {"$eq": "Received"}} in publish_params["filter"][
        "$and"
    ]
    assert publish_params["individualHooks"] is True
    assert staging_exists["config"]["rejectOnFalse"] is False
    assert {"f_application_status": {"$ne": patch.PN_STATUS_NAME}} not in (
        publish_params["filter"]["$and"]
    )


def test_p_number_notice_has_home_identity_and_unique_dedupe_key() -> None:
    api = FakeApi()
    workflow = build_p_number_candidate(api)
    plan = patch.node_by_title(workflow, "05 Build P Number Notice")
    normalize = patch.node_by_title(workflow, "00 Normalize P Number trigger")
    home = patch.node_by_title(workflow, "04A Resolve Home Record by final P Number")
    notice = patch.node_by_title(
        workflow, "10 Create P Number Notice without attachments"
    )
    values = notice["config"]["params"]["values"]

    assert values["f_rch_no"] == patch.ref(plan, "rchNo")
    assert values["f_rch_name"] == patch.ref(plan, "rchName")
    assert values[patch.DEDUPE_FIELD] == patch.ref(plan, "dedupeKey")
    assert home["config"]["params"]["filter"] == {
        "$and": [{"f_final_o_no": {"$eq": patch.ref(normalize, "pNumber")}}]
    }
    assert "const rchNo = home" in plan["config"]["content"]
    assert "home && home.f_rch_no != null" in plan["config"]["content"]
    assert "rchNo: pNumber" not in plan["config"]["content"]
    assert "attachmentIds: []" in plan["config"]["content"]


def test_p_number_validation_rejects_status_regression_filter() -> None:
    api = FakeApi()
    workflow = build_p_number_candidate(api)
    staging = patch.node_by_title(workflow, "01 Resolve Received NLA CREATE staging")
    filters = staging["config"]["params"]["filter"]["$and"]
    filters[-1] = {"f_application_status": {"$ne": patch.PN_STATUS_NAME}}

    with pytest.raises(patch.ApiError, match="safety validation failed"):
        patch.validate_p_number(api, workflow)


def test_validate_p_number_is_strictly_read_only() -> None:
    api = FakeApi()
    workflow = build_p_number_candidate(api)
    api.calls.clear()

    patch.validate_p_number(api, workflow)

    assert api.calls
    assert {method for method, _path, _body in api.calls} == {"GET"}


def test_unique_constraint_scans_before_update_and_reads_back() -> None:
    api = FakeApi(unique=False, notices=[{"id": 1, patch.DEDUPE_FIELD: "one"}])

    changed = patch.ensure_dedupe_constraint(api)

    assert changed is True
    update_index = next(
        index
        for index, (method, path, _body) in enumerate(api.calls)
        if method == "POST" and "fields:update" in path
    )
    first_scan_index = next(
        index
        for index, (method, path, _body) in enumerate(api.calls)
        if method == "GET" and f"/{patch.NOTICE_COLLECTION}:list" in path
    )
    assert first_scan_index < update_index
    assert api.unique is True
    assert api.dedupe_description == patch.DEDUPE_DESCRIPTION
    assert api.dedupe_ui_description == patch.DEDUPE_DESCRIPTION
    assert sum("fields:get" in path for _method, path, _body in api.calls) >= 2


def test_duplicate_dedupe_keys_fail_before_any_write() -> None:
    api = FakeApi(
        unique=False,
        notices=[
            {"id": 1, patch.DEDUPE_FIELD: "duplicate"},
            {"id": 2, patch.DEDUPE_FIELD: "duplicate"},
        ],
    )

    with pytest.raises(patch.ApiError, match="Duplicate Notice dedupe keys"):
        patch.ensure_dedupe_constraint(api)

    assert {method for method, _path, _body in api.calls} == {"GET"}


def test_unique_field_description_is_reconciled_and_read_back() -> None:
    api = FakeApi(unique=True)
    api.dedupe_description = "legacy"
    api.dedupe_ui_description = "legacy"

    changed = patch.ensure_dedupe_constraint(api)

    assert changed is True
    assert api.unique is True
    assert api.dedupe_description == patch.DEDUPE_DESCRIPTION
    assert api.dedupe_ui_description == patch.DEDUPE_DESCRIPTION


def test_prepare_p_number_is_idempotent_and_never_enables_candidate() -> None:
    api = FakeApi()

    first = patch.prepare_p_number(api)
    second = patch.prepare_p_number(api)

    assert first["id"] == second["id"]
    assert second["enabled"] is False
    creates = [
        call
        for call in api.calls
        if call[0] == "POST" and call[1] == "/api/workflows:create"
    ]
    assert len(creates) == 1
    assert not any(
        call[0] == "POST"
        and call[1].startswith("/api/workflows:update")
        and call[2] == {"enabled": True}
        for call in api.calls
    )


def test_received_reconciler_catches_p_number_created_before_received() -> None:
    api = FakeApi()
    workflow = build_received_p_number_candidate(api)
    application = patch.node_by_title(
        workflow, "01 Resolve NLA with an existing P Number"
    )
    home = patch.node_by_title(workflow, "04A Resolve Home Record by final P Number")
    publish = patch.node_by_title(
        workflow, "11 Publish P_Number_Generated from Received"
    )

    assert workflow["config"]["changed"] == ["f_application_status"]
    assert {"f_application_status": {"$eq": "Received"}} in workflow["config"][
        "condition"
    ]["$and"]
    assert {"f_p_no": {"$notEmpty": True}} in application["config"]["params"]["filter"][
        "$and"
    ]
    assert home["config"]["params"]["filter"] == {
        "$and": [{"f_final_o_no": {"$eq": patch.ref(application, "f_p_no")}}]
    }
    plan = patch.node_by_title(workflow, "05 Build Received P Number Notice")
    assert "home && home.f_rch_no != null" in plan["config"]["content"]
    assert publish["config"]["params"]["individualHooks"] is True
    assert {"f_application_status": {"$eq": "Received"}} in publish["config"]["params"][
        "filter"
    ]["$and"]


def test_both_p_number_workflows_share_the_same_dedupe_identity() -> None:
    api = FakeApi()
    app_workflow = build_p_number_candidate(api)
    received_workflow = build_received_p_number_candidate(api)
    app_plan = patch.node_by_title(app_workflow, "05 Build P Number Notice")
    received_plan = patch.node_by_title(
        received_workflow, "05 Build Received P Number Notice"
    )
    expression = "['nla','p-number',stagingId,statusId].join(':')"

    assert expression in app_plan["config"]["content"]
    assert expression in received_plan["config"]["content"]


def test_received_reconciler_validation_is_read_only() -> None:
    api = FakeApi()
    workflow = build_received_p_number_candidate(api)
    api.calls.clear()

    patch.validate_received_p_number(api, workflow)

    assert api.calls
    assert {method for method, _path, _body in api.calls} == {"GET"}


def test_received_reconciler_rejects_non_received_update_filter() -> None:
    api = FakeApi()
    workflow = build_received_p_number_candidate(api)
    publish = patch.node_by_title(
        workflow, "11 Publish P_Number_Generated from Received"
    )
    filters = publish["config"]["params"]["filter"]["$and"]
    filters[-1] = {"f_application_status": {"$ne": patch.PN_STATUS_NAME}}

    with pytest.raises(patch.ApiError, match="safety validation failed"):
        patch.validate_received_p_number(api, workflow)


def test_prepare_received_reconciler_is_idempotent_and_disabled() -> None:
    api = FakeApi()

    first = patch.prepare_received_p_number(api)
    second = patch.prepare_received_p_number(api)

    assert first["id"] == second["id"]
    assert second["enabled"] is False
    creates = [
        call
        for call in api.calls
        if call[0] == "POST" and call[1] == "/api/workflows:create"
    ]
    assert len(creates) == 1
    assert not any(
        call[0] == "POST"
        and call[1].startswith("/api/workflows:update")
        and call[2] == {"enabled": True}
        for call in api.calls
    )


def test_received_reconciler_activation_requires_guarded_primary() -> None:
    api = FakeApi()
    workflow = build_received_p_number_candidate(api)

    with pytest.raises(patch.ApiError, match="guarded P Number v2"):
        patch.activate(api, workflow["id"], kind="p-number-on-received")

    assert api.workflows[workflow["id"]]["enabled"] is False


def sent_candidate() -> dict[str, Any]:
    plan = {
        "id": 10,
        "key": "plan",
        "type": "script",
        "title": patch.SENT_PLAN_TITLE,
        "config": {
            "content": (
                "const noticeStatusName = type === 'a' ? 'Acknowledged' "
                ": type === 'b' ? 'Confirmed' "
                ": ['c','e','f'].includes(type) ? 'Approved' : 'Received';"
            )
        },
    }
    status = {
        "id": 11,
        "key": "status",
        "type": "query",
        "title": patch.SENT_STATUS_QUERY_TITLE,
        "upstreamId": 10,
        "config": patch.query_config(
            patch.STATUS_COLLECTION,
            [{"f_status": {"$eq": patch.ref(plan, "noticeStatusName")}}],
        ),
    }
    guard = {
        "id": 12,
        "key": "guard",
        "type": "condition",
        "title": patch.SENT_STATUS_GUARD_TITLE,
        "upstreamId": 11,
        "config": patch.exists_config(status, reject_on_false=True),
    }
    create = {
        "id": 13,
        "key": "create",
        "type": "create",
        "title": patch.SENT_CREATE_TITLE,
        "upstreamId": 12,
        "branchIndex": 1,
        "config": {"params": {"values": {"fk_status": patch.ref(status, "id")}}},
    }
    filler = [
        {"id": number, "key": f"filler-{number}", "title": f"filler {number}"}
        for number in range(20, 25)
    ]
    return {
        "id": 99,
        "key": patch.SENT_KEY,
        "title": patch.SENT_DRAFT_TITLE,
        "type": "collection",
        "sync": False,
        "config": patch.sent_trigger_config(),
        "enabled": True,
        "nodes": [*filler, plan, status, guard, create],
    }


def seed_interrupted_sent_revision(api: FakeApi) -> int:
    old_line = (
        "const noticeStatusId = type === 'a' ? 4 : type === 'b' ? 5 : "
        "['c','e','f'].includes(type) ? 7 : 2;"
    )
    plan = {
        "id": 210,
        "key": "old-plan",
        "type": "script",
        "title": patch.SENT_PLAN_TITLE,
        "config": {"content": old_line + "\nreturn {\n  noticeStatusId,\n};"},
    }
    create = {
        "id": 211,
        "key": "old-create",
        "type": "create",
        "title": patch.SENT_CREATE_TITLE,
        "config": {
            "params": {"values": {"fk_status": patch.ref(plan, "noticeStatusId")}}
        },
    }
    filler = [
        {
            "id": number,
            "key": f"source-{number}",
            "type": "query",
            "title": f"source {number}",
            "config": {},
        }
        for number in range(212, 217)
    ]
    source = {
        "id": patch.SENT_SOURCE_ID,
        "key": patch.SENT_KEY,
        "title": patch.SENT_SOURCE_TITLE,
        "type": "collection",
        "sync": False,
        "config": patch.sent_trigger_config(),
        "enabled": True,
        "nodes": [*filler, plan, create],
    }
    api.workflows[patch.SENT_SOURCE_ID] = source
    candidate_id = patch.SENT_SOURCE_ID + 1
    candidate = copy.deepcopy(source)
    candidate.update({"id": candidate_id, "enabled": False, "executed": 0})
    for node in candidate["nodes"]:
        node["id"] += 1000
        node["key"] += "-draft"
    candidate_plan = next(
        node for node in candidate["nodes"] if node["title"] == patch.SENT_PLAN_TITLE
    )
    candidate_create = next(
        node for node in candidate["nodes"] if node["title"] == patch.SENT_CREATE_TITLE
    )
    candidate_create["config"]["params"]["values"]["fk_status"] = patch.ref(
        candidate_plan, "noticeStatusId"
    )
    api.workflows[candidate_id] = candidate
    return candidate_id


def test_sent_v3_dynamic_mapping_validation_is_read_only() -> None:
    api = FakeApi()

    patch.validate_sent(api, sent_candidate())

    assert api.calls
    assert {method for method, _path, _body in api.calls} == {"GET"}


def test_sent_trigger_uses_exact_reviewed_relation_appends() -> None:
    assert patch.sent_trigger_config()["appends"] == [
        "f_attachment",
        "f_home_record",
        "f_senduser",
    ]


def test_interrupted_sent_revision_is_reconciled_without_duplicate_candidate() -> None:
    api = FakeApi()
    interrupted_id = seed_interrupted_sent_revision(api)

    first = patch.prepare_sent(api)
    second = patch.prepare_sent(api)

    assert first["id"] == interrupted_id == second["id"]
    assert second["enabled"] is False
    assert len(second["nodes"]) == 9
    plan = patch.node_by_title(second, patch.SENT_PLAN_TITLE)
    assert "noticeStatusName" in plan["config"]["content"]
    assert "noticeStatusId" not in plan["config"]["content"]
    created_nodes = [
        call
        for call in api.calls
        if call[0] == "POST" and call[1] == "/api/flow_nodes:create"
    ]
    assert len(created_nodes) == 2
    assert not any(
        call[0] == "POST"
        and call[1].startswith("/api/workflows:update")
        and call[2] == {"enabled": True}
        for call in api.calls
    )


def test_interrupted_sent_prepare_restores_disabled_reviewed_source() -> None:
    api = FakeApi()
    candidate_id = seed_interrupted_sent_revision(api)
    api.workflows[patch.SENT_SOURCE_ID]["enabled"] = False

    result = patch.prepare_sent(api)

    assert result["id"] == candidate_id
    assert result["enabled"] is False
    assert api.workflows[patch.SENT_SOURCE_ID]["enabled"] is True
    assert any(
        call[0] == "POST"
        and call[1].endswith(f"filterByTk={patch.SENT_SOURCE_ID}")
        and call[2] == {"enabled": True}
        for call in api.calls
    )


def workflow_for_trigger_test(
    api: FakeApi, kind: str
) -> tuple[dict[str, Any], Any]:
    if kind == "sent":
        return sent_candidate(), patch.validate_sent
    if kind == "p-number":
        return build_p_number_candidate(api), patch.validate_p_number
    if kind == "p-number-on-received":
        return build_received_p_number_candidate(api), patch.validate_received_p_number
    raise AssertionError(kind)


@pytest.mark.parametrize("kind", ["sent", "p-number", "p-number-on-received"])
@pytest.mark.parametrize(
    ("target", "tampered"),
    [
        ("collection", "widened_collection"),
        ("mode", 1),
        ("changed", []),
        ("condition", {}),
        ("appends", ["unexpected_relation"]),
        ("extra", True),
        ("type", "schedule"),
        ("sync", True),
    ],
)
def test_validation_rejects_any_top_level_trigger_tampering(
    kind: str, target: str, tampered: Any
) -> None:
    api = FakeApi()
    workflow, validator = workflow_for_trigger_test(api, kind)
    api.calls.clear()

    if target in {"type", "sync"}:
        workflow[target] = copy.deepcopy(tampered)
    else:
        workflow["config"][target] = copy.deepcopy(tampered)

    with pytest.raises(patch.ApiError, match="trigger"):
        validator(api, workflow)

    assert not any(method != "GET" for method, _path, _body in api.calls)


def test_prepare_rejects_tampered_existing_trigger_without_workflow_writes() -> None:
    api = FakeApi()
    workflow = build_p_number_candidate(api)
    api.workflows[workflow["id"]]["config"]["unexpected"] = "widened"
    api.calls.clear()

    with pytest.raises(patch.ApiError, match="trigger"):
        patch.prepare_p_number(api)

    assert {method for method, _path, _body in api.calls} == {"GET"}


def test_activation_rejects_tampered_trigger_without_enabling_candidate() -> None:
    api = FakeApi()
    workflow = build_p_number_candidate(api)
    api.workflows[workflow["id"]]["config"]["appends"] = ["unexpected_relation"]
    api.calls.clear()

    with pytest.raises(patch.ApiError, match="trigger"):
        patch.activate(api, workflow["id"], kind="p-number")

    assert api.workflows[workflow["id"]]["enabled"] is False
    assert {method for method, _path, _body in api.calls} == {"GET"}


def test_dual_p_number_entry_race_is_bounded_by_unique_create_before_publish() -> None:
    """A race can fail one create, but cannot duplicate or prematurely publish."""
    api = FakeApi()
    app_workflow = build_p_number_candidate(api)
    received_workflow = build_received_p_number_candidate(api)

    for workflow, plan_title, notice_title in (
        (
            app_workflow,
            "05 Build P Number Notice",
            "10 Create P Number Notice without attachments",
        ),
        (
            received_workflow,
            "05 Build Received P Number Notice",
            "10 Create Received P Number Notice without attachments",
        ),
    ):
        plan = patch.node_by_title(workflow, plan_title)
        notice = patch.node_by_title(workflow, notice_title)
        publish = patch.node_by_title(
            workflow, "11 Publish P_Number_Generated from Received"
        )
        values = notice["config"]["params"]["values"]

        assert values[patch.DEDUPE_FIELD] == patch.ref(plan, "dedupeKey")
        assert publish["upstreamId"] == notice["id"]

    assert api.unique is True
