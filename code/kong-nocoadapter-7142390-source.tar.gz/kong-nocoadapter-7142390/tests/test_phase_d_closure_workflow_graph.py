from __future__ import annotations

import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from create_nocobase_phase_d_closure_workflows import (  # noqa: E402
    ATOMIC_STAGING_CLAIM_SQL,
    ATOMIC_UPDATE_STAGING_CLAIM_SQL,
    BPS,
    build_create_graph,
    build_update_graph,
    closure_parse_config,
)


class FakeApi:
    def __init__(self) -> None:
        self.nodes: list[dict[str, Any]] = []

    def create_node(self, body: dict[str, Any]) -> dict[str, Any]:
        node_id = len(self.nodes) + 1
        node = {**deepcopy(body), "id": node_id, "key": f"node-{node_id}"}
        self.nodes.append(node)
        return deepcopy(node)

    def update_node(self, node_id: int, body: dict[str, Any]) -> dict[str, Any]:
        node = next(row for row in self.nodes if row["id"] == node_id)
        node.update(deepcopy(body))
        return deepcopy(node)


def bp(key: str) -> dict[str, Any]:
    return next(deepcopy(row) for row in BPS if row["key"] == key)


def by_title(api: FakeApi, title: str) -> dict[str, Any]:
    return next(row for row in api.nodes if row["title"] == title)


def values(node: dict[str, Any]) -> dict[str, Any]:
    return node["config"]["params"]["values"]


def test_self_withdraw_example_matches_checklist_only_public_contract() -> None:
    config = closure_parse_config(bp("self"))
    form = config["example"]["form_data"]

    assert set(form) >= {
        "case_summary",
        "applicant_title",
        "applicant_name_en",
        "means_of_authorisation",
        "tentative_date_of_closure",
        "reason_for_closure",
        "reason_for_closure_others",
        "checklist",
    }
    assert "written_authorisation_attachment_ids" not in form
    assert "resident_list_attachment_ids" not in form
    assert "relocation_plan_attachment_ids" not in form
    assert len(form["checklist"]) == 4
    assert all(
        set(row) == {"position_code", "attachment_id"} for row in form["checklist"]
    )
    variable_paths = {row["path"] for row in config["variables"]}
    assert "form_data" in variable_paths
    assert not any(path.endswith("_attachment_ids") for path in variable_paths)


@pytest.mark.parametrize("key", ["self", "revoke"])
@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_phase_d_graph_uses_atomic_sql_claim_and_writes_failed_reasons(
    key: str, builder: Any
) -> None:
    api = FakeApi()
    builder(api, 100, bp(key))

    claim_kind = "CREATE" if builder is build_create_graph else "UPDATE"
    claim = by_title(api, f"Atomically claim submitted Closure {claim_kind} row")
    expected_claim_sql = (
        ATOMIC_STAGING_CLAIM_SQL
        if builder is build_create_graph
        else ATOMIC_UPDATE_STAGING_CLAIM_SQL
    )
    assert claim["type"] == "sql"
    assert claim["config"] == {
        "dataSource": "main",
        "sql": expected_claim_sql,
        "withMeta": False,
        "unsafeInjection": False,
        "variables": [
            {"name": "stagingId", "value": "{{$context.data.id}}"},
        ],
    }
    if builder is build_create_graph:
        assert claim["config"]["sql"] == (
            'UPDATE "t_api_request_staging" SET "f_status"=\'processing\' '
            'WHERE "id"=:stagingId AND "f_status"=\'submitted\' RETURNING "id";'
        )
    else:
        sql = claim["config"]["sql"]
        assert 'parent."f_request_event"=\'CREATE\'' in sql
        assert 'parent."f_status"=\'succeeded\'' in sql
        assert 'parent."f_application_status"=\'Accepted\'' in sql
        assert 'parent."f_intake_id" IS NOT NULL' in sql
        assert 'parent."f_application_id" IS NOT NULL' in sql
        assert 'staged."f_active_update_id" IS NOT NULL' in sql
        assert 'parent."f_active_update_id"=staged."f_active_update_id"' in sql
        assert 'active."f_request_event"=\'UPDATE\'' in sql
        assert 'active."f_status"=\'processing\'' in sql
        assert (
            'active."id"<staged."id" AND active."f_status"=\'submitted\'' in sql
        )
        assert 'RETURNING staged."id"' in sql
    count = by_title(api, f"Validate Closure {claim_kind} claim row count")
    assert count["type"] == "script"
    assert "rows.length === 1" in count["config"]["content"]
    assert count["upstreamId"] == claim["id"]
    guard = by_title(api, f"Closure {claim_kind} claim succeeded")
    assert guard["upstreamId"] == count["id"]
    rejected = by_title(api, f"Finalize rejected Closure {claim_kind} claim")
    assert rejected["type"] == "sql"
    assert rejected["upstreamId"] == guard["id"]
    assert rejected["branchIndex"] == 0
    assert '"f_status"=\'failed\'' in rejected["config"]["sql"]
    assert '"f_status"=\'submitted\'' in rejected["config"]["sql"]
    assert rejected["config"]["unsafeInjection"] is False
    rejected_vars = {
        row["name"]: row["value"] for row in rejected["config"]["variables"]
    }
    assert rejected_vars["reason"] == (
        "create_claim_rejected"
        if builder is build_create_graph
        else "update_claim_rejected"
    )
    rejected_count = by_title(
        api, f"Validate rejected Closure {claim_kind} claim row count"
    )
    rejected_guard = by_title(
        api, f"Rejected Closure {claim_kind} claim finalized"
    )
    assert rejected_count["upstreamId"] == rejected["id"]
    assert rejected_guard["upstreamId"] == rejected_count["id"]
    if builder is build_update_graph:
        finalizer = by_title(
            api,
            "Finalize deferred Received after rejected Closure Update claim",
        )
        assert finalizer["upstreamId"] == rejected_guard["id"]
        assert finalizer["branchIndex"] == 1
    parse_title = (
        f"Parse staged {key} request body"
        if builder is build_create_graph
        else f"Parse staged {key} update body"
    )
    parse = by_title(api, parse_title)
    assert parse["upstreamId"] == guard["id"]
    assert parse["branchIndex"] == 1
    assert not any(
        row["title"] in {"Mark processing", "Mark update processing"}
        for row in api.nodes
    )
    assert not any("Confirm " in row["title"] for row in api.nodes)
    failed = [
        row
        for row in api.nodes
        if row["type"] == "update" and values(row).get("f_status") == "failed"
    ]
    assert failed
    assert all(values(row).get("f_error_message") for row in failed)
    assert all(row["type"] != "transaction" for row in api.nodes)


def test_create_marks_intake_provenance_and_backfills_before_lookup() -> None:
    api = FakeApi()
    build_create_graph(api, 100, bp("self"))

    intake = by_title(api, "Create Intake (fixed Closure type + Home Record)")
    assert values(intake)["f_api_create_staging_id"] == "{{$context.data.id}}"
    home = by_title(api, "Resolve Closure Home Record before Intake")
    home_guard = by_title(api, "Closure Home Record exists")
    parse = by_title(api, "Parse staged self request body")
    assert home["upstreamId"] == parse["id"]
    assert home["config"]["collection"] == "t_home_record"
    assert home["config"]["params"]["filter"] == {
        "$and": [{"id": {"$eq": "{{$context.data.f_rch_id}}"}}]
    }
    assert home_guard["upstreamId"] == home["id"]
    assert intake["upstreamId"] == home_guard["id"]
    assert intake["branchIndex"] == 1
    assert values(intake)["f_subject"] == (
        "{{$jobsMapByNodeKey." + home["key"] + ".f_rch_no}}"
    )
    home_failed = by_title(api, "Mark Closure Home Record failure")
    assert values(home_failed)["f_status"] == "failed"
    assert values(home_failed)["f_error_message"] == "home_record_not_resolved"
    assert home_failed["upstreamId"] == home_guard["id"]
    assert home_failed["branchIndex"] == 0
    early = by_title(api, "Backfill Closure Intake ID before native application lookup")
    application = by_title(api, "Find native-created Closure application")
    assert early["upstreamId"] == intake["id"]
    assert application["upstreamId"] == early["id"]
    assert set(values(early)) == {"f_intake_id"}


@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_self_withdraw_checklist_creates_details_before_latest(
    builder: Any,
) -> None:
    api = FakeApi()
    builder(api, 100, bp("self"))

    existing_detail = by_title(api, "Create existing Closure Checklist upload Details")
    existing_latest = by_title(api, "Refresh existing Closure Checklist Latest")
    new_detail = by_title(api, "Create new Closure Checklist upload Details")
    new_latest = by_title(api, "Refresh new Closure Checklist Latest")
    assert existing_latest["upstreamId"] == existing_detail["id"]
    assert new_latest["upstreamId"] == new_detail["id"]
    assert existing_detail["config"]["collection"] == (
        "t_document_submitted_for_application_details"
    )
    assert new_detail["config"]["collection"] == (
        "t_document_submitted_for_application_details"
    )
    assert "f_lastest_files" not in values(
        by_title(api, "Create Closure checklist item without Latest")
    )
    for title in (
        "Refresh existing Closure Checklist Latest",
        "Refresh new Closure Checklist Latest",
    ):
        assert by_title(api, title)["config"]["params"]["individualHooks"] is True

    for title, reason in (
        (
            "Mark Closure checklist template failure",
            "checklist_template_not_resolved",
        ),
        (
            "Mark Closure Checklist attachment failure",
            "checklist_attachment_not_resolved",
        ),
    ):
        assert values(by_title(api, title))["f_error_message"] == reason

    succeeded = by_title(
        api,
        "Mark succeeded + backfill IDs"
        if builder is build_create_graph
        else "Mark update succeeded + backfill IDs",
    )
    guard = by_title(api, "Closure Checklist completed without failure")
    assert succeeded["upstreamId"] == guard["id"]
    assert succeeded["branchIndex"] == 1
    assert {"f_status": {"$eq": "processing"}} in succeeded["config"]["params"][
        "filter"
    ]["$and"]


def test_update_is_preserve_on_absent_and_requires_accepted_parent() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("self"))

    original = by_title(api, "Resolve original CREATE staging record")
    parent_filters = original["config"]["params"]["filter"]["$and"]
    assert {"f_request_event": {"$eq": "CREATE"}} in parent_filters
    assert {"f_status": {"$eq": "succeeded"}} in parent_filters
    assert {"f_application_status": {"$eq": "Accepted"}} in parent_filters
    assert {"f_intake_id": {"$notEmpty": True}} in parent_filters
    assert {"f_application_id": {"$notEmpty": True}} in parent_filters
    script = by_title(api, "Project guarded self Closure update patch")["config"][
        "content"
    ]
    assert "hasOwnProperty.call" in script
    assert "current[internal]" in script
    assert "currentIntake[internal]" in script
    patch = values(by_title(api, "Apply staged Closure update overlay"))
    assert patch
    assert all(".patch." in reference for reference in patch.values())
    assert not any(
        field in patch
        for field in (
            "f_written_authorisation_for_representative_of_applicant",
            "f_resident_list",
            "f_relocation_plan_for_residents",
        )
    )
    succeeded = values(by_title(api, "Mark update succeeded + backfill IDs"))
    assert succeeded["f_parent_create_id"].endswith(".id}}")
    assert (
        values(by_title(api, "Mark Closure update parent/lock failure"))[
            "f_error_message"
        ]
        == "update_parent_not_accepted_or_not_found"
    )
    assert (
        values(by_title(api, "Mark linked Closure application failure"))[
            "f_error_message"
        ]
        == "linked_closure_application_not_resolved"
    )


def test_self_update_preflights_the_full_checklist_before_business_writes() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("self"))

    normalize = by_title(api, "Project guarded self Closure update patch")
    preflight_loop = by_title(api, "Preflight Closure Checklist files")
    preflight_valid = by_title(
        api, "Closure checklist preflight completed without failure"
    )
    apply_intake = by_title(api, "Apply guarded Closure Intake update")
    apply_application = by_title(api, "Apply staged Closure update overlay")

    assert preflight_loop["upstreamId"] == normalize["id"]
    assert apply_intake["upstreamId"] == preflight_valid["id"]
    assert apply_intake["branchIndex"] == 1
    assert apply_application["upstreamId"] == apply_intake["id"]

    template_failure = by_title(
        api, "Mark Closure checklist preflight template failure"
    )
    attachment_failure = by_title(
        api, "Mark Closure checklist preflight attachment failure"
    )
    assert values(template_failure)["f_error_message"] == (
        "checklist_template_not_resolved"
    )
    assert values(attachment_failure)["f_error_message"] == (
        "checklist_attachment_not_resolved"
    )


@pytest.mark.parametrize("key", ["self", "revoke"])
def test_update_finalizes_deferred_received_only_when_intake_is_complete_and_idle(
    key: str,
) -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp(key))

    succeeded = by_title(api, "Mark update succeeded + backfill IDs")
    success_finalizer = by_title(
        api, "Finalize deferred Received after successful Closure Update"
    )
    assert success_finalizer["upstreamId"] == succeeded["id"]
    assert success_finalizer["type"] == "sql"

    config = success_finalizer["config"]
    sql = config["sql"]
    assert config["dataSource"] == "main"
    assert config["unsafeInjection"] is False
    assert not sql.startswith("WITH ")
    assert '"f_active_update_id"=NULL' in sql
    assert 'create_row."f_active_update_id"=:activeUpdateId' in sql
    assert '"f_application_status"=CASE WHEN' in sql
    assert 'create_row."f_status"=\'succeeded\'' in sql
    assert 'create_row."f_request_event"=\'CREATE\'' in sql
    assert 'create_row."f_application_status"=\'Accepted\'' in sql
    assert 'intake."f_approval_status" AS text)=\'4\'' in sql
    assert 'active."f_request_event"=\'UPDATE\'' in sql
    assert 'active."f_status" IN (\'submitted\',\'processing\')' in sql
    assert "NOT EXISTS" in sql
    assert {row["name"] for row in config["variables"]} == {
        "parentCreateId",
        "activeUpdateId",
        "createApiType",
        "applicationType",
    }

    parent_failure = by_title(api, "Mark Closure update parent/lock failure")
    failure_finalizer = by_title(
        api, "Finalize deferred Received after Closure terminal failure 1"
    )
    assert failure_finalizer["upstreamId"] == parent_failure["id"]

    if key == "self":
        preflight = by_title(
            api, "Closure checklist preflight completed without failure"
        )
        preflight_finalizer = by_title(
            api,
            "Finalize deferred Received after Closure checklist preflight failure",
        )
        assert preflight_finalizer["upstreamId"] == preflight["id"]
        assert preflight_finalizer["branchIndex"] == 0

        checklist_guard = by_title(
            api, "Closure Checklist completed without failure"
        )
        checklist_finalizer = by_title(
            api,
            "Finalize deferred Received after Closure checklist commit failure",
        )
        assert checklist_finalizer["upstreamId"] == checklist_guard["id"]
        assert checklist_finalizer["branchIndex"] == 0


def test_update_preserves_absent_intake_fields_and_never_changes_identity() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("self"))

    original = by_title(api, "Resolve original CREATE staging record")
    original_guard = by_title(api, "Accepted Closure parent CREATE exists")
    intake = by_title(api, "Resolve linked Closure Intake")
    intake_guard = by_title(api, "Linked Closure Intake exists")
    application = by_title(api, "Resolve linked Closure application")
    assert intake["upstreamId"] == original_guard["id"]
    assert intake["branchIndex"] == 1
    assert intake["config"]["params"]["filter"] == {
        "$and": [
            {
                "id": {
                    "$eq": ("{{$jobsMapByNodeKey." + original["key"] + ".f_intake_id}}")
                }
            }
        ]
    }
    assert application["upstreamId"] == intake_guard["id"]
    assert application["branchIndex"] == 1
    intake_failed = by_title(api, "Mark linked Closure Intake failure")
    assert values(intake_failed)["f_error_message"] == (
        "linked_closure_intake_not_resolved"
    )
    assert intake_failed["branchIndex"] == 0

    normalize = by_title(api, "Project guarded self Closure update patch")
    arguments = {row["name"]: row["value"] for row in normalize["config"]["arguments"]}
    assert arguments["intake"] == ("{{$jobsMapByNodeKey." + intake["key"] + "}}")
    apply_intake = by_title(api, "Apply guarded Closure Intake update")
    assert apply_intake["config"]["collection"] == "t_intake_form"
    intake_patch = values(apply_intake)
    assert set(intake_patch) == {
        "f_received_date",
        "f_severity",
        "fk_intake_source",
        "f_source_other",
        "fk_task_owner",
        "fk_task_owner_post",
    }
    assert all(".intake_patch." in reference for reference in intake_patch.values())
    assert not (
        {
            "f_office_cd",
            "fk_intake_source_rch",
            "createdBy",
        }
        & set(intake_patch)
    )
    apply_application = by_title(api, "Apply staged Closure update overlay")
    assert apply_application["upstreamId"] == apply_intake["id"]
    assert "f_office_cd" not in values(apply_application)


def test_revoke_uses_shared_closure_fields_and_checklist_nodes() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("revoke"))

    assert any("Checklist" in row["title"] for row in api.nodes)
    succeeded = by_title(api, "Mark update succeeded + backfill IDs")
    checklist_completion = by_title(api, "Closure Checklist completed without failure")
    assert succeeded["upstreamId"] == checklist_completion["id"]
    assert succeeded["branchIndex"] == 1
    patch = values(by_title(api, "Apply staged Closure update overlay"))
    assert set(patch) >= {
        "f_applicant_title",
        "f_applicant_name_eng",
        "f_means_of_authorisation",
        "f_tentative_date_of_closure",
        "f_reason_for_closure",
        "f_comments",
    }
