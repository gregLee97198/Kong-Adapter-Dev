from __future__ import annotations

import json
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from scripts.create_nocobase_phase_e_sh_rp_workflows import (
    BPS,
    RP_CASE_STATUS_NATIVE_VALUES,
    build_create_graph,
    build_update_graph,
    claim_result_script,
    guarded_patch_script,
    parse_config,
    ref,
    rp_case_status_script,
    rp_validation_script,
    specific_hour_validation_script,
)


class FakeApi:
    def __init__(self) -> None:
        self.nodes: list[dict[str, Any]] = []

    def create_node(self, body: dict[str, Any]) -> dict[str, Any]:
        node_id = len(self.nodes) + 1
        node = {**deepcopy(body), "id": node_id, "key": f"node-{node_id}"}
        self.nodes.append(node)
        return deepcopy(node)

    def update_node(self, node_id: int, body: dict[str, Any]) -> dict[str, Any]:
        node = next(row for row in self.nodes if row["id"] == node_id)
        node.update(deepcopy(body))
        return deepcopy(node)


def bp(key: str) -> dict[str, Any]:
    return next(deepcopy(row) for row in BPS if row["key"] == key)


def by_title(api: FakeApi, title: str) -> dict[str, Any]:
    return next(row for row in api.nodes if row["title"] == title)


def values(node: dict[str, Any]) -> dict[str, Any]:
    return node["config"]["params"]["values"]


def is_descendant_of(
    api: FakeApi, node: dict[str, Any], ancestor: dict[str, Any]
) -> bool:
    by_id = {row["id"]: row for row in api.nodes}
    current = node
    visited: set[int] = set()
    while current.get("upstreamId") is not None:
        upstream_id = current["upstreamId"]
        if upstream_id == ancestor["id"]:
            return True
        if upstream_id in visited:
            return False
        visited.add(upstream_id)
        current = by_id[upstream_id]
    return False


def run_js(script: str, **arguments: Any) -> dict[str, Any]:
    names = list(arguments)
    source = (
        f"const fn = new Function(...{json.dumps(names)}, {json.dumps(script)});"
        f"const values = {json.dumps([arguments[name] for name in names])};"
        "process.stdout.write(JSON.stringify(fn(...values)));"
    )
    result = subprocess.run(
        ["node", "-e", source],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


@pytest.mark.parametrize("key", ["sh", "rp"])
@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_phase_e_graph_claims_only_submitted_and_has_failed_terminal_branches(
    key: str, builder: Any
) -> None:
    api = FakeApi()
    builder(api, 100, bp(key))

    claim_title = (
        "Atomically claim submitted Create row"
        if builder is build_create_graph
        else "Atomically claim submitted Update row"
    )
    claim_kind = "Create" if builder is build_create_graph else "Update"
    claim = by_title(api, claim_title)
    assert claim["type"] == "sql"
    assert claim["config"]["dataSource"] == "main"
    assert claim["config"]["unsafeInjection"] is False
    assert claim["config"]["variables"] == [
        {"name": "stagingId", "value": "{{$context.data.id}}"}
    ]
    assert "SET \"f_status\" = 'processing'" in claim["config"]["sql"]
    assert "\"f_status\" = 'submitted'" in claim["config"]["sql"]
    assert 'RETURNING staged."id"' in claim["config"]["sql"]
    if builder is build_update_graph:
        sql = claim["config"]["sql"]
        assert 'parent."f_request_event" = \'CREATE\'' in sql
        assert 'parent."f_status" = \'succeeded\'' in sql
        assert 'parent."f_application_status" = \'Accepted\'' in sql
        assert 'parent."f_intake_id" IS NOT NULL' in sql
        assert 'parent."f_application_id" IS NOT NULL' in sql
        assert 'staged."f_active_update_id" IS NOT NULL' in sql
        assert (
            'parent."f_active_update_id" = staged."f_active_update_id"' in sql
        )
        assert 'NOT EXISTS (SELECT 1 FROM "t_api_request_staging" AS active' in sql
        assert 'active."f_status" = \'processing\'' in sql
        assert 'active."id" < staged."id"' in sql
        assert 'active."f_status" = \'submitted\'' in sql
    claim_guard_title = (
        "Atomic Create claim returned one row"
        if builder is build_create_graph
        else "Atomic Update claim returned one row"
    )
    claim_guard = by_title(api, claim_guard_title)
    rejected_title = (
        "Finalize rejected Create claim"
        if builder is build_create_graph
        else "Finalize rejected Update claim"
    )
    rejected = by_title(api, rejected_title)
    assert rejected["type"] == "sql"
    assert rejected["upstreamId"] == claim_guard["id"]
    assert rejected["branchIndex"] == 0
    assert '"f_status"=\'failed\'' in rejected["config"]["sql"]
    assert '"f_status"=\'submitted\'' in rejected["config"]["sql"]
    rejected_vars = {
        row["name"]: row["value"] for row in rejected["config"]["variables"]
    }
    assert rejected_vars["reason"] == (
        "create_claim_rejected"
        if builder is build_create_graph
        else "update_claim_rejected"
    )
    rejected_count = by_title(api, f"Validate rejected {claim_kind} claim row count")
    rejected_guard = by_title(api, f"Rejected {claim_kind} claim finalized")
    assert rejected_count["upstreamId"] == rejected["id"]
    assert rejected_guard["upstreamId"] == rejected_count["id"]
    if builder is build_update_graph:
        finalizer = by_title(
            api,
            "Finalize deferred Received after rejected Update claim",
        )
        assert finalizer["upstreamId"] == rejected_guard["id"]
        assert finalizer["branchIndex"] == 1
    failed = [
        row
        for row in api.nodes
        if row["type"] == "update" and values(row).get("f_status") == "failed"
    ]
    assert failed
    assert all(values(row).get("f_error_message") for row in failed)
    terminal = failed + [
        row
        for row in api.nodes
        if row["type"] == "update" and values(row).get("f_status") == "succeeded"
    ]
    expected_cas = {
        "$and": [
            {"id": {"$eq": "{{$context.data.id}}"}},
            {"f_status": {"$eq": "processing"}},
        ]
    }
    assert terminal
    assert all(row["config"]["params"]["filter"] == expected_cas for row in terminal)

    if builder is build_create_graph:
        guard = by_title(api, "Reject Create row with existing business IDs")
        assert {arg["name"] for arg in guard["config"]["arguments"]} == {
            "intakeId",
            "applicationId",
        }


def test_atomic_claim_continues_only_for_exactly_one_returned_row() -> None:
    script = claim_result_script()
    assert run_js(script, rows=[]) == {"claimed": False}
    assert run_js(script, rows=[{"id": 1}]) == {"claimed": True}
    assert run_js(script, rows=[{"id": 1}, {"id": 2}]) == {"claimed": False}


@pytest.mark.parametrize("key", ["sh", "rp"])
def test_create_resolves_home_before_intake_and_uses_canonical_rch_number(
    key: str,
) -> None:
    api = FakeApi()
    build_create_graph(api, 100, bp(key))

    home = by_title(api, "Resolve Home Record for Intake subject")
    assert home["config"]["collection"] == "t_home_record"
    assert home["config"]["params"]["filter"] == {
        "$and": [{"id": {"$eq": "{{$context.data.f_rch_id}}"}}]
    }
    home_exists = by_title(api, "Resolved Home Record exists")
    intake = by_title(api, "Create Intake (fixed type + Home Record)")
    home_failed = by_title(api, "Mark Home Record resolution failed")
    assert intake["upstreamId"] == home_exists["id"]
    assert intake["branchIndex"] == 1
    assert home_failed["upstreamId"] == home_exists["id"]
    assert home_failed["branchIndex"] == 0
    assert values(intake)["f_subject"] == ref(home, "f_rch_no")
    assert ".lorcheDNo}}" not in values(intake)["f_subject"]


def test_sh_create_uses_only_canonical_plural_three_level_relations() -> None:
    api = FakeApi()
    build_create_graph(api, 100, bp("sh"))

    option = by_title(api, "Create Specific Hour option")
    staffing = by_title(api, "Create Specific Hour staffing")
    time_row = by_title(api, "Create Specific Hour time row")
    assert option["config"]["collection"] == "t_specific_hour_option"
    assert set(values(option)) >= {
        "fk_specific_hour_app",
        "f_specific_hour_set_no",
        "f_section",
    }
    assert "fk_specific_hour_option" not in values(option)
    assert staffing["config"]["collection"] == "t_specific_hour_staffing"
    assert set(values(staffing)) >= {
        "fk_specific_hour_option",
        "fk_staff_type",
        "f_staff_ratio_requirement",
        "f_minimum_required_hours",
        "f_sort_order",
    }
    assert "fk_specific_hour_staffing" not in values(staffing)
    assert values(staffing)["f_staff_ratio_requirement"].endswith(
        ".item._rule_snapshot.staff_ratio_requirement}}"
    )
    assert values(staffing)["f_minimum_required_hours"].endswith(
        ".item._rule_snapshot.minimum_required_hours}}"
    )
    assert values(staffing)["f_sort_order"].endswith(
        ".item._rule_snapshot.sort_order}}"
    )
    assert time_row["config"]["collection"] == "t_specific_hour_data"
    assert set(values(time_row)) >= {
        "fk_specific_hour_staffing",
        "f_work_hour_from",
        "f_work_hour_to",
        "f_duration_hours",
        "f_sort_order",
    }
    assert values(time_row)["f_duration_hours"].endswith(".item._duration_hours}}")
    assert values(time_row)["f_sort_order"].endswith(".item._sort_order}}")
    assert by_title(api, "Create Specific Hour options")["config"]["target"].endswith(
        ".specificHourOptions}}"
    )


def test_rp_create_writes_page_fields_questions_and_currently_appointed_rows() -> None:
    api = FakeApi()
    build_create_graph(api, 100, bp("rp"))

    overlay = values(by_title(api, "Apply staged overlay"))
    assert overlay["p3_Email"].endswith(".rpEmail}}")
    assert overlay["f_rp_email"].endswith(".rpEmail}}")
    assert overlay["p8_checked"].endswith(".declarationAcknowledged}}")
    assert "f_rp_declaration_ack" not in overlay
    assert "f_other_home_name" not in overlay
    assert "f_other_home_lorche_d_no" not in overlay
    assert overlay["f_q1_answer"].endswith(".q1_answer}}")
    assert overlay["f_q1_case_status"].endswith(".q1_case_status}}")
    assert overlay["q2being_and_has"].endswith(".q2_case_status}}")
    assert overlay["f_q3_case_status"].endswith(".q3_case_status}}")
    assert overlay["q4being_has"].endswith(".q4_case_status}}")
    assert overlay["f_q5_rch_name"].endswith(".q5_rch_no_and_name}}")
    assert "f_q5_lorche_d_no" not in overlay
    assert overlay["f_q8_court"].endswith(".q8_court}}")

    child = by_title(api, "Create RP currently appointed home")
    assert child["config"]["collection"] == "t_rp_currently_appointed"
    assert set(values(child)) == {
        "fk_t_rp_application_id",
        "f_rch_no",
        "f_rch_name",
    }


def test_examples_only_expose_the_two_public_checklist_fields() -> None:
    for key in ("sh", "rp"):
        item = parse_config(bp(key))["example"]["form_data"]["checklist"][0]
        assert set(item) == {"position_code", "attachment_id"}

    rp_form = parse_config(bp("rp"))["example"]["form_data"]
    assert "other_home_name" not in rp_form
    assert "other_home_lorche_d_no" not in rp_form


def test_rp_case_status_script_contains_exact_page_enum_translation() -> None:
    assert RP_CASE_STATUS_NATIVE_VALUES == {
        "q1": {
            "being_prosecuted_currently": "being prosecuted currently",
            "has_been_convicted": "has been convicted",
        },
        "q2": {
            "being_prosecuted_currently": "being prosecuted currently",
            "has_been_convicted": "has been convicted",
        },
        "q3": {
            "being_prosecuted_currently": "q3being",
            "has_been_convicted": "q3has",
        },
        "q4": {
            "being_prosecuted_currently": "q4being prosecuted currently",
            "has_been_convicted": "q4has been convicted",
        },
    }
    script = rp_case_status_script()
    for number in range(1, 5):
        assert f"typeof q{number}CaseStatus === 'undefined'" in script
    for mapping in RP_CASE_STATUS_NATIVE_VALUES.values():
        for public_value, native_value in mapping.items():
            assert public_value in script
            assert native_value in script

    api = FakeApi()
    build_create_graph(api, 100, bp("rp"))
    normalizer = by_title(api, "Normalize RP case status values")
    assert normalizer["type"] == "script"
    assert normalizer["config"]["content"] == script


def test_rp_update_allows_explicit_null_to_clear_case_status() -> None:
    result = run_js(
        guarded_patch_script(bp("rp")),
        formData={"other_particulars": {"q1": {"case_status": None}}},
        application={"f_q1_case_status": "being prosecuted currently"},
        intake={},
    )

    assert result["patch"]["f_q1_case_status"] is None


@pytest.mark.parametrize("key", ["sh", "rp"])
def test_update_is_preserve_on_absent_and_uses_validated_nested_replacement(
    key: str,
) -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp(key))

    projection = by_title(api, f"Project guarded {key} update patch")
    script = projection["config"]["content"]
    assert "hasOwnProperty.call" in script
    assert "current[internal]" in script
    if key == "rp":
        assert "q3being" in script
        assert "q4being prosecuted currently" in script
        assert "f_rp_declaration_ack" not in script
        assert "f_other_home_name" not in script
        assert "f_other_home_lorche_d_no" not in script
    apply = values(by_title(api, "Apply staged update overlay"))
    assert apply
    assert all(".patch." in reference for reference in apply.values())

    failed = by_title(api, "Mark nested replacement validation failed")
    assert values(failed)["f_error_message"] == (
        "nested_replacement_readback_validation_failed"
    )
    validation_title = (
        "Validate replacement Specific Hour hierarchy"
        if key == "sh"
        else "Validate replacement RP currently appointed rows"
    )
    validation = by_title(api, validation_title)
    guard = by_title(api, "Replacement hierarchy validated")
    assert guard["upstreamId"] == validation["id"]
    processing = by_title(api, "Reload processing Staging before nested swap")
    assert processing["upstreamId"] == guard["id"]
    assert processing["branchIndex"] == 1

    if key == "sh":
        cleanup_times = by_title(
            api, "Cleanup invalid replacement Specific Hour time rows"
        )
        cleanup_staffings = by_title(
            api, "Cleanup invalid replacement Specific Hour staffings"
        )
        cleanup_options = by_title(
            api, "Cleanup invalid replacement Specific Hour options"
        )
        assert cleanup_times["upstreamId"] == guard["id"]
        assert cleanup_times["branchIndex"] == 0
        assert cleanup_staffings["upstreamId"] == cleanup_times["id"]
        assert cleanup_options["upstreamId"] == cleanup_staffings["id"]
        assert failed["upstreamId"] == cleanup_options["id"]
        assert cleanup_times["config"]["params"]["filter"] == {
            "$and": [{"id": {"$in": ref(validation, "cleanup_time_ids")}}]
        }
        assert cleanup_staffings["config"]["params"]["filter"] == {
            "$and": [{"id": {"$in": ref(validation, "cleanup_staffing_ids")}}]
        }
        assert cleanup_options["config"]["params"]["filter"] == {
            "$and": [{"id": {"$in": ref(validation, "cleanup_option_ids")}}]
        }
        destroy_times = by_title(
            api, "Destroy old Specific Hour time rows by snapshot IDs"
        )
        destroy_staff = by_title(
            api, "Destroy old Specific Hour staffings by snapshot IDs"
        )
        destroy_options = by_title(
            api, "Destroy old Specific Hour options by snapshot IDs"
        )
        assert destroy_times["type"] == "destroy"
        assert destroy_staff["upstreamId"] == destroy_times["id"]
        assert destroy_options["upstreamId"] == destroy_staff["id"]
        assert destroy_times["config"]["params"]["filter"] == {
            "$and": [{"id": {"$in": ref(validation, "delete_time_ids")}}]
        }
        assert "fk_specific_hour" not in str(destroy_times["config"])
        assert "fk_specific_hour" not in str(destroy_staff["config"])
        assert "fk_specific_hour" not in str(destroy_options["config"])
    else:
        cleanup_rows = by_title(
            api, "Cleanup invalid replacement RP appointed rows"
        )
        assert cleanup_rows["upstreamId"] == guard["id"]
        assert cleanup_rows["branchIndex"] == 0
        assert failed["upstreamId"] == cleanup_rows["id"]
        assert cleanup_rows["config"]["params"]["filter"] == {
            "$and": [{"id": {"$in": ref(validation, "cleanup_ids")}}]
        }
        destroy_rows = by_title(
            api, "Destroy old RP currently appointed rows by snapshot IDs"
        )
        assert destroy_rows["type"] == "destroy"
        assert destroy_rows["config"]["params"]["filter"] == {
            "$and": [{"id": {"$in": ref(validation, "delete_ids")}}]
        }
        assert "fk_t_rp_application_id" not in str(destroy_rows["config"])


@pytest.mark.parametrize("key", ["sh", "rp"])
def test_update_patches_only_allowed_intake_fields_and_preserves_omissions(
    key: str,
) -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp(key))

    intake = by_title(api, "Resolve linked Intake for guarded update")
    original = by_title(api, "Resolve original CREATE staging record")
    assert intake["config"]["params"]["filter"] == {
        "$and": [{"id": {"$eq": ref(original, "f_intake_id")}}]
    }
    intake_exists = by_title(api, "Linked Intake exists")
    application = by_title(api, "Resolve linked application")
    assert application["upstreamId"] == intake_exists["id"]
    assert application["branchIndex"] == 1

    apply_intake = by_title(api, "Apply guarded Intake update")
    assert apply_intake["config"]["collection"] == "t_intake_form"
    assert set(values(apply_intake)) == {
        "f_received_date",
        "f_severity",
        "fk_intake_source",
        "f_source_other",
        "fk_task_owner",
        "fk_task_owner_post",
    }
    assert all(".intake_patch." in item for item in values(apply_intake).values())
    forbidden = {
        "f_office_cd",
        "fk_intake_source_rch",
        "createdBy",
        "createdById",
        "f_subject",
    }
    assert forbidden.isdisjoint(values(apply_intake))

    may_swap = by_title(api, "Staging still processing before nested swap")
    application_patch = by_title(api, "Apply staged update overlay")
    assert apply_intake["upstreamId"] == may_swap["id"]
    assert apply_intake["branchIndex"] == 1
    assert application_patch["upstreamId"] == apply_intake["id"]

    current = {
        "f_received_date": "2026-09-01",
        "f_severity": "0",
        "fk_intake_source": 701,
        "f_source_other": "Existing source",
        "fk_task_owner": 45,
        "fk_task_owner_post": "S(LR)1",
        "f_office_cd": "LORCHE",
        "fk_intake_source_rch": 9001,
        "createdById": 12,
    }
    projected = run_js(
        guarded_patch_script(bp(key)),
        formData={
            "case_summary": {
                "severity": "2",
                "office_code": "LORCHD",
                "submitter_user_id": 999,
                "lorche_d_no": "CLIENT-VALUE",
            }
        },
        application={},
        intake=current,
    )["intake_patch"]
    assert projected == {
        "f_received_date": "2026-09-01",
        "f_severity": "2",
        "fk_intake_source": 701,
        "f_source_other": "Existing source",
        "fk_task_owner": 45,
        "fk_task_owner_post": "S(LR)1",
    }


def test_rp_nested_validation_distinguishes_missing_clear_and_invalid() -> None:
    script = rp_validation_script()
    old = [{"id": 1, "f_rch_no": "OLD", "f_rch_name": "Old Home"}]
    # NocoBase omits unresolved optional script arguments entirely, rather
    # than binding them to null.  A scalar/Checklist-only Update must remain
    # a no-op for this relation, while an incomplete replacement must fail.
    omitted = run_js(script, replacementRequested=False)
    assert omitted == {"valid": True, "delete_ids": [], "cleanup_ids": []}
    incomplete = run_js(script, replacementRequested=True)
    assert incomplete == {"valid": False, "delete_ids": [], "cleanup_ids": []}
    missing_snapshot = run_js(
        script, replacementRequested=True, requestedHomes=[]
    )
    assert missing_snapshot == {
        "valid": False, "delete_ids": [], "cleanup_ids": [],
    }
    missing = run_js(
        script,
        replacementRequested=False,
        requestedHomes=None,
        oldIds=[1],
        currentHomes=old,
    )
    assert missing == {"valid": True, "delete_ids": [], "cleanup_ids": []}

    clear = run_js(
        script,
        replacementRequested=True,
        requestedHomes=[],
        oldIds=[1],
        currentHomes=old,
    )
    assert clear == {"valid": True, "delete_ids": [1], "cleanup_ids": []}

    invalid = run_js(
        script,
        replacementRequested=True,
        requestedHomes=[{"rch_no": "NEW", "rch_name": "New Home"}],
        oldIds=[1],
        currentHomes=[
            *old,
            {"id": 2, "f_rch_no": "WRONG", "f_rch_name": "Wrong Home"},
        ],
    )
    assert invalid == {"valid": False, "delete_ids": [], "cleanup_ids": [2]}

    valid = run_js(
        script,
        replacementRequested=True,
        requestedHomes=[{"rch_no": "NEW", "rch_name": "New Home"}],
        oldIds=[1],
        currentHomes=[
            *old,
            {"id": 2, "f_rch_no": "NEW", "f_rch_name": "New Home"},
        ],
    )
    assert valid == {"valid": True, "delete_ids": [1], "cleanup_ids": [2]}


def test_sh_nested_validation_preserves_old_until_complete_readback() -> None:
    script = specific_hour_validation_script()
    old = [{"id": 1, "f_specific_hour_staffings": []}]
    common = {
        "oldOptionIds": [1],
        "oldStaffingIds": [2],
        "oldTimeIds": [3],
    }
    # NocoBase omits unresolved optional argument bindings entirely.  A
    # scalar-only UPDATE must still pass nested validation without a JS
    # ReferenceError or a replacement of existing Specific Hour rows.
    omitted = run_js(
        script,
        replacementRequested=False,
        currentOptions=old,
        **common,
    )
    assert omitted == {
        "valid": True,
        "delete_time_ids": [],
        "delete_staffing_ids": [],
        "delete_option_ids": [],
        "cleanup_time_ids": [],
        "cleanup_staffing_ids": [],
        "cleanup_option_ids": [],
    }
    missing = run_js(
        script,
        replacementRequested=False,
        requestedOptions=None,
        currentOptions=old,
        **common,
    )
    assert missing == {
        "valid": True,
        "delete_time_ids": [],
        "delete_staffing_ids": [],
        "delete_option_ids": [],
        "cleanup_time_ids": [],
        "cleanup_staffing_ids": [],
        "cleanup_option_ids": [],
    }
    clear = run_js(
        script,
        replacementRequested=True,
        requestedOptions=[],
        currentOptions=old,
        **common,
    )
    assert clear == {
        "valid": True,
        "delete_time_ids": [3],
        "delete_staffing_ids": [2],
        "delete_option_ids": [1],
        "cleanup_time_ids": [],
        "cleanup_staffing_ids": [],
        "cleanup_option_ids": [],
    }

    requested = [
        {
            "set_no": "0",
            "section": "workday_and_holiday",
            "section_other": None,
            "staffings": [
                {
                    "staff_type_code": "AW",
                    "other_duties": "Care",
                    "_rule_snapshot": {
                        "staff_ratio_requirement": "1:20",
                        "minimum_required_hours": 2,
                        "sort_order": 1,
                    },
                    "time_rows": [
                        {
                            "work_hour_from": "08:00:00",
                            "work_hour_to": "10:00:00",
                            "remark": "Morning",
                            "_duration_hours": 2,
                            "_sort_order": 1,
                        }
                    ],
                }
            ],
        }
    ]
    new_option = {
        "id": 10,
        "f_specific_hour_set_no": "0",
        "f_section": "workday_and_holiday",
        "f_section_other": None,
        "f_specific_hour_staffings": [
            {
                "id": 20,
                "f_staff_type_id": {"f_staff_code": "AW"},
                "f_duty_description": "Care",
                "f_staff_ratio_requirement": "1:20",
                "f_minimum_required_hours": 2,
                "f_sort_order": 1,
                "f_specific_hour_time_rows": [
                    {
                        "id": 30,
                        "f_work_hour_from": "08:00:00",
                        "f_work_hour_to": "10:00:00",
                        "f_duration_hours": 2,
                        "f_sort_order": 1,
                        "f_remark": "Morning",
                    }
                ],
            }
        ],
    }
    invalid = run_js(
        script,
        replacementRequested=True,
        requestedOptions=requested,
        currentOptions=[
            *old,
            {
                **new_option,
                "f_section": "unexpected_section",
            },
        ],
        **common,
    )
    assert invalid["valid"] is False
    assert invalid["delete_option_ids"] == []
    assert invalid["cleanup_time_ids"] == [30]
    assert invalid["cleanup_staffing_ids"] == [20]
    assert invalid["cleanup_option_ids"] == [10]

    valid = run_js(
        script,
        replacementRequested=True,
        requestedOptions=requested,
        currentOptions=[*old, new_option],
        **common,
    )
    assert valid == {
        "valid": True,
        "delete_time_ids": [3],
        "delete_staffing_ids": [2],
        "delete_option_ids": [1],
        "cleanup_time_ids": [30],
        "cleanup_staffing_ids": [20],
        "cleanup_option_ids": [10],
    }


@pytest.mark.parametrize("key", ["sh", "rp"])
@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_checklist_always_creates_details_before_latest(key: str, builder: Any) -> None:
    api = FakeApi()
    builder(api, 100, bp(key))

    existing_detail = by_title(api, "Create existing Checklist upload Details")
    existing_latest = by_title(api, "Refresh existing Checklist Latest")
    new_detail = by_title(api, "Create new Checklist upload Details")
    new_latest = by_title(api, "Refresh new Checklist Latest")
    assert existing_latest["upstreamId"] == existing_detail["id"]
    assert new_latest["upstreamId"] == new_detail["id"]
    assert existing_detail["config"]["collection"] == (
        "t_document_submitted_for_application_details"
    )
    assert new_detail["config"]["collection"] == (
        "t_document_submitted_for_application_details"
    )
    assert values(existing_latest)["f_lastest_files"]
    assert values(new_latest)["f_lastest_files"]
    base_create = values(by_title(api, "Create checklist item without Latest"))
    assert "f_lastest_files" not in base_create

    succeeded_title = (
        "Mark succeeded + backfill IDs"
        if builder is build_create_graph
        else "Mark update succeeded + backfill IDs"
    )
    succeeded = by_title(api, succeeded_title)
    final_guard = by_title(api, "Checklist completed without failure")
    assert succeeded["upstreamId"] == final_guard["id"]
    assert succeeded["branchIndex"] == 1


def test_update_requires_accepted_parent_and_backfills_parent_create_id() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("rp"))

    original = by_title(api, "Resolve original CREATE staging record")
    filters = original["config"]["params"]["filter"]["$and"]
    assert {"f_application_status": {"$eq": "Accepted"}} in filters
    succeeded = values(by_title(api, "Mark update succeeded + backfill IDs"))
    assert succeeded["f_parent_create_id"].endswith(".id}}")


def test_sh_rch_care_level_is_mapped_on_create_and_update() -> None:
    create_api = FakeApi()
    build_create_graph(create_api, 100, bp("sh"))
    create_parse = by_title(create_api, "Parse staged sh request body")
    create_overlay = values(by_title(create_api, "Apply staged overlay"))
    assert create_overlay["f_rch_care_level"] == ref(
        create_parse, "rchCareLevel"
    )

    update_api = FakeApi()
    build_update_graph(update_api, 100, bp("sh"))
    projection = by_title(update_api, "Project guarded sh update patch")
    update_overlay = values(by_title(update_api, "Apply staged update overlay"))
    assert update_overlay["f_rch_care_level"] == ref(
        projection, "patch.f_rch_care_level"
    )


def test_rp_received_date_is_mapped_on_update() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("rp"))

    projection = by_title(api, "Project guarded rp update patch")
    overlay = values(by_title(api, "Apply staged update overlay"))
    assert overlay["f_application_received_date"] == ref(
        projection, "patch.f_application_received_date"
    )
    assert "f_application_received_date" in projection["config"]["content"]


@pytest.mark.parametrize("key", ["sh", "rp"])
def test_update_checklist_preflight_precedes_every_business_write(key: str) -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp(key))

    projection = by_title(api, f"Project guarded {key} update patch")
    preflight_loop = by_title(api, "Preflight Checklist files")
    preflight_guard = by_title(api, "Checklist preflight completed without failure")
    assert preflight_loop["upstreamId"] == projection["id"]

    business_mutations = [
        row
        for row in api.nodes
        if row["type"] in {"create", "update", "destroy"}
        and row.get("config", {}).get("collection")
        not in {None, "t_api_request_staging"}
    ]
    assert business_mutations
    assert all(
        is_descendant_of(api, mutation, preflight_guard)
        for mutation in business_mutations
    )


@pytest.mark.parametrize("key", ["sh", "rp"])
def test_update_finalizes_deferred_received_after_all_terminal_paths(
    key: str,
) -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp(key))

    finalizers = [
        row
        for row in api.nodes
        if row["type"] == "sql"
        and row["title"].startswith("Finalize deferred Received after ")
    ]
    assert len(finalizers) == 8
    for finalizer in finalizers:
        sql = finalizer["config"]["sql"]
        assert 'create_row."f_status"=\'succeeded\'' in sql
        assert not sql.startswith("WITH ")
        assert '"f_active_update_id"=NULL' in sql
        assert 'create_row."f_active_update_id"=:activeUpdateId' in sql
        assert '"f_application_status"=CASE WHEN' in sql
        assert 'create_row."f_request_event"=\'CREATE\'' in sql
        assert 'create_row."f_application_status"=\'Accepted\'' in sql
        assert 'intake."f_approval_status" AS text)=\'4\'' in sql
        assert 'active."f_status" IN (\'submitted\',\'processing\')' in sql
        assert 'NOT EXISTS (SELECT 1 FROM "t_api_request_staging" AS active' in sql
        assert 'RETURNING create_row."id"' in sql
        assert finalizer["config"]["variables"] == [
            {
                "name": "parentCreateId",
                "value": "{{$context.data.f_parent_create_id}}",
            },
            {
                "name": "activeUpdateId",
                "value": "{{$context.data.f_active_update_id}}",
            },
            {"name": "createApiType", "value": bp(key)["create_api_type"]},
            {"name": "applicationType", "value": bp(key)["application_type"]},
        ]

    preflight_guard = by_title(api, "Checklist preflight completed without failure")
    preflight_failure = by_title(
        api, "Finalize deferred Received after Checklist preflight failure"
    )
    assert preflight_failure["upstreamId"] == preflight_guard["id"]
    assert preflight_failure["branchIndex"] == 0

    checklist_guard = by_title(api, "Checklist completed without failure")
    checklist_failure = by_title(
        api, "Finalize deferred Received after Checklist commit failure"
    )
    assert checklist_failure["upstreamId"] == checklist_guard["id"]
    assert checklist_failure["branchIndex"] == 0

    succeeded = by_title(api, "Mark update succeeded + backfill IDs")
    success_finalizer = by_title(
        api, "Finalize deferred Received after successful Update"
    )
    assert success_finalizer["upstreamId"] == succeeded["id"]
