from __future__ import annotations

import json
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from create_nocobase_phase_f_change_workflows import (  # noqa: E402
    BPS,
    build_create_graph,
    build_update_graph,
    create_intake_patch_script,
    create_record_patch_script,
    director_document_cleanup_script,
    guarded_patch_script,
    ref,
)


class FakeApi:
    def __init__(self) -> None:
        self.nodes: list[dict[str, Any]] = []

    def create_node(self, body: dict[str, Any]) -> dict[str, Any]:
        node_id = len(self.nodes) + 1
        node = {
            **deepcopy(body),
            "id": node_id,
            "key": f"node-{node_id}",
        }
        self.nodes.append(node)
        return deepcopy(node)

    def update_node(self, node_id: int, body: dict[str, Any]) -> dict[str, Any]:
        node = next(row for row in self.nodes if row["id"] == node_id)
        node.update(deepcopy(body))
        return deepcopy(node)


def bp(key: str) -> dict[str, Any]:
    return next(deepcopy(row) for row in BPS if row["key"] == key)


def by_title(api: FakeApi, title: str) -> dict[str, Any]:
    return next(row for row in api.nodes if row["title"] == title)


def values(node: dict[str, Any]) -> dict[str, Any]:
    return node["config"]["params"]["values"]


def run_js(script: str, **arguments: Any) -> dict[str, Any]:
    names = list(arguments)
    source = (
        f"const fn = new Function(...{json.dumps(names)}, {json.dumps(script)});"
        f"const values = {json.dumps([arguments[name] for name in names])};"
        "process.stdout.write(JSON.stringify(fn(...values)));"
    )
    result = subprocess.run(
        ["node", "-e", source],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_change_graph_uses_atomic_claim_without_transaction(
    key: str, builder: Any
) -> None:
    api = FakeApi()
    builder(api, 100, bp(key))

    operation = "Create" if builder is build_create_graph else "Update"
    claim = by_title(api, f"Atomically claim submitted {operation} row")
    assert claim["type"] == "sql"
    assert claim["config"]["dataSource"] == "main"
    assert claim["config"]["unsafeInjection"] is False
    assert claim["config"]["variables"] == [
        {"name": "stagingId", "value": "{{$context.data.id}}"}
    ]
    assert "SET \"f_status\" = 'processing'" in claim["config"]["sql"]
    assert "\"f_status\" = 'submitted'" in claim["config"]["sql"]
    assert "RETURNING" in claim["config"]["sql"]
    if builder is build_update_graph:
        sql = claim["config"]["sql"]
        assert 'parent."f_request_event" = \'CREATE\'' in sql
        assert 'parent."f_status" = \'succeeded\'' in sql
        assert 'parent."f_application_status" = \'Accepted\'' in sql
        assert 'parent."f_intake_id" IS NOT NULL' in sql
        assert 'parent."f_application_id" IS NOT NULL' in sql
        assert 'parent."f_active_update_id" = staged."f_active_update_id"' in sql
        assert 'active."f_status" = \'processing\'' in sql
        assert 'active."f_status" = \'submitted\'' in sql

    inspect = by_title(api, f"Inspect atomic {operation} claim result")
    guard = by_title(api, f"Atomic {operation} claim returned one row")
    rejected = by_title(api, f"Finalize rejected {operation} claim")
    assert inspect["upstreamId"] == claim["id"]
    assert guard["upstreamId"] == inspect["id"]
    assert rejected["upstreamId"] == guard["id"]
    assert rejected["branchIndex"] == 0
    assert all(node["type"] != "transaction" for node in api.nodes)


@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
def test_create_never_directly_creates_change_monitoring_base(key: str) -> None:
    api = FakeApi()
    build_create_graph(api, 100, bp(key))

    assert not any(
        node["type"] == "create"
        and node["config"].get("collection") == "t_change_monitoring_base"
        for node in api.nodes
    )
    application = by_title(api, "Find native-created Change Monitoring")
    assert application["type"] == "query"
    assert application["config"]["collection"] == "t_change_monitoring_base"
    intake = by_title(api, "Create marked Intake (fixed type + Home Record)")
    assert values(intake)["f_api_create_staging_id"] == "{{$context.data.id}}"


@pytest.mark.parametrize("key", ["mgr", "beds", "mode", "dir", "nurse"])
@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_base_writes_exclude_intake_identity_and_comments(
    key: str, builder: Any
) -> None:
    api = FakeApi()
    builder(api, 100, bp(key))

    forbidden = {
        "f_comments",
        "fk_intake_form",
        "fk_intake_type",
        "fk_home_record",
        "createdBy",
        "updatedBy",
    }
    base_writes = [
        node
        for node in api.nodes
        if node["type"] == "update"
        and node["config"].get("collection") == "t_change_monitoring_base"
    ]
    assert base_writes
    assert all(not (set(values(node)) & forbidden) for node in base_writes)
    if builder is build_create_graph:
        assert set(values(base_writes[0])) <= {
            "f_application_received_date",
            "f_proposed_effective_date",
            "f_remarks",
            "f_documents",
        }
    else:
        intake_patch = by_title(api, "Apply guarded Intake comments patch")
        assert intake_patch["config"]["collection"] == "t_intake_form"
        assert set(values(intake_patch)) == {"f_comments"}


@pytest.mark.parametrize(
    ("key", "should_create"),
    [
        ("mgr", True),
        ("beds", True),
        ("mode", True),
        ("dir", True),
        ("nurse", True),
    ],
)
def test_integration_fallback_can_create_each_missing_change_detail(
    key: str, should_create: bool
) -> None:
    api = FakeApi()
    selected = bp(key)
    build_create_graph(api, 100, selected)

    detail_creates = [
        node
        for node in api.nodes
        if node["type"] == "create"
        and node["config"].get("collection") == selected["child_collection"]
    ]
    assert bool(detail_creates) is should_create
    if should_create:
        assert [node["title"] for node in detail_creates] == [
            "Create missing Change detail owned by integration"
        ]
        assert "fk_change_monitoring" in values(detail_creates[0])
    else:
        failed = by_title(api, "Mark native Change detail resolution failed")
        assert values(failed)["f_error_message"] == (
            "native_change_detail_not_resolved"
        )


@pytest.mark.parametrize(
    ("key", "builder", "title"),
    [
        ("dir", build_create_graph, "Create submitted Director document rows"),
        ("dir", build_update_graph, "Upsert replacement Director document rows"),
    ],
)
def test_director_document_loops_use_standard_loop_configuration(
    key: str, builder: Any, title: str
) -> None:
    api = FakeApi()
    builder(api, 100, bp(key))

    loop = by_title(api, title)
    assert loop["type"] == "loop"
    source = by_title(
        api,
        (
            "Parse staged dir request body"
            if builder is build_create_graph
            else "Project guarded dir update patch"
        ),
    )
    assert loop["config"] == {
        "target": ref(
            source,
            "directorDocuments" if builder is build_create_graph else "documents",
        ),
        "condition": False,
        "exit": 2,
    }
    row = by_title(
        api,
        (
            "Create typed Director document row"
            if builder is build_create_graph
            else "Find existing Director document by type"
        ),
    )
    assert row["upstreamId"] == loop["id"]
    assert row["branchIndex"] == 0


def test_guarded_manager_patch_preserves_omitted_fields() -> None:
    result = run_js(
        guarded_patch_script(bp("mgr")),
        formData={"proposed_name": "Replacement Manager"},
        base={
            "f_application_received_date": "2026-09-01",
            "f_proposed_effective_date": "2026-12-31",
            "f_remarks": "keep base remarks",
            "f_documents": [{"id": 101}, {"id": 102}],
        },
        child={
            "f_proposed_name": "Old Manager",
            "f_proposed_tel": "21234567",
            "f_proposed_email": "old@example.com",
            "f_proposed_post": "Home Manager",
            "f_proposed_remark": "keep child remark",
        },
        intake={"f_comments": "keep Intake comments"},
    )

    assert result["valid"] is True
    assert result["base_patch"] == {
        "f_application_received_date": "2026-09-01",
        "f_proposed_effective_date": "2026-12-31",
        "f_remarks": "keep base remarks",
        "f_documents": [101, 102],
    }
    assert result["child_patch"] == {
        "f_proposed_name": "Replacement Manager",
        "f_proposed_tel": "21234567",
        "f_proposed_email": "old@example.com",
        "f_proposed_post": "Home Manager",
        "f_proposed_remark": "keep child remark",
    }
    assert result["intake_patch"] == {
        "f_comments": "keep Intake comments"
    }


def test_guarded_beds_patch_does_not_invent_total_equality_rules() -> None:
    result = run_js(
        guarded_patch_script(bp("beds")),
        formData={"proposed_beds_self_care": 30},
        base={
            "f_proposed_effective_date": None,
            "f_remarks": None,
            "f_documents": [],
        },
        child={
            "f_proposed_beds_self_care": 20,
            "f_proposed_beds_meal": 20,
            "f_proposed_beds_nursing": 40,
            "f_proposed_beds_care_and_attention": 10,
            "f_proposed_residents_total_ab": 0,
            "f_proposed_residents_total_a": 0,
            "f_proposed_residents_total_b": 0,
            "f_proposed_residents_self_care": 0,
            "f_proposed_residents_meal": 0,
            "f_proposed_residents_nursing": 0,
            "f_proposed_residents_care_and_attention": 0,
            "f_proposed_residents_nursing_beyond": 0,
            "f_proposed_residents_nonelderly_mental": 0,
            "f_proposed_residents_nonelderly_intellectual": 0,
            "f_proposed_residents_nonelderly_physical": 0,
            "f_proposed_residents_nonelderly_others": 0,
            "f_proposed_residents_nonelderly_others_specify": None,
            "f_proposed_residents_nonelderly_other_details_num": 0,
        },
        intake={"f_comments": None},
    )

    assert result["valid"] is True
    assert result["error"] is None
    assert result["child_patch"]["f_proposed_beds_self_care"] == 30
    assert result["child_patch"]["f_proposed_residents_total_ab"] == 0

    missing_others_description = run_js(
        guarded_patch_script(bp("beds")),
        formData={
            "proposed_residents_nonelderly_others": 1,
            "proposed_residents_nonelderly_others_specify": None,
        },
        base={
            "f_proposed_effective_date": None,
            "f_remarks": None,
            "f_documents": [],
        },
        child=result["child_patch"],
        intake={"f_comments": None},
    )
    assert missing_others_description["valid"] is False
    assert (
        missing_others_description["error"]
        == "beds_others_specify_required"
    )


def test_nurse_documents_are_written_on_detail_not_base() -> None:
    create_api = FakeApi()
    build_create_graph(create_api, 100, bp("nurse"))
    base_patch = by_title(create_api, "Apply staged base fields only")
    child_patch = by_title(create_api, "Apply staged detail fields")
    child_query = by_title(create_api, "Find native Change detail row")

    assert "f_documents" not in values(base_patch)
    assert values(child_patch)["f_documents"].endswith(".patch.f_documents}}")
    assert child_query["config"]["params"]["appends"] == ["f_documents"]

    update_api = FakeApi()
    build_update_graph(update_api, 100, bp("nurse"))
    update_base = by_title(update_api, "Apply guarded base patch")
    update_child = by_title(update_api, "Apply guarded detail patch")
    assert "f_documents" not in values(update_base)
    assert "f_documents" in values(update_child)


@pytest.mark.parametrize("builder", [build_create_graph, build_update_graph])
def test_director_documents_use_typed_uploading_document_relation(
    builder: Any,
) -> None:
    api = FakeApi()
    build = builder
    build(api, 100, bp("dir"))

    base_title = (
        "Apply staged base fields only"
        if builder is build_create_graph
        else "Apply guarded base patch"
    )
    child_title = (
        "Apply staged detail fields"
        if builder is build_create_graph
        else "Apply guarded detail patch"
    )
    assert "f_documents" not in values(by_title(api, base_title))
    assert "f_documents" not in values(by_title(api, child_title))
    document = by_title(
        api,
        (
            "Create typed Director document row"
            if builder is build_create_graph
            else "Create missing Director document by type"
        ),
    )
    assert document["config"]["collection"] == "t_uploading_documents"
    assert set(values(document)) >= {
        "fk_uploading_documents",
        "f_document_type",
        "f_lastest_files",
        "f_remarks",
    }

    if builder is build_update_graph:
        child_query = by_title(api, "Resolve linked Change detail")
        assert child_query["config"]["params"]["appends"] == [
            "f_uploading_documents",
            "f_uploading_documents.f_lastest_files",
        ]
        destroy = by_title(
            api, "Destroy only obsolete pre-upsert Director document rows"
        )
        upsert = by_title(api, "Upsert replacement Director document rows")
        cleanup = by_title(
            api, "Obsolete Director snapshot rows remain after upsert"
        )
        assert destroy["config"]["collection"] == "t_uploading_documents"
        assert cleanup["upstreamId"] == upsert["id"]
        assert destroy["upstreamId"] == cleanup["id"]
        assert destroy["branchIndex"] == 1


def test_guarded_director_patch_requires_effective_authorisation_letter() -> None:
    script = guarded_patch_script(bp("dir"))
    base = {"f_proposed_effective_date": None, "f_remarks": None}
    common_child = {
        "f_title": "0",
        "f_name_eng": "Director",
        "f_name_chi": "董事",
        "f_date_of_directors_change": "2026-09-23",
        "f_other_phone_number": "21234567",
        "f_authorised_to_apply": True,
        "f_means_of_authorisation": "1",
    }
    existing_letter = {
        **common_child,
        "f_uploading_documents": [
            {"f_document_type": "AUTHORISATION_LETTER"}
        ],
    }

    preserved = run_js(
        script,
        formData={"name_en": "Changed Director"},
        base=base,
        child=existing_letter,
        intake={"f_comments": None},
    )
    assert preserved["valid"] is True
    assert preserved["documents_requested"] is False

    cleared = run_js(
        script,
        formData={"documents": []},
        base=base,
        child=existing_letter,
        intake={"f_comments": None},
    )
    assert cleared["valid"] is False
    assert cleared["error"] == "directors_authorisation_letter_required"

    missing = run_js(
        script,
        formData={"name_en": "Changed Director"},
        base=base,
        child={**common_child, "f_uploading_documents": []},
        intake={"f_comments": None},
    )
    assert missing["valid"] is False
    assert missing["error"] == "directors_authorisation_letter_required"


def test_create_record_patch_preserves_omitted_native_defaults() -> None:
    result = run_js(
        create_record_patch_script(
            {
                "case_summary.received_date": "f_application_received_date",
                "proposed_name": "f_proposed_name",
                "proposed_tel": "f_proposed_tel",
                "attachment_ids": "f_documents",
            }
        ),
        formData={
            "case_summary": {},
            "proposed_name": "Replacement Manager",
        },
        current={
            "f_application_received_date": "2026-09-01",
            "f_proposed_name": "Native Manager",
            "f_proposed_tel": "native-default",
            "f_documents": [{"id": 101}],
        },
    )

    assert result["patch"] == {
        "f_application_received_date": "2026-09-01",
        "f_proposed_name": "Replacement Manager",
        "f_proposed_tel": "native-default",
        "f_documents": [101],
    }


def test_create_graph_applies_optional_intake_fields_after_native_create() -> None:
    api = FakeApi()
    build_create_graph(api, 100, bp("mgr"))

    intake = by_title(api, "Create marked Intake (fixed type + Home Record)")
    initial_values = values(intake)
    assert not (
        {
            "f_received_date",
            "f_severity",
            "fk_intake_source",
            "f_source_other",
            "f_comments",
        }
        & set(initial_values)
    )
    normalize = by_title(
        api, "Merge optional Intake Create fields with native defaults"
    )
    apply = by_title(api, "Apply supplied optional Intake Create fields")
    assert normalize["upstreamId"] == intake["id"]
    assert apply["upstreamId"] == normalize["id"]

    projected = run_js(
        create_intake_patch_script(),
        formData={"case_summary": {}, "proposed_name": "Manager"},
        intake={
            "f_received_date": "2026-09-23",
            "f_severity": "native-severity",
            "fk_intake_source": 77,
            "f_source_other": "native-source",
            "f_comments": "native-comments",
        },
    )
    assert projected == {
        "f_received_date": "2026-09-23",
        "f_severity": "native-severity",
        "fk_intake_source": 77,
        "f_source_other": "native-source",
        "f_comments": "native-comments",
    }


def test_director_update_upserts_before_snapshot_cleanup() -> None:
    api = FakeApi()
    build_update_graph(api, 100, bp("dir"))

    snapshot = by_title(api, "Snapshot existing Director document rows")
    plan = by_title(
        api, "Plan obsolete Director documents from pre-upsert snapshot"
    )
    upsert = by_title(api, "Upsert replacement Director document rows")
    existing = by_title(api, "Find existing Director document by type")
    create = by_title(api, "Create missing Director document by type")
    update = by_title(api, "Update existing Director document by type")
    cleanup_guard = by_title(
        api, "Obsolete Director snapshot rows remain after upsert"
    )
    destroy = by_title(
        api, "Destroy only obsolete pre-upsert Director document rows"
    )

    assert plan["upstreamId"] == snapshot["id"]
    assert upsert["upstreamId"] == plan["id"]
    assert existing["upstreamId"] == upsert["id"]
    assert existing["config"]["params"]["sort"] == [
        {"field": "id", "direction": "asc"}
    ]
    assert create["branchIndex"] == 0
    assert update["branchIndex"] == 1
    assert cleanup_guard["upstreamId"] == upsert["id"]
    assert destroy["upstreamId"] == cleanup_guard["id"]


def test_director_cleanup_only_targets_obsolete_snapshot_rows() -> None:
    result = run_js(
        director_document_cleanup_script(),
        rows=[
            {"id": 1, "f_document_type": "AUTHORISATION_LETTER"},
            {"id": 2, "f_document_type": "ND2A"},
            {"id": 3, "f_document_type": "ND2B"},
            {"id": 4, "f_document_type": "AUTHORISATION_LETTER"},
        ],
        documents=[
            {"document_type": "AUTHORISATION_LETTER", "attachment_ids": [101]},
            {"document_type": "ND2B", "attachment_ids": [103]},
        ],
    )

    assert result == {"ids": [2, 4], "has_obsolete": True}
