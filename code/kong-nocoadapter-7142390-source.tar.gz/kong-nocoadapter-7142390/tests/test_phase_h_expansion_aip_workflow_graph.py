from __future__ import annotations

import json
import subprocess
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from scripts.create_nocobase_phase_e_sh_rp_workflows import (  # noqa: E402
    INTAKE_UPDATE_FIELD_MAP,
)
from scripts.create_nocobase_phase_h_expansion_aip_workflows import (  # noqa: E402
    AIP_FIELD_MAP,
    APPLICATION_TYPE,
    BP,
    CHECKLIST_LATEST_FOREIGN_KEY,
    CHECKLIST_LATEST_THROUGH,
    COLLECTION,
    CREATE_API_TYPE,
    HOME_FK,
    INTAKE_FK,
    INTAKE_SUBMIT_WORKFLOW_KEY,
    INTAKE_TYPE_ID,
    SUBMIT_TITLE,
    UPDATE_API_TYPE,
    build_create_graph,
    build_update_graph,
    guarded_patch_script,
    native_candidate_script,
    parse_config,
    ref,
)
from scripts.workflow_source_condition import external_source_condition  # noqa: E402


class FakeApi:
    def __init__(self) -> None:
        self.nodes: list[dict[str, Any]] = []

    def create_node(self, body: dict[str, Any]) -> dict[str, Any]:
        node_id = len(self.nodes) + 1
        node = {**deepcopy(body), "id": node_id, "key": f"node-{node_id}"}
        self.nodes.append(node)
        return deepcopy(node)

    def update_node(self, node_id: int, body: dict[str, Any]) -> dict[str, Any]:
        node = next(row for row in self.nodes if row["id"] == node_id)
        node.update(deepcopy(body))
        return deepcopy(node)


def by_title(api: FakeApi, title: str) -> dict[str, Any]:
    return next(row for row in api.nodes if row["title"] == title)


def values(node: dict[str, Any]) -> dict[str, Any]:
    return node["config"]["params"]["values"]


def is_descendant_of(
    api: FakeApi,
    node: dict[str, Any],
    ancestor: dict[str, Any],
) -> bool:
    by_id = {row["id"]: row for row in api.nodes}
    current = node
    visited: set[int] = set()
    while current.get("upstreamId") is not None:
        upstream_id = current["upstreamId"]
        if upstream_id == ancestor["id"]:
            return True
        if upstream_id in visited:
            return False
        visited.add(upstream_id)
        current = by_id[upstream_id]
    return False


def run_js(script: str, **arguments: Any) -> dict[str, Any]:
    names = list(arguments)
    source = (
        f"const fn = new Function(...{json.dumps(names)}, {json.dumps(script)});"
        f"const values = {json.dumps([arguments[name] for name in names])};"
        "process.stdout.write(JSON.stringify(fn(...values)));"
    )
    result = subprocess.run(
        ["node", "-e", source],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def test_aip_contract_constants_and_strict_external_triggers() -> None:
    assert COLLECTION == "t_expansion_aip_for_licence"
    assert INTAKE_FK == "fk_intake_form"
    assert HOME_FK == "fk_home_record_id"
    assert INTAKE_TYPE_ID == 365214779310080
    assert INTAKE_SUBMIT_WORKFLOW_KEY == "qdkj25b0793"
    assert APPLICATION_TYPE == "expansion_aip"
    assert BP["checklist_use_for"] == COLLECTION
    assert BP["collection"] == COLLECTION

    create_condition = external_source_condition("CREATE", CREATE_API_TYPE)
    update_condition = external_source_condition("UPDATE", UPDATE_API_TYPE)
    assert create_condition == {
        "$and": [
            {"f_status": {"$eq": "submitted"}},
            {"f_source_system": {"$ne": "CMTF"}},
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_api_type": {"$eq": "create_intake_for_expansion_aip"}},
        ]
    }
    assert update_condition["$and"][-2:] == [
        {"f_request_event": {"$eq": "UPDATE"}},
        {"f_api_type": {"$eq": "update_expansion_aip_data"}},
    ]


def test_parse_config_matches_part_contract_and_compact_checklist() -> None:
    config = parse_config()
    example = config["example"]["form_data"]
    assert set(example) == {"case_summary", "part_1", "part_2", "part_3"}
    assert example["part_1"]["title"] == "0"
    assert example["part_1"]["means_of_authorisation"] == "0"
    assert "tentative_area_of_floor_space_expansion" in example["part_2"]
    assert "existing_area_of_floor_space_expansion" not in example["part_2"]
    assert example["part_3"] == {"checklist": []}

    by_key = {item["key"]: item["path"] for item in config["variables"]}
    assert by_key["name_eng"] == "form_data.part_1.name_eng"
    assert by_key["tentative_area_of_floor_space_expansion"] == (
        "form_data.part_2.tentative_area_of_floor_space_expansion"
    )
    assert by_key["checklist"] == "form_data.part_3.checklist"
    assert by_key["checklistPosition"] == (
        "form_data.part_3.checklist[].position_code"
    )
    assert by_key["checklistAttachment"] == (
        "form_data.part_3.checklist[].attachment_id"
    )
    assert AIP_FIELD_MAP["tentative_area_of_floor_space_expansion"] == (
        "f_existing_area_of_floor_space_expansion"
    )


def test_native_candidate_selector_requires_exactly_one_row() -> None:
    script = native_candidate_script()
    assert run_js(script, rows=[])["exactly_one"] is False
    assert run_js(script, rows=[])["count"] == 0
    one = run_js(script, rows=[{"id": 71}])
    assert one == {
        "exactly_one": True,
        "application": {"id": 71},
        "count": 1,
    }
    duplicate = run_js(script, rows=[{"id": 71}, {"id": 72}])
    assert duplicate["exactly_one"] is False
    assert duplicate["application"] is None
    assert duplicate["count"] == 2


def test_create_reuses_exactly_one_native_application_before_submit() -> None:
    api = FakeApi()
    build_create_graph(api, 100)

    claim = by_title(api, "Atomically claim submitted Expansion AIP Create row")
    assert claim["type"] == "sql"
    assert 'SET "f_status" = \'processing\'' in claim["config"]["sql"]
    assert '"f_status" = \'submitted\'' in claim["config"]["sql"]
    assert claim["config"]["unsafeInjection"] is False

    home = by_title(api, "Resolve Expansion AIP Home Record")
    intake = by_title(api, "Create Expansion AIP Intake (fixed type + Home Record)")
    intake_values = values(intake)
    assert intake_values["fk_intake_type"] == INTAKE_TYPE_ID
    assert intake_values["fk_intake_source_rch"] == "{{$context.data.f_rch_id}}"
    assert intake_values["f_subject"] == ref(home, "f_rch_no")
    assert intake_values["f_api_create_staging_id"] == "{{$context.data.id}}"
    assert intake_values["f_intake_accept_reject"] == "0"
    assert intake_values["createdBy"].endswith(".id}}")

    identity = by_title(api, "Apply Expansion AIP submitter post to Intake")
    candidates = by_title(api, "Find native-created Expansion AIP candidates")
    selector = by_title(api, "Require exactly one native-created Expansion AIP")
    unique_guard = by_title(api, "Exactly one native-created Expansion AIP exists")
    overlay = by_title(api, "Apply staged Expansion AIP overlay")
    assert candidates["type"] == "query"
    assert candidates["config"]["collection"] == COLLECTION
    assert candidates["config"]["multiple"] is True
    assert candidates["config"]["params"]["filter"] == {
        "$and": [{INTAKE_FK: {"$eq": ref(intake, "id")}}]
    }
    assert candidates["upstreamId"] == by_title(
        api, "Backfill Expansion AIP Intake ID before native Submit"
    )["id"]
    assert is_descendant_of(api, candidates, identity)
    assert selector["upstreamId"] == candidates["id"]
    assert unique_guard["upstreamId"] == selector["id"]
    assert overlay["upstreamId"] == unique_guard["id"]
    assert overlay["branchIndex"] == 1
    assert overlay["config"]["params"]["filter"] == {
        "$and": [
            {"id": {"$eq": ref(selector, "application.id")}},
        ]
    }
    assert set(values(overlay)) == set(AIP_FIELD_MAP.values())
    assert HOME_FK not in values(overlay)
    assert INTAKE_FK not in values(overlay)

    candidate_failed = by_title(
        api, "Mark native Expansion AIP candidate count failure"
    )
    assert candidate_failed["upstreamId"] == unique_guard["id"]
    assert candidate_failed["branchIndex"] == 0
    assert values(candidate_failed)["f_error_message"] == (
        "native_application_count_not_one"
    )

    load = by_title(api, "Load Expansion AIP Intake for native Submit")
    submit = by_title(api, SUBMIT_TITLE)
    reload_application = by_title(
        api, "Reload native Expansion AIP after native Submit"
    )
    assert load["upstreamId"] == overlay["id"]
    assert submit["upstreamId"] == load["id"]
    assert submit["type"] == "subflow"
    assert submit["config"]["workflow"] == INTAKE_SUBMIT_WORKFLOW_KEY
    assert submit["config"]["context"]["data"] == ref(load)
    assert submit["config"]["context"]["userId"].endswith(".id}}")
    assert reload_application["upstreamId"] == submit["id"]
    assert reload_application["config"]["params"]["filter"] == {
        "$and": [
            {"id": {"$eq": ref(selector, "application.id")}},
            {INTAKE_FK: {"$eq": ref(intake, "id")}},
        ]
    }

    # Only the native workflow may create the application. The sidecar never
    # creates one, so synchronous native Intake creation cannot race it.
    application_creates = [
        row
        for row in api.nodes
        if row["type"] == "create" and row["config"].get("collection") == COLLECTION
    ]
    assert application_creates == []
    assert is_descendant_of(api, submit, overlay)


def test_create_overlays_only_explicit_aip_fields_and_checklist_history() -> None:
    api = FakeApi()
    build_create_graph(api, 100)

    overlay = values(
        by_title(api, "Apply staged Expansion AIP overlay")
    )
    assert set(overlay) == set(AIP_FIELD_MAP.values())
    forbidden_home_projection = {
        INTAKE_FK,
        HOME_FK,
        "f_approval_status",
        "createdBy",
        "updatedBy",
        "f_rch_no",
        "f_rch_name",
        "f_rch_name_en",
        "f_rch_name_chi",
        "f_p_no",
        "f_office_cd",
    }
    assert forbidden_home_projection.isdisjoint(overlay)

    template = by_title(api, "Resolve checklist template by position_code")
    filters = template["config"]["params"]["filter"]["$and"]
    assert {"f_use_for": {"$anyOf": [COLLECTION]}} in filters
    item = values(by_title(api, "Create checklist item without Latest"))
    assert item["f_business_type"] == COLLECTION
    assert item["f_business_key"].endswith(".id}}")

    existing_detail = by_title(api, "Create existing Checklist upload Details")
    existing_latest = by_title(api, "Refresh existing Checklist Latest")
    new_detail = by_title(api, "Create new Checklist upload Details")
    new_latest = by_title(api, "Refresh new Checklist Latest")
    assert existing_latest["upstreamId"] == existing_detail["id"]
    assert new_latest["upstreamId"] == new_detail["id"]

    succeeded = by_title(
        api, "Mark Expansion AIP Create succeeded + backfill IDs"
    )
    succeeded_values = values(succeeded)
    assert succeeded_values["f_status"] == "succeeded"
    assert "f_application_status" not in succeeded_values
    assert succeeded_values["f_intake_id"].endswith(".id}}")
    assert succeeded_values["f_application_id"].endswith(".id}}")
    assert succeeded["config"]["params"]["filter"] == {
        "$and": [
            {"id": {"$eq": "{{$context.data.id}}"}},
            {"f_status": {"$eq": "processing"}},
        ]
    }


def test_guarded_update_patch_preserves_omissions_and_nested_parts() -> None:
    application = {
        native: f"old:{public}"
        for public, native in AIP_FIELD_MAP.items()
    }
    intake = {
        native: f"old:{public}"
        for public, native in INTAKE_UPDATE_FIELD_MAP.items()
    }
    result = run_js(
        guarded_patch_script(),
        formData={
            "case_summary": {"severity": "2"},
            "part_1": {"name_eng": "Updated Name", "name_chi": None},
            "part_2": {"tentative_area_of_floor_space_expansion": 580.5},
            "part_3": {"checklist": []},
        },
        application=application,
        intake=intake,
    )

    assert set(result["patch"]) == set(AIP_FIELD_MAP.values())
    assert result["patch"]["f_name_eng"] == "Updated Name"
    assert result["patch"]["f_name_chi"] is None
    assert result["patch"]["f_existing_area_of_floor_space_expansion"] == 580.5
    assert result["patch"]["f_title"] == "old:title"
    assert set(result["intake_patch"]) == set(INTAKE_UPDATE_FIELD_MAP.values())
    assert result["intake_patch"]["f_severity"] == "2"
    assert result["intake_patch"]["f_received_date"] == "old:received_date"
    assert result["checklist_replacement_requested"] is True

    without_checklist = run_js(
        guarded_patch_script(),
        formData={"case_summary": {"severity": "1"}},
        application=application,
        intake=intake,
    )
    assert without_checklist["checklist_replacement_requested"] is False


def test_update_is_serial_accepted_only_and_never_changes_home_identity() -> None:
    api = FakeApi()
    build_update_graph(api, 100)

    claim = by_title(api, "Atomically claim submitted Expansion AIP Update row")
    sql = claim["config"]["sql"]
    assert 'parent."f_application_status" = \'Accepted\'' in sql
    assert 'parent."f_status" = \'succeeded\'' in sql
    assert 'parent."f_active_update_id" = staged."f_active_update_id"' in sql
    assert 'active."id" < staged."id"' in sql
    assert 'active."f_status" = \'submitted\'' in sql
    assert 'active."f_status" = \'processing\'' in sql

    parent = by_title(api, "Resolve original Expansion AIP CREATE staging record")
    parent_filters = parent["config"]["params"]["filter"]["$and"]
    assert {"f_api_type": {"$eq": CREATE_API_TYPE}} in parent_filters
    assert {"f_application_type": {"$eq": APPLICATION_TYPE}} in parent_filters
    assert {"f_application_status": {"$eq": "Accepted"}} in parent_filters
    assert {"f_status": {"$eq": "succeeded"}} in parent_filters

    app_update = values(
        by_title(api, "Apply staged Expansion AIP update overlay")
    )
    assert set(app_update) == set(AIP_FIELD_MAP.values())
    assert HOME_FK not in app_update
    assert INTAKE_FK not in app_update
    assert "f_approval_status" not in app_update
    assert all(".patch." in value for value in app_update.values())

    intake_update = values(
        by_title(api, "Apply guarded Expansion AIP Intake update")
    )
    assert set(intake_update) == set(INTAKE_UPDATE_FIELD_MAP.values())
    assert {
        "f_office_cd",
        "fk_intake_source_rch",
        "createdBy",
        "f_subject",
    }.isdisjoint(intake_update)

    preflight = by_title(
        api, "Checklist preflight completed without failure"
    )
    application = by_title(api, "Resolve linked Expansion AIP application")
    project = by_title(api, "Project guarded Expansion AIP update patch")
    apply_intake = by_title(api, "Apply guarded Expansion AIP Intake update")
    apply_application = by_title(
        api, "Apply staged Expansion AIP update overlay"
    )
    assert apply_application["upstreamId"] == apply_intake["id"]

    existing = by_title(api, "Load existing Expansion AIP Checklist items")
    assert existing["upstreamId"] == preflight["id"]
    assert existing["branchIndex"] == 1
    existing_filters = existing["config"]["params"]["filter"]["$and"]
    assert {"f_business_key": {"$eq": ref(application, "id")}} in existing_filters
    assert {"f_business_type": {"$eq": COLLECTION}} in existing_filters
    selected = by_title(api, "Select Expansion AIP Checklist items to reset")
    assert selected["upstreamId"] == existing["id"]
    assert ref(project, "checklist_replacement_requested") in str(
        selected["config"]["arguments"]
    )
    reset_loop = by_title(api, "Reset existing Expansion AIP Checklist Latest")
    assert reset_loop["upstreamId"] == selected["id"]
    reset = by_title(api, "Clear existing Expansion AIP Checklist Latest item")
    assert reset["upstreamId"] == reset_loop["id"]
    assert reset["branchIndex"] == 0
    reset_values = values(reset)
    assert reset_values == {
        "f_is_checked": False,
        "f_lastest_files": None,
        "f_lastest_files_name": None,
        "f_lastest_file_date": None,
    }
    unlink = by_title(api, "Unlink existing Expansion AIP Checklist Latest files")
    assert unlink["upstreamId"] == reset["id"]
    assert unlink["type"] == "sql"
    assert (
        f'DELETE FROM "{CHECKLIST_LATEST_THROUGH}"'
        in unlink["config"]["sql"]
    )
    assert (
        f'"{CHECKLIST_LATEST_FOREIGN_KEY}"=:checklistItemId'
        in unlink["config"]["sql"]
    )
    assert unlink["config"]["unsafeInjection"] is False
    assert apply_intake["upstreamId"] == reset_loop["id"]

    succeeded = by_title(
        api, "Mark Expansion AIP Update succeeded + backfill IDs"
    )
    succeeded_values = values(succeeded)
    assert succeeded_values["f_parent_create_id"] == ref(parent, "id")
    assert succeeded_values["f_status"] == "succeeded"
    assert "f_application_status" not in succeeded_values
    finalizer = by_title(
        api, "Finalize deferred Received after successful Expansion AIP Update"
    )
    assert finalizer["upstreamId"] == succeeded["id"]
    assert '"f_active_update_id"=NULL' in finalizer["config"]["sql"]


def test_update_failure_and_checklist_paths_are_cas_guarded() -> None:
    api = FakeApi()
    build_update_graph(api, 100)

    expected_filter = {
        "$and": [
            {"id": {"$eq": "{{$context.data.id}}"}},
            {"f_status": {"$eq": "processing"}},
        ]
    }
    terminal_updates = [
        row
        for row in api.nodes
        if row["type"] == "update"
        and values(row).get("f_status") in {"failed", "succeeded"}
    ]
    assert terminal_updates
    assert all(
        row["config"]["params"]["filter"] == expected_filter
        for row in terminal_updates
    )

    for title in (
        "Create existing Checklist upload Details",
        "Create new Checklist upload Details",
    ):
        assert by_title(api, title)["config"]["collection"] == (
            "t_document_submitted_for_application_details"
        )
    assert by_title(api, "Refresh existing Checklist Latest")["upstreamId"] == (
        by_title(api, "Create existing Checklist upload Details")["id"]
    )
    assert by_title(api, "Refresh new Checklist Latest")["upstreamId"] == (
        by_title(api, "Create new Checklist upload Details")["id"]
    )

    for title in (
        "Finalize deferred Received after Expansion AIP Checklist preflight failure",
        "Finalize deferred Received after Expansion AIP Checklist commit failure",
        "Finalize deferred Received after Expansion AIP terminal failure 1",
        "Finalize deferred Received after Expansion AIP terminal failure 2",
        "Finalize deferred Received after Expansion AIP terminal failure 3",
    ):
        assert by_title(api, title)["type"] == "sql"
