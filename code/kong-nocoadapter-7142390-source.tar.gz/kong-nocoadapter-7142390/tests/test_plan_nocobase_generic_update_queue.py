"""Offline contract for one 12-family queue parent; no remote API calls."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import plan_nocobase_generic_update_queue as plan  # noqa: E402
from plan_nocobase_shared_create_dispatch import (  # noqa: E402
    PUBLIC_CREATE_FAMILIES,
    SharedCreatePlanError,
)


def test_public_catalogue_is_exactly_v081_create_update_pairs() -> None:
    from app.update_queue_service import PUBLIC_UPDATE_QUEUE_TYPES

    families = plan.PUBLIC_UPDATE_FAMILIES
    assert len(families) == len(PUBLIC_CREATE_FAMILIES) == 12
    assert tuple(item.create for item in families) == PUBLIC_CREATE_FAMILIES
    assert {item.application_type for item in families} == PUBLIC_UPDATE_QUEUE_TYPES
    assert len({item.update_api_type for item in families}) == 12
    assert len({item.update_route for item in families}) == 12
    assert families[0].update_route == "nla_update"
    assert not families[2].requires_intake
    assert all(
        item.requires_intake for item in families if item.name != "licence_renewal"
    )
    assert not {"revoke_licence", "prosecution"} & {
        item.application_type for item in families
    }


def test_trigger_observes_status_and_reservation_release_exact_tuples() -> None:
    config = plan.parent_trigger_config()
    assert config["mode"] == 3
    assert config["collection"] == "t_api_request_staging"
    assert config["changed"] == ["f_status", "f_active_update_id"]
    conditions = config["condition"]["$and"]
    assert conditions[0] == {"f_source_system": {"$eq": "OP"}}
    assert len(conditions[1]["$or"]) == 12
    for arm, family in zip(conditions[1]["$or"], plan.PUBLIC_UPDATE_FAMILIES):
        assert arm["$and"][0] == {
            "f_application_type": {"$eq": family.application_type}
        }
        create, completed, queued, submitted = arm["$and"][1]["$or"]
        assert create["$and"][:3] == [
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_api_type": {"$eq": family.create.api_type}},
            {"f_status": {"$eq": "submitted"}},
        ]
        assert completed["$and"][:3] == [
            {"f_request_event": {"$eq": "CREATE"}},
            {"f_api_type": {"$eq": family.create.api_type}},
            {"f_status": {"$eq": "succeeded"}},
        ]
        for status, child in (("queued", queued), ("submitted", submitted)):
            assert child["$and"] == [
                {"f_request_event": {"$eq": "UPDATE"}},
                {"f_api_type": {"$eq": family.update_api_type}},
                {"f_status": {"$eq": status}},
                {"f_queue_counted": {"$eq": True}},
                {"f_active_update_id": {"$notEmpty": True}},
            ]


def test_fifo_sql_uses_whitelisted_mapping_and_one_exact_parent() -> None:
    sql = plan.generic_fifo_dispatch_sql()
    assert sql.count("WHERE approved.application_type = :applicationType") == 1
    assert "contract.create_api_type" in sql
    assert 'staged."f_api_type" = (SELECT update_api_type FROM contract)' in sql
    assert 'CAST(parent."id" AS text) = CAST(:createId AS text)' in sql
    assert 'staged."f_parent_create_id" = CAST(parent_guard."id" AS text)' in sql
    assert sql.count("FOR UPDATE OF staged SKIP LOCKED") == 1
    assert sql.count("LIMIT 1") == 1
    assert "parent.\"f_status\" = 'succeeded'" in sql
    assert "parent.\"f_application_status\" = 'Accepted'" in sql
    assert 'parent."f_active_update_id" IS NULL' in sql
    for family in plan.PUBLIC_UPDATE_FAMILIES:
        assert (
            f"('{family.application_type}', '{family.create.api_type}', "
            f"'{family.update_api_type}')"
        ) in sql
    assert "revoke_licence" not in sql
    assert "prosecution" not in sql


def test_submitted_claim_has_24_exact_routes_and_reservation_fence() -> None:
    sql = plan.submitted_claim_sql()
    assert sql.count("WHEN (") == 24
    assert sql.count("FOR UPDATE OF staged SKIP LOCKED") == 1
    assert 'staged."id" = :stagingId' in sql
    assert 'parent."f_active_update_id" = staged."f_active_update_id"' in sql
    assert "parent.\"f_application_status\" = 'Accepted'" in sql
    assert 'staged."f_queue_sequence" IS NOT NULL' in sql
    assert 'COALESCE(staged."f_attempt_count", 0) > 0' in sql
    assert "parent.\"f_api_type\" = 'create_licence_renewal'" in sql
    assert "revoke_licence" not in sql
    assert "prosecution" not in sql
    for family in plan.PUBLIC_UPDATE_FAMILIES:
        assert f"THEN '{family.create.route}'" in sql
        assert f"THEN '{family.update_route}'" in sql


def test_parent_has_shared_ingress_and_completion_fifo_pumps() -> None:
    nodes = plan.parent_nodes()
    assert len(nodes) == 61
    assert len({node["key"] for node in nodes}) == len(nodes)
    assert nodes[0]["key"] == "generic_is_create_completion"
    assert nodes[1]["upstream"] == nodes[0]["key"]
    assert nodes[1]["branch"] == 1
    assert nodes[5]["key"] == "generic_is_queued_update"
    assert nodes[5]["upstream"] == nodes[0]["key"]
    assert nodes[5]["branch"] == 0
    assert nodes[10]["key"] == "shared_create_claim"
    assert nodes[10]["upstream"] == nodes[5]["key"]
    assert nodes[10]["branch"] == 0
    updates = [item for item in nodes if item["type"] == "update"]
    assert len(updates) == 26  # two FIFO wakes + 24 route markers
    status_wakes = [
        item
        for item in updates
        if item["config"]["params"]["values"] == {"f_status": "submitted"}
    ]
    assert len(status_wakes) == 2
    assert all(item["config"]["params"]["individualHooks"] is True for item in status_wakes)
    assert all(item["type"] != "subflow" for item in nodes)
    assert set(
        item["config"]["params"]["values"]["f_dispatch_route"]
        for item in updates
        if "f_dispatch_route" in item["config"]["params"]["values"]
    ) == {
        *(family.create.route for family in plan.PUBLIC_UPDATE_FAMILIES),
        *(family.update_route for family in plan.PUBLIC_UPDATE_FAMILIES),
    }


@pytest.mark.parametrize("family", plan.PUBLIC_UPDATE_FAMILIES)
def test_update_child_marker_is_exact_and_not_business_workflow_change(
    family: plan.UpdateFamily,
) -> None:
    child = plan.update_child_trigger_config(family)
    assert child["mode"] == 2
    assert child["changed"] == ["f_dispatch_route"]
    clauses = child["condition"]["$and"]
    assert {"f_api_type": {"$eq": family.update_api_type}} in clauses
    assert {"f_application_type": {"$eq": family.application_type}} in clauses
    assert {"f_dispatch_claim": {"$eq": family.update_route}} in clauses
    assert {"f_dispatch_route": {"$eq": family.update_route}} in clauses
    assert {"f_queue_counted": {"$eq": True}} in clauses


def test_success_pump_must_be_anchored_after_verified_create_terminal() -> None:
    family = plan.PUBLIC_UPDATE_FAMILIES[2]  # LRN has application but no Intake ID
    nodes = plan.create_success_pump(family, "verified_success_terminal")
    assert len(nodes) == 4
    assert nodes[0]["upstream"] == "verified_success_terminal"
    assert nodes[0]["config"]["variables"] == [
        {"name": "createId", "value": "{{$context.data.id}}"},
        {"name": "sourceSystem", "value": "OP"},
        {"name": "applicationType", "value": "licence_renewal"},
    ]
    assert nodes[-1]["config"]["params"]["values"] == {"f_status": "submitted"}
    with pytest.raises(SharedCreatePlanError):
        plan.create_success_pump(family, "")


def test_offline_plan_does_not_authorize_activation() -> None:
    result = plan.validate_plan()
    assert result["writes"] is False
    assert result["activation"] is False
    assert result["family_count"] == 12
    assert result["parent_event_tuple_count"] == 48
    assert result["outer_or_arms"] == 12
    assert "unverified" in result["trigger_or_limit"]
