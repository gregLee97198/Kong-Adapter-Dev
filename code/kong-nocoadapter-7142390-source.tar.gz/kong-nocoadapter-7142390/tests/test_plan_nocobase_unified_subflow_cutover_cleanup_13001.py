"""Offline tests for exact 13001 unified-subflow cutover guardrails."""

from __future__ import annotations

import copy
import json
import pathlib
import sys

import pytest


SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import plan_nocobase_unified_subflow_cutover_cleanup_13001 as cleanup  # noqa: E402
import plan_nocobase_unified_subflow_dispatch_13001 as topology  # noqa: E402


def _evidence() -> dict:
    return {
        "environment": "13001",
        "architecture": topology.ARCHITECTURE,
        "sentinel": {
            "passed": True,
            "parent_execution_delta": 1,
            "child_execution_delta": 1,
            "cleanup_confirmed": True,
        },
        "ingress": {
            "id": 9001,
            "key": "verified-ingress-key",
            "title": "Verified unified ingress",
            "type": "collection",
            "router_type": "multi-conditions",
            "business_branch_count": 12,
            "collection_event_workflow_count": 1,
            "serial_condition_chain": False,
            "marker_write": False,
            "category": topology.API_SOURCE_CATEGORY_TITLE,
        },
        "children": [
            {
                "id": 9100 + index,
                "key": f"verified-child-{index}",
                "title": f"Verified {business.name} child",
                "business": business.name,
                "type": "custom-action",
                "router_type": "multi-conditions",
                "event_branches": ["CREATE", "UPDATE"],
                "marker_write": False,
                "category": topology.API_SOURCE_CATEGORY_TITLE,
                "executed": 0,
            }
            for index, business in enumerate(topology.BUSINESSES)
        ],
    }


def _snapshot() -> dict:
    rows = []
    for target in (*cleanup.PUBLIC_LEGACY, *cleanup.PRESERVE):
        rows.append({
            "id": target.id,
            "key": target.key,
            "title": target.title,
            "enabled": True,
            "type": "collection",
        })
    return {
        "environment": "13001",
        "workflows": rows,
        "executions": {str(target.id): {"running": 0, "queued": 0}
                       for target in cleanup.PUBLIC_LEGACY},
    }


def test_static_catalogue_is_exact_and_preserves_notice():
    plan = cleanup.static_plan()

    assert plan["writes_remote"] is False
    assert len(plan["default_legacy_retirement"]) == 25
    assert len(plan["optional_unpublished_retirement"]) == 4
    assert plan["preserve_exact"] == [
        {
            "id": 390051643523072,
            "key": "786j92ko3yp",
            "title": "API Notice — NLA Received with Existing P Number v1",
            "business": "notice",
            "role": "notice_listener",
            "disposition": "preserve",
        }
    ]
    assert plan["topology_contract"]["ingress_router_type"] == "multi-conditions"
    assert plan["topology_contract"]["ingress_business_branch_count"] == 12


def test_review_emits_no_write_operation_order_for_exact_evidence():
    result = cleanup.review(_snapshot(), _evidence())

    assert result["writes_remote"] is False
    assert result["ready_for_manual_cutover"] is True
    assert result["operation_order"][0]["action"] == "quiesce_public_create_update_admission"
    assert result["operation_order"][1]["action"] == "disable_exact_workflows"
    assert len(result["operation_order"][1]["ids"]) == 25
    assert result["preserved_ids"] == [390051643523072]


def test_review_rejects_serial_ingress_even_when_branch_count_matches():
    evidence = _evidence()
    evidence["ingress"]["serial_condition_chain"] = True

    with pytest.raises(cleanup.PlanError, match="direct twelve-way multi-branch"):
        cleanup.review(_snapshot(), evidence)


def test_review_rejects_child_marker_write_and_allows_a_legacy_worker_already_disabled():
    evidence = _evidence()
    evidence["children"][0]["marker_write"] = True
    with pytest.raises(cleanup.PlanError, match="forbidden marker routing"):
        cleanup.review(_snapshot(), evidence)

    snapshot = _snapshot()
    # This reflects the known guarded LRN Update workflow, which was already
    # disabled before the unified cutover.  The review must still permit the
    # exact no-op disable/readback in its cutover operation order.
    for row in snapshot["workflows"]:
        if row["id"] == 392475375632384:
            row["enabled"] = False
    assert cleanup.review(snapshot, _evidence())["ready_for_manual_cutover"] is True


def test_review_rejects_identity_drift_or_reappeared_deleted_candidate():
    snapshot = _snapshot()
    drift = copy.deepcopy(snapshot)
    drift["workflows"][0]["title"] = "wrong title"
    with pytest.raises(cleanup.PlanError, match="identity drifted"):
        cleanup.review(drift, _evidence())

    reappeared = _snapshot()
    reappeared["workflows"].append({
        "id": 392927045615616, "key": "unexpected", "title": "unexpected", "enabled": False,
    })
    with pytest.raises(cleanup.PlanError, match="reappeared"):
        cleanup.review(reappeared, _evidence())


def _executor_validation(*, runtime_ready: bool = True) -> dict:
    evidence = _evidence()
    prerequisites = {
        "created_by_id": "passed" if runtime_ready else "not_yet_tested",
        "op_role_mapping": "passed",
        "direct_create_submitted_trigger": "passed",
    }
    return {
        "writes_remote": False,
        "environment": "13001",
        "migration_id": "subflow-test-validation",
        "manifest": "/tmp/subflow-test-validation/manifest.json",
        "topology_sha256": topology._topology_digest(),
        "source_snapshot_sha256": "c" * 64,
        "validated_disabled": True,
        "cutover_not_implemented": True,
        "sentinel": {
            "state": "passed",
            "evidence_sha256": "a" * 64,
            "parent_execution_delta": 1,
            "child_execution_delta": 1,
            "child_enable_state_at_cutover": "enabled",
        },
        "runtime_acceptance_prerequisites": prerequisites,
        "runtime_acceptance_passed": runtime_ready,
        "parent": {
            **evidence["ingress"],
            "enabled": False,
            "executed": 0,
        },
        "children": {
            item["business"]: {**item, "enabled": False}
            for item in evidence["children"]
        },
    }


def _runtime_record(validation: dict) -> dict:
    return {
        "writes_remote": False,
        "migration_id": validation.get("migration_id"),
        "manifest": validation.get("manifest"),
        "topology_sha256": validation.get("topology_sha256"),
        "source_snapshot_sha256": validation.get("source_snapshot_sha256"),
        "runtime_acceptance_prerequisites": {
            "created_by_id": "passed",
            "op_role_mapping": "passed",
            "direct_create_submitted_trigger": "passed",
        },
        "runtime_evidence": {
            "state": "passed",
            "evidence_sha256": "b" * 64,
            "outcomes": {
                "created_by_id": {"passed": True, "observation": "createdById retained"},
                "op_role_mapping": {"passed": True, "observation": "OP role executed"},
                "direct_create_submitted_trigger": {"passed": True, "observation": "direct CREATE submitted"},
            },
        },
    }


def _post_cutover_snapshot(evidence: dict) -> dict:
    snapshot = _snapshot()
    for row in snapshot["workflows"]:
        if row["id"] in {target.id for target in cleanup.PUBLIC_LEGACY}:
            row["enabled"] = False
    snapshot["workflows"].append({
        "id": evidence["ingress"]["id"],
        "key": evidence["ingress"]["key"], "title": evidence["ingress"]["title"],
        "type": "collection", "enabled": True,
    })
    snapshot["executions"][str(evidence["ingress"]["id"])] = {"running": 0, "queued": 0}
    for child in evidence["children"]:
        snapshot["workflows"].append({
            "id": child["id"],
            "key": child["key"], "title": child["title"],
            "type": "custom-action", "enabled": True,
        })
        snapshot["executions"][str(child["id"])] = {"running": 0, "queued": 0}
    return snapshot


def test_executor_validation_normalizer_splits_cutover_from_post_cutover_retirement():
    pending = _executor_validation(runtime_ready=False)
    normalized = cleanup.normalize_executor_validation(pending)
    result = cleanup.review_executor_validation(_snapshot(), pending)
    assert normalized["ingress"]["router_type"] == "multi-conditions"
    assert result["ready_for_manual_cutover"] is True
    assert all("delete" not in operation["action"] for operation in result["operation_order"])

    with pytest.raises(cleanup.PlanError, match="runtime acceptance evidence is required"):
        cleanup.review_executor_validation(
            _post_cutover_snapshot(normalized), pending, phase="retirement"
        )

    ready = _executor_validation(runtime_ready=False)
    # The actual builder's pre-cutover validation includes these fields.  Bind
    # the local post-cutover record to the exact same preparation identity.
    ready["migration_id"] = "subflow-test-ready"
    ready["manifest"] = "/tmp/subflow-test-ready/manifest.json"
    runtime = _runtime_record(ready)
    retirement_evidence = cleanup.normalize_executor_validation(
        ready, runtime_record=runtime, require_runtime_acceptance=True
    )
    retired = cleanup.review_executor_validation(
        _post_cutover_snapshot(retirement_evidence),
        ready,
        phase="retirement",
        runtime_record=runtime,
    )
    assert retired["ready_for_manual_retirement"] is True
    assert retired["operation_order"][1]["action"] == "delete_exact_disabled_legacy"


def test_executor_runtime_record_must_match_the_frozen_topology_and_source_digest():
    validation = _executor_validation(runtime_ready=False)
    runtime = _runtime_record(validation)
    runtime["topology_sha256"] = "0" * 64

    with pytest.raises(cleanup.PlanError, match="topology_sha256 does not match"):
        cleanup.normalize_executor_validation(
            validation, runtime_record=runtime, require_runtime_acceptance=True
        )

    runtime = _runtime_record(validation)
    runtime["runtime_evidence"]["outcomes"]["created_by_id"]["observation"] = ""
    with pytest.raises(cleanup.PlanError, match="outcome is incomplete"):
        cleanup.normalize_executor_validation(
            validation, runtime_record=runtime, require_runtime_acceptance=True
        )


def test_cli_never_allows_generic_candidate_evidence_to_authorize_retirement(tmp_path, capsys):
    snapshot_path = tmp_path / "snapshot.json"
    evidence_path = tmp_path / "evidence.json"
    snapshot_path.write_text(json.dumps(_snapshot()), encoding="utf-8")
    evidence = _evidence()
    evidence["runtime_acceptance_passed"] = True
    evidence_path.write_text(json.dumps(evidence), encoding="utf-8")

    assert cleanup.main(
        [
            "--review",
            "--phase",
            "retirement",
            "--snapshot",
            str(snapshot_path),
            "--candidate-evidence",
            str(evidence_path),
        ]
    ) == 1
    assert "requires --executor-validation and --runtime-record" in capsys.readouterr().err

