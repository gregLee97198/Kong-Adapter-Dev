"""Offline guardrails for the single API-Staging subflow topology.

These tests deliberately never construct a NocoBase client or contact 13001.
They prevent the reviewed design from silently regressing into the former
serial marker/collection-worker topology while a remote writer is built.
"""

from __future__ import annotations

import copy
import json
import os
import pathlib
import sys
import urllib.parse


SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import plan_nocobase_unified_subflow_dispatch_13001 as plan  # noqa: E402
import probe_nocobase_custom_action_subflow_13001 as probe  # noqa: E402


class _FakeFlowApi:
    """Minimal in-memory flow_nodes API; no HTTP is involved."""

    def __init__(self, workflow: dict, *, timeout_after_create: bool = False) -> None:
        self.workflow = workflow
        self.timeout_after_create = timeout_after_create
        self.created = 0
        self.updated = 0

    def get_workflow(self, workflow_id: int) -> dict:
        assert workflow_id == self.workflow["id"]
        return copy.deepcopy(self.workflow)

    def create_node(self, values: dict) -> dict:
        assert values["workflowId"] == self.workflow["id"]
        self.created += 1
        row = {
            "id": 900000 + self.created,
            "key": f"candidate{self.created}",
            "title": values["title"],
            "type": values["type"],
            "config": copy.deepcopy(values["config"]),
            "upstreamId": None,
            "downstreamId": None,
            "branchIndex": None,
        }
        self.workflow["nodes"].append(row)
        if self.timeout_after_create:
            raise plan.ApiError("simulated timeout after remote commit")
        return copy.deepcopy(row)

    def update_node(self, node_id: int, values: dict) -> None:
        self.updated += 1
        for row in self.workflow["nodes"]:
            if row["id"] == node_id:
                row.update(copy.deepcopy(values))
                return
        raise AssertionError(node_id)

    def request(self, method: str, path: str, values: dict | None = None):
        """Only the category GETs used by candidate readback are supported."""
        assert method == "GET"
        assert values is None
        if path.startswith("/api/workflowCategories:list?"):
            return [{"id": 4, "title": "API Suorce"}]
        if path.startswith("/api/workflows:get?"):
            return {"id": self.workflow["id"], "categories": [{"id": 4}]}
        raise AssertionError(path)


def _patch_candidate() -> tuple[dict, dict]:
    workflow = {
        "id": 444,
        "key": "patch-child",
        "title": "offline patch candidate",
        "type": "custom-action",
        "sync": True,
        "enabled": False,
        "config": plan.child_config(),
        "nodes": [
            {
                "id": 445,
                "key": "patch-node",
                "title": "offline node",
                "type": "update",
                "config": {"before": True},
                "upstreamId": None,
                "downstreamId": None,
                "branchIndex": None,
            }
        ],
    }
    return workflow, copy.deepcopy(workflow["nodes"][0])


def test_patch_node_retries_only_after_readback_proves_the_node_unchanged():
    workflow, node = _patch_candidate()
    api = _FakeFlowApi(workflow)
    attempts = {"count": 0}

    def timeout_before_commit(node_id: int, values: dict) -> None:
        attempts["count"] += 1
        if attempts["count"] < plan.PATCH_MAX_ATTEMPTS:
            raise plan.ApiError("simulated transport timeout before commit")
        for row in api.workflow["nodes"]:
            if row["id"] == node_id:
                row.update(copy.deepcopy(values))
                return
        raise AssertionError(node_id)

    api.update_node = timeout_before_commit  # type: ignore[method-assign]
    checkpoints: list[tuple[str, dict]] = []
    plan._patch_node(
        api,
        workflow["id"],
        node,
        {"config": {"after": True}},
        checkpoint=lambda action, details: checkpoints.append((action, dict(details))),
        reason="offline-retry",
    )

    assert attempts["count"] == plan.PATCH_MAX_ATTEMPTS
    assert node["config"] == {"after": True}
    assert [action for action, _ in checkpoints].count(
        "node_patch_retry_after_unchanged_timeout"
    ) == plan.PATCH_MAX_ATTEMPTS - 1
    assert checkpoints[-1][0] == "node_patched"


def test_patch_node_reconciles_when_timeout_happened_after_commit():
    workflow, node = _patch_candidate()
    api = _FakeFlowApi(workflow)
    attempts = {"count": 0}

    def timeout_after_commit(node_id: int, values: dict) -> None:
        attempts["count"] += 1
        for row in api.workflow["nodes"]:
            if row["id"] == node_id:
                row.update(copy.deepcopy(values))
                break
        raise plan.ApiError("simulated response loss after commit")

    api.update_node = timeout_after_commit  # type: ignore[method-assign]
    checkpoints: list[tuple[str, dict]] = []
    plan._patch_node(
        api,
        workflow["id"],
        node,
        {"config": {"after": True}},
        checkpoint=lambda action, details: checkpoints.append((action, dict(details))),
        reason="offline-reconcile",
    )

    assert attempts["count"] == 1
    assert node["config"] == {"after": True}
    assert checkpoints[-1][0] == "node_patch_reconciled_after_timeout"


def test_patch_node_refuses_retry_when_the_exact_patch_fields_diverge():
    workflow, node = _patch_candidate()
    api = _FakeFlowApi(workflow)
    attempts = {"count": 0}

    def timeout_with_conflicting_commit(node_id: int, values: dict) -> None:
        attempts["count"] += 1
        for row in api.workflow["nodes"]:
            if row["id"] == node_id:
                row["config"] = {"concurrent": True}
                break
        raise plan.ApiError("simulated conflicting mutation")

    api.update_node = timeout_with_conflicting_commit  # type: ignore[method-assign]
    try:
        plan._patch_node(
            api,
            workflow["id"],
            node,
            {"config": {"after": True}},
            checkpoint=lambda *_: None,
            reason="offline-divergence",
        )
    except plan.PreparationError as exc:
        assert "diverged" in str(exc)
    else:
        raise AssertionError("divergent node state was retried")
    assert attempts["count"] == 1


def test_static_plan_has_one_event_entry_and_direct_business_branches():
    result = plan.static_plan()

    assert result["writes_remote"] is False
    assert result["collection_event_workflow_count"] == 1
    assert result["candidate_collection_parent_count"] == 1
    assert result["collection_event_workflow_count_scope"].startswith("candidate topology")
    assert result["custom_action_child_count"] == 12
    assert len(result["ingress"]["nodes"]) == 13

    router, *subflows = result["ingress"]["nodes"]
    assert router["type"] == "multi-conditions"
    assert len(router["config"]["conditions"]) == 12
    assert [node["type"] for node in subflows] == ["subflow"] * 12
    assert [node["branch"] for node in subflows] == list(range(1, 13))
    assert all(
        node["config"]["context"]
        == {
            "data": "{{$context.data}}",
            "userId": "{{$context.data.createdById}}",
            "roleName": None,
        }
        for node in subflows
    )
    assert set(result["runtime_acceptance_prerequisites"]) >= set(
        plan.RUNTIME_ACCEPTANCE_KEYS
    )


def test_every_child_has_one_custom_action_root_and_create_update_branches():
    result = plan.static_plan()

    for child in result["children"]:
        assert child["type"] == "custom-action"
        assert child["sync"] is True
        assert child["config"] == {
            "type": 1,
            "collection": "t_api_request_staging",
            "appends": [],
        }
        root = child["graph"]["root"]
        assert root["type"] == "multi-conditions"
        assert [branch["title"] for branch in root["config"]["conditions"]] == [
            "CREATE",
            "UPDATE",
        ]
        assert child["graph"]["create_branch_index"] == 1
        assert child["graph"]["update_branch_index"] == 2


def test_plan_explicitly_excludes_marker_workers_and_serial_conditions():
    result = plan.static_plan()
    prohibited = " ".join(result["prohibited"])

    assert "f_dispatch_route" in prohibited
    assert "per-business collection-event worker" in prohibited
    assert "serial chain" in prohibited


def test_sentinel_is_no_write_by_default_and_uses_enabled_custom_action_child():
    result = probe.dry_run()

    assert result["writes_remote"] is False
    assert result["parent"]["type"] == "collection"
    assert result["parent"]["nodes"][0]["type"] == "multi-conditions"
    assert result["parent"]["nodes"][1]["type"] == "subflow"
    assert result["parent"]["nodes"][1]["branchIndex"] == 1
    assert result["child"] == {
        "type": "custom-action",
        "sync": True,
        "enabled_during_execution": True,
        "config": {"type": 1, "collection": "t_api_request_staging", "appends": []},
        "node": {"type": "update", "config": probe.child_update_config("<uuid-v4>")},
    }
    assert "finally" in result["cleanup"]


class _ExecutionListApi:
    """Offline API fixture for durable execution-list reads."""

    def __init__(self, pages: dict[int, list[dict]]) -> None:
        self.pages = pages
        self.paths: list[str] = []

    def request(self, method: str, path: str, values=None):
        assert method == "GET"
        assert values is None
        self.paths.append(path)
        query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
        return copy.deepcopy(self.pages[int(query["page"][0])])


def test_sentinel_uses_durable_execution_rows_not_workflow_executed_counter():
    api = _ExecutionListApi(
        {
            1: [{"id": 101}, {"id": 102}],
        }
    )

    assert probe._execution_snapshot(api, 77) == {
        101: {"id": 101},
        102: {"id": 102},
    }
    assert all("/api/executions:list?" in path for path in api.paths)
    assert all("filter%5BworkflowId%5D=77" in path for path in api.paths)


class _SentinelRowApi:
    def __init__(self, marker: str) -> None:
        self.marker = marker

    def request(self, method: str, path: str, values=None):
        assert method == "GET"
        assert values is None
        assert "/api/t_api_request_staging:get?" in path
        return {
            "id": 501,
            "f_error_message": f"custom-action-subflow-sentinel:{self.marker}",
        }


def _matching_execution(identifier: int, *, parent_execution_id=None) -> dict:
    return {
        "id": identifier,
        "status": 1,
        "parentExecutionId": parent_execution_id,
        "context": {
            "data": {
                "id": 501,
                "f_source_system": probe.SENTINEL_SOURCE,
                "f_request_event": probe.SENTINEL_EVENT,
                "f_api_type": probe.SENTINEL_API_TYPE,
                "f_client_request_id": "marker-1",
                "f_status": probe.TRIGGER_STATUS,
            }
        },
    }


def test_sentinel_requires_one_linked_successful_parent_and_child(monkeypatch):
    parent = _matching_execution(701)
    child = _matching_execution(702, parent_execution_id=701)

    def snapshot(_api, workflow_id):
        return {701: parent} if workflow_id == 11 else {702: child}

    monkeypatch.setattr(probe, "_execution_snapshot", snapshot)
    result = probe._wait_for_marker(
        object(),
        _SentinelRowApi("marker-1"),
        staging_id=501,
        parent_id=11,
        child_id=12,
        before_parent={},
        before_child={},
        marker="marker-1",
        expected_marker="custom-action-subflow-sentinel:marker-1",
        timeout_seconds=1,
    )

    assert result == {
        "parent_execution_delta": 1,
        "child_execution_delta": 1,
        "row_marker": "custom-action-subflow-sentinel:marker-1",
    }


def test_sentinel_does_not_accept_a_correct_marker_when_parent_duplicated(monkeypatch):
    parent_one = _matching_execution(701)
    parent_two = _matching_execution(703)
    child = _matching_execution(702, parent_execution_id=701)

    def snapshot(_api, workflow_id):
        return {701: parent_one, 703: parent_two} if workflow_id == 11 else {702: child}

    clock = iter((0.0, 0.0, 2.0))
    monkeypatch.setattr(probe, "_execution_snapshot", snapshot)
    monkeypatch.setattr(probe.time, "monotonic", lambda: next(clock))
    monkeypatch.setattr(probe.time, "sleep", lambda _seconds: None)

    try:
        probe._wait_for_marker(
            object(),
            _SentinelRowApi("marker-1"),
            staging_id=501,
            parent_id=11,
            child_id=12,
            before_parent={},
            before_child={},
            marker="marker-1",
            expected_marker="custom-action-subflow-sentinel:marker-1",
            timeout_seconds=1,
        )
    except probe.ApiError as exc:
        assert "did not complete exactly once" in str(exc)
        assert "parent_new_executions" in str(exc)
        assert '"id": 701' in str(exc)
        assert '"id": 703' in str(exc)
    else:
        raise AssertionError("duplicate parent execution was accepted")


def _frozen_manifest_for_one_business() -> tuple[dict, plan.Business]:
    """A local-only source fixture for clone-shape tests.

    Both branches use a valid graph fixture, but their workflow identities are
    adjusted to the catalogue values because this test never contacts 13001.
    """
    business = plan.BUSINESSES[0]
    update = plan.legacy.prepared_update_graph(business)
    create = copy.deepcopy(update)
    create["id"] = business.create_source_id
    create["key"] = business.create_source_key
    return {
        "source_snapshot": {
            "create": {business.name: create},
            "update": {business.name: update},
        }
    }, business


def test_child_graph_has_one_multi_condition_root_and_direct_create_update_edges():
    manifest, business = _frozen_manifest_for_one_business()
    specs = plan._child_specs(manifest, business)
    root = specs[0]

    assert root["identity"] == "ROUTER"
    assert root["type"] == "multi-conditions"
    assert [item["title"] for item in root["initial_config"]["conditions"]] == [
        "CREATE",
        "UPDATE",
    ]
    create_roots = [
        item for item in specs if item["prefix"] == "CREATE" and item["upstream"] == "ROUTER"
    ]
    update_roots = [
        item for item in specs if item["prefix"] == "UPDATE" and item["upstream"] == "ROUTER"
    ]
    assert len(create_roots) == 1
    assert len(update_roots) == 1
    assert create_roots[0]["branch"] == 1
    assert update_roots[0]["branch"] == 2


def test_preparation_manifest_records_unknown_runtime_state_without_sentinel(tmp_path, monkeypatch):
    monkeypatch.setattr(plan, "PREPARED_ROOT", tmp_path)
    path, manifest = plan._manifest("subflow-test-001")

    assert path.is_file()
    assert manifest["sentinel"]["state"] == "not_recorded"
    assert manifest["sentinel"]["child_enable_state_at_cutover"] == "unknown"
    assert manifest["runtime_acceptance_prerequisites"] == {
        "created_by_id": "not_yet_tested",
        "op_role_mapping": "not_yet_tested",
        "direct_create_submitted_trigger": "not_yet_tested",
    }
    assert plan._cutover_prerequisites_passed(manifest) is False
    assert os.stat(path).st_mode & 0o777 == 0o600


def test_successful_sentinel_evidence_is_checked_before_it_is_recorded(tmp_path):
    evidence = tmp_path / "sentinel.json"
    evidence.write_text(
        json.dumps(
            {
                "probe": "passed",
                "child_enabled": True,
                "parent_execution_delta": 1,
                "child_execution_delta": 1,
                "row_marker": "custom-action-subflow-sentinel:example",
            }
        ),
        encoding="utf-8",
    )
    state = plan._valid_sentinel_evidence(evidence)
    assert state["state"] == "passed"
    assert state["child_enable_state_at_cutover"] == "enabled"


def test_existing_manifest_accepts_its_recorded_sentinel_when_validation_requires_it(
    tmp_path, monkeypatch
):
    """A second validation must use already sealed evidence, not require its path again."""
    monkeypatch.setattr(plan, "PREPARED_ROOT", tmp_path)
    migration_id = "subflow-recorded-sentinel"
    path, manifest = plan._manifest(migration_id)
    manifest["sentinel"] = {
        "state": "passed",
        "child_enable_state_at_cutover": "enabled",
        "cutover_blocked": False,
    }
    plan._atomic_json(path, manifest)

    _path, reopened = plan._existing_manifest(migration_id, require_evidence=True)

    assert reopened["sentinel"]["state"] == "passed"


def test_runtime_evidence_is_local_only_and_bound_to_frozen_sources(tmp_path, monkeypatch):
    """A cutover guard can consume evidence without an editable manifest hack."""
    monkeypatch.setattr(plan, "PREPARED_ROOT", tmp_path / "preparations")
    migration_id = "subflow-runtime-evidence"
    manifest_path, manifest = plan._manifest(migration_id)
    frozen_sources = {"create": {"nla": {"id": 1}}, "update": {"nla": {"id": 2}}}
    manifest["source_snapshot"] = frozen_sources
    manifest["source_snapshot_sha256"] = plan.digest(frozen_sources)
    manifest["sentinel"] = {
        "state": "passed",
        "child_enable_state_at_cutover": "enabled",
        "cutover_blocked": False,
    }
    plan._atomic_json(manifest_path, manifest)

    evidence = tmp_path / "runtime-evidence.json"
    evidence.write_text(
        json.dumps(
            {
                "format": plan.RUNTIME_EVIDENCE_FORMAT,
                "migration_id": migration_id,
                "topology_sha256": manifest["topology_sha256"],
                "source_snapshot_sha256": manifest["source_snapshot_sha256"],
                "outcomes": {
                    "created_by_id": {
                        "passed": True,
                        "observation": "Controlled OP row retained createdById.",
                    },
                    "op_role_mapping": {
                        "passed": True,
                        "observation": "OP-mapped role executed the custom-action child.",
                    },
                    "direct_create_submitted_trigger": {
                        "passed": True,
                        "observation": "One submitted CREATE took one direct parent-to-child path.",
                    },
                },
            }
        ),
        encoding="utf-8",
    )

    result = plan.record_runtime_evidence(migration_id, evidence)

    assert result["writes_remote"] is False
    assert result["writes_local"] is True
    assert result["topology_sha256"] == manifest["topology_sha256"]
    assert result["source_snapshot_sha256"] == manifest["source_snapshot_sha256"]
    assert result["runtime_acceptance_prerequisites"] == {
        key: "passed" for key in plan.RUNTIME_ACCEPTANCE_KEYS
    }
    persisted = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert plan._runtime_acceptance_passed(persisted) is True
    assert plan._cutover_prerequisites_passed(persisted) is True
    assert persisted["runtime_evidence"]["state"] == "passed"


def test_runtime_evidence_rejects_a_manifest_digest_mismatch(tmp_path, monkeypatch):
    monkeypatch.setattr(plan, "PREPARED_ROOT", tmp_path / "preparations")
    migration_id = "subflow-runtime-mismatch"
    manifest_path, manifest = plan._manifest(migration_id)
    frozen_sources = {"create": {}, "update": {}}
    manifest["source_snapshot"] = frozen_sources
    manifest["source_snapshot_sha256"] = plan.digest(frozen_sources)
    manifest["sentinel"] = {
        "state": "passed",
        "child_enable_state_at_cutover": "enabled",
        "cutover_blocked": False,
    }
    plan._atomic_json(manifest_path, manifest)
    evidence = tmp_path / "runtime-evidence-mismatch.json"
    evidence.write_text(
        json.dumps(
            {
                "format": plan.RUNTIME_EVIDENCE_FORMAT,
                "migration_id": migration_id,
                "topology_sha256": "not-the-reviewed-topology",
                "source_snapshot_sha256": manifest["source_snapshot_sha256"],
                "outcomes": {
                    key: {"passed": True, "observation": key}
                    for key in plan.RUNTIME_ACCEPTANCE_KEYS
                },
            }
        ),
        encoding="utf-8",
    )

    try:
        plan.record_runtime_evidence(migration_id, evidence)
    except plan.PreparationError as exc:
        assert "not bound" in str(exc)
    else:
        raise AssertionError("mismatched runtime evidence was accepted")


def test_runtime_evidence_requires_a_successful_sentinel_first(tmp_path, monkeypatch):
    monkeypatch.setattr(plan, "PREPARED_ROOT", tmp_path / "preparations")
    migration_id = "subflow-runtime-needs-sentinel"
    manifest_path, manifest = plan._manifest(migration_id)
    frozen_sources = {"create": {}, "update": {}}
    manifest["source_snapshot"] = frozen_sources
    manifest["source_snapshot_sha256"] = plan.digest(frozen_sources)
    plan._atomic_json(manifest_path, manifest)
    evidence = tmp_path / "runtime-evidence-needs-sentinel.json"
    evidence.write_text(
        json.dumps(
            {
                "format": plan.RUNTIME_EVIDENCE_FORMAT,
                "migration_id": migration_id,
                "topology_sha256": manifest["topology_sha256"],
                "source_snapshot_sha256": manifest["source_snapshot_sha256"],
                "outcomes": {
                    key: {"passed": True, "observation": key}
                    for key in plan.RUNTIME_ACCEPTANCE_KEYS
                },
            }
        ),
        encoding="utf-8",
    )

    try:
        plan.record_runtime_evidence(migration_id, evidence)
    except plan.PreparationError as exc:
        assert "sentinel" in str(exc)
    else:
        raise AssertionError("runtime evidence was recorded without a sentinel proof")


def test_runtime_evidence_cli_is_explicitly_local_only(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(plan, "PREPARED_ROOT", tmp_path / "preparations")
    migration_id = "subflow-runtime-cli"
    manifest_path, manifest = plan._manifest(migration_id)
    frozen_sources = {"create": {}, "update": {}}
    manifest["source_snapshot"] = frozen_sources
    manifest["source_snapshot_sha256"] = plan.digest(frozen_sources)
    manifest["sentinel"] = {
        "state": "passed",
        "child_enable_state_at_cutover": "enabled",
        "cutover_blocked": False,
    }
    plan._atomic_json(manifest_path, manifest)
    evidence = tmp_path / "runtime-evidence-cli.json"
    evidence.write_text(
        json.dumps(
            {
                "format": plan.RUNTIME_EVIDENCE_FORMAT,
                "migration_id": migration_id,
                "topology_sha256": manifest["topology_sha256"],
                "source_snapshot_sha256": manifest["source_snapshot_sha256"],
                "outcomes": {
                    key: {"passed": True, "observation": f"verified {key}"}
                    for key in plan.RUNTIME_ACCEPTANCE_KEYS
                },
            }
        ),
        encoding="utf-8",
    )

    def _must_not_contact_remote():
        raise AssertionError("runtime evidence action attempted remote access")

    monkeypatch.setattr(plan, "_require_api", _must_not_contact_remote)
    assert plan.main(
        [
            "--record-runtime-evidence",
            str(evidence),
            "--migration-id",
            migration_id,
        ]
    ) == 0
    response = json.loads(capsys.readouterr().out)
    assert response["writes_remote"] is False
    assert response["writes_local"] is True
    assert response["topology_sha256"] == manifest["topology_sha256"]
    assert response["source_snapshot_sha256"] == manifest["source_snapshot_sha256"]


def test_validate_cli_can_seal_non_overwritable_private_evidence(tmp_path, monkeypatch, capsys):
    migration_id = "subflow-validate-artifact"
    result = {
        "writes_remote": False,
        "environment": "13001",
        "migration_id": migration_id,
        "validated_disabled": True,
        "cutover_not_implemented": True,
    }
    output = tmp_path / "validated-disabled.json"
    monkeypatch.setattr(
        plan,
        "validate_preparation",
        lambda observed, *, require_sentinel: (
            result
            if observed == migration_id and require_sentinel is True
            else (_ for _ in ()).throw(AssertionError("unexpected validation arguments"))
        ),
    )

    assert plan.main(
        [
            "--validate",
            "--migration-id",
            migration_id,
            "--require-sentinel",
            "--write-validation",
            str(output),
        ]
    ) == 0
    response = json.loads(capsys.readouterr().out)
    assert response["local_validation_path"] == str(output.resolve())
    assert json.loads(output.read_text(encoding="utf-8")) == result
    assert os.stat(output).st_mode & 0o777 == 0o600

    assert plan.main(
        [
            "--validate",
            "--migration-id",
            migration_id,
            "--require-sentinel",
            "--write-validation",
            str(output),
        ]
    ) == 1
    assert "refusing to overwrite validation evidence" in capsys.readouterr().err


def test_parent_reconcile_creates_one_router_and_twelve_direct_subflows():
    migration_id = "subflow-test-parent"
    candidate = {
        "id": 100,
        "key": "parentkey",
        "title": plan.ingress_title(migration_id),
        "type": "collection",
        "sync": False,
        "enabled": False,
        "config": plan.ingress_config(),
        "nodes": [],
    }
    child_keys = {business.name: f"child-{index}" for index, business in enumerate(plan.BUSINESSES, 1)}
    api = _FakeFlowApi(candidate)

    result = plan._reconcile_parent(
        api,
        candidate,
        child_keys=child_keys,
        checkpoint=lambda *_: None,
    )

    assert result["node_count"] == 13
    assert result["type"] == "collection"
    assert result["router_type"] == "multi-conditions"
    assert result["business_branch_count"] == 12
    assert result["collection_event_workflow_count"] == 1
    assert result["serial_condition_chain"] is False
    assert result["marker_write"] is False
    router = next(row for row in api.workflow["nodes"] if row["type"] == "multi-conditions")
    subflows = [row for row in api.workflow["nodes"] if row["type"] == "subflow"]
    assert len(subflows) == 12
    assert [row["branchIndex"] for row in subflows] == list(range(1, 13))
    assert all(row["upstreamId"] == router["id"] for row in subflows)
    assert all("f_dispatch_route" not in json.dumps(row["config"]) for row in api.workflow["nodes"])


def test_child_reconcile_is_resumable_after_timeout_and_keeps_create_update_in_one_child():
    manifest, business = _frozen_manifest_for_one_business()
    manifest["sentinel"] = {"child_enable_state_at_cutover": "unknown"}
    migration_id = "subflow-test-child"
    candidate = {
        "id": 101,
        "key": "childkey",
        "title": plan.child_title(business, migration_id),
        "type": "custom-action",
        "sync": True,
        "enabled": False,
        "config": plan.child_config(),
        "nodes": [],
    }
    # First creation commits but the client loses the response.  Exact node
    # title reconciliation means no duplicate POST is made for that node.
    api = _FakeFlowApi(candidate, timeout_after_create=True)
    specs = plan._child_specs(manifest, business)
    nodes: dict[str, dict] = {}
    first = specs[0]
    recovered = plan._ensure_node(
        api,
        candidate["id"],
        nodes,
        identity=first["identity"],
        title=first["title"],
        node_type=first["type"],
        config=first["initial_config"],
        checkpoint=lambda *_: None,
    )
    assert recovered["title"] == first["title"]
    assert api.created == 1

    api.timeout_after_create = False
    result = plan._reconcile_child(
        api,
        candidate,
        business=business,
        manifest=manifest,
        checkpoint=lambda *_: None,
    )
    assert result["node_count"] == len(specs)
    assert result["type"] == "custom-action"
    assert result["router_type"] == "multi-conditions"
    assert result["event_branches"] == ["CREATE", "UPDATE"]
    assert result["marker_write"] is False
    assert result["enabled"] is False
    router = next(row for row in api.workflow["nodes"] if row["title"] == first["title"])
    roots = [
        row for row in api.workflow["nodes"]
        if row["upstreamId"] == router["id"]
    ]
    assert sorted(row["branchIndex"] for row in roots) == [1, 2]
