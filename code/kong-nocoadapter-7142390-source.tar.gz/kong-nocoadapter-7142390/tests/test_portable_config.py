from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from app.errors import ConfigurationError
from app.portable_config import render_kong_config, validate_runtime

ROOT = Path(__file__).resolve().parents[1]


def write_nocobase(path: Path, *, token: str = "yaml-secret") -> None:
    path.write_text(
        f"""
nocobase:
  version: "2.2.3"
  base_url: "https://noco.internal:1443/cmtf2"
  authenticator: "basic"
  config_token: "{token}"
""".strip(),
        encoding="utf-8",
    )


def write_template(path: Path) -> None:
    path.write_text(
        """
_format_version: "3.0"
_transform: true
services:
  - name: nocobase-adapter-auth-service
    url: http://change-me.invalid:8080
    routes: []
  - name: nocobase-adapter-business-write-service
    url: http://change-me.invalid:8080
    routes: []
  - name: nocobase-adapter-query-service
    url: http://change-me.invalid:8080
    routes: []
""".strip(),
        encoding="utf-8",
    )


def write_legacy_template(path: Path) -> None:
    path.write_text(
        """
_format_version: "3.0"
_transform: true
services:
  - name: nocobase-adapter-auth-service
    protocol: http
    host: change-me.invalid
    port: 8080
    routes: []
  - name: nocobase-file-adapter-service
    protocol: http
    host: change-me.invalid
    port: 8080
    routes: []
""".strip(),
        encoding="utf-8",
    )


def test_render_uses_one_nocobase_yaml_without_leaking_token(
    tmp_path: Path,
) -> None:
    nocobase = tmp_path / "nocobase.yaml"
    template = tmp_path / "kong.template.yml"
    write_nocobase(nocobase)
    write_template(template)

    rendered = render_kong_config(template, nocobase)
    document = yaml.safe_load(rendered)
    services = {item["name"]: item for item in document["services"]}

    assert "yaml-secret" not in rendered
    assert services["nocobase-adapter-auth-service"]["url"] == (
        "http://cmtf-adapter:8080"
    )
    assert services["nocobase-adapter-business-write-service"]["url"] == (
        "http://cmtf-adapter:8080"
    )
    assert services["nocobase-adapter-query-service"]["url"] == (
        "http://cmtf-adapter:8080"
    )


def test_render_preserves_central_comments_and_named_policy_anchors(
    tmp_path: Path,
) -> None:
    nocobase = tmp_path / "adapter.yaml"
    write_nocobase(nocobase)

    rendered = render_kong_config(
        ROOT / "config/kong.portable-template.yml",
        nocobase,
    )

    assert "# ======================== 集中配置区" in rendered
    assert "&adapter_upstream_url" in rendered
    assert "plugins: *policy_business_write" in rendered
    assert "http://change-me.invalid" not in rendered
    assert "nocobase-adapter-auth-service" in rendered
    assert "yaml-secret" not in rendered


def test_render_keeps_legacy_component_template_compatible(
    tmp_path: Path,
) -> None:
    nocobase = tmp_path / "adapter.yaml"
    template = tmp_path / "kong.template.yml"
    runtime = tmp_path / "kong.runtime.yml"
    write_nocobase(nocobase)
    write_legacy_template(template)

    rendered = render_kong_config(template, nocobase)
    runtime.write_text(rendered, encoding="utf-8")
    document = yaml.safe_load(rendered)
    services = {item["name"]: item for item in document["services"]}

    assert {
        "protocol": "http",
        "host": "cmtf-adapter",
        "port": 8080,
    }.items() <= services["nocobase-adapter-auth-service"].items()
    assert {
        "protocol": "http",
        "host": "cmtf-adapter",
        "port": 8080,
    }.items() <= services["nocobase-file-adapter-service"].items()
    validate_runtime(runtime, nocobase, require_token=True)


def test_validate_requires_token_by_default(tmp_path: Path) -> None:
    nocobase = tmp_path / "nocobase.yaml"
    template = tmp_path / "kong.template.yml"
    runtime = tmp_path / "kong.runtime.yml"
    write_nocobase(nocobase, token="")
    write_template(template)
    runtime.write_text(
        render_kong_config(template, nocobase), encoding="utf-8"
    )

    with pytest.raises(ConfigurationError, match="config_token is required"):
        validate_runtime(runtime, nocobase, require_token=True)

    validate_runtime(runtime, nocobase, require_token=False)


def test_validate_rejects_mismatched_auth_adapter_target(tmp_path: Path) -> None:
    nocobase = tmp_path / "nocobase.yaml"
    template = tmp_path / "kong.template.yml"
    runtime = tmp_path / "kong.runtime.yml"
    write_nocobase(nocobase)
    write_template(template)
    runtime.write_text(
        render_kong_config(template, nocobase).replace(
            "url: http://cmtf-adapter:8080",
            "url: http://wrong-adapter:8080",
            1,
        ),
        encoding="utf-8",
    )

    with pytest.raises(ConfigurationError, match="adapter target is invalid"):
        validate_runtime(runtime, nocobase, require_token=True)


def test_validate_rejects_one_invalid_adapter_group(tmp_path: Path) -> None:
    nocobase = tmp_path / "adapter.yaml"
    template = tmp_path / "kong.template.yml"
    runtime = tmp_path / "kong.yml"
    write_nocobase(nocobase)
    write_template(template)
    runtime.write_text(
        render_kong_config(template, nocobase).replace(
            "url: http://cmtf-adapter:8080",
            "url: http://wrong-adapter:8080",
            1,
        ),
        encoding="utf-8",
    )

    with pytest.raises(ConfigurationError, match="adapter target is invalid"):
        validate_runtime(runtime, nocobase, require_token=True)
