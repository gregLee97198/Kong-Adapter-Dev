from __future__ import annotations

import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]

LEGACY_RUNTIME_FILENAMES = (
    "kong.runtime.yml",
    "nocobase.runtime.yaml",
)

PORTABLE_YAML_EXPORTS = {
    "config/kong.portable-template.yml": ("0644", "kong.yaml"),
    "config/nocobase.portable.yaml": ("0600", "adapter.yaml"),
}


def test_portable_compose_uses_two_3_1_9_images_and_external_yaml() -> None:
    document = yaml.safe_load(
        (ROOT / "docker-compose.portable.yml").read_text(encoding="utf-8")
    )
    services = document["services"]
    adapter = services["cmtf-adapter"]
    kong = services["cmtf-kong"]

    assert adapter["image"] == "cmtf-adapter:${CMTF_RELEASE_TAG:-3.1.9}"
    assert kong["image"] == "cmtf-kong:${CMTF_RELEASE_TAG:-3.1.9}"
    assert "ports" not in adapter
    assert adapter["volumes"] == [
        "./adapter.yaml:/app/config/nocobase.yaml:ro",
        "./kong.yaml:/app/config/kong.yaml:ro",
    ]
    assert "NOCOBASE_CONFIG_TOKEN" not in adapter["environment"]
    assert "NOCOBASE_CONFIG_TOKEN_FILE" not in adapter["environment"]
    assert adapter["environment"]["CREATE_IDEMPOTENCY_INDEX_READY"] == (
        "${CREATE_IDEMPOTENCY_INDEX_READY:-0}"
    )
    assert adapter["environment"]["DEPLOYMENT_ENV"] == (
        "${DEPLOYMENT_ENV:-online_test}"
    )
    assert adapter["environment"]["KONG_HTTPS_BIND"] == (
        "${KONG_HTTPS_BIND:-0.0.0.0}"
    )
    assert adapter["environment"]["KONG_HTTPS_PORT"] == (
        "${KONG_HTTPS_PORT:-443}"
    )
    assert kong["volumes"] == [
        "./kong.yaml:/kong/declarative/kong.yml:ro"
    ]
    assert kong["extra_hosts"] == ["host.docker.internal:host-gateway"]


def test_each_runtime_yaml_is_mounted_into_its_matching_image() -> None:
    document = yaml.safe_load(
        (ROOT / "docker-compose.portable.yml").read_text(encoding="utf-8")
    )
    services = document["services"]

    expected_contract = {
        "cmtf-adapter": {
            "image": "cmtf-adapter:${CMTF_RELEASE_TAG:-3.1.9}",
            "volumes": [
                "./adapter.yaml:/app/config/nocobase.yaml:ro",
                "./kong.yaml:/app/config/kong.yaml:ro",
            ],
        },
        "cmtf-kong": {
            "image": "cmtf-kong:${CMTF_RELEASE_TAG:-3.1.9}",
            "volumes": ["./kong.yaml:/kong/declarative/kong.yml:ro"],
        },
    }

    for service_name, expected in expected_contract.items():
        service = services[service_name]
        assert service["image"] == expected["image"]
        assert service["volumes"] == expected["volumes"]

    assert services["cmtf-adapter"]["volumes"][1].endswith(":ro")
    assert "./adapter.yaml" not in services["cmtf-kong"]["volumes"][0]


def test_portable_templates_are_secret_free_and_not_bound_to_211() -> None:
    nocobase = yaml.safe_load(
        (ROOT / "config/nocobase.portable.yaml").read_text(encoding="utf-8")
    )["nocobase"]
    kong_text = (ROOT / "config/kong.portable-template.yml").read_text(
        encoding="utf-8"
    )

    assert nocobase["base_url"] == "http://change-me.invalid/cmtf2"
    assert nocobase["config_token"] == ""
    assert "119.91." not in kong_text
    assert "host.docker.internal" not in kong_text
    assert "change-me.invalid" not in kong_text


def test_kong_template_centralizes_upstream_and_route_policies() -> None:
    template_path = ROOT / "config/kong.portable-template.yml"
    template_text = template_path.read_text(encoding="utf-8")
    document = yaml.safe_load(template_text)
    services = document["services"]
    routes = [route for service in services for route in service["routes"]]

    assert len(services) == 8
    assert len(routes) == 45
    assert all("url" in service for service in services)
    assert all("plugins" in service for service in services)
    assert all("plugins" not in route for route in routes)
    assert "&nocobase_auth_upstream_url" not in template_text
    assert "&adapter_upstream_url" in template_text
    assert "&policy_business_write" in template_text
    assert "plugins: *policy_business_write" in template_text
    assert "# 认证也经 Adapter 转发" in template_text
    paths = [path for route in routes for path in route.get("paths", [])]
    assert "~/health/ready$" in paths
    assert "~/health/live$" not in paths
    assert "~/v1/request/[^/]+$" in paths
    assert "~/v1/requests/[^/]+$" not in paths


def test_adapter_template_explains_the_only_environment_values_to_edit() -> None:
    adapter_text = (ROOT / "config/nocobase.portable.yaml").read_text(
        encoding="utf-8"
    )

    assert "# 需要修改：" in adapter_text
    assert "nocobase.base_url" in adapter_text
    assert "nocobase.config_token" in adapter_text
    assert "# 通常不需修改" in adapter_text


def test_portable_gateway_requires_mounted_declarative_config() -> None:
    dockerfile = (ROOT / "Dockerfile.kong-portable").read_text(encoding="utf-8")
    entrypoint = (
        ROOT
        / "deploy/kong-release/require-declarative-config-and-start.sh"
    ).read_text(encoding="utf-8")

    assert "COPY config/kong.211-dbless.yml" not in dockerfile
    assert "require-declarative-config-and-start" in dockerfile
    assert "if [ ! -s \"$runtime_config\" ]" in entrypoint
    assert "/opt/kong-release/kong.yml" not in entrypoint


def test_build_script_exports_two_separate_image_archives() -> None:
    script = (ROOT / "scripts/build_portable_3_1_9_release.sh").read_text(
        encoding="utf-8"
    )

    assert 'KONG_IMAGE="cmtf-kong:$VERSION"' in script
    assert 'ADAPTER_IMAGE="cmtf-adapter:$VERSION"' in script
    assert "cmtf-kong-$VERSION-linux-amd64.docker.tar.gz" in script
    assert "cmtf-adapter-$VERSION-linux-amd64.docker.tar.gz" in script
    assert "docker save \"$KONG_IMAGE\"" in script
    assert "docker save \"$ADAPTER_IMAGE\"" in script
    assert '"$RELEASE_DIR/kong.yaml"' in script
    assert '"$RELEASE_DIR/config/kong.runtime.yml"' not in script
    assert '"$RELEASE_DIR/cmtf-kong-$VERSION' in script
    assert '"$RELEASE_DIR/cmtf-adapter-$VERSION' in script
    assert '"$RELEASE_DIR/images' not in script
    assert '"$RELEASE_DIR/config' not in script
    assert "refusing to build from a dirty source tree" in script
    assert '"kong_image_id=$KONG_IMAGE_ID"' in script
    assert '"adapter_image_id=$ADAPTER_IMAGE_ID"' in script
    assert '> SHA256SUMS' in script


def test_build_script_exports_templates_to_exact_runtime_yaml_names() -> None:
    script = (ROOT / "scripts/build_portable_3_1_9_release.sh").read_text(
        encoding="utf-8"
    )
    export_pattern = re.compile(
        r"install -m (?P<mode>\d{4}) "
        r"(?P<source>config/(?:kong\.portable-template\.yml|"
        r"nocobase\.portable\.yaml)) \\\n"
        r"\s+\"\$RELEASE_DIR/(?P<destination>(?:kong|adapter)\.yaml)\""
    )
    actual_exports = {
        match.group("source"): (
            match.group("mode"),
            match.group("destination"),
        )
        for match in export_pattern.finditer(script)
    }

    assert actual_exports == PORTABLE_YAML_EXPORTS
    assert "adapter.yaml \\\n    kong.yaml" in script


def test_release_contract_does_not_use_legacy_runtime_yaml_names() -> None:
    contract_paths = (
        "config/kong.portable-template.yml",
        "config/nocobase.portable.yaml",
        "docker-compose.portable.yml",
        "scripts/build_portable_3_1_9_release.sh",
        "scripts/configure_portable_runtime.sh",
        "docs/Portable-3.1.9-Deployment_zh-CN.md",
    )

    for relative_path in contract_paths:
        text = (ROOT / relative_path).read_text(encoding="utf-8")
        for legacy_name in LEGACY_RUNTIME_FILENAMES:
            assert legacy_name not in text, (
                f"{relative_path} still uses legacy runtime filename "
                f"{legacy_name}"
            )


def test_runtime_configurator_reads_only_root_level_yaml() -> None:
    script = (ROOT / "scripts/configure_portable_runtime.sh").read_text(
        encoding="utf-8"
    )

    assert 'ADAPTER_CONFIG="$ROOT_DIR/adapter.yaml"' in script
    assert 'KONG_CONFIG="$ROOT_DIR/kong.yaml"' in script
    assert 'CONFIG_DIR="$ROOT_DIR/config"' not in script


def test_root_runtime_yaml_files_are_gitignored() -> None:
    ignored = (ROOT / ".gitignore").read_text(encoding="utf-8").splitlines()

    assert "/adapter.yaml" in ignored
    assert "/kong.yaml" in ignored
