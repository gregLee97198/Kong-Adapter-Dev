from __future__ import annotations

import hashlib
from dataclasses import fields
from pathlib import Path
from unittest.mock import AsyncMock

import pytest
import yaml
from fastapi.testclient import TestClient
from test_main import FakeAuthClient

from app.errors import ConfigurationError
from app.main import create_app
from app.nocobase_client import NocoBaseClient
from app.portable_config import pin_runtime, validate_runtime
from app.portable_runtime import load_portable_runtime
from app.settings import Settings
from app.update_queue_release import QUEUE_FAMILY_API_TYPES
from app.update_queue_service import QueueActivationGates

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = "http://host.docker.internal:13000/cmtf2"


def _runtime_files(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> tuple[Path, Path]:
    adapter = tmp_path / "adapter.yaml"
    kong = tmp_path / "kong.yaml"
    document = yaml.safe_load(
        (ROOT / "config/nocobase.portable.yaml").read_text(encoding="utf-8")
    )
    document["nocobase"]["base_url"] = UPSTREAM
    document["nocobase"]["config_token"] = "fixture-only-token"
    adapter.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    kong.write_text(
        (ROOT / "config/kong.portable-template.yml").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    monkeypatch.setenv("NOCOBASE_CONFIG_PATH", str(adapter))
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN", raising=False)
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN_FILE", raising=False)
    monkeypatch.setenv("DEPLOYMENT_ENV", "online_test")
    monkeypatch.setenv("KONG_HTTPS_BIND", "0.0.0.0")
    monkeypatch.setenv("KONG_HTTPS_PORT", "443")
    return adapter, kong


def _write_adapter(path: Path, document: dict) -> None:
    path.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")


def _reviewed_document(document: dict) -> None:
    evidence = {
        item.name: f"review:20261017:{item.name}"
        for item in fields(QueueActivationGates)
        if item.name != "native_intake_boundary_verified"
    }
    document["nocobase"]["features"]["licence_renewal_update"] = True
    document["portable_deployment"]["update_queue"] = {
        "enabled": True,
        "families": list(QUEUE_FAMILY_API_TYPES),
    }
    document["update_queue_release"] = {
        "schema_version": 1,
        "review_id": "review:20261017:all-v081-families",
        "deployment_env": "online_test",
        "nocobase_base_url": UPSTREAM,
        "source_system": "OP",
        "https_bind": "0.0.0.0",
        "https_port": "443",
        "admission_workflow_key": "u2w20ale8lj",
        "rejection_workflow_key": "2jglgnj6mwt",
        "families": {
            name: {
                "create_api_type": routes[0],
                "update_api_type": routes[1],
                "evidence": {
                    key: f"{reference}:{name}" for key, reference in evidence.items()
                },
            }
            for name, routes in QUEUE_FAMILY_API_TYPES.items()
        },
    }


def test_pin_is_independent_and_preserves_kong_comments(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    original = kong.read_text(encoding="utf-8")
    digest = pin_runtime(kong, adapter)
    assert digest == hashlib.sha256(adapter.read_bytes()).hexdigest()
    assert "fixture-only-token" not in kong.read_text(encoding="utf-8")
    assert "&policy_business_write" in kong.read_text(encoding="utf-8")
    assert "# ======================== 集中配置区" in kong.read_text(encoding="utf-8")
    assert len(original.splitlines()) == len(
        kong.read_text(encoding="utf-8").splitlines()
    )
    validate_runtime(kong, adapter, require_token=True, require_pin=True)

    adapter.write_text(
        adapter.read_text(encoding="utf-8") + "# changed\n", encoding="utf-8"
    )
    with pytest.raises(ConfigurationError, match="pin does not match"):
        validate_runtime(kong, adapter, require_token=True, require_pin=True)


def test_portable_template_is_inert_and_binds_docker_settings(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    pin_runtime(kong, adapter)
    runtime = load_portable_runtime(settings=Settings.from_env(), kong_path=kong)
    assert runtime.update_queue_enabled is False
    assert runtime.update_queue_families == frozenset()
    assert runtime.create_idempotency_index_ready is False
    assert runtime.profile_sha256 == hashlib.sha256(adapter.read_bytes()).hexdigest()

    monkeypatch.setenv("KONG_HTTPS_PORT", "18443")
    with pytest.raises(ConfigurationError, match="binding does not match"):
        load_portable_runtime(settings=Settings.from_env(), kong_path=kong)


def test_portable_rejects_unpinned_upstream_or_token_env_override(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    pin_runtime(kong, adapter)
    for name, value in (
        ("NOCOBASE_BASE_URL", "http://other.invalid/cmtf2"),
        ("NOCOBASE_CONFIG_TOKEN", "untracked-token"),
    ):
        monkeypatch.setenv(name, value)
        with pytest.raises(ConfigurationError, match="overrides are not allowed"):
            load_portable_runtime(settings=Settings.from_env(), kong_path=kong)
        monkeypatch.delenv(name)


def test_portable_queue_rejects_unreviewed_partial_family_activation(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    document["portable_deployment"]["update_queue"] = {
        "enabled": True,
        "families": ["new_licence"],
    }
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    with pytest.raises(ConfigurationError, match="release evidence is missing"):
        load_portable_runtime(settings=Settings.from_env(), kong_path=kong)


def test_portable_queue_accepts_reviewed_subset_and_blocks_other_updates(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    _reviewed_document(document)
    document["nocobase"]["features"]["licence_renewal_update"] = False
    document["portable_deployment"]["update_queue"]["families"] = [
        "changing_home"
    ]
    document["update_queue_release"]["families"] = {
        "changing_home": document["update_queue_release"]["families"]["changing_home"]
    }
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    monkeypatch.setenv("PORTABLE_RELEASE", "1")
    monkeypatch.setenv("PORTABLE_KONG_CONFIG_PATH", str(kong))
    monkeypatch.setattr(NocoBaseClient, "start", AsyncMock())
    monkeypatch.setattr(NocoBaseClient, "close", AsyncMock())

    with TestClient(create_app(Settings.from_env())) as client:
        assert client.app.state.update_queue_service is not None
        assert client.app.state.update_queue_application_types == frozenset(
            {"changing_home"}
        )
        fake_client = FakeAuthClient()
        client.app.state.client = fake_client
        response = client.post(
            "/v1/update_new_licence_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "NLA-PORTABLE-UNSELECTED-1",
                "create_id": "384761337741312",
                "form_data": {"part_2": {"rch_name_en": "Updated RCH Name"}},
            },
        )

    assert response.status_code == 503
    assert response.json()["error"]["code"] == "update_queue_not_ready"
    assert fake_client.staging_calls == []


def test_portable_queue_rejects_enabled_empty_family_set(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    document["portable_deployment"]["update_queue"]["enabled"] = True
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    with pytest.raises(ConfigurationError, match="at least one reviewed family"):
        load_portable_runtime(settings=Settings.from_env(), kong_path=kong)


def test_portable_reviewed_lrn_queue_needs_no_legacy_feature_flag(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    _reviewed_document(document)
    document["nocobase"]["features"]["licence_renewal_update"] = False
    document["portable_deployment"]["update_queue"]["families"] = [
        "licence_renewal"
    ]
    document["update_queue_release"]["families"] = {
        "licence_renewal": document["update_queue_release"]["families"][
            "licence_renewal"
        ]
    }
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    monkeypatch.setenv("PORTABLE_RELEASE", "1")
    monkeypatch.setenv("PORTABLE_KONG_CONFIG_PATH", str(kong))
    monkeypatch.setattr(NocoBaseClient, "start", AsyncMock())
    monkeypatch.setattr(NocoBaseClient, "close", AsyncMock())
    with TestClient(create_app(Settings.from_env())) as client:
        queue = client.app.state.update_queue_service
        assert queue is not None
        assert client.app.state.update_queue_application_types == frozenset(
            {"licence_renewal"}
        )
        fake_client = FakeAuthClient()
        fake_client.original_request.update(
            {
                "f_api_type": "create_licence_renewal",
                "f_application_type": "licence_renewal",
                "f_intake_id": None,
                "f_rch_id": "376863288262672",
            }
        )
        client.app.state.client = fake_client
        queue.admit_update = AsyncMock()
        response = client.post(
            "/v1/update_licence_renewal_data",
            headers={"Authorization": "Bearer valid-client-token"},
            json={
                "request_id": "LRN-PORTABLE-REVIEWED-1",
                "create_id": "384761337741312",
                "form_data": {
                    "part_1": {"application_received_date": "2026-10-17"}
                },
            },
        )
        assert response.status_code == 200
        assert response.json() == {
            "accepted": True,
            "request_id": "LRN-PORTABLE-REVIEWED-1",
            "create_id": "384761337741312",
            "status": "Accepted",
            "application_type": "licence_renewal",
        }
        queue.admit_update.assert_awaited_once()
        assert fake_client.staging_calls == []


def test_portable_create_idempotency_requires_evidence(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    document["portable_deployment"]["create_idempotency"]["enabled"] = True
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    with pytest.raises(ConfigurationError, match="evidence is missing"):
        load_portable_runtime(settings=Settings.from_env(), kong_path=kong)


def test_portable_startup_ignores_legacy_queue_env_and_requires_review(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    pin_runtime(kong, adapter)
    monkeypatch.setenv("PORTABLE_RELEASE", "1")
    monkeypatch.setenv("PORTABLE_KONG_CONFIG_PATH", str(kong))
    monkeypatch.setenv("UPDATE_QUEUE_ENABLED", "1")
    monkeypatch.setenv("UPDATE_QUEUE_APPLICATION_TYPES", "new_licence")
    monkeypatch.setattr(NocoBaseClient, "start", AsyncMock())
    monkeypatch.setattr(NocoBaseClient, "close", AsyncMock())
    with TestClient(create_app(Settings.from_env())) as client:
        assert client.app.state.update_queue_service is None
        assert client.app.state.update_queue_application_types == frozenset()

    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    _reviewed_document(document)
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    with TestClient(create_app(Settings.from_env())) as client:
        service = client.app.state.update_queue_service
        assert service is not None
        service._gates.require_ready()
        assert client.app.state.update_queue_application_types == frozenset(
            QUEUE_FAMILY_API_TYPES
        )


def test_portable_review_rejects_missing_family_evidence(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter, kong = _runtime_files(tmp_path, monkeypatch)
    document = yaml.safe_load(adapter.read_text(encoding="utf-8"))
    _reviewed_document(document)
    document["update_queue_release"]["families"]["new_licence"]["evidence"].pop(
        "native_worker_revisions_verified"
    )
    _write_adapter(adapter, document)
    pin_runtime(kong, adapter)
    monkeypatch.setenv("PORTABLE_RELEASE", "1")
    monkeypatch.setenv("PORTABLE_KONG_CONFIG_PATH", str(kong))
    monkeypatch.setattr(NocoBaseClient, "start", AsyncMock())
    monkeypatch.setattr(NocoBaseClient, "close", AsyncMock())
    with pytest.raises(RuntimeError, match="gate evidence"):
        with TestClient(create_app(Settings.from_env())):
            pass
