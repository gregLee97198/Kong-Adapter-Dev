"""Offline guardrails for the disabled unified dispatcher revision."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import prepare_nocobase_unified_staging_dispatch_13001 as prepare  # noqa: E402
from plan_nocobase_generic_update_queue import (  # noqa: E402
    legacy_parent_nodes,
    parent_nodes,
)


def test_candidate_and_legacy_graphs_have_explicit_safe_shapes() -> None:
    """A completion-pump upgrade must be auditable without a remote call."""
    assert prepare.SOURCE_UID == 392438115532800
    assert prepare.SOURCE_KEY == "7dms7pwosyw"
    assert len(legacy_parent_nodes()) == 56
    candidate = parent_nodes()
    assert len(candidate) == 61
    assert candidate[0]["key"] == "generic_is_create_completion"
    assert candidate[0]["upstream"] is None
    assert candidate[0]["branch"] is None


def test_preparation_is_explicitly_scoped_to_13001() -> None:
    assert ":13001/cmtf2" in prepare.BASE_URL
    assert "PREPARE_DISABLED_UNIFIED_STAGING_DISPATCH_13001" == prepare.CONFIRM
