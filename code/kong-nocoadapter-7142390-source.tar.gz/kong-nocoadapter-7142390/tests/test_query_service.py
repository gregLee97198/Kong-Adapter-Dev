from __future__ import annotations

from copy import deepcopy
from typing import Any

import pytest

from app.errors import AdapterError
from app.query_service import QueryService, _normalize_new_licence_public_types


def _contains_status_field(value: Any) -> bool:
    if isinstance(value, dict):
        return any(
            (isinstance(key, str) and "status" in key.lower())
            or _contains_status_field(item)
            for key, item in value.items()
        )
    if isinstance(value, list):
        return any(_contains_status_field(item) for item in value)
    return False


def _contains_native_id(value: Any) -> bool:
    if isinstance(value, dict):
        return "id" in value or any(
            _contains_native_id(item) for item in value.values()
        )
    if isinstance(value, list):
        return any(_contains_native_id(item) for item in value)
    return False


def test_new_licence_query_normalizes_native_field_types() -> None:
    form_data: dict[str, Any] = {
        "part_1": {
            "application_received_date": "2026-10-07T00:00:00.000Z",
            "tentative_commencement_date": "2027-04-05",
        },
        "part_2": {
            "monthly_fee_min": "12000.00",
            "floor_area_sqm": "520.50",
            "floors_total": "2.00",
            "units_total": 0,
            "is_rcsv": False,
            "complies_lease_dmc": "true",
            "premises": {
                "rented": [
                    {
                        "tenancy_from": "2026-07-09T00:00:00.000Z",
                        "tenancy_to": "2031-10-06",
                    }
                ]
            },
        },
        "part_3": {
            "signature_date": "2026-10-07T00:00:00.000Z",
            "operator": {"active": True, "address_for_licence": "true"},
            "personnel": [{"active": "false"}],
        },
        "part_4": {"authorised_representative": {"active": "1"}},
    }

    _normalize_new_licence_public_types(form_data)

    assert form_data["part_1"] == {
        "application_received_date": "2026-10-07",
        "tentative_commencement_date": "2027-04-05",
    }
    part_2 = form_data["part_2"]
    assert part_2["monthly_fee_min"] == 12000
    assert part_2["floor_area_sqm"] == 520.5
    assert part_2["floors_total"] == 2
    assert part_2["units_total"] == 0
    assert part_2["is_rcsv"] is False
    assert part_2["complies_lease_dmc"] is True
    assert part_2["premises"]["rented"][0]["tenancy_from"] == "2026-07-09"
    assert form_data["part_3"]["signature_date"] == "2026-10-07"
    assert form_data["part_3"]["operator"]["address_for_licence"] is True
    assert form_data["part_3"]["personnel"][0]["active"] is False
    assert form_data["part_4"]["authorised_representative"]["active"] is True


@pytest.mark.parametrize(
    ("field", "value"),
    [("floor_area_sqm", "not-a-number"), ("floors_total", "2.5")],
)
def test_new_licence_query_rejects_invalid_native_field_types(
    field: str, value: str
) -> None:
    form_data = {"part_2": {field: value}}
    with pytest.raises(AdapterError) as exc:
        _normalize_new_licence_public_types(form_data)
    assert exc.value.status_code == 502
    assert exc.value.code == "upstream_error"


class FakeClient:
    def __init__(self) -> None:
        self.record: dict[str, Any] = {}
        self.queued_records: list[dict[str, Any]] = []
        self.rows: list[dict[str, Any]] = []
        self.queued_results: list[dict[str, Any]] = []
        self.catalog_rows: list[dict[str, Any]] = []
        self.staging_update_rows: list[dict[str, Any]] = []
        self.calls: list[dict[str, Any]] = []

    async def get_record(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(kwargs)
        if self.queued_records:
            return self.queued_records.pop(0)
        return self.record

    async def list_records(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(kwargs)
        if kwargs.get("collection") == "t_api_request_staging":
            filters = kwargs.get("filters") or {}
            clauses = filters.get("$and") or []
            matches = list(self.staging_update_rows)
            for clause in clauses:
                field, condition = next(iter(clause.items()))
                if "$eq" in condition:
                    matches = [
                        row for row in matches
                        if str(row.get(field)) == str(condition["$eq"])
                    ]
                elif "$in" in condition:
                    matches = [
                        row for row in matches
                        if row.get(field) in condition["$in"]
                    ]
            if kwargs.get("sort") == ("-id",):
                matches.sort(key=lambda row: row["id"], reverse=True)
            matches = matches[: kwargs.get("page_size", 20)]
            return {
                "data": matches,
                "meta": {"count": len(matches)},
            }
        if self.queued_results:
            return self.queued_results.pop(0)
        return {
            "data": self.rows,
            "meta": {"count": len(self.rows), "page": 1, "pageSize": 20},
        }

    async def list_configuration_records(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(kwargs)
        return {
            "data": self.catalog_rows,
            "meta": {"count": len(self.catalog_rows)},
        }


@pytest.mark.asyncio
async def test_notice_list_is_compact_and_allows_missing_attachment() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 1,
            "f_third_party_name": "OP",
            "f_intake_type": {"id": 10, "f_name": "New Licence Application"},
            "f_status": {"id": 100, "f_status": "Acknowledged"},
            "f_notice_type": "a",
            "f_content": "Acknowledgement issued.",
            "f_rch_no": "L0043",
            "f_rch_name": "Example Home",
            "createdAt": "2026-09-15T01:00:00Z",
            "f_letter_attachment": {
                "id": 20,
                "f_is_send": True,
                "f_sendtime": "2026-09-15T00:59:00Z",
                "f_attachment": [
                    {"id": 30, "filename": "letter.pdf", "size": 1234}
                ],
            },
        },
        {
            "id": 2,
            "f_third_party_name": "OP",
            "f_intake_type": {"id": 10, "f_name": "New Licence Application"},
            "f_status": None,
            "f_notice_type": "warning",
            "f_content": None,
            "f_rch_no": "L0043",
            "f_rch_name": "Example Home",
            "createdAt": "2026-09-15T02:00:00Z",
            "f_letter_attachment": None,
        },
        {
            "id": 3,
            "f_third_party_name": "ANOTHER_PARTY",
            "f_intake_type": {"id": 10, "f_name": "New Licence Application"},
            "f_notice_type": "warning",
            "createdAt": "2026-09-15T03:00:00Z",
            "f_letter_attachment": None,
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_notices(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert client.calls[0]["filters"] == {
        "$and": [
            {"fk_api_request": {"$eq": "9001"}},
            {"f_third_party_name": {"$eq": "OP"}},
        ]
    }
    assert client.calls[0]["authorization_token"] == "client-token"
    assert "f_status" in client.calls[0]["appends"]
    assert len(result) == 2
    assert result[0]["notice_id"] == "1"
    assert result[1]["notice_id"] == "2"
    assert result[0]["status"] == "Acknowledged"
    assert result[1]["status"] is None
    assert result[0]["content"] == "Acknowledgement issued."
    assert result[1]["content"] is None
    assert result[0]["attachments"] == [
        {
            "data_id": 30,
            "filename": "letter.pdf",
            "size": 1234,
            "download_url": "/v1/files/30",
        }
    ]
    assert result[1]["attachments"] == []
    assert "letter_attachment_id" not in result[0]


@pytest.mark.asyncio
async def test_notice_list_excludes_wrong_create_id_from_upstream_page() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 1,
            "fk_api_request": 9001,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Received"},
        },
        {
            "id": 2,
            "fk_api_request": 9002,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Received"},
        },
    ]

    notices = await QueryService(client, "OP").list_notices(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert [notice["notice_id"] for notice in notices] == ["1"]


@pytest.mark.asyncio
async def test_notice_list_hides_file_until_letter_send_is_recorded() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 5,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Acknowledged"},
            "f_letter_attachment": {
                "f_is_send": False,
                "f_sendtime": None,
                "f_attachment": [{"id": 1407, "filename": "letter.docx"}],
            },
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert notices[0]["status"] == "Acknowledged"
    assert notices[0]["attachments"] == []


@pytest.mark.asyncio
async def test_nla_notices_hide_premature_approval_until_canonical_status() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 70,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"},
            "f_notice_type": "c",
            "createdAt": "2026-10-08T01:00:00Z",
            "f_letter_attachment": {
                "id": 700,
                "f_is_send": True,
                "f_sendtime": "2026-10-08T01:00:00Z",
                "f_attachment": [{"id": 701, "filename": "cover.pdf"}],
            },
        },
        {
            "id": 71,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Confirmed"},
            "f_notice_type": "b",
            "createdAt": "2026-10-08T00:00:00Z",
            "f_letter_attachment": {
                "id": 710,
                "f_is_send": True,
                "f_sendtime": "2026-10-08T00:00:00Z",
                "f_attachment": [{"id": 711, "filename": "confirmation.pdf"}],
            },
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    confirmed = await service.list_notices(
        create_id="9001",
        request_id="request-1",
        authorization_token="client-token",
        application_type_value="new_licence",
        current_status="Confirmed",
    )
    assert [notice["notice_id"] for notice in confirmed] == ["71"]

    approved = await service.list_notices(
        create_id="9001",
        request_id="request-2",
        authorization_token="client-token",
        application_type_value="new_licence",
        current_status="Approved",
    )
    # A Cover Letter on its own is not the Approved package.
    assert [notice["notice_id"] for notice in approved] == ["71"]


@pytest.mark.asyncio
async def test_nla_letter_notice_requires_linked_sent_file() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 80,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Received"},
            "f_letter_attachment": None,
        },
        {
            "id": 81,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Acknowledged"},
            "f_notice_type": "a",
            "f_letter_attachment": None,
        },
        {
            "id": 82,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Confirmed"},
            "f_notice_type": "b",
            "f_letter_attachment": {
                "f_is_send": True,
                "f_sendtime": "2026-10-08T00:00:00Z",
                "f_attachment": [],
            },
        },
        {
            "id": 83,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"},
            "f_notice_type": "c",
            "f_letter_attachment": {
                "f_is_send": True,
                "f_sendtime": "2026-10-08T01:00:00Z",
                "f_attachment": [{"id": 1420, "filename": "cover.pdf"}],
            },
        },
        {
            "id": 84,
            "f_third_party_name": "OP",
            "f_status": None,
            "f_notice_type": "warning",
            "f_letter_attachment": None,
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="request-1",
        authorization_token="client-token",
        application_type_value="new_licence",
        current_status="Approved",
    )

    assert [notice["notice_id"] for notice in notices] == ["80", "84"]
    assert notices[1]["attachments"] == []


@pytest.mark.asyncio
async def test_nla_approved_package_is_one_notice_with_both_issued_files() -> None:
    client = FakeClient()
    cover = {
        "id": 501, "f_letter_type": "c", "f_business_key": 900,
        "f_is_send": True, "f_sendtime": "2026-10-08T01:00:00Z",
        "f_attachment": [{"id": 701, "filename": "cover.pdf", "size": 100}],
    }
    licence = {
        "id": 502, "f_letter_type": "f", "f_business_key": 900,
        "f_is_send": True, "f_sendtime": "2026-10-08T02:00:00Z",
        "f_attachment": [{"id": 702, "filename": "licence.pdf", "size": 200}],
    }
    package = {
        "id": 600, "f_third_party_name": "OP",
        "f_status": {"f_status": "Approved"},
        "f_notice_type": "f", "f_business_record_id": 900,
        "f_source_collection": "t_letter_attachment",
        "f_source_record_id": "502", "f_letter_attachment": licence,
        "f_issued_letters": [cover, licence],
        "f_recipient_snapshot": {
            "issuedLetterIds": [501, 502],
            "attachmentIds": [701, 702],
        },
        "createdAt": "2026-10-08T02:01:00Z",
    }
    client.rows = [package]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="800", request_id="transport-1",
        authorization_token="client-token",
        application_type_value="new_licence", current_status="Approved",
    )

    assert len(notices) == 1
    assert notices[0]["notice_id"] == "600"
    assert notices[0]["notice_type"] == "new_licence_letter"
    assert [item["data_id"] for item in notices[0]["attachments"]] == [701, 702]
    assert set(notices[0]) == {
        "notice_id", "third_party_name", "intake_type", "notice_type",
        "status", "content", "rch_no", "rch_name", "created_time",
        "attachments",
    }
    assert "f_issued_letters.f_attachment" in client.calls[0]["appends"]

    cover["f_is_send"] = False
    assert await service.list_notices(
        create_id="800", request_id="transport-2",
        authorization_token="client-token",
        application_type_value="new_licence", current_status="Approved",
    ) == []

    cover["f_is_send"] = True
    client.rows.append({**package, "id": 601})
    with pytest.raises(AdapterError) as exc:
        await service.list_notices(
            create_id="800", request_id="transport-3",
            authorization_token="client-token",
            application_type_value="new_licence", current_status="Approved",
        )
    assert exc.value.status_code == 502
    assert exc.value.code == "invalid_upstream_response"


@pytest.mark.asyncio
async def test_nla_notice_history_projects_current_approved_package_once() -> None:
    client = FakeClient()
    cover = {
        "id": 501,
        "f_letter_type": "c",
        "f_business_key": 900,
        "f_is_send": True,
        "f_sendtime": "2026-10-08T01:00:00Z",
        "f_attachment": [{"id": 701, "filename": "cover.pdf", "size": 100}],
    }
    licence = {
        "id": 502,
        "f_letter_type": "f",
        "f_business_key": 900,
        "f_is_send": True,
        "f_sendtime": "2026-10-08T02:00:00Z",
        "f_attachment": [{"id": 702, "filename": "licence.pdf", "size": 200}],
    }
    client.rows = [
        {
            "id": 117,
            "fk_api_request": 800,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Received"},
            "f_notice_type": "received",
            "createdAt": "2026-10-07T12:59:13Z",
        },
        {
            "id": 119,
            "fk_api_request": 800,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "P_Number_Generated"},
            "f_notice_type": "p_number_generated",
            "createdAt": "2026-10-07T13:13:29Z",
        },
        {
            "id": 129,
            "fk_api_request": 800,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"},
            "f_notice_type": "c",
            "f_source_collection": "t_letter_attachment",
            "f_letter_attachment": None,
            "createdAt": "2026-10-08T03:50:07Z",
        },
        {
            "id": 130,
            "fk_api_request": 800,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"},
            "f_notice_type": "f",
            "f_source_collection": "t_letter_attachment",
            "f_letter_attachment": None,
            "createdAt": "2026-10-08T03:50:08Z",
        },
        {
            "id": 481,
            "fk_api_request": 800,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"},
            "f_notice_type": "f",
            "f_source_collection": "t_letter_attachment",
            "f_source_record_id": "502",
            "f_business_record_id": 900,
            "f_letter_attachment": licence,
            "f_issued_letters": [cover, licence],
            "f_recipient_snapshot": {
                "issuedLetterIds": [501, 502],
                "attachmentIds": [701, 702],
            },
            "createdAt": "2026-10-16T12:00:00Z",
        },
    ]

    notices = await QueryService(client, "OP").list_notices(
        create_id="800",
        request_id="transport-1",
        authorization_token="client-token",
        application_type_value="new_licence",
        current_status="Approved",
    )

    assert [notice["status"] for notice in notices] == [
        "Received",
        "P_Number_Generated",
        "Approved",
    ]
    assert [notice["notice_id"] for notice in notices] == ["117", "119", "481"]
    assert [file["data_id"] for file in notices[2]["attachments"]] == [701, 702]
    assert [file["download_url"] for file in notices[2]["attachments"]] == [
        "/v1/files/701",
        "/v1/files/702",
    ]


@pytest.mark.asyncio
async def test_nla_legacy_approved_pair_is_projected_once() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 610, "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"}, "f_notice_type": "c",
            "f_source_collection": "t_letter_attachment",
            "f_source_record_id": "501",
            "f_letter_attachment": {
                "id": 501, "f_is_send": True,
                "f_sendtime": "2026-10-08T01:00:00Z",
                "f_attachment": [{"id": 701, "filename": "cover.pdf"}],
            },
            "createdAt": "2026-10-08T01:01:00Z",
        },
        {
            "id": 611, "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"}, "f_notice_type": "f",
            "f_source_collection": "t_letter_attachment",
            "f_source_record_id": "502",
            "f_letter_attachment": {
                "id": 502, "f_is_send": True,
                "f_sendtime": "2026-10-08T02:00:00Z",
                "f_attachment": [{"id": 702, "filename": "licence.pdf"}],
            },
            "createdAt": "2026-10-08T02:01:00Z",
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="800", request_id="transport-1",
        authorization_token="client-token",
        application_type_value="new_licence", current_status="Approved",
    )
    assert [item["notice_id"] for item in notices] == ["611"]
    assert [item["data_id"] for item in notices[0]["attachments"]] == [701, 702]

    client.rows.pop()
    assert await service.list_notices(
        create_id="800", request_id="transport-2",
        authorization_token="client-token",
        application_type_value="new_licence", current_status="Approved",
    ) == []


@pytest.mark.asyncio
async def test_other_application_letter_notice_requires_linked_sent_file() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 85,
            "f_third_party_name": "OP",
            "f_source_collection": "t_letter_attachment",
            "f_letter_attachment": None,
        },
        {
            "id": 86,
            "f_third_party_name": "OP",
            "f_source_collection": "t_letter_attachment",
            "f_letter_attachment": {
                "f_is_send": False,
                "f_sendtime": None,
                "f_attachment": [{"id": 123, "filename": "draft.pdf"}],
            },
        },
        {
            "id": 87,
            "f_third_party_name": "OP",
            "f_source_collection": "t_letter_attachment",
            "f_letter_attachment": {
                "f_is_send": True,
                "f_sendtime": "2026-10-15T00:00:00Z",
                "f_attachment": [],
            },
        },
        {
            "id": 88,
            "f_third_party_name": "OP",
            "f_source_collection": "t_letter_attachment",
            "f_source_record_id": "550",
            "f_letter_attachment": {
                "id": 550,
                "f_is_send": True,
                "f_sendtime": "2026-10-15T00:00:00Z",
                "f_attachment": [{"id": 456, "filename": "sent.pdf"}],
            },
        },
        {
            "id": 90,
            "f_third_party_name": "OP",
            "f_source_collection": "t_letter_attachment",
            "f_source_record_id": "551",
            "f_letter_attachment": {
                "id": 550,
                "f_is_send": True,
                "f_sendtime": "2026-10-15T00:00:00Z",
                "f_attachment": [{"id": 456, "filename": "wrong.pdf"}],
            },
        },
        {
            "id": 89,
            "f_third_party_name": "OP",
            "f_notice_type": "warning",
            "f_letter_attachment": None,
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="request-1",
        authorization_token="client-token",
        application_type_value="renewal_licence",
    )

    assert [notice["notice_id"] for notice in notices] == ["88", "89"]
    assert notices[0]["attachments"][0]["download_url"] == "/v1/files/456"
    assert notices[1]["attachments"] == []


@pytest.mark.asyncio
async def test_notice_list_returns_each_file_of_a_sent_letter() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 6,
            "f_third_party_name": "OP",
            "f_status": {"f_status": "Approved"},
            "f_letter_attachment": {
                "f_is_send": True,
                "f_sendtime": "2026-10-08T01:00:00Z",
                "f_attachment": [
                    {"id": 1415, "filename": "cover-letter.pdf", "size": 100},
                    {"id": 1416, "filename": "licence.pdf", "size": 200},
                ],
            },
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert [file["data_id"] for file in notices[0]["attachments"]] == [1415, 1416]
    assert [file["download_url"] for file in notices[0]["attachments"]] == [
        "/v1/files/1415",
        "/v1/files/1416",
    ]


@pytest.mark.asyncio
async def test_notice_list_reads_all_pages_without_truncating_history() -> None:
    client = FakeClient()
    client.queued_results = [
        {
            "data": [
                {"id": index, "f_third_party_name": "OP"}
                for index in range(1, 501)
            ],
            "meta": {"count": 501},
        },
        {
            "data": [{"id": 501, "f_third_party_name": "OP"}],
            "meta": {"count": 501},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert len(notices) == 501
    assert [call["page"] for call in client.calls] == [1, 2]
    assert all(call["authorization_token"] == "client-token" for call in client.calls)


@pytest.mark.asyncio
async def test_notice_list_orders_historical_received_backfill_by_event_time() -> None:
    client = FakeClient()
    # NocoBase returns insertion order.  Received was backfilled only after
    # P Number and acknowledgement had already been recorded.
    client.rows = [
        {
            "id": 98,
            "f_third_party_name": "OP",
            "f_notice_type": "p_number_generated",
            "f_status": {"f_status": "P_Number_Generated"},
            "f_status_updated_at": "2026-10-05T09:00:00+08:00",
            "createdAt": "2026-10-05T09:00:01+08:00",
        },
        {
            "id": 101,
            "f_third_party_name": "OP",
            "f_notice_type": "a",
            "f_status": {"f_status": "Acknowledged"},
            "f_status_updated_at": "2026-10-06T03:00:00Z",
            "createdAt": "2026-10-06T03:00:01Z",
        },
        {
            "id": 120,
            "f_third_party_name": "OP",
            "f_notice_type": "received",
            "f_status": {"f_status": "Received"},
            "f_status_updated_at": "2026-10-05T00:00:00Z",
            "createdAt": "2026-10-07T10:00:00Z",
            "f_letter_attachment": None,
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="390780233973760",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert [notice["status"] for notice in notices] == [
        "Received",
        "P_Number_Generated",
        "Acknowledged",
    ]
    assert [notice["notice_id"] for notice in notices] == ["120", "98", "101"]
    assert [notice["notice_type"] for notice in notices] == [
        None,
        None,
        "acknowledgement_letter",
    ]
    assert notices[0]["attachments"] == []
    # The existing public field remains the row creation time, not the
    # historical business-event time used for ordering.
    assert notices[0]["created_time"] == "2026-10-07T10:00:00Z"


@pytest.mark.asyncio
async def test_notice_list_sort_falls_back_to_created_at_and_numeric_id() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 10,
            "f_third_party_name": "OP",
            "f_status_updated_at": "not-a-time",
            "createdAt": "2026-10-07T00:00:00Z",
        },
        {
            "id": 2,
            "f_third_party_name": "OP",
            "createdAt": "2026-10-07T08:00:00+08:00",
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="transport-2",
        authorization_token="client-token",
    )

    assert [notice["notice_id"] for notice in notices] == ["2", "10"]


@pytest.mark.asyncio
async def test_notice_list_uses_application_label_when_intake_type_missing() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 100,
            "f_third_party_name": "OP",
            "f_intake_type": None,
            "f_status": {"f_status": "Acknowledged"},
            "f_letter_attachment": None,
        },
        {
            "id": 101,
            "f_third_party_name": "OP",
            "f_intake_type": {"f_name": "Native Intake Category"},
            "f_letter_attachment": None,
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    notices = await service.list_notices(
        create_id="9001",
        request_id="transport-2",
        authorization_token="client-token",
        application_type_label="New Licence Applications",
    )

    assert [notice["intake_type"] for notice in notices] == [
        "New Licence Applications",
        "Native Intake Category",
    ]
    assert notices[0]["status"] == "Acknowledged"
    assert client.calls[0]["collection"] == "t_notice_board"

    without_fallback = await service.list_notices(
        create_id="9001",
        request_id="transport-3",
        authorization_token="client-token",
    )
    assert [notice["intake_type"] for notice in without_fallback] == [
        None,
        "Native Intake Category",
    ]


@pytest.mark.asyncio
async def test_request_status_returns_public_ids_without_request_body() -> None:
    client = FakeClient()
    client.record = {
        "id": 9001,
        "f_request_body": {"request_id": "OP-001"},
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_status": "succeeded",
        "f_application_type": "new_licence",
        "f_office_code": "LORCHE",
        "f_application_status": "Acknowledged",
        "f_intake_id": "8001",
        "f_application_id": "7001",
        "createdAt": "2026-09-04T00:00:00Z",
        "updatedAt": "2026-09-04T00:00:01Z",
    }
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_request(
        record_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["id"] == 9001
    assert result["request_id"] == "OP-001"
    assert result["create_id"] == 9001
    assert result["status"] == "succeeded"
    assert result["application_type"] == "new_licence"
    assert result["office_code"] == "LORCHE"
    assert result["application_status"] == "Acknowledged"
    assert result["intake_id"] == "8001"
    assert result["application_id"] == "7001"
    assert result.get("rch_id") is None
    assert "form_data" not in result


@pytest.mark.asyncio
async def test_request_status_uses_staging_id_as_create_id_for_chi() -> None:
    client = FakeClient()
    client.record = {
        "id": 9101,
        "f_request_body": {"request_id": "CHI-001"},
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_changing_home",
        "f_status": "succeeded",
        "f_application_type": "changing_home",
        "f_application_status": "Submitted",
        "f_rch_id": "376863288262672",
    }
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_request(
        record_id="9101",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["create_id"] == 9101
    assert result["application_type"] == "changing_home"
    assert result["rch_id"] == "376863288262672"


@pytest.mark.asyncio
async def test_request_status_hides_another_source_system() -> None:
    client = FakeClient()
    client.record = {"id": 9001, "f_source_system": "OTHER"}
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    with pytest.raises(AdapterError, match="request was not found") as exc:
        await service.get_request(
            record_id="9001",
            request_id="transport-1",
            authorization_token="client-token",
        )

    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_request_status_allows_cmtf_native_source() -> None:
    client = FakeClient()
    client.record = {
        "id": 9001,
        "f_source_system": "CMTF",
        "f_request_event": "CREATE",
        "f_api_type": "create_intake_for_new_licence",
        "f_status": "succeeded",
        "f_application_type": "new_licence",
        "f_application_status": "Received",
        "f_intake_id": 8001,
        "f_application_id": 7001,
    }
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_request(
        record_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["create_id"] == 9001
    assert result["application_status"] == "Received"
    assert result["intake_id"] == 8001
    assert result["application_id"] == 7001


@pytest.mark.asyncio
async def test_new_licence_request_excludes_legacy_letters() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9001,
            "f_request_body": {"request_id": "OP-001"},
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_new_licence",
            "f_status": "succeeded",
            "f_application_type": "new_licence",
            "f_office_code": "LORCHE",
            "f_application_status": "Acknowledged",
            "f_intake_id": 8001,
            "f_application_id": 7001,
        },
        {
            "id": 7001,
            "fk_intake_form": 8001,
            "f_office_cd": "LORCHE",
            "createdAt": "2026-09-04T00:00:00Z",
            "updatedAt": "2026-09-04T00:00:01Z",
            "f_approval_status": "15",
            "f_service_type": "1",
            "f_is_rcsv": False,
            "f_beds_nursing": 0,
            "f_comments": "Internal review comment",
            "f_other_information": "Internal note",
            "f_remarks": "Officer remark",
            "f_letter_attachments": [
                {
                    "id": 601,
                    "f_letter_type": "a",
                    "f_sendtime": "2026-09-08T10:00:00Z",
                    "fk_senduser": 12,
                    "f_attachment": [
                        {
                            "id": 501,
                            "filename": "acknowledgement.pdf",
                            "mimetype": "application/pdf",
                        }
                    ],
                },
                {
                    "id": 602,
                    "f_letter_type": "b",
                    "f_sendtime": None,
                    "f_attachment": [
                        {
                            "id": 502,
                            "filename": "draft.pdf",
                            "mimetype": "application/pdf",
                        }
                    ],
                },
            ],
            "f_intake_form": {
                "id": 8001,
                "f_approval_status": "4",
                "createdById": 12,
                "fk_task_owner": 45,
                "fk_task_owner_post": "S(LR)1",
                "fk_intake_source": 70,
                "f_source_other": "Internal routing",
                "f_severity": "2",
                "f_activity": [
                    {
                        "id": 801,
                        "f_activity": "Submitted",
                        "f_activity_status": "completed",
                        "f_attachments": [],
                    }
                ],
            },
            "f_licence_contact_person": [
                {"id": 901, "f_full_name_en": "Submitted Contact"}
            ],
            "f_licence_app_premise": [
                {
                    "id": 801,
                    "f_premise_type": "0",
                    "f_location": "1/F",
                    "f_address_self_owned": {
                        "id": 802,
                        "f_fullname_en": "1 Test Road",
                    },
                }
            ],
            "f_documents_submitted": [
                {
                    "id": 701,
                    "f_status": "1",
                    "f_details": [],
                    "f_document_checklist": {
                        "id": 601,
                        "f_position_code": "LORCHE_NLA_001",
                    },
                    "f_lastest_files": [{"id": 501, "filename": "submitted.pdf"}],
                }
            ],
            "f_attachments_of_rchs": [
                {"id": 503, "filename": "standalone.pdf"}
            ],
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["office_code"] == "LORCHE"
    assert result["request_id"] == "OP-001"
    assert result["create_id"] == "9001"
    assert result["application_type"] == {
        "value": "new_licence",
        "label": "New Licence Applications",
    }
    assert result["status"] == "Acknowledged"
    assert set(result["application_data"]) == {"form_data"}
    part_2 = result["application_data"]["form_data"]["part_2"]
    assert part_2["is_rcsv"] is False
    assert part_2["nursing_home_places"] == 0
    assert result["application_data"]["form_data"]["part_5"]["checklist"] == [
        {
            "position_code": "LORCHE_NLA_001",
            "attachment_id": 501,
        }
    ]
    assert "attachment_ids" not in result["application_data"]["form_data"]["part_5"]
    assert "attachments" not in result["application_data"]["form_data"]["part_5"]
    assert "comments" not in result["application_data"]["form_data"]["part_5"]
    assert "other_information" not in result["application_data"]["form_data"]["part_5"]
    assert "remarks" not in result["application_data"]["form_data"]["part_5"]
    assert "intake" not in result["application_data"]
    assert not _contains_native_id(result["application_data"])
    case_summary = result["application_data"]["form_data"]["case_summary"]
    assert case_summary["office_code"] == "LORCHE"
    assert not {
        "submitter_user_id",
        "task_owner_user_id",
        "task_owner_post_code",
        "source_id",
        "source_other",
        "severity",
    }.intersection(case_summary)
    assert "letter_attachments" not in result["application_data"]
    part_3 = result["application_data"]["form_data"]["part_3"]
    assert part_3["rch_business_status"] == "1"
    approval_only = deepcopy(result["application_data"])
    approval_only["form_data"]["part_3"].pop("rch_business_status")
    assert not _contains_status_field(approval_only)
    assert "letter_attachments" not in result
    assert not any(
        append.startswith("f_letter_attachments")
        for append in client.calls[1]["appends"]
    )
    assert client.calls[0] == {
        "collection": "t_api_request_staging",
        "record_id": "9001",
        "request_id": "transport-1",
        "authorization_token": "client-token",
    }
    assert client.calls[1]["collection"] == "t_licence_app"
    assert client.calls[1]["record_id"] == 7001


@pytest.mark.asyncio
async def test_new_licence_request_allows_cmtf_native_source() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9001,
            "f_source_system": "CMTF",
            "f_api_type": "create_intake_for_new_licence",
            "f_status": "succeeded",
            "f_application_type": "new_licence",
            "f_office_code": "LORCHD",
            "f_application_status": "Received",
            "f_intake_id": 8001,
            "f_application_id": 7001,
        },
        {"id": 7001, "f_office_cd": "LORCHD", "fk_intake_form": 8001},
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9001",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["office_code"] == "LORCHD"
    assert result["application_type"] == {
        "value": "new_licence",
        "label": "New Licence Applications",
    }
    assert result["status"] == "Received"
    assert result["request_id"] is None
    assert result["create_id"] == "9001"
    case_summary = result["application_data"]["form_data"]["case_summary"]
    assert case_summary["office_code"] == "LORCHD"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "accepted_status",
    ["queued", "submitted", "processing", "needs_review", "succeeded"],
)
async def test_public_query_uses_latest_accepted_update_request_id(
    accepted_status: str,
) -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9001,
            "f_request_body": {"request_id": "OP-CREATE-001"},
            "f_source_system": "OP",
            "f_request_event": "CREATE",
            "f_api_type": "create_intake_for_new_licence",
            "f_application_type": "new_licence",
            "f_application_status": "Accepted",
            "f_application_id": 7001,
        },
        {"id": 7001, "f_office_cd": "LORCHE"},
    ]
    client.staging_update_rows = [
        {
            "id": 9002,
            "f_request_body": {"request_id": "OP-UPDATE-001"},
            "f_source_system": "OP",
            "f_request_event": "UPDATE",
            "f_parent_create_id": "9001",
            "f_api_type": "update_new_licence_data",
            "f_status": "succeeded",
        },
        {
            "id": 9003,
            "f_request_body": {"request_id": "OP-UPDATE-002"},
            "f_source_system": "OP",
            "f_request_event": "UPDATE",
            "f_parent_create_id": "9001",
            "f_api_type": "update_new_licence_data",
            "f_status": accepted_status,
        },
        {
            "id": 9004,
            "f_request_body": {"request_id": "OP-UPDATE-FAILED"},
            "f_source_system": "OP",
            "f_request_event": "UPDATE",
            "f_parent_create_id": "9001",
            "f_api_type": "update_new_licence_data",
            "f_status": "failed",
        },
        {
            "id": 9005,
            "f_request_body": {"request_id": "OTHER-APPLICATION"},
            "f_source_system": "OP",
            "f_request_event": "UPDATE",
            "f_parent_create_id": "9999",
            "f_api_type": "update_new_licence_data",
            "f_status": "succeeded",
        },
    ]

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9001", request_id="transport-1", authorization_token="client-token"
    )

    assert result["request_id"] == "OP-UPDATE-002"
    assert result["create_id"] == "9001"
    assert result["status"] == "Accepted"
    case_summary = result["application_data"]["form_data"]["case_summary"]
    assert case_summary["office_code"] == "LORCHE"
    history_call = client.calls[-1]
    assert history_call["collection"] == "t_api_request_staging"
    assert history_call["authorization_token"] == "client-token"
    assert history_call["sort"] == ("-id",)
    assert history_call["page_size"] == 1


@pytest.mark.asyncio
async def test_public_query_keeps_create_request_id_if_updates_not_accepted() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9001,
            "f_request_body": {"request_id": "OP-CREATE-001"},
            "f_source_system": "OP",
            "f_request_event": "CREATE",
            "f_api_type": "create_intake_for_new_licence",
            "f_application_type": "new_licence",
            "f_application_status": "Received",
            "f_application_id": 7001,
        },
        {"id": 7001, "f_office_cd": "LORCHE"},
    ]
    client.staging_update_rows = [
        {
            "id": 9002 + index,
            "f_request_body": {"request_id": f"OP-UPDATE-{status}"},
            "f_source_system": "OP",
            "f_request_event": "UPDATE",
            "f_parent_create_id": "9001",
            "f_api_type": "update_new_licence_data",
            "f_status": status,
        }
        for index, status in enumerate(
            ("admission_pending", "missing_required", "invalid_request", "failed")
        )
    ]

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9001", request_id="transport-1", authorization_token="client-token"
    )

    assert result["request_id"] == "OP-CREATE-001"
    assert result["status"] == "Received"


@pytest.mark.asyncio
async def test_new_licence_request_fails_if_application_was_not_backfilled() -> None:
    client = FakeClient()
    client.record = {
        "id": 9001,
        "f_request_body": {"request_id": "OP-001"},
        "f_source_system": "OP",
        "f_api_type": "create_intake_for_new_licence",
        "f_status": "processing",
        "f_application_type": "new_licence",
        "f_office_code": "LORCHD",
        "f_application_status": "Received",
        "f_intake_id": None,
        "f_application_id": None,
    }
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    with pytest.raises(AdapterError) as exc:
        await service.get_new_licence_request(
            create_id="9001",
            request_id="transport-1",
            authorization_token="client-token",
        )

    assert exc.value.status_code == 502
    assert exc.value.code == "upstream_error"
    assert len(client.calls) == 1


@pytest.mark.asyncio
async def test_new_licence_request_rejects_an_update_record_id() -> None:
    client = FakeClient()
    client.record = {
        "id": 9002,
        "f_source_system": "OP",
        "f_api_type": "update_new_licence_data",
        "f_application_type": "new_licence",
    }
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    with pytest.raises(AdapterError, match="request was not found") as exc:
        await service.get_new_licence_request(
            create_id="9002",
            request_id="transport-1",
            authorization_token="client-token",
        )

    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_licence_renewal_query_hides_internal_case_summary_fields() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9204,
            "f_request_body": {"request_id": "LRN-QUERY-001"},
            "f_source_system": "OP",
            "f_api_type": "create_licence_renewal",
            "f_application_type": "licence_renewal",
            "f_office_code": "LORCHE",
            "f_application_status": "Received",
            "f_application_id": 7006,
            "f_rch_id": 3001,
        },
        {
            "id": 7006,
            "f_office_cd": "LORCHE",
            "fk_renewal_home_record_id": 3001,
            "f_renewal_home_record": {
                "id": 3001,
                "f_rch_no": "L0001",
                "f_final_o_no": "PE0001",
            },
            "f_intake_form": {
                "id": 8002,
                "createdById": 12,
                "fk_task_owner": 45,
                "f_severity": "2",
            },
            "f_attachments_of_rchs": [{"id": 501}],
            "f_comments": "Internal renewal approval note",
            "f_other_information": "Internal routing detail",
            "f_remarks": "Officer review remark",
        },
    ]
    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9204", request_id="transport-lrn", authorization_token="client"
    )

    case_summary = result["application_data"]["form_data"]["case_summary"]
    assert result["request_id"] == "LRN-QUERY-001"
    assert result["create_id"] == "9204"
    assert case_summary["office_code"] == "LORCHE"
    assert case_summary["lorche_d_no"] == "L0001"
    assert case_summary["p_no"] == "PE0001"
    assert "submitter_user_id" not in case_summary
    assert "task_owner_user_id" not in case_summary
    assert "severity" not in case_summary
    part_5 = result["application_data"]["form_data"]["part_5"]
    assert not {
        "attachments",
        "attachment_ids",
        "comments",
        "other_information",
        "remarks",
    } & part_5.keys()


@pytest.mark.asyncio
@pytest.mark.parametrize("keep_submitted", [True, False])
async def test_licence_renewal_query_omits_cleared_checklist_positions(
    keep_submitted: bool,
) -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9205,
            "f_request_body": {"request_id": "LRN-QUERY-CLEARED"},
            "f_source_system": "OP",
            "f_api_type": "create_licence_renewal",
            "f_application_type": "licence_renewal",
            "f_office_code": "LORCHE",
            "f_application_status": "Accepted",
            "f_application_id": 7007,
            "f_rch_id": 3001,
        },
        {
            "id": 7007,
            "f_office_cd": "LORCHE",
            "fk_renewal_home_record_id": 3001,
            "f_renewal_home_record": {"id": 3001, "f_rch_no": "L0001"},
        },
    ]
    client.rows = [
        {
            "id": 41,
            "f_is_checked": keep_submitted,
            "f_document_checklist": {"id": 81, "f_position_code": "KEEP"},
            "f_lastest_files": [{"id": 101, "filename": "keep.pdf"}],
        },
        {
            "id": 42,
            "f_is_checked": False,
            "f_document_checklist": {"id": 82, "f_position_code": "CLEARED"},
            "f_lastest_files": [{"id": 102, "filename": "old.pdf"}],
        },
        {
            "id": 43,
            "f_is_checked": True,
            "f_document_checklist": {"id": 83, "f_position_code": "NO_FILE"},
            "f_lastest_files": [],
        },
    ]

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9205", request_id="transport-lrn", authorization_token="client"
    )

    expected = (
        [{"position_code": "KEEP", "attachment_id": 101}]
        if keep_submitted
        else []
    )
    assert result["application_data"]["form_data"]["part_5"]["checklist"] == expected


@pytest.mark.asyncio
async def test_intake_application_filter_resolves_fk_before_deep_appends() -> None:
    client = FakeClient()
    client.queued_results = [
        {
            "data": [{"id": 7001, "fk_intake_form": 8001}],
            "meta": {"count": 1, "page": 1, "pageSize": 1},
        },
        {
            "data": [
                {
                    "id": 8001,
                    "f_office_cd": "LORCHE",
                    "f_approval_status": "4",
                    "f_activity": [],
                    "t_new_licence_application": {"id": 7001},
                }
            ],
            "meta": {"count": 1, "page": 1, "pageSize": 20},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_intakes(
        request_id="transport-1",
        authorization_token="client-token",
        office_code="LORCHE",
        status="4",
        intake_id="8001",
        application_id="7001",
        page=1,
        page_size=20,
    )

    assert result["data"][0]["intake_id"] == 8001
    assert client.calls[0] == {
        "collection": "t_licence_app",
        "request_id": "transport-1",
        "authorization_token": "client-token",
        "filters": {"id": {"$eq": "7001"}},
        "page": 1,
        "page_size": 1,
        "sort": (),
    }
    assert client.calls[1]["collection"] == "t_intake_form"
    assert client.calls[1]["filters"] == {
        "$and": [
            {"f_office_cd": {"$eq": "LORCHE"}},
            {"f_approval_status": {"$eq": "4"}},
            {"id": {"$eq": 8001}},
        ]
    }
    assert all(
        "t_new_licence_application.id" not in clause
        for clause in client.calls[1]["filters"]["$and"]
    )


@pytest.mark.asyncio
async def test_intake_application_filter_returns_empty_for_mismatched_intake() -> None:
    client = FakeClient()
    client.queued_results = [
        {
            "data": [{"id": 7001, "fk_intake_form": 8001}],
            "meta": {"count": 1, "page": 1, "pageSize": 1},
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_intakes(
        request_id="transport-1",
        authorization_token="client-token",
        office_code=None,
        status=None,
        intake_id="8002",
        application_id="7001",
        page=3,
        page_size=10,
    )

    assert result["data"] == []
    assert result["meta"] == {
        "count": 0,
        "page": 3,
        "pageSize": 10,
        "totalPage": 0,
    }
    assert [call["collection"] for call in client.calls] == [
        "t_licence_app",
        "fields",
    ]


@pytest.mark.asyncio
async def test_intake_filter_is_empty_when_application_missing() -> None:
    client = FakeClient()
    client.queued_results = [
        {
            "data": [],
            "meta": {"count": 0, "page": 1, "pageSize": 1},
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_intakes(
        request_id="transport-1",
        authorization_token="client-token",
        office_code="LORCHE",
        status="4",
        intake_id=None,
        application_id="missing-app",
        page=1,
        page_size=20,
    )

    assert result["data"] == []
    assert result["meta"]["count"] == 0
    assert [call["collection"] for call in client.calls] == [
        "t_licence_app",
        "fields",
    ]


@pytest.mark.asyncio
async def test_application_query_uses_public_form_shape_and_gateway_downloads() -> None:
    client = FakeClient()
    client.rows = [
        {
            "id": 7001,
            "fk_intake_form": 8001,
            "f_office_cd": "LORCHE",
            "f_approval_status": "6",
            "f_rch_name_en": "Test RCH",
            "f_rch_address": {
                "id": 6001,
                "f_region_en": {"f_code": "0"},
                "f_district_name_en": {"f_code": "C"},
                "f_sub_district_en": {"f_code": "Admiralty"},
                "f_fullname_en": "1 Test Road",
            },
            "f_attachments_of_rchs": [
                {
                    "id": 501,
                    "filename": "application.pdf",
                    "mimetype": "application/pdf",
                }
            ],
            "f_letter_attachments": [
                {
                    "id": 601,
                    "f_letter_type": "a",
                    "f_sendtime": "2026-09-08T10:00:00Z",
                    "fk_senduser": 12,
                    "f_attachment": [
                        {
                            "id": 502,
                            "title": "Acknowledgement Letter",
                            "filename": "acknowledgement-letter.pdf",
                            "size": 2048,
                            "mimetype": "application/pdf",
                            "createdAt": "2026-09-08T09:59:00Z",
                        }
                    ],
                },
                {
                    "id": 602,
                    "f_letter_type": "a",
                    "f_sendtime": "2026-09-09T10:00:00Z",
                    "fk_senduser": 13,
                    "f_attachment": [
                        {
                            "id": 503,
                            "title": "Acknowledgement Letter (reissued)",
                            "filename": "acknowledgement-letter-v2.pdf",
                            "size": 3072,
                            "mimetype": "application/pdf",
                            "createdAt": "2026-09-09T09:59:00Z",
                        }
                    ],
                },
                {
                    "id": 603,
                    "f_letter_type": "b",
                    "f_sendtime": None,
                    "f_attachment": [
                        {
                            "id": 504,
                            "filename": "confirmation-draft.pdf",
                            "mimetype": "application/pdf",
                        }
                    ],
                },
                {
                    "id": 604,
                    "f_letter_type": "c",
                    "f_sendtime": "2026-09-10T10:00:00Z",
                    "f_attachment": [],
                },
                {
                    "id": 605,
                    "f_letter_type": "b",
                    "f_sendtime": "2026-09-09T20:00:00+08:00",
                    "fk_senduser": 14,
                    "f_attachment": [
                        {
                            "id": 505,
                            "filename": "confirmation.pdf",
                            "mimetype": "application/pdf",
                        }
                    ],
                },
                {
                    "id": 606,
                    "f_letter_type": "c",
                    "f_sendtime": "2026-09-11T10:00:00Z",
                    "f_attachment": [{}],
                },
            ],
            "f_intake_form": {
                "id": 8001,
                "f_approval_status": "4",
                "f_intake_no": "INT-1",
                "f_activity": [],
            },
            "f_licence_contact_person": [],
            "f_licence_app_premise": [],
            "f_documents_submitted": [],
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_applications(
        request_id="transport-1",
        authorization_token="client-token",
        office_code="LORCHE",
        status="6",
        intake_id="8001",
        application_id="7001",
        page=1,
        page_size=20,
    )

    application = result["data"][0]
    assert application["application_status"] == {
        "value": "6",
        "label": "Assigning Inspection Teams",
    }
    assert application["intake"]["intake_status"] == {
        "value": "4",
        "label": "Completed",
    }
    assert application["form_data"]["part_2"]["address"]["region_code"] == "0"
    assert application["form_data"]["part_5"]["attachment_ids"] == [501]
    attachment = application["form_data"]["part_5"]["attachments"][0]
    assert attachment["download_url"] == "/v1/files/501"
    letters = application["letter_attachments"]
    assert [item["letter_attachment_id"] for item in letters] == [605, 602, 601]
    assert letters[0]["letter_category"] == {
        "value": "b",
        "label": "Confirmation Letter",
    }
    assert letters[0]["send_time"] == "2026-09-09T20:00:00+08:00"
    assert letters[0]["sent_by_user_id"] == 14
    assert letters[0]["is_latest"] is True
    assert letters[0]["attachment_ids"] == [505]
    assert letters[1]["letter_category"] == {
        "value": "a",
        "label": "Acknowledgement Letter",
    }
    assert letters[1]["send_time"] == "2026-09-09T10:00:00Z"
    assert letters[1]["sent_by_user_id"] == 13
    assert letters[1]["is_latest"] is True
    assert letters[1]["attachment_ids"] == [503]
    assert letters[1]["attachments"][0]["download_url"] == "/v1/files/503"
    assert letters[2]["sent_by_user_id"] == 12
    assert letters[2]["is_latest"] is False
    assert letters[2]["attachment_ids"] == [502]
    assert letters[2]["attachments"][0]["download_url"] == "/v1/files/502"
    assert "f_letter_attachments" in client.calls[0]["appends"]
    assert "f_letter_attachments.f_attachment" in client.calls[0]["appends"]
    assert client.calls[0]["filters"] == {
        "$and": [
            {"f_office_cd": {"$eq": "LORCHE"}},
            {"f_approval_status": {"$eq": "6"}},
            {"fk_intake_form": {"$eq": "8001"}},
            {"id": {"$eq": "7001"}},
        ]
    }


@pytest.mark.asyncio
async def test_checklist_catalog_returns_only_supported_nla_positions() -> None:
    client = FakeClient()
    client.catalog_rows = [
        {
            "id": 10,
            "parentId": None,
            "f_item_type": "1",
            "f_active": True,
            "f_name_en": "Documents",
            "f_name_cn": "文件",
        },
        {
            "id": 11,
            "parentId": 10,
            "f_item_type": "2",
            "f_active": True,
            "f_use_for": ["t_licence_app"],
            "f_checklist_code": "LORCHE_STAGE2",
            "f_position_code": "LORCHE_STAGE2:ROW:35",
            "f_source_excel_row_no": 35,
            "f_office_code": "LORCHE",
            "f_name_en": "Tenancy agreement",
            "f_name_cn": "租約",
            "f_is_mandatory_default": True,
            "f_sort_order": 8,
        },
        {
            "id": 12,
            "parentId": 10,
            "f_item_type": "2",
            "f_active": True,
            "f_use_for": ["t_other_application"],
            "f_checklist_code": "OTHER",
            "f_source_excel_row_no": 1,
            "f_office_code": "LORCHE",
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_checklist_catalog(
        request_id="transport-1", office_code="LORCHE"
    )

    assert len(result["data"]) == 1
    assert result["data"][0] == {
        "checklist_id": 11,
        "position_code": "LORCHE_STAGE2:ROW:35",
        "name_en": "Tenancy agreement",
        "name_cn": "租約",
        "required": True,
    }
    assert client.calls[0]["filters"] == {
        "$and": [
            {"f_office_code": {"$eq": "LORCHE"}},
            {"f_use_for": {"$anyOf": ["t_licence_app"]}},
            {"f_active": {"$eq": True}},
        ]
    }


@pytest.mark.asyncio
async def test_lorchd_checklist_catalog_uses_persisted_position_code() -> None:
    client = FakeClient()
    client.catalog_rows = [
        {
            "id": 20,
            "parentId": None,
            "f_item_type": "1",
            "f_active": True,
            "f_office_code": "LORCHD",
            "f_use_for": ["t_licence_app"],
            "f_name_cn": "Document Checklist",
        },
        {
            "id": 21,
            "parentId": 20,
            "f_item_type": "2",
            "f_active": True,
            "f_office_code": "LORCHD",
            "f_use_for": ["t_licence_app"],
            "f_checklist_code": None,
            "f_position_code": "LORCHD_APP_FILE_001",
            "f_source_excel_row_no": None,
            "f_name_en": "Application form",
            "f_name_cn": "牌照申請表",
            "f_is_mandatory_default": True,
            "f_sort_order": 171,
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_checklist_catalog(
        request_id="transport-1", office_code="LORCHD"
    )

    assert len(result["data"]) == 1
    assert result["data"][0]["checklist_id"] == 21
    assert result["data"][0]["position_code"] == "LORCHD_APP_FILE_001"
    assert set(result["data"][0]) == {
        "checklist_id", "position_code", "name_en", "name_cn", "required"
    }


@pytest.mark.asyncio
async def test_changing_home_checklist_catalog_filters_chi_use_for() -> None:
    client = FakeClient()
    client.catalog_rows = [
        {
            "id": 31,
            "parentId": 30,
            "f_item_type": "2",
            "f_active": True,
            "f_use_for": ["t_change_home_information_app", "t_licence_app"],
            "f_position_code": "LORCHE_STAGE2:ROW:68",
            "f_office_code": "LORCHE",
            "f_name_en": "Floor Plan",
            "f_name_cn": "平面图",
            "f_is_mandatory_default": True,
            "f_sort_order": 1,
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_checklist_catalog(
        request_id="transport-1",
        office_code="LORCHE",
        application_collection="t_change_home_information_app",
    )

    assert len(result["data"]) == 1
    assert result["data"][0]["position_code"] == "LORCHE_STAGE2:ROW:68"
    assert client.calls[0]["filters"] == {
        "$and": [
            {"f_office_code": {"$eq": "LORCHE"}},
            {"f_use_for": {"$anyOf": ["t_change_home_information_app"]}},
            {"f_active": {"$eq": True}},
        ]
    }


@pytest.mark.asyncio
async def test_changing_home_request_projects_flags_and_home_record() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9101,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_office_code": "LORCHE",
            "f_application_status": "Submitted",
            "f_application_id": 7002,
            "f_rch_id": "376863288262672",
        },
        {
            "id": 7002,
            "fk_home_record": 376863288262672,
            "f_rch_no": "L0043",
            "f_office_cd": "LORCHE",
            "f_rch_name_en": "Test Home",
            "is_change_name": True,
            "is_change_address": False,
            "is_change_operator_or_operating_company": False,
            "is_change_rch_type": False,
            "is_change_maximum_capacity": False,
            "is_aip": False,
            "f_home_record": {"id": 376863288262672, "f_rch_no": "L0043"},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9101",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["application_type"]["value"] == "changing_home"
    assert "home_record_id" not in result["application_data"]
    assert result["application_data"]["form_data"]["is_change_name"] is True
    assert result["application_data"]["form_data"]["case_summary"]["lorche_d_no"] == (
        "L0043"
    )
    assert any(
        call.get("collection") == "t_document_submitted_for_application"
        for call in client.calls
    )


@pytest.mark.asyncio
async def test_changing_home_query_projects_owned_popup_children() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9202,
            "f_request_body": {"request_id": "CHI-QUERY-001"},
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_office_code": "LORCHE",
            "f_application_status": "Accepted",
            "f_application_id": 7004,
            "f_rch_id": 3001,
        },
        {
            "id": 7004,
            "fk_home_record": 3001,
            "f_office_cd": "LORCHE",
            "f_licence_capacity": 95,
            "f_service_type": "1",
            "f_approval_status": "pending_native_approval",
            "f_comments": "Officer approval comment",
            "f_other_information": "Internal routing note",
            "f_remarks": "Officer review remark",
            "f_attachments_of_rchs": [
                {"id": 999, "filename": "unrelated-native-file.pdf", "size": 123}
            ],
            "f_licence_contact_company": {
                "id": 404,
                "f_compnay_name_en": "Example Company",
                "f_rpop_op_app": [{
                    "id": 405,
                    "f_company_registration_identifier_types": 0,
                    "f_legislation_chapter_no": "12",
                }],
                "f_rpop_app_detail_1": {
                    "id": 406,
                    "f_declaration_answer": "Yes",
                },
            },
            "f_licence_contact_person": [{
                "id": 407,
                "f_full_name_en": "Example Operator",
                "f_rpop_app_detail_2": {
                    "id": 408,
                    "f_declaration_answer": "No",
                },
            }],
            "f_home_record": {"id": 3001, "f_rch_no": "L0001"},
            "f_intake_form": {
                "id": 8002,
                "createdById": 12,
                "fk_task_owner": 45,
                "f_severity": "2",
            },
        },
    ]
    client.queued_results = [
        {
            "data": [
                {
                    "id": 8101,
                    "f_document_checklist": {
                        "id": 55,
                        "f_position_code": "LORCHE_APP_FILE_001",
                    },
                    "f_lastest_files": [
                        {"id": 501, "filename": "checklist.pdf", "size": 10}
                    ],
                }
            ],
            "meta": {"count": 1},
        }
    ]
    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9202", request_id="transport-chi", authorization_token="client"
    )
    part_3 = result["application_data"]["form_data"]["part_3"]
    assert result["request_id"] == "CHI-QUERY-001"
    assert result["create_id"] == "9202"
    assert result["status"] == "Accepted"
    assert part_3["rch_business_status"] == "1"
    assert "application_status" not in result["application_data"]
    assert result["application_data"]["form_data"]["part_2"]["max_capacity"] == 95
    case_summary = result["application_data"]["form_data"]["case_summary"]
    assert case_summary["office_code"] == "LORCHE"
    assert case_summary["lorche_d_no"] == "L0001"
    assert "submitter_user_id" not in case_summary
    assert "task_owner_user_id" not in case_summary
    assert "severity" not in case_summary
    assert part_3["company"]["registration_identifier_types"] == ["0"]
    assert part_3["company"]["legislation_chapter_no"] == "12"
    assert part_3["company"]["declaration_answers"] == {"1": "Yes"}
    assert "id" not in part_3["operator"]
    assert part_3["operator"]["declaration_answers"] == {"2": "No"}
    assert part_3["operators"] == [part_3["operator"]]
    assert part_3["personnel"][0]["declaration_answers"] == {"2": "No"}
    part_5 = result["application_data"]["form_data"]["part_5"]
    assert part_5["checklist"] == [
        {"position_code": "LORCHE_APP_FILE_001", "attachment_id": 501}
    ]
    assert not {
        "attachments",
        "attachment_ids",
        "comments",
        "other_information",
        "remarks",
    } & part_5.keys()
    assert "f_licence_contact_company.f_rpop_op_app" in client.calls[1]["appends"]


@pytest.mark.asyncio
async def test_changing_home_query_does_not_choose_an_arbitrary_operator() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9203,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_changing_home",
            "f_application_type": "changing_home",
            "f_office_code": "LORCHE",
            "f_application_status": "Accepted",
            "f_application_id": 7005,
            "f_rch_id": 3001,
        },
        {
            "id": 7005,
            "fk_home_record": 3001,
            "f_office_cd": "LORCHE",
            "f_licence_contact_person": [
                {"id": 407, "f_full_name_en": "First"},
                {"id": 409, "f_full_name_en": "Second"},
            ],
            "f_home_record": {"id": 3001, "f_rch_no": "L0001"},
        },
    ]
    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9203", request_id="transport-chi", authorization_token="client"
    )
    part_3 = result["application_data"]["form_data"]["part_3"]
    assert part_3["operator"] is None
    assert part_3["operators"] == part_3["personnel"]
    assert all("id" not in person for person in part_3["operators"])
    assert [person["full_name_en"] for person in part_3["personnel"]] == [
        "First",
        "Second",
    ]


@pytest.mark.asyncio
async def test_self_withdraw_checklist_catalog_filters_use_for() -> None:
    client = FakeClient()
    client.catalog_rows = [
        {
            "id": 41,
            "parentId": 40,
            "f_item_type": "2",
            "f_active": True,
            "f_use_for": ["t_self_withdraw_licence_application"],
            "f_position_code": "LORCHE_SELF_WITHDRAW_001",
            "f_office_code": "LORCHE",
            "f_name_en": "Written Authorisation for Representative of Applicant",
            "f_name_cn": "Written Authorisation for Representative of Applicant",
            "f_is_mandatory_default": False,
            "f_sort_order": 274,
        }
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.list_checklist_catalog(
        request_id="transport-1",
        office_code="LORCHE",
        application_collection="t_self_withdraw_licence_application",
    )

    assert len(result["data"]) == 1
    assert result["data"][0]["position_code"] == "LORCHE_SELF_WITHDRAW_001"


@pytest.mark.asyncio
async def test_self_withdraw_request_projects_home_record_and_reason() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9201,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_self_withdraw",
            "f_application_type": "self_withdraw",
            "f_office_code": "LORCHE",
            "f_application_status": "Submitted",
            "f_application_id": 7003,
            "f_rch_id": "376863288262672",
        },
        {
            "id": 7003,
            "fk_home_record_id": 376863288262672,
            "f_office_cd": "LORCHE",
            "f_closure_workflow_type": "self",
            "f_reason_for_closure": "0",
            "f_comments": "Phase D",
            "f_intake_form": {"id": 8003, "f_office_cd": "LORCHE"},
        },
        {
            "id": 376863288262672,
            "f_rch_no": "L0043",
            "f_office_cd": "LORCHE",
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9201",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["application_type"]["value"] == "self_withdraw"
    assert "home_record_id" not in result["application_data"]
    assert result["application_data"]["form_data"]["reason_for_closure"] == "0"
    assert "comments" not in result["application_data"]["form_data"]
    assert result["application_data"]["form_data"]["case_summary"]["lorche_d_no"] == (
        "L0043"
    )


@pytest.mark.asyncio
async def test_specific_hour_request_projects_home_record() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9301,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_specific_hour",
            "f_application_type": "specific_hour",
            "f_office_code": "LORCHE",
            "f_application_status": "Submitted",
            "f_application_id": 7004,
            "f_rch_id": "376863288262672",
        },
        {
            "id": 7004,
            "fk_home_record": 376863288262672,
            "f_application_detail": "approval",
            "f_comments": "Phase E",
            "f_intake_form": {"id": 8004, "f_office_cd": "LORCHE"},
            "f_home_record": {"id": 376863288262672, "f_rch_no": "L0043"},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9301",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["application_type"]["value"] == "specific_hour"
    assert "home_record_id" not in result["application_data"]
    assert result["application_data"]["form_data"]["application_detail"] == (
        "approval"
    )


@pytest.mark.asyncio
async def test_change_home_manager_request_projects_child_overlay() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9401,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_change_home_manager",
            "f_application_type": "change_home_manager",
            "f_office_code": "LORCHE",
            "f_application_status": "Submitted",
            "f_application_id": 7005,
            "f_rch_id": "376863288262672",
        },
        {
            "id": 7005,
            "fk_home_record_id": 376863288262672,
            "f_office_cd": "LORCHE",
            "f_change_type": "home_manager",
            "f_remarks": "Phase F",
            "f_intake_form": {"id": 8005, "f_office_cd": "LORCHE"},
            "f_change_home_manager": {
                "id": 7105,
                "f_proposed_name": "Example Manager",
            },
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9401",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["application_type"]["value"] == "change_home_manager"
    assert "home_record_id" not in result["application_data"]
    assert result["application_data"]["form_data"]["proposed_name"] == (
        "Example Manager"
    )
    form_data = result["application_data"]["form_data"]
    internal = {"change_type", "remarks", "comments", "attachment_ids"}
    assert not internal & form_data.keys()


@pytest.mark.parametrize(
    ("api_type", "application_type", "child_assoc", "business_field", "native_field"),
    [
        (
            "create_intake_for_change_home_manager",
            "change_home_manager",
            "f_change_home_manager",
            "proposed_name",
            "f_proposed_name",
        ),
        (
            "create_intake_for_change_beds",
            "change_beds",
            "f_change_beds",
            "proposed_beds_self_care",
            "f_proposed_beds_self_care",
        ),
        (
            "create_intake_for_change_operation_mode",
            "change_operation_mode",
            "f_change_home_type",
            "proposed_rch_nature_code",
            "fk_proposed_rch_nature",
        ),
        (
            "create_intake_for_change_directors",
            "change_directors",
            "f_change_directors_information",
            "name_en",
            "f_name_eng",
        ),
        (
            "create_intake_for_change_nurse_in_charge",
            "change_nurse_in_charge",
            "f_change_nurse_in_charge",
            "name",
            "f_name",
        ),
    ],
)
@pytest.mark.asyncio
async def test_change_request_omits_internal_notes_but_keeps_business_fields(
    api_type: str,
    application_type: str,
    child_assoc: str,
    business_field: str,
    native_field: str,
) -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9460,
            "f_source_system": "OP",
            "f_api_type": api_type,
            "f_application_type": application_type,
            "f_office_code": "LORCHE",
            "f_application_status": "Accepted",
            "f_application_id": 7060,
        },
        {
            "id": 7060,
            "f_office_cd": "LORCHE",
            "f_change_type": "internal",
            "f_remarks": "Internal review note",
            "f_documents": [{"id": 9}],
            "f_intake_form": {"id": 8060, "f_comments": "Officer comment"},
            child_assoc: {native_field: "client value"},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9460",
        request_id="transport-1",
        authorization_token="client-token",
    )

    form_data = result["application_data"]["form_data"]
    assert form_data[business_field] == "client value"
    internal = {"change_type", "remarks", "comments", "attachment_ids"}
    assert not internal & form_data.keys()


@pytest.mark.parametrize(
    ("api_type", "application_type", "child_assoc"),
    [
        (
            "create_intake_for_change_home_manager",
            "change_home_manager",
            "f_change_home_manager",
        ),
        ("create_intake_for_change_beds", "change_beds", "f_change_beds"),
        (
            "create_intake_for_change_operation_mode",
            "change_operation_mode",
            "f_change_home_type",
        ),
        (
            "create_intake_for_change_directors",
            "change_directors",
            "f_change_directors_information",
        ),
        (
            "create_intake_for_change_nurse_in_charge",
            "change_nurse_in_charge",
            "f_change_nurse_in_charge",
        ),
    ],
)
@pytest.mark.asyncio
async def test_change_requests_do_not_query_or_return_checklist(
    api_type: str,
    application_type: str,
    child_assoc: str,
) -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9450,
            "f_source_system": "OP",
            "f_api_type": api_type,
            "f_application_type": application_type,
            "f_office_code": "LORCHE",
            "f_application_status": "Submitted",
            "f_application_id": 7050,
            "f_rch_id": "376863288262672",
        },
        {
            "id": 7050,
            "fk_home_record_id": 376863288262672,
            "f_office_cd": "LORCHE",
            "f_intake_form": {"id": 8050, "f_office_cd": "LORCHE"},
            "f_home_record": {"id": 376863288262672, "f_rch_no": "L0043"},
            child_assoc: {},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9450",
        request_id="transport-1",
        authorization_token="client-token",
    )

    form_data = result["application_data"]["form_data"]
    assert "checklist" not in form_data
    assert "position_code" not in form_data
    assert "attachment_id" not in form_data
    assert not any(
        call.get("collection") == "t_document_submitted_for_application"
        for call in client.calls
    )


@pytest.mark.asyncio
async def test_prosecution_request_projects_legal_advice() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9501,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_prosecution",
            "f_application_type": "prosecution",
            "f_office_code": "LORCHE",
            "f_application_status": "Submitted",
            "f_application_id": 7006,
            "f_rch_id": "376863288262672",
        },
        {
            "id": 7006,
            "fk_home_record_id": 376863288262672,
            "f_office_cd": "LORCHE",
            "f_result_of_seeking_legal_advice_from_doj": "Go for Prosecution",
            "f_unlicenced_rch": False,
            "f_comments": "Phase G",
            "f_intake_form": {"id": 8006, "f_office_cd": "LORCHE"},
        },
    ]
    service = QueryService(client, "OP")  # type: ignore[arg-type]

    result = await service.get_new_licence_request(
        create_id="9501",
        request_id="transport-1",
        authorization_token="client-token",
    )

    assert result["application_type"]["value"] == "prosecution"
    assert "home_record_id" not in result["application_data"]
    assert result["application_data"]["form_data"]["legal_advice_result"] == (
        "Go for Prosecution"
    )


@pytest.mark.asyncio
async def test_expansion_aip_request_projects_form_and_checklist() -> None:
    client = FakeClient()
    client.queued_records = [
        {
            "id": 9601,
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_expansion_aip",
            "f_application_type": "expansion_aip",
            "f_office_code": "LORCHE",
            "f_application_status": "Accepted",
            "f_application_id": 7007,
            "f_rch_id": 376863288262672,
        },
        {
            "id": 7007,
            "fk_home_record_id": 376863288262672,
            "fk_intake_form": 8007,
            "f_office_cd": "LORCHE",
            "f_title": "0",
            "f_name_eng": "Example Applicant",
            "f_name_chi": "示例申請人",
            "f_authorised_to_apply_by_operator": True,
            "f_means_of_authorisation": "0",
            "f_authorised_name_eng": "Authorised Person",
            "f_hkic_number1": "A123456",
            "f_hkic_number2": "7",
            "f_address_chi_expansion": "香港示例地址",
            "f_address_eng_expansion": "Example Address, Hong Kong",
            "f_tentative_licencing_capacity_expansion": 120,
            "f_existing_area_of_floor_space_expansion": 580.5,
            "f_number_of_beds_expansion": 100,
            "f_approval_status": "internal-only",
            "f_intake_form": {
                "id": 8007,
                "f_intake_no": "INT-AIP-001",
                "f_office_cd": "LORCHE",
                "f_received_date": "2026-09-24",
                "f_severity": "2",
                "fk_intake_source": {"id": 701},
                "f_source_other": "OP portal",
                "createdBy": {"id": 12},
                "fk_task_owner": {"id": 45},
                "fk_task_owner_post": {
                    "id": 99,
                    "f_post_cd": "S(LR)1",
                },
            },
        },
        {
            "id": 376863288262672,
            "f_rch_no": "L0043",
            "f_final_o_no": "PE0177",
        },
    ]
    client.queued_results = [
        {
            "data": [
                {
                    "id": 8101,
                    "f_is_checked": True,
                    "f_document_checklist": {
                        "id": 8201,
                        "f_position_code": "LORCHE_EXPANSION_AIP_001",
                    },
                    "f_lastest_files": [
                        {"id": 8301, "filename": "aip.pdf", "size": 123}
                    ],
                },
                {
                    "id": 8102,
                    "f_is_checked": False,
                    "f_document_checklist": {
                        "id": 8202,
                        "f_position_code": "LORCHE_EXPANSION_AIP_002",
                    },
                    # Historical Latest data on an unchecked row is not a
                    # current public assignment.
                    "f_lastest_files": [
                        {"id": 8302, "filename": "old.pdf", "size": 321}
                    ],
                }
            ],
            "meta": {"count": 1},
        }
    ]

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id="9601",
        request_id="transport-aip",
        authorization_token="client-token",
    )

    assert result["application_type"] == {
        "value": "expansion_aip",
        "label": "Expansion AIP for Licence",
    }
    assert result["status"] == "Accepted"
    data = result["application_data"]
    assert "application_id" not in data
    assert "home_record_id" not in data
    assert "intake" not in data
    assert data["form_data"]["case_summary"] == {
        "office_code": "LORCHE",
        "lorche_d_no": "L0043",
        "p_no": "PE0177",
        "received_date": "2026-09-24",
        "severity": "2",
    }
    assert data["form_data"]["part_1"]["name_eng"] == "Example Applicant"
    assert data["form_data"]["part_2"] == {
        "address_chi_expansion": "香港示例地址",
        "address_eng_expansion": "Example Address, Hong Kong",
        "tentative_licencing_capacity_expansion": 120,
        "tentative_area_of_floor_space_expansion": 580.5,
        "number_of_beds_expansion": 100,
    }
    assert data["form_data"]["part_3"]["checklist"] == [
        {
            "position_code": "LORCHE_EXPANSION_AIP_001",
            "attachment_id": 8301,
        }
    ]
    assert "letter_attachments" not in data
    assert "f_approval_status" not in str(data)


@pytest.mark.asyncio
async def test_expansion_aip_checklist_catalog_is_compact() -> None:
    client = FakeClient()
    client.catalog_rows = [
        {
            "id": 8401,
            "f_item_type": "2",
            "f_active": True,
            "f_use_for": ["t_expansion_aip_for_licence"],
            "f_position_code": "LORCHE_EXPANSION_AIP_001",
            "f_office_code": "LORCHE",
            "f_name_en": "Authorisation document",
            "f_name_cn": "授權文件",
            "f_is_mandatory_default": True,
        }
    ]

    result = await QueryService(client, "OP").list_checklist_catalog(
        request_id="transport-aip",
        office_code="LORCHE",
        application_collection="t_expansion_aip_for_licence",
    )

    assert result == {
        "data": [
            {
                "checklist_id": 8401,
                "position_code": "LORCHE_EXPANSION_AIP_001",
                "name_en": "Authorisation document",
                "name_cn": "授權文件",
                "required": True,
            }
        ]
    }
