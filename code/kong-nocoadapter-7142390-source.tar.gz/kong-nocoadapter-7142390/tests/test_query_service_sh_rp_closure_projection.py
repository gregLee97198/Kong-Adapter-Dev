from __future__ import annotations

from typing import Any

import pytest

from app.query_service import QueryService


class ScriptedClient:
    def __init__(
        self,
        *,
        records: list[dict[str, Any]],
        list_results: list[dict[str, Any]],
    ) -> None:
        self.records = list(records)
        self.list_results = list(list_results)
        self.get_calls: list[dict[str, Any]] = []
        self.list_calls: list[dict[str, Any]] = []

    async def get_record(self, **kwargs: Any) -> dict[str, Any]:
        self.get_calls.append(kwargs)
        return self.records.pop(0)

    async def list_records(self, **kwargs: Any) -> dict[str, Any]:
        self.list_calls.append(kwargs)
        return self.list_results.pop(0)


def empty_list_result() -> dict[str, Any]:
    return {"data": [], "meta": {"count": 0, "page": 1, "pageSize": 1000}}


@pytest.mark.asyncio
async def test_specific_hour_query_returns_sorted_nested_business_tree() -> None:
    application = {
        "id": 7001,
        "fk_home_record": 6001,
        "f_intake_form": {
            "id": 8001,
            "f_intake_no": "E-8001",
            "f_office_cd": "LORCHE",
            "createdBy": {"id": 12},
            "f_received_date": "2026-09-22",
            "f_severity": "0",
            "fk_intake_source": {"id": 701},
            "f_source_other": "OP",
            "fk_task_owner": {"id": 45},
            "fk_task_owner_post": {"f_post_cd": "S(LR)1"},
        },
        "f_home_record": {
            "id": 6001,
            "f_rch_no": "L0001",
            "f_final_o_no": "P0001",
        },
        "f_specific_hour_set_count": "1",
        "f_warning_acknowledged": True,
        "f_comments": "Internal approval note",
        "f_specific_hour_options": [
            {
                "id": 12,
                "f_specific_hour_set_no": "1",
                "f_section": "only_holiday",
                "f_specific_hour_staffings": [],
            },
            {
                "id": 11,
                "f_specific_hour_set_no": "0",
                "f_section": "workday_and_holiday",
                "f_specific_hour_staffings": [
                    {
                        "id": 22,
                        "f_sort_order": 2,
                        "f_staff_type_id": {"f_staff_code": "CW"},
                        "f_duty_description": "care work",
                        "f_staff_ratio_requirement": "1:20",
                        "f_minimum_required_hours": "2.0",
                        "f_specific_hour_time_rows": [
                            {
                                "id": 32,
                                "f_sort_order": 2,
                                "f_work_hour_from": "18:00:00",
                                "f_work_hour_to": "20:00:00",
                                "f_duration_hours": "2.0",
                                "f_remark": "evening",
                            },
                            {
                                "id": 31,
                                "f_sort_order": 1,
                                "f_work_hour_from": "08:00:00",
                                "f_work_hour_to": "10:00:00",
                                "f_duration_hours": "2.0",
                                "f_remark": "morning",
                            },
                        ],
                    },
                    {
                        "id": 21,
                        "f_sort_order": 1,
                        "f_staff_type_id": {"f_staff_code": "AW"},
                        "f_duty_description": None,
                        "f_staff_ratio_requirement": "1:40",
                        "f_minimum_required_hours": "1.0",
                        "f_specific_hour_time_rows": [],
                    },
                ],
            },
        ],
    }
    client = ScriptedClient(
        records=[
            {
                "id": 9001,
                "f_source_system": "OP",
                "f_api_type": "create_intake_for_specific_hour",
                "f_application_type": "specific_hour",
                "f_application_status": "Accepted",
                "f_application_id": 7001,
                "f_rch_id": 6001,
            },
            application,
        ],
        list_results=[empty_list_result()],
    )

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id=9001,
        request_id="trace-sh",
        authorization_token="client-token",
    )

    options = result["application_data"]["form_data"]["specific_hour_options"]
    assert [item["set_no"] for item in options] == ["0", "1"]
    assert [item["staff_type_code"] for item in options[0]["staffings"]] == [
        "AW",
        "CW",
    ]
    cw_rows = options[0]["staffings"][1]["time_rows"]
    assert [item["remark"] for item in cw_rows] == ["morning", "evening"]
    assert options[0]["staffings"][1]["minimum_required_hours"] == "2.0"
    assert result["application_data"]["form_data"]["warning_acknowledged"] is True
    assert "comments" not in result["application_data"]["form_data"]
    assert result["application_data"]["form_data"]["case_summary"] == {
        "office_code": "LORCHE",
        "lorche_d_no": "L0001",
        "p_no": "P0001",
        "received_date": "2026-09-22",
        "severity": "0",
    }
    assert client.get_calls[1]["appends"] == (
        "f_intake_form",
        "f_intake_form.createdBy",
        "f_intake_form.fk_intake_source",
        "f_intake_form.fk_task_owner",
        "f_intake_form.fk_task_owner_post",
        "f_home_record",
        "f_specific_hour_options",
        "f_specific_hour_options.f_specific_hour_staffings",
        "f_specific_hour_options.f_specific_hour_staffings.f_staff_type_id",
        "f_specific_hour_options.f_specific_hour_staffings.f_specific_hour_time_rows",
    )


@pytest.mark.asyncio
async def test_rp_query_returns_homes_questions_and_ui_declaration() -> None:
    application = {
        "id": 7002,
        "fk_home_record_id": 6002,
        "f_office_code": "LORCHD",
        "fk_intake": {"id": 8002, "f_intake_no": "D-8002"},
        "f_home_record": {
            "id": 6002,
            "f_rch_no": "D0002",
            "f_final_o_no": "PD0002",
        },
        "p3_Email": "page@example.test",
        "f_rp_email": "legacy@example.test",
        "f_ceased_status": "will_cease",
        "f_comments": "Internal approval note",
        "f_t_rp_currently_appointed": [
            {"id": 2, "f_rch_no": "L0002", "f_rch_name": "Second"},
            {"id": 1, "f_rch_no": "D0001", "f_rch_name": "First"},
        ],
        "f_q1_answer": "yes",
        "f_q1_case_status": "being_prosecuted_currently",
        "f_q1_prosecuting_authority": "Authority 1",
        "f_fxeb5nzxq5f": "Place 1",
        "f_q1_offence": "Offence 1",
        "f_q1_conviction_date": "2026-09-01",
        "f_q4_answer": "no",
        "q2being_and_has": None,
        "f_q3_answer": "no",
        "f_q3_case_status": None,
        "q4_": "no",
        "q4being_has": None,
        "f_q5_answer": "yes",
        "f_q5_date": "2026-09-02",
        "f_q5_lorche_d_no": "D0099",
        "f_q5_rch_name": "Prior Home",
        "f_q5_reasons": "Reason",
        "f_q6_answer": "no",
        "f_q7_answer": "yes",
        "f_q7_adjudication_date": "2026-09-03",
        "f_q7_court": "Repayment proposal",
        "f_q8_answer": "yes",
        "f_q8_company_name_en": "Example Company",
        "f_q8_company_name_zh": "示例公司",
        "f_q8_business_registration_no": "BR-1",
        "f_q8_certificate_incorporation_no": "CI-1",
        "q8Registered_address": "Registered address",
        "f_q8_adjudication_date": "2026-09-04",
        "f_q8_court": "Court 8",
        "p8_checked": True,
        "f_signature_date_of_rp": "2026-09-05",
        "f_signature_date_of_applicant_representative_partner": "2026-09-06",
    }
    client = ScriptedClient(
        records=[
            {
                "id": 9002,
                "f_source_system": "OP",
                "f_api_type": "create_intake_for_rp",
                "f_application_type": "responsible_person",
                "f_application_status": "Accepted",
                "f_application_id": 7002,
                "f_rch_id": 6002,
            },
            application,
        ],
        list_results=[empty_list_result()],
    )

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id=9002,
        request_id="trace-rp",
        authorization_token="client-token",
    )

    form = result["application_data"]["form_data"]
    assert "comments" not in form
    assert form["rp_email"] == "page@example.test"
    assert form["ceased_status"] == "will_cease"
    assert form["currently_appointed_homes"] == [
        {"rch_no": "D0001", "rch_name": "First"},
        {"rch_no": "L0002", "rch_name": "Second"},
    ]
    assert form["other_particulars"]["q1"] == {
        "answer": "yes",
        "case_status": "being_prosecuted_currently",
        "prosecuting_authority": "Authority 1",
        "place_of_proceeding": "Place 1",
        "offence_involved": "Offence 1",
        "hearing_date": "2026-09-01",
        "court": None,
        "place_of_court": None,
        "offence_committed": None,
        "penalty": None,
        "conviction_date": None,
    }
    assert form["other_particulars"]["q5"]["rch_no_and_name"] == "Prior Home"
    assert form["other_particulars"]["q7"] == {
        "answer": "yes",
        "adjudication_date": "2026-09-03",
        "repayment_proposal": "Repayment proposal",
    }
    assert form["other_particulars"]["q8"]["registered_address"] == (
        "Registered address"
    )
    assert form["declaration"] == {
        "acknowledged": True,
        "signature_date_of_rp": "2026-09-05",
        "signature_date_of_applicant_representative_partner": "2026-09-06",
    }
    assert "f_t_rp_currently_appointed" in client.get_calls[1]["appends"]


@pytest.mark.asyncio
async def test_closure_query_exposes_attachments_only_through_checklist() -> None:
    client = ScriptedClient(
        records=[
            {
                "id": 9003,
                "f_source_system": "OP",
                "f_api_type": "create_intake_for_self_withdraw",
                "f_application_type": "self_withdraw",
                "f_application_status": "Accepted",
                "f_application_id": 7003,
                "f_rch_id": 6003,
            },
            {
                "id": 7003,
                "fk_home_record_id": 6003,
                "f_office_cd": "LORCHE",
                "f_intake_form": {"id": 8003, "f_intake_no": "E-8003"},
                "f_written_authorisation_for_representative_of_applicant": [{"id": 91}],
                "f_resident_list": [{"id": 92}],
                "f_relocation_plan_for_residents": [{"id": 93}],
            },
            {"id": 6003, "f_rch_no": "L0003", "f_final_o_no": "P0003"},
        ],
        list_results=[
            {
                "data": [
                    {
                        "id": 81,
                        "f_document_checklist": {
                            "f_position_code": "LORCHE_SELF_WITHDRAW_001"
                        },
                        "f_is_checked": True,
                        "f_lastest_files": [{"id": 94}],
                    }
                ],
                "meta": {"count": 1, "page": 1, "pageSize": 1000},
            }
        ],
    )

    result = await QueryService(client, "OP").get_new_licence_request(
        create_id=9003,
        request_id="trace-closure",
        authorization_token="client-token",
    )

    form = result["application_data"]["form_data"]
    assert form["checklist"] == [
        {
            "position_code": "LORCHE_SELF_WITHDRAW_001",
            "attachment_id": 94,
        }
    ]
    assert "written_authorisation_attachment_ids" not in form
    assert "resident_list_attachment_ids" not in form
    assert "relocation_plan_attachment_ids" not in form
    appends = client.get_calls[1]["appends"]
    assert "f_written_authorisation_for_representative_of_applicant" not in appends
    assert "f_resident_list" not in appends
    assert "f_relocation_plan_for_residents" not in appends
