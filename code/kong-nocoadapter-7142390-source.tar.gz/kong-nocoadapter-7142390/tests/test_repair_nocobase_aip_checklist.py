from __future__ import annotations

import copy
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from repair_nocobase_aip_checklist import (  # noqa: E402
    EXPECTED_CODES,
    USE_FOR,
    RepairError,
    build_repair_plan,
    simulate_plan,
    validate_catalogue,
)


def catalogue_fixture() -> list[dict]:
    rows: list[dict] = [
        {
            "id": 100,
            "parentId": None,
            "f_item_type": "1",
            "f_active": True,
            "f_use_for": [USE_FOR],
            "f_position_code": None,
            "f_name_en": "Expansion AIP documents",
            "f_name_cn": "擴建 AIP 文件",
            "f_sort_order": 1,
        },
        # Unrelated catalogue row proves global collision checks do not depend
        # on the AIP filter.
        {
            "id": 900,
            "parentId": None,
            "f_item_type": "2",
            "f_active": True,
            "f_use_for": ["t_other_application"],
            "f_position_code": "OTHER_001",
            "f_name_en": "Other",
            "f_name_cn": "其他",
            "f_sort_order": 1,
        },
    ]
    for index in range(1, 8):
        rows.append(
            {
                "id": 100 + index,
                "parentId": 100,
                "f_item_type": "2",
                "f_active": True,
                "f_use_for": [USE_FOR],
                "f_position_code": None,
                "f_name_en": f"Expansion AIP document {index}",
                "f_name_cn": f"擴建 AIP 文件 {index}",
                "f_sort_order": index,
            }
        )
    return rows


def test_plan_assigns_exact_seven_leaf_codes_without_touching_names_or_root() -> None:
    rows = catalogue_fixture()
    before = copy.deepcopy(rows)

    plan = build_repair_plan(rows)

    assert len(plan) == 7
    assert tuple(action.values["f_position_code"] for action in plan) == (
        EXPECTED_CODES
    )
    assert all(set(action.values) == {"f_position_code"} for action in plan)
    predicted = simulate_plan(rows, plan)
    assert validate_catalogue(predicted) == []

    root = next(row for row in predicted if row["id"] == 100)
    assert root["f_position_code"] is None
    assert root["f_name_en"] == before[0]["f_name_en"]
    assert root["f_name_cn"] == before[0]["f_name_cn"]
    for old, new in zip(before[2:], predicted[2:]):
        assert new["f_name_en"] == old["f_name_en"]
        assert new["f_name_cn"] == old["f_name_cn"]


def test_repair_is_idempotent() -> None:
    rows = catalogue_fixture()
    repaired = simulate_plan(rows, build_repair_plan(rows))

    assert build_repair_plan(repaired) == ()
    assert validate_catalogue(repaired) == []


def test_existing_matching_values_only_plan_missing_leaves() -> None:
    rows = catalogue_fixture()
    for index in range(3):
        rows[index + 2]["f_position_code"] = EXPECTED_CODES[index]

    plan = build_repair_plan(rows)

    assert len(plan) == 4
    assert tuple(action.values["f_position_code"] for action in plan) == (
        EXPECTED_CODES[3:]
    )


def test_conflicting_leaf_code_aborts_instead_of_overwriting() -> None:
    rows = catalogue_fixture()
    rows[2]["f_position_code"] = "MANUAL_AIP_CODE"

    with pytest.raises(RepairError, match="conflicting position code"):
        build_repair_plan(rows)


def test_code_used_by_another_catalogue_aborts() -> None:
    rows = catalogue_fixture()
    rows[1]["f_position_code"] = EXPECTED_CODES[0]

    with pytest.raises(RepairError, match="already used"):
        build_repair_plan(rows)


def test_root_or_section_code_must_remain_null() -> None:
    rows = catalogue_fixture()
    rows[0]["f_position_code"] = "ROOT_CODE"

    with pytest.raises(RepairError, match="must keep f_position_code NULL"):
        build_repair_plan(rows)


@pytest.mark.parametrize("remove_count", [1, 2])
def test_leaf_count_mismatch_aborts_without_guessing(remove_count: int) -> None:
    rows = catalogue_fixture()[:-remove_count]

    with pytest.raises(RepairError, match="expected exactly 7 active leaves"):
        build_repair_plan(rows)


def test_duplicate_existing_codes_abort() -> None:
    rows = catalogue_fixture()
    rows[2]["f_position_code"] = EXPECTED_CODES[0]
    rows[3]["f_position_code"] = EXPECTED_CODES[0]

    with pytest.raises(RepairError, match="duplicate position code"):
        build_repair_plan(rows)
