from __future__ import annotations

import copy
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from repair_nocobase_sh_rp_closure_checklists import (  # noqa: E402
    RepairError,
    build_repair_plan,
    simulate_plan,
    validate_catalogue,
)

USE_FOR = {
    "SH": "t_specific",
    "RP": "t_rp_application",
    "SELF_WITHDRAW": "t_self_withdraw_licence_application",
}
COUNTS = {"SH": 6, "RP": 4, "SELF_WITHDRAW": 4}
MIDDLES = {
    "SH": "SPECIFIC_HOUR",
    "RP": "RP",
    "SELF_WITHDRAW": "SELF_WITHDRAW",
}


def catalogue_fixture() -> list[dict]:
    rows: list[dict] = []
    next_id = 100
    for kind in ("SH", "RP", "SELF_WITHDRAW"):
        for office in ("LORCHE", "LORCHD"):
            if kind == "SELF_WITHDRAW" and office == "LORCHD":
                continue
            root_id = next_id
            next_id += 1
            rows.append(
                {
                    "id": root_id,
                    "parentId": None,
                    "f_item_type": "1",
                    "f_active": True,
                    "f_office_code": office,
                    "f_use_for": [USE_FOR[kind]],
                    "f_checklist_code": f"{office}_{kind}",
                    "f_item_code": f"{office}_{kind}_ROOT",
                    "f_name_en": f"{kind} documents",
                    "f_name_cn": f"{kind} 文件",
                    "f_sort_order": 1,
                }
            )
            for index in range(1, COUNTS[kind] + 1):
                position_code = f"{office}_{MIDDLES[kind]}_{index:03d}"
                if kind == "RP" and office == "LORCHD":
                    position_code = None
                rows.append(
                    {
                        "id": next_id,
                        "parentId": root_id,
                        "f_item_type": "2",
                        "f_active": True,
                        "f_office_code": office,
                        "f_use_for": [USE_FOR[kind]],
                        "f_checklist_code": f"{office}_{kind}",
                        "f_item_code": f"{office}_{kind}_{index}",
                        "f_position_code": position_code,
                        "f_name_en": None if kind in {"SH", "RP"} else f"EN {index}",
                        "f_name_cn": f"English source name {index}",
                        "f_sort_order": index,
                    }
                )
                next_id += 1
    return rows


def test_plan_repairs_names_rp_codes_and_clones_closure_lorchd() -> None:
    rows = catalogue_fixture()

    plan = build_repair_plan(rows)

    # 12 SH names + 8 RP names, of which the four LORCHD rows also get codes.
    assert len(plan.updates) == 20
    assert plan.closure_root is not None
    assert len(plan.closure_leaves) == 4
    rp_codes = {
        action.values["f_position_code"]
        for action in plan.updates
        if "f_position_code" in action.values
    }
    assert rp_codes == {f"LORCHD_RP_{index:03d}" for index in range(1, 5)}

    predicted = simulate_plan(rows, plan)
    assert validate_catalogue(predicted) == []
    closure_leaves = [
        row
        for row in predicted
        if row.get("f_office_code") == "LORCHD"
        and "t_self_withdraw_licence_application" in row.get("f_use_for", [])
        and row.get("f_item_type") == "2"
    ]
    assert len({row["parentId"] for row in closure_leaves}) == 1
    assert {row["f_position_code"] for row in closure_leaves} == {
        f"LORCHD_SELF_WITHDRAW_{index:03d}" for index in range(1, 5)
    }


def test_repaired_catalogue_is_idempotent() -> None:
    rows = catalogue_fixture()
    repaired = simulate_plan(rows, build_repair_plan(rows))

    second_plan = build_repair_plan(repaired)

    assert second_plan.change_count == 0
    assert validate_catalogue(repaired) == []


def test_partial_closure_clone_only_creates_missing_leaves() -> None:
    rows = catalogue_fixture()
    first_plan = build_repair_plan(rows)
    repaired = simulate_plan(rows, first_plan)
    partial = [
        row
        for row in repaired
        if row.get("f_position_code")
        not in {"LORCHD_SELF_WITHDRAW_003", "LORCHD_SELF_WITHDRAW_004"}
    ]

    plan = build_repair_plan(partial)

    assert plan.closure_root is None
    assert len(plan.closure_leaves) == 2
    assert {item.expected_position_code for item in plan.closure_leaves} == {
        "LORCHD_SELF_WITHDRAW_003",
        "LORCHD_SELF_WITHDRAW_004",
    }
    assert validate_catalogue(simulate_plan(partial, plan)) == []


def test_conflicting_rp_position_code_is_not_overwritten() -> None:
    rows = catalogue_fixture()
    rp_leaf = next(
        row
        for row in rows
        if row.get("f_office_code") == "LORCHD"
        and "t_rp_application" in row.get("f_use_for", [])
        and row.get("f_item_type") == "2"
    )
    rp_leaf["f_position_code"] = "MANUAL_CODE"

    with pytest.raises(RepairError, match="unexpected position code"):
        build_repair_plan(rows)


def test_missing_source_name_aborts_before_any_write_plan() -> None:
    rows = catalogue_fixture()
    sh_leaf = next(
        row
        for row in rows
        if row.get("f_office_code") == "LORCHE"
        and "t_specific" in row.get("f_use_for", [])
        and row.get("f_item_type") == "2"
    )
    broken = copy.deepcopy(rows)
    broken_row = next(row for row in broken if row["id"] == sh_leaf["id"])
    broken_row["f_name_en"] = None
    broken_row["f_name_cn"] = None

    with pytest.raises(RepairError, match="has no English/Chinese name"):
        build_repair_plan(broken)
