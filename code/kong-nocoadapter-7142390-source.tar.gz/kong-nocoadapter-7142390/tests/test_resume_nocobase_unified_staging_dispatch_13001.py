"""Offline guardrails for resumable, disabled API-Staging candidates."""

from __future__ import annotations

import copy
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import resume_nocobase_unified_staging_dispatch_13001 as resume  # noqa: E402
from extend_nocobase_staging_relations import ApiError  # noqa: E402


class _FakeApi:
    """Small in-memory flow_nodes surface; it makes no network request."""

    def __init__(self, workflow: dict, *, timeout_after_create: bool = False) -> None:
        self.workflow = workflow
        self.timeout_after_create = timeout_after_create
        self.created = 0
        self.updated = 0

    def get_workflow(self, workflow_id: int) -> dict:
        assert workflow_id == self.workflow["id"]
        return copy.deepcopy(self.workflow)

    def create_node(self, values: dict) -> dict:
        assert values["workflowId"] == self.workflow["id"]
        self.created += 1
        node = {
            "id": 900000 + self.created,
            "key": f"candidate{self.created}",
            "title": values["title"],
            "type": values["type"],
            "config": copy.deepcopy(values["config"]),
            "upstreamId": None,
            "branchIndex": None,
            "downstreamId": None,
        }
        # Simulate the important failure mode: NocoBase committed the POST but
        # the client timed out before receiving its response.
        self.workflow["nodes"].append(node)
        if self.timeout_after_create:
            raise ApiError("simulated timeout after remote commit")
        return copy.deepcopy(node)

    def update_node(self, node_id: int, values: dict) -> None:
        self.updated += 1
        for node in self.workflow["nodes"]:
            if node["id"] == node_id:
                node.update(copy.deepcopy(values))
                return
        raise AssertionError(node_id)


def _ingress_workflow() -> dict:
    return {
        "id": 99,
        "key": "fake",
        "title": "candidate",
        "enabled": False,
        "type": "collection",
        "config": resume.blueprint.ingress_config(),
        "nodes": [],
    }


def test_partial_ingress_recovers_only_the_missing_terminal_node() -> None:
    specs = resume._expected_ingress()
    workflow = _ingress_workflow()
    for index, spec in enumerate(specs[:-1], 1):
        workflow["nodes"].append({
            "id": index,
            "key": f"existing{index}",
            "title": spec["title"],
            "type": spec["type"],
            "config": copy.deepcopy(spec["config"]),
            "upstreamId": None,
            "branchIndex": None,
            "downstreamId": None,
        })
    actual = {spec["identity"]: node for spec, node in zip(specs[:-1], workflow["nodes"])}
    for spec in specs[:-1]:
        if spec["upstream"] is None:
            continue
        child, parent = actual[spec["identity"]], actual[spec["upstream"]]
        child["upstreamId"] = parent["id"]
        child["branchIndex"] = spec["branch"]
        if spec["branch"] is None:
            parent["downstreamId"] = child["id"]
    api = _FakeApi(workflow)
    result = resume._reconcile_ingress(api, workflow, lambda *_: None)
    assert api.created == 1
    assert result["node_count"] == 24
    assert workflow["nodes"][-1]["title"] == "Mark Change Nurse-in-Charge unified worker"


def test_timeout_after_node_commit_is_reconciled_by_deterministic_title() -> None:
    api = _FakeApi(_ingress_workflow(), timeout_after_create=True)
    node = resume._ensure_node(
        api,
        99,
        title="Match New Licence Application CREATE or UPDATE",
        node_type="condition",
        initial_config={"one": "value"},
        checkpoint=lambda *_: None,
    )
    assert node["title"] == "Match New Licence Application CREATE or UPDATE"
    assert api.created == 1
    assert len(api.workflow["nodes"]) == 1


def test_worker_config_rewrite_uses_reconstructed_candidate_keys() -> None:
    """A resumed clone must never retain a pre-candidate source node key."""
    specs = [
        {
            "identity": "EVENT", "initial_config": {}, "config_source": None,
            "prefix": None, "source_key": None,
        },
        {
            "identity": "CREATE:old_a", "initial_config": {}, "prefix": "CREATE",
            "source_key": "old_a", "config_source": {"value": "{{$jobsMapByNodeKey.old_b.id}}"},
        },
        {
            "identity": "CREATE:old_b", "initial_config": {}, "prefix": "CREATE",
            "source_key": "old_b", "config_source": {},
        },
    ]
    actual = {
        "EVENT": {"key": "event_new"},
        "CREATE:old_a": {"key": "candidate_a"},
        "CREATE:old_b": {"key": "candidate_b"},
    }
    desired = resume._desired_worker_configs(specs, actual)
    assert desired["CREATE:old_a"] == {"value": "{{$jobsMapByNodeKey.candidate_b.id}}"}
