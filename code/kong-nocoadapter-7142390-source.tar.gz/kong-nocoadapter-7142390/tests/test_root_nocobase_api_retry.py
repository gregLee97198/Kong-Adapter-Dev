from __future__ import annotations

import http.client
import sys
import urllib.request
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import create_nocobase_phase_c_chi_workflows as workflow_client  # noqa: E402


class Response:
    def __enter__(self) -> Response:
        return self

    def __exit__(self, *_args: Any) -> None:
        return None

    def read(self) -> bytes:
        return b'{"data":{"ok":true}}'


def test_root_api_retries_remote_disconnect(monkeypatch: Any) -> None:
    calls = 0

    def fake_urlopen(_request: Any, timeout: int) -> Response:
        nonlocal calls
        calls += 1
        assert timeout == 180
        if calls == 1:
            raise http.client.RemoteDisconnected("upstream reset")
        return Response()

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(workflow_client.time, "sleep", lambda _seconds: None)

    result = workflow_client.RootNocoBaseApi(
        "http://nocobase.test/cmtf2", "secret"
    ).request("GET", "/api/example:get")

    assert result == {"ok": True}
    assert calls == 2


def test_root_api_does_not_retry_uncertain_mutation(monkeypatch: Any) -> None:
    calls = 0

    def fake_urlopen(_request: Any, timeout: int) -> Response:
        nonlocal calls
        calls += 1
        assert timeout == 180
        raise http.client.RemoteDisconnected("upstream reset after commit")

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(workflow_client.time, "sleep", lambda _seconds: None)

    api = workflow_client.RootNocoBaseApi(
        "http://nocobase.test/cmtf2", "secret"
    )
    try:
        api.request("POST", "/api/flow_nodes:create", {"title": "node"})
    except workflow_client.ApiError as exc:
        assert "URL error" in str(exc)
    else:  # pragma: no cover - defensive assertion
        raise AssertionError("uncertain mutation must fail without a retry")

    assert calls == 1
