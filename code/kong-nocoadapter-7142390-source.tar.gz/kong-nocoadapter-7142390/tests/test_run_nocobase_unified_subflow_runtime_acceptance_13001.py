"""Offline contract tests for the controlled 13001 runtime acceptance tool."""

from __future__ import annotations

import copy
import json
import pathlib
import stat
import sys

import pytest

SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

import run_nocobase_unified_subflow_runtime_acceptance_13001 as target  # noqa: E402

REQUEST_ID = "DISPATCH-LRN-20261019T010203Z-ABCDEF123456"
CREATE_ID = "9001"
PARENT_ID = 7001
CHILD_ID = 7002
PARENT_EXECUTION_ID = 7101
CHILD_EXECUTION_ID = 7102


def _manifest() -> dict:
    return {
        "migration_id": target.MIGRATION_ID,
        "topology_sha256": "a" * 64,
        "source_snapshot_sha256": "b" * 64,
        "environment": "13001",
        "candidates": {
            "parent": {"id": PARENT_ID},
            "children": {"licence_renewal": {"id": CHILD_ID}},
        },
    }


def _execution(execution_id: int, *, parent_execution_id: int | None = None) -> dict:
    return {
        "id": execution_id,
        "status": 1,
        "parentExecutionId": parent_execution_id,
        "context": {
            "data": {
                "id": int(CREATE_ID),
                "f_source_system": "OP",
                "f_request_event": "CREATE",
                "f_api_type": "create_licence_renewal",
                "f_application_type": "licence_renewal",
                "f_status": "submitted",
            }
        },
    }


def _staging(request_id: str = REQUEST_ID) -> dict:
    return {
        "id": int(CREATE_ID),
        "f_source_system": "OP",
        "f_request_event": "CREATE",
        "f_api_type": "create_licence_renewal",
        "f_application_type": "licence_renewal",
        "f_office_code": "LORCHE",
        "f_request_body": {"request_id": request_id},
        "createdById": 3,
        "f_dispatch_route": None,
        "f_status": "succeeded",
        "f_application_id": 9901,
        "f_error_message": None,
    }


class _FakeInspector:
    def __init__(self, *, live_after_create: bool = False) -> None:
        self.live_after_create = live_after_create
        self.created = False
        self.request_id = REQUEST_ID
        self.old_rows: dict[int, dict] = {}

    def workflow(self, workflow_id: int) -> dict:
        if workflow_id == PARENT_ID or workflow_id == CHILD_ID:
            return {"id": workflow_id, "enabled": True}
        if workflow_id == target.LRN_OLD_CREATE_WORKFLOW_ID:
            return {"id": workflow_id, "enabled": False}
        raise AssertionError(workflow_id)

    def staging(self, create_id: str) -> dict:
        assert create_id == CREATE_ID
        assert self.created or not self.live_after_create
        return _staging(self.request_id)

    def executions(self, workflow_id: int) -> dict[int, dict]:
        if self.live_after_create and not self.created:
            return {}
        if workflow_id == PARENT_ID:
            return {PARENT_EXECUTION_ID: _execution(PARENT_EXECUTION_ID)}
        if workflow_id == CHILD_ID:
            return {
                CHILD_EXECUTION_ID: _execution(
                    CHILD_EXECUTION_ID, parent_execution_id=PARENT_EXECUTION_ID
                )
            }
        if workflow_id == target.LRN_OLD_CREATE_WORKFLOW_ID:
            return copy.deepcopy(self.old_rows)
        raise AssertionError(workflow_id)


class _FakeGateway:
    def __init__(self, inspector: _FakeInspector) -> None:
        self.inspector = inspector
        self.readiness_calls = 0
        self.authenticate_calls = 0
        self.create_calls = 0
        self.received_payload: dict | None = None

    def readiness(self) -> None:
        self.readiness_calls += 1

    def authenticate(self, *, account: str, password: str, request_id: str) -> str:
        assert account == "op-account"
        assert password == "not-a-real-password"
        assert request_id == REQUEST_ID
        self.authenticate_calls += 1
        return "temporary-token-not-recorded"

    def create_lrn(self, *, token: str, payload: dict) -> dict:
        assert token == "temporary-token-not-recorded"
        assert payload["request_id"] == REQUEST_ID
        self.received_payload = copy.deepcopy(payload)
        self.create_calls += 1
        self.inspector.created = True
        self.inspector.request_id = str(payload["request_id"])
        return {
            "accepted": True,
            "request_id": payload["request_id"],
            "create_id": CREATE_ID,
            "status": "Accepted",
            "application_type": "licence_renewal",
        }


def test_minimal_payload_is_lrn_lorche_l0043_and_has_no_attachment_work():
    payload = target.minimal_lrn_payload(REQUEST_ID, received_date="2026-10-19")

    assert payload == {
        "request_id": REQUEST_ID,
        "form_data": {
            "case_summary": {"office_code": "LORCHE", "rch_no": "L0043"},
            "part_1": {"application_received_date": "2026-10-19"},
            "part_5": {"checklist": []},
        },
    }


def test_collect_existing_is_read_only_and_produces_plan_compatible_shape():
    inspector = _FakeInspector()
    evidence = target.collect_existing_acceptance(
        inspector=inspector,
        manifest=_manifest(),
        create_id=CREATE_ID,
        request_id=REQUEST_ID,
    )

    assert evidence["format"] == target.topology.RUNTIME_EVIDENCE_FORMAT
    assert evidence["mode"] == "collect_existing"
    assert evidence["accepted_response"]["captured"] is False
    assert set(evidence["outcomes"]) == set(target.topology.RUNTIME_ACCEPTANCE_KEYS)
    assert all(item["passed"] is True for item in evidence["outcomes"].values())
    assert evidence["execution_proof"]["parent_execution"]["id"] == PARENT_EXECUTION_ID
    assert (
        evidence["execution_proof"]["child_execution"]["parent_execution_id"]
        == PARENT_EXECUTION_ID
    )


def test_collect_existing_rejects_any_legacy_execution_for_the_same_row():
    inspector = _FakeInspector()
    inspector.old_rows = {7200: _execution(7200)}

    with pytest.raises(target.AcceptanceError, match="legacy LRN Create"):
        target.collect_existing_acceptance(
            inspector=inspector,
            manifest=_manifest(),
            create_id=CREATE_ID,
            request_id=REQUEST_ID,
        )


def test_run_creates_once_and_never_returns_or_serializes_the_op_token():
    inspector = _FakeInspector(live_after_create=True)
    gateway = _FakeGateway(inspector)
    evidence = target.run_controlled_acceptance(
        gateway=gateway,  # type: ignore[arg-type]
        inspector=inspector,  # type: ignore[arg-type]
        manifest=_manifest(),
        account="op-account",
        password="not-a-real-password",
        request_id=REQUEST_ID,
        timeout_seconds=5,
        profile_validator=lambda: None,
    )

    assert gateway.readiness_calls == 1
    assert gateway.authenticate_calls == 1
    assert gateway.create_calls == 1
    assert gateway.received_payload is not None
    assert evidence["accepted_response"]["create_id"] == CREATE_ID
    rendered = json.dumps(evidence, sort_keys=True)
    assert "temporary-token-not-recorded" not in rendered
    assert "not-a-real-password" not in rendered
    assert "op-account" not in rendered


def test_evidence_file_is_new_and_owner_only(tmp_path):
    path = tmp_path / "runtime-evidence.json"
    target._write_new_private_json(path, {"safe": True})

    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    with pytest.raises(target.AcceptanceError, match="refusing to overwrite"):
        target._write_new_private_json(path, {"safe": False})


def test_generated_evidence_passes_the_plan_runtime_evidence_validator(tmp_path):
    manifest = _manifest()
    manifest["source_snapshot"] = {"frozen": "source"}
    manifest["source_snapshot_sha256"] = target.topology.digest(
        manifest["source_snapshot"]
    )
    inspector = _FakeInspector()
    evidence = target.collect_existing_acceptance(
        inspector=inspector,
        manifest=manifest,
        create_id=CREATE_ID,
        request_id=REQUEST_ID,
    )
    path = tmp_path / "compatible.json"
    target._write_new_private_json(path, evidence)

    accepted = target.topology._valid_runtime_evidence(path, manifest)

    assert accepted["state"] == "passed"


def test_profile_guard_refuses_a_non_13001_profile(tmp_path):
    config = tmp_path / "config"
    config.mkdir()
    (config / "compose.local-test.env").write_text(
        "\n".join(
            [
                "DEPLOYMENT_ENV=local_test",
                "KONG_HTTPS_BIND=127.0.0.1",
                "KONG_HTTPS_PORT=28443",
                "NOCOBASE_PROFILE_FILE=./config/nocobase.local-test.yaml",
            ]
        ),
        encoding="utf-8",
    )
    (config / "nocobase.local-test.yaml").write_text(
        "nocobase:\n  base_url: 'http://119.91.104.211:13001/cmtf2'\n",
        encoding="utf-8",
    )
    target.assert_local_development_profile(tmp_path)
    (config / "nocobase.local-test.yaml").write_text(
        "nocobase:\n  base_url: 'http://119.91.104.211:13000/cmtf2'\n",
        encoding="utf-8",
    )
    with pytest.raises(target.AcceptanceError, match="pinned to development 13001"):
        target.assert_local_development_profile(tmp_path)


def test_default_cli_is_no_write_and_needs_no_credentials(capsys):
    assert target.main([]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["writes_remote"] is False
    assert result["fixed_local_gateway"] == "https://127.0.0.1:28443"
    assert result["fixed_development_nocobase"].endswith(":13001/cmtf2")
