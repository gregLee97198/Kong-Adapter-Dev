from pathlib import Path

import pytest

from app.errors import ConfigurationError
from app.settings import Settings, _read_optional_secret


def write_profile(path: Path, token: str) -> None:
    path.write_text(
        f"""
nocobase:
  version: "2.2.3"
  base_url: "http://example.test/cmtf2"
  authenticator: "basic"
  config_token: "{token}"
  storage:
    selection: default
    name: ""
    attachment_field_context: ""
  api:
    auth_check: "/api/auth:check"
    simple_test: "/api/webhook:trigger/simple"
    homerecord_query: "/api/webhook:trigger/home"
    request_staging_create: "/api/t_api_request_staging:create"
    storage_basic_info: "/api/storages:getBasicInfo"
    storage_basic_info_by_name: "/api/storages:getBasicInfo/{{storage_name}}"
    create_presigned_url: "/api/storages:createPresignedUrl"
    attachment_create: "/api/attachments:create"
    attachment_download: "/files/main/main/attachments/{{attachment_id}}"
  response:
    data_key: "data"
""".strip(),
        encoding="utf-8",
    )


def test_reads_secret_from_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    secret_path = tmp_path / "config_token"
    secret_path.write_text("test-secret\n", encoding="utf-8")
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN", raising=False)
    monkeypatch.setenv("NOCOBASE_CONFIG_TOKEN_FILE", str(secret_path))

    value = _read_optional_secret(
        "NOCOBASE_CONFIG_TOKEN",
        "NOCOBASE_CONFIG_TOKEN_FILE",
    )

    assert value == "test-secret"


def test_rejects_direct_and_file_secret_at_the_same_time(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    secret_path = tmp_path / "config_token"
    secret_path.write_text("file-secret", encoding="utf-8")
    monkeypatch.setenv("NOCOBASE_CONFIG_TOKEN", "direct-secret")
    monkeypatch.setenv("NOCOBASE_CONFIG_TOKEN_FILE", str(secret_path))

    with pytest.raises(ConfigurationError, match="Set only one"):
        _read_optional_secret(
            "NOCOBASE_CONFIG_TOKEN",
            "NOCOBASE_CONFIG_TOKEN_FILE",
        )


def test_settings_falls_back_to_yaml_config_token(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    profile_path = tmp_path / "nocobase.yaml"
    write_profile(profile_path, "yaml-secret")
    monkeypatch.setenv("NOCOBASE_CONFIG_PATH", str(profile_path))
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN", raising=False)
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN_FILE", raising=False)

    settings = Settings.from_env()

    assert settings.nocobase_config_token == "yaml-secret"
    assert "yaml-secret" not in repr(settings)


def test_environment_token_overrides_yaml_token(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    profile_path = tmp_path / "nocobase.yaml"
    write_profile(profile_path, "yaml-secret")
    monkeypatch.setenv("NOCOBASE_CONFIG_PATH", str(profile_path))
    monkeypatch.setenv("NOCOBASE_CONFIG_TOKEN", "environment-secret")
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN_FILE", raising=False)

    settings = Settings.from_env()

    assert settings.nocobase_config_token == "environment-secret"


def test_secret_file_overrides_yaml_token(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    profile_path = tmp_path / "nocobase.yaml"
    secret_path = tmp_path / "config_token"
    write_profile(profile_path, "yaml-secret")
    secret_path.write_text("file-secret\n", encoding="utf-8")
    monkeypatch.setenv("NOCOBASE_CONFIG_PATH", str(profile_path))
    monkeypatch.delenv("NOCOBASE_CONFIG_TOKEN", raising=False)
    monkeypatch.setenv("NOCOBASE_CONFIG_TOKEN_FILE", str(secret_path))

    settings = Settings.from_env()

    assert settings.nocobase_config_token == "file-secret"
