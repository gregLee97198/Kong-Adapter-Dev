from __future__ import annotations

import copy
import os
import shutil
import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).parents[1]
SOURCE = ROOT / "config/kong.211-dbless.yml"
UAT = ROOT / "config/kong.uat-dbless.yml"


def _yaml(path: Path) -> dict[str, object]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def test_uat_candidate_is_regenerated_from_current_211_contract() -> None:
    env = os.environ.copy()
    env["UAT_ENV_FILE"] = "uat.env.example"
    result = subprocess.run(
        [sys.executable, "scripts/generate_uat_kong_config.py", "--check"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    assert result.returncode == 0, result.stderr


def test_unpacked_bundle_changes_both_upstreams_without_211_yaml(
    tmp_path: Path,
) -> None:
    (tmp_path / "config").mkdir()
    (tmp_path / "scripts").mkdir()
    subprocess.run(
        [
            sys.executable,
            "scripts/render_uat_release_manifest.py",
            str(tmp_path / "config/environments.yaml"),
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    for relative in (
        "config/nocobase.uat.yaml",
        "config/kong.uat-dbless.yml",
        "scripts/retarget_uat_config.py",
        "scripts/manage_environment.py",
    ):
        shutil.copy2(ROOT / relative, tmp_path / relative)
    (tmp_path / ".env").write_text(
        "UAT_NOCOBASE_BASE_URL=http://10.24.0.17:8081/cmtf2\n"
        "NOCOBASE_CONFIG_TOKEN=example-only\n",
        encoding="utf-8",
    )
    env = os.environ.copy()
    env.pop("UAT_ENV_FILE", None)
    result = subprocess.run(
        [sys.executable, "scripts/retarget_uat_config.py", "--write"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    assert result.returncode == 0, result.stderr
    kong = _yaml(tmp_path / "config/kong.uat-dbless.yml")
    adapter = _yaml(tmp_path / "config/nocobase.uat.yaml")
    services = {service["name"]: service for service in kong["services"]}
    assert services["nocobase-adapter-auth-service"]["host"] == "kong-nocoadapter"
    assert services["nocobase-adapter-auth-service"]["port"] == 8080
    assert services["nocobase-file-adapter-service"]["host"] == "kong-nocoadapter"
    assert adapter["nocobase"]["base_url"] == "http://10.24.0.17:8081/cmtf2"
    validation = subprocess.run(
        [sys.executable, "scripts/manage_environment.py", "validate", "uat"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    assert validation.returncode == 0, validation.stderr


def test_release_manifest_contains_only_uat_parameters(tmp_path: Path) -> None:
    output = tmp_path / "environments.yaml"
    result = subprocess.run(
        [
            sys.executable,
            "scripts/render_uat_release_manifest.py",
            str(output),
            "--check-dir",
            str(tmp_path),
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    manifest = _yaml(output)
    assert manifest["default_environment"] == "uat"
    assert set(manifest["environments"]) == {"uat"}
    uat = manifest["environments"]["uat"]
    assert uat["compose_env_file"] == ".env"
    assert uat["upstream_env_file"] == ".env"
    assert "forbidden_upstream_hosts" not in uat
    text = output.read_text(encoding="utf-8")
    for forbidden in (
        "119.91.104.211",
        "cmtf2sit.swd.hksarg",
        "local_test",
        "online_test",
        "development",
        "production",
        "211",
    ):
        assert forbidden not in text


def test_release_payload_rejects_other_environment_parameters(tmp_path: Path) -> None:
    (tmp_path / "local.env").write_text(
        "DEPLOYMENT_ENV=local_test\n", encoding="utf-8"
    )
    result = subprocess.run(
        [
            sys.executable,
            "scripts/render_uat_release_manifest.py",
            str(tmp_path / "environments.yaml"),
            "--check-dir",
            str(tmp_path),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode != 0
    assert "other environment parameter" in result.stderr


def test_uat_preserves_211_business_routes_on_docker_network() -> None:
    source = _yaml(SOURCE)
    uat = _yaml(UAT)
    uat_services = {service["name"]: service for service in uat["services"]}
    assert set(uat_services) == {
        "nocobase-adapter-auth-service",
        "nocobase-file-adapter-service",
    }
    for source_service in source["services"]:
        target = copy.deepcopy(uat_services[source_service["name"]])
        assert target["host"] == "kong-nocoadapter"
        assert target["port"] == 8080
        target["host"] = source_service["host"]
        target["port"] = source_service["port"]
        for route in target["routes"]:
            assert route["protocols"] == ["http", "https"]
            route["protocols"] = ["https"]
            route["https_redirect_status_code"] = 426
        assert target == source_service
    assert uat["plugins"] == source["plugins"]


def test_offline_image_and_compose_use_two_key_env() -> None:
    dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    assert "RUN pip install --no-cache-dir --requirement requirements.txt" in dockerfile
    assert "COPY app ./app" in dockerfile
    assert "COPY config/nocobase.yaml ./config/nocobase.yaml" in dockerfile
    embedded_profile = (ROOT / "config/nocobase.yaml").read_text(encoding="utf-8")
    assert "http://change-me.invalid/cmtf2" in embedded_profile
    assert "119.91.104.211" not in embedded_profile

    compose = _yaml(ROOT / "docker-compose.uat.yml")
    services = compose["services"]
    adapter = services["kong-nocoadapter"]
    kong = services["kong-gateway"]
    assert adapter["image"].startswith("${ADAPTER_IMAGE:")
    assert adapter["environment"]["NOCOBASE_CONFIG_TOKEN"].startswith(
        "${NOCOBASE_CONFIG_TOKEN:"
    )
    assert "NOCOBASE_CONFIG_TOKEN_FILE" not in adapter["environment"]
    assert kong["ports"] == ["0.0.0.0:18000:8000", "127.0.0.1:18001:8001"]
    assert kong["environment"]["KONG_DATABASE"] == "off"


def test_bundle_script_excludes_other_environments_and_builds_amd64() -> None:
    script = (ROOT / "scripts/build_uat_offline_bundle.sh").read_text(
        encoding="utf-8"
    )
    assert 'PLATFORM="linux/amd64"' in script
    assert 'docker image save "$ADAPTER_IMAGE" "$KONG_IMAGE"' in script
    assert "docker run --rm --network none" in script
    release_paths = script.split("RELEASE_PATHS=(", 1)[1].split(")", 1)[0]
    assert set(release_paths.split()) == {
        "config/nocobase.uat.yaml",
        "config/kong.uat-dbless.yml",
        "docker-compose.uat.yml",
        "scripts/retarget_uat_config.py",
        "scripts/manage_environment.py",
        "docs/Kong-UAT-Offline-Deployment_zh-CN.md",
    }
    assert 'scripts/render_uat_release_manifest.py \\' in script
    assert '"$STAGE_DIR/config/environments.yaml"' in script
    assert '--check-dir "$STAGE_DIR"' in script
    assert 'cp -- uat.env.example "$STAGE_DIR/.env"' in script
    assert 'chmod 600 "$STAGE_DIR/.env"' in script
    assert 'git archive --format=tar HEAD "${RELEASE_PATHS[@]}"' in script
    assert "SOURCE_COMMIT" not in script
    assert "PYTHON_PACKAGES.txt" not in script
    assert "IMAGE_IDS.txt" not in script
    assert "config/nocobase.uat.yaml" in release_paths
    assert "config/kong.uat-dbless.yml" in release_paths
    assert "docker-compose.uat.yml" in release_paths
    assert "scripts/deploy_uat_docker.sh" not in release_paths
    assert "config/nocobase.211.yaml" not in release_paths
    assert "config/nocobase.local-test.yaml" not in release_paths
    assert "config/kong.211-dbless.yml" not in release_paths
    assert "deploy/kubernetes" not in release_paths
    assert "secrets" not in release_paths
    assert 'echo "release_tar=$RELEASE_TAR"' in script
    assert "release_sha256=" not in script
    assert "SHA256SUMS" not in script


def test_download_guide_is_docker_only_and_file_manager_edits_env() -> None:
    guide = (
        ROOT / "docs/Kong-UAT-Offline-Deployment_zh-CN.md"
    ).read_text(encoding="utf-8")
    assert "Docker 离线部署" in guide
    assert "只有 `uat` Profile" in guide
    assert "211" not in guide
    assert "包内已经有不含真实密钥的 `.env` 模板" in guide
    assert "将 `uat.env.example` 复制" not in guide
    assert "获取 Root API Key" in guide
    assert "Nginx 端口指向" in guide
    assert "APP_KEY" in guide
    assert "GET /api/storages:getBasicInfo" in guide
    assert "GET /api/fields:list" in guide
    assert "GET /api/t_document_checklist:list" in guide
    assert "http://UAT主机内网IP:18000" in guide
    assert "文件管理器" in guide
    assert "两行" in guide
    assert "bash scripts/deploy_uat_docker.sh" not in guide
    assert "docker image load -i images/kong-uat-0.19.1-linux-amd64.docker.tar" in guide
    assert "gzip -dc" not in guide
    assert "文件管理器" in guide
    assert "/release/scripts/retarget_uat_config.py --write" in guide
    assert "up -d --no-build --pull never --force-recreate" in guide
    assert "UAT_REGISTRY=" not in guide
    assert "docker push" not in guide
    assert "kubectl" not in guide
    assert "build_uat_offline_bundle.sh" not in guide
    assert ".tar.sha256" not in guide
    assert "sha256sum" not in guide
    assert "vi .env" not in guide


def test_uat_uses_separate_offline_commands_not_one_shot_start_script() -> None:
    assert not (ROOT / "scripts/deploy_uat_docker.sh").exists()
    guide = (
        ROOT / "docs/Kong-UAT-Offline-Deployment_zh-CN.md"
    ).read_text(encoding="utf-8")
    assert "--network none" in guide
    assert "docker compose --env-file .env" in guide
    assert "--pull never" in guide
    assert "docker push" not in guide
    assert "pip install" in guide  # Mentioned only to state it is not used in UAT.


def test_uat_env_example_has_only_upstream_and_root_token() -> None:
    example = (ROOT / "uat.env.example").read_text(encoding="utf-8")
    keys = {
        line.split("=", 1)[0]
        for line in example.splitlines()
        if line and not line.startswith("#") and "=" in line
    }
    assert keys == {"UAT_NOCOBASE_BASE_URL", "NOCOBASE_CONFIG_TOKEN"}
    assert "119.91.104.211" not in example
    assert "13000" not in example
    assert "211 Token" not in example
    assert "Kubernetes" not in example
    assert "kubectl" not in example


def test_legacy_kubernetes_uat_candidate_and_apply_script_are_removed() -> None:
    assert not (ROOT / "deploy/kubernetes/kong-uat-with-adapter.yml").exists()
    assert not (ROOT / "scripts/apply_uat_config.sh").exists()
    assert (ROOT / "config/nocobase.uat.yaml").exists()
    assert (ROOT / "config/kong.uat-dbless.yml").exists()
