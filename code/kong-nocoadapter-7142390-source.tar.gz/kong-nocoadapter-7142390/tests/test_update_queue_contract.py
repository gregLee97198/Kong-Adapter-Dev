"""Offline checks for the planned Staging UPDATE queue; no live API calls."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from update_queue_contract import (  # noqa: E402
    ADMISSION_PENDING,
    APPLICATION_ONLY_READY_TYPES,
    ATOMIC_ADMIT_PENDING_SQL,
    ATOMIC_ADVANCE_RECEIVED_SQL,
    ATOMIC_BEGIN_APPLY_SQL,
    ATOMIC_CANCEL_COUNTED_AFTER_RECEIVED_SQL,
    ATOMIC_FAIL_PREFLIGHT_SQL,
    ATOMIC_FIFO_DISPATCH_SQL,
    ATOMIC_ISOLATE_APPLYING_SQL,
    ATOMIC_NATIVE_WORKER_RESERVE_SQL,
    ATOMIC_REJECT_UNADMITTED_SQL,
    ATOMIC_RELEASE_CLAIMED_PREFLIGHT_FAILURE_SQL,
    ATOMIC_RELEASE_CLAIMED_SUCCESS_SQL,
    ATOMIC_RETRY_PREFLIGHT_SQL,
    ATOMIC_WORKER_CLAIM_SQL,
    CHILD_QUEUE_FIELDS,
    COUNTED_SEQUENCE_DUPLICATE_AUDIT_SQL,
    COUNTED_SEQUENCE_UNIQUE_INDEX_SQL,
    IDEMPOTENCY_DUPLICATE_AUDIT_SQL,
    IDEMPOTENCY_UNIQUE_INDEX_SQL,
    INTAKE_AND_APPLICATION_READY_TYPES,
    NATIVE_INTAKE_OPEN_PREDICATE,
    PARENT_QUEUE_FIELDS,
    RECEIVED_BARRIER_PREDICATE,
    RECEIVED_BLOCKING_STATUSES,
    RELEASE_TERMINAL_RESERVATION_SQL,
    RESERVATION_TOKEN_UNIQUE_INDEX_SQL,
    SUPPORTED_APPLICATION_TYPES,
    classify_admission_readback,
    classify_boundary_reconciliation,
    classify_recovery,
    classify_reserved_orm_wake,
    failure_status,
)


def test_dispatch_is_one_statement_with_child_before_parent_lock() -> None:
    sql = ATOMIC_FIFO_DISPATCH_SQL
    assert sql.count('UPDATE "t_api_request_staging"') == 2
    assert "FOR UPDATE OF parent SKIP LOCKED" not in sql
    assert "FOR UPDATE OF staged SKIP LOCKED" in sql
    assert sql.index("FOR UPDATE OF staged SKIP LOCKED") < sql.index(
        'UPDATE "t_api_request_staging" AS parent'
    )
    assert 'ORDER BY staged."f_queue_sequence"' in sql
    assert "LIMIT 1" in sql
    assert 'older."f_queue_sequence" < staged."f_queue_sequence"' in sql
    assert 'older."f_queue_counted" IS TRUE' in sql
    assert "'admission_pending', 'queued', 'submitted', 'processing'" in sql
    assert 'parent."f_status" = \'succeeded\'' in sql
    assert 'parent."f_application_status" = \'Accepted\'' in sql
    assert 'parent."f_application_type" = :applicationType' in sql
    assert 'parent."f_source_system" = :sourceSystem' in sql
    assert 'parent."f_api_type" = :createApiType' in sql
    assert 'staged."f_application_type" = :applicationType' in sql
    assert 'staged."f_source_system" = :sourceSystem' in sql
    assert 'staged."f_api_type" = :updateApiType' in sql
    assert 'parent."f_application_type" = \'licence_renewal\'' in sql
    assert 'OR parent."f_intake_id" IS NOT NULL' in sql
    assert 'parent."f_active_update_id" IS NULL' in sql
    assert 'COALESCE(parent."f_queue_pending_count", 0) > 0' in sql
    assert 'staged."f_queue_counted" IS TRUE' in sql
    assert 'staged."f_queue_sequence" IS NOT NULL' in sql
    assert 'staged."f_status" = \'queued\'' in sql
    assert 'SET "f_status" = \'submitted\'' not in sql
    assert 'SET "f_queue_claimed_at" = NOW()' in sql
    assert 'staged."f_active_update_id" = candidate."f_active_update_id"' in sql
    assert "COALESCE(staged.\"f_attempt_count\", 0) + 1" in sql
    assert "RETURNING staged.\"id\"" in sql


def test_preflight_failure_release_is_fenced_and_does_not_match_applying() -> None:
    sql = ATOMIC_RELEASE_CLAIMED_PREFLIGHT_FAILURE_SQL
    assert 'child."f_status" = \'failed\'' in sql
    assert 'child."f_queue_phase" = \'preflight\'' in sql
    assert 'child."f_status" = \'succeeded\'' not in sql
    assert 'child."f_queue_phase" = \'applying\'' not in sql
    assert 'child."f_queue_worker_token" = :workerToken' in sql
    assert 'child."f_active_update_id" = :reservationId' in sql
    assert sql.index("FOR UPDATE OF child SKIP LOCKED") < sql.index(
        'UPDATE "t_api_request_staging" AS parent'
    )
    assert 'parent."f_queue_pending_count" - 1' in sql
    assert sql.endswith(";")


def test_dispatch_readiness_covers_all_current_bp_families() -> None:
    assert APPLICATION_ONLY_READY_TYPES == {"licence_renewal"}
    assert "new_licence" in INTAKE_AND_APPLICATION_READY_TYPES
    assert "expansion_aip" in INTAKE_AND_APPLICATION_READY_TYPES
    assert "change_nurse_in_charge" in INTAKE_AND_APPLICATION_READY_TYPES
    assert SUPPORTED_APPLICATION_TYPES == (
        APPLICATION_ONLY_READY_TYPES | INTAKE_AND_APPLICATION_READY_TYPES
    )
    for application_type in SUPPORTED_APPLICATION_TYPES:
        assert f"'{application_type}'" in ATOMIC_FIFO_DISPATCH_SQL


def test_received_barrier_blocks_admission_and_every_pending_state() -> None:
    predicate = RECEIVED_BARRIER_PREDICATE
    assert 'COALESCE(create_row."f_queue_pending_count", 0) = 0' in predicate
    assert 'create_row."f_active_update_id" IS NULL' in predicate
    assert 'pending."f_parent_create_id" = CAST(create_row."id" AS text)' in predicate
    for status in RECEIVED_BLOCKING_STATUSES:
        assert f"'{status}'" in predicate


def test_received_writer_is_one_guarded_parent_update() -> None:
    sql = ATOMIC_ADVANCE_RECEIVED_SQL
    assert sql.count('UPDATE "t_api_request_staging"') == 1
    assert 'SET "f_application_status" = \'Received\'' in sql
    assert 'create_row."f_application_status" = \'Accepted\'' in sql
    assert 'create_row."f_request_event" = \'CREATE\'' in sql
    assert 'create_row."f_source_system" = :sourceSystem' in sql
    assert 'create_row."f_application_type" = :applicationType' in sql
    assert RECEIVED_BARRIER_PREDICATE in sql
    assert sql.endswith(";")


def test_unadmitted_rejection_and_safe_preflight_retry_are_fenced() -> None:
    reject = ATOMIC_REJECT_UNADMITTED_SQL
    assert 'child."f_status" = \'admission_pending\'' in reject
    assert 'child."f_queue_counted" IS NOT TRUE' in reject
    assert 'parent."f_application_status" <> \'Accepted\'' in reject
    assert "update_superseded" not in reject
    assert '"f_error_message" = \'update_locked\'' in reject
    assert 'child."f_client_request_id"' not in reject
    assert 'SET "f_status" = \'failed\'' in reject
    retry = ATOMIC_RETRY_PREFLIGHT_SQL
    assert 'child."f_queue_phase" = \'preflight\'' in retry
    assert 'child."f_queue_worker_token" = :workerToken' in retry
    assert 'parent."f_active_update_id" = :reservationId' in retry
    assert 'child."f_attempt_count" < :maxAttempts' in retry
    assert '"f_attempt_count" = child."f_attempt_count" + 1' in retry
    assert '"f_queue_pending_count"' not in retry
    assert '"f_active_update_id" = NULL' not in retry


def test_only_terminal_child_can_release_matching_parent_reservation() -> None:
    sql = RELEASE_TERMINAL_RESERVATION_SQL
    assert 'parent."f_active_update_id" = :reservationId' in sql
    assert 'child."f_active_update_id" = :reservationId' in sql
    assert 'child."id" = :updateId' in sql
    assert "child.\"f_status\" IN ('succeeded', 'failed')" in sql
    assert 'child."f_queue_counted" IS TRUE' in sql
    assert '"f_queue_pending_count" = parent."f_queue_pending_count" - 1' in sql
    assert 'SET "f_queue_counted" = FALSE' in sql
    assert "needs_review" not in sql


def test_overtaken_counted_update_cancels_without_touching_business_data() -> None:
    sql = ATOMIC_CANCEL_COUNTED_AFTER_RECEIVED_SQL
    assert 'child."id" = :updateId' in sql
    assert 'child."f_parent_create_id" = :createId' in sql
    assert 'child."f_queue_counted" IS TRUE' in sql
    assert 'child."f_active_update_id" = :reservationId' in sql
    assert "child.\"f_status\" IN ('admission_pending', 'queued', 'submitted')" in sql
    assert 'child."f_queue_phase" = \'preflight\'' in sql
    assert "'applying'" not in sql
    assert "'needs_review'" not in sql
    assert 'parent."f_application_status" IS DISTINCT FROM \'Accepted\'' in sql
    assert 'intake."f_approval_status" = \'4\'' in sql
    assert 'WHEN parent."f_active_update_id" = :reservationId THEN NULL' in sql
    assert 'parent."f_queue_pending_count" - 1' in sql
    assert '"f_error_message" = \'update_locked_after_admission\'' in sql
    assert '"f_queue_counted" = FALSE' in sql
    assert "1 / child_rows" in sql


@pytest.mark.parametrize(
    ("status", "phase", "counted", "parent_status", "intake_complete", "expected"),
    [
        ("queued", None, True, "Accepted", False, "none"),
        ("queued", None, True, "Received", False, "cancel_counted"),
        ("admission_pending", None, True, "Accepted", True, "cancel_counted"),
        ("submitted", None, True, "Received", False, "cancel_counted"),
        ("processing", "preflight", True, "Accepted", True, "cancel_counted"),
        ("processing", "applying", True, "Received", True, "isolate"),
        ("needs_review", "applying", True, "Received", True, "isolate"),
        ("succeeded", "applying", True, "Received", True, "release_terminal"),
        ("failed", "preflight", True, "Received", True, "release_terminal"),
        ("queued", None, False, "Received", True, "none"),
        ("unexpected", None, True, "Received", True, "isolate"),
    ],
)
def test_boundary_reconciliation_selects_only_safe_actions(
    status: str, phase: str | None, counted: bool,
    parent_status: str, intake_complete: bool, expected: str,
) -> None:
    assert classify_boundary_reconciliation(
        status=status,
        phase=phase,
        counted=counted,
        parent_application_status=parent_status,
        intake_complete=intake_complete,
    ) == expected


def test_admission_counts_one_pending_row_without_bypassing_orm_wake() -> None:
    sql = ATOMIC_ADMIT_PENDING_SQL
    assert sql.count('UPDATE "t_api_request_staging"') == 2
    assert "FOR UPDATE OF child SKIP LOCKED" in sql
    assert 'child."f_status" = \'admission_pending\'' in sql
    assert 'child."f_source_system" = :sourceSystem' in sql
    assert 'parent."f_source_system" = :sourceSystem' in sql
    assert 'child."f_active_update_id" IS NOT NULL' in sql
    assert 'child."f_client_request_id" IS NOT NULL' in sql
    assert 'parent."f_application_status" = \'Accepted\'' in sql
    assert 'COALESCE(parent."f_queue_pending_count", 0) + 1' in sql
    assert '"f_queue_next_sequence" =' in sql
    assert 'COALESCE(parent."f_queue_next_sequence", 0) + 1' in sql
    assert '"f_queue_sequence" = admitted_parent."f_queue_next_sequence"' in sql
    assert 'pending."id"' in sql
    assert "last_admitted_id" not in sql
    assert 'SET "f_queue_counted" = TRUE' in sql
    assert 'SET "f_status" = \'queued\'' not in sql
    assert "1 / child_rows" in sql
    assert "RETURNING child.\"id\"" in sql


def test_update_worker_fences_redelivery_before_business_writes() -> None:
    native = ATOMIC_NATIVE_WORKER_RESERVE_SQL
    assert 'child."f_status" = \'submitted\'' in native
    assert 'SET "f_queue_phase" = \'preflight\'' in native
    assert 'gen_random_uuid()::text' in native
    assert 'SET "f_status" = \'processing\'' not in native
    assert 'parent."f_application_status" = \'Accepted\'' in native
    assert 'parent."f_active_update_id" = :reservationId' in native
    assert NATIVE_INTAKE_OPEN_PREDICATE in native
    assert 'RETURNING child."id", child."f_queue_worker_token"' in native
    claim = ATOMIC_WORKER_CLAIM_SQL
    assert 'child."f_status" = \'submitted\'' in claim
    assert 'child."f_source_system" = :sourceSystem' in claim
    assert 'child."f_api_type" = :updateApiType' in claim
    assert 'parent."f_api_type" = :createApiType' in claim
    assert 'child."f_queue_phase" IS NULL' in claim
    assert 'child."f_queue_worker_token" IS NULL' in claim
    assert 'child."f_active_update_id" = :reservationId' in claim
    assert 'parent."f_active_update_id" = :reservationId' in claim
    assert 'parent."f_application_status" = \'Accepted\'' in claim
    assert NATIVE_INTAKE_OPEN_PREDICATE in claim
    assert '"f_queue_phase" = \'preflight\'' in claim
    assert '"f_queue_worker_token" = :workerToken' in claim
    begin = ATOMIC_BEGIN_APPLY_SQL
    assert 'child."f_queue_phase" = \'preflight\'' in begin
    assert 'child."f_queue_worker_token" = :workerToken' in begin
    assert '"f_queue_phase" = \'applying\'' in begin
    assert 'parent."f_active_update_id" = :reservationId' in begin
    assert NATIVE_INTAKE_OPEN_PREDICATE in begin
    assert 'intake."f_approval_status" IS DISTINCT FROM \'4\'' in begin


def test_native_success_release_requires_exact_worker_token() -> None:
    sql = ATOMIC_RELEASE_CLAIMED_SUCCESS_SQL
    assert 'child."f_status" = \'succeeded\'' in sql
    assert 'child."f_queue_phase" = \'applying\'' in sql
    assert 'child."f_queue_worker_token" = :workerToken' in sql
    assert 'child."f_active_update_id" = :reservationId' in sql
    assert 'parent."f_active_update_id" = :reservationId' in sql
    assert '"f_queue_pending_count" = parent."f_queue_pending_count" - 1' in sql
    assert '"f_queue_counted" = FALSE' in sql


def test_error_finalizers_never_advance_ambiguous_business_writes() -> None:
    preflight = ATOMIC_FAIL_PREFLIGHT_SQL
    applying = ATOMIC_ISOLATE_APPLYING_SQL
    assert 'child."f_queue_phase" = \'preflight\'' in preflight
    assert '"f_status" = \'failed\'' in preflight
    assert 'child."f_queue_phase" = \'applying\'' in applying
    assert '"f_status" = \'needs_review\'' in applying
    assert '"f_queue_pending_count"' not in applying
    assert '"f_active_update_id" = NULL' not in applying


@pytest.mark.parametrize(
    ("status", "phase", "execution_state", "attempts", "expected"),
    [
        ("admission_pending", None, "unknown", 0, "retry_admission"),
        ("queued", None, "unknown", 0, "wait_ready"),
        ("submitted", None, "unknown", 1, "invoke_subflow"),
        ("processing", "preflight", "running", 1, "wait_execution"),
        ("processing", "preflight", "finished", 1, "retry_preflight"),
        ("processing", "preflight", "finished", 3, "isolate"),
        ("processing", "applying", "finished", 1, "isolate"),
        ("processing", None, "finished", 1, "isolate"),
        ("processing", "preflight", "unknown", 1, "isolate"),
        ("needs_review", "applying", "finished", 1, "isolate"),
        ("succeeded", "applying", "finished", 1, "terminal"),
        ("failed", "preflight", "finished", 1, "terminal"),
    ],
)
def test_recovery_classification_fails_closed(
    status: str,
    phase: str | None,
    execution_state: str,
    attempts: int,
    expected: str,
) -> None:
    assert classify_recovery(
        status=status,
        phase=phase,
        execution_state=execution_state,  # type: ignore[arg-type]
        attempts=attempts,
    ) == expected


def test_only_preflight_failure_can_finish_and_advance_fifo() -> None:
    assert failure_status(phase="preflight") == "failed"
    assert failure_status(phase="applying") == "needs_review"
    assert failure_status(phase=None) == "needs_review"


def test_request_id_deduplication_has_explicit_schema_and_preflight_audit() -> None:
    assert ADMISSION_PENDING == "admission_pending"
    assert PARENT_QUEUE_FIELDS == (
        "f_queue_pending_count", "f_queue_next_sequence", "f_active_update_id"
    )
    assert "f_queue_counted" in CHILD_QUEUE_FIELDS
    assert "f_queue_sequence" in CHILD_QUEUE_FIELDS
    assert "f_client_request_id" in CHILD_QUEUE_FIELDS
    assert "f_queue_worker_token" in CHILD_QUEUE_FIELDS
    assert "HAVING COUNT(*) > 1" in IDEMPOTENCY_DUPLICATE_AUDIT_SQL
    assert '"f_client_request_id"' in IDEMPOTENCY_UNIQUE_INDEX_SQL
    assert '"f_parent_create_id"' in IDEMPOTENCY_UNIQUE_INDEX_SQL
    assert '"f_api_type"' in IDEMPOTENCY_UNIQUE_INDEX_SQL
    assert "'UPDATE'" in IDEMPOTENCY_UNIQUE_INDEX_SQL
    assert "missing_required" in IDEMPOTENCY_UNIQUE_INDEX_SQL
    assert "invalid_request" in IDEMPOTENCY_UNIQUE_INDEX_SQL
    assert '"f_active_update_id"' in RESERVATION_TOKEN_UNIQUE_INDEX_SQL
    assert '"f_request_event" = \'UPDATE\'' in RESERVATION_TOKEN_UNIQUE_INDEX_SQL
    assert (
        '"f_parent_create_id", "f_queue_sequence"'
        in COUNTED_SEQUENCE_UNIQUE_INDEX_SQL
    )
    assert '"f_queue_counted" IS TRUE' in COUNTED_SEQUENCE_UNIQUE_INDEX_SQL
    assert "HAVING COUNT(*) > 1" in COUNTED_SEQUENCE_DUPLICATE_AUDIT_SQL


def _readback_row(**overrides: object) -> dict[str, object]:
    row: dict[str, object] = {
        "id": 101,
        "f_request_event": "UPDATE",
        "f_source_system": "OP",
        "f_api_type": "update_new_licence_data",
        "f_application_type": "new_licence",
        "f_parent_create_id": "100",
        "f_client_request_id": "OP-REQ-1",
        "f_active_update_id": "reservation-1",
        "f_request_body": {"request_id": "OP-REQ-1", "form_data": {"part_1": {}}},
        "f_status": "admission_pending",
        "f_queue_counted": False,
        "f_queue_sequence": None,
        "f_queue_phase": None,
        "f_attempt_count": 0,
    }
    row.update(overrides)
    return row


def _decide(
    row: dict[str, object],
    parent_status: str = "Accepted",
    parent_next_sequence: int = 0,
) -> str:
    return classify_admission_readback(
        row=row,
        parent_application_status=parent_status,
        parent_next_sequence=parent_next_sequence,
        source_system="OP",
        api_type="update_new_licence_data",
        application_type="new_licence",
        create_id="100",
        request_id="OP-REQ-1",
        request_body={"request_id": "OP-REQ-1", "form_data": {"part_1": {}}},
        reservation_id="reservation-1",
    )


def test_admission_readback_does_not_trust_custom_action_http_200() -> None:
    assert _decide(_readback_row()) == "retry_admission"
    assert _decide(_readback_row(), "Received") == "reject_unadmitted"
    assert _decide(
        _readback_row(f_queue_counted=True, f_queue_sequence=1),
        parent_next_sequence=1,
    ) == (
        "wake_required"
    )
    assert _decide(_readback_row(f_queue_counted=True), "Received") == "isolate"
    assert _decide(
        _readback_row(f_status="queued", f_queue_counted=True, f_queue_sequence=1),
        parent_next_sequence=1,
    ) == (
        "accepted"
    )
    assert _decide(_readback_row(f_status="queued")) == "isolate"
    assert _decide(
        _readback_row(f_status="queued", f_queue_counted=True, f_queue_sequence=1),
        "Received", parent_next_sequence=1,
    ) == "accepted"
    assert _decide(
        _readback_row(f_queue_counted=True, f_queue_sequence=1),
        "Received", parent_next_sequence=1,
    ) == "accepted"
    assert _decide(
        _readback_row(
            f_status="failed", f_error_message="update_locked",
        ),
        "Received",
    ) == "update_locked"


def test_admission_readback_replays_terminal_only_if_it_was_dispatched() -> None:
    assert _decide(
        _readback_row(
            f_status="succeeded", f_queue_phase="applying", f_attempt_count=1,
            f_queue_sequence=1,
        ), parent_next_sequence=1
    ) == "accepted"
    assert _decide(
        _readback_row(
            f_status="failed", f_queue_phase="preflight", f_attempt_count=1,
            f_queue_sequence=1,
        ), parent_next_sequence=1
    ) == "accepted"
    assert _decide(
        _readback_row(
            f_status="succeeded", f_queue_phase="finished",
            f_queue_counted=False, f_attempt_count=1, f_queue_sequence=1,
        ), parent_next_sequence=1
    ) == "accepted"
    assert _decide(_readback_row(f_status="failed")) == "isolate"


def test_admission_readback_rejects_body_reuse_and_identity_drift() -> None:
    assert _decide(_readback_row(f_request_body={"request_id": "OP-REQ-1"})) == (
        "idempotency_conflict"
    )
    assert _decide(_readback_row(f_parent_create_id="999")) == "isolate"
    assert _decide(_readback_row(f_active_update_id="different")) == "isolate"


def test_reserved_orm_wake_requires_exact_parent_slot_and_child_identity() -> None:
    parent = {"id": 100, "f_active_update_id": "ticket-101"}
    child: dict[str, object] = {
        "id": 101,
        "f_request_event": "UPDATE",
        "f_parent_create_id": "100",
        "f_active_update_id": "ticket-101",
        "f_queue_counted": True,
        "f_status": "queued",
    }
    args = {
        "child": child,
        "parent": parent,
        "expected_update_id": 101,
        "expected_reservation_id": "ticket-101",
    }
    assert classify_reserved_orm_wake(**args) == "wake_required"
    child["f_status"] = "submitted"
    assert classify_reserved_orm_wake(**args) == "submitted"
    child["f_status"] = "processing"
    assert classify_reserved_orm_wake(**args) == "claimed"
    parent["f_active_update_id"] = "ticket-102"
    assert classify_reserved_orm_wake(**args) == "isolate"
    parent["f_active_update_id"] = None
    child["f_status"] = "succeeded"
    child["f_queue_counted"] = False
    assert classify_reserved_orm_wake(**args) == "terminal"
    child["f_parent_create_id"] = "other"
    assert classify_reserved_orm_wake(**args) == "isolate"


def test_parent_sequence_accepts_late_older_id_and_invalid_sequence_fails_closed(
) -> None:
    pending = _readback_row()
    assert _decide(pending, parent_next_sequence=2) == "retry_admission"
    assert _decide(pending, parent_next_sequence=-1) == "isolate"
    assert _decide(pending, parent_next_sequence=2147483648) == "isolate"
    assert _decide(_readback_row(id="101"), parent_next_sequence=2) == "isolate"
    assert (
        _decide(_readback_row(f_queue_sequence=1), parent_next_sequence=2)
        == "isolate"
    )
    assert _decide(
        _readback_row(f_status="queued", f_queue_counted=True, f_queue_sequence=2),
        parent_next_sequence=1,
    ) == "isolate"
