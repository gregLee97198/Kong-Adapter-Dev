"""Local-only reviewed UPDATE queue startup gates; no NocoBase I/O."""

from __future__ import annotations

import hashlib
from dataclasses import fields
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml

from app.main import _update_queue_service_from_env
from app.update_queue_release import (
    QUEUE_FAMILY_API_TYPES,
    load_reviewed_queue_release,
)
from app.update_queue_service import QueueActivationGates


def _document(*, environment: str = "local_test") -> dict:
    create_api_type, update_api_type = QUEUE_FAMILY_API_TYPES["new_licence"]
    evidence = {
        item.name: f"review:20261017:{item.name}"
        for item in fields(QueueActivationGates)
        if item.name != "native_intake_boundary_verified"
    }
    return {
        "update_queue_release": {
            "schema_version": 1,
            "review_id": "review:20261017:nla",
            "deployment_env": environment,
            "nocobase_base_url": (
                "http://host.docker.internal:13000/cmtf2"
                if environment == "online_test"
                else "http://127.0.0.1:13001/cmtf2"
            ),
            "source_system": "OP",
            "https_bind": "0.0.0.0" if environment == "online_test" else "127.0.0.1",
            "https_port": "443" if environment == "online_test" else "28443",
            "admission_workflow_key": "u2w20ale8lj",
            "rejection_workflow_key": "2jglgnj6mwt",
            "families": {
                "new_licence": {
                    "create_api_type": create_api_type,
                    "update_api_type": update_api_type,
                    "evidence": evidence,
                }
            },
        }
    }


def _profile(tmp_path: Path, document: dict) -> tuple[Path, str]:
    profile = tmp_path / "nocobase.yaml"
    content = yaml.safe_dump(document, sort_keys=False).encode()
    profile.write_bytes(content)
    return profile, hashlib.sha256(content).hexdigest()


def _load(profile: Path, digest: str, **overrides: object):
    values = {
        "profile_path": profile,
        "expected_sha256": digest,
        "deployment_env": "local_test",
        "nocobase_base_url": "http://127.0.0.1:13001/cmtf2",
        "source_system": "OP",
        "https_bind": "127.0.0.1",
        "https_port": "28443",
        "enabled_families": frozenset({"new_licence"}),
    }
    values.update(overrides)
    return load_reviewed_queue_release(**values)


def test_reviewed_manifest_requires_exact_profile_digest_and_binding(
    tmp_path: Path,
) -> None:
    profile, digest = _profile(tmp_path, _document())
    release = _load(profile, digest)
    assert release.families == frozenset({"new_licence"})
    assert release.gates.native_intake_boundary_race_accepted is True
    assert release.gates.native_intake_boundary_verified is False
    release.gates.require_ready()

    for changed in (
        {"expected_sha256": "0" * 64},
        {"expected_sha256": ""},
        {"deployment_env": "online_test"},
        {"nocobase_base_url": "http://127.0.0.1:13000/cmtf2"},
        {"source_system": "CMTF"},
        {"https_port": "443"},
        {"enabled_families": frozenset({"new_licence", "licence_renewal"})},
    ):
        with pytest.raises(RuntimeError):
            _load(profile, digest, **changed)


def test_online_test_review_is_bound_to_13000_and_public_443(
    tmp_path: Path,
) -> None:
    profile, digest = _profile(tmp_path, _document(environment="online_test"))
    release = _load(
        profile,
        digest,
        deployment_env="online_test",
        nocobase_base_url="http://host.docker.internal:13000/cmtf2",
        https_bind="0.0.0.0",
        https_port="443",
    )
    assert release.families == frozenset({"new_licence"})
    with pytest.raises(RuntimeError, match="runtime binding"):
        _load(
            profile,
            digest,
            deployment_env="online_test",
            nocobase_base_url="http://host.docker.internal:13001/cmtf2",
            https_bind="0.0.0.0",
            https_port="443",
        )


def test_reviewed_manifest_rejects_incomplete_or_wrong_family_evidence(
    tmp_path: Path,
) -> None:
    document = _document()
    family = document["update_queue_release"]["families"]["new_licence"]
    family["evidence"].pop("native_wake_path_verified")
    profile, digest = _profile(tmp_path, document)
    with pytest.raises(RuntimeError, match="gate evidence"):
        _load(profile, digest)

    document = _document()
    family = document["update_queue_release"]["families"]["new_licence"]
    family["update_api_type"] = "update_change_beds_data"
    profile, digest = _profile(tmp_path, document)
    with pytest.raises(RuntimeError, match="route binding"):
        _load(profile, digest)

    document = _document()
    family = document["update_queue_release"]["families"]["new_licence"]
    family["evidence"]["schema_verified"] = True
    profile, digest = _profile(tmp_path, document)
    with pytest.raises(RuntimeError, match="gate reference"):
        _load(profile, digest)

    document = _document()
    family = document["update_queue_release"]["families"]["new_licence"]
    family["evidence"].pop("native_intake_boundary_race_accepted")
    profile, digest = _profile(tmp_path, document)
    with pytest.raises(RuntimeError, match="Intake boundary"):
        _load(profile, digest)

    document = _document()
    document["update_queue_release"]["schema_version"] = 1.0
    profile, digest = _profile(tmp_path, document)
    with pytest.raises(RuntimeError, match="schema version"):
        _load(profile, digest)


def test_reviewed_manifest_validates_each_enabled_family(tmp_path: Path) -> None:
    document = _document()
    original = document["update_queue_release"]["families"]["new_licence"]
    create_api_type, update_api_type = QUEUE_FAMILY_API_TYPES["licence_renewal"]
    document["update_queue_release"]["families"]["licence_renewal"] = {
        "create_api_type": create_api_type,
        "update_api_type": update_api_type,
        "evidence": dict(original["evidence"]),
    }
    profile, digest = _profile(tmp_path, document)
    release = _load(
        profile,
        digest,
        enabled_families=frozenset({"new_licence", "licence_renewal"}),
    )
    assert release.families == frozenset({"new_licence", "licence_renewal"})
    document["update_queue_release"]["families"]["licence_renewal"][
        "evidence"
    ].pop("native_reconciliation_verified")
    profile, digest = _profile(tmp_path, document)
    with pytest.raises(RuntimeError, match="gate evidence"):
        _load(
            profile,
            digest,
            enabled_families=frozenset({"new_licence", "licence_renewal"}),
        )


def test_reviewed_mode_is_off_without_all_four_runtime_switches(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    profile, digest = _profile(tmp_path, _document())
    settings = SimpleNamespace(
        nocobase=SimpleNamespace(source_path=profile),
        nocobase_base_url="http://127.0.0.1:13001/cmtf2",
        source_system="OP",
    )
    client = object()
    families = frozenset({"new_licence"})
    monkeypatch.setenv("DEPLOYMENT_ENV", "local_test")
    monkeypatch.setenv("KONG_HTTPS_BIND", "127.0.0.1")
    monkeypatch.setenv("KONG_HTTPS_PORT", "28443")
    monkeypatch.setenv("UPDATE_QUEUE_RELEASE_MODE", "reviewed")
    monkeypatch.setenv("UPDATE_QUEUE_RELEASE_SHA256", digest)
    assert _update_queue_service_from_env(client, settings, families) is None

    monkeypatch.setenv("UPDATE_QUEUE_ENABLED", "1")
    service = _update_queue_service_from_env(client, settings, families)
    assert service is not None
    assert service._pilot_nla_test_mode is False
    service._gates.require_ready()
    assert service._admission_workflow_key == "u2w20ale8lj"

    monkeypatch.delenv("UPDATE_QUEUE_RELEASE_SHA256")
    with pytest.raises(RuntimeError, match="SHA-256"):
        _update_queue_service_from_env(client, settings, families)

    monkeypatch.setenv("UPDATE_QUEUE_RELEASE_SHA256", digest)
    monkeypatch.setenv("UPDATE_QUEUE_RELEASE_MODE", "disabled")
    with pytest.raises(RuntimeError, match="mode is invalid"):
        _update_queue_service_from_env(client, settings, families)
