"""Local-only UPDATE admission tests; no NocoBase or database connection."""

from __future__ import annotations

from dataclasses import fields, replace
from typing import Any
from unittest.mock import AsyncMock

import pytest

from app.errors import AdapterError
from app.nocobase_client import NocoBaseClient
from app.update_queue_service import (
    QueueActivationGates,
    QueueAdmissionService,
    QueueFamily,
    classify_admission_readback,
    parse_enabled_queue_families,
)

FAMILY = QueueFamily(
    source_system="OP",
    application_type="new_licence",
    create_api_type="create_intake_for_new_licence",
    update_api_type="update_new_licence_data",
)
LRN_FAMILY = QueueFamily(
    source_system="OP",
    application_type="licence_renewal",
    create_api_type="create_licence_renewal",
    update_api_type="update_licence_renewal_data",
)
BODY = {"request_id": "OP-UPDATE-1", "form_data": {"part_1": {"telephone": "27123456"}}}


def test_queue_family_allowlist_is_exact_and_default_off() -> None:
    assert parse_enabled_queue_families(None) == frozenset()
    assert parse_enabled_queue_families(" ") == frozenset()
    assert parse_enabled_queue_families("new_licence, changing_home") == frozenset(
        {"new_licence", "changing_home"}
    )
    for invalid in (
        "*",
        "new_licence,",
        "new_licence,new_licence",
        "prosecution",
        "revoke_licence",
        "new-license",
    ):
        with pytest.raises(ValueError):
            parse_enabled_queue_families(invalid)


def ready_gates() -> QueueActivationGates:
    return QueueActivationGates(
        **{item.name: True for item in fields(QueueActivationGates)}
    )


class FakeClient:
    def __init__(self) -> None:
        self.parent: dict[str, Any] = {
            "id": 100,
            "f_request_event": "CREATE",
            "f_source_system": "OP",
            "f_api_type": "create_intake_for_new_licence",
            "f_application_type": "new_licence",
            "f_application_status": "Accepted",
            "f_queue_next_sequence": 0,
        }
        self.rows: dict[int, dict[str, Any]] = {}
        self.calls: list[tuple[str, str]] = []
        self.action_mode = "admit"
        self.wake_mode = "wake"
        self.create_timeout_after_insert = False
        self.create_count = 0

    async def get_record(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(("get", kwargs["authorization_token"]))
        record_id = int(kwargs["record_id"])
        if record_id == 100:
            return dict(self.parent)
        return dict(self.rows[record_id])

    async def list_records(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(("list", kwargs["authorization_token"]))
        assert kwargs["collection"] == "t_api_request_staging"
        assert kwargs["page_size"] == 2
        filters = kwargs["filters"]["$and"]
        criteria = {
            key: value["$eq"] for item in filters for key, value in item.items()
        }
        rows = [
            dict(row)
            for row in self.rows.values()
            if all(row.get(key) == value for key, value in criteria.items())
        ]
        return {"data": rows[:2], "meta": {}}

    async def create_request_staging(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(("create", kwargs["authorization_token"]))
        self.create_count += 1
        row = {"id": 201, **kwargs["values"]}
        self.rows[201] = row
        if self.create_timeout_after_insert:
            raise AdapterError(504, "upstream_timeout", "Timed out")
        return dict(row)

    async def trigger_staging_custom_action(self, **kwargs: Any) -> None:
        self.calls.append((kwargs["workflow_key"], kwargs["authorization_token"]))
        assert kwargs["staging_id"] == 201
        row = self.rows[201]
        if kwargs["workflow_key"] == "admit-key":
            if self.action_mode in {"admit", "admit_then_timeout"}:
                if self.parent["f_application_status"] == "Accepted":
                    self.parent["f_queue_next_sequence"] += 1
                    row["f_queue_counted"] = True
                    row["f_queue_sequence"] = self.parent["f_queue_next_sequence"]
            elif self.action_mode == "received_while_pending":
                self.parent["f_application_status"] = "Received"
            if self.action_mode == "admit_then_timeout":
                raise AdapterError(504, "upstream_timeout", "Timed out")
        elif kwargs["workflow_key"] == "reject-key":
            row["f_status"] = "failed"
            if self.parent["f_application_status"] != "Accepted":
                row["f_error_message"] = "update_locked"
        else:
            raise AssertionError("Unexpected Custom Action key")

    async def update_record_if(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(("wake", kwargs["authorization_token"]))
        assert kwargs["collection"] == "t_api_request_staging"
        assert kwargs["record_id"] == 201
        assert kwargs["expected"] == {
            "f_status": "admission_pending",
            "f_queue_counted": True,
            "f_active_update_id": self.rows[201]["f_active_update_id"],
        }
        assert kwargs["values"] == {"f_status": "queued"}
        if self.wake_mode in {"wake", "wake_then_timeout"}:
            self.rows[201]["f_status"] = "queued"
        if self.wake_mode == "wake_then_timeout":
            raise AdapterError(504, "upstream_timeout", "Timed out")
        return {}


def service(client: FakeClient, **kwargs: Any) -> QueueAdmissionService:
    return QueueAdmissionService(
        client,  # type: ignore[arg-type]
        gates=ready_gates(),
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
        **kwargs,
    )


async def admit(client: FakeClient, **kwargs: Any) -> Any:
    return await service(client, **kwargs).admit_update(
        authorization_token="customer-token",
        transport_request_id="transport-1",
        client_request_id="OP-UPDATE-1",
        create_id=100,
        request_body=BODY,
        family=FAMILY,
        context={"f_office_code": "LORCHE", "f_user_role": "op_client"},
    )


@pytest.mark.asyncio
async def test_queue_service_is_default_off_before_any_upstream_io() -> None:
    client = FakeClient()
    candidate = QueueAdmissionService(client)  # type: ignore[arg-type]
    with pytest.raises(AdapterError) as caught:
        await candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-1",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body=BODY,
            family=FAMILY,
        )
    assert (caught.value.status_code, caught.value.code) == (
        503, "update_queue_not_ready"
    )
    assert client.calls == []


@pytest.mark.asyncio
async def test_nla_only_pilot_bypasses_release_evidence_but_not_family_binding(
) -> None:
    client = FakeClient()
    candidate = QueueAdmissionService(
        client,  # type: ignore[arg-type]
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
        pilot_nla_test_mode=True,
    )
    result = await candidate.admit_update(
        authorization_token="customer-token",
        transport_request_id="transport-1",
        client_request_id="OP-UPDATE-1",
        create_id=100,
        request_body=BODY,
        family=FAMILY,
    )
    assert result.status == "accepted"
    assert client.rows[201]["f_status"] == "queued"

    another_client = FakeClient()
    another_candidate = QueueAdmissionService(
        another_client,  # type: ignore[arg-type]
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
        pilot_nla_test_mode=True,
    )
    with pytest.raises(AdapterError, match="NLA pilot binding is invalid"):
        await another_candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-1",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body=BODY,
            family=replace(FAMILY, application_type="changing_home"),
        )
    assert another_client.calls == []


@pytest.mark.asyncio
async def test_lrn_only_pilot_keeps_customer_token_and_exact_family() -> None:
    client = FakeClient()
    client.parent["f_application_type"] = "licence_renewal"
    client.parent["f_api_type"] = "create_licence_renewal"
    candidate = QueueAdmissionService(
        client,  # type: ignore[arg-type]
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
        pilot_lrn_test_mode=True,
    )
    body = {"request_id": "OP-UPDATE-1", "form_data": {"part_5": {"checklist": []}}}
    result = await candidate.admit_update(
        authorization_token="customer-token",
        transport_request_id="transport-1",
        client_request_id="OP-UPDATE-1",
        create_id=100,
        request_body=body,
        family=LRN_FAMILY,
    )
    assert result.status == "accepted"
    assert client.rows[201]["f_status"] == "queued"
    assert all(token == "customer-token" for _action, token in client.calls)

    wrong = FakeClient()
    wrong_candidate = QueueAdmissionService(
        wrong,  # type: ignore[arg-type]
        pilot_lrn_test_mode=True,
    )
    with pytest.raises(AdapterError, match="LRN pilot binding is invalid"):
        await wrong_candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-1",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body=body,
            family=FAMILY,
        )
    assert wrong.calls == []

    with pytest.raises(ValueError, match="Only one local"):
        QueueAdmissionService(
            wrong,  # type: ignore[arg-type]
            pilot_nla_test_mode=True,
            pilot_lrn_test_mode=True,
        )


@pytest.mark.asyncio
async def test_native_intake_boundary_is_an_independent_activation_gate() -> None:
    client = FakeClient()
    candidate = QueueAdmissionService(
        client,  # type: ignore[arg-type]
        gates=replace(
            ready_gates(),
            native_intake_boundary_verified=False,
            native_intake_boundary_race_accepted=False,
        ),
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
    )
    with pytest.raises(AdapterError) as caught:
        await candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-1",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body=BODY,
            family=FAMILY,
        )
    assert (caught.value.status_code, caught.value.code) == (
        503, "update_queue_not_ready"
    )
    assert client.calls == []


@pytest.mark.asyncio
async def test_boundary_waiver_does_not_bypass_other_gates() -> None:
    client = FakeClient()
    candidate = QueueAdmissionService(
        client,  # type: ignore[arg-type]
        gates=replace(
            ready_gates(),
            native_intake_boundary_verified=False,
            native_intake_boundary_race_accepted=True,
            native_worker_revisions_verified=False,
        ),
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
    )
    with pytest.raises(AdapterError) as caught:
        await candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-1",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body=BODY,
            family=FAMILY,
        )
    assert (caught.value.status_code, caught.value.code) == (
        503, "update_queue_not_ready"
    )
    assert client.calls == []


@pytest.mark.asyncio
async def test_post_received_cancellation_is_an_independent_gate() -> None:
    client = FakeClient()
    candidate = QueueAdmissionService(
        client,  # type: ignore[arg-type]
        gates=replace(ready_gates(), post_received_cancel_verified=False),
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
    )
    with pytest.raises(AdapterError) as caught:
        await candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-1",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body=BODY,
            family=FAMILY,
        )
    assert (caught.value.status_code, caught.value.code) == (
        503, "update_queue_not_ready"
    )
    assert client.calls == []


@pytest.mark.asyncio
async def test_boundary_waiver_passes_only_full_other_gates() -> None:
    client = FakeClient()
    candidate = QueueAdmissionService(
        client,  # type: ignore[arg-type]
        gates=replace(
            ready_gates(),
            native_intake_boundary_verified=False,
            native_intake_boundary_race_accepted=True,
        ),
        admission_workflow_key="admit-key",
        rejection_workflow_key="reject-key",
    )
    result = await candidate.admit_update(
        authorization_token="customer-token",
        transport_request_id="transport-1",
        client_request_id="OP-UPDATE-1",
        create_id=100,
        request_body=BODY,
        family=FAMILY,
    )
    assert result.status == "accepted"


@pytest.mark.asyncio
async def test_admission_creates_pending_then_requires_exact_readback() -> None:
    client = FakeClient()
    result = await admit(client)
    assert (result.create_id, result.update_id, result.status, result.replayed) == (
        "100", 201, "accepted", False
    )
    assert client.rows[201]["f_status"] == "queued"
    assert client.rows[201]["f_client_request_id"] == "OP-UPDATE-1"
    assert client.rows[201]["f_request_body"] == BODY
    assert client.rows[201]["f_queue_counted"] is True
    assert client.create_count == 1
    assert {token for _, token in client.calls} == {"customer-token"}
    assert [name for name, _ in client.calls].count("wake") == 1
    assert "customer-token" not in str(client.rows[201])


@pytest.mark.asyncio
async def test_custom_action_http_200_with_zero_rows_never_acknowledges() -> None:
    client = FakeClient()
    client.action_mode = "no_change"
    with pytest.raises(AdapterError) as caught:
        await admit(client)
    assert (caught.value.status_code, caught.value.code) == (
        503, "update_queue_unconfirmed"
    )
    assert client.create_count == 1
    assert [name for name, _ in client.calls].count("admit-key") == 2
    assert client.rows[201]["f_status"] == "admission_pending"


@pytest.mark.asyncio
async def test_timeout_after_insert_recovers_existing_row_not_duplicate() -> None:
    client = FakeClient()
    client.create_timeout_after_insert = True
    result = await admit(client)
    assert (result.update_id, result.replayed) == (201, True)
    assert client.create_count == 1
    assert client.rows[201]["f_status"] == "queued"


@pytest.mark.asyncio
async def test_action_timeout_after_commit_is_confirmed_by_child_readback() -> None:
    client = FakeClient()
    client.action_mode = "admit_then_timeout"
    result = await admit(client)
    assert result.status == "accepted"
    assert [name for name, _ in client.calls].count("admit-key") == 1


@pytest.mark.asyncio
async def test_orm_wake_timeout_after_commit_is_confirmed_by_readback() -> None:
    client = FakeClient()
    client.wake_mode = "wake_then_timeout"
    result = await admit(client)
    assert result.status == "accepted"
    assert client.rows[201]["f_status"] == "queued"
    assert [name for name, _ in client.calls].count("wake") == 1


@pytest.mark.asyncio
async def test_orm_wake_zero_row_does_not_acknowledge_counted_pending() -> None:
    client = FakeClient()
    client.wake_mode = "no_change"
    with pytest.raises(AdapterError) as caught:
        await admit(client)
    assert (caught.value.status_code, caught.value.code) == (
        503, "update_queue_unconfirmed"
    )
    assert client.rows[201]["f_status"] == "admission_pending"
    assert client.rows[201]["f_queue_counted"] is True
    assert [name for name, _ in client.calls].count("wake") == 2
    assert [name for name, _ in client.calls].count("admit-key") == 1


@pytest.mark.asyncio
async def test_replay_wakes_counted_pending_without_re_admission() -> None:
    client = FakeClient()
    client.wake_mode = "no_change"
    with pytest.raises(AdapterError):
        await admit(client)
    client.wake_mode = "wake"
    result = await admit(client)
    assert result.replayed is True
    assert client.create_count == 1
    assert [name for name, _ in client.calls].count("admit-key") == 1
    assert client.rows[201]["f_status"] == "queued"


@pytest.mark.asyncio
async def test_same_request_id_different_body_is_conflict() -> None:
    client = FakeClient()
    await admit(client)
    candidate = service(client)
    with pytest.raises(AdapterError) as caught:
        await candidate.admit_update(
            authorization_token="customer-token",
            transport_request_id="transport-2",
            client_request_id="OP-UPDATE-1",
            create_id=100,
            request_body={
                "request_id": "OP-UPDATE-1",
                "form_data": {"part_1": {"telephone": "different"}},
            },
            family=FAMILY,
        )
    assert (caught.value.status_code, caught.value.code) == (
        409, "idempotency_conflict"
    )
    assert client.create_count == 1


@pytest.mark.asyncio
async def test_duplicate_terminal_success_replays_original_admission() -> None:
    client = FakeClient()
    await admit(client)
    client.rows[201].update(
        f_status="succeeded",
        f_queue_counted=False,
        f_attempt_count=1,
        f_queue_phase="applying",
    )
    client.parent["f_application_status"] = "Received"
    client.parent["f_queue_pending_count"] = 0
    result = await admit(client)
    assert result.replayed is True
    assert client.create_count == 1


@pytest.mark.asyncio
async def test_duplicate_after_atomic_terminal_release_replays_admission() -> None:
    client = FakeClient()
    await admit(client)
    client.rows[201].update(
        f_status="succeeded",
        f_queue_counted=False,
        f_attempt_count=1,
        f_queue_phase="finished",
    )
    client.parent.update(
        f_application_status="Received",
        f_queue_pending_count=0,
        f_active_update_id=None,
    )
    result = await admit(client)
    assert result.replayed is True
    assert client.create_count == 1
    assert [name for name, _ in client.calls].count("admit-key") == 1


@pytest.mark.asyncio
async def test_terminal_before_parent_release_replays_without_token_storage() -> None:
    client = FakeClient()
    await admit(client)
    client.rows[201].update(
        f_status="succeeded", f_queue_counted=True,
        f_attempt_count=1, f_queue_phase="applying",
    )
    client.parent["f_queue_pending_count"] = 1
    result = await admit(client)
    assert result.replayed is True
    assert {token for _, token in client.calls} == {"customer-token"}
    assert "customer-token" not in str(client.rows[201])


@pytest.mark.asyncio
async def test_received_parent_audits_new_update_then_returns_locked() -> None:
    client = FakeClient()
    client.parent["f_application_status"] = "Received"
    with pytest.raises(AdapterError) as caught:
        await admit(client)
    assert (caught.value.status_code, caught.value.code) == (409, "update_locked")
    assert caught.value.details == {"field": "create_id", "status": "Received"}
    assert client.create_count == 1
    assert client.rows[201]["f_request_body"] == BODY
    assert client.rows[201]["f_parent_create_id"] == "100"
    assert client.rows[201]["f_status"] == "failed"
    assert client.rows[201]["f_error_message"] == "update_locked"
    assert client.rows[201]["f_queue_counted"] is False
    assert [name for name, _ in client.calls].count("reject-key") == 1
    assert [name for name, _ in client.calls].count("wake") == 0


@pytest.mark.asyncio
async def test_received_parent_replays_same_locked_audit_without_duplicate() -> None:
    client = FakeClient()
    client.parent["f_application_status"] = "Received"
    with pytest.raises(AdapterError) as first:
        await admit(client)
    with pytest.raises(AdapterError) as replay:
        await admit(client)
    assert (first.value.status_code, first.value.code) == (409, "update_locked")
    assert (replay.value.status_code, replay.value.code) == (409, "update_locked")
    assert client.create_count == 1
    assert [name for name, _ in client.calls].count("reject-key") == 1


@pytest.mark.asyncio
async def test_received_race_rejects_only_uncounted_pending_child() -> None:
    client = FakeClient()
    client.action_mode = "received_while_pending"
    with pytest.raises(AdapterError) as caught:
        await admit(client)
    assert (caught.value.status_code, caught.value.code) == (409, "update_locked")
    assert client.rows[201]["f_status"] == "failed"
    assert client.rows[201]["f_queue_counted"] is False
    assert [name for name, _ in client.calls].count("reject-key") == 1


@pytest.mark.asyncio
async def test_older_staging_id_admitted_after_newer_uses_later_sequence() -> None:
    client = FakeClient()
    client.parent["f_queue_next_sequence"] = 1
    client.rows[202] = {
        "id": 202,
        "f_parent_create_id": "100",
        "f_queue_counted": True,
        "f_queue_sequence": 1,
        "f_status": "queued",
    }
    result = await admit(client)
    assert result.status == "accepted"
    assert client.rows[201]["f_queue_sequence"] == 2
    assert client.rows[201]["f_queue_counted"] is True
    assert [name for name, _ in client.calls].count("reject-key") == 0
    assert client.create_count == 1


def test_classifier_refuses_unreserved_or_uncounted_active_row() -> None:
    row: dict[str, Any] = {
        "id": 201,
        "f_request_event": "UPDATE",
        "f_source_system": "OP",
        "f_api_type": "update_new_licence_data",
        "f_application_type": "new_licence",
        "f_parent_create_id": "100",
        "f_client_request_id": "OP-UPDATE-1",
        "f_request_body": BODY,
        "f_status": "queued",
        "f_queue_counted": True,
    }
    params = dict(
        row=row,
        parent_application_status="Accepted",
        parent_next_sequence=1,
        family=FAMILY,
        create_id="100",
        client_request_id="OP-UPDATE-1",
        request_body=BODY,
        reservation_id=None,
    )
    assert classify_admission_readback(**params) == "isolate"
    row["f_active_update_id"] = "reservation-1"
    row["f_queue_counted"] = False
    assert classify_admission_readback(**params) == "isolate"
    row["f_queue_counted"] = True
    row["f_queue_sequence"] = 1
    params["parent_application_status"] = "Received"
    assert classify_admission_readback(**params) == "accepted"

    row["f_status"] = "admission_pending"
    assert classify_admission_readback(**params) == "accepted"

    # A confirmed admission cancelled after the native boundary must replay
    # the same Accepted result rather than pretending it was never admitted.
    row.update(
        f_status="failed",
        f_queue_counted=False,
        f_error_message="update_locked_after_admission",
    )
    assert classify_admission_readback(**params) == "accepted"


@pytest.mark.asyncio
async def test_nocobase_trigger_uses_customer_token_and_requires_readback() -> None:
    client = object.__new__(NocoBaseClient)
    client._request_json = AsyncMock(return_value={})  # type: ignore[method-assign]
    result = await client.trigger_staging_custom_action(
        staging_id=201,
        workflow_key="admit-key",
        request_id="transport-1",
        authorization_token="customer-token",
    )
    assert result is None
    client._request_json.assert_awaited_once_with(
        "POST",
        "/api/t_api_request_staging:trigger",
        request_id="transport-1",
        authorization_token="customer-token",
        params=[("filterByTk", "201"), ("triggerWorkflows", "admit-key")],
        json_body={},
        unwrap_data=False,
    )
