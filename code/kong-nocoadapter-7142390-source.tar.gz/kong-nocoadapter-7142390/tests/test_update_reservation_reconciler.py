from __future__ import annotations

import json
import sys
import urllib.parse
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from extend_nocobase_staging_relations import ApiError  # noqa: E402
from reconcile_nocobase_update_reservations import (  # noqa: E402
    CONFIRMATION_PHRASE,
    audit_reservations,
    main,
    publish_received_if_complete,
    recover_reservation,
)


class FakeApi:
    def __init__(self, responses: list[Any]) -> None:
        self.responses = list(responses)
        self.calls: list[tuple[str, str, Any]] = []

    def request(self, method: str, path: str, body: Any = None) -> Any:
        self.calls.append((method, path, body))
        return self.responses.pop(0) if self.responses else []


NOW = datetime(2026, 9, 23, 2, 0, tzinfo=timezone.utc)
STALE_AFTER = timedelta(minutes=60)


def valid_parent(**overrides: Any) -> dict[str, Any]:
    row = {
        "id": 1,
        "f_request_event": "CREATE",
        "f_status": "succeeded",
        "f_application_status": "Accepted",
        "f_application_type": "change_home_manager",
        "f_api_type": "create_intake_for_change_home_manager",
        "f_active_update_id": "reservation-1",
        "f_intake_id": 30,
        "f_application_id": 40,
        "updatedAt": "2026-09-23T00:00:00Z",
    }
    row.update(overrides)
    return row


def valid_child(**overrides: Any) -> dict[str, Any]:
    row = {
        "id": 20,
        "f_request_event": "UPDATE",
        "f_status": "succeeded",
        "f_parent_create_id": "1",
        "f_active_update_id": "reservation-1",
        "f_application_type": "change_home_manager",
        "f_api_type": "update_change_home_manager_data",
        "updatedAt": "2026-09-23T00:10:00Z",
    }
    row.update(overrides)
    return row


def test_old_orphan_without_update_child_is_manual_review_not_recoverable() -> None:
    api = FakeApi([[valid_parent()], [], []])

    recoverable, manual_review, active = audit_reservations(
        api, now=NOW, stale_after=STALE_AFTER
    )

    assert recoverable == []
    assert [row["id"] for row in manual_review] == [1]
    assert manual_review[0]["reasons"] == ["no_matching_update_child"]
    assert active == []


def test_stale_processing_child_is_manual_review_not_recoverable() -> None:
    child = valid_child(f_status="processing")
    api = FakeApi([[valid_parent()], [child], [child]])

    recoverable, manual_review, active = audit_reservations(
        api, now=NOW, stale_after=STALE_AFTER
    )

    assert recoverable == []
    assert manual_review[0]["reasons"] == ["stale_active_update_child"]
    assert active == []


@pytest.mark.parametrize("terminal_status", ["succeeded", "failed"])
def test_one_old_terminal_child_with_exact_identity_is_recoverable(
    terminal_status: str,
) -> None:
    api = FakeApi(
        [[valid_parent()], [valid_child(f_status=terminal_status)], []]
    )

    recoverable, manual_review, active = audit_reservations(
        api, now=NOW, stale_after=STALE_AFTER
    )

    assert [row["id"] for row in recoverable] == [1]
    assert recoverable[0]["reasons"] == ["terminal_child_finalizer_stale"]
    assert manual_review == []
    assert active == []


def test_terminal_child_with_wrong_api_identity_is_manual_review() -> None:
    child = valid_child(f_api_type="update_change_beds_data")
    api = FakeApi([[valid_parent()], [child], []])

    recoverable, manual_review, active = audit_reservations(
        api, now=NOW, stale_after=STALE_AFTER
    )

    assert recoverable == []
    assert manual_review[0]["reasons"] == ["child_update_api_mismatch"]
    assert active == []


def test_parent_with_wrong_create_api_identity_is_manual_review() -> None:
    parent = valid_parent(f_api_type="create_intake_for_change_beds")
    api = FakeApi([[parent], [valid_child()], []])

    recoverable, manual_review, active = audit_reservations(
        api, now=NOW, stale_after=STALE_AFTER
    )

    assert recoverable == []
    assert manual_review[0]["reasons"] == ["parent_create_api_mismatch"]
    assert active == []


def test_recent_terminal_child_stays_in_finalizer_grace_period() -> None:
    parent = valid_parent(updatedAt="2026-09-23T01:45:00Z")
    child = valid_child(updatedAt="2026-09-23T01:46:00Z")
    api = FakeApi([[parent], [child], []])

    recoverable, manual_review, active = audit_reservations(
        api, now=NOW, stale_after=STALE_AFTER
    )

    assert recoverable == []
    assert manual_review == []
    assert active[0]["reasons"] == ["terminal_child_finalizer_grace_period"]


def test_recovery_rechecks_evidence_and_atomically_publishes_received() -> None:
    parent = valid_parent()
    current = {
        **parent,
        "f_active_update_id": None,
        "f_application_status": "Received",
    }
    api = FakeApi(
        [
            [parent],  # targeted parent lookup
            [valid_child()],  # exact reservation child
            [],  # no active child for parent
            {"id": 30, "f_approval_status": "4"},
            [],  # compare-and-set response
            [current],  # verify parent
        ]
    )

    result = recover_reservation(
        api,
        parent_id=1,
        reservation_id="reservation-1",
        now=NOW,
        stale_after=STALE_AFTER,
    )

    assert result["cleared"] is True
    assert result["received"] is True
    method, path, body = api.calls[4]
    assert method == "POST"
    assert body == {
        "f_active_update_id": None,
        "f_application_status": "Received",
    }
    query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
    filters = json.loads(query["filter"][0])
    assert {"f_active_update_id": {"$eq": "reservation-1"}} in filters[
        "$and"
    ]
    assert {"f_status": {"$eq": "succeeded"}} in filters["$and"]
    assert {"f_application_status": {"$eq": "Accepted"}} in filters[
        "$and"
    ]


def test_recovery_refuses_an_orphan_even_with_exact_token() -> None:
    api = FakeApi([[valid_parent()], [], []])

    with pytest.raises(ApiError, match="no_matching_update_child"):
        recover_reservation(
            api,
            parent_id=1,
            reservation_id="reservation-1",
            now=NOW,
            stale_after=STALE_AFTER,
        )

    assert all(method == "GET" for method, _, _ in api.calls)


def test_recovery_detects_compare_and_set_that_did_not_clear() -> None:
    parent = valid_parent()
    api = FakeApi(
        [
            [parent],
            [valid_child()],
            [],
            {"id": 30, "f_approval_status": "0"},
            [],
            [parent],
        ]
    )

    with pytest.raises(ApiError, match="did not clear"):
        recover_reservation(
            api,
            parent_id=1,
            reservation_id="reservation-1",
            now=NOW,
            stale_after=STALE_AFTER,
        )


def test_publish_received_requires_complete_intake_and_idle_parent() -> None:
    api = FakeApi(
        [
            {"id": 30, "f_approval_status": "4"},
            [],
            [
                {
                    "id": 1,
                    "f_application_status": "Received",
                    "f_active_update_id": None,
                }
            ],
        ]
    )

    assert publish_received_if_complete(api, parent_id=1, intake_id=30) is True

    method, path, body = api.calls[1]
    assert method == "POST"
    assert body == {"f_application_status": "Received"}
    query = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
    filters = json.loads(query["filter"][0])
    assert {"f_application_status": {"$eq": "Accepted"}} in filters["$and"]
    assert {"f_active_update_id": {"$empty": True}} in filters["$and"]


def test_cli_disallows_broad_apply_without_exact_target(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("NOCOBASE_TOKEN", "test-only")

    result = main(
        [
            "--base-url",
            "http://example.invalid/cmtf2",
            "--apply",
        ]
    )

    assert result == 2
    assert "targeted recovery requires" in capsys.readouterr().err


def test_cli_requires_literal_confirmation_phrase(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("NOCOBASE_TOKEN", "test-only")

    result = main(
        [
            "--base-url",
            "http://example.invalid/cmtf2",
            "--apply",
            "--recover-parent-id",
            "1",
            "--expected-reservation-id",
            "reservation-1",
            "--operator",
            "Gregory Lee",
            "--reason",
            "workflow interrupted",
            "--confirm",
            "wrong",
        ]
    )

    assert result == 2
    assert CONFIRMATION_PHRASE in capsys.readouterr().err
