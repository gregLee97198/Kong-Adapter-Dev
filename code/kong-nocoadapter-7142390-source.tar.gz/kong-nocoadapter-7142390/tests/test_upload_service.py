from __future__ import annotations

from dataclasses import replace
from io import BytesIO
from pathlib import Path
from typing import Any, Optional

import pytest
from starlette.datastructures import Headers, UploadFile

from app.errors import AdapterError
from app.models import StorageInfo
from app.nocobase_config import NocoBaseProfile
from app.settings import Settings
from app.upload_service import UploadService

PROFILE_PATH = Path(__file__).parents[1] / "config/nocobase.yaml"
CLIENT_TOKEN = "client-native-token"


def settings(*, max_file_bytes: int = 1024) -> Settings:
    profile = replace(
        NocoBaseProfile.load(PROFILE_PATH),
        base_url="http://example.test/cmtf2",
        storage_selection="default",
        storage_name=None,
    )
    return Settings(
        nocobase=profile,
        nocobase_config_token="root-config-token",
        verify_tls=True,
        storage_cache_seconds=0,
        max_file_bytes=max_file_bytes,
        allowed_mime_types=frozenset({"application/pdf"}),
        connect_timeout_seconds=1,
        request_timeout_seconds=1,
        upload_timeout_seconds=1,
        max_connections=5,
        log_level="INFO",
    )


class FakeStorageCache:
    def __init__(
        self,
        *,
        storage_type: str = "s3-compatible",
        rules: Optional[dict[str, Any]] = None,
    ) -> None:
        self.storage_type = storage_type
        self.rules = rules or {"size": 20 * 1024 * 1024}

    async def get(self, request_id: str, *, force: bool = False) -> StorageInfo:
        return StorageInfo(
            id=2,
            name="configured-storage",
            type=self.storage_type,
            title="Configured storage",
            rules=self.rules,
        )


class FakeClient:
    def __init__(self) -> None:
        self.uploaded = b""
        self.created_attachment_kwargs: Optional[dict[str, Any]] = None
        self.server_upload_kwargs: Optional[dict[str, Any]] = None

    async def create_presigned_url(self, **kwargs):
        assert kwargs["authorization_token"] == CLIENT_TOKEN
        return {
            "putUrl": "https://objects.example.test/upload",
            "fileInfo": {
                "key": "api/generated.pdf",
                "title": "application.pdf",
                "extname": ".pdf",
                "size": kwargs["size"],
                "mimetype": kwargs["mime_type"],
                "meta": {},
            },
        }

    async def upload_object(self, **kwargs):
        chunks = []
        async for chunk in kwargs["content"]:
            chunks.append(chunk)
        self.uploaded = b"".join(chunks)
        return '"mock-etag"'

    async def create_attachment(self, **kwargs):
        assert kwargs["authorization_token"] == CLIENT_TOKEN
        self.created_attachment_kwargs = kwargs
        return {
            "id": 99,
            "title": "application.pdf",
            "filename": "api/generated.pdf",
            "size": kwargs["file_info"]["size"],
            "mimetype": "application/pdf",
        }

    async def upload_attachment_file(self, **kwargs):
        assert kwargs["authorization_token"] == CLIENT_TOKEN
        self.server_upload_kwargs = kwargs
        self.uploaded = kwargs["file_object"].read()
        return {
            "id": 100,
            "title": kwargs["filename"],
            "filename": f"uploads/{kwargs['filename']}",
            "size": len(self.uploaded),
            "mimetype": kwargs["mime_type"],
        }


def make_upload(content: bytes) -> UploadFile:
    return UploadFile(
        file=BytesIO(content),
        filename="application.pdf",
        headers=Headers({"content-type": "application/pdf"}),
    )


def make_service(client: FakeClient, storage: FakeStorageCache) -> UploadService:
    return UploadService(
        settings=settings(),
        client=client,
        storage_cache=storage,
    )


@pytest.mark.asyncio
async def test_s3_pro_upload_uses_client_token_for_business_operations() -> None:
    client = FakeClient()
    service = make_service(client, FakeStorageCache())

    result = await service.upload_file(
        upload=make_upload(b"%PDF-test"),
        request_id="request-file-1",
        external_request_id="external-file-1",
        expected_sha256=None,
        consumer_id="nocobase-user:42",
        authorization_token=CLIENT_TOKEN,
    )

    assert client.uploaded == b"%PDF-test"
    assert client.created_attachment_kwargs is not None
    assert client.created_attachment_kwargs["attachment_field_context"] is None
    assert result.data_id == 99
    assert result.filename == "application.pdf"
    assert result.size == len(b"%PDF-test")
    assert result.download_url == "/v1/files/99"


@pytest.mark.asyncio
async def test_local_storage_uses_server_side_multipart_with_client_token() -> None:
    client = FakeClient()
    service = make_service(client, FakeStorageCache(storage_type="local"))

    result = await service.upload_file(
        upload=make_upload(b"%PDF-local"),
        request_id="request-local",
        external_request_id=None,
        expected_sha256=None,
        consumer_id="nocobase-user:42",
        authorization_token=CLIENT_TOKEN,
    )

    assert client.created_attachment_kwargs is None
    assert client.server_upload_kwargs is not None
    assert client.uploaded == b"%PDF-local"
    assert result.data_id == 100
    assert result.filename == "application.pdf"
    assert result.download_url == "/v1/files/100"


@pytest.mark.asyncio
async def test_non_s3_pro_storage_uses_server_side_upload() -> None:
    client = FakeClient()
    service = make_service(client, FakeStorageCache(storage_type="s3"))

    result = await service.upload_file(
        upload=make_upload(b"%PDF-open-source-s3"),
        request_id="request-server-s3",
        external_request_id=None,
        expected_sha256=None,
        consumer_id="nocobase-user:42",
        authorization_token=CLIENT_TOKEN,
    )

    assert result.data_id == 100
    assert client.server_upload_kwargs is not None


@pytest.mark.asyncio
async def test_rejects_file_over_live_storage_limit() -> None:
    client = FakeClient()
    service = make_service(client, FakeStorageCache(rules={"size": 4}))

    with pytest.raises(AdapterError) as caught:
        await service.upload_file(
            upload=make_upload(b"12345"),
            request_id="request-file-3",
            external_request_id=None,
            expected_sha256=None,
            consumer_id="nocobase-user:42",
            authorization_token=CLIENT_TOKEN,
        )

    assert caught.value.code == "file_too_large_for_storage"
    assert client.uploaded == b""


@pytest.mark.asyncio
async def test_wildcard_mime_type_allows_generic_binary_files() -> None:
    wildcard_settings = replace(
        settings(),
        allowed_mime_types=frozenset({"*"}),
    )
    client = FakeClient()
    service = UploadService(
        settings=wildcard_settings,
        client=client,
        storage_cache=FakeStorageCache(),
    )
    upload = UploadFile(
        file=BytesIO(b"generic-binary"),
        filename="archive.bin",
        headers=Headers({"content-type": "application/octet-stream"}),
    )

    result = await service.upload_file(
        upload=upload,
        request_id="request-file-wildcard",
        external_request_id=None,
        expected_sha256=None,
        consumer_id="nocobase-user:42",
        authorization_token=CLIENT_TOKEN,
    )

    assert result.data_id == 99
    assert client.uploaded == b"generic-binary"


@pytest.mark.asyncio
async def test_rejects_oversized_file_before_any_upstream_write() -> None:
    client = FakeClient()
    service = UploadService(
        settings=settings(max_file_bytes=4),
        client=client,
        storage_cache=FakeStorageCache(),
    )

    with pytest.raises(AdapterError) as caught:
        await service.upload_file(
            upload=make_upload(b"12345"),
            request_id="request-oversized",
            external_request_id=None,
            expected_sha256=None,
            consumer_id="nocobase-user:42",
            authorization_token=CLIENT_TOKEN,
        )

    assert caught.value.code == "file_too_large"
    assert client.uploaded == b""
